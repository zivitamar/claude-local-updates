'use strict';
// ============================================================
//  Session host (HOT-UPDATE plan, stage 1.2).
//  A small long-lived process that OWNS the claude.exe / shell children, so the server can be
//  restarted (hot update) without killing running turns.
//    - pipe server (NDJSON, see proto.js): one authenticated server at a time
//    - per-session output ring with seq numbers; attach(fromSeq) replays exactly what was not acked
//    - hook/MCP gate on 127.0.0.1:<random>: forwards to the server, holds while no server, fallback after HOLD_MS
//  Runs inside the EXE as a utilityProcess (electron/host-child.js) or, in dev, as `node sessionhost.js`
//  (env: CLAUDE_HOST_PIPE, CLAUDE_HOST_TOKEN, CLAUDE_HOST_STATE, CLAUDE_HOST_DEV=1).
// ============================================================
const net = require('net');
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn, execFile } = require('child_process');
const { StringDecoder } = require('string_decoder');
const P = require('./proto');

const IDLE_MS = Number(process.env.CLAUDE_HOST_IDLE_MS) > 0 ? Number(process.env.CLAUDE_HOST_IDLE_MS) : 10 * 60 * 1000;
const FALLBACK_PRE = { hookSpecificOutput: { hookEventName: 'PreToolUse', permissionDecision: 'deny', permissionDecisionReason: 'Claude Local is restarting (update). Wait about 30 seconds and run the same tool again.' } };
const FALLBACK_MCP_TEXT = 'Claude Local is restarting \u2014 call the tool again in 30 seconds';

function codeHash(dir = __dirname) {
  const h = crypto.createHash('sha256');
  for (const f of ['sessionhost.js', 'proto.js']) { try { h.update(fs.readFileSync(path.join(dir, f))); } catch { } }
  return h.digest('hex').slice(0, 12);
}

function sysPaths() {
  const root = process.env.SystemRoot || process.env.windir || 'C:\\Windows';
  return {
    cmd: path.join(root, 'System32', 'cmd.exe'),
    powershell: path.join(root, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe'),
    taskkill: path.join(root, 'System32', 'taskkill.exe'),
  };
}
// spawn allowlist: an existing ...\claude.exe, or the system cmd.exe / powershell.exe. Returns the path to run or null.
function allowedCmd(cmd) {
  const f = String(cmd || '');
  if (!f) return null;
  const sp = sysPaths();
  const low = f.toLowerCase();
  if (low === 'cmd.exe' || low === 'cmd') return sp.cmd;
  if (low === 'powershell.exe' || low === 'powershell') return sp.powershell;
  if (path.isAbsolute(f)) {
    const r = path.resolve(f);
    if (/\\claude\.exe$/i.test(r) && fs.existsSync(r)) return r;
    if (r.toLowerCase() === sp.cmd.toLowerCase() || r.toLowerCase() === sp.powershell.toLowerCase()) return r;
  }
  return null;
}
function cleanEnv(env) {
  const out = Object.assign({}, env || process.env);
  for (const k of Object.keys(out)) if (/^CLAUDE_HOST_/i.test(k)) delete out[k];
  return out;
}

function startHost(opts = {}) {
  const token = String(opts.token || '');
  const pipe = opts.pipe;
  const stateDir = opts.stateDir || null;
  const devMode = !!opts.devMode;
  const onEvent = typeof opts.onEvent === 'function' ? opts.onEvent : () => { };
  const exitFn = typeof opts.exit === 'function' ? opts.exit : (c => process.exit(c));
  if (!pipe || token.length < 16) return Promise.reject(new Error('startHost: pipe and token required'));
  const HASH = codeHash();
  const startedAt = Date.now();

  // ---------- log ----------
  const logFile = stateDir ? path.join(stateDir, 'host.log') : null;
  try { if (stateDir) fs.mkdirSync(stateDir, { recursive: true }); } catch { }
  function log(...a) {
    const line = `[${new Date().toISOString()}] [host ${process.pid}] ${a.join(' ')}\n`;
    if (!logFile) return;
    try {
      try { if (fs.statSync(logFile).size > 1024 * 1024) fs.renameSync(logFile, logFile + '.1'); } catch { }
      fs.appendFileSync(logFile, line);
    } catch { }
  }

  // ---------- state ----------
  const sessions = new Map();       // sid -> session
  let active = null;                // the authenticated, non-detaching connection (gets live output + hooks)
  const conns = new Set();          // all open connections
  let sockBlocked = false;          // active socket is over its high-water mark
  let totalBytes = 0;
  let connSeq = 0;
  let hookPort = 0;
  let lastServerAt = Date.now();
  let exiting = false;

  // ---------- pid file (orphan sweep on the next start) ----------
  const pidFile = stateDir ? path.join(stateDir, 'host-pids.json') : null;
  function savePids() {
    if (!pidFile) return;
    const o = {};
    for (const s of sessions.values()) if (s.state === 'running' && s.pid) o[s.sid] = { pid: s.pid, startedAt: s.startedAt, image: path.basename(s.cmd || '') };
    try { fs.writeFileSync(pidFile + '.tmp', JSON.stringify(o)); fs.renameSync(pidFile + '.tmp', pidFile); } catch (e) { log('savePids failed', e.message); }
  }
  function orphanSweep() {
    if (!pidFile) return Promise.resolve(0);
    let prev = {};
    try { prev = JSON.parse(fs.readFileSync(pidFile, 'utf8')) || {}; } catch { return Promise.resolve(0); }
    const items = Object.values(prev).filter(x => x && Number(x.pid) > 0);
    savePids();
    if (!items.length) return Promise.resolve(0);
    const ids = items.map(x => Number(x.pid)).join(',');
    const ps = `Get-Process -Id ${ids} -ErrorAction SilentlyContinue | ForEach-Object { '{0} {1} {2}' -f $_.Id, $_.ProcessName, ([DateTimeOffset]$_.StartTime).ToUnixTimeMilliseconds() }`;
    return new Promise(resolve => {
      execFile(sysPaths().powershell, ['-NoProfile', '-NonInteractive', '-Command', ps], { windowsHide: true, timeout: 15000 }, (err, stdout) => {
        let killed = 0;
        const live = new Map();
        for (const l of String(stdout || '').split(/\r?\n/)) { const m = /^(\d+) (\S+) (\d+)$/.exec(l.trim()); if (m) live.set(Number(m[1]), { name: m[2].toLowerCase(), start: Number(m[3]) }); }
        for (const it of items) {
          const p = live.get(Number(it.pid));
          if (!p) continue;
          const img = String(it.image || '').toLowerCase().replace(/\.exe$/, '');
          if (img && p.name !== img) continue;                         // pid was reused by another program
          if (Math.abs(p.start - Number(it.startedAt || 0)) > 15000) continue; // same name, different process
          killTreePid(it.pid); killed++;
          log('orphanSweep: killed tree of', it.pid, img);
        }
        resolve(killed);
      });
    });
  }
  function killTreePid(pid) {
    return new Promise(resolve => {
      if (!(pid > 0)) return resolve();
      execFile(sysPaths().taskkill, ['/PID', String(pid), '/T', '/F'], { windowsHide: true, timeout: 10000 }, () => resolve());
    });
  }

  // ---------- sending ----------
  function writeTo(c, obj) {
    if (!c || c.closed) return true;
    let s; try { s = JSON.stringify(obj) + '\n'; } catch { return true; }
    return c.sock.write(s);
  }
  function sendActive(str) {
    if (!active) return;
    const ok = active.sock.write(str);
    if (!ok && !sockBlocked) {
      sockBlocked = true; applyFlowAll();
      const c = active;
      c.sock.once('drain', () => { if (active === c) { sockBlocked = false; applyFlowAll(); } });
    }
  }

  // ---------- flow control ----------
  function applyFlow(s) {
    if (!s.child || s.state !== 'running') return;
    const want = s.ringPaused || (sockBlocked && s.attached);
    if (want === s.paused) return;
    s.paused = want;
    for (const st of [s.child.stdout, s.child.stderr]) { try { want ? st.pause() : st.resume(); } catch { } }
  }
  function applyFlowAll() { for (const s of sessions.values()) applyFlow(s); }
  function checkTotal() {
    while (totalBytes > P.TOTAL_MAX) {
      let big = null;
      for (const s of sessions.values()) if (s.state === 'running' && !s.ringPaused && (!big || s.bufBytes > big.bufBytes)) big = s;
      if (!big) break;
      big.ringPaused = true; applyFlow(big);
      log('total ring over', P.TOTAL_MAX, '- paused', big.sid);
      if (totalBytes - big.bufBytes <= P.TOTAL_MAX) break;
    }
  }

  // ---------- session output ----------
  function push(s, frame) {
    const str = JSON.stringify(frame) + '\n';
    const bytes = Buffer.byteLength(str);
    s.ring.push({ seq: frame.seq, str, bytes });
    s.bufBytes += bytes; totalBytes += bytes;
    if (s.bufBytes > P.RING_MAX && !s.ringPaused) { s.ringPaused = true; applyFlow(s); }
    checkTotal();
    if (s.attached && active) sendActive(str);
  }
  function emitLine(s, stream, line) {
    if (line.endsWith('\r')) line = line.slice(0, -1);
    s.seq++;
    push(s, { t: 'out', sid: s.sid, seq: s.seq, s: stream, line });
  }
  function feed(s, stream, chunk) {
    const st = s.lb[stream];
    st.buf += st.dec.write(chunk);
    let i;
    while ((i = st.buf.indexOf('\n')) >= 0) { const line = st.buf.slice(0, i); st.buf = st.buf.slice(i + 1); emitLine(s, stream, line); }
  }
  function flushPartial(s) {
    for (const k of ['o', 'e']) { const st = s.lb[k]; st.buf += st.dec.end(); if (st.buf.length) { const l = st.buf; st.buf = ''; emitLine(s, k, l); } }
  }

  function sessInfo(s) {
    return { sid: s.sid, key: s.key, pid: s.pid, state: s.state, exitCode: s.exitCode, lastSeq: s.seq, ackSeq: s.ackSeq, wids: s.widList.slice(-200), startedAt: s.startedAt, bufBytes: s.bufBytes, paused: !!s.paused };
  }
  function listSessions() { return [...sessions.values()].map(sessInfo); }

  // ---------- session ops ----------
  function spawnSession(c, f) {
    const rid = f.rid;
    const sid = String(f.sid || '');
    if (!sid) return writeTo(c, { t: 'err', rid, code: 'bad', msg: 'sid required' });
    const ex = sessions.get(sid);
    if (ex) return writeTo(c, { t: 'spawned', rid, sid, pid: ex.pid, dup: true });
    const file = allowedCmd(f.cmd);
    if (!file) { log('spawn REJECTED (not allowlisted):', JSON.stringify(String(f.cmd || '')).slice(0, 300)); return writeTo(c, { t: 'err', rid, code: 'denied', msg: 'command not allowed' }); }
    const args = Array.isArray(f.args) ? f.args.map(String) : [];
    let child;
    try {
      child = spawn(file, args, { cwd: f.cwd || undefined, env: cleanEnv(f.env), windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'], windowsVerbatimArguments: !!f.verbatim });
    } catch (e) { return writeTo(c, { t: 'err', rid, code: 'spawn', msg: String(e && e.message || e) }); }
    if (!child.pid) {
      child.once('error', e => writeTo(c, { t: 'err', rid, code: 'spawn', msg: String(e && e.message || e) }));
      return;
    }
    const s = {
      sid, key: f.key || null, pid: child.pid, cmd: file, child, state: 'running', exitCode: null,
      seq: 0, ackSeq: 0, ring: [], bufBytes: 0, wids: new Set(), widList: [], startedAt: Date.now(),
      paused: false, ringPaused: false, attached: c === active, released: false, killed: false,
      lb: { o: { dec: new StringDecoder('utf8'), buf: '' }, e: { dec: new StringDecoder('utf8'), buf: '' } },
    };
    sessions.set(sid, s);
    savePids();
    log('spawn', sid, s.pid, path.basename(file), JSON.stringify(s.key || {}).slice(0, 200));
    writeTo(c, { t: 'spawned', rid, sid, pid: s.pid });
    child.stdout.on('data', d => feed(s, 'o', d));
    child.stderr.on('data', d => feed(s, 'e', d));
    child.stdin.on('error', () => { });
    child.on('error', e => log('child error', sid, e && e.message));
    child.on('close', (code, signal) => {
      flushPartial(s);
      s.state = 'exited';
      s.exitCode = code == null ? (signal ? 1 : 0) : code;
      s.child = null; s.paused = false;
      s.seq++;
      push(s, { t: 'exit', sid, seq: s.seq, code: s.exitCode });
      log('exit', sid, s.pid, 'code', s.exitCode);
      savePids();
      if (s.released && s.bufBytes === 0) dropSession(s);
      checkIdle();
    });
  }
  function writeSession(c, f) {
    const s = sessions.get(String(f.sid));
    const wid = f.wid == null ? null : String(f.wid);
    if (!s) return writeTo(c, { t: 'err', sid: f.sid, wid, code: 'nosession', msg: 'no such session' });
    if (wid && s.wids.has(wid)) return writeTo(c, { t: 'wrote', sid: s.sid, wid, seq: s.seq, dup: true });
    if (s.state !== 'running' || !s.child || !s.child.stdin.writable) return writeTo(c, { t: 'err', sid: s.sid, wid, code: 'gone', msg: 'session stdin closed' });
    if (wid) {
      s.wids.add(wid); s.widList.push(wid);
      while (s.widList.length > P.WIDS_KEEP) s.wids.delete(s.widList.shift());
    }
    try { s.child.stdin.write(String(f.data == null ? '' : f.data)); } catch (e) { return writeTo(c, { t: 'err', sid: s.sid, wid, code: 'gone', msg: e.message }); }
    writeTo(c, { t: 'wrote', sid: s.sid, wid, seq: s.seq, dup: false });
  }
  function endSession(f) { const s = sessions.get(String(f.sid)); if (s && s.child) { try { s.child.stdin.end(); } catch { } } }
  function killSession(f) {
    const s = sessions.get(String(f.sid));
    if (!s || s.state !== 'running') return;
    s.killed = true;
    log('kill', s.sid, s.pid, f.tree === false ? '' : 'tree');
    if (f.tree === false) { try { s.child.kill(); } catch { } return; }
    killTreePid(s.pid);
  }
  function attachSession(c, f) {
    const s = sessions.get(String(f.sid));
    if (!s) return writeTo(c, { t: 'err', sid: f.sid, code: 'nosession', msg: 'no such session' });
    const from = Number(f.fromSeq) || 0;
    if (c === active) {
      for (const e of s.ring) if (e.seq >= from) sendActive(e.str);
      writeTo(c, { t: 'caughtUp', sid: s.sid, seq: s.seq });
      s.attached = true;
      applyFlow(s);
    } else {
      for (const e of s.ring) if (e.seq >= from) c.sock.write(e.str);
      writeTo(c, { t: 'caughtUp', sid: s.sid, seq: s.seq });
    }
  }
  function ackSession(f) {
    const s = sessions.get(String(f.sid));
    if (!s) return;
    const seq = Number(f.seq) || 0;
    if (seq > s.ackSeq) s.ackSeq = Math.min(seq, s.seq);
    let freed = 0;
    while (s.ring.length && s.ring[0].seq <= s.ackSeq) { freed += s.ring.shift().bytes; }
    s.bufBytes -= freed; totalBytes -= freed;
    if (s.ringPaused && s.bufBytes < P.RING_RESUME && totalBytes < P.TOTAL_MAX) { s.ringPaused = false; applyFlow(s); }
    if (s.state === 'exited' && s.released && s.bufBytes === 0) dropSession(s);
  }
  function releaseSession(c, f) {
    const s = sessions.get(String(f.sid));
    if (!s) return writeTo(c, { t: 'released', sid: f.sid });
    s.released = true;
    if (s.state === 'exited') dropSession(s);
    writeTo(c, { t: 'released', sid: s.sid });
  }
  function dropSession(s) {
    totalBytes -= s.bufBytes; s.bufBytes = 0; s.ring = [];
    sessions.delete(s.sid);
    checkIdle();
  }

  // ---------- hook / MCP gate ----------
  const pending = new Map();   // hid -> entry
  const holdQueue = [];        // hids, FIFO
  const gates = new Map();     // convId -> {stop, reason}
  let hidSeq = 0;

  function forwardHook(e) {
    e.conn = active; e.state = 'sent';
    if (e.timer) { clearTimeout(e.timer); e.timer = null; }
    writeTo(active, { t: 'hook', hid: e.hid, convId: e.convId, kind: e.kind, body: e.body });
  }
  function holdHook(e) {
    e.conn = null; e.state = 'held';
    if (!e.heldSince) e.heldSince = Date.now();
    holdQueue.push(e.hid);
    if (!e.timer) e.timer = setTimeout(() => fallback(e), Math.max(0, P.HOLD_MS - (Date.now() - e.heldSince)));
  }
  function flushHold() {
    if (!active) return;
    const ids = holdQueue.splice(0).sort((a, b) => a - b);
    for (const hid of ids) { const e = pending.get(hid); if (e && e.state === 'held') forwardHook(e); }
  }
  function finishHook(e, status, body) {
    if (e.done) return;
    e.done = true;
    pending.delete(e.hid);
    if (e.timer) { clearTimeout(e.timer); e.timer = null; }
    const i = holdQueue.indexOf(e.hid); if (i >= 0) holdQueue.splice(i, 1);
    const txt = typeof body === 'string' ? body : JSON.stringify(body == null ? {} : body);
    try { e.res.writeHead(status || 200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(txt) }); e.res.end(txt); } catch { }
  }
  function fallbackBody(e) {
    if (e.kind === 'pre') return { status: 200, body: FALLBACK_PRE };
    if (e.kind === 'stop') { const g = gates.get(e.convId); return { status: 200, body: g && g.stop === 'block' ? { decision: 'block', reason: g.reason || 'Claude Local is updating \u2014 continue the work; do not finish yet.' } : {} }; }
    if (e.kind === 'mcp') {
      let id; try { id = JSON.parse(e.body).id; } catch { }
      if (id === undefined) return { status: 202, body: '' };
      return { status: 200, body: { jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: FALLBACK_MCP_TEXT }], isError: true } } };
    }
    return { status: 200, body: {} };
  }
  function fallback(e) {
    e.timer = null;
    if (e.done || e.state !== 'held') return;
    log('hook fallback', e.kind, e.convId, 'after', Date.now() - e.heldSince, 'ms');
    const fb = fallbackBody(e);
    finishHook(e, fb.status, fb.body);
  }
  function hookReply(f) {
    const e = pending.get(Number(f.hid));
    if (!e) return;
    finishHook(e, Number(f.status) || 200, f.body);
  }

  const deny = (res, code, why) => { try { res.writeHead(code, { 'Content-Type': 'text/plain' }); res.end(why || 'forbidden'); } catch { } };
  const httpSrv = http.createServer((req, res) => {
    const ra = req.socket.remoteAddress;
    if (ra !== '127.0.0.1' && ra !== '::ffff:127.0.0.1') { log('gate: non-local', ra); return deny(res, 403); }
    if (req.headers.origin !== undefined || req.headers.referer !== undefined) { log('gate: origin/referer rejected'); return deny(res, 403); }
    if (req.headers.host !== `127.0.0.1:${hookPort}`) { log('gate: bad host', String(req.headers.host).slice(0, 80)); return deny(res, 403); }
    const m = /^\/h\/([^/?#]{1,200})\/([0-9a-f]{32})\/(pre|stop|prompt|post|mcp)$/.exec(req.url || '');
    if (!m) return deny(res, 404, 'not found');
    let convId; try { convId = decodeURIComponent(m[1]); } catch { return deny(res, 404, 'not found'); }
    if (!P.safeEq(m[2], P.sessTok(token, convId))) { log('gate: bad tok for', convId.slice(0, 80)); return deny(res, 403); }
    const kind = m[3];
    if (req.method !== 'POST') {
      // MCP Streamable-HTTP clients may open a GET SSE stream first; 405 tells them "POST only" (spec), 404 would look like a dead server.
      try { res.writeHead(kind === 'mcp' ? 405 : 404, kind === 'mcp' ? { 'Content-Type': 'text/plain', Allow: 'POST' } : { 'Content-Type': 'text/plain' }); res.end(kind === 'mcp' ? 'method not allowed' : 'not found'); } catch { }
      return;
    }
    const max = kind === 'mcp' ? P.MCP_BODY_MAX : P.HOOK_BODY_MAX;
    const cl = Number(req.headers['content-length']);
    if (cl > max) { deny(res, 413, 'too large'); try { req.destroy(); } catch { } return; }
    const chunks = []; let size = 0, over = false;
    req.on('data', d => { if (over) return; size += d.length; if (size > max) { over = true; deny(res, 413, 'too large'); try { req.destroy(); } catch { } return; } chunks.push(d); });
    req.on('end', () => {
      if (over) return;
      const e = { hid: ++hidSeq, convId, kind, body: Buffer.concat(chunks).toString('utf8'), res, conn: null, state: 'new', timer: null, heldSince: 0, done: false };
      pending.set(e.hid, e);
      res.on('close', () => { if (!e.done) { e.done = true; pending.delete(e.hid); if (e.timer) clearTimeout(e.timer); const i = holdQueue.indexOf(e.hid); if (i >= 0) holdQueue.splice(i, 1); } });
      if (active) forwardHook(e); else holdHook(e);
    });
  });
  httpSrv.keepAliveTimeout = 5000;

  // ---------- connections ----------
  function onConnect(sock) {
    const c = { id: ++connSeq, sock, authed: false, detaching: false, closed: false };
    conns.add(c);
    sock.setEncoding('utf8');
    const helloTimer = setTimeout(() => { if (!c.authed) { log('conn', c.id, 'no hello in 2s'); sock.destroy(); } }, 2000);
    const reader = P.frameReader(f => {
      if (c.closed) return;
      if (!c.authed) { clearTimeout(helloTimer); return authHello(c, f); }
      try { handle(c, f); } catch (e) { log('frame error', f && f.t, e && e.stack || e); }
    }, why => { log('conn', c.id, 'bad frame:', why); sock.destroy(); });
    sock.on('data', reader);
    sock.on('error', () => { });
    sock.on('close', () => { clearTimeout(helloTimer); onClose(c); });
  }
  function authHello(c, f) {
    const fail = code => { writeTo(c, { t: 'helloErr', code }); c.sock.end(); setTimeout(() => c.sock.destroy(), 200); };
    if (!f || f.t !== 'hello' || !P.safeEq(f.token, token)) { log('conn', c.id, 'auth failed'); onEvent({ type: 'foreign', reason: 'auth' }); return fail('auth'); }
    if (!(Number(f.proto) === P.PROTO || Number(f.proto) === P.PROTO - 1)) { log('conn', c.id, 'proto mismatch', f.proto); return fail('proto'); }
    if (active && !active.closed && !active.detaching) { log('conn', c.id, 'busy (server', active.pid, 'still connected)'); onEvent({ type: 'foreign', reason: 'busy', pid: f.pid }); return fail('busy'); }
    c.authed = true; c.pid = Number(f.pid) || 0; c.gen = f.gen;
    active = c; sockBlocked = false; lastServerAt = Date.now();
    for (const s of sessions.values()) s.attached = false;
    applyFlowAll();
    log('server connected: conn', c.id, 'pid', c.pid, 'gen', c.gen);
    writeTo(c, { t: 'helloOk', proto: P.PROTO, hostPid: process.pid, hookPort, codeHash: HASH, sessions: listSessions() });
    flushHold();
  }
  function handle(c, f) {
    switch (f.t) {
      case 'spawn': return spawnSession(c, f);
      case 'write': return writeSession(c, f);
      case 'end': return endSession(f);
      case 'kill': return killSession(f);
      case 'attach': return attachSession(c, f);
      case 'ack': return ackSession(f);
      case 'release': return releaseSession(c, f);
      case 'gate': if (f.convId != null) gates.set(String(f.convId), { stop: f.stop === 'block' ? 'block' : 'allow', reason: f.reason ? String(f.reason) : '' }); return;
      case 'hookReply': return hookReply(f);
      case 'detaching': return detach(c);
      case 'list': return writeTo(c, { t: 'sessions', items: listSessions() });
      default: log('unknown frame', String(f.t).slice(0, 40));
    }
  }
  function detach(c) {
    c.detaching = true;
    if (active !== c) return;
    active = null; sockBlocked = false; lastServerAt = Date.now();
    for (const s of sessions.values()) s.attached = false;
    applyFlowAll();
    log('server detaching: conn', c.id);
  }
  function onClose(c) {
    if (c.closed) return;
    c.closed = true; conns.delete(c);
    if (active === c) detach(c);
    // hooks that were sent to this server and not answered: hold them for the next server (at least once)
    const back = [...pending.values()].filter(e => e.conn === c && !e.done).sort((a, b) => a.hid - b.hid);
    for (const e of back) holdHook(e);
    if (back.length) holdQueue.sort((a, b) => a - b);
    if (active) flushHold();
    if (c.authed) log('server conn', c.id, 'closed; re-held hooks:', back.length);
    checkIdle();
  }

  // ---------- drain / idle / retire ----------
  function running() { return [...sessions.values()].filter(s => s.state === 'running'); }
  function drain({ graceMs = 3000 } = {}) {
    const list = running();
    log('drain', list.length, 'sessions, grace', graceMs);
    for (const s of list) {
      try {
        if (!(s.key && s.key.kind === 'shell') && s.child && s.child.stdin.writable)
          s.child.stdin.write(JSON.stringify({ type: 'control_request', request_id: 'drain:' + s.sid, request: { subtype: 'interrupt' } }) + '\n');
      } catch { }
      try { s.child && s.child.stdin.end(); } catch { }
    }
    return new Promise(resolve => {
      const t0 = Date.now();
      const tick = () => {
        const left = running();
        if (!left.length) return resolve(0);
        if (Date.now() - t0 >= graceMs) { Promise.all(left.map(s => killTreePid(s.pid))).then(() => resolve(left.length)); return; }
        setTimeout(tick, 100);
      };
      tick();
    });
  }
  function stats() {
    let n = 0;
    for (const s of sessions.values()) if (s.state === 'running' || s.bufBytes > 0) n++;
    return { sessions: n, bytes: totalBytes, running: running().length, connected: !!active, pending: pending.size };
  }
  function close() {
    try { pipeSrv.close(); } catch { }
    try { httpSrv.close(); } catch { }
    for (const c of conns) { try { c.sock.destroy(); } catch { } }
    clearInterval(idleTimer);
  }
  function retire() {
    if (running().length) return false;
    log('retire'); exiting = true; close();
    return true;
  }
  function checkIdle() {
    if (!devMode || exiting) return;
    if (active) { lastServerAt = Date.now(); return; }
    if (Date.now() - startedAt < 30000 && connSeq === 0) return; // first server is still starting
    const live = running().length;
    if (!live && !pending.size) { exiting = true; log('dev: no server and no sessions - exit'); close(); setTimeout(() => exitFn(0), 50); return; }
    if (Date.now() - lastServerAt > IDLE_MS) {
      exiting = true; log('dev: no server for', IDLE_MS, 'ms - drain and exit');
      drain({ graceMs: 3000 }).then(() => { close(); exitFn(0); });
    }
  }
  const idleTimer = setInterval(checkIdle, devMode ? 5000 : 60000);
  idleTimer.unref();

  // ---------- start ----------
  const pipeSrv = net.createServer(onConnect);
  return new Promise((resolve, reject) => {
    pipeSrv.once('error', reject);
    pipeSrv.listen(pipe, () => {
      pipeSrv.removeListener('error', reject);
      pipeSrv.on('error', e => log('pipe server error', e.message));
      httpSrv.once('error', reject);
      httpSrv.listen(0, '127.0.0.1', () => {
        hookPort = httpSrv.address().port;
        log('started: pipe', pipe, 'hookPort', hookPort, 'codeHash', HASH, devMode ? '(dev)' : '');
        orphanSweep().catch(() => { });
        resolve({ hookPort, codeHash: HASH, pid: process.pid, drain, stats, retire, close, listSessions, orphanSweep });
      });
    });
  });
}

module.exports = { startHost, codeHash, allowedCmd, PROTO: P.PROTO };

// dev mode / tests: `node sessionhost.js` with CLAUDE_HOST_PIPE, CLAUDE_HOST_TOKEN, CLAUDE_HOST_STATE [, CLAUDE_HOST_DEV=1]
if (require.main === module) {
  const pipe = process.env.CLAUDE_HOST_PIPE, token = process.env.CLAUDE_HOST_TOKEN;
  delete process.env.CLAUDE_HOST_TOKEN;
  startHost({ pipe, token, stateDir: process.env.CLAUDE_HOST_STATE || null, devMode: process.env.CLAUDE_HOST_DEV === '1' })
    .then(h => {
      if (process.env.CLAUDE_HOST_INFO) { try { fs.writeFileSync(process.env.CLAUDE_HOST_INFO, JSON.stringify({ pid: process.pid, pipe, hookPort: h.hookPort, proto: P.PROTO, codeHash: h.codeHash })); } catch { } }
      if (process.send) process.send({ type: 'ready', pid: process.pid, hookPort: h.hookPort, proto: P.PROTO, codeHash: h.codeHash });
      process.stdout.write(JSON.stringify({ type: 'ready', pid: process.pid, hookPort: h.hookPort, proto: P.PROTO, codeHash: h.codeHash }) + '\n');
    })
    .catch(e => { console.error('[sessionhost] failed:', e && e.message); process.exit(1); });
}
