'use strict';
// ============================================================
//  Session-host wire protocol (HOT-UPDATE plan, stage 1.1).
//  Shared by sessionhost.js (host side) and hostclient.js (server side).
//  Transport: a Windows named pipe carrying NDJSON frames (one JSON object per line).
// ============================================================

const PROTO = 1;

const MB = 1024 * 1024;
const envInt = (name, def) => { const n = Number(process.env[name]); return Number.isFinite(n) && n > 0 ? n : def; };

const LIMITS = {
  MAX_FRAME: 32 * MB,        // one NDJSON frame (either direction)
  RING_MAX: 64 * MB,         // un-acked output per session -> pause the child's stdout
  RING_RESUME: 48 * MB,      // ...resume when acks bring it back under this
  TOTAL_MAX: 512 * MB,       // all sessions together
  WIDS_KEEP: 2000,           // remembered write-ids per session (dedup)
  HOLD_MS: envInt('CLAUDE_HOST_HOLD_MS', 150000), // a hook waits this long for a server before the fallback answer
};

// server -> host
const C2H = ['hello', 'spawn', 'write', 'end', 'kill', 'attach', 'ack', 'release', 'gate', 'hookReply', 'detaching', 'list'];
// host -> server
const H2C = ['helloOk', 'helloErr', 'spawned', 'err', 'wrote', 'out', 'exit', 'caughtUp', 'hook', 'sessions', 'released'];

const HOOK_KINDS = ['pre', 'stop', 'prompt', 'post', 'mcp'];
const HOOK_BODY_MAX = 256 * 1024;
const MCP_BODY_MAX = 8 * MB;

const crypto = require('crypto');
// per-conversation gate token: HMAC_SHA256(token, convId) hex, first 32 chars
function sessTok(token, convId) {
  return crypto.createHmac('sha256', String(token)).update(String(convId)).digest('hex').slice(0, 32);
}
function safeEq(a, b) {
  const A = Buffer.from(String(a == null ? '' : a)), B = Buffer.from(String(b == null ? '' : b));
  if (A.length !== B.length) { crypto.timingSafeEqual(A, A); return false; }
  return crypto.timingSafeEqual(A, B);
}

// NDJSON line splitter with a frame-size cap. onFrame(obj) / onBad(reason)
function frameReader(onFrame, onBad) {
  let buf = '';
  return chunk => {
    buf += chunk;
    if (buf.length > LIMITS.MAX_FRAME && buf.indexOf('\n') < 0) { buf = ''; onBad && onBad('frame-too-big'); return; }
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i); buf = buf.slice(i + 1);
      if (!line.trim()) continue;
      let o; try { o = JSON.parse(line); } catch { onBad && onBad('bad-json'); continue; }
      if (o && typeof o === 'object') onFrame(o);
    }
  };
}

module.exports = { PROTO, LIMITS, ...LIMITS, C2H, H2C, HOOK_KINDS, HOOK_BODY_MAX, MCP_BODY_MAX, sessTok, safeEq, frameReader };
