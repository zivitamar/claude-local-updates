'use strict';
// ============================================================
//  managers.js — 🧭 מנהל עבודה: צ'אט Claude שמנהל פרויקט עד הסוף, עם 1–3 צ'אטי עובדים, בלי הבעלים.
//  מבוסס על ההחלטות במחקר (docs/research/work-manager/crosscheck.md, D1–D27). מה שנאכף כאן — בקוד, לא בבקשה:
//   • רק מנהל יוצר צ'אטים (chat_new); מספר עובדים מוגבל (ברירת מחדל 3, תקרה 5) — D23
//   • המנהל לא עושה עבודת עובד: בלי Write/Edit — D5
//   • לולאה בלי סוף — D1, D19: המנהל לא מסיים תור כל עוד הפרויקט לא הוכח (חוץ מכשעובדים / מחקר רצים — אז הוא מוער כשהם מסיימים)
//   • "סיימתי" רק עם הוכחה: כל פריט בתוכנית נבדק בפקודה שהשרת מריץ בעצמו (קוד יציאה + טקסט צפוי) — D2, D13, D27
//   • קיר → מחקר: תקלה של עובד / הוכחה שנכשלה פעמיים → חובה חיפוש ברשת; אותו קיר שוב → חובה מחקר עמוק — D9
//   • מצב על דיסק (בתוך קובץ השיחה) — שורד אתחול; פעימה מעירה מנהל שנרדם; דדליין של הבעלים — D7, D18
// ============================================================
const { spawn } = require('child_process');

const MAX_WORKERS_CAP = 5;
const DEFAULTS = { maxWorkers: 3, heartbeatMin: 10, proofTimeoutSec: 300 };
const WEB_TOOLS = /^(WebSearch|WebFetch)$/;
const DEEP_TOOL = 'mcp__claudechat__research_start';
const WRITE_TOOLS = /^(Write|Edit|MultiEdit|NotebookEdit)$/;
const WALL_RE = /(לא הצלחתי|לא מצליח|תקוע|חסום|\bfailed to\b|\bI (?:could not|couldn't|can't|cannot|was unable)\b|\bunable to\b|\bstuck\b|\bblocked\b|\b[1-9]\d* (?:tests? )?failed\b|Traceback \(most recent|[1-9]\d* נכשל)/i;
const norm = s => String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
const clampInt = (v, lo, hi, d) => { const n = Math.round(Number(v)); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d; };
const wallKey = s => norm(s).toLowerCase().replace(/[0-9a-f]{6,}|\d+/g, '#').slice(0, 80);

function newState(o = {}) {
  return {
    v: 1, goal: norm(o.goal).slice(0, 4000), status: 'running', createdAt: Date.now(),
    deadline: Number(o.deadline) > 0 ? Number(o.deadline) : null,
    maxWorkers: clampInt(o.maxWorkers, 1, MAX_WORKERS_CAP, DEFAULTS.maxWorkers),
    heartbeatMin: clampInt(o.heartbeatMin, 2, 240, DEFAULTS.heartbeatMin),
    workers: [], plan: [], walls: [], log: [], events: [], improvements: [], roles: {}, scale: '', researchTopics: [],
    reportsSinceImprove: 0, kickoffResearchAt: 0,
    blocks: 0, lastToolAt: 0, lastWebAt: 0, lastDeepAt: 0, lastWakeAt: 0, finishedAt: null, finishNote: ''
  };
}

// ---------- pure decisions (tested by combination in tests/managers-logic.test.js) ----------
/** what the open walls still require: null | 'web' | 'deep' */
function wallNeed(st) {
  let need = null;
  for (const w of st.walls || []) {
    if (w.resolved) continue;
    const want = w.count >= 2 ? 'deep' : 'web';
    const done = want === 'deep' ? (st.lastDeepAt || 0) > w.at : Math.max(st.lastWebAt || 0, st.lastDeepAt || 0) > w.at;
    if (!done) { if (want === 'deep') return 'deep'; need = 'web'; }
  }
  return need;
}
/** may the manager end its turn now? ctx: { now, workersRunning, researchRunning, toolsSinceLastBlock } */
function stopDecision(st, ctx = {}) {
  const now = ctx.now || Date.now();
  if (!st) return { allow: true };
  if (st.status === 'done' || st.status === 'paused' || st.status === 'stopped') return { allow: true };
  if (st.deadline && now >= st.deadline) return { allow: true, deadline: true };
  const need = wallNeed(st);
  if (need === 'deep') return { allow: false, why: 'deep', text: 'יש קיר שחזר על עצמו — חובה מחקר עמוק (mcp__claudechat__research_start, עם min_sources ו-max_sources) לפני שממשיכים או עוצרים.' };
  if (need === 'web') return { allow: false, why: 'web', text: 'יש קיר פתוח — חובה לחפש ברשת (WebSearch / WebFetch, או research_start) לפני שממשיכים או עוצרים. אל תסמוך על הידע הבסיסי.' };
  if (ctx.workersRunning || ctx.researchRunning) return { allow: true, waiting: true };
  // nothing running, not proven: keep working. A turn that made no progress at all several times → let it rest; the heartbeat wakes it
  if ((st.blocks || 0) >= 4 && !ctx.toolsSinceLastBlock) return { allow: true, rest: true };
  { const i = improveNeed(st, now, ctx.minuteMs || 60000); if (i) return { allow: false, why: 'improve-' + i, text: IMPROVE_TEXT[i] }; }
  const open = (st.plan || []).filter(p => p.status !== 'proven');
  if (st.plan && st.plan.length && !open.length) return { allow: false, why: 'finish', text: 'כל הפריטים בתוכנית הוכחו. אם יש עוד מה לבנות — הוסף פריטים (manager_plan). אחרת סיים: manager_finish עם סיכום.' };
  const text = !st.plan || !st.plan.length
    ? 'עוד אין תוכנית. קבע תוכנית עם manager_plan (פריטים מדידים), חלק לעובדים (chat_new / chat_send) והמשך.'
    : `הפרויקט עוד לא הוכח: ${open.length} פריטים פתוחים (${open.slice(0, 4).map(p => p.id + ' ' + p.text.slice(0, 40)).join(' · ')}). המשך: הנחה עובד, או הוכח פריט עם manager_prove, או סיים עם manager_finish כשהכל מוכח.`;
  return { allow: false, why: 'unfinished', text };
}
/** owner's criteria (docs/MANAGER-CRITERIA.md): plan at SCALE with research topics, research BEFORE workers, improve continuously */
const FREEZE_MIN = 15, SILENT_MIN = 15, IMPROVE_EVERY = 2, RESEARCH_EVERY_MIN = 45;
function kickoffNeed(st) {
  if (!st.plan || !st.plan.length) return 'plan';
  if (!norm(st.scale)) return 'scale';
  if (!(st.researchTopics || []).length) return 'topics';
  if (!((st.lastWebAt || 0) > (st.planAt || 0) || (st.lastDeepAt || 0) > (st.planAt || 0) || st.kickoffResearchAt)) return 'research';
  return null;
}
function improveNeed(st, now = Date.now(), MIN = 60000) {
  if ((st.reportsSinceImprove || 0) >= IMPROVE_EVERY) return 'improve';
  if (!st.createdAt) return null; const last = Math.max(st.lastWebAt || 0, st.lastDeepAt || 0, st.createdAt);
  if (st.status === 'running' && st.plan && st.plan.length && now - last > RESEARCH_EVERY_MIN * MIN) return 'research';
  return null;
}
const KICKOFF_TEXT = { plan: 'קודם תוכנית: manager_plan עם scale (היקף מדויק ומקצועי לפי מה שהבעלים ביקש), research (נושאי מחקר: עיצוב / ייעול / כלים / backend לפי הפרויקט), ופריטים מדידים עם role ו-proof.', scale: 'בתוכנית חסר scale — היקף העבודה המדויק (manager_plan עם scale).', topics: 'בתוכנית חסרים נושאי מחקר (research) — מחקר עיצוב / ייעול / כלים לפי הפרויקט.', research: 'לפני שפותחים עובדים: לצאת למחקר על נושאי התוכנית (WebSearch / WebFetch, או research_start) ולהחליט ממנו.' };
const IMPROVE_TEXT = { improve: `עברו ${IMPROVE_EVERY} דיווחי עובדים בלי שיפור רשום. עצור רגע, בדוק מה אפשר לייעל (שיטה, חלוקה, כלים, בדיקות) ורשום עם manager_improve (observation, change, metric) — ואז יישם.`, research: `עברו ${RESEARCH_EVERY_MIN} דק' בלי מחקר. צא למחקר ייעול קצר (WebSearch) על נקודת הכאב הכי גדולה עכשיו, ורשום שיפור עם manager_improve.` };
/** may the manager open another worker? */
function canAddWorker(st, activeWorkers) {
  if (activeWorkers >= (st.maxWorkers || DEFAULTS.maxWorkers)) return { ok: false, text: `כבר יש ${activeWorkers} עובדים (המקסימום למנהל הזה: ${st.maxWorkers}). השתמש בעובד קיים (chat_send) או שחרר אחד (manager_release). פחות צ'אטים = פחות טוקנים.` };
  return { ok: true };
}
/** what the owner's criteria still require before "done": improvement, research DURING the work, a flow/watch for a worker, all of them turned off */
const RED_RE = /(שבור|לשבור|red.?team|adversar|break|edge.?case|מקרי קצה|קצה|fuzz|אקראי|independent|בלתי תלוי|ביקורת|review)/i;
function finishDuties(st) {
  const ev = st.events || [], hire = ev.find(e => e.kind === 'hire');
  const miss = [];
  if (!(st.improvements || []).length) miss.push('לא נרשם אף שיפור לשיטת העבודה (manager_improve) — מנהל לא מסתפק במה שיש');
  if (hire && !ev.some(e => e.at > hire.at && /^(WebSearch|WebFetch|research_start)$/.test(e.what))) miss.push('לא היה מחקר תוך כדי העבודה (אחרי שהעובדים התחילו) — צא למחקר ייעול על נקודת הכאב הכי גדולה');
  const fw = ev.filter(e => /^(flow_create|manager_watch|watch_create)$/.test(e.what));
  if (hire && !fw.length) miss.push('לא נבנה תזרים או מעקב לאף עובד — בנה לעובד תזרים (flow_create, scope של הצ\'אט שלו) למחזור בדיקה→תיקון→בדיקה, או מעקב (manager_watch)');
  if (fw.length && !ev.some(e => e.at > fw[fw.length - 1].at && /^(flow_stop|watch_stop|watch_pause|flow_update)$/.test(e.what))) miss.push('תזרים/מעקב של עובד עדיין דולק — כבה אותו כשהמשימה שלו הוכחה (flow_stop / watch_stop)');
  if ((st.reportsSinceImprove || 0) >= IMPROVE_EVERY) miss.push(`עברו ${st.reportsSinceImprove} דיווחי עובדים מאז השיפור האחרון — מחקר ייעול קצר ושיפור (manager_improve) לפני סיום`);
  // red team (exam hebcal 2026-11-27: "done" in 5 min, wrong on hidden dates): after everything is proven, a worker must try to BREAK it
  const allProvenAt = Math.max(0, ...(st.plan || []).map(p => p.provenAt || 0));
  if (hire && allProvenAt) {
    const rt = ev.filter(e => e.at > allProvenAt && e.what === 'chat_send' && RED_RE.test(e.detail || ''));
    if (!rt.length) miss.push('אחרי שהכל הוכח: שלח עובד לנסות לשבור את התוצאה (red team) — מקרי קצה, קלט אקראי מול מקור בלתי תלוי, הלוך-חזור, עומס — ופעל לפי מה שמצא');
    else if (!ev.some(e => e.kind === 'report' && e.at > rt[0].at)) miss.push('ה-red team עוד לא דיווח — חכה לדיווח שלו, תקן מה שנמצא, והוכח שוב');
  }
  // strict (exams gpt #2 / cnn): a FLOW for a worker (not only watches), and the plan re-made from what was learned while working
  if (hire && fw.length && !ev.some(e => e.what === 'flow_create')) miss.push('נבנו רק מעקבים — בנה לפחות לעובד אחד תזרים (flow_create עם worker) למחזור החוזר שלו (אימון→מדידה→השוואה / בדיקה→תיקון→בדיקה)');
  if (hire && !ev.some(e => e.kind === 'plan' && e.at > hire.at)) miss.push('התוכנית לא עודכנה מאז שהעבודה התחילה — עדכן אותה (manager_plan) לפי מה שלמדת: פריטים שנוספו, שהשתנו או שירדו');
  const notApplied = (st.improvements || []).filter(i => !ev.some(e => e.at > i.at && /^(chat_send|manager_plan|flow_create|flow_update|flow_start|flow_stop|manager_watch|watch_create|watch_pause|watch_resume|watch_stop)$/.test(e.what)));
  if (notApplied.length) miss.push(`${notApplied.length} שיפורים נרשמו ולא יושמו — יישם כל שיפור בפועל (הוראה לעובד / תוכנית מעודכנת / תזרים) ומדוד`);
  return miss;
}
/** an improvement must come from research done since the last one (owner: "מחקרים זה כלי מחייב תמידית כדי לייעל") */
function improveGrounded(st) {
  const ev = st.events || [], last = (st.improvements || []).slice(-1)[0], hire = ev.find(e => e.kind === 'hire');
  const since = Math.max(last ? last.at : 0, hire ? hire.at : 0, st.createdAt || 0);
  return ev.some(e => e.at >= since && /^(WebSearch|WebFetch|research_start)$/.test(e.what));
}
function finishCheck(st) {
  if (!st.plan || !st.plan.length) return { ok: false, text: 'אין תוכנית — אי אפשר לסיים בלי פריטים מוכחים.' };
  const open = st.plan.filter(p => p.status !== 'proven');
  if (open.length) return { ok: false, text: 'אי אפשר לסיים — פריטים שלא הוכחו: ' + open.map(p => p.id + ' "' + p.text.slice(0, 50) + '"').join(', ') };
  const need = wallNeed(st); if (need) return { ok: false, text: 'יש קיר פתוח שלא נחקר.' };
  const d = finishDuties(st); if (d.length) return { ok: false, text: 'עוד לא — לפי הקריטריונים של הבעלים חסר:\n• ' + d.join('\n• ') };
  return { ok: true };
}

// ---------- the manager's brain (appended to its system prompt; static part first for caching — D21) ----------
const BRAIN = `🧭 YOU ARE A WORK MANAGER (מנהל עבודה) — a team lead at the most professional high-tech company in the world. The owner gave you a project and left. You take it PERSONALLY: you own it, you care about it, and you do whatever it takes to finish it as fast as possible and at the highest quality, with no compromises — until it is DONE AND PROVEN. You replace the owner: never ask the owner anything; decide, act, and record your decisions.

HOW YOU WORK (the app enforces these — its hooks block you otherwise):
1. THINK BIG, PLAN FIRST: call mcp__claudechat__manager_plan with a precise professional SCALE (scope exactly as the owner wants it), research TOPICS for this kind of project (design research, efficiency research, research on the tools / software / backend it uses), and small MEASURABLE items — each with a role (who does it) and a proof (how it is measured).
2. RESEARCH BEFORE BUILDING: before opening workers, research the plan's topics (WebSearch/WebFetch, or mcp__claudechat__research_start for depth) and decide from what you found — not from memory. Opening workers is blocked until then.
3. A TEAM WITH CLEAR ROLES: you manage up to N Claude worker chats (the owner sets N; your limit is in the status). Smart division of roles: every new worker (mcp__claudechat__chat_new) starts its brief with "תפקיד: …" (backend / design / tests / research / …), then goal, files and how it will be proven. Re-use a worker (mcp__claudechat__chat_send) before opening another — every chat costs tokens. Parallel workers only for truly independent parts.
4. YOU DO NOT DO THE WORKERS' JOB: you cannot write/edit files. You read, run checks, route work, verify, decide.
5. LIVE MANAGEMENT, HAND ON THE PULSE: keep YOUR OWN turns short — delegate long runs (training, benchmarks, big test suites) to a worker, so you react to every report within seconds; watch every worker report; VERIFY yourself (read files, run tests) — a worker's "done" is a claim, not a proof. Notice what is slow or wasteful and change the method while working.
6. NEVER SETTLE — IMPROVE CONTINUOUSLY: every few worker reports you must record an improvement with mcp__claudechat__manager_improve (observation → change → metric) and apply it; every ~45 min you must run an efficiency research. Always look for the most efficient way: better split, better tools, faster tests, parallelism, automation. Change course mid-work whenever the data says so (re-plan).
7. WALLS → RESEARCH AT ONCE: when work hits a wall, do NOT guess. Research the pain points immediately (WebSearch; if the wall repeats, a deep mcp__claudechat__research_start with min_sources/max_sources), then PROVE which change breaks the wall and makes the project move faster.
8. FLOWS & WATCHES FOR WORKERS: build a worker a fixed flow (mcp__claudechat__flow_create with worker = that worker's code — the flow drives THAT worker) — prefer a FLOW for any repeating multi-step cycle (train → evaluate → compare, test → fix → retest) for repeatable cycles (test → fix → retest), or a watch (mcp__claudechat__manager_watch) for periodic checks. Turn them on/off yourself (flow_start / flow_stop, watch pause/resume) so results always keep advancing.
9. THOROUGH, PROOF OR IT DIDN'T HAPPEN (a proof is a FAST check, ≤90 s — have a worker produce the artifacts first; your own Bash commands must stay under 90 s): an item is done only when mcp__claudechat__manager_prove ran its command on the server and the output matched. Prove EVERY tool/feature (run it, test it, screenshot UIs). Only then mcp__claudechat__manager_finish — it refuses while anything is unproven, AND until you have: recorded at least one improvement (each one grounded in research done since the previous one, and each one APPLIED: an instruction to a worker / an updated plan / a flow), researched DURING the work (after workers started), given a worker a flow or watch, and turned every such flow/watch off when its job was proven, AND — after everything is proven — sent a worker to try to BREAK the result (red team: edge cases, random inputs vs an independent source, round-trips, load) and acted on its report.
10. NEVER STOP, TAKE RESPONSIBILITY FOR EVERYTHING: you end a turn only while workers or a research are running (you are woken when they finish). There is no "failed": a failure is the next thing to fix or research.
11. REPORT TO THE OWNER in short Hebrew lines: what is proven, what is running, what you improved, what's next. Facts only.`;

function brainFor(conv, st, live) {
  if (!st) return '';
  const w = live.workers.map(x => `${x.code} "${x.title}" — ${x.running ? 'עובד עכשיו' : 'פנוי'}`).join(' · ') || 'אין עדיין';
  const plan = (st.plan || []).map(p => `${p.status === 'proven' ? '✅' : p.status === 'failing' ? '❌' : '⬜'} ${p.id} ${p.text}${p.role ? ' [' + p.role + ']' : ''}`).join('\n') || '(אין תוכנית עדיין)';
  const extra = `\nSCALE: ${st.scale || '(not set)'}\nRESEARCH TOPICS: ${(st.researchTopics || []).join(' · ') || '(not set)'}\nIMPROVEMENTS SO FAR: ${(st.improvements || []).length}${(st.reportsSinceImprove || 0) >= IMPROVE_EVERY ? ' — ⚠ an improvement is due now (manager_improve)' : ''}${kickoffNeed(st) ? '\nKICKOFF MISSING: ' + kickoffNeed(st) : ''}`;
  const walls = (st.walls || []).filter(x => !x.resolved).map(x => `• ${x.what} (×${x.count})`).join('\n');
  return BRAIN + `\n\nCURRENT STATE (live):\nGOAL: ${st.goal}\nSTATUS: ${st.status}${st.deadline ? ' · DEADLINE ' + new Date(st.deadline).toLocaleString('he-IL') : ' · no deadline (until proven done)'}\nWORKERS (max ${st.maxWorkers}): ${w}\nPLAN:\n${plan}${extra}${walls ? '\nOPEN WALLS (research required):\n' + walls : ''}`;
}

// ---------- the module ----------
function createManagers(deps) {
  const { getConv, saveConv, listConvs, sendToChat, isRunning, researchRunningFor, createWatch, projectDirOf, log = () => { }, emit = () => { } } = deps;
  const MIN = Number(deps.minuteMs || process.env.CLAUDE_MANAGER_MINUTE_MS) || 60000; // tests: a fast minute
  const stOf = conv => (conv && conv.role === 'manager' && conv.manager) ? conv.manager : null;
  const save = conv => { try { saveConv(conv); } catch (e) { log('[manager] save ' + e.message); } };
  const note = (conv, text) => { const st = stOf(conv); if (!st) return; st.log.push({ at: Date.now(), text: String(text).slice(0, 300) }); if (st.log.length > 200) st.log.splice(0, st.log.length - 200); };
  const ev = (st, kind, what, detail) => { st.events = st.events || []; st.events.push({ at: Date.now(), kind, what: String(what || '').slice(0, 80), detail: String(detail || '').slice(0, 160) }); if (st.events.length > 2000) st.events.splice(0, st.events.length - 2000); };
  const workersOf = conv => (listConvs() || []).filter(c => c.managedBy === conv.id && !c.released);
  const live = conv => ({ workers: workersOf(conv).map(c => ({ id: c.id, code: c.code, title: c.title, running: !!isRunning(c.id) })) });

  function create(conv, o) {
    conv.role = 'manager'; conv.manager = newState(o);
    note(conv, 'מנהל נוצר: ' + conv.manager.goal.slice(0, 120)); save(conv); emit(conv);
    return conv.manager;
  }
  function systemFor(conv) { const st = stOf(conv); return st ? brainFor(conv, st, live(conv)) : ''; }

  // PreToolUse — every tool of every chat passes here
  function gate(convId, name, input) {
    let conv = null; try { conv = getConv(convId); } catch { } if (!conv) return null;
    const st = stOf(conv);
    if (st) {
      st.lastToolAt = Date.now();
      ev(st, 'tool', name.replace(/^mcp__claudechat__/, ''), input && (name === 'mcp__claudechat__chat_send' ? String(input.code || '') + ': ' + String(input.text || '').slice(0, 140) : (input.query || input.question || input.code || input.item || input.name || input.url || '')));
      if (WEB_TOOLS.test(name)) st.lastWebAt = Date.now();
      if (name === DEEP_TOOL) st.lastDeepAt = Date.now();
      save(conv); // the research / activity marks must survive (the next hook reads the chat from disk)
      { const need = wallNeed(st); if (need && !/^(WebSearch|WebFetch|ToolSearch|Read|Grep|Glob|mcp__claudechat__research_start|mcp__claudechat__research_status|mcp__claudechat__research_read|mcp__claudechat__manager_status)$/.test(name)) return { allow: false, reason: '🧭 קיר פתוח — קודם מחקר, מיד: ' + (need === 'deep' ? 'הקיר חזר → research_start (מחקר עמוק, עם min_sources ו-max_sources).' : 'WebSearch / WebFetch על נקודת הכאב.') + ' אחר כך החלט מה שובר את הקיר והוכח את זה.' }; }
      if (/^(Bash|PowerShell)$/.test(name) && input && (Number(input.timeout) > 90000 || input.run_in_background)) return { allow: false, reason: '🧭 יד על הדופק: אתה מנהל — פקודה ארוכה (מעל 90 שניות או ברקע) חוסמת אותך מלהגיב לעובדים. תן אותה לעובד (chat_send) ובדוק את התוצאה שלו; אתה מריץ רק בדיקות קצרות.' };
      if (WRITE_TOOLS.test(name)) return { allow: false, reason: '🧭 אתה מנהל עבודה — אתה לא כותב קבצים בעצמך. הנחה עובד (chat_send / chat_new) לעשות את זה, ואז אמת.' };
      if (name === 'mcp__claudechat__chat_new') {
        const k = kickoffNeed(st); if (k) return { allow: false, reason: '🧭 ' + KICKOFF_TEXT[k] };
        const c = canAddWorker(st, workersOf(conv).length); if (!c.ok) return { allow: false, reason: '🧭 ' + c.text };
        if (!/(תפקיד|ROLE)\s*[:：]/i.test(String((input && (input.text || input.title)) || ''))) return { allow: false, reason: '🧭 לכל עובד תפקיד ברור: התחל את ההוראה ב"תפקיד: …" (למשל תפקיד: backend / עיצוב / בדיקות / מחקר), עם מטרה, קבצים ואיך יוכח.' };
        st.pendingRole = (String(input.text || '').match(/(?:תפקיד|ROLE)\s*[:：]\s*([^\n.;]{1,60})/i) || [])[1] || ''; save(conv);
      }
      if (name === 'mcp__claudechat__chat_send' || name === 'mcp__claudechat__flow_create' || name === 'mcp__claudechat__manager_watch' || name === 'mcp__claudechat__manager_prove') { const i = improveNeed(st, Date.now(), MIN); if (i) return { allow: false, reason: '🧭 ' + IMPROVE_TEXT[i] }; }
      return null;
    }
    // a normal chat: only a manager opens chats (owner's law, docs/WORK-MANAGER-PLAN.md §0.1)
    if (name === 'mcp__claudechat__chat_new') return { allow: false, reason: 'רק מנהל עבודה רשאי לפתוח צ\'אטים חדשים. אם צריך עזרה של צ\'אט אחר — chat_send לצ\'אט קיים.' };
    // a worker belongs to its manager: other chats don't send it instructions (its own manager, and the owner from the UI, may)
    if (name === 'mcp__claudechat__chat_send' && input && input.code) {
      const t = (listConvs() || []).find(c => String(c.code || '').toUpperCase() === String(input.code).toUpperCase());
      if (t && t.managedBy && t.managedBy !== conv.id && conv.managedBy !== t.managedBy && t.id !== conv.managedBy) return { allow: false, reason: `הצ'אט ${t.code} הוא עובד של מנהל עבודה — רק המנהל שלו שולח לו הוראות.` };
    }
    return null;
  }

  // Stop hook: the manager doesn't end its turn until the work is proven (or it waits on workers / research)
  const toolsAtBlock = new Map();
  function stopGate(convId) {
    let conv = null; try { conv = getConv(convId); } catch { } const st = stOf(conv); if (!st) return null;
    const lv = live(conv);
    const d = stopDecision(st, { workersRunning: lv.workers.some(w => w.running), researchRunning: !!researchRunningFor(convId), toolsSinceLastBlock: (st.lastToolAt || 0) > (toolsAtBlock.get(convId) || 0) });
    if (d.deadline && st.status === 'running') { st.status = 'deadline'; note(conv, 'הגיע הדדליין שהבעלים קבע'); save(conv); emit(conv); }
    if (d.allow) { if (!d.rest) st.blocks = 0; save(conv); return null; }
    st.blocks = (st.blocks || 0) + 1; toolsAtBlock.set(convId, Date.now()); save(conv);
    return { decision: 'block', reason: `[🧭 מנהל עבודה — אסור לעצור עכשיו] ${d.text}` };
  }

  // a turn ended somewhere: a worker → report to its manager (+ wall detection); the manager → nothing
  function onTurnEnd(convId, { text, error, refused } = {}) {
    let c = null; try { c = getConv(convId); } catch { } if (!c || !c.managedBy) return;
    let m = null; try { m = getConv(c.managedBy); } catch { } const st = stOf(m); if (!st || st.status !== 'running') return;
    // a wall = a real failure statement (not "added error handling" / "0 failed")
    const wall = error || refused || WALL_RE.test(String(text || '').slice(-1500));
    if (wall) addWall(m, `${c.code}: ${norm(error || text).slice(0, 140)}`, false);
    const body = `[עובד ${c.code} "${c.title}" סיים תור${wall ? ' — ⚠ נראה כקיר' : ''}]\n${norm(error ? 'שגיאה: ' + error : text).slice(0, 1800) || '(בלי טקסט)'}\n\nאמת בעצמך את מה שהוא טוען (קבצים / בדיקות), ואז החלט על הצעד הבא.`;
    st.reportsSinceImprove = (st.reportsSinceImprove || 0) + 1; ev(st, 'report', c.code, wall ? 'wall' : 'ok');
    note(m, `עובד ${c.code} סיים${wall ? ' (קיר)' : ''}`); save(m);
    Promise.resolve(sendToChat(m.id, body, { from: c.code, fromInfo: { kind: 'worker', code: c.code } })).catch(e => log('[manager] notify ' + e.message));
  }
  function addWall(m, what, fromProof) {
    const st = stOf(m); if (!st) return;
    const k = wallKey(what); const w = st.walls.find(x => x.key === k && !x.resolved);
    if (w) { w.count++; w.at = Date.now(); } else st.walls.push({ key: k, what: norm(what).slice(0, 200), count: 1, at: Date.now(), fromProof: !!fromProof });
    if (st.walls.length > 60) st.walls.splice(0, st.walls.length - 60);
    note(m, '🧱 קיר: ' + norm(what).slice(0, 120)); save(m); emit(m);
  }

  function runProof(cmd, cwd, timeoutSec) {
    return new Promise(resolve => {
      const t0 = Date.now(); let out = '';
      let ch; try { ch = spawn(process.platform === 'win32' ? 'powershell.exe' : 'bash', process.platform === 'win32' ? ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', cmd] : ['-lc', cmd], { cwd, windowsHide: true }); }
      catch (e) { return resolve({ code: -1, out: String(e.message), ms: 0 }); }
      const add = d => { out += d; if (out.length > 200000) out = out.slice(-100000); };
      ch.stdout.on('data', add); ch.stderr.on('data', add);
      const to = setTimeout(() => { try { process.platform === 'win32' ? spawn('taskkill', ['/pid', String(ch.pid), '/T', '/F'], { windowsHide: true }) : ch.kill('SIGKILL'); } catch { } }, timeoutSec * 1000);
      ch.on('close', code => { clearTimeout(to); resolve({ code: code == null ? -1 : code, out, ms: Date.now() - t0 }); });
      ch.on('error', e => { clearTimeout(to); resolve({ code: -1, out: out + String(e.message), ms: Date.now() - t0 }); });
    });
  }

  // MCP tools of the manager
  async function tool(convId, name, a = {}) {
    let conv = null; try { conv = getConv(convId); } catch { } const st = stOf(conv);
    const err = t => ({ output: t, is_error: true });
    if (!st) return err('הכלי הזה רק למנהל עבודה (צ\'אט שהבעלים הגדיר כמנהל).');
    st.lastToolAt = Date.now();
    if (name === 'manager_status') {
      const lv = live(conv);
      return { output: JSON.stringify({ goal: st.goal, status: st.status, deadline: st.deadline, maxWorkers: st.maxWorkers, workers: lv.workers, plan: st.plan, openWalls: st.walls.filter(w => !w.resolved), need: wallNeed(st), scale: st.scale, research: st.researchTopics, kickoff: kickoffNeed(st), improveDue: improveNeed(st, Date.now(), MIN), improvements: (st.improvements || []).slice(-10) }, null, 1) };
    }
    if (name === 'manager_plan') {
      const items = Array.isArray(a.items) ? a.items : []; if (!items.length) return err('צריך items: [{id, text}]');
      const old = new Map((st.plan || []).map(p => [p.id, p]));
      st.plan = items.slice(0, 60).map((it, i) => { const id = norm(it.id || 'P' + (i + 1)).slice(0, 12); const prev = old.get(id); const text = norm(it.text).slice(0, 300); const extra = { role: norm(it.role).slice(0, 40), proof: norm(it.proof).slice(0, 200) }; return prev && prev.text === text ? { ...prev, ...extra } : { id, text, status: 'todo', proofs: [], ...extra }; });
      if (a.scale) st.scale = norm(a.scale).slice(0, 1500);
      if (Array.isArray(a.research)) st.researchTopics = a.research.map(x => norm(x).slice(0, 160)).filter(Boolean).slice(0, 20);
      if (!st.planAt) st.planAt = Date.now(); st.replans = (st.replans || 0) + 1; ev(st, 'plan', String(st.plan.length), (st.replans > 1 ? 'replan ' : '') + String(st.scale || '').slice(0, 100));
      note(conv, `תוכנית: ${st.plan.length} פריטים`); save(conv); emit(conv);
      const miss = kickoffNeed(st);
      return { output: (miss && miss !== 'research' ? '⚠ ' + KICKOFF_TEXT[miss] + '\n' : '') + 'התוכנית נשמרה:\n' + st.plan.map(p => `${p.status === 'proven' ? '✅' : '⬜'} ${p.id} ${p.text}`).join('\n') };
    }
    if (name === 'manager_prove') {
      const p = (st.plan || []).find(x => x.id === String(a.item || '')); if (!p) return err('אין פריט כזה בתוכנית: ' + a.item);
      const cmd = String(a.command || '').trim(); if (!cmd) return err('חסרה command — הפקודה שמוכיחה את הפריט');
      const expect = String(a.expect || '');
      const cwd = a.cwd || projectDirOf(conv) || process.cwd();
      const r = await runProof(cmd, cwd, clampInt(a.timeout_sec, 5, 90, 90));
      const ok = r.code === 0 && (!expect || r.out.includes(expect));
      const ev = { at: Date.now(), cmd: cmd.slice(0, 500), expect: expect.slice(0, 200), code: r.code, ms: r.ms, tail: r.out.slice(-1500), ok };
      p.proofs = (p.proofs || []).concat(ev).slice(-5);
      if (ok) { p.status = 'proven'; p.provenAt = Date.now(); for (const w of st.walls) if (!w.resolved && w.fromProof && w.key === wallKey('proof ' + p.id)) w.resolved = true; }
      else { p.fails = (p.fails || 0) + 1; p.status = 'failing'; if (p.fails >= 2) addWall(conv, 'proof ' + p.id, true); }
      note(conv, `${ok ? '✅' : '❌'} הוכחה ${p.id} (קוד ${r.code})`); save(conv); emit(conv);
      return { output: `${ok ? '✅ הוכח' : '❌ לא הוכח'}: ${p.id} "${p.text}"\nפקודה: ${cmd}\nקוד יציאה: ${r.code}${expect ? ` · טקסט צפוי "${expect}": ${r.out.includes(expect) ? 'נמצא' : 'לא נמצא'}` : ''} · ${r.ms}ms\n--- סוף הפלט ---\n${r.out.slice(-2500)}`, is_error: !ok };
    }
    if (name === 'manager_finish') {
      const f = finishCheck(st); if (!f.ok) return err(f.text);
      st.status = 'done'; st.finishedAt = Date.now(); for (const w of st.walls) w.resolved = true; st.finishNote = norm(a.summary).slice(0, 2000);
      note(conv, '🏁 הפרויקט הוכח והסתיים'); save(conv); emit(conv);
      return { output: '🏁 הפרויקט סומן כמוכח וגמור. כתוב לבעלים סיכום קצר: מה נבנה ואיך כל דבר הוכח.' };
    }
    if (name === 'manager_improve') {
      const o = norm(a.observation), ch = norm(a.change); if (!o || !ch) return err('צריך observation (מה ראית) ו-change (מה משנים)');
      if (!improveGrounded(st)) return err('שיפור צריך לבוא ממחקר: מאז השיפור הקודם (או מאז שהעובדים התחילו) לא היה מחקר. צא למחקר ייעול (WebSearch / WebFetch, או research_start) על נקודת הכאב — ואז רשום את השיפור שעולה ממנו.');
      st.improvements = st.improvements || []; st.improvements.push({ at: Date.now(), observation: o.slice(0, 400), change: ch.slice(0, 400), metric: norm(a.metric).slice(0, 200) }); if (st.improvements.length > 100) st.improvements.shift();
      st.reportsSinceImprove = 0; ev(st, 'improve', ch.slice(0, 80), a.metric); note(conv, '📈 שיפור: ' + ch.slice(0, 120)); save(conv); emit(conv);
      return { output: `נרשם שיפור #${st.improvements.length}. עכשיו יישם אותו (הנחה את העובדים / עדכן תוכנית / תזרים) ומדוד את ${norm(a.metric) || 'המדד'} לפני ואחרי.` };
    }
    if (name === 'manager_wall') { addWall(conv, String(a.what || 'קיר'), false); return { output: 'נרשם קיר. עכשיו חובה מחקר: WebSearch, ואם הקיר חוזר — research_start.' }; }
    if (name === 'manager_release') {
      const w = workersOf(conv).find(c => String(c.code).toUpperCase() === String(a.code || '').toUpperCase()); if (!w) return err('אין עובד כזה');
      const wc = getConv(w.id); wc.released = true; saveConv(wc); note(conv, 'שוחרר עובד ' + w.code); save(conv); emit(conv);
      return { output: `העובד ${w.code} שוחרר (השיחה נשארת, אבל לא נספרת כעובד).` };
    }
    if (name === 'manager_watch') {
      const w = workersOf(conv).find(c => String(c.code).toUpperCase() === String(a.code || '').toUpperCase()); if (!w) return err('אין עובד כזה');
      try { const r = createWatch({ convId: w.id, task: a.task, everyMin: a.every_min, durationMin: a.duration_min }); note(conv, `מעקב לעובד ${w.code}`); save(conv); return { output: `נפתח מעקב לעובד ${w.code}: ${r && (r.id || '')}` }; }
      catch (e) { return err(e.message); }
    }
    return err('כלי לא מוכר: ' + name);
  }
  // a worker the manager opened: mark it, put it in the manager's folder
  function adoptWorker(managerId, workerConv) {
    let m = null; try { m = getConv(managerId); } catch { } if (!stOf(m)) return;
    workerConv.managedBy = m.id; workerConv.workerRole = m.manager.pendingRole || ''; m.manager.roles = { ...(m.manager.roles || {}), [workerConv.code]: workerConv.workerRole }; ev(m.manager, 'hire', workerConv.code, workerConv.workerRole); if (m.folderId) workerConv.folderId = m.folderId; saveConv(workerConv);
    m.manager.workers = [...new Set([...(m.manager.workers || []), workerConv.id])]; note(m, 'נפתח עובד ' + workerConv.code); save(m); emit(m);
  }

  // heartbeat: a running manager that sleeps with nothing running is woken; the deadline is applied
  let timer = null;
  function tick() {
    const now = Date.now();
    for (const c of listConvs() || []) {
      if (c.role !== 'manager') continue;
      let conv; try { conv = getConv(c.id); } catch { continue; } const st = stOf(conv); if (!st) continue;
      // release freeze (exam gpt #4: at the deadline a worker was mid-edit and 1/43 tests failed): FREEZE_MIN before the deadline the manager stops changes and keeps the deliverable green
      if (st.status === 'running' && st.deadline && !st.frozenAt && now >= st.deadline - FREEZE_MIN * MIN && now < st.deadline) { st.frozenAt = now; ev(st, 'freeze', String(FREEZE_MIN), ''); note(conv, '❄ הקפאת שחרור — ' + FREEZE_MIN + ' דקות לדדליין'); save(conv); emit(conv);
        sendToChat(conv.id, `[🧭 הקפאת שחרור] נשארו ${FREEZE_MIN} דקות לדדליין. מעכשיו: אין שינויים חדשים. הורה לכל העובדים לעצור עריכות ולשמור את מה שעובד, הרץ את כל הבדיקות (manager_prove) וודא שהתוצר ירוק ושלם. אם משהו באמצע — בטל אותו ולא תשאיר חצי עבודה.`, { from: 'manager', fromInfo: { kind: 'manager-tick' } }).catch(e => log('[manager] freeze ' + e.message)); continue; }
      if (st.status === 'running' && st.deadline && now >= st.deadline) { st.status = 'deadline'; note(conv, 'הגיע הדדליין'); save(conv); emit(conv); sendToChat(conv.id, '[🧭 הגיע הדדליין שהבעלים קבע] עצור עבודה חדשה. כתוב לבעלים דוח: מה הוכח, מה לא, ומה הצעד הבא.', { from: 'manager', fromInfo: { kind: 'manager-tick' } }).catch(() => { }); continue; }
      if (st.status !== 'running' || isRunning(conv.id)) continue;
      { // hand on the pulse (exam cnn #2: a worker went silent mid-turn for 40 min and the manager just waited): a 'running' worker with no activity for SILENT_MIN wakes the manager
        const silent = workersOf(conv).filter(w => isRunning(w.id) && now - (w.updatedAt || 0) > SILENT_MIN * MIN && now - ((st.silentWarned || {})[w.id] || 0) > SILENT_MIN * MIN);
        if (silent.length && !isRunning(conv.id)) { st.silentWarned = { ...(st.silentWarned || {}) }; for (const w of silent) st.silentWarned[w.id] = now; ev(st, 'silent', silent.map(w => w.code).join(','), ''); note(conv, 'עובד שותק: ' + silent.map(w => w.code).join(', ')); save(conv);
          sendToChat(conv.id, `[🧭 יד על הדופק] העובד ${silent.map(w => w.code).join(', ')} מסומן "עובד" אבל לא היה לו שום פעולה ${SILENT_MIN}+ דקות. בדוק אותו עכשיו (chat_read): אם הוא תקוע — שלח לו הוראה (chat_send) או שחרר והחלף (manager_release + chat_new). אל תחכה.`, { from: 'manager', fromInfo: { kind: 'manager-tick' } }).catch(e => log('[manager] silent ' + e.message)); continue; } }
      const lv = live(conv); if (lv.workers.some(w => w.running) || researchRunningFor(conv.id)) continue;
      if (now - Math.max(st.lastWakeAt || 0, conv.updatedAt || 0) < st.heartbeatMin * MIN) continue;
      st.lastWakeAt = now; st.blocks = 0; note(conv, 'פעימה: המנהל הוער'); save(conv);
      sendToChat(conv.id, '[🧭 פעימה] אין עובד או מחקר שרצים והפרויקט עוד לא הוכח. בדוק מצב (manager_status), החלט והמשך.', { from: 'manager', fromInfo: { kind: 'manager-tick' } }).catch(e => log('[manager] wake ' + e.message));
    }
  }
  function start(everyMs = 60000) { clearInterval(timer); timer = setInterval(() => { try { tick(); } catch (e) { log('[manager] tick ' + e.message); } }, everyMs); if (timer.unref) timer.unref(); }
  function stop() { clearInterval(timer); timer = null; }
  function setStatus(conv, status) { const st = stOf(conv); if (!st) return null; if (!['running', 'paused', 'stopped'].includes(status)) return null; st.status = status; st.blocks = 0; if (status === 'running') st.lastWakeAt = 0; note(conv, 'הבעלים: ' + status); save(conv); emit(conv); return st; }
  function summary(conv) { const st = stOf(conv); if (!st) return null; const lv = live(conv); return { id: conv.id, code: conv.code, title: conv.title, projectId: conv.projectId, folderId: conv.folderId || null, goal: st.goal, status: st.status, deadline: st.deadline, maxWorkers: st.maxWorkers, workers: lv.workers, plan: st.plan, walls: st.walls.filter(w => !w.resolved && wallNeed({ walls: [w], lastWebAt: st.lastWebAt, lastDeepAt: st.lastDeepAt })), proven: st.plan.filter(p => p.status === 'proven').length, total: st.plan.length, log: st.log.slice(-30), finishedAt: st.finishedAt, createdAt: st.createdAt, scale: st.scale || '', research: st.researchTopics || [], roles: st.roles || {}, improvements: st.improvements || [], replans: st.replans || 0, events: (st.events || []).slice(-(Number(conv._evTail) || 400)), wallsAll: st.walls || [] }; }
  return { create, systemFor, gate, stopGate, onTurnEnd, tool, adoptWorker, tick, start, stop, setStatus, summary, isManager: c => !!stOf(c) };
}

const MANAGER_TOOL_DEFS = [
  { name: 'manager_status', description: 'Manager only: your live state — goal, workers (running/idle), plan items with proof status, open walls and what research they require.', input_schema: { type: 'object', properties: {} } },
  { name: 'manager_plan', description: 'Manager only: set/replace the work plan at a precise professional SCALE — scale (scope as the owner wants it), research (topics: design / efficiency / tools / backend…), and small MEASURABLE items, each with a role (who) and proof (how it is measured). Proven items keep their status if their text is unchanged. Re-plan whenever reality changes.', input_schema: { type: 'object', properties: { scale: { type: 'string', description: 'the exact scope/scale of the work' }, research: { type: 'array', items: { type: 'string' }, description: 'research topics' }, items: { type: 'array', items: { type: 'object', properties: { id: { type: 'string' }, text: { type: 'string', description: 'what must be true' }, role: { type: 'string', description: 'which worker role owns it' }, proof: { type: 'string', description: 'how it will be proven' } }, required: ['text'] } } }, required: ['items'] } },
  { name: 'manager_improve', description: 'Manager only: record an improvement to HOW the work is done (method, split, tools, tests, flows): what you observed, what you change, and the metric that should move. Required every few worker reports — a manager never settles for what exists.', input_schema: { type: 'object', properties: { observation: { type: 'string' }, change: { type: 'string' }, metric: { type: 'string' } }, required: ['observation', 'change'] } },
  { name: 'manager_prove', description: 'Manager only: PROVE a plan item — the SERVER runs the command (PowerShell on Windows) in the project folder; proven only if exit code 0 and the output contains `expect`. Two failed proofs of the same item = a wall (research required).', input_schema: { type: 'object', properties: { item: { type: 'string' }, command: { type: 'string', description: 'command that demonstrates the item works (tests, run, curl…)' }, expect: { type: 'string', description: 'text that must appear in the output' }, cwd: { type: 'string' }, timeout_sec: { type: 'number' } }, required: ['item', 'command'] } },
  { name: 'manager_finish', description: 'Manager only: mark the project DONE. Refused while any plan item is unproven or a wall is open.', input_schema: { type: 'object', properties: { summary: { type: 'string' } } } },
  { name: 'manager_wall', description: 'Manager only: record a wall (something blocks progress). Research becomes mandatory (web search; deep research if it repeats).', input_schema: { type: 'object', properties: { what: { type: 'string' } }, required: ['what'] } },
  { name: 'manager_release', description: 'Manager only: release a worker chat (frees a worker slot; the chat stays).', input_schema: { type: 'object', properties: { code: { type: 'string' } }, required: ['code'] } },
  { name: 'manager_watch', description: 'Manager only: give one of YOUR workers a watch (it re-checks something every N minutes on its own).', input_schema: { type: 'object', properties: { code: { type: 'string' }, task: { type: 'string' }, every_min: { type: 'number' }, duration_min: { type: 'number' } }, required: ['code', 'task', 'every_min'] } }
];

module.exports = { improveGrounded, finishDuties, kickoffNeed, improveNeed, IMPROVE_EVERY, RESEARCH_EVERY_MIN, WALL_RE, createManagers, MANAGER_TOOL_DEFS, stopDecision, wallNeed, canAddWorker, finishCheck, newState, wallKey, BRAIN, MAX_WORKERS_CAP };
