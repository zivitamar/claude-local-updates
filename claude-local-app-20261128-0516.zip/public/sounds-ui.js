// ============================================================
//  sounds-ui.js — הגדרות › 🔊 צלילים
//  מתג ראשי · עוצמה · פרופילים (ברירת מחדל + פרופילים לפרויקטים) · קול לכל פרופיל · חיפוש · כל אירוע וכל כלי: הפעלה + בחירת צליל + ▶
//  בוחר צלילים: ספרייה (חיפוש + קטגוריות) · 3 קולות · הצלילים שלי (העלאת MP3 / הקלטה) · עורך חיתוך מדויק · "מה נוגן לאחרונה" חי
// ============================================================
(function () {
  const App = window.App, el = App.el, esc = App.esc, CAT = window.SOUND_CATALOG, LIB = window.SOUND_LIB;
  const clone = o => JSON.parse(JSON.stringify(o));
  let saveT = null;
  const cur = () => clone(App.sound.settings());
  async function persist(s, msg) { clearTimeout(saveT); App.state.config.sounds = s; saveT = setTimeout(async () => { try { await App.saveConfig({ sounds: s }); if (msg) App.toast('✅ ' + msg, 1200); } catch (e) { App.toast('❌ ' + e.message, 4000); } }, 250); }
  const srcLabel = (src, s) => {
    if (!src) return '—';
    if (src.startsWith('syn:')) { const r = LIB.byId[src.slice(4)]; return '🎵 ' + (r ? r.name : src.slice(4)); }
    if (src === 'voice') return '🗣 קול (המשפט של האירוע)';
    if (src.startsWith('voice:')) return '🗣 קול: ' + voiceName(src.slice(6));
    if (src.startsWith('phrase:')) { const [, v, ...k] = src.split(':'); const key = k.join(':'); const ph = (CAT.byKey[key] || {}).phrase || CAT.EXTRA_PHRASES[key] || key; return '🗣 "' + stripN(ph) + '" · ' + voiceName(v); }
    if (src.startsWith('custom:')) { const c = (s || App.sound.settings()).custom.find(x => x.id === src.slice(7)); return '🎙 ' + (c ? c.name : 'קובץ שנמחק'); }
    return src;
  };
  const stripN = t => String(t || '').replace(/[֑-ׇ]/g, '');
  let VOICES = [];
  const voiceName = id => (VOICES.find(v => v.id === id) || { name: id }).name;

  async function render(box) {
    VOICES = await App.sound.voices().catch(() => []);
    let s = cur(); let profId = box._prof || 'default';
    const prof = () => s.profiles.find(p => p.id === profId) || s.profiles[0];
    box.innerHTML = ''; box.classList.add('snd-page');
    const LV = CAT.LEVELS || { 1: 'קריטיים בלבד', 2: 'מפורט', 3: 'כל הצלילים' };
    // ----- פס קבוע למעלה (בכל תת-עמוד): מתג ראשי + עוצמה -----
    const top = el('section', 'snd-head');
    top.innerHTML = `<label class="snd-master"><input type="checkbox" class="snd-master-cb"><span class="sw big"></span><b>🔊 צלילים</b></label>
      <label class="snd-vol"><input type="range" min="0" max="100" class="snd-vol-r"><b class="snd-vol-v"></b></label>`;
    const mcb = top.querySelector('.snd-master-cb'), vr = top.querySelector('.snd-vol-r'), vv = top.querySelector('.snd-vol-v');
    const paintMaster = () => { mcb.checked = s.master !== false; top.classList.toggle('off', !mcb.checked); box.classList.toggle('snd-off', !mcb.checked); };
    mcb.onchange = () => { s.master = mcb.checked; paintMaster(); persist(s, mcb.checked ? 'הצלילים הופעלו' : 'כל הצלילים כובו'); };
    vr.value = Math.round((s.volume == null ? 0.8 : s.volume) * 100); vv.textContent = vr.value + '%';
    vr.oninput = () => { vv.textContent = vr.value + '%'; s.volume = vr.value / 100; persist(s); };
    paintMaster(); box.appendChild(top);
    // ----- תת-תפריט -----
    const TABS = [['main', '🎚 רמה וקול'], ['events', '🔔 אירועים'], ['profiles', '👤 פרופילים'], ['machines', '🖥 מחשבים'], ['mine', '🎙 הצלילים שלי'], ['log', '📻 מה נוגן']];
    const nav = el('nav', 'snd-nav'); nav.innerHTML = TABS.map(([k, t]) => `<button type="button" class="snd-tab" data-t="${k}">${t}</button>`).join('');
    box.appendChild(nav);
    const pages = {}; for (const [k] of TABS) { pages[k] = el('div', 'snd-sub'); pages[k].dataset.t = k; box.appendChild(pages[k]); }
    const show = k => { box._tab = k; nav.querySelectorAll('.snd-tab').forEach(b => b.classList.toggle('on', b.dataset.t === k)); for (const [kk, pg] of Object.entries(pages)) pg.hidden = kk !== k; };
    nav.querySelectorAll('.snd-tab').forEach(b => b.onclick = () => show(b.dataset.t));

    // ----- רמה וקול: רמת הצלילים (3 מצבים) · הקול (3) · מהירות -----
    const mp = pages.main;
    mp.innerHTML = `<section class="st-sec snd-lvl"><h3>רמת הצלילים</h3>
        <div class="snd-lvl-bar"><input type="range" min="1" max="3" step="1" class="snd-lvl-r"><div class="snd-lvl-ticks">${[1, 2, 3].map(n => `<button type="button" data-l="${n}">${esc(LV[n])}</button>`).join('')}</div></div>
        <div class="snd-lvl-list"></div></section>
      <section class="st-sec"><h3>קול</h3><div class="snd-voices"></div></section>
      <section class="st-sec"><h3>מהירות דיבור</h3><label class="snd-speed"><input type="range" min="0.7" max="1.5" step="0.05" class="snd-sp-r"><b class="snd-sp-v"></b><button type="button" class="btn-ghost snd-sp-play">▶</button></label></section>`;
    const lr = mp.querySelector('.snd-lvl-r'), ll = mp.querySelector('.snd-lvl-list');
    const paintLevel = () => {
      lr.value = s.level || 1; mp.querySelectorAll('.snd-lvl-ticks button').forEach(b => b.classList.toggle('on', +b.dataset.l === +lr.value));
      const keys = CAT.EVENTS.filter(e => CAT.levelOf(e.key) <= +lr.value);
      ll.innerHTML = +lr.value === 3 ? '' : keys.map(e => `<span class="snd-chip">${esc(e.label)}</span>`).join('');
    };
    const setLevel = n => { s.level = n; persist(s, 'רמת הצלילים: ' + LV[n]); paintLevel(); paintEvents(); };
    lr.oninput = () => setLevel(+lr.value);
    mp.querySelectorAll('.snd-lvl-ticks button').forEach(b => b.onclick = () => setLevel(+b.dataset.l));
    const paintVoices = () => {
      const vbox = mp.querySelector('.snd-voices'); vbox.innerHTML = '';
      for (const v of VOICES) { const b = el('button', 'snd-voice' + (prof().voice === v.id ? ' on' : '')); b.type = 'button'; b.dataset.voice = v.id; b.innerHTML = `<span>${esc(v.name)}</span><i title="השמע">▶</i>`;
        b.onclick = e => { if (e.target.tagName === 'I') { App.sound.preview('phrase:' + v.id + ':ev:finish', { key: 'ev:finish' }); return; } prof().voice = v.id; persist(s, 'הקול: ' + v.name); paintVoices(); paintProf(); paintEvents(); }; vbox.appendChild(b); }
    };
    const spr = mp.querySelector('.snd-sp-r'), spv = mp.querySelector('.snd-sp-v');
    const paintSpeed = () => { spr.value = s.speed || 1; spv.textContent = '×' + (+spr.value).toFixed(2); };
    spr.oninput = () => { s.speed = +spr.value; paintSpeed(); persist(s); };
    mp.querySelector('.snd-sp-play').onclick = () => App.sound.preview('voice', { key: 'ev:finish', voice: prof().voice });
    paintSpeed();

    // ----- פרופילים: בחירה · יצירה · שם · מחיקה · שיוך לפרויקטים -----
    const ps = pages.profiles; ps.classList.add('snd-prof');
    ps.innerHTML = `<section class="st-sec"><div class="snd-prof-cards"></div><button type="button" class="btn-primary snd-prof-new">＋ פרופיל חדש</button></section>
      <section class="st-sec"><h3>פרופיל לכל פרויקט</h3><div class="snd-proj-list"></div></section>`;
    const paintProf = () => {
      const cards = ps.querySelector('.snd-prof-cards'); cards.innerHTML = '';
      for (const p of s.profiles) {
        const used = (App.projects ? App.projects.list() : []).filter(x => (s.projectProfiles[x.id] || 'default') === p.id).map(x => x.name);
        const c = el('div', 'snd-pcard' + (p.id === prof().id ? ' on' : '')); c.dataset.id = p.id;
        c.innerHTML = `<button type="button" class="snd-pcard-pick"><b></b><small></small></button>${p.id === 'default' ? '' : '<button type="button" class="btn-ghost" data-a="ren" title="שם">✏️</button><button type="button" class="btn-ghost" data-a="del" title="מחק">🗑️</button>'}`;
        c.querySelector('b').textContent = p.name; c.querySelector('small').textContent = voiceName(p.voice) + (used.length ? ' · ' + used.join(', ') : p.id === 'default' ? ' · כל השאר' : '');
        c.querySelector('.snd-pcard-pick').onclick = () => { profId = box._prof = p.id; paintProf(); paintVoices(); paintEvents(); App.toast('עורך את "' + p.name + '"', 1200); };
        const ren = c.querySelector('[data-a=ren]'); if (ren) ren.onclick = async () => { const n = await App.prompt('שם הפרופיל:', p.name, { title: 'שינוי שם' }); if (!n || !n.trim()) return; p.name = n.trim().slice(0, 40); persist(s); paintProf(); };
        const del = c.querySelector('[data-a=del]'); if (del) del.onclick = async () => { if (!(await App.confirm(`למחוק את הפרופיל "${p.name}"?`, { danger: true, okText: 'מחק' }))) return; s.profiles = s.profiles.filter(x => x !== p); for (const [k, v] of Object.entries(s.projectProfiles)) if (v === p.id) delete s.projectProfiles[k]; profId = box._prof = 'default'; persist(s, 'הפרופיל נמחק'); paintProf(); paintVoices(); paintEvents(); };
        cards.appendChild(c);
      }
      const pl = ps.querySelector('.snd-proj-list'); pl.innerHTML = '';
      for (const p of (App.projects ? App.projects.list() : [])) {
        const r = el('label', 'snd-proj'); r.innerHTML = `<span>📁 ${esc(p.name)}</span>`; const ss = el('select'); ss.dataset.project = p.id;
        ss.innerHTML = s.profiles.map(x => `<option value="${esc(x.id)}">${esc(x.name)}</option>`).join(''); ss.value = s.projectProfiles[p.id] || 'default';
        ss.onchange = () => { if (ss.value === 'default') delete s.projectProfiles[p.id]; else s.projectProfiles[p.id] = ss.value; persist(s, 'הפרויקט "' + p.name + '" ← ' + ss.options[ss.selectedIndex].text); paintProf(); };
        r.appendChild(ss); pl.appendChild(r);
      }
    };
    ps.querySelector('.snd-prof-new').onclick = async () => { const n = await App.prompt('שם הפרופיל החדש:', 'פרופיל ' + s.profiles.length, { title: 'פרופיל צלילים חדש' }); if (!n || !n.trim()) return; const id = 'p' + Date.now().toString(36); s.profiles.push({ id, name: n.trim().slice(0, 40), voice: prof().voice, events: clone(prof().events || {}) }); profId = box._prof = id; persist(s, 'נוצר פרופיל "' + n.trim() + '"'); paintProf(); paintVoices(); paintEvents(); };

    // ----- מחשבים: צלילים מכל מחשב ברשת — מתי להשמיע, עוצמה, רמה, פרופיל (הצלילים מושמעים תמיד ברמקולים של המחשב שלך) -----
    const mpg = pages.machines; mpg.classList.add('snd-mach');
    const setMach = (id, patch) => { s.machines = s.machines || {}; const o = { ...(s.machines[id] || {}), ...patch }; for (const k of Object.keys(o)) if (o[k] == null || o[k] === false || o[k] === '') delete o[k]; if (Object.keys(o).length) s.machines[id] = o; else delete s.machines[id]; persist(s); };
    const paintMach = () => {
      const ms = App.mesh ? App.mesh.machines() : [];
      mpg.innerHTML = `<section class="st-sec snd-om-sec"><label class="snd-om"><input type="checkbox"><span class="sw"></span><span class="snd-om-t"><b>צלילים ממחשבים אחרים</b><small>צ'אט שמסיים או מבקש אישור במחשב אחר — נשמע כאן, ברמקולים שלך</small></span></label></section><div class="snd-mlist"></div>`;
      const om = mpg.querySelector('.snd-om input'); om.checked = s.otherMachines !== false;
      const box2 = mpg.querySelector('.snd-mlist');
      const dim = () => box2.querySelectorAll('.snd-mcard:not(.self)').forEach(c => c.classList.toggle('off', !om.checked));
      om.onchange = () => { s.otherMachines = om.checked; persist(s, om.checked ? 'צלילים ממחשבים אחרים: פועל' : 'צלילים ממחשבים אחרים: כבוי'); dim(); };
      if (!ms.length) { box2.appendChild(el('div', 'ag-empty', 'אין מחשבים ברשת')); return; }
      const MODES = [['always', '🔊 תמיד'], ['viewing', '👁 רק כשאני עליו'], ['mute', '🔇 מושתק']];
      for (const m of ms) {
        const c = (s.machines || {})[m.id] || {}, card = el('div', 'snd-mcard' + (m.self ? ' self' : '')); card.dataset.id = m.id;
        card.style.setProperty('--mc', App.mesh.colorOf(m.id)); if (App.mesh.fgOf) card.style.setProperty('--mc-fg', App.mesh.fgOf(m.id));
        const mode = c.mute ? 'mute' : c.onlyViewing ? 'viewing' : 'always', vol = Math.round((c.vol != null ? c.vol : 1) * 100);
        card.innerHTML = `<div class="snd-mhead"><i class="snd-mav"></i><div class="snd-mtitle"><b></b><small></small></div><span class="snd-mstate"></span></div>
          <div class="snd-mgrid">
            <span class="snd-ml">מתי להשמיע</span><div class="snd-mseg">${MODES.map(([v, t]) => `<button type="button" data-v="${v}">${t}</button>`).join('')}</div>
            <span class="snd-ml">עוצמה</span><label class="snd-mvol"><input type="range" min="0" max="100" value="${vol}"><b>${vol}%</b></label>
            <span class="snd-ml">רמת פירוט</span><select class="snd-mlvl"><option value="">כמו ההגדרה הכללית</option>${[1, 2, 3].map(n => `<option value="${n}">${esc(LV[n])}</option>`).join('')}</select>
            <span class="snd-ml">פרופיל צלילים</span><select class="snd-mprof">${s.profiles.map(p => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('')}</select>
          </div>`;
        if (App.mesh.iconOf) card.querySelector('.snd-mav').innerHTML = App.mesh.iconOf(m); else card.querySelector('.snd-mav').textContent = App.mesh.initials ? App.mesh.initials(m.displayName) : String(m.displayName || '?').slice(0, 2);
        card.querySelector('.snd-mtitle b').textContent = m.displayName;
        card.querySelector('.snd-mtitle small').textContent = [m.info && m.info.host, m.info && m.info.os].filter(Boolean).join(' · ');
        const st = card.querySelector('.snd-mstate'); st.textContent = m.self ? 'המחשב הזה' : m.online ? '🟢 מחובר' : '⚪ לא מחובר'; st.classList.add(m.self ? 'self' : m.online ? 'on' : 'off');
        const segB = [...card.querySelectorAll('.snd-mseg button')]; const paintSeg = v => segB.forEach(b => b.classList.toggle('on', b.dataset.v === v)); paintSeg(mode);
        segB.forEach(b => (b.onclick = () => { paintSeg(b.dataset.v); setMach(m.id, { mute: b.dataset.v === 'mute', onlyViewing: b.dataset.v === 'viewing' }); }));
        const vr = card.querySelector('.snd-mvol input'), vb = card.querySelector('.snd-mvol b'); vr.oninput = () => { vb.textContent = vr.value + '%'; setMach(m.id, { vol: +vr.value === 100 ? null : +vr.value / 100 }); };
        const sl = card.querySelector('.snd-mlvl'); sl.value = c.level ? String(c.level) : ''; sl.onchange = () => setMach(m.id, { level: sl.value ? +sl.value : null });
        const sp = card.querySelector('.snd-mprof'); sp.value = c.profile || 'default'; sp.onchange = () => setMach(m.id, { profile: sp.value === 'default' ? null : sp.value });
        box2.appendChild(card);
      }
      dim();
    };
    nav.querySelector('[data-t=machines]').addEventListener('click', paintMach);
    if (box._tab === 'machines') paintMach();

    // ----- אירועים -----
    const es = el('section', 'st-sec snd-events');
    es.innerHTML = `<div class="snd-row snd-tools"><input type="search" class="text-input snd-search" placeholder="🔍 חיפוש"><span class="snd-count ag-dim"></span></div>
      <div class="snd-row snd-bulk"><span class="snd-evprof"></span><button class="btn-ghost" data-bulk="voice-tools">🗣 קול לכל הכלים</button><button class="btn-ghost" data-bulk="off-tools">🔕 כבה את כל הכלים</button><button class="btn-ghost" data-bulk="reset">↺ ברירת מחדל</button></div>
      <div class="snd-list"></div>`;
    const list = es.querySelector('.snd-list'), search = es.querySelector('.snd-search'), count = es.querySelector('.snd-count');
    const openGroups = box._open || (box._open = new Set());
    const isTool = k => !/^ev:/.test(k) || k === 'ev:screenshot' || k === 'ev:image';
    es.querySelectorAll('[data-bulk]').forEach(b => b.onclick = async () => {
      const p = prof(); p.events = p.events || {};
      if (b.dataset.bulk === 'reset') { if (!(await App.confirm('להחזיר את כל האירועים בפרופיל הזה לברירת המחדל?', { okText: 'החזר' }))) return; p.events = {}; }
      else for (const e of CAT.EVENTS) if (isTool(e.key)) p.events[e.key] = b.dataset.bulk === 'voice-tools' ? { on: true, src: 'voice' } : { ...(p.events[e.key] || {}), on: false };
      persist(s, { 'voice-tools': 'כל הכלים יאמרו בקול מה Claude עושה', 'off-tools': 'כל צלילי הכלים כבויים', reset: 'חזר לברירת המחדל' }[b.dataset.bulk]); paintEvents();
    });
    function paintEvents() {
      const q = search.value.trim().toLowerCase(); const p = prof(); list.innerHTML = ''; let shown = 0, onN = 0;
      es.querySelector('.snd-evprof').textContent = '👤 ' + p.name;
      for (const [gid, gname] of Object.entries(CAT.GROUPS)) {
        const items = CAT.EVENTS.filter(e => e.group === gid).filter(e => { if (!q) return true; const c = App.sound.eventCfg(p, e.key); return (e.label + ' ' + stripN(e.phrase) + ' ' + e.key + ' ' + gname + ' ' + srcLabel(c.src, s) + ' ' + CAT.tags(e.key)).toLowerCase().includes(q); });
        if (!items.length) continue;
        // מקופל בהתחלה; נפתח כשמחפשים (או כשהמשתמש פתח אותו קודם)
        const g = el('details', 'snd-group'); g.open = !!q || openGroups.has(gid); g.ontoggle = () => { if (!q) g.open ? openGroups.add(gid) : openGroups.delete(gid); };
        g.innerHTML = `<summary>${esc(gname)} <small class="ag-dim">${items.length}</small></summary>`;
        for (const e of items) {
          const c = App.sound.eventCfg(p, e.key); shown++; if (c.on) onN++;
          const lv = CAT.levelOf(e.key), inLevel = lv <= (s.level || 1);
          const r = el('div', 'snd-ev' + (c.on ? ' on' : '') + (inLevel ? '' : ' out-lvl')); r.dataset.key = e.key; if (!inLevel) r.title = 'מעל רמת הצלילים שנבחרה — לא יושמע עד שתעלה את הרמה';
          r.innerHTML = `<label class="snd-ev-t"><input type="checkbox" ${c.on ? 'checked' : ''}><span class="sw"></span><span class="snd-ev-l">${esc(e.label)}</span></label><span class="snd-lv l${lv}" title="${esc(LV[lv])}">${lv === 1 ? '●' : lv === 2 ? '◐' : '○'}</span><button type="button" class="snd-src" title="בחר צליל">${esc(srcLabel(c.src, s))}</button><button type="button" class="snd-play" title="השמע">▶</button>`;
          r.querySelector('input').onchange = ev => { p.events = p.events || {}; p.events[e.key] = { ...(p.events[e.key] || {}), on: ev.target.checked }; r.classList.toggle('on', ev.target.checked); persist(s); count.textContent = countText(); };
          r.querySelector('.snd-play').onclick = () => App.sound.preview(c.src, { key: e.key, voice: p.voice });
          r.querySelector('.snd-src').onclick = () => openPicker(e, p, () => paintEvents());
          g.appendChild(r);
        }
        list.appendChild(g);
      }
      if (!shown) list.appendChild(el('div', 'ag-empty', 'לא נמצא אירוע או צליל שמתאים לחיפוש'));
      count.textContent = countText(shown, onN);
    }
    const countText = (shown, onN) => { const p = prof(); const on = CAT.EVENTS.filter(e => App.sound.eventCfg(p, e.key).on).length; return `${on} פעילים מתוך ${CAT.EVENTS.length}` + (shown != null && shown !== CAT.EVENTS.length ? ` · מוצגים ${shown}` : ''); };
    search.oninput = () => paintEvents();
    pages.events.appendChild(es);

    // ----- הצלילים שלי -----
    const cs = el('section', 'st-sec snd-custom');
    cs.innerHTML = `<div class="snd-row"><button class="btn-primary snd-up">📁 העלה קובץ</button><button class="btn-ghost snd-rec">🎙 הקלט</button><input type="file" class="snd-file" accept="audio/*,.mp3,.wav,.ogg,.m4a,.webm" hidden></div><div class="snd-clist"></div>`;
    const clist = cs.querySelector('.snd-clist');
    function paintCustom() {
      clist.innerHTML = ''; if (!s.custom.length) { clist.appendChild(el('div', 'ag-dim', 'עוד אין צלילים שלך.')); return; }
      for (const c of s.custom) {
        const r = el('div', 'snd-c'); r.dataset.id = c.id;
        r.innerHTML = `<span class="snd-c-n">🎙 ${esc(c.name)}</span><small class="ag-dim">${fmtLen((c.end != null ? c.end : c.dur) - (c.start || 0))} · מתוך הקובץ: <bdi dir="ltr">${(+(c.start || 0)).toFixed(2)} → ${(+(c.end != null ? c.end : c.dur)).toFixed(2)}</bdi></small><button class="btn-ghost" data-a="play">▶</button><button class="btn-ghost" data-a="edit">✂️ חתוך</button><button class="btn-ghost" data-a="del">🗑️</button>`;
        r.querySelector('[data-a=play]').onclick = () => App.sound.preview('custom:' + c.id);
        r.querySelector('[data-a=edit]').onclick = () => openTrimmer(c, () => { persist(s, 'החיתוך נשמר'); paintCustom(); paintEvents(); });
        r.querySelector('[data-a=del]').onclick = async () => { if (!(await App.confirm(`למחוק את "${c.name}"? אירועים שהשתמשו בו יחזרו לצליל ברירת המחדל.`, { danger: true, okText: 'מחק' }))) return; s.custom = s.custom.filter(x => x !== c); for (const pp of s.profiles) for (const v of Object.values(pp.events || {})) if (v.src === 'custom:' + c.id) delete v.src; App.api('/api/sounds/custom/' + c.id, { method: 'DELETE' }).catch(() => { }); persist(s, 'נמחק'); paintCustom(); paintEvents(); };
        clist.appendChild(r);
      }
    }
    const fileIn = cs.querySelector('.snd-file');
    cs.querySelector('.snd-up').onclick = () => fileIn.click();
    fileIn.onchange = async () => { const f = fileIn.files[0]; fileIn.value = ''; if (f) await addCustom(f, f.name.replace(/\.[^.]+$/, '')); };
    cs.querySelector('.snd-rec').onclick = () => recordDialog(blob => addCustom(blob, 'הקלטה ' + App.fmt.hm(Date.now())));
    async function addCustom(blob, name) {
      try {
        const ext = (/\.(mp3|wav|ogg|m4a|webm)$/i.exec(blob.name || '') || [, (blob.type.match(/(mpeg|mp3)/) ? 'mp3' : blob.type.match(/wav/) ? 'wav' : blob.type.match(/ogg/) ? 'ogg' : blob.type.match(/mp4|m4a/) ? 'm4a' : 'webm')])[1].toLowerCase();
        const data = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(blob); });
        const up = await App.api('/api/sounds/custom', { method: 'POST', body: { data, ext } });
        const ab = await blob.arrayBuffer(); App.sound.unlock(); const buf = await new (window.OfflineAudioContext)(1, 1, 44100).decodeAudioData(ab.slice(0));
        const c = { id: up.id, name: String(name || 'צליל').slice(0, 60), ext, dur: +buf.duration.toFixed(3), start: 0, end: null, gain: 1 };
        s.custom.push(c); persist(s, 'הקובץ נוסף — עכשיו אפשר לחתוך'); paintCustom(); openTrimmer(c, () => { persist(s, 'החיתוך נשמר'); paintCustom(); paintEvents(); });
      } catch (e) { App.toast('❌ לא הצלחתי לקרוא את הקובץ: ' + e.message, 5000); }
    }
    pages.mine.appendChild(cs);

    // ----- מה נוגן לאחרונה (חי) -----
    const ls = el('section', 'st-sec snd-live'); ls.innerHTML = '<div class="snd-log"></div>';
    const lg = ls.querySelector('.snd-log');
    const paintLog = () => { const l = App.sound.log.slice(-12).reverse(); lg.innerHTML = l.length ? l.map(x => `<div class="snd-l ${x.played ? 'ok' : 'skip'}"><time>${App.fmt.time(x.at)}</time><b>${esc((CAT.byKey[x.key || x.keys[0]] || {}).label || x.key || x.keys[0])}</b><span>${x.played ? esc(srcLabel(x.src, s)) + ' · ' + (x.dur || 0).toFixed(2) + ' שנ\'' : esc(x.skip || '')}</span></div>`).join('') : '<div class="ag-dim">עוד לא נוגן כלום. כשה-Claude יעבוד, תראה כאן כל צליל בזמן אמת.</div>'; };
    const off = App.on('sound:played', () => { if (!document.body.contains(lg)) return; paintLog(); });
    paintLog(); pages.log.appendChild(ls);

    paintProf(); paintEvents(); paintCustom(); paintLevel(); paintVoices(); show(box._tab || 'main');
  }
  const fmtS = v => (Math.max(0, +v || 0)).toFixed(2) + ' שנ\'';
  const fmtLen = v => (Math.max(0, +v || 0)).toFixed(2) + ' שנ\'';

  // ---------- בוחר צליל לאירוע ----------
  function openPicker(e, p, done) {
    const s = App.sound.settings(); const cur0 = App.sound.eventCfg(p, e.key).src;
    const body = el('div', 'snd-picker');
    body.innerHTML = `<div class="snd-pk-head"><b>${esc(e.label)}</b><small class="ag-dim">עכשיו: ${esc(srcLabel(cur0, s))}</small></div>
      <div class="seg snd-tabs"><button class="seg-btn active" data-t="lib">🎵 צלילים (${LIB.list.length})</button><button class="seg-btn" data-t="voice">🗣 קולות</button><button class="seg-btn" data-t="mine">🎙 שלי (${s.custom.length})</button></div>
      <input type="search" class="text-input snd-pk-q" placeholder="🔍 חיפוש צליל…"><div class="snd-pk-body"></div>`;
    const m = App.modal({ title: '🔔 בחר צליל', body, cls: 'snd-pick-modal' });
    const pb = body.querySelector('.snd-pk-body'), qi = body.querySelector('.snd-pk-q'); let tab = 'lib';
    const choose = src => { const ss = cur(); const pp = ss.profiles.find(x => x.id === p.id); pp.events = pp.events || {}; pp.events[e.key] = { ...(pp.events[e.key] || {}), on: true, src }; persist(ss, 'נבחר: ' + srcLabel(src, ss)); Object.assign(p, pp); m.close(); done(); };
    const row = (src, label, sub) => { const r = el('div', 'snd-pk-row' + (src === cur0 ? ' on' : '')); r.dataset.src = src; r.innerHTML = `<button class="snd-pk-play" title="השמע">▶</button><span class="snd-pk-l">${esc(label)}${sub ? `<small>${esc(sub)}</small>` : ''}</span><button class="btn-ghost snd-pk-ch">בחר</button>`; r.querySelector('.snd-pk-play').onclick = () => App.sound.preview(src, { key: e.key, voice: p.voice }); r.querySelector('.snd-pk-ch').onclick = () => choose(src); return r; };
    function paint() {
      const q = qi.value.trim().toLowerCase(); pb.innerHTML = '';
      if (tab === 'lib') {
        if (e.alt && !q) { const r0 = LIB.byId[e.alt.slice(4)]; if (r0) { pb.appendChild(el('div', 'snd-pk-cat', '⭐ מומלץ לאירוע הזה')); pb.appendChild(row(e.alt, r0.name)); } }
        for (const c of LIB.cats) { const items = LIB.list.filter(x => x.cat === c && (!q || (x.name + ' ' + x.tags + ' ' + c).toLowerCase().includes(q))); if (!items.length) continue; pb.appendChild(el('div', 'snd-pk-cat', esc(c))); for (const x of items) pb.appendChild(row('syn:' + x.id, x.name)); }
      } else if (tab === 'voice') {
        pb.appendChild(el('div', 'snd-pk-cat', 'המשפט של האירוע: "' + esc(stripN(e.phrase)) + '"'));
        pb.appendChild(row('voice', '🗣 בקול של הפרופיל (' + voiceName(p.voice) + ')', 'מתחלף אוטומטית כשמחליפים קול לפרופיל'));
        for (const v of VOICES) pb.appendChild(row('voice:' + v.id, voiceName(v.id), stripN(e.phrase)));
        pb.appendChild(el('div', 'snd-pk-cat', 'או משפט אחר'));
        const phrases = [...Object.entries(CAT.EXTRA_PHRASES), ...CAT.EVENTS.map(x => [x.key, x.phrase])].filter(([k, ph]) => k !== e.key && (!q || stripN(ph).includes(q)));
        for (const [k, ph] of phrases.slice(0, 120)) pb.appendChild(row('phrase:' + p.voice + ':' + k, '"' + stripN(ph) + '"', voiceName(p.voice)));
      } else {
        if (!s.custom.length) pb.appendChild(el('div', 'ag-dim', 'עוד אין צלילים שלך — העלה או הקלט באזור "הצלילים שלי" בהגדרות.'));
        for (const c of s.custom.filter(c => !q || c.name.toLowerCase().includes(q))) pb.appendChild(row('custom:' + c.id, '🎙 ' + c.name, fmtS((c.end != null ? c.end : c.dur) - (c.start || 0))));
      }
      if (!pb.children.length) pb.appendChild(el('div', 'ag-empty', 'לא נמצא צליל שמתאים לחיפוש'));
    }
    body.querySelectorAll('.snd-tabs .seg-btn').forEach(b => b.onclick = () => { tab = b.dataset.t; body.querySelectorAll('.snd-tabs .seg-btn').forEach(x => x.classList.toggle('active', x === b)); paint(); });
    qi.oninput = paint; paint(); setTimeout(() => qi.focus(), 50);
  }

  // ---------- עורך חיתוך מדויק ----------
  async function openTrimmer(c, done) {
    const body = el('div', 'snd-trim');
    body.innerHTML = `<div class="snd-row"><span class="snd-lbl">שם</span><input class="text-input snd-tr-name" maxlength="60"></div>
      <div class="snd-tr-wave"><canvas></canvas><div class="snd-tr-sel"></div><div class="snd-tr-h a" title="גרור — תחילת הצליל"></div><div class="snd-tr-h b" title="גרור — סוף הצליל"></div><div class="snd-tr-ph"></div></div>
      <div class="snd-row snd-tr-nums"><label>התחלה <input type="number" step="0.01" min="0" class="text-input snd-tr-a" dir="ltr"></label><label>סוף <input type="number" step="0.01" min="0" class="text-input snd-tr-b" dir="ltr"></label><b class="snd-tr-len"></b><small class="ag-dim snd-tr-tot"></small></div>
      <div class="snd-row"><button class="btn-ghost snd-tr-play">▶ השמע את החיתוך</button><button class="btn-ghost snd-tr-auto">✨ חיתוך אוטומטי של השקט</button><button class="btn-ghost snd-tr-all">↔ כל הקובץ</button><label class="snd-vol"><span>עוצמה</span><input type="range" min="10" max="300" class="snd-tr-g"><b class="snd-tr-gv"></b></label></div>
      <div class="confirm-bar"><button class="btn-ghost snd-tr-cancel">ביטול</button><button class="btn-primary snd-tr-save">שמור</button></div>`;
    const m = App.modal({ title: '✂️ חיתוך צליל', body, cls: 'snd-trim-modal' });
    const q = x => body.querySelector(x);
    q('.snd-tr-name').value = c.name;
    let buf; try { const ab = await (await fetch('/api/sounds/custom/' + c.id + '/file')).arrayBuffer(); buf = await new OfflineAudioContext(1, 1, 44100).decodeAudioData(ab); } catch (e) { App.toast('❌ ' + e.message); m.close(); return; }
    const D = buf.duration; let a = c.start || 0, b = c.end != null ? c.end : D, g = c.gain || 1;
    const wave = q('.snd-tr-wave'), cv = wave.querySelector('canvas');
    const draw = () => {
      const W = cv.width = wave.clientWidth * devicePixelRatio, H = cv.height = wave.clientHeight * devicePixelRatio; const x = cv.getContext('2d'); const d = buf.getChannelData(0);
      x.clearRect(0, 0, W, H); x.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--accent') || '#d97757';
      const step = d.length / W; for (let i = 0; i < W; i++) { let mx = 0; for (let j = Math.floor(i * step); j < Math.floor((i + 1) * step); j++) mx = Math.max(mx, Math.abs(d[j] || 0)); const h = Math.max(1, mx * H * 0.95); x.fillRect(i, (H - h) / 2, 1, h); }
    };
    const paint = () => {
      a = Math.max(0, Math.min(a, D)); b = Math.max(a + 0.02, Math.min(b, D));
      const w = wave.clientWidth; const xa = a / D * w, xb = b / D * w;
      q('.snd-tr-h.a').style.left = xa + 'px'; q('.snd-tr-h.b').style.left = xb + 'px'; q('.snd-tr-sel').style.left = xa + 'px'; q('.snd-tr-sel').style.width = (xb - xa) + 'px';
      q('.snd-tr-a').value = a.toFixed(2); q('.snd-tr-b').value = b.toFixed(2); q('.snd-tr-len').textContent = 'אורך: ' + (b - a).toFixed(2) + ' שנ\''; q('.snd-tr-tot').textContent = 'כל הקובץ: ' + D.toFixed(2) + ' שנ\'';
      q('.snd-tr-g').value = Math.round(g * 100); q('.snd-tr-gv').textContent = Math.round(g * 100) + '%';
    };
    const drag = (h, set) => { h.onpointerdown = ev => { h.setPointerCapture(ev.pointerId); const r = wave.getBoundingClientRect(); const mv = e2 => { set(Math.max(0, Math.min(1, (e2.clientX - r.left) / r.width)) * D); paint(); }; h.onpointermove = mv; h.onpointerup = () => { h.onpointermove = null; }; }; };
    drag(q('.snd-tr-h.a'), v => (a = Math.min(v, b - 0.02))); drag(q('.snd-tr-h.b'), v => (b = Math.max(v, a + 0.02)));
    q('.snd-tr-a').onchange = () => { a = +q('.snd-tr-a').value || 0; paint(); }; q('.snd-tr-b').onchange = () => { b = +q('.snd-tr-b').value || D; paint(); };
    q('.snd-tr-g').oninput = () => { g = q('.snd-tr-g').value / 100; paint(); };
    q('.snd-tr-all').onclick = () => { a = 0; b = D; paint(); };
    q('.snd-tr-auto').onclick = () => { const d = buf.getChannelData(0), sr = buf.sampleRate; let pk = 0; for (const v of d) pk = Math.max(pk, Math.abs(v)); const thr = Math.max(0.004, pk * 0.04); const i0 = Math.floor(a * sr), i1 = Math.floor(b * sr); let s0 = i0, s1 = i1 - 1; while (s0 < i1 && Math.abs(d[s0]) < thr) s0++; while (s1 > s0 && Math.abs(d[s1]) < thr) s1--; a = Math.max(0, s0 / sr - 0.01); b = Math.min(D, s1 / sr + 0.03); paint(); App.toast('✨ השקט בקצוות נחתך', 1400); };
    q('.snd-tr-play').onclick = async () => { const s2 = App.sound.settings(); const it = s2.custom.find(x => x.id === c.id); const keep = it ? { ...it } : null; if (it) Object.assign(it, { start: a, end: b, gain: g }); await App.sound.preview('custom:' + c.id); if (it && keep) Object.assign(it, keep); };
    q('.snd-tr-cancel').onclick = () => m.close();
    q('.snd-tr-save').onclick = () => { c.name = q('.snd-tr-name').value.trim() || c.name; c.start = +a.toFixed(3); c.end = +b.toFixed(3); c.gain = +g.toFixed(2); m.close(); done(); };
    body._trim = { get: () => ({ a, b, g, D }), set: (na, nb) => { a = na; b = nb; paint(); } }; // לבדיקה
    requestAnimationFrame(() => { draw(); paint(); });
  }

  // ---------- הקלטה מהמיקרופון ----------
  async function recordDialog(onDone) {
    let stream; try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: true } }); } catch (e) { App.toast('❌ אין גישה למיקרופון: ' + e.message, 5000); return; }
    const body = el('div', 'snd-recd'); body.innerHTML = `<div class="snd-rec-dot"></div><b class="snd-rec-t">00:00</b><p class="ag-dim">מקליט… אמור את מה שאתה רוצה (למשל "בש"). אחר כך תוכל לחתוך בדיוק.</p><div class="confirm-bar"><button class="btn-ghost snd-rec-cancel">ביטול</button><button class="btn-primary snd-rec-stop">⏹ סיים הקלטה</button></div>`;
    const m = App.modal({ title: '🎙 הקלטה', body, cls: 'small', onClose: () => stream.getTracks().forEach(t => t.stop()) });
    const rec = new MediaRecorder(stream); const parts = []; rec.ondataavailable = e => e.data.size && parts.push(e.data); let cancel = false;
    rec.onstop = () => { stream.getTracks().forEach(t => t.stop()); m.close(); if (!cancel && parts.length) onDone(new Blob(parts, { type: rec.mimeType || 'audio/webm' })); };
    rec.start(); const t0 = Date.now(); const iv = setInterval(() => { if (!document.body.contains(body)) return clearInterval(iv); const s = Math.floor((Date.now() - t0) / 1000); body.querySelector('.snd-rec-t').textContent = String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); }, 250);
    body.querySelector('.snd-rec-stop').onclick = () => rec.stop(); body.querySelector('.snd-rec-cancel').onclick = () => { cancel = true; rec.stop(); };
  }

  App.soundsUI = { render, openPicker, openTrimmer, srcLabel };
})();
