// ============================================================
//  core.js — תשתית משותפת לכל חלקי הממשק (App namespace)
//  נטען ראשון. כל מודול (chat.js, explorer.js, agents.js, settings.js, ...) משתמש ב-App.*
//  חוזה מלא: docs/UI-CONTRACT.md
// ============================================================
(function () {
  const App = (window.App = window.App || {});
  const $ = id => document.getElementById(id);
  App.$ = $;
  App.state = { config: null, models: [], system: null, account: null };

  // ---------- אירועים פנימיים ----------
  const handlers = {};
  App.on = (ev, fn) => { (handlers[ev] = handlers[ev] || []).push(fn); return () => App.off(ev, fn); };
  App.off = (ev, fn) => { handlers[ev] = (handlers[ev] || []).filter(f => f !== fn); };
  App.emit = (ev, data) => { for (const f of [...(handlers[ev] || [])]) { try { f(data); } catch (e) { console.error('[App.emit ' + ev + ']', e); } } };
  // מריץ fn אחרי שהליבה והצ'אט מוכנים (מודולים משתמשים בזה כדי להירשם)
  const readyFns = [];
  App.ready = fn => { if (App._isReady) fn(); else readyFns.push(fn); };
  App._fireReady = () => { App._isReady = true; for (const f of readyFns.splice(0)) { try { f(); } catch (e) { console.error('[App.ready]', e); } } };

  // ---------- HTTP ----------
  App.api = async function api(path, opts = {}) {
    const res = await fetch(path, {
      method: opts.method || (opts.body ? 'POST' : 'GET'),
      headers: opts.body ? { 'content-type': 'application/json' } : {},
      body: opts.body ? JSON.stringify(opts.body) : undefined,
      cache: 'no-store'
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) { const e = new Error(data.error || 'HTTP ' + res.status); e.status = res.status; e.data = data; throw e; }
    return data;
  };

  // ---------- DOM ----------
  App.el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  App.esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  // צבעים: "#rrggbb" / "rgb(…)" → [r,g,b]; בהירות יחסית (WCAG); יחס ניגודיות
  App.rgbOf = s => { s = String(s || '').trim(); let m = s.match(/^#([0-9a-f]{6})$/i); if (m) { const n = parseInt(m[1], 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; } m = s.match(/rgba?\(([^)]+)\)/); return m ? m[1].split(/[\s,\/]+/).filter(Boolean).slice(0, 3).map(Number) : null; };
  App.lum = c => { const f = v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }; return .2126 * f(c[0]) + .7152 * f(c[1]) + .0722 * f(c[2]); };
  App.contrast = (a, b) => { const x = App.lum(a), y = App.lum(b); return (Math.max(x, y) + .05) / (Math.min(x, y) + .05); };
  // צבע טקסט שנקרא על רקע נתון: הכהה או הבהיר — מה שנותן ניגודיות גבוהה יותר
  App.textOn = hex => { const c = App.rgbOf(hex); if (!c) return null; return App.contrast(c, [255, 255, 255]) >= App.contrast(c, [20, 20, 19]) ? '#ffffff' : '#141413'; };
  window.escapeHtml = window.escapeHtml || App.esc; // markdown.js משתמש בזה
  App.toast = function toast(text, ms = 2500) {
    const t = $('toast');
    t.textContent = text; t.hidden = false;
    clearTimeout(App.toast._t); App.toast._t = setTimeout(() => (t.hidden = true), ms);
  };
  App.copyText = async function copyText(text, okMsg = 'הועתק') {
    try { await navigator.clipboard.writeText(text); }
    catch { const ta = App.el('textarea'); ta.value = text; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); } catch { } ta.remove(); }
    if (okMsg) App.toast(okMsg);
  };

  // ---------- פורמט ----------
  const pad = n => String(n).padStart(2, '0');
  App.fmt = {
    pad,
    num: n => (n >= 1e6 ? (n / 1e6).toFixed(2) + 'M' : n >= 1e3 ? (n / 1e3).toFixed(1) + 'K' : String(Math.round(n || 0))),
    money: n => { n = Number(n) || 0; return '$' + (n < 10 ? n.toFixed(3) : n.toFixed(2)); },
    // אחוז מהמנוי: קטן מאוד = "<0.01%"
    pct: p => { p = Number(p) || 0; return p <= 0 ? '0%' : p < 0.001 ? '<0.001%' : (p < 0.01 ? p.toFixed(3) : p < 1 ? p.toFixed(2) : p < 10 ? p.toFixed(1) : Math.round(p)) + '%'; },
    // שימוש של הודעה / שיחה / מחקר: טוקנים + (מנוי: אחוז מהחלון השבועי / 5 שעות · API: עלות בדולר)
    use(u, opts) {
      if (!u) return { text: '', title: '' };
      const sub = (App.state.config || {}).accountMode === 'subscription', f = App.fmt;
      const tok = (u.input || 0) + (u.output || 0);
      const parts = [`🔢 ${f.num(tok)} טוקנים`];
      const P = u.pct || {};
      if (sub) { if (P.seven_day != null) parts.push(`${f.pct(P.seven_day)} מהשבועי`); if (P.five_hour != null) parts.push(`${f.pct(P.five_hour)} מ-5 השעות`); }
      else if (u.costUSD != null) parts.push(f.money(u.costUSD));
      const title = [`קלט: ${(u.input || 0).toLocaleString('en-US')} טוקנים (כולל מטמון)`, `פלט: ${(u.output || 0).toLocaleString('en-US')} טוקנים`]
        .concat(u.calls ? [`${u.calls} קריאות למודל`] : [], u.agents ? [`כולל ${u.agents} סוכנים / מחקרים שההודעה הפעילה`] : [], (u.models && u.models.length) ? ['מודל: ' + u.models.map(m => App.modelLabel ? App.modelLabel(m) : m).join(', ')] : [])
        .concat(sub ? (P.seven_day != null || P.five_hour != null ? ['האחוז = העלות בתעריף API ÷ כמה עולה 1% מהחלון בחשבון שלך (נמדד מכל השימוש מאז תחילת החלון)'] : ['האחוז יופיע אחרי שמד המנוי יכויל (עד דקה מהפעלת האפליקציה)']) : []).join('\n');
      return { text: parts.join(' · '), title, sub };
    },
    // שעה לפי הגדרות הצ'אט: 24 שעות (14:05:09) או 12 שעות (2:05:09 PM), עם / בלי שניות. secs=false מכריח בלי שניות
    time: (ts, secs) => {
      const d = new Date(ts); if (isNaN(d)) return ''; const u = App.chatUi ? App.chatUi() : {};
      const showS = secs === false ? false : u.seconds !== false; const h = d.getHours();
      const s = showS ? ':' + pad(d.getSeconds()) : '';
      // 12 שעות: השעה עטופה בבידוד כיווני (LRI…PDI) — אחרת בממשק מימין לשמאל "6:13 PM" מוצג "PM 6:13"
      return u.clock === '12' ? `⁦${h % 12 || 12}:${pad(d.getMinutes())}${s} ${h < 12 ? 'AM' : 'PM'}⁩` : `${pad(h)}:${pad(d.getMinutes())}${s}`;
    },
    hm: ts => App.fmt.time(ts, false), // שעה ודקה בלבד (רשימות, תזמונים)
    day: ts => new Date(ts).toLocaleDateString('he-IL', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }),
    dateTime: ts => { const d = new Date(ts); if (isNaN(d)) return ''; return `${pad(d.getDate())}/${pad(d.getMonth() + 1)} ${App.fmt.hm(ts)}`; },
    fullDateTime: ts => { const d = new Date(ts); if (isNaN(d)) return ''; return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${App.fmt.time(ts)}`; },
    clock: ms => { const s = Math.floor(ms / 1000); return `${pad(Math.floor(s / 60))}:${pad(s % 60)}`; },
    dur(ms) {
      const s = Math.max(0, Math.round(ms / 1000));
      if (s < 60) return s + " שנ'";
      const m = Math.floor(s / 60);
      if (m < 60) return `${m}:${pad(s % 60)} דק'`;
      return `${Math.floor(m / 60)}:${pad(m % 60)}:${pad(s % 60)} שע'`;
    },
    until(ts) { // "בעוד 3 שעות" / "בעוד 2 ימים"
      const ms = ts - Date.now();
      if (ms <= 0) return 'עכשיו';
      const m = Math.round(ms / 60000);
      if (m < 60) return `בעוד ${m} דק'`;
      const h = Math.round(m / 60);
      if (h < 48) return `בעוד ${h} שעות`;
      return `בעוד ${Math.round(h / 24)} ימים`;
    },
    size: n => (n == null ? '' : n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : n < 1073741824 ? (n / 1048576).toFixed(1) + ' MB' : (n / 1073741824).toFixed(2) + ' GB')
  };
  App.baseName = p => String(p || '').replace(/[\\/]+$/, '').split(/[\\/]/).pop() || String(p || '');

  // ---------- חלון קופץ (modal) ----------
  // App.modal({title, body(HTMLElement|string), wide, onClose}) → { el, body, head, close() }
  App.modal = function modal(o = {}) {
    const back = App.el('div', 'modal-backdrop');
    const box = App.el('div', 'modal' + (o.wide ? ' wide' : '') + (o.cls ? ' ' + o.cls : ''));
    const head = App.el('div', 'modal-head');
    const h = App.el('h2'); h.textContent = o.title || '';
    const x = App.el('button', 'icon-btn', '✕'); x.title = 'סגור (Esc)';
    head.append(h, x);
    const body = App.el('div', 'modal-body');
    if (typeof o.body === 'string') body.innerHTML = o.body; else if (o.body) body.appendChild(o.body);
    box.append(head, body);
    back.appendChild(box);
    (App.$('overlays') || document.body).appendChild(back);
    const api = {
      el: back, box, head, body, titleEl: h,
      close() { if (back.isConnected) { back.remove(); document.removeEventListener('keydown', onKey, true); if (o.onClose) o.onClose(); } },
      setTitle(t) { h.textContent = t; }
    };
    const onKey = e => { if (e.key === 'Escape' && !e.defaultPrevented) { const all = document.querySelectorAll('.modal-backdrop'); if (all[all.length - 1] === back) { e.preventDefault(); e.stopPropagation(); api.close(); } } };
    document.addEventListener('keydown', onKey, true);
    x.onclick = () => api.close();
    back.addEventListener('mousedown', e => { if (e.target === back && !o.sticky) api.close(); });
    return api;
  };
  // אישור בסגנון המערכת (במקום confirm של הדפדפן). מחזיר Promise<boolean>
  App.confirm = function confirmDlg(message, { okText = 'אישור', cancelText = 'ביטול', danger = false, title = 'לאשר?' } = {}) {
    return new Promise(res => {
      let done = false;
      const body = App.el('div', 'confirm-body');
      const p = App.el('p'); p.textContent = message;
      const bar = App.el('div', 'confirm-bar');
      const ok = App.el('button', danger ? 'btn-danger' : 'btn-primary'); ok.textContent = okText;
      const no = App.el('button', 'btn-ghost'); no.textContent = cancelText;
      bar.append(no, ok); body.append(p, bar);
      const m = App.modal({ title, body, cls: 'small', onClose: () => { if (!done) { done = true; res(false); } } });
      ok.onclick = () => { done = true; m.close(); res(true); };
      no.onclick = () => m.close();
      ok.focus();
    });
  };
  // בקשת טקסט (במקום prompt). מחזיר Promise<string|null>
  App.prompt = function promptDlg(message, value = '', { okText = 'אישור', title = '', placeholder = '' } = {}) {
    return new Promise(res => {
      let done = false;
      const body = App.el('div', 'confirm-body');
      const p = App.el('p'); p.textContent = message;
      const inp = App.el('input', 'text-input'); inp.value = value; inp.placeholder = placeholder;
      const bar = App.el('div', 'confirm-bar');
      const ok = App.el('button', 'btn-primary'); ok.textContent = okText;
      const no = App.el('button', 'btn-ghost'); no.textContent = 'ביטול';
      bar.append(no, ok); body.append(p, inp, bar);
      const m = App.modal({ title: title || message, body, cls: 'small', onClose: () => { if (!done) { done = true; res(null); } } });
      p.hidden = !title;
      const submit = () => { done = true; const v = inp.value; m.close(); res(v); };
      ok.onclick = submit; no.onclick = () => m.close();
      inp.onkeydown = e => { if (e.key === 'Enter') submit(); };
      setTimeout(() => { inp.focus(); inp.select(); }, 30);
    });
  };

  // ---------- תפריט הקשר (קליק ימני) ----------
  // App.menu(x, y, [{label, icon, onClick, danger, disabled, sep:true}])
  let openMenu = null;
  function buildMenu(items) {
    const m = App.el('div', 'ctx-menu');
    for (const it of items.filter(Boolean)) {
      if (it.sep) { m.appendChild(App.el('div', 'ctx-sep')); continue; }
      if (it.el) { m.appendChild(it.el); continue; } // רכיב מותאם (למשל פס עוצמה) — לחיצה בו לא סוגרת את התפריט
      const b = App.el('button', 'ctx-item' + (it.danger ? ' danger' : '') + (it.sub ? ' ctx-2l' : ''));
      b.innerHTML = `<span class="ctx-ic">${it.icon || ''}</span><span class="ctx-lb"></span>`;
      const lb = b.querySelector('.ctx-lb');
      if (it.name != null || it.sub) { // שתי שורות: "תווית + שם (בצבע)" ומתחת שורת משנה (נתיב)
        const l1 = App.el('span', 'ctx-l1'); l1.appendChild(document.createTextNode(it.label || ''));
        if (it.name != null) { const nm = App.el('span', 'ctx-name'); nm.textContent = it.name; if (it.color) { nm.style.color = it.color; nm.dataset.color = it.color; } l1.appendChild(nm); }
        lb.appendChild(l1);
        if (it.sub) { const s = App.el('span', 'ctx-sub'); s.textContent = it.sub; s.title = it.sub; lb.appendChild(s); }
      } else lb.textContent = it.label;
      if (it.hint) b.appendChild(App.el('span', 'ctx-hint', App.esc(it.hint)));
      b.disabled = !!it.disabled;
      if (it.children) { // תת-תפריט: נפתח בריחוף (או בלחיצה / מגע) לצד הפריט
        b.classList.add('ctx-parent'); b.appendChild(App.el('span', 'ctx-arrow', '‹'));
        const open = () => { if (b.disabled) return; if (m._subOf === b) return; closeSub(m); const kids = typeof it.children === 'function' ? it.children() : it.children; const sm = buildMenu(kids && kids.length ? kids : [{ label: it.empty || 'אין אפשרויות', disabled: true }], true); sm.classList.add('ctx-submenu'); m._sub = sm; m._subOf = b; b.classList.add('open'); document.body.appendChild(sm); placeSub(sm, b); };
        b.onmouseenter = open; b.onclick = e => { e.stopPropagation(); open(); };
      } else {
        b.onmouseenter = () => closeSub(m);
        b.onclick = e => { e.stopPropagation(); App.menuClose(); if (it.onClick) it.onClick(); };
      }
      m.appendChild(b);
    }
    return m;
  }
  function closeSub(m) { if (m && m._sub) { closeSub(m._sub); m._sub.remove(); if (m._subOf) m._subOf.classList.remove('open'); m._sub = null; m._subOf = null; } }
  function placeSub(sm, b) { // RTL: התת-תפריט נפתח משמאל לפריט; אין מקום → מימין
    const r = b.getBoundingClientRect(), s = sm.getBoundingClientRect();
    let x = r.left - s.width + 2; if (x < 4) x = Math.min(r.right - 2, innerWidth - s.width - 4);
    sm.style.left = Math.max(4, x) + 'px';
    sm.style.top = Math.max(4, Math.min(r.top - 5, innerHeight - s.height - 4)) + 'px';
  }
  App.menu = function menu(x, y, items) {
    App.menuClose();
    const m = buildMenu(items);
    document.body.appendChild(m);
    // שם בצבע שלא נקרא על רקע התפריט (למשל שחור על כהה) — מקבל מתחתיו רקע מנוגד קטן, והצבע עצמו נשאר
    for (const nm of m.querySelectorAll('.ctx-name[data-color]')) { try { const bg = App.rgbOf(getComputedStyle(m).backgroundColor), fg = App.rgbOf(getComputedStyle(nm).color); if (bg && fg && App.contrast(bg, fg) < 3) { const D = [28, 27, 25], Lt = [244, 242, 236]; nm.classList.add('chip'); nm.style.background = App.contrast(fg, D) >= App.contrast(fg, Lt) ? '#1c1b19' : '#f4f2ec'; } } catch { } }
    const r = m.getBoundingClientRect();
    m.style.left = Math.max(4, Math.min(x, innerWidth - r.width - 4)) + 'px';
    m.style.top = Math.max(4, Math.min(y, innerHeight - r.height - 4)) + 'px';
    openMenu = m;
    return m;
  };
  App.menuClose = () => { if (openMenu) { closeSub(openMenu); openMenu.remove(); openMenu = null; } };
  document.addEventListener('mousedown', e => { if (openMenu && !e.target.closest('.ctx-menu')) App.menuClose(); }, true);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') App.menuClose(); });
  window.addEventListener('blur', () => App.menuClose());

  // ---------- הגדלת תמונה (lightbox) + העתקה ----------
  // App.lightbox(src, {name}) — לחיצה על תמונה בצ'אט פותחת אותה בגדול, עם העתקה / שמירה / סגירה
  App.lightbox = function lightbox(src, { name = 'image' } = {}) {
    const lb = App.el('div', 'lightbox');
    const img = App.el('img'); img.src = src; img.alt = name;
    // תמונה קטנה מוגדלת כך שתמלא את רוב המסך (עד פי 4 מהגודל המקורי); גדולה — מותאמת למסך
    img.addEventListener('load', () => {
      const nw = img.naturalWidth || 1, nh = img.naturalHeight || 1;
      const fit = Math.min((innerWidth * 0.86) / nw, (innerHeight * 0.78) / nh, 4);
      img.style.maxWidth = 'none'; img.style.maxHeight = 'none'; img.style.width = Math.round(nw * fit) + 'px'; img.style.height = Math.round(nh * fit) + 'px';
    });
    const bar = App.el('div', 'lb-bar');
    const mk = (t, title, fn) => { const b = App.el('button', 'lb-btn', t); b.title = title; b.onclick = e => { e.stopPropagation(); fn(b); }; return b; };
    const zoomLbl = App.el('span', 'lb-zoom', '100%');
    let scale = 1, tx = 0, ty = 0;
    const apply = () => { img.style.transform = `translate(${tx}px,${ty}px) scale(${scale})`; zoomLbl.textContent = Math.round(scale * 100) + '%'; };
    const copy = mk('📋 העתק תמונה', 'העתק את התמונה ללוח (Ctrl+C)', async b => {
      try {
        const blob = await (await fetch(src)).blob();
        let out = blob;
        if (blob.type !== 'image/png') { // הלוח תומך ב-PNG בלבד: ממירים דרך canvas
          const bmp = await createImageBitmap(blob); const c = document.createElement('canvas'); c.width = bmp.width; c.height = bmp.height;
          c.getContext('2d').drawImage(bmp, 0, 0); out = await new Promise(r => c.toBlob(r, 'image/png'));
        }
        await navigator.clipboard.write([new ClipboardItem({ 'image/png': out })]);
        b.textContent = '✅ הועתק'; App.toast('התמונה הועתקה ללוח'); setTimeout(() => (b.textContent = '📋 העתק תמונה'), 1600);
      } catch (e) { App.toast('ההעתקה נכשלה: ' + e.message, 4000); }
    });
    const save = mk('💾 שמור', 'שמור את התמונה כקובץ', () => { const a = App.el('a'); a.href = src; a.download = name; document.body.appendChild(a); a.click(); a.remove(); });
    const zin = mk('＋', 'הגדל', () => { scale = Math.min(8, scale * 1.25); apply(); });
    const zout = mk('－', 'הקטן', () => { scale = Math.max(.2, scale / 1.25); apply(); });
    const reset = mk('⟲', 'איפוס', () => { scale = 1; tx = ty = 0; apply(); });
    const close = mk('✕', 'סגור (Esc)', () => closeLb());
    bar.append(copy, save, zout, zoomLbl, zin, reset, close);
    lb.append(img, bar);
    document.body.appendChild(lb);
    const closeLb = () => { lb.remove(); document.removeEventListener('keydown', onKey, true); };
    const onKey = e => {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closeLb(); }
      else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'c') { e.preventDefault(); copy.click(); }
      else if (e.key === '+' || e.key === '=') zin.click(); else if (e.key === '-') zout.click(); else if (e.key === '0') reset.click();
    };
    document.addEventListener('keydown', onKey, true);
    lb.addEventListener('click', e => { if (e.target === lb) closeLb(); });
    lb.addEventListener('wheel', e => { e.preventDefault(); scale = Math.max(.2, Math.min(8, scale * (e.deltaY < 0 ? 1.12 : 1 / 1.12))); apply(); }, { passive: false });
    let drag = null;
    img.addEventListener('mousedown', e => { e.preventDefault(); drag = { x: e.clientX - tx, y: e.clientY - ty }; img.classList.add('grabbing'); });
    window.addEventListener('mousemove', e => { if (drag) { tx = e.clientX - drag.x; ty = e.clientY - drag.y; apply(); } });
    window.addEventListener('mouseup', () => { drag = null; img.classList.remove('grabbing'); });
    img.addEventListener('dblclick', () => { scale = scale === 1 ? 2 : 1; tx = ty = 0; apply(); });
    return { close: closeLb };
  };
  // קליק על כל תמונה בתוך הצ'אט (data: / blob: / http) — מגדיל; קליק ימני — תפריט העתקה
  document.addEventListener('click', e => {
    const img = e.target.closest && e.target.closest('.msg img, .att-thumbs img, .att-chip img, img.zoomable');
    if (!img || img.closest('.lightbox')) return;
    e.preventDefault();
    App.lightbox(img.currentSrc || img.src, { name: img.alt || 'image.png' });
  });
  document.addEventListener('contextmenu', e => {
    const img = e.target.closest && e.target.closest('.msg img, .att-thumbs img, img.zoomable');
    if (!img) return;
    e.preventDefault();
    const src = img.currentSrc || img.src;
    App.menu(e.clientX, e.clientY, [
      { icon: '🔍', label: 'הגדל', onClick: () => App.lightbox(src, { name: img.alt || 'image.png' }) },
      { icon: '📋', label: 'העתק תמונה', onClick: async () => {
        try {
          const blob = await (await fetch(src)).blob(); let out = blob;
          if (blob.type !== 'image/png') { const bmp = await createImageBitmap(blob); const c = document.createElement('canvas'); c.width = bmp.width; c.height = bmp.height; c.getContext('2d').drawImage(bmp, 0, 0); out = await new Promise(r => c.toBlob(r, 'image/png')); }
          await navigator.clipboard.write([new ClipboardItem({ 'image/png': out })]); App.toast('התמונה הועתקה ללוח');
        } catch (er) { App.toast('ההעתקה נכשלה: ' + er.message, 4000); }
      } }
    ]);
  });

  // ---------- גרירה ושחרור (drag & drop) ----------
  // מודולים רושמים handler: App.dropHandlers.push({ priority, name, handle: async (dt, ctx) => true אם טיפל }).
  // main.js מפעיל את כולם לפי סדר priority (קטן = קודם) עד שאחד מחזיר true. ctx = { target: Element }.
  // כך תיקייה שנגררת מ-Windows (explorer.js, priority 10) הופכת לתיקיית העבודה, וקבצים נצמדים לצ'אט (chat.js, priority 50).
  App.dropHandlers = [];
  App.registerDrop = h => { App.dropHandlers.push(h); App.dropHandlers.sort((a, b) => (a.priority || 50) - (b.priority || 50)); };
  App.dispatchDrop = async function (dt, ctx = {}) {
    for (const h of App.dropHandlers) {
      try { if (await h.handle(dt, ctx)) return h.name || true; } catch (e) { console.error('[drop:' + (h.name || '?') + ']', e); App.toast('שגיאה בגרירה: ' + e.message, 4000); }
    }
    return false;
  };
  // מידע מוקדם על מה שנגרר (סינכרוני, בזמן dragenter/dragover): האם יש תיקייה? אפשר להציג רמז בשכבת הגרירה
  App.dragInfo = function (dt) {
    const info = { hasFiles: false, hasDir: false, count: 0, internalPath: '' };
    if (!dt) return info;
    info.hasFiles = [...(dt.types || [])].includes('Files');
    if (dt.types && [...dt.types].includes('application/x-claude-path')) info.internalPath = '1';
    try { for (const it of dt.items || []) { info.count++; const en = it.webkitGetAsEntry && it.webkitGetAsEntry(); if (en && en.isDirectory) info.hasDir = true; } } catch { }
    return info;
  };

  // ---------- שיתוף נתונים ----------
  // עובדים על מחשב אחר: ההגדרות שלו (מודל, חשבון, הוראות…) — אבל הצלילים תמיד של המחשב שלך (הרמקולים שלך, ההגדרות לכל מחשב)
  const remote = () => window.MESH && MESH.remote;
  const localCfg = async (method, body) => { const r = await fetch('/api/config', { method, headers: { 'content-type': 'application/json', 'x-mesh-local': '1' }, body: body ? JSON.stringify(body) : undefined, cache: 'no-store' }); return r.json(); };
  // ---------- הגדרות הצ'אט (הגדרות → 💬 צ'אט): שעה, גופנים, רוחב, כלים, סיכום, שאלות ותשובות, Enter ----------
  const CHAT_UI_DEFAULTS = { clock: '24', seconds: true, font: '', size: 15, lineHeight: 'normal', width: 'normal', codeFont: '', tools: 'normal', footer: true, qaBox: true, summary: 'none', enter: 'enter' };
  App.chatUiDefaults = CHAT_UI_DEFAULTS;
  App.chatUi = () => ({ ...CHAT_UI_DEFAULTS, ...(((App.state || {}).config || {}).chatUi || {}) });
  const WIDTHS = { narrow: '700px', normal: '820px', wide: '1080px', full: '100%' }, LINE_H = { tight: '1.5', normal: '1.7', airy: '1.95' };
  const fontStack = (f, mono) => (f ? `"${String(f).replace(/["\\;{}]/g, '')}", ` : '') + (mono ? '"Cascadia Code", Consolas, "Courier New", monospace' : 'var(--font)');
  let lastUi = '';
  App.applyChatUi = (u = App.chatUi()) => {
    const r = document.documentElement, s = r.style;
    s.setProperty('--chat-font', fontStack(u.font, false)); s.setProperty('--code-font', fontStack(u.codeFont, true)); if (u.codeFont) s.setProperty('--mono', fontStack(u.codeFont, true)); else s.removeProperty('--mono'); // כל הקוד והנתיבים באפליקציה
    s.setProperty('--chat-size', Math.max(12, Math.min(22, Number(u.size) || 15)) + 'px');
    s.setProperty('--chat-lh', LINE_H[u.lineHeight] || LINE_H.normal); s.setProperty('--chat-maxw', WIDTHS[u.width] || WIDTHS.normal);
    r.classList.toggle('tools-compact', u.tools === 'compact'); r.classList.toggle('no-turn-footer', u.footer === false);
    r.classList.toggle('sum-bubble', u.summary === 'bubble'); r.classList.toggle('sum-highlight', u.summary === 'highlight');
    r.classList.toggle('qa-off', u.qaBox === false); r.classList.toggle('hide-thinking', ((App.state || {}).config || {}).showThinking === false);
    // שעה / שניות / תיבת שאלות-ותשובות השתנו: כל מה שכבר מוצג נבנה מחדש בפורמט החדש
    const sig = [u.clock, u.seconds, u.qaBox].join('|');
    if (lastUi && sig !== lastUi) App.emit('chatui:changed', u);
    lastUi = sig;
  };
  App.on('config:changed', () => App.applyChatUi());

  // העדפות תצוגה שתמיד של המחשב שלך (גם כשעובדים על מחשב אחר): צלילים + הגדרות הצ'אט
  const LOCAL_KEYS = ['sounds', 'chatUi'];
  App.loadConfig = async () => {
    const c = await App.api('/api/config');
    if (remote()) { try { const lc = await localCfg('GET'); for (const k of LOCAL_KEYS) c[k] = lc[k]; } catch { } }
    App.state.config = c; App.emit('config:changed', App.state.config); return App.state.config;
  };
  App.saveConfig = async patch => {
    if (remote() && patch && LOCAL_KEYS.some(k => k in patch)) {
      const loc = {}, rest = {}; for (const [k, v] of Object.entries(patch)) (LOCAL_KEYS.includes(k) ? loc : rest)[k] = v;
      await localCfg('POST', loc); App.state.config = { ...App.state.config, ...loc };
      if (!Object.keys(rest).length) { App.emit('config:changed', App.state.config); return App.state.config; }
      patch = rest;
    }
    const keep = {}; if (remote()) for (const k of LOCAL_KEYS) keep[k] = (App.state.config || {})[k];
    App.state.config = await App.api('/api/config', { method: 'POST', body: patch });
    Object.assign(App.state.config, keep);
    App.emit('config:changed', App.state.config); return App.state.config;
  };
  App.modelLabel = id => { const m = App.state.models.find(x => x.id === id); return m ? m.name : (id || ''); };
  App.isDesktop = () => !!(window.desktop && window.desktop.isDesktop);
  // נתיב אמיתי של קובץ/תיקייה שנגררו: ב-Electron דרך webUtils, בדפדפן אין (נחזיר '' ואז מחפשים לפי שם)
  App.pathForFile = file => { try { return (window.desktop && window.desktop.pathForFile && window.desktop.pathForFile(file)) || ''; } catch { return ''; } };
})();
