// ============================================================
//  chat.js — חלוניות צ'אט (כל טאב = שיחה עם הודעות + תיבת כתיבה משלה). שיחות רצות במקביל ברקע (השרת מריץ, הממשק מתחבר ומתנתק)
//  ה-DOM וה-CSS של ההודעות / החשיבה / כרטיסי הכלים / מסך הפתיחה זהים לגרסת הדפדפן המקורית (style.css לא שונה).
// ============================================================
(function () {
  const App = window.App, $ = App.$, el = App.el, esc = App.esc, fmt = App.fmt;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const ls = { get: k => { try { return localStorage.getItem(k); } catch { return null; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch { } }, del: k => { try { localStorage.removeItem(k); } catch { } } };
// הקלדה בממשק → השרת יודע שלא להחיל עדכון באמצע (HOT-UPDATE-PLAN 0.7). לכל היותר פעם ב-10 שניות
let uiActivityAt = 0;
function uiActivity() { const t = Date.now(); if (t - uiActivityAt < 10000) return; uiActivityAt = t; try { fetch('/api/ui/activity', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}', keepalive: true }).catch(() => { }); } catch { } }
  const SUGGESTIONS = [
    ['🔬 תוכיח שיש לך גישה למחשב', 'הוכח לי שיש לך גישה למחשב: תגיד לי את שם המחשב, שם המשתמש, כמה זיכרון RAM יש, כמה מקום פנוי בכונן C, ותיצור על שולחן העבודה קובץ בשם \'הוכחה מ-Claude.txt\' עם התאריך והשעה עכשיו. אחר כך תקרא את הקובץ ותראה לי שהוא קיים.'],
    ['📁 מה יש על שולחן העבודה?', 'מה יש על שולחן העבודה שלי? תסדר לי את זה בטבלה עם גדלים.'],
    ['📊 מה מעמיס על המחשב?', 'אילו תוכנות צורכות הכי הרבה זיכרון עכשיו? תראה את 10 הראשונות בטבלה.'],
    ['🐍 תכתוב ותריץ קוד', 'תכתוב לי סקריפט Python קטן שמדפיס את לוח הכפל, תשמור אותו על שולחן העבודה ותריץ אותו.']
  ];

  // ---------- תיאור הפעולות של Claude בעברית (גם כלי ה-API וגם הכלים של Claude Code) ----------
  const P = i => i.file_path || i.path || i.notebook_path || '';
  const TOOL_INFO = {
    run_command: { icon: '⚡', label: 'מריץ פקודה', arg: i => i.command },
    Bash: { icon: '⚡', label: 'מריץ פקודה', arg: i => i.command },
    PowerShell: { icon: '⚡', label: 'מריץ פקודה', arg: i => i.command },
    read_file: { icon: '📖', label: 'קורא קובץ', arg: P }, Read: { icon: '📖', label: 'קורא קובץ', arg: P },
    write_file: { icon: '✍️', label: 'כותב קובץ', arg: P }, Write: { icon: '✍️', label: 'כותב קובץ', arg: P },
    edit_file: { icon: '✏️', label: 'עורך קובץ', arg: P }, Edit: { icon: '✏️', label: 'עורך קובץ', arg: P }, MultiEdit: { icon: '✏️', label: 'עורך קובץ', arg: P }, NotebookEdit: { icon: '✏️', label: 'עורך מחברת', arg: P },
    list_directory: { icon: '📁', label: 'מציג תיקייה', arg: i => i.path || '.' },
    search_files: { icon: '🔍', label: 'מחפש', arg: i => i.pattern },
    Glob: { icon: '🔍', label: 'מחפש קבצים', arg: i => i.pattern }, Grep: { icon: '🔍', label: 'מחפש בקבצים', arg: i => i.pattern },
    WebSearch: { icon: '🌐', label: 'מחפש ברשת', arg: i => i.query }, web_search: { icon: '🌐', label: 'מחפש ברשת', arg: i => i.query },
    WebFetch: { icon: '🌐', label: 'קורא דף', arg: i => i.url }, web_fetch: { icon: '🌐', label: 'קורא דף', arg: i => i.url },
    agent: { icon: '🤖', label: 'סוכן משנה', arg: i => i.description }, Agent: { icon: '🤖', label: 'סוכן משנה', arg: i => i.description }, Task: { icon: '🤖', label: 'סוכן משנה', arg: i => i.description },
    deep_research: { icon: '🔬', label: 'מחקר עמוק', arg: i => i.question },
    TodoWrite: { icon: '☑️', label: 'מעדכן רשימת משימות', arg: i => (i.todos ? i.todos.length + ' משימות' : '') },
    Skill: { icon: '🧩', label: 'מפעיל Skill', arg: i => i.skill || i.name }, ToolSearch: { icon: '🧰', label: 'מחפש כלים', arg: i => i.query },
    AskUserQuestion: { icon: '❓', label: 'שואל אותך', arg: i => (i.questions && i.questions[0] && i.questions[0].question) || '' },
    ExitPlanMode: { icon: '📝', label: 'מציג תוכנית לאישור', arg: () => '' }, EnterPlanMode: { icon: '📝', label: 'עובר למצב תכנון', arg: () => '' }
  };
  // הנתיב שהכלי קורא / כותב / מחפש בו — מוצג כקישור (כמו ב-VS Code). inLabel: הנתיב הוא הטקסט שבכותרת; אחרת — תווית נוספת
  const PATH_TOOLS = new Set(['Read', 'Write', 'Edit', 'MultiEdit', 'NotebookEdit', 'read_file', 'write_file', 'edit_file', 'list_directory', 'LS']);
  const RESULT_LINES_TOOLS = new Set(['Glob', 'Grep', 'LS', 'list_directory', 'search_files']);
  function toolPath(name, input) {
    if (PATH_TOOLS.has(name)) { const p = name === 'list_directory' || name === 'LS' ? (input.path || '.') : P(input); return p ? { path: String(p), inLabel: true } : null; }
    const p = input.path || input.file_path || input.notebook_path;
    if (typeof p === 'string' && p.trim() && (name === 'Glob' || name === 'Grep' || name === 'search_files' || String(name).startsWith('mcp__'))) return { path: p, inLabel: false };
    return null;
  }
  const infoOf = name => TOOL_INFO[name] || (String(name).startsWith('mcp__') ? { icon: '🔌', label: String(name).replace(/^mcp__/, '').replace(/__/g, ' › '), arg: i => { const k = Object.keys(i || {})[0]; return k ? String(i[k]).slice(0, 80) : ''; } } : { icon: '🔧', label: name, arg: () => '' });
  function toolIcon(name, input) {
    try { if (typeof App.toolIcon === 'function') { const h = App.toolIcon(name, input || {}); if (h) return h; } } catch { }
    return infoOf(name).icon;
  }

  // ---------- היסטוריה בחלון: עד HIST_FULL הודעות מוצגות כולן; מעל — רק HIST_TAIL האחרונות, והשאר בגלילה ----------
  const HIST_FULL = 400, HIST_TAIL = 150;
  const isTurnStart = m => m && m.role === 'user' && !m.auto && Array.isArray(m.content) && m.content.some(b => b && b.type !== 'tool_result' && !(b.type === 'text' && b.hidden));
  // נקודת התחלה בתחילת "תור" (הודעה שלך), כדי שתשובה של Claude לא תיחתך לשתי בועות
  function alignTurnLocal(list, i) { for (let k = Math.min(i, list.length - 1); k > 0 && k > i - 300; k--) if (isTurnStart(list[k])) return k; return Math.max(0, i); }
  function addResults(map, list) { for (const m of list) if (m.role === 'user' && Array.isArray(m.content)) for (const b of m.content) if (b.type === 'tool_result') map[b.tool_use_id] = { ...b, ts: m.ts }; }

  // ---------- שיחות במקביל ----------
  const chats = [];       // Chat[]  (הטאבים הפתוחים)
  let active = null;

  class Chat {
    constructor(o = {}) {
      this.id = o.id || null; this.title = o.title || 'שיחה חדשה';
      this.workingDir = o.workingDir || null; this.projectId = o.projectId || null;
      this.running = false; this.runStart = 0; this.attachments = []; this.toolCards = {}; this.live = null; this.lastDay = null;
      this.loaded = false; this.abort = null; this.closed = false; this.unseen = false; this.waiting = false;
      this.usage = null; this.queued = {}; this.remote = !!o.remote; this.liveThinking = new Set(); this.code = o.code || null; this.folderId = null;
      this.buildPane();
    }

    // ----- בניית החלונית: הודעות + תיבת כתיבה (בדיוק המבנה של הגרסה המקורית, עם שורת כלים תחתונה חדשה) -----
    buildPane() {
      const pane = this.pane = el('div', 'chat-pane');
      pane.innerHTML = `
        <div class="pane-bar">
          <button class="pane-title" title="לחיצה: שינוי שם השיחה"><span class="pt-text"></span></button>
          <button class="pane-code" hidden></button>
          <span class="pane-flow" hidden></span>
          <span class="pane-spacer"></span>
          <span class="cb-use" hidden></span>
        </div>
        <div class="watch-dock" hidden></div>
        <section class="messages"></section>
        <footer class="composer-wrap">
          <div class="composer">
            <div class="attachments"></div>
            <div class="tag-row" hidden></div>
            <textarea rows="1" placeholder="כתוב ל-Claude מה לעשות…"></textarea>
            <div class="composer-bar cb2">
              <button class="cb-btn cb-plus" title="צרף קבצים או תמונות (גם גרירה והדבקה Ctrl+V)">＋</button>
              <button class="cb-btn cb-slash" title="פקודות / (אפשר גם להקליד / בתיבה)">/</button>
              <button class="cb-btn cb-more" title="עוד: Remote Control · סוכנים · הוראות · תזרים · מעקב">⋯</button>
              <button class="cb-btn cb-remote" title="Remote Control — המשך את השיחה הזו מהטלפון / claude.ai. לחיצה: הפעלה וכיבוי"><span class="rc-dot"></span><span class="cb-lbl">Remote Control</span><span class="cb-short">RC</span></button>
              <button class="cb-btn cb-agents" title="סוכנים שרצים בשיחה הזו — לחיצה: רשימה ועצירה"><span class="ag-dot"></span><b class="ag-n">0</b><span class="cb-lbl">סוכנים</span></button>
              <div class="ctrl-pop-wrap cbw-tool">
                <button class="cb-btn cb-instr" title="הוראות לשיחה הזו — בחר אילו דלוקות (חל מיד, גם על הסוכנים של השיחה)"><span class="cb-ic">📝</span><span class="cb-lbl">הוראות</span> <b class="cb-cnt"></b></button>
                <div class="ctrl-pop cb-pop cb-instrpop" hidden></div>
              </div>
              <div class="ctrl-pop-wrap cbw-tool">
                <button class="cb-btn cb-flow" title="תזרים לשיחה הזו — בוחרים תזרים אחד והוא חל מיד (אפשר להחליף באמצע)"><span class="cb-ic">⚙</span><span class="cb-lbl">תזרים</span> <span class="cb-flowtxt"></span></button>
                <div class="ctrl-pop cb-pop cb-flowpop" hidden></div>
              </div>
              <div class="ctrl-pop-wrap cbw-tool">
                <button class="cb-btn cb-watch" title="מעקב — משימה קבועה: Claude יתעורר כל כמה זמן שתבחר ויבצע את מה שתכתוב בהודעה (לבדוק ולתקן)"><span class="cb-ic">⏱</span><span class="cb-lbl">מעקב</span></button>
                <div class="ctrl-pop cb-pop cb-watchpop" hidden></div>
              </div>
              <button class="cb-btn cb-wcount" hidden title="מעקבים פתוחים בשיחה הזו — לחיצה: מעבר לחלון המעקב"><span class="wc-dot"></span><b class="wc-n">0</b></button>
              <div class="ctrl-pop-wrap cb-model-wrap">
                <button class="cb-btn cb-model" title="מודל, מאמץ וחשיבה"><span class="cb-model-txt">מודל</span></button>
                <div class="ctrl-pop cb-pop cb-modelpop" hidden></div>
              </div>
              <span class="cb-spacer"></span>
              <span class="work-status" hidden title="Claude עובד"><span class="ws-ic">⚙️</span><span class="ws-time">00:00</span></span>
              <div class="ctrl-pop-wrap cbw-mode">
                <button class="cb-btn cb-mode" title="מצב הרשאות — מה Claude מבצע בלי לשאול"><span class="mode-txt">Auto</span></button>
                <div class="ctrl-pop cb-pop cb-modepop" hidden></div>
              </div>
              <button class="cb-btn cb-mic" title="הכתבה קולית (עברית / English) — לחיצה: התחל לדבר" aria-label="הכתבה קולית" aria-pressed="false"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10v1a7 7 0 0 0 14 0v-1M12 18v4M8 22h8"/></svg></button>
              <button class="btn-stop" hidden title="עצור את Claude (Esc)" aria-label="עצור">■</button>
              <button class="btn-send" title="שלח (Enter). גם כש-Claude עובד: ההודעה תתווסף למשימה">➤</button>
            </div>
          </div>
          <input type="file" class="fileInput" multiple hidden>
        </footer>`;
      const q = s => pane.querySelector(s);
      this.$messages = q('.messages'); this.$input = q('textarea'); this.$attach = q('.attachments'); this.$composer = q('.composer'); this.setupScrolling(); this.setupSticky();
      this.$send = q('.btn-send'); this.$stop = q('.btn-stop'); this.$work = q('.work-status'); this.$file = q('.fileInput');
      this.$cbInstr = q('.cb-instr'); this.$cbFlow = q('.cb-flow'); this.$ptitle = q('.pt-text'); this.$pcode = q('.pane-code'); this.$pflow = q('.pane-flow'); this.$tags = q('.tag-row');
      this.renderWelcome();
      this.bindPane();
      $('chatstack').appendChild(pane);
      this.updateCwd();
    }

    renderWelcome() {
      const w = el('div', 'welcome');
      w.innerHTML = `<div class="welcome-logo">✳</div><h1>שלום! אני Claude</h1>
        <p>יש לי גישה מלאה למחשב שלך: אני יכול להריץ פקודות, לקרוא, לכתוב ולערוך קבצים, ולחפש בתיקיות.</p>
        <div class="suggestions"></div><div class="setup-hint" hidden>⚠️ עוד לא הגדרת חיבור. <button class="link-btn">לחץ כאן כדי להגדיר</button></div>`;
      const box = w.querySelector('.suggestions');
      for (const [label, text] of SUGGESTIONS) { const b = el('button', 'sugg'); b.textContent = label; b.onclick = () => this.send(text); box.appendChild(b); }
      w.querySelector('.link-btn').onclick = () => App.settings && App.settings.open('account');
      this.$welcome = w; this.$messages.appendChild(w);
      this.updateSetupHint();
    }
    updateSetupHint() { const h = this.$welcome && this.$welcome.querySelector('.setup-hint'); if (h) h.hidden = hasAuth(); }
    hideWelcome() { if (this.$welcome) this.$welcome.hidden = true; }
    showWelcome() { if (this.$welcome) { this.$welcome.hidden = false; this.updateSetupHint(); } }

    // ----- אירועים של החלונית -----
    bindPane() {
      const p = this.pane, q = s => p.querySelector(s);
      this.$send.onclick = () => this.send();
      this.$stop.onclick = () => this.stop();
      q('.pane-title').onclick = () => this.id && renameChat(this);
      this.$pcode.onclick = () => this.code && App.copyText(this.code, 'הקוד ' + this.code + ' הועתק');
      this.$file.onchange = e => { this.addFiles([...e.target.files]); e.target.value = ''; };
      q('.cb-plus').onclick = e => { const r = e.currentTarget.getBoundingClientRect(); App.menu(r.left, r.top - 110, [
        { icon: '📎', label: 'צרף קובץ או תמונה…', onClick: () => this.$file.click() },
        { icon: '📋', label: 'הדבק תמונה מהלוח', hint: 'Ctrl+V', onClick: () => this.pasteImage() },
        { icon: '🔬', label: 'מחקר מעמיק', onClick: () => this.setResearch(true) }
      ]); };
      q('.cb-slash').onclick = e => this.slashMenu(e.currentTarget);
      q('.cb-remote').onclick = () => this.toggleRemote();
      q('.cb-mic').onclick = () => window.Dictation && Dictation.toggle(this); // הכתבה קולית (dictation.js)
      q('.cb-mic').addEventListener('pointerenter', () => window.Dictation && Dictation.warm(), { once: true });
      q('.cb-agents').onclick = e => this.agentsPop(e.currentTarget);
      // מודל / מצב — פופאוברים
      const popToggle = (btn, pop, build) => btn.onclick = e => { e.stopPropagation(); const wasHidden = pop.hidden; document.querySelectorAll('.cb-pop').forEach(x => (x.hidden = true)); if (wasHidden) { if (build) build(); pop.hidden = false; } };
      popToggle(q('.cb-model'), q('.cb-modelpop'), () => this.buildModelPop());
      popToggle(q('.cb-mode'), q('.cb-modepop'), () => this.buildModePop());
      popToggle(q('.cb-instr'), q('.cb-instrpop'), () => this.buildInstrPop());
      popToggle(q('.cb-flow'), q('.cb-flowpop'), () => this.buildFlowPop());
      popToggle(q('.cb-watch'), q('.cb-watchpop'), () => App.watches && App.watches.buildPop(this, q('.cb-watchpop')));
      q('.cb-wcount').onclick = () => App.watches && App.watches.focusDock(this);
      // ⋯ (רק כשהתיבה צרה מאוד): הכפתורים שלא נכנסו — באותן פעולות בדיוק
      q('.cb-more').onclick = e => {
        e.stopPropagation(); const btn = e.currentTarget, r = btn.getBoundingClientRect(), L = this._fit || 0, n = (this.agentList || []).length;
        const cnt = (q('.cb-instr .cb-cnt').textContent || '').trim(), ft = (q('.cb-flowtxt').textContent || '').trim();
        const items = [
          { icon: '📱', label: 'Remote Control — ' + (this.remote ? 'פעיל (לחיצה: כיבוי)' : 'כבוי (לחיצה: הפעלה)'), onClick: () => this.toggleRemote() },
          { icon: '🤖', label: `סוכנים (${n})`, onClick: () => this.agentsPop(btn) },
          { icon: '📝', label: 'הוראות' + (cnt ? ' (' + cnt + ')' : ''), onClick: () => q('.cb-instr').click() },
          { icon: '⚙', label: 'תזרים' + (ft ? ': ' + ft : ''), onClick: () => q('.cb-flow').click() },
          { icon: '⏱', label: 'מעקב', onClick: () => q('.cb-watch').click() }
        ];
        if (L >= 8) items.push({ sep: true }, { icon: '🔐', label: 'מצב הרשאות: ' + (q('.cb-mode').textContent || '').trim(), onClick: () => q('.cb-mode').click() }, { icon: '🎤', label: 'הכתבה קולית', onClick: () => q('.cb-mic').click() });
        if (L >= 9) items.unshift({ icon: '📎', label: 'צרף קובץ או תמונה…', onClick: () => this.$file.click() }, { icon: '🔬', label: 'מחקר מעמיק', onClick: () => this.setResearch(true) }, { sep: true });
        App.menu(r.left, Math.max(8, r.top - items.length * 34 - 24), items);
      };
      this.setupBarFit();
      this.pane.addEventListener('click', e => { if (!e.target.closest('.ctrl-pop-wrap')) p.querySelectorAll('.cb-pop').forEach(x => (x.hidden = true)); });
      const input = this.$input;
      input.addEventListener('input', () => { this.autoGrow(); this.slashAuto(); this.saveDraftSoon(); uiActivity(); });
      this.restoreDraft(); // טיוטה שנשארה (רענון / הפעלה מחדש באמצע הקלדה)
      input.addEventListener('keydown', e => {
        uiActivity();
        // הגדרות → צ'אט: "Enter שולח" (Shift+Enter = שורה חדשה) או "Ctrl+Enter שולח" (Enter = שורה חדשה)
        const ctrlMode = App.chatUi && App.chatUi().enter === 'ctrl', slashSel = document.querySelector('.slash-pop .sl-item.sel');
        if (e.key === 'Enter' && !e.isComposing && ctrlMode && !slashSel && !(e.ctrlKey || e.metaKey)) return; // שורה חדשה רגילה
        if (e.key === 'Enter' && (!e.shiftKey || (ctrlMode && (e.ctrlKey || e.metaKey))) && !e.isComposing) { e.preventDefault(); if (document.querySelector('.slash-pop .sl-item.sel')) { document.querySelector('.slash-pop .sl-item.sel').click(); return; } this.send(); }
        else if (e.key === 'Escape') { if (document.querySelector('.slash-pop')) { e.stopPropagation(); this.closeSlash(); } }
        else if ((e.key === 'ArrowDown' || e.key === 'ArrowUp') && document.querySelector('.slash-pop')) { e.preventDefault(); this.slashMove(e.key === 'ArrowDown' ? 1 : -1); }
      });
      input.addEventListener('paste', e => { const files = [...((e.clipboardData && e.clipboardData.files) || [])]; if (files.length) { e.preventDefault(); this.addFiles(files); } });
      this.$messages.addEventListener('click', e => {
        const btn = e.target.closest('.copy-code'); if (!btn) return;
        App.copyText(btn.closest('.code-block').querySelector('code').innerText, '');
        btn.textContent = '✅ הועתק'; setTimeout(() => (btn.textContent = '📋 העתק'), 1500);
      });
    }

    // ----- כותרת החלונית: שם השיחה + קוד (בלי נתיבים — הנתיב מופיע בטאב של הפרויקט) -----
    updateHead() {
      if (!this.$ptitle) return;
      this.$ptitle.textContent = this.title || 'שיחה חדשה';
      this.$pcode.hidden = !this.code; if (this.code) { this.$pcode.textContent = this.code; this.$pcode.title = 'קוד השיחה: ' + this.code + ' — אפשר לכתוב ל-Claude "שיחה ' + this.code + '" והוא יוכל לקרוא אותה ולשלוח אליה. לחיצה: העתקה'; }
    }
    updateCwd() { this.updateHead(); }
    setFlowBadge(f) { if (!this.$pflow) return; this.$pflow.hidden = !f; if (f) { this.$pflow.textContent = '⚙ תזרים: ' + f.flowName + ' · שלב ' + f.no + '/' + f.total; this.$pflow.title = f.stepName || ''; } }
    async setDir(dir) { if (App.workspace) await App.workspace.add(dir); }
    // שימוש של כל השיחה (סכום כל ההודעות, כולל סוכנים): טוקנים + אחוז מהמנוי / $ במצב API
    showUsage(u) {
      if (u && !u.live) this.usage = u; else if (u && u.live) return;
      const s = this.pane && this.pane.querySelector('.cb-use'); if (!s) return;
      const v = this.usage && ((this.usage.input || 0) + (this.usage.output || 0)) ? fmt.use(this.usage) : null;
      s.hidden = !v; if (!v) return;
      s.textContent = 'בשיחה: ' + v.text; s.title = 'סך השימוש של השיחה הזו\n' + v.title;
    }

    // ----- הוראות + תזרים לשיחה הזו (כפתורים בסרגל התחתון) -----
    syncRules(conv) {
      this.instructionIds = Array.isArray(conv && conv.instructionIds) ? conv.instructionIds : null; this.flowId = (conv && conv.flowId) || null;
      this.updateRuleButtons();
    }
    async updateRuleButtons() {
      if (!this.$cbInstr) return;
      let sel = null;
      if (this.id) { try { sel = (await App.api('/api/conversations/' + this.id + '/instructions')); } catch { } }
      else { try { const all = (await App.api('/api/instructions')).instructions || []; sel = { selected: this.instructionIds ? this.instructionIds : all.filter(i => i.enabled).map(i => i.id), custom: !!this.instructionIds }; } catch { } }
      const n = sel ? sel.selected.length : 0, cnt = this.$cbInstr.querySelector('.cb-cnt');
      cnt.textContent = n ? String(n) : ''; this.$cbInstr.classList.toggle('on', n > 0); this.$cbInstr.classList.toggle('custom', !!(sel && sel.custom));
      this.paintFlowButton();
    }
    async paintFlowButton() {
      if (!this.$cbFlow) return;
      let name = '', st = '';
      if (this.flowId) {
        try { const f = await App.api('/api/flows/' + this.flowId); name = (f.flow && f.flow.name) || ''; } catch { }
        const r = this.flowRun;
        if (r && r.status === 'running') st = ' · ' + r.stepNo + '/' + r.total; else if (r && r.status && r.status !== 'running') st = r.status === 'done' ? ' ✓' : ' ✖';
      }
      this.$cbFlow.classList.toggle('on', !!this.flowId); this.$cbFlow.classList.toggle('busy', !!(this.flowRun && this.flowRun.status === 'running'));
      this.$cbFlow.querySelector('.cb-flowtxt').textContent = name ? (name.length > 14 ? name.slice(0, 13) + '…' : name) + st : '';
      this.$cbFlow.title = name ? 'תזרים: ' + name : 'תזרים לשיחה הזו — בוחרים תזרים אחד והוא חל מיד (אפשר להחליף באמצע)';
    }
    // שיחה חדשה שעוד אין לה הודעה: יוצרים אותה עכשיו כדי שאפשר יהיה לקשור לה הוראות/תזרים
    async ensureConv() {
      if (this.id) return this.id;
      const settings = this.settings(); // ⚙ מה שנבחר בתיבה לפני ההודעה הראשונה עובר לצ'אט שנוצר (הוראות / תזרים לפני הודעה)
      const r = await App.api('/api/conversations', { method: 'POST', body: { projectId: this.projectId, folderId: this.folderId, settings } });
      this.pin = r.pin || settings; this.draft = {};
      this.id = r.id; this.code = r.code; this.title = r.title || this.title; this.updateHead(); loadConversations();
      if (active === this) history.replaceState(null, '', location.search + '#' + this.id); // ?m= (מחשב מרוחק) נשמר
      return this.id;
    }
    async buildInstrPop() {
      const pop = this.pane.querySelector('.cb-instrpop'); pop.innerHTML = '<div class="rl-head">הוראות לשיחה הזו</div><div class="rl-loading">טוען…</div>';
      let data;
      try {
        const all = (await App.api('/api/instructions')).instructions || [];
        if (this.id) { const r = await App.api('/api/conversations/' + this.id + '/instructions'); data = { all, selected: new Set(r.selected), custom: r.custom }; }
        else data = { all, selected: new Set(this.instructionIds || all.filter(i => i.enabled).map(i => i.id)), custom: !!this.instructionIds };
      } catch (e) { pop.innerHTML = '<div class="rl-empty">שגיאה: ' + esc(e.message) + '</div>'; return; }
      const render = () => {
        pop.innerHTML = `<div class="rl-head"><span>הוראות לשיחה הזו</span><small>${data.custom ? 'בחירה של השיחה' : 'ברירת המחדל'}</small></div>`;
        if (!data.all.length) pop.appendChild(el('div', 'rl-empty', 'עוד אין הוראות. צור אותן בהגדרות › מאגרי הוראות.'));
        const list = el('div', 'rl-list');
        for (const it of data.all) {
          const row = el('label', 'rl-row'); const cb = el('input'); cb.type = 'checkbox'; cb.checked = data.selected.has(it.id);
          const tx = el('span', 'rl-tx'); tx.innerHTML = `<b></b><small></small><i class="rl-enf"></i>`; tx.querySelector('b').textContent = it.name || 'הוראה'; tx.querySelector('small').textContent = (it.text || '').replace(/\s+/g, ' ').slice(0, 90);
          tx.querySelector('.rl-enf').textContent = it.enforced && it.enforced.length ? '🛡 ההוק אוכף: ' + it.enforced.join(' · ') : '🛡 אין כלל מדיד — לא נחסם';
          cb.onchange = async () => {
            if (cb.checked) data.selected.add(it.id); else data.selected.delete(it.id); data.custom = true;
            try { await this.ensureConv(); const r = await App.api('/api/conversations/' + this.id + '/instructions', { method: 'POST', body: { ids: [...data.selected] } }); this.instructionIds = [...data.selected]; this.updateRuleButtons(); App.toast(r.appliedNow ? '✅ חל מיד — Claude קיבל את השינוי באמצע העבודה' : '✅ חל מההודעה הבאה', 1800); render(); }
            catch (e) { App.toast('❌ ' + e.message, 3500); cb.checked = !cb.checked; }
          };
          row.append(cb, tx); list.appendChild(row);
        }
        pop.appendChild(list);
        const foot = el('div', 'rl-foot');
        const reset = el('button', 'btn-ghost', 'ברירת מחדל'); reset.title = 'חזרה להוראות שדלוקות בהגדרות'; reset.disabled = !data.custom;
        reset.onclick = async () => { try { await this.ensureConv(); const r = await App.api('/api/conversations/' + this.id + '/instructions', { method: 'POST', body: { ids: null } }); data.selected = new Set(r.selected); data.custom = false; this.instructionIds = null; this.updateRuleButtons(); render(); } catch (e) { App.toast('❌ ' + e.message, 3500); } };
        const manage = el('button', 'btn-ghost', '＋ נהל הוראות'); manage.onclick = () => { pop.hidden = true; App.settings && App.settings.open('instr'); };
        foot.append(manage, reset); pop.appendChild(foot);
      };
      render();
    }
    async buildFlowPop() {
      const pop = this.pane.querySelector('.cb-flowpop'); pop.innerHTML = '<div class="rl-head">תזרים לשיחה הזו</div><div class="rl-loading">טוען…</div>';
      let flows, active_ = null;
      try { const r = await App.api('/api/flows'); flows = r.flows || []; active_ = this.id ? (r.active || []).find(x => x.convId === this.id) : null; this.flowRun = active_ || this.flowRun; }
      catch (e) { pop.innerHTML = '<div class="rl-empty">שגיאה: ' + esc(e.message) + '</div>'; return; }
      const render = () => {
        pop.innerHTML = `<div class="rl-head"><span>תזרים לשיחה הזו</span><small>${this.flowRun && this.flowRun.status === 'running' ? 'רץ: שלב ' + this.flowRun.stepNo + '/' + this.flowRun.total : 'בחירה = הפעלה מיד'}</small></div>`;
        const list = el('div', 'rl-list');
        const mk = (id, name, sub) => {
          const row = el('label', 'rl-row'); const rb = el('input'); rb.type = 'radio'; rb.name = 'flowsel'; rb.checked = (this.flowId || null) === id;
          const tx = el('span', 'rl-tx'); tx.innerHTML = '<b></b><small></small>'; tx.querySelector('b').textContent = name; tx.querySelector('small').textContent = sub || '';
          rb.onchange = async () => {
            try {
              await this.ensureConv();
              const r = await App.api('/api/conversations/' + this.id + '/flow', { method: 'POST', body: { flowId: id } });
              this.flowId = id; this.flowRun = r.run || null; this.paintFlowButton();
              App.toast(id ? (r.replaced ? '✅ התזרים הוחלף והחדש התחיל' : '✅ התזרים התחיל על השיחה הזו') : '✅ התזרים הופסק', 2200);
              App.emit('flow:event', { type: 'flow_run', data: r.run || {} }); pop.hidden = true;
            } catch (e) { App.toast('❌ ' + e.message, 4000); render(); }
          };
          row.append(rb, tx); return row;
        };
        list.appendChild(mk(null, 'ללא תזרים', 'Claude עובד חופשי'));
        const mine = flows.filter(f => f.scope && ((f.scope.type === 'project' && f.scope.id === this.projectId) || f.scope.type === 'chat'));
        const rest = flows.filter(f => !mine.includes(f));
        for (const f of [...mine, ...rest]) list.appendChild(mk(f.id, f.name, f.steps.length + ' שלבים' + (f.schedule && f.schedule.mode !== 'none' ? ' · מתוזמן' : '')));
        if (!flows.length) list.appendChild(el('div', 'rl-empty', 'עוד אין תזרימים. צור אחד בלשונית "תזרים" בצד ימין.'));
        pop.appendChild(list);
        const foot = el('div', 'rl-foot'); const manage = el('button', 'btn-ghost', '＋ נהל תזרימים'); manage.onclick = () => { pop.hidden = true; App.view && App.view.show('flows'); };
        foot.appendChild(manage); pop.appendChild(foot);
      };
      render();
    }

    // ----- בקרים בתחתית התיבה (מודל / מצב / סוכנים / Remote Control) -----
    syncControls() {
      const c = App.state.config; if (!c) return;
      const q = s => this.pane.querySelector(s);
      const models = App.state.models;
      const S = this.settings(), t = S.thinking;
      // תווית הכפתור: "Sonnet 5.5 · Extra high"
      const EFF = { default: '', low: 'Low', medium: 'Medium', high: 'High', xhigh: 'Extra high', max: 'Max' };
      // שיחה שהועתקה מ-VS Code רצה עם המודל וה-effort של הצ'אט המקורי (pin) — מוצג כאן כדי שהתווית תהיה נכונה
      const pin = this.pin || {}, model = S.model, effort = S.effort, ultra = S.ultracode, vs = !!(this.importedFrom && pin.model);
      const pretty = id => { const l = App.modelLabel(id); if (l && l !== id) return l; const m = String(id || '').match(/^claude-([a-z]+)-(\d+)-(\d+)/); return m ? m[1][0].toUpperCase() + m[1].slice(1) + ' ' + m[2] + '.' + m[3] : id; };
      const effTxt = (ultra ? 'ULTRA' : '') + (ultra && EFF[effort] ? ' · ' : '') + (EFF[effort] || (t === 'on' && !ultra ? 'Extra high' : ''));
      q('.cb-model-txt').innerHTML = (vs ? '🔗 ' : '') + esc(pretty(model) || 'מודל') + (effTxt ? ` <span class="cb-eff">${esc(effTxt)}</span>` : '') + (t === 'on' ? ' <span class="cb-eff cb-think on" title="חשיבה: תמיד">🧠</span>' : t === 'off' ? '' : ` <span class="cb-eff cb-think auto" title="חשיבה: אוטומטית — Claude מחליט מתי לחשוב">${window.ModelMenu ? window.ModelMenu.autoBrain() : '🧠'}</span>`); // (הבעלים 26/11) תמיד = 🧠 · כבויה = בלי סמל · אוטומטית = 🧠 עם שני חצים שמסתובבים סביבו
      q('.cb-model').title = (pretty(model) || 'מודל') + (effTxt ? ' · ' + effTxt : '') + (vs ? ' — המודל של הצ\'אט המקורי מ-VS Code' : '') + ' — מודל, מאמץ וחשיבה של הצ\'אט הזה בלבד'; // השם המלא גם כשהתווית מתקצרת (…)
      this.syncMode();
      if (!q('.cb-modelpop').hidden) this.buildModelPop();
      const rc = q('.cb-remote'); rc.classList.toggle('on', !!this.remote); rc.title = this.remote ? (this.remoteUrl ? 'Remote Control פעיל: ' + this.remoteUrl : 'Remote Control פעיל — לחיצה לכיבוי') : 'Remote Control כבוי — לחיצה להפעלה (המשך את השיחה מהטלפון / claude.ai)';
      rc.hidden = c.accountMode !== 'subscription';
    }
    // ⚙ הגדרות לפי צ'אט (REQUESTS-10 H): ההגדרות הכלליות = ברירת מחדל לצ'אט חדש; בחירה כאן חלה מיד על הצ'אט הזה בלבד.
    //    צ'אט קיים → pin בשרת. צ'אט חדש (עוד בלי הודעה) → טיוטה (draft) שנשלחת עם ההודעה הראשונה.
    settings() {
      const c = App.state.config || {}, th = c.thinking === true ? 'on' : c.thinking === false ? 'auto' : (c.thinking || 'auto');
      const o = { model: c.model || '', effort: c.effort || 'default', thinking: th, ultracode: !!c.ultracode, permissionMode: c.permissionMode || (c.autoApprove === false ? 'default' : 'bypassPermissions') };
      const p = this.pin || {}, d = this.id ? {} : (this.draft || {});
      for (const k of Object.keys(o)) { if (p[k] !== undefined && p[k] !== '') o[k] = p[k]; if (d[k] !== undefined) o[k] = d[k]; }
      return o;
    }
    async setChat(patch, label) {
      let r = null;
      if (this.id) { r = await this.setPin(patch); if (!r) return false; } else { this.draft = { ...(this.draft || {}), ...patch }; this.syncControls(); }
      // באמצע עבודה (מנוי): מודל / הרשאות / מאמץ — מיד. חשיבה — Claude Code לא משנה אותה באמצע תור (נמדד), אז מיד עובר המאמץ שלה
      // (כבויה → מאמץ נמוך, כמעט בלי חשיבה) והחשיבה עצמה מההודעה הבאה. ULTRACODE — מההודעה הבאה (הוראות)
      const keys = Object.keys(patch), L = (r && r.live) || {}, live = L.applied || [], part = L.partial || [], sub = (App.state.config || {}).accountMode === 'subscription';
      const when = !this.running ? '' : !sub ? ' · חל מהצעד הבא של Claude'
        : keys.includes('thinking') && part.includes('thinking') ? (patch.thinking === 'off' ? ' · מיד: מאמץ נמוך (כמעט בלי חשיבה) · כבויה לגמרי מההודעה הבאה' : ' · מיד: מאמץ גבוה · חשיבה מלאה מההודעה הבאה')
        : keys.every(k => live.includes(k)) ? ' · חל מיד, גם על העבודה שרצה עכשיו'
        : keys.some(k => live.includes(k)) ? ' · חלק מיד, השאר מההודעה הבאה' : ' · מההודעה הבאה';
      const mp = this.pane.querySelector('.cb-modelpop');
      if (mp && !mp.hidden) { const sc = mp.querySelector('.mp-scope'); if (sc) sc.textContent = '⚙ חל על הצ\'אט הזה בלבד' + when; } // החלון פתוח: השורה למעלה אומרת (הודעה צפה הייתה מסתירה את שורת החשיבה)
      else App.toast((label || 'עודכן') + ' — לצ\'אט הזה בלבד' + when, 3000);
      return true;
    }
    async setPin(patch) { try { const r = await App.api('/api/conversations/' + this.id + '/pin', { method: 'POST', body: patch }); if (!r || !r.pin) throw new Error((r && r.error) || 'השינוי לא נשמר'); this.pin = r.pin; this.syncControls(); return r; } catch (e) { App.toast('❌ השינוי לא נשמר: ' + e.message, 4000); this.syncControls(); return false; } }
    modeInfo() {
      const c = App.state.config || {}, sub = c.accountMode === 'subscription';
      const mode = this.settings().permissionMode;
      const all = [
        ...(mode === 'auto' ? [{ id: 'auto', icon: '🤖', name: 'Auto של VS Code', desc: 'כמו בצ\'אט המקורי: מבצע לבד, ומסווג בטיחות חוסם פעולות מסוכנות', short: 'Auto·VS' }] : []),
        { id: 'default', icon: '🛡️', name: 'שאל לפני כל פעולה', desc: 'Claude מבקש אישור לפני הרצת פקודות ועריכת קבצים', short: 'Ask' },
        ...(sub ? [{ id: 'acceptEdits', icon: '✏️', name: 'אשר עריכות אוטומטית', desc: 'עריכת קבצים בלי לשאול; פקודות עדיין מבקשות אישור', short: 'Edits' }, { id: 'plan', icon: '📝', name: 'מצב תכנון', desc: 'Claude רק מתכנן ולא משנה כלום עד שתאשר את התוכנית', short: 'Plan' }] : []),
        { id: 'bypassPermissions', icon: '⚡', name: 'Auto — גישה מלאה', desc: 'מבצע הכל בלי לשאול (כמו "ביצוע אוטומטי")', short: 'Auto' }
      ];
      return { mode, all, cur: all.find(x => x.id === mode) || all[0] };
    }
    syncMode() { const { cur } = this.modeInfo(); const b = this.pane.querySelector('.cb-mode'); b.innerHTML = `<span class="mode-ic">${cur.icon}</span><span class="mode-txt">${cur.short}</span>`; b.classList.toggle('auto', cur.id === 'bypassPermissions'); b.title = cur.name + ' — ' + cur.desc; }
    buildModePop() {
      const pop = this.pane.querySelector('.cb-modepop'); pop.innerHTML = '<div class="pop-title">מצב הרשאות</div>';
      const { mode, all } = this.modeInfo();
      for (const m of all) {
        const b = el('button', 'mode-item' + (m.id === mode ? ' on' : '')); b.innerHTML = `<span class="mi-ic">${m.icon}</span><span class="mi-body"><b>${esc(m.name)}</b><small>${esc(m.desc)}</small></span>${m.id === mode ? '<span class="mi-ck">✓</span>' : ''}`;
        b.onclick = async () => { pop.hidden = true; await this.setChat({ permissionMode: m.id }, 'מצב: ' + m.name); };
        pop.appendChild(b);
      }
    }
    async toggleRemote() {
      const on = !this.remote;
      if (!this.id) { this.remote = on; this.syncControls(); App.toast(on ? 'Remote Control יופעל עם ההודעה הראשונה' : 'Remote Control כבוי'); return; }
      try { const r = await App.api('/api/conversations/' + this.id + '/remote', { method: 'POST', body: { enabled: on } }); this.remote = !!r.enabled; this.remoteUrl = r.url || null; App.toast(this.remote ? '📱 Remote Control פעיל' + (r.url ? ': ' + r.url : ' — יתחבר עם ההודעה הבאה') : 'Remote Control כבוי'); }
      catch (e) { App.toast('Remote Control: ' + e.message, 5000); }
      this.syncControls();
    }
    setAgents(list) {
      this.agentList = list; const n = list.length;
      const b = this.pane.querySelector('.cb-agents'); b.querySelector('.ag-n').textContent = n; b.classList.toggle('busy', n > 0);
    }
    agentsPop(btn) {
      const r = btn.getBoundingClientRect(); const list = this.agentList || [];
      const items = list.length ? list.slice(0, 12).map(a => ({ icon: '🤖', label: `${a.description || 'סוכן'}${a.activity ? ' — ' + a.activity : ''}`.slice(0, 70), hint: '■ עצור', onClick: () => App.api('/api/agents/' + a.id + '/stop', { method: 'POST' }).then(() => App.toast('הסוכן נעצר')) })) : [{ icon: '·', label: 'אין סוכנים שרצים כרגע', disabled: true }];
      App.menu(r.left, Math.max(8, r.top - 40 - items.length * 34 - 90), [...items, { sep: true }, ...(list.length ? [{ icon: '⏹️', label: 'עצור את כל הסוכנים', danger: true, onClick: () => App.api('/api/agents/stop-all', { method: 'POST', body: { conversationId: this.id || null } }).then(() => App.toast('כל הסוכנים נעצרים')) }] : []), { icon: '🤖', label: 'פתח את פאנל הסוכנים', onClick: () => App.view.show('agents') }]);
    }

    // ----- חלון המודל: רשימה, רמת מאמץ, מצב חשיבה, ULTRACODE (הכל בתוך התיבה) -----
    buildModelPop() {
      const pop = this.pane.querySelector('.cb-modelpop'), c = App.state.config || {}, models = App.state.models, S = this.settings();
      const keepFly = this._fly && document.querySelector('.mp-fly') ? this._fly : null; // תפריט גרסאות פתוח נשאר פתוח גם כשהחלון נבנה מחדש
      pop.innerHTML = ''; if (window.ModelMenu) window.ModelMenu.closeAll();
      pop.appendChild(el('div', 'mp-scope', this.id ? '⚙ חל על הצ\'אט הזה בלבד' : '⚙ חל על הצ\'אט החדש הזה בלבד'));
      const sec = (title) => { const d = el('div', 'mp-sec'); d.appendChild(el('div', 'mp-h', title)); pop.appendChild(d); return d; };
      const sm = sec('מודל'); const list = el('div', 'mp-models'); sm.appendChild(list);
      // (הבעלים 26/11) Default ואז משפחות בסדר Fable · Opus · Sonnet · Haiku. ריחוף (או לחיצה) על משפחה פותח את כל הגרסאות שלה בצד;
      // הגרסה שנבחרה מוצגת ליד שם המשפחה עם ✓ — בלי שורה נפרדת למודל הנוכחי
      const cur = S.model || '';
      const plan = window.ModelMenu.plan(models.length ? models : [], cur);
      const closeFly = () => { this._fly = null; document.querySelectorAll('.mp-fly').forEach(f => f.remove()); list.querySelectorAll('.mp-fam.open').forEach(x => x.classList.remove('open')); };
      this._closeModelFly = closeFly;
      const row = (m, cls, label, sub) => {
        const b = el('button', cls + (m && m.id === cur ? ' on' : '')); b.innerHTML = `<span class="mp-ck">${m && m.id === cur ? '✓' : ''}</span><span class="mp-name"></span>${sub ? '<span class="mp-sub"></span>' : ''}`;
        b.querySelector('.mp-name').textContent = label; if (sub) b.querySelector('.mp-sub').textContent = sub;
        if (m) { b.title = m.description || m.id; b.onclick = async () => { closeFly(); await this.setChat({ model: m.id }, 'מודל: ' + label); }; }
        return b;
      };
      if (!plan.top.length && !plan.families.length) list.appendChild(row({ id: cur, name: cur }, 'mp-model', cur || 'לא נטענו מודלים'));
      const optL = new Map(window.ModelMenu.options(models, cur)); for (const m of plan.top) list.appendChild(row(m, 'mp-model', optL.get(m.id) || m.name));
      for (const f of plan.families) {
        const fb = el('button', 'mp-model mp-fam' + (f.selected ? ' on' : '')); fb.dataset.fam = f.key;
        fb.innerHTML = `<span class="mp-ck">${f.selected ? '✓' : ''}</span><span class="mp-name"></span><span class="mp-sub"></span><span class="mp-arrow">◂</span>`;
        fb.querySelector('.mp-name').textContent = f.name; fb.querySelector('.mp-sub').textContent = f.selected ? f.selected.ver : '';
        // (הבעלים 26/11) התפריט לא נסגר מעצמו: ריחוף פותח (ועובר למשפחה אחרת בריחוף עליה), לחיצה נועלת אותו פתוח — גם כשהעכבר זז לכל מקום.
        // נסגר רק בבחירת גרסה, לחיצה מחוץ לחלון, Esc, או כשהחלון נסגר. רענון של החלון (עדכון הגדרות) לא סוגר אותו
        const open = (pin) => {
          if (fb.classList.contains('open') && document.querySelector('.mp-fly')) { if (pin) this._fly = { fam: f.key, pinned: true }; return; }
          closeFly(); fb.classList.add('open'); this._fly = { fam: f.key, pinned: !!pin };
          const fly = el('div', 'mp-fly'); fly.dataset.fam = f.key; fly.appendChild(el('div', 'mp-fly-h', f.name));
          for (const v of f.versions) fly.appendChild(row(v.model, 'mp-model mp-ver', v.ver, v.note));
          document.body.appendChild(fly);
          // ליד השורה: בצד שמאל של החלון (RTL), ואם אין מקום — מימין
          const r = fb.getBoundingClientRect(), pr = pop.getBoundingClientRect(), w = fly.offsetWidth, h = fly.offsetHeight;
          let left = pr.left - w - 6; if (left < 6) left = Math.min(innerWidth - w - 6, pr.right + 6);
          fly.style.left = Math.max(6, left) + 'px'; fly.style.top = Math.max(6, Math.min(innerHeight - h - 6, r.top - 6)) + 'px';
        };
        fb.onmouseenter = () => { const s = this._fly; if (s && s.pinned && s.fam !== f.key && document.querySelector('.mp-fly')) return; open(false); }; // נעול בלחיצה → ריחוף על משפחה אחרת לא מחליף
        fb.onclick = e => { e.preventDefault(); open(true); };
        list.appendChild(fb);
        if (keepFly && keepFly.fam === f.key) { this._fly = keepFly; open(keepFly.pinned); }
      }
      const mi = models.find(x => x.id === S.model) || {}, eff = mi.effort || null;
      const se = sec('רמת מאמץ'); const segE = el('div', 'mp-seg');
      for (const [v, t] of [['default', 'רגיל'], ['low', 'נמוך'], ['medium', 'בינוני'], ['high', 'גבוה'], ['xhigh', 'גבוה מאוד'], ['max', 'מקסימום']]) {
        if (v !== 'default' && eff && !eff[v]) continue;
        const b = el('button', 'mp-opt' + ((S.effort || 'default') === v ? ' on' : '')); b.textContent = t;
        b.onclick = () => this.setChat({ effort: v }, 'רמת מאמץ: ' + t); segE.appendChild(b);
      }
      se.appendChild(segE);
      const st = sec('חשיבה'); const segT = el('div', 'mp-seg'); const tv = S.thinking;
      for (const [v, t] of [['auto', 'אוטומטית'], ['on', 'תמיד'], ['off', 'כבויה']]) { const b = el('button', 'mp-opt' + (tv === v ? ' on' : '')); b.textContent = t; b.onclick = () => this.setChat({ thinking: v }, 'חשיבה: ' + t); segT.appendChild(b); }
      st.appendChild(segT);
      // אמת על המודל (נמדד 26/11): Opus 5.5 / Fable — Anthropic לא מאפשרת לכבות בהם חשיבה; "כבויה" = מאמץ נמוך + הוראה (כמעט תמיד בלי חשיבה)
      const rid = String(mi.resolved || S.model || '').toLowerCase();
      const subM = (App.state.config || {}).accountMode === 'subscription';
      const canOff = mi.thinkingTypes ? !!mi.thinkingTypes.disabled : !/sonnet-5-5|opus-5-5|fable|mythos|haiku-5-5/.test(rid); // כמו thinkOffMode בשרת
      if (tv === 'off' && !canOff && !/haiku-5-5/.test(rid) && (subM || /opus-5-5|fable|mythos/.test(rid))) { const n = el('div', 'mp-note'); n.textContent = 'ℹ️ במודל הזה Anthropic לא מאפשרת לכבות חשיבה לגמרי — "כבויה" כאן = מאמץ נמוך והוראה לענות ישר (כמעט תמיד בלי חשיבה). לכיבוי מלא: Opus 4.8 / Haiku 5.5.'; st.appendChild(n); }
      if (tv === 'on') { const n = el('div', 'mp-note'); n.textContent = 'ℹ️ "תמיד" = מאמץ מקסימלי והוראה לחשוב בכל הודעה. במודלים החדשים המודל מחליט בעצמו, ובשאלה טריוויאלית לפעמים עונה בלי לחשוב.'; st.appendChild(n); }
      const ub = el('button', 'ultra-btn' + (S.ultracode ? ' on' : ''), S.ultracode ? '⚡ ULTRACODE פעיל' : '⚡ ULTRACODE'); ub.title = 'מאמץ מקסימלי, חשיבה ובדיקות — לצ\'אט הזה בלבד';
      ub.onclick = () => { const on = !this.settings().ultracode, top = ['xhigh', 'max', 'high'].find(v => !eff || eff[v]) || 'default'; this.setChat(on ? { ultracode: true, effort: top, thinking: 'on' } : { ultracode: false }, on ? '⚡ ULTRACODE פעיל (מאמץ מקסימלי + חשיבה תמיד)' : 'ULTRACODE כבוי'); }; pop.appendChild(ub);
    }

    // ----- תגיות מעל התיבה: פקודת / ומחקר מעמיק. לא נכנסות לטקסט שנכתב; נשלחות ברקע עם ההודעה -----
    setResearch(on) { this.researchNext = !!on; if (on) this.researchDepth = this.researchDepth || (App.state.config && App.state.config.researchDepth) || 'standard'; this.renderTags(); if (on) this.$input.focus(); }
    setCmd(c) { this.cmdTag = c ? { name: c.name, title: slashHe(c).title } : null; this.renderTags(); if (c) this.$input.focus(); }
    renderTags() {
      const row = this.$tags; row.innerHTML = '';
      if (this.cmdTag) {
        const t = el('span', 'tag tag-cmd'); t.innerHTML = '<span class="tg-ic">/</span><span class="tg-t"></span><button title="הסר">✕</button>';
        t.querySelector('.tg-t').textContent = this.cmdTag.title; t.title = '/' + this.cmdTag.name; t.querySelector('button').onclick = () => this.setCmd(null); row.appendChild(t);
      }
      if (this.watchNext) { // מעקב חמוש: ההודעה הבאה תפתח אותו
        const w = this.watchNext, t = el('span', 'tag tag-watch'); t.innerHTML = '<span class="tg-ic">⏱</span><span class="tg-t"></span><button title="בטל את המעקב">✕</button>';
        t.querySelector('.tg-t').textContent = 'מעקב' + (w.name ? ' «' + w.name + '»' : '') + ' · ' + (App.watches ? App.watches.describe(w) : '');
        t.title = 'ההודעה שתשלח עכשיו תהיה המשימה של המעקב. סבב ראשון מיד, ואז לפי הזמנים שבחרת.';
        t.querySelector('button').onclick = () => { this.watchNext = null; this.renderTags(); }; row.appendChild(t);
      }
      // כשמעקב חמוש — ההסבר בתוך התיבה עצמה (לא הודעה קופצת שמכסה את התגית)
      this.$input.placeholder = this.watchNext ? 'כתוב כאן את המשימה של המעקב ושלח — Claude יבצע אותה בכל סבב…' : (this.running ? 'Claude עובד… אפשר להוסיף הודעה' : 'כתוב ל-Claude מה לעשות…');
      if (this.researchNext) {
        const t = el('span', 'tag tag-research'); t.innerHTML = '<span class="tg-ic">🔬</span><span class="tg-t">מחקר מעמיק</span><select><option value="quick">מהיר</option><option value="standard">רגיל</option><option value="deep">עמוק</option></select><button title="הסר">✕</button>';
        const sel = t.querySelector('select'); sel.value = this.researchDepth || 'standard'; sel.onchange = () => (this.researchDepth = sel.value);
        t.querySelector('button').onclick = () => this.setResearch(false); row.appendChild(t);
      }
      row.hidden = !row.children.length;
    }
    // כרטיס מחקר חי: שלב, חוקרים, מקורות (מתוך היעד), זמן שרץ, טוקנים ואחוז מהמנוי — מתעדכן מהשרת; לחיצה = מסך המחקר המלא
    researchCard(id, question) {
      const c = el('div', 'research-card live'); c.dataset.researchId = id;
      c.innerHTML = '<span class="rc-ic">🔬</span><span class="rc-body"><span class="rc-top"><b class="rc-title">מחקר</b><span class="rc-phase">⏳ מתחיל…</span></span><small class="rc-q"></small><span class="rc-bar"><i></i></span><span class="rc-stats"></span></span><button class="btn-ghost">פתח את המחקר ▸</button>';
      c.querySelector('.rc-q').textContent = question ? question.slice(0, 160) : 'לחץ כדי לראות את התהליך, התוצאות והמקורות';
      c.querySelector('button').onclick = () => { if (App.agents && App.agents.openResearch) App.agents.openResearch(id); else App.view.show('research'); };
      c.onclick = e => { if (!e.target.closest('button')) c.querySelector('button').click(); };
      const PH = { planning: ['🧭', 'מתכנן'], researching: ['🔎', 'חוקרים עובדים'], writing: ['✍️', 'כותב את הדוח'], done: ['✅', 'הסתיים'], error: ['❌', 'שגיאה'], stopped: ['⏹', 'נעצר'], interrupted: ['⏸', 'נקטע'], refused: ['🚫', 'סורב'] };
      const TERM = /^(done|error|stopped|interrupted|refused)$/;
      let s = null, timer = null, seen = false;
      const paint = () => {
        if (!s) return;
        const ph = PH[s.status] || ['⏳', s.status || ''], subs = s.subquestions || [], fin = subs.filter(x => /^(done|error)$/.test(x.status)).length;
        c.querySelector('.rc-title').textContent = s.title || 'מחקר';
        const pe = c.querySelector('.rc-phase'); pe.textContent = `${ph[0]} ${ph[1]}`; pe.title = s.phase || ''; c.dataset.status = s.status || '';
        if (s.question && !question) c.querySelector('.rc-q').textContent = String(s.question).slice(0, 160);
        const o = s.opts || {}, goal = o.maxSources || o.minSources || 0, n = s.sourcesCount || 0;
        const prog = TERM.test(s.status || '') ? 1 : s.status === 'writing' ? 0.92 : goal ? Math.min(0.9, n / goal * 0.9) : subs.length ? 0.1 + 0.8 * fin / subs.length : 0.05;
        c.querySelector('.rc-bar i').style.width = Math.round(prog * 100) + '%';
        const secs = ((s.endedAt || Date.now()) - (s.startedAt || Date.now()));
        const u = fmt.use(s.tokens ? { ...s.tokens, pct: s.pct, costUSD: s.costUSD } : null);
        const st = [`👥 ${subs.length ? `${fin}/${subs.length} חוקרים` : 'חוקרים: עוד לא'}`, `📄 ${n}${goal ? '/' + goal : ''} מקורות`, `⏱ ${fmt.clock(secs)}`];
        if (u.text) st.push(u.text);
        const se = c.querySelector('.rc-stats'); se.textContent = st.join(' · '); se.title = u.title || '';
        if (TERM.test(s.status || '')) { clearInterval(timer); timer = null; }
      };
      const onUpd = d => { if (!d || d.id !== id) return; s = d; seen = true; paint(); if (!TERM.test(d.status || '') && !timer) timer = setInterval(() => { if (!c.isConnected && seen) { stop(); return; } paint(); }, 1000); };
      const off = App.on('research:update', onUpd);
      const stop = () => { clearInterval(timer); timer = null; off(); };
      // מצב התחלתי (גם לשיחה שנפתחה מההיסטוריה) — ואז האירועים החיים
      App.api('/api/research/' + id).then(r => { if (r && r.research && r.research.summary && (!s || !seen)) onUpd(r.research.summary); }).catch(() => { c.querySelector('.rc-phase').textContent = '— לא נמצא'; });
      setTimeout(() => { if (!c.isConnected) stop(); }, 120000);
      return c;
    }
    // כרטיס מחקר אחרי כרטיס הכלי research_start (בזמן אמת ובשיחה שנטענת מההיסטוריה) — פעם אחת לכל מחקר
    researchCardAfter(card, output) {
      const m = String(output || '').match(/\bid: ([\w-]{6,})/); if (!m) return;
      const root = card.closest('.messages') || this.$messages; if (root && root.querySelector(`.research-card[data-research-id="${m[1]}"]`)) return;
      card.after(this.researchCard(m[1], ''));
    }
    // ----- פקודות / בעברית: בחירה = תגית (לא טקסט בצ׳אט) -----
    async commandList() { if (!this._cmds) { try { this._cmds = (await App.api('/api/commands')).commands || []; } catch { this._cmds = []; } } return this._cmds.filter(c => !SLASH_HIDE.has(c.name)); }
    async slashMenu(btn) {
      const r = btn.getBoundingClientRect(); const cmds = await this.commandList();
      if (!cmds.length) { App.toast('פקודות זמינות במצב מנוי'); return; }
      this.openSlash(cmds, '', r.left, r.top);
    }
    async slashAuto() {
      const v = this.$input.value;
      if (!v.startsWith('/') || v.includes('\n')) { this.closeSlash(); return; }
      const cmds = await this.commandList(); const r = this.$input.getBoundingClientRect();
      this.openSlash(cmds, v.slice(1).split(/\s/)[0], r.left, r.top, true);
    }
    // תפריט / עם תיבת חיפוש למעלה: מסנן את כל הפקודות (שם + הסבר בעברית + התיאור באנגלית), בלי תלות באותיות גדולות/קטנות.
    // נפתח מהכפתור: הסמן בתיבת החיפוש. נפתח מהקלדת / בתיבה: הסמן נשאר בתיבה, וההקלדה שם ממשיכה לסנן כמו קודם.
    openSlash(cmds, filter, x, y, fromInput) {
      this.closeSlash();
      const matches = q => { q = String(q || '').trim().toLowerCase().replace(/^\//, ''); return c => { if (!q) return true; const h = slashHe(c); return [c.name, h.title, h.desc, c.description].some(s => String(s || '').toLowerCase().includes(q)); }; };
      if (fromInput && !cmds.some(matches(filter))) return;
      const pop = el('div', 'slash-pop');
      pop.innerHTML = '<div class="sl-find"><input type="search" class="text-input sl-search" placeholder="חיפוש פקודה, Skill או כלי…" autocomplete="off" spellcheck="false"><button type="button" class="sl-find-x" title="נקה חיפוש" hidden>✕</button></div><div class="sl-list"></div>';
      const search = pop.querySelector('.sl-search'), clear = pop.querySelector('.sl-find-x'), listEl = pop.querySelector('.sl-list');
      const pick = c => { if (fromInput) { this.$input.value = ''; this.autoGrow(); } this.closeSlash(); if (c.name === 'deep-research') this.setResearch(true); else this.setCmd(c); };
      const render = () => {
        listEl.innerHTML = ''; clear.hidden = !search.value;
        const list = cmds.filter(matches(search.value));
        list.forEach((c, i) => {
          const h = slashHe(c), it = el('button', 'sl-item' + (i === 0 ? ' sel' : ''));
          it.innerHTML = '<span class="sl-name"></span><span class="sl-desc"></span>'; it.querySelector('.sl-name').textContent = h.title; it.querySelector('.sl-desc').textContent = h.desc; it.title = '/' + c.name; it.dataset.cmd = c.name;
          it.onclick = () => pick(c);
          listEl.appendChild(it);
        });
        if (!list.length) listEl.appendChild(el('div', 'sl-empty', 'לא נמצאו פקודות'));
        listEl.scrollTop = 0;
      };
      search.value = fromInput ? filter : ''; render();
      search.addEventListener('input', render);
      search.addEventListener('keydown', e => {
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); this.slashMove(e.key === 'ArrowDown' ? 1 : -1); }
        else if (e.key === 'Enter' && !e.isComposing) { e.preventDefault(); const s = pop.querySelector('.sl-item.sel'); if (s) s.click(); }
        else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); this.closeSlash(); this.$input.focus(); }
      });
      clear.onclick = () => { search.value = ''; render(); search.focus(); };
      document.body.appendChild(pop);
      const hgt = pop.offsetHeight; pop.style.height = hgt + 'px'; // גובה קבוע: החיפוש לא מזיז את התפריט
      pop.style.left = Math.max(8, Math.min(x, innerWidth - pop.offsetWidth - 8)) + 'px'; pop.style.top = Math.max(8, y - hgt - 8) + 'px';
      this._slash = pop;
      if (!fromInput) search.focus();
      setTimeout(() => { if (this._slash !== pop) return; this._slashOut = ev => { if (!ev.target.closest('.slash-pop')) this.closeSlash(); }; document.addEventListener('mousedown', this._slashOut); }, 0);
    }
    closeSlash() { if (this._slash) { this._slash.remove(); this._slash = null; } if (this._slashOut) { document.removeEventListener('mousedown', this._slashOut); this._slashOut = null; } }
    slashMove(d) { const items = [...document.querySelectorAll('.slash-pop .sl-item')]; if (!items.length) return; let i = items.findIndex(x => x.classList.contains('sel')); items[i] && items[i].classList.remove('sel'); i = (i + d + items.length) % items.length; items[i].classList.add('sel'); items[i].scrollIntoView({ block: 'nearest' }); }

    // ----- קבצים מצורפים -----
    autoGrow() { const t = this.$input; t.style.height = 'auto'; t.style.height = Math.min(t.scrollHeight, 260) + 'px'; }
    async pasteImage() { try { const items = await navigator.clipboard.read(); for (const it of items) for (const t of it.types) if (t.startsWith('image/')) { const b = await it.getType(t); await this.addFiles([new File([b], 'clipboard.png', { type: t })]); return; } App.toast('אין תמונה בלוח'); } catch (e) { App.toast('אי אפשר לקרוא את הלוח: ' + e.message); } }
    async addFiles(files) {
      for (const f of files) {
        try {
          if (/^image\/(png|jpeg|gif|webp)$/.test(f.type)) {
            if (f.size > 5 * 1024 * 1024) { App.toast(`${f.name}: תמונה גדולה מ-5MB`); continue; }
            const url = await readAs(f, 'url');
            this.attachments.push({ kind: 'image', name: f.name || 'image.png', mediaType: f.type, data: url.split(',')[1], preview: url });
          } else if (f.type.startsWith('text/') || TEXT_EXT.test(f.name)) {
            if (f.size > 2 * 1024 * 1024) { App.toast(`${f.name}: קובץ טקסט גדול מ-2MB`); continue; }
            this.attachments.push({ kind: 'text', name: f.name, text: await readAs(f, 'text') });
          } else App.toast(`${f.name}: סוג קובץ לא נתמך. אפשר לבקש מ-Claude לפתוח אותו לפי הנתיב.`, 4000);
        } catch { App.toast('שגיאה בקריאת ' + f.name); }
      }
      this.renderAttachments();
    }
    renderAttachments() {
      const box = this.$attach; box.innerHTML = '';
      this.attachments.forEach((a, i) => {
        const chip = el('div', 'att-chip');
        if (a.kind === 'image') { const img = el('img'); img.src = a.preview; chip.appendChild(img); } else chip.appendChild(el('span', '', '📄'));
        const name = el('span', 'name'); name.textContent = a.name; chip.appendChild(name);
        const x = el('button', '', '✕'); x.onclick = () => { this.attachments.splice(i, 1); this.renderAttachments(); }; chip.appendChild(x);
        box.appendChild(chip);
      });
    }
    insertText(text) {
      const t = this.$input, s = t.selectionStart == null ? t.value.length : t.selectionStart, e2 = t.selectionEnd == null ? s : t.selectionEnd;
      const pre = t.value.slice(0, s), post = t.value.slice(e2);
      const sp = pre && !/\s$/.test(pre) ? ' ' : '';
      t.value = pre + sp + text + ' ' + post; const pos = (pre + sp + text + ' ').length; t.setSelectionRange(pos, pos); this.autoGrow(); t.focus();
    }

    // ===================== הודעות =====================
    nearBottom(px = 150) { const m = this.$messages; return m.scrollHeight - m.scrollTop - m.clientHeight < px; }
    // עקיבה אחרי תחתית השיחה: "דבוק לתחתית" (stick) נקבע לפי המשתמש — גלילה למעלה משחררת, גלילה חזרה לתחתית (או שליחת הודעה) תופסת שוב.
    // קודם: נבדק "ליד התחתית (150px)" בכל אירוע — כרטיס כלי / פסקה גדולה שנוספו בבת אחת (>150px) ניתקו את העקיבה והשיחה נשארה למעלה.
    unstick(ms = 1500) { this.stick = false; this._noStickUntil = Date.now() + ms; }
    scrollDown(force) { const m = this.$messages; if (force) { this.stick = true; this._noStickUntil = 0; } if (force || this.stick) { this._prog = true; m.scrollTop = m.scrollHeight; requestAnimationFrame(() => { this._prog = false; }); } }
    // גלילה: כרטיס כלי (pre עם גלילה פנימית) שנראה רק חלקית — הגלגלת מגלגלת את השיחה ולא נבלעת בתוך הבלוק; ובקצה הבלוק היא ממשיכה מיד לשיחה
    setupScrolling() {
      const m = this.$messages; this.stick = true;
      const toBottom = () => { if (this._moQ) return; this._moQ = requestAnimationFrame(() => { this._moQ = 0; if (!this.stick) return; this._prog = true; m.scrollTop = m.scrollHeight; requestAnimationFrame(() => { this._prog = false; }); }); };
      // רק פעולה של המשתמש משחררת את ההיצמדות לתחתית: גלגלת למעלה, גרירת פס הגלילה, מקלדת, מגע.
      // גלילה שהדפדפן עושה לבד (הודעות מחוץ למסך מקבלות את הגובה האמיתי שלהן — content-visibility — ועיגון גלילה) לא משחררת:
      // קודם היא שחררה, ואחרי רענון באמצע ריצה התשובה הסופית נשארה 2,599px מתחת למסך.
      const userFor = ms => { this._userScroll = true; clearTimeout(this._usT); this._usT = setTimeout(() => { this._userScroll = false; }, ms); };
      // עכבר לחוץ בתוך השיחה: גרירת פס הגלילה, או סימון טקסט שגולל את השיחה — של המשתמש
      m.addEventListener('pointerdown', e => { if (e.button !== 0) return; this._userScroll = true; clearTimeout(this._usT); const up = () => { window.removeEventListener('pointerup', up, true); window.removeEventListener('pointercancel', up, true); userFor(250); }; window.addEventListener('pointerup', up, true); window.addEventListener('pointercancel', up, true); }, true);
      m.addEventListener('touchmove', () => userFor(400), { passive: true });
      document.addEventListener('keydown', e => { if (/^(PageUp|PageDown|ArrowUp|ArrowDown|Home|End| )$/.test(e.key) && !(e.target && e.target.closest && e.target.closest('input,textarea,select,[contenteditable="true"]')) && this.pane && this.pane.classList.contains('active')) userFor(500); }, true);
      m.addEventListener('scroll', () => {
        if (this._prog) return;
        // קפיצה מכוונת (לחיצה על ההודעה הנעוצה, Ctrl+F, סבב מעקב) מתחילה ליד התחתית — לא נצמדים מחדש באמצע התנועה שלה
        if (this.nearBottom(40)) { if (this._userScroll || Date.now() > (this._noStickUntil || 0)) this.stick = true; return; }
        if (this._userScroll) { this.stick = false; return; }
        if (this.stick) toBottom(); // הדפדפן הזיז — נשארים למטה
      }, { passive: true });
      // גובה של הודעה השתנה (תמונה נטענה, הודעה מחוץ למסך צוירה, כרטיס נפתח בסוף) — אם דבוקים לתחתית, נשארים בה
      const ro = new ResizeObserver(() => { if (this.stick) toBottom(); });
      // כל שינוי בתוכן השיחה (הודעה / כרטיס / פסקה שנוספו או עודכנו) כשהמשתמש "דבוק לתחתית" — גוללים לתחתית (פעם אחת לפריים)
      new MutationObserver(recs => {
        for (const r of recs) for (const n of r.addedNodes) if (n.nodeType === 1 && n.parentNode === m && n.classList.contains('msg')) ro.observe(n);
        if (this.stick) toBottom();
      }).observe(m, { childList: true, subtree: true, characterData: true });
      // פתיחת כרטיס ע"י המשתמש: לא קופצים לתחתית. פתיחה/סגירה אוטומטית (בלוק חשיבה שנסגר בסוף, שחזור אחרי רענון) לא משחררת
      m.addEventListener('click', e => { if (e.target && e.target.closest && e.target.closest('summary')) { this._userToggle = true; setTimeout(() => { this._userToggle = false; }, 400); } }, true);
      m.addEventListener('toggle', e => { if (!(e.target && e.target.tagName === 'DETAILS')) return; if (this._userToggle) this.stick = this.nearBottom(40); else if (this.stick) toBottom(); }, true);
      m.addEventListener('wheel', e => {
        if (e.deltaY < 0) this.stick = false;
        userFor(300);
        if (e.ctrlKey || !e.target || !e.target.closest) return;
        const pre = e.target.closest('.tool pre, .code-block pre, .rs-refuse-pre'); if (!pre) return;
        if (pre.scrollHeight <= pre.clientHeight + 1) return; // אין מה לגלול בפנים: ברירת המחדל (ממשיך לשיחה)
        const pr = pre.getBoundingClientRect(), mr = m.getBoundingClientRect();
        const fully = pr.top >= mr.top - 1 && pr.bottom <= mr.bottom + 1;
        const atEdge = (e.deltaY > 0 && pre.scrollTop + pre.clientHeight >= pre.scrollHeight - 1) || (e.deltaY < 0 && pre.scrollTop <= 0);
        if (!fully || atEdge) { e.preventDefault(); m.scrollTop += e.deltaMode === 1 ? e.deltaY * 40 : e.deltaMode === 2 ? e.deltaY * m.clientHeight : e.deltaY; }
      }, { passive: false });
    }
    // ----- ההודעה האחרונה שלי נצמדת למעלה בזמן גלילה; לחיצה עליה גוללת בדיוק אליה -----
    setupSticky() {
      // עטיפה בגובה 0 (sticky) — הפס צף מעל ההודעות ולא תופס מקום, כך שהופעה/היעלמות שלו לא מזיזה את התוכן
      const m = this.$messages, wrap = el('div', 'sticky-wrap'), s = this.$sticky = el('button', 'sticky-user'); s.type = 'button'; s.hidden = true;
      s.innerHTML = '<span class="su-ic">📌</span><span class="su-t"></span><span class="su-go">↑ אל ההודעה</span>';
      wrap.appendChild(s); m.insertBefore(wrap, m.firstChild);
      // לחיצה על הנעוצה: ההודעה מגיעה מתחת לפס הנעוץ (שלא יסתיר אותה), מתייצבת במקום, ומסומנת במסגרת
      s.onclick = async () => {
        const t = this._stickyTarget; if (!t || !t.isConnected) return; this.unstick(2500);
        // הרווח = מהקצה העליון של הרשימה עד הקצה התחתון של פס הנעוץ (+12) — לא רק גובה הפס (הפס יושב מעט מתחת לקצה)
        const pinBottom = () => s.hidden ? 0 : Math.max(0, s.getBoundingClientRect().bottom - m.getBoundingClientRect().top);
        const gap = () => pinBottom() + 12;
        const want = () => m.scrollTop + (t.getBoundingClientRect().top - m.getBoundingClientRect().top) - gap();
        this._holdLoad = Date.now() + 1200;
        m.scrollTo({ top: Math.max(0, want()), behavior: 'smooth' });
        t.classList.remove('flash'); void t.offsetWidth; t.classList.add('flash');
        await new Promise(r => setTimeout(r, 450));
        for (let k = 0; k < 6; k++) { const d = (t.getBoundingClientRect().top - m.getBoundingClientRect().top) - gap(); if (Math.abs(d) < 3) break; m.scrollTop += d; await new Promise(r => requestAnimationFrame(r)); }
      };
      const upd = () => {
        this._suQ = 0;
        const mr = m.getBoundingClientRect(); let target = null;
        // סבבי מעקב אוטומטיים אינם "ההודעה שלי"; ההודעה שפתחה מעקב — כן
        for (const u of m.querySelectorAll('.msg.user:not(.watch-round):not(.from-claude):not(.from-auto)')) { const r = u.getBoundingClientRect(); if (r.top < mr.top + 4) target = u; else break; }
        // מוצגת רק כשההודעה עצמה כבר גללה למעלה ואינה נראית
        if (target && target.getBoundingClientRect().bottom > mr.top + 8) target = null;
        if (target !== this._stickyTarget) { this._stickyTarget = target; if (target) { const b0 = target.querySelector('.body'), b = b0 && b0.cloneNode(true); if (b) b.querySelectorAll('.watch-pill').forEach(x => x.remove()); s.querySelector('.su-t').textContent = ((b && b.textContent) || '').replace(/\s+/g, ' ').trim().slice(0, 220) || '(הודעה)'; } }
        s.hidden = !target;
      };
      m.addEventListener('scroll', () => { if (!this._suQ) this._suQ = requestAnimationFrame(upd); }, { passive: true });
      new MutationObserver(() => { if (!this._suQ) this._suQ = requestAnimationFrame(upd); }).observe(m, { childList: true });
    }
    // ----- שורת הכלים של התיבה: תמיד שורה אחת שנכנסת כולה בתיבה, בכל רוחב -----
    // מדרגות (מצטברות, f1..f8): RC מקוצר → "מעקב" אייקון → שאר התוויות אייקון → ריווח קטן → המודל מתקצר →
    // כלים משניים עוברים ל-⋯ → "/" והשעון יורדים → מצב הרשאות והכתבה עוברים ל-⋯ → "+" עובר ל-⋯. החישוב כולל תמיד מקום לסטטוס+עצור,
    // כך שכלום לא קופץ כשריצה מתחילה או נגמרת.
    setupBarFit() {
      const bar = this.pane.querySelector('.composer-bar.cb2'), MAX = 9;
      const ws = bar.querySelector('.work-status'), st = bar.querySelector('.btn-stop'), mw = bar.querySelector('.cb-model-wrap');
      const setL = L => { for (let i = 1; i <= MAX; i++) bar.classList.toggle('f' + i, i <= L); this._fit = L; };
      const need = L => {
        const g = parseFloat(getComputedStyle(bar).columnGap) || 0; let w = 0, n = 0;
        for (const c of bar.children) {
          if (!c.getClientRects().length) continue; const cs = getComputedStyle(c); if (cs.position === 'absolute') continue;
          n++;
          if (c.classList.contains('cb-spacer')) { w += 4; continue; }
          if (c === mw) { w += L >= 5 ? (parseFloat(cs.minWidth) || 36) : Math.min(c.getBoundingClientRect().width, 96); continue; } // תווית מודל ארוכה מתקצרת (…) לפני שכלים עוברים ל-⋯
          w += c.getBoundingClientRect().width + (parseFloat(cs.marginLeft) || 0) + (parseFloat(cs.marginRight) || 0);
        }
        return w + g * Math.max(0, n - 1);
      };
      let raf = 0, mo = null;
      const fit = () => {
        raf = 0; if (!bar.isConnected || !bar.clientWidth) return;
        const h1 = ws.hidden, h2 = st.hidden; ws.hidden = false; st.hidden = false; mw.style.flex = '0 0 auto';
        const avail = bar.clientWidth; let L = 0;
        for (; L <= MAX; L++) { setL(L); if (need(L) <= avail + 0.5) break; }
        if (L > MAX) setL(MAX);
        ws.hidden = h1; st.hidden = h2; mw.style.flex = '';
        bar.querySelector('.cb-more').classList.toggle('dot', (this.agentList || []).length > 0 || !!this.remote);
        if (mo) mo.takeRecords();
      };
      this.fitBar = () => { if (!raf) raf = requestAnimationFrame(fit); };
      new ResizeObserver(this.fitBar).observe(bar);
      mo = new MutationObserver(recs => { if (recs.some(r => !ws.contains(r.target))) this.fitBar(); }); mo.observe(bar, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['hidden', 'class'] });
      document.fonts && document.fonts.ready.then(this.fitBar);
      this.fitBar();
    }
    // ----- ⑂ פורק: 3 אפשרויות — קוד · שיחה · חלון חדש -----
    forkMenu(msg, text, btn) {
      const r = btn.getBoundingClientRect();
      App.menu(r.left, r.bottom + 4, [
        { icon: '🗂', label: 'חזור לנקודת הקוד הזאת', hint: 'הקבצים', onClick: () => this.restoreCodeTo(msg, text) },
        { icon: '↩', label: 'חזור לנקודת השיחה הזאת', hint: 'Claude ישכח', onClick: () => this.rewindTo(msg, text, false) },
        { icon: '⑂', label: 'פתח מהנקודה הזאת בחלון חדש', hint: 'שיחה חדשה', onClick: () => this.forkTo(msg, text) }
      ]);
    }
    userOrdinal(msg) { return [...this.$messages.querySelectorAll('.msg.user')].indexOf(msg); }
    // חזור לנקודת הקוד: כל קובץ ש-Claude שינה מההודעה הזו והלאה חוזר למצבו לפני ההודעה (קובץ שהוא יצר — נמחק). השיחה לא משתנה
    async restoreCodeTo(msg, text) {
      if (!this.id) return;
      try {
        const body = { index: msg.dataset.idx != null ? +msg.dataset.idx : undefined, ordinal: this.userOrdinal(msg), text };
        const pv = await App.api('/api/conversations/' + this.id + '/code-preview', { method: 'POST', body });
        const files = pv.files || [];
        if (!files.length) { App.toast('🗂 הקבצים כבר במצב של הנקודה הזו — אין מה להחזיר', 3500); return; }
        const short = f => '⁦' + f.replace(/^.*[\\/]([^\\/]+[\\/][^\\/]+)$/, '…\\$1') + '⁩'; // נתיב משמאל לימין בתוך שורה עברית (בלי שיתהפך)
        const lines = files.slice(0, 12).map(f => (f.action === 'delete' ? '🗑 יימחק (לא היה קיים אז): ' : f.action === 'skip' ? '⚠ גדול מדי, לא יוחזר: ' : f.action === 'create' ? '↺ ייווצר מחדש: ' : '↺ יחזור: ') + short(f.file)).join('\n') + (files.length > 12 ? `\n…ועוד ${files.length - 12}` : '');
        const ok = await App.confirm(`להחזיר את הקבצים למצב שלפני ההודעה הזו?\n${lines}\n\nהשיחה עצמה לא תשתנה.`, { okText: '🗂 החזר את הקוד', danger: true, title: '🗂 חזרה לנקודת הקוד' });
        if (!ok) return;
        const r = await App.api('/api/conversations/' + this.id + '/restore-code', { method: 'POST', body });
        const n = (r.restored || []).length, d = (r.deleted || []).length, s = (r.skipped || []).length;
        const cnt = (k, one, many) => k === 1 ? one : k + ' ' + many;
        const parts = [n && cnt(n, 'קובץ אחד הוחזר', 'קבצים הוחזרו'), d && cnt(d, 'קובץ אחד נמחק', 'קבצים נמחקו'), s && cnt(s, 'קובץ אחד דולג (גדול מדי)', 'קבצים דולגו')].filter(Boolean);
        App.toast('🗂 הקוד חזר לנקודה — ' + parts.join(', '), 4000);
        if (App.explorer && App.explorer.refresh) try { App.explorer.refresh(); } catch { }
      } catch (e) { App.toast('❌ ' + e.message, 4000); }
    }
    async rewindTo(msg, text, resend) {
      if (!this.id) return;
      const after = (() => { let n = 0, e = msg; while ((e = e.nextElementSibling)) if (e.classList.contains('msg')) n++; return n; })();
      const ok = await App.confirm(`לחזור לנקודה הזו באותה שיחה?\nההודעה הזו ו-${after} ההודעות שאחריה יימחקו, ו-Claude ישכח אותן לגמרי — כאילו לא קרו.${resend ? '\nאחרי זה ההודעה תישלח שוב מיד.' : '\nהטקסט של ההודעה יחזור לתיבת הכתיבה.'}\n(הקבצים לא משתנים. אם צריך גם להחזיר את הקוד — בחר קודם "חזור לנקודת הקוד הזאת")`, { okText: resend ? '🔁 חזור ושלח שוב' : '↩ חזור לנקודת השיחה', danger: true, title: '↩ חזרה לנקודת השיחה' });
      if (!ok) return;
      try {
        const r = await App.api('/api/conversations/' + this.id + '/rewind', { method: 'POST', body: { index: msg.dataset.idx != null ? +msg.dataset.idx : undefined, ordinal: this.userOrdinal(msg), text } });
        for (let i = 0; i < 30 && this.running; i++) await sleep(100);
        await this.load();
        const t = r.text != null ? r.text : text;
        App.toast(`↩ חזרת לנקודה — ${after + 1} הודעות נמחקו מהשיחה ו-Claude שכח אותן`, 3200);
        if (resend && t) this.send(t); else if (t) { this.$input.value = t; this.autoGrow(); this.$input.focus(); }
      } catch (e) { App.toast('❌ ' + e.message, 4000); }
    }
    async forkTo(msg, text) {
      if (!this.id) return;
      try {
        const r = await App.api('/api/conversations/' + this.id + '/fork', { method: 'POST', body: { index: msg.dataset.idx != null ? +msg.dataset.idx : undefined, ordinal: this.userOrdinal(msg), text } });
        await App.chats.openConversation(r.id);
        const c = App.chats.byConvId(r.id); if (c && r.text) { c.$input.value = r.text; c.autoGrow(); c.$input.focus(); }
        App.toast(`⑂ נפתחה שיחה חדשה ${r.code || ''} עם השיחה עד הנקודה הזו (השיחה המקורית לא השתנתה)`, 3500);
      } catch (e) { App.toast('❌ ' + e.message, 4000); }
    }
    daySeparator(ts) { if (!ts) return; const day = new Date(ts).toDateString(); if (day === this.lastDay) return; this.lastDay = day; this.$messages.appendChild(el('div', 'day-sep', fmt.day(ts))); }
    clearMessages() { this.$messages.querySelectorAll('.msg, .notice, .day-sep, .refusal-card, .ask-card, .hist-sentinel').forEach(n => n.remove()); this.renderStart = 0; this._detached = false; if (this._toEnd) this._toEnd.hidden = true; this.lastDay = null; this.toolCards = {}; this.live = null; }

    userBubble(content, ts, opts = {}) {
      this.daySeparator(ts);
      const msg = el('div', 'msg user'), body = el('div', 'body'), thumbs = el('div', 'att-thumbs');
      let text = '';
      for (const b of content) {
        if (b.type === 'image') { const img = el('img', 'zoomable'); img.onload = () => { if (img.naturalHeight > img.naturalWidth * 3) img.classList.add('tall'); }; /* צילום ארוך לגובה: תצוגה מקדימה מהחלק העליון (לחיצה — כולו) */ img.src = `data:${b.source.media_type};base64,${b.source.data}`; img.title = 'לחץ להגדלה · קליק ימני: העתקה'; thumbs.appendChild(img); }
        else if (b.type === 'text' && b.hidden) continue;
        else if (b.type === 'text' && b.text.startsWith('<attached_file')) { const name = (b.text.match(/name="([^"]*)"/) || [])[1] || 'file'; thumbs.appendChild(el('span', 'att-file', '📄 ' + esc(name))); }
        else if (b.type === 'text') text += (text ? '\n' : '') + b.text;
      }
      // סבב של מעקב: שורה קצרה ומסומנת במקום הודעה (ההוראות המלאות נסתרות); ההודעה שפתחה מעקב — תג מעל הטקסט
      const wm = opts.watch || (/^🔁 מעקב (W\d+) «([^»]*)» · סבב (\d+)$/.test(text.trim()) ? (([, id, name, n]) => ({ id, name, n: +n }))(text.trim().match(/^🔁 מעקב (W\d+) «([^»]*)» · סבב (\d+)$/)) : null);
      if (wm) {
        msg.dataset.watchRound = wm.id + '-' + wm.n; msg.classList.add('watch-msg'); if (!wm.created) msg.classList.add('watch-round');
        const wp = el('button', 'watch-pill'); wp.type = 'button';
        wp.innerHTML = '<span class="wp-ic">⏱</span><span class="wp-t"></span>';
        // התווית (REQUESTS-10): "הודעה אוטומטית ממעקב <שם מודגש> | W1 | סבב 3" — בלי "לא ממך" (הצבע והתווית כבר אומרים ממי)
        const wt = wp.querySelector('.wp-t');
        if (wm.created) wt.textContent = `נפתח מעקב ${wm.id} «${wm.name}» — זה סבב 1`;
        else { wt.append('הודעה אוטומטית ממעקב '); const wb = el('b'); wb.textContent = wm.name || wm.id; wb.dir = /[\u0590-\u05FF]/.test(wb.textContent) ? 'rtl' : 'auto'; wt.append(wb, ` | ${wm.id} | סבב ${wm.n}` + (wm.followup && wm.audit ? ' | הבודק העצמאי ביקש בדיקה חוזרת' : wm.followup ? ' | דרישה לשורת סטטוס' : '')); }
        if (wm.followup) wp.querySelector('.wp-ic').textContent = '↩️';
        wp.title = 'לחיצה: חלון המעקב'; wp.onclick = () => App.watches && App.watches.focusDock(this, wm.id);
        body.appendChild(wp);
        if (!wm.created) { text = ''; msg.classList.add('mt-watch'); } // ההודעה שלי שפתחה מעקב = שלי (בצבע שלי); כל סבב / דרישה = הודעה אוטומטית
      }
      // הודעה שאינה ממך (Claude אחר · מנוע המחקר · תזרים · מעקב): צבע משלה (נבחר בהגדרות → "צבעי הודעות שאינן שלך") ותווית שאומרת ממי ולמה — אי אפשר לטעות ולחשוב שאתה כתבת אותה
      // תוויות (REQUESTS-10): "<סמל> הודעה … <שם מודגש> | פרט | פרט" — בלי "לא ממך"
      const pill = (cls, parts) => { const p = el('div', cls); for (const x of parts) { if (x == null || x === '') continue; if (typeof x === 'object') { const b = el('b'); b.textContent = x.b; b.dir = /[\u0590-\u05FF]/.test(String(x.b)) ? 'rtl' : 'auto'; p.append(b); } else p.append(x); } return p; };
      if (opts.flow) { msg.classList.add('mt-flow'); const f = opts.flow; body.appendChild(pill('flow-pill from-pill', ['⚙ הודעה אוטומטית מתזרים ', { b: f.flowName || 'תזרים' }, ` | שלב ${f.no}/${f.total}`, f.stepName ? ' — ' + f.stepName : ''])); }
      if (opts.from === 'research' || opts.from === 'flow' || opts.flow) msg.classList.add('from-auto');
      if (opts.from === 'flow' && !opts.flow) msg.classList.add('mt-flow');
      if (opts.from === 'research') {
        msg.classList.add('mt-research'); const ri = opts.fromInfo || {};
        // שם המחקר המלא + האם הסתיים בהצלחה (מהשרת; בהודעות ישנות — מהטקסט "המחקר «…» הסתיים")
        const tm = /המחקר «([^»]+)» הסתיים(?::\s*([^\n]*)| בלי דוח)?/.exec(text || ''), rname = ri.title || (tm && tm[1]) || '';
        const okR = ri.ok != null ? ri.ok : tm ? !/בלי דוח/.test(tm[0]) : null;
        const fr = pill('from-pill', ['🔬 הודעה אוטומטית ממנוע המחקר - מחקר שהפעלת הסתיים, ו-Claude ממשיך איתו']);
        if (rname || okR != null) { const d2 = pill('rp-desc', [rname ? { b: rname } : '', okR == null ? '' : okR ? ' | ✅ הסתיים בהצלחה' + (ri.sources != null ? ` · ${ri.sources} מקורות` : '') + (ri.secs != null ? ` · ${ri.secs} שנ'` : '') : ' | ❌ הסתיים בלי דוח' + (ri.status ? ' (' + ri.status + ')' : '')]); fr.appendChild(d2); }
        fr.title = 'מנוע המחקר שלח את זה כשהמחקר הסתיים, כדי ש-Claude יקרא את הדוח וימשיך במשימה'; body.appendChild(fr);
      }
      else if (opts.from && opts.from !== 'flow') {
        msg.classList.add('from-claude', 'mt-claude');
        const fi = opts.fromInfo || {}, code = fi.code || (opts.from !== 'claude' ? opts.from : '');
        let title = fi.title || ''; if (!title && code && App.projects && App.projects.convByCode) { try { const cv = App.projects.convByCode(code); if (cv) title = cv.title || ''; } catch { } }
        // "🤖 הודעה מ- <שם הצ'אט מודגש> | שיחה J692 | במחשב itamar" (REQUESTS-10)
        const fr = pill('from-pill from-claude-pill', ['🤖 הודעה מ- ', title ? { b: title } : 'Claude אחר', code ? ' | שיחה ' + code : '', fi.machine ? ' | במחשב ' + fi.machine : '', fi.approved ? ' | ✋ אישרת אותה' : fi.trust === 'open' ? ' | 🔓 בסמכות שלך' : '']);
        fr.title = 'Claude בשיחה אחרת שלח את ההודעה הזו (chat_send). Claude כאן יודע שהיא לא ממך.' + (fi.trust === 'open' ? ' לפי ההגדרות שלך (הרשאות → תקשורת בין Claude-ים: פתוח לגמרי) היא בסמכות שלך — Claude מבצע אותה כאילו אתה כתבת.' : fi.approved ? ' אישרת אותה בעצמך לפני שנשלחה.' : '');
        if (code && App.projects && App.projects.convByCode) fr.onclick = () => { try { const cv = App.projects.convByCode(code); if (cv && App.projects.openConversation) App.projects.openConversation(cv.id); } catch { } };
        body.appendChild(fr);
      }
      if (thumbs.children.length) body.appendChild(thumbs);
      if (opts.cmd) { const ct = el('span', 'cmd-pill'); ct.textContent = '/ ' + (window.SLASH_HE[opts.cmd] ? window.SLASH_HE[opts.cmd][0] : opts.cmd); body.appendChild(ct); if (text) body.appendChild(document.createTextNode(' ')); }
      body.appendChild(document.createTextNode(text));
      const time = el('div', 'msg-time'); time.textContent = ts ? '🕒 ' + fmt.time(ts) : '';
      if (opts.queued) { time.appendChild(el('span', 'queued-tag', '⏳ ממתין: Claude יקרא את זה בצעד הבא')); msg.dataset.queueId = opts.queued; }
      if (opts.injected) time.appendChild(el('span', 'queued-tag', '➕ נוספה בזמן עבודה'));
      const acts = el('div', 'msg-actions');
      const copy = el('button', '', '📋 העתק'); copy.onclick = () => App.copyText(text);
      const edit = el('button', '', '✏️ ערוך ושלח שוב'); edit.onclick = () => { this.$input.value = text; this.autoGrow(); this.$input.focus(); };
      const fork = el('button', 'fork-btn', '⑂ פורק'); fork.title = 'פורק: חזור לנקודת הקוד · חזור לנקודת השיחה · פתח מהנקודה בחלון חדש'; fork.onclick = e => this.forkMenu(msg, text, e.currentTarget);
      const notMine = /\bmt-(claude|research|flow|watch)\b/.test(msg.className); if (notMine) msg.dataset.msgType = (msg.className.match(/\bmt-(claude|research|flow|watch)\b/) || [])[1];
      if (opts.archived) acts.append(copy); else if (notMine) acts.append(copy, fork); else acts.append(copy, edit, fork); // הודעה מההיסטוריה שהועתקה: רק להעתיק · הודעה שאינה ממך: בלי "ערוך ושלח שוב" (זה לא הטקסט שלך)
      const wrap = el('div', 'user-wrap'); body.style.maxWidth = '100%';
      wrap.append(body, time, acts); msg.appendChild(wrap); this.$messages.appendChild(msg);
      return msg;
    }
    assistantBubble(ts) {
      this.daySeparator(ts);
      const msg = el('div', 'msg assistant'); msg.appendChild(el('div', 'avatar', '✳'));
      const body = el('div', 'body'); msg.appendChild(body);
      const time = el('div', 'msg-time'), acts = el('div', 'msg-actions');
      const copy = el('button', '', '📋 העתק תשובה');
      copy.onclick = () => App.copyText([...body.querySelectorAll(':scope > .md')].map(m => m.dataset.raw || '').join('\n\n'));
      acts.appendChild(copy); body.append(time, acts); this.$messages.appendChild(msg);
      return { msg, body, time, acts, current: null, currentType: null, typing: null, start: ts || Date.now(), model: null };
    }
    addBlock(a, node) { a.body.insertBefore(node, a.time); }
    setTyping(a, on) {
      if (on && !a.typing) { a.typing = el('div', 'typing', '<span></span><span></span><span></span>'); this.addBlock(a, a.typing); }
      if (!on && a.typing) { a.typing.remove(); a.typing = null; }
      if (on && a.typing) a.body.insertBefore(a.typing, a.time);
    }
    setBubbleTime(a, endTs, model) {
      if (model) a.model = model;
      // טווח הזמן משמאל לימין (התחלה → סוף) גם בממשק בעברית; הפורמט לפי הגדרות הצ'אט (12/24 שעות, שניות)
      a.time.innerHTML = ''; a.time.appendChild(document.createTextNode('🕒 '));
      const rng = document.createElement('bdi'); rng.dir = 'ltr'; rng.className = 'tm-range'; rng.textContent = fmt.time(a.start) + (endTs ? ' → ' + fmt.time(endTs) : ''); a.time.appendChild(rng);
      if (endTs) a.time.appendChild(document.createTextNode(' · ' + fmt.dur(endTs - a.start)));
      if (a.model) a.time.appendChild(el('span', 'model-tag', esc(App.modelLabel(a.model))));
      if (a.turnUse) { const u = fmt.use(a.turnUse); if (u.text) { const s = el('span', 'turn-use', esc(u.text)); s.title = u.title; a.time.appendChild(s); } }
      if (endTs || a !== this.live) this.markFinal(a);
    }
    // הטקסט האחרון של התור = הסיכום של Claude (מוצג בבועה / ברקע מודגש לפי הגדרות → צ'אט)
    markFinal(a) {
      const mds = [...a.body.children].filter(n => n.classList && n.classList.contains('md'));
      mds.forEach(n => n.classList.remove('final'));
      const last = mds[mds.length - 1];
      if (last && last.textContent.trim()) last.classList.add('final');
      a.msg.classList.toggle('had-tools', !!a.body.querySelector(':scope > .tool'));
    }
    newTextBlock(a) { const md = el('div', 'md cursor'); md.dataset.raw = ''; this.addBlock(a, md); a.current = md; a.currentType = 'text'; }
    // תשובה שנפסלה כי לא עמדה בהוראות (Stop hook) — מקופלת; התשובה שנכתבה מחדש מוצגת רגיל אחריה
    rejectedBlock(text, reason) {
      const d = el('details', 'rejected-ans'); d.innerHTML = '<summary>⛔ תשובה שנפסלה לפי ההוראות — נכתבה מחדש <small></small></summary><div class="md"></div>';
      d.querySelector('small').textContent = reason && reason !== true ? '(' + reason + ')' : ''; const md = d.querySelector('.md'); md.innerHTML = renderMarkdown(text); md.dataset.raw = text;
      return d;
    }
    rejectLive(a, reason) {
      if (!a) return; this.finishBlocks(a);
      const kids = [...a.body.children], lastTool = kids.map(n => n.classList.contains('tool')).lastIndexOf(true);
      for (const n of kids.slice(lastTool + 1)) if (n.classList.contains('md') && !n.closest('.rejected-ans')) { const r = this.rejectedBlock(n.dataset.raw || n.textContent, reason); n.replaceWith(r); }
      a.current = null; a.currentType = null; this.setTyping(a, true);
    }
    thinkingBlock(text, ms, live) {
      const d = el('details', 'thinking' + (live ? ' live' : ''));
      d.innerHTML = `<summary><span class="t-title">${live ? '🧠 חושב...' : '🧠 חשב'}</span><span class="t-clock">${fmt.clock(ms || 0)}</span></summary><div class="content"></div>`;
      d.querySelector('.content').textContent = text || ''; d.dataset.start = Date.now() - (ms || 0);
      if (live) { d.open = true; this.liveThinking.add(d); }
      return d;
    }
    newThinkingBlock(a) { const d = this.thinkingBlock('', 0, true); this.addBlock(a, d); a.current = d; a.currentType = 'thinking'; }
    stopThinking(d) {
      if (!this.liveThinking.has(d)) return;
      this.liveThinking.delete(d); d.classList.remove('live');
      d.querySelector('.t-title').textContent = '🧠 חשב'; d.querySelector('.t-clock').textContent = fmt.dur(Date.now() - Number(d.dataset.start));
      if (!d.querySelector('.content').textContent.trim()) d.querySelector('.content').textContent = '(Claude חשב, אבל המודל לא החזיר את תוכן החשיבה)';
      d.open = false;
    }
    setWaiting(a, info) { this.clearWaiting(a); a.wait = { start: Date.now(), ctx: (info && info.context) || 0, compactAt: (info && info.compactAt) || 150000 }; a.waitEl = el('div', 'wait-line'); this.addBlock(a, a.waitEl); this.updateWaiting(a); }
    clearWaiting(a) { if (a && a.waitEl) { a.waitEl.remove(); a.waitEl = null; } if (a) a.wait = null; }
    updateWaiting(a) {
      if (!a || !a.wait || !a.waitEl) return;
      const ms = Date.now() - a.wait.start; const txt = `⏳ ממתין ל-Claude · ${fmt.clock(ms)}`;
      a.waitEl.textContent = txt;
    }
    tick() {
      for (const d of this.liveThinking) d.querySelector('.t-clock').textContent = fmt.clock(Date.now() - Number(d.dataset.start));
      if (this.live) this.updateWaiting(this.live);
      if (this.running) this.syncWork();
    }
    renderLater(md) { if (this._rt) return; this._rt = requestAnimationFrame(() => { this._rt = null; md.innerHTML = renderMarkdown(md.dataset.raw); this.scrollDown(); }); }
    finishBlocks(a) {
      a.body.querySelectorAll('.md.cursor').forEach(m => { m.classList.remove('cursor'); m.innerHTML = renderMarkdown(m.dataset.raw); });
      a.body.querySelectorAll('.thinking.live').forEach(d => this.stopThinking(d)); this.setTyping(a, false);
    }

    // ----- כרטיסי כלים (אייקון לפי סוג: Bash כחול, CMD חלון שחור, PowerShell...) -----
    toolCard(id, name) {
      const info = infoOf(name), card = el('details', 'tool running' + (TASKS.has(name) ? ' sub-task' : ''));
      card.innerHTML = `<summary><span class="t-icon">${toolIcon(name, {})}</span><span class="t-label">${esc(info.label)} <code></code></span><span class="t-time"></span><span class="t-status">⏳ עובד...</span></summary><div class="t-detail"></div>`;
      card.dataset.name = name; card.dataset.start = Date.now(); card.dataset.toolId = id || '';
      if (id) this.toolCards[id] = card;
      return card;
    }
    setToolInput(card, input) {
      const name = card.dataset.name, info = infoOf(name); input = input || {};
      const arg = String(info.arg(input) || '').split('\n')[0];
      const codeEl = card.querySelector('.t-label code');
      codeEl.textContent = arg.length > 110 ? arg.slice(0, 110) + '…' : arg;
      const tp = App.paths && toolPath(name, input);
      if (tp) {
        // הנתיב נחתך מההתחלה כשאין מקום (…\תיקייה\קובץ.png) — שם הקובץ תמיד נראה, כמו ב-VS Code
        const fill = (node, p) => { node.textContent = ''; const b = document.createElement('bdi'); b.dir = 'ltr'; b.textContent = p.length > 180 ? p.slice(0, 3) + '…' + p.slice(-170) : p; node.appendChild(b); };
        card.classList.add('has-path');
        if (tp.inLabel) { fill(codeEl, tp.path); App.paths.mark(codeEl, tp.path, this.workingDir); }
        else { let chip = card.querySelector('.t-pathchip'); if (!chip) { chip = el('code', 't-pathchip'); card.querySelector('.t-label').appendChild(chip); } fill(chip, tp.path); App.paths.mark(chip, tp.path, this.workingDir); }
      }
      card.querySelector('.t-icon').innerHTML = toolIcon(name, input);
      const sh = shellOf(name, input);
      if (sh && !card.querySelector('.shell-badge')) card.querySelector('.t-label').appendChild(el('span', 'shell-badge', sh));
      let shown;
      if (name === 'run_command' || name === 'Bash' || name === 'PowerShell') shown = (input.command || '') + (input.cwd ? `\n\n(cwd: ${input.cwd})` : '') + (input.description ? `\n\n# ${input.description}` : '');
      else if (name === 'write_file' || name === 'Write') shown = `${P(input)}\n${'-'.repeat(40)}\n${input.content || ''}`;
      else if (name === 'edit_file') shown = `${input.path}\n\n--- old ---\n${input.old_text}\n\n+++ new +++\n${input.new_text}`;
      else if (name === 'Edit') shown = `${P(input)}\n\n--- old ---\n${input.old_string}\n\n+++ new +++\n${input.new_string}`;
      else shown = JSON.stringify(input, null, 2);
      const det = card.querySelector('.t-detail'); const old = det.querySelector('.t-in'); if (old) old.remove();
      const sec = el('div', 't-section t-in', '<div class="t-section-title">קלט</div><pre></pre>'); sec.querySelector('pre').textContent = shown; det.prepend(sec);
      if (TASKS.has(name) && App.agents && App.agents.decorateToolCard && !card.dataset.deco) { card.dataset.deco = '1'; try { App.agents.decorateToolCard(card, { toolId: card.dataset.toolId, name, convId: this.id, input }); } catch { } }
    }
    setToolResult(card, output, isError, ms, ts) {
      card.classList.remove('running'); card.classList.add(isError ? 'err' : 'ok');
      card.querySelector('.t-status').textContent = isError ? '❌ שגיאה' : '✅ בוצע';
      const dur = ms != null ? ms : (Date.now() - Number(card.dataset.start || Date.now()));
      card.querySelector('.t-time').textContent = (ts ? fmt.time(ts) + ' · ' : '') + fmt.dur(dur);
      const sec = el('div', 't-section', '<div class="t-section-title">תוצאה</div><pre></pre>'); sec.querySelector('pre').textContent = output;
      if (App.paths && output) { try { App.paths.linkifyPre(sec.querySelector('pre'), this.workingDir, RESULT_LINES_TOOLS.has(card.dataset.name) ? 'lines' : 'any'); } catch { } }
      card.querySelector('.t-detail').appendChild(sec);
      const bar = card.querySelector('.approve-bar'); if (bar) bar.remove();
      // בציור מההיסטוריה התוצאה נקבעת לפני שהכרטיס נכנס לרשימה — מכניסים את כרטיס המחקר רגע אחרי
      if (!isError && /(^|__)research_start$/.test(card.dataset.name || '')) { const go = () => { try { this.researchCardAfter(card, output); } catch { } }; if (card.parentNode) go(); else queueMicrotask(go); }
    }

    // ----- ציור שיחה שמורה (ציר זמן) -----
    // ----- היסטוריה: שיחה ארוכה מוצגת בחלון (הסוף), והחלקים הקודמים נטענים בגלילה למעלה; Ctrl+F קופץ לכל נקודה -----
    // offset = המיקום של ההודעה הראשונה ברשימה בתוך כל השיחה; total = כמה הודעות יש בשיחה; archived = כמה מהן היסטוריה שהועתקה
    renderHistory(messages, opts = {}) {
      this.clearMessages();
      const offset = opts.offset || 0;
      this.msgTotal = opts.total != null ? opts.total : offset + messages.length; this._archived = opts.archived || 0; this._detached = false;
      let start = 0;
      if (messages.length > HIST_FULL) start = alignTurnLocal(messages, messages.length - HIST_TAIL);
      this._older = start > 0 ? { list: messages.slice(0, start), offset } : null;
      this._results = {}; addResults(this._results, messages);
      this.renderStart = offset + start; this.renderEnd = offset + messages.length;
      this.renderMessages(messages.slice(start), offset + start);
      this.updateHistEdges();
      this.scrollDown(true);
    }
    renderMessages(messages, base) {
      const results = this._results || {};
      // סבבי מעקב שהפעולות שלהם מוצגות "רק בחלון המעקב": לא נכנסים לצ'אט בכלל (Claude עדיין יודע אותם — הם בשיחה שלו)
      const dockIds = new Set(((App.watches && App.watches.list && App.watches.list()) || []).filter(w => w.actionsInDock && w.convId === this.id).map(w => w.id));
      let a = null, skipRound = false;
      messages.forEach((m, k) => {
        const idx = base + k;
        const content = Array.isArray(m.content) ? m.content : [{ type: 'text', text: String(m.content) }];
        // "רק כאן": גם סבב 1 (ההודעה שפתחה את המעקב) — הכל בחלון המעקב
        if (m.role === 'user' && isTurnStart(m)) { skipRound = !!(m.watch && dockIds.has(m.watch.id) && !(m.watch.created && m.injected)); this._roundHidden = skipRound; /* הודעה שפתחה מעקב ונכנסה באמצע ריצה אחרת שלך — נשארת (אחריה ממשיכה התשובה לבקשה הקודמת) */ if (skipRound) { if (a) this.setBubbleTime(a, a.end, a.model); a = null; return; } }
        if (skipRound) return;
        if (m.role === 'user') {
          if (m.auto) return;
          const visible = content.filter(b => b.type !== 'tool_result' && !(b.type === 'text' && b.hidden));
          if (visible.length) { if (a) this.setBubbleTime(a, a.end, a.model); const ub = this.userBubble(visible, m.ts, { injected: m.injected, cmd: m.cmd, flow: m.flow, from: m.from, fromInfo: m.fromInfo, watch: m.watch, archived: idx < (this._archived || 0) }); ub.dataset.idx = idx; a = null; if (m.research && this.researchId) { this.$messages.appendChild(this.researchCard(this.researchId, '')); } }
          return;
        }
        const add = node => { node.dataset.idx = idx; this.addBlock(a, node); };
        if (content.length === 1 && content[0].type === 'text' && /^\((no response|…)\)$/.test(content[0].text)) {
          if (!a) a = this.assistantBubble(m.ts);
          add(el('div', 'notice', '⚠️ לא התקבלה תשובה: מסנן הבטיחות של המודל חסם את הבקשה בשקט.')); return;
        }
        if (!a) { a = this.assistantBubble(m.ts); a.msg.dataset.idx = idx; }
        if (m.model) a.model = m.model; if (m.doneAt) a.end = m.doneAt; if (m.turnUsage) a.turnUse = m.turnUsage;
        let ti = 0;
        for (const b of content) {
          if (b.type === 'text' && b.rejected) add(this.rejectedBlock(b.text, b.rejected));
          else if (b.type === 'text') { const md = el('div', 'md', renderMarkdown(b.text)); md.dataset.raw = b.text; add(md); }
          else if (b.type === 'thinking') {
            const ms = (m.thinkingMs || [])[ti++] || 0;
            if (cfgShowThinking() || ms) add(this.thinkingBlock(b.thinking || '(Claude חשב, אבל המודל לא החזיר את תוכן החשיבה)', ms, false));
          } else if (b.type === 'tool_use') {
            const card = this.toolCard(b.id, b.name); this.setToolInput(card, b.input || {});
            const r = results[b.id];
            if (r) this.setToolResult(card, typeof r.content === 'string' ? r.content : JSON.stringify(r.content), r.is_error, r.ms, r.ts); else this.setToolResult(card, '(no result)', true);
            add(card);
          } else if (b.type === 'fallback') add(el('div', 'notice info', `🛡️ מסנן הבטיחות של ${esc(App.modelLabel(b.from && b.from.model))} חסם, והבקשה עברה אוטומטית ל-${esc(App.modelLabel(b.to && b.to.model))}`));
          else if (b.type === 'compaction') add(el('div', 'notice info', '♾️ השיחה הישנה סוכמה אוטומטית, והשיחה ממשיכה בלי מגבלת אורך'));
          else if (b.type === 'refusal_notice') add(this.refusalCard(b, k === messages.length - 1));
          else if (b.type === 'local_notice') add(b.info ? el('div', 'notice info import-notice', esc(b.text).replace(/\n/g, '<br>')) : el('div', 'notice error', '❌ ' + esc(b.text)));
        }
      });
      if (a) this.setBubbleTime(a, a.end, a.model);
    }
    // קצוות החלון: למעלה — טעינה אוטומטית כשמתקרבים; למטה (אחרי קפיצה מחיפוש) — טעינה קדימה + כפתור "לסוף"
    updateHistEdges() {
      const m = this.$messages;
      // גם לפי הגלילה עצמה (לא רק IntersectionObserver, שלא יורה שוב כשנקודת הטעינה נשארת בטווח)
      if (!this._histScroll) { this._histScroll = true; m.addEventListener('scroll', () => { if (Date.now() < (this._holdLoad || 0)) return; if (this.renderStart > 0 && m.scrollTop < 1500) this.loadOlder(); if (this._detached && m.scrollHeight - m.scrollTop - m.clientHeight < 1500) this.loadNewer(); }, { passive: true }); }
      if (this.renderStart > 0) {
        if (!this._topSent) {
          this._topSent = el('div', 'hist-sentinel', '<span></span><span></span><span></span>');
          this._topIO = new IntersectionObserver(es => { if (Date.now() >= (this._holdLoad || 0) && es.some(e => e.isIntersecting)) this.loadOlder(); }, { root: m, rootMargin: '900px 0px 0px 0px' });
        }
        const first = [...m.children].find(n => n !== this.$welcome && n !== this._topSent);
        if (this._topSent.parentNode !== m || this._topSent.nextSibling !== first) m.insertBefore(this._topSent, first || null);
        this._topIO.observe(this._topSent);
      } else if (this._topSent) { this._topIO.unobserve(this._topSent); this._topSent.remove(); }
      if (this._detached) {
        if (!this._botSent) {
          this._botSent = el('div', 'hist-sentinel', '<span></span><span></span><span></span>');
          this._botIO = new IntersectionObserver(es => { if (Date.now() >= (this._holdLoad || 0) && es.some(e => e.isIntersecting)) this.loadNewer(); }, { root: m, rootMargin: '0px 0px 900px 0px' });
        }
        m.appendChild(this._botSent); this._botIO.observe(this._botSent);
        if (!this._toEnd) { this._toEnd = el('button', 'hist-toend', '⬇'); this._toEnd.title = 'לסוף השיחה'; this._toEnd.onclick = () => this.load(); this.pane.appendChild(this._toEnd); }
        this._toEnd.hidden = false;
      } else {
        if (this._botSent) { this._botIO.unobserve(this._botSent); this._botSent.remove(); }
        if (this._toEnd) this._toEnd.hidden = true;
      }
    }
    async loadOlder() {
      if (this._loadingOlder || !(this.renderStart > 0)) return;
      this._loadingOlder = true;
      try {
        let list = null, from = 0;
        if (this._older && this._older.list.length) { const L = this._older.list, s = alignTurnLocal(L, Math.max(0, L.length - HIST_TAIL)); list = L.slice(s); from = this._older.offset + s; this._older.list = L.slice(0, s); }
        else if (this.id) { const r = await App.api('/api/conversations/' + this.id + '/messages?before=' + this.renderStart + '&limit=' + HIST_TAIL); list = r.messages; from = r.from; }
        if (!list || !list.length) { this.renderStart = 0; this.updateHistEdges(); return; }
        addResults(this._results, list);
        const real = this.$messages, prevH = real.scrollHeight, prevTop = real.scrollTop;
        // עוגן: הבלוק הראשון שנראה עכשיו — אחרי ההוספה למעלה הוא נשאר בדיוק באותו מקום על המסך
        const rt = real.getBoundingClientRect().top; const anchorEl = [...real.querySelectorAll('[data-idx]')].find(e => e.getBoundingClientRect().bottom > rt); const anchorTop = anchorEl ? anchorEl.getBoundingClientRect().top : null;
        const box = document.createElement('div'), lastDay = this.lastDay, live = this.live;
        this.$messages = box; this.lastDay = null;
        try { this.renderMessages(list, from); } finally { this.$messages = real; this.lastDay = lastDay; this.live = live; }
        const anchor = this._topSent && this._topSent.parentNode === real ? this._topSent.nextSibling : [...real.children].find(n => n !== this.$welcome);
        if (anchor && anchor.classList && anchor.classList.contains('day-sep') && box.querySelector('.day-sep') && [...box.querySelectorAll('.day-sep')].pop().textContent === anchor.textContent) anchor.remove();
        const anchor2 = this._topSent && this._topSent.parentNode === real ? this._topSent.nextSibling : [...real.children].find(n => n !== this.$welcome);
        while (box.firstChild) real.insertBefore(box.firstChild, anchor2 || null);
        this.renderStart = from;
        this._prog = true; real.scrollTop = prevTop + (real.scrollHeight - prevH);
        const fix = () => { if (anchorEl && anchorEl.isConnected && anchorTop != null) { const d = anchorEl.getBoundingClientRect().top - anchorTop; if (Math.abs(d) > 1) real.scrollTop += d; } };
        fix(); requestAnimationFrame(() => { fix(); requestAnimationFrame(() => { fix(); this._prog = false; }); });
        this.updateHistEdges();
      } catch (e) { App.toast('❌ ' + e.message); } finally { this._loadingOlder = false; }
    }
    async loadNewer() {
      if (this._loadingNewer || !this._detached || !this.id) return;
      this._loadingNewer = true;
      try {
        const r = await App.api('/api/conversations/' + this.id + '/messages?from=' + this.renderEnd + '&limit=' + HIST_TAIL);
        addResults(this._results, r.messages);
        if (this._botSent) this._botSent.remove();
        this.renderMessages(r.messages, r.from);
        this.renderEnd = r.to; this.msgTotal = r.total; this._detached = r.to < r.total;
        this.updateHistEdges();
      } catch (e) { App.toast('❌ ' + e.message); } finally { this._loadingNewer = false; }
    }
    // שיחה שגדלה מאוד בזמן עבודה: החלק הישן שעל המסך יוצא מהזיכרון (נטען שוב בגלילה למעלה) — הגלילה נשארת חלקה
    trimHistory() {
      if (this._detached || !this.stick || this.$messages.querySelectorAll('.msg').length < HIST_FULL * 1.5) return;
      const users = [...this.$messages.querySelectorAll('.msg.user[data-idx]')]; if (users.length < 40) return;
      const keepFrom = users[Math.max(0, users.length - 60)]; const cut = +keepFrom.dataset.idx; if (!(cut > this.renderStart)) return;
      for (const n of [...this.$messages.children]) { if (n === keepFrom) break; if (n === this.$welcome || n === this._topSent) continue; n.remove(); }
      this.renderStart = cut; this._older = null; this.updateHistEdges();
    }
    // ----- Ctrl+F: חיפוש בכל השיחה (כולל מה שלא על המסך) · ▲ ישן יותר · ▼ חדש יותר · Enter / Shift+Enter · Esc -----
    openFind() {
      if (!this._find) {
        const bar = el('div', 'find-bar');
        bar.innerHTML = '<input type="search" class="find-q" placeholder="חיפוש בשיחה"><span class="find-n"></span><button class="find-up" title="הקודם (Enter)">▲</button><button class="find-dn" title="הבא (Shift+Enter)">▼</button><button class="find-x" title="סגור (Esc)">✕</button>';
        this.pane.insertBefore(bar, this.$messages);
        const q = bar.querySelector('.find-q');
        let t = null; q.oninput = () => { clearTimeout(t); t = setTimeout(() => this.runFind(q.value), 220); };
        q.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); this.findStep(e.shiftKey ? 1 : -1); } else if (e.key === 'Escape') { e.preventDefault(); this.closeFind(); } };
        bar.querySelector('.find-up').onclick = () => this.findStep(-1); bar.querySelector('.find-dn').onclick = () => this.findStep(1); bar.querySelector('.find-x').onclick = () => this.closeFind();
        this._find = { bar, q, hits: [], cur: -1, text: '', seq: 0 };
      }
      this._find.bar.hidden = false; this._find.q.focus(); this._find.q.select();
      if (this._find.q.value.trim()) this.runFind(this._find.q.value);
    }
    closeFind() { if (!this._find) return; this._find.bar.hidden = true; this.clearMarks(); this._find.hits = []; this._find.cur = -1; this.$input.focus(); }
    async runFind(text) {
      const F = this._find; text = String(text || '').trim(); F.text = text; const my = ++F.seq;
      const n = F.bar.querySelector('.find-n');
      this.clearMarks();
      if (text.length < 2) { F.hits = []; F.cur = -1; n.textContent = ''; return; }
      let hits = [];
      try {
        if (this.id) hits = (await App.api('/api/conversations/' + this.id + '/search?q=' + encodeURIComponent(text))).hits || [];
        else hits = [...this.$messages.querySelectorAll('[data-idx]')].filter(e => e.textContent.toLowerCase().includes(text.toLowerCase())).map(e => ({ i: +e.dataset.idx }));
      } catch (e) { n.textContent = '❌'; return; }
      if (my !== F.seq) return;
      const seen = new Set(); F.hits = hits.filter(h => !seen.has(h.i) && seen.add(h.i)).sort((a, b) => a.i - b.i);
      if (!F.hits.length) { F.cur = -1; n.textContent = '0'; F.bar.classList.add('none'); return; }
      F.bar.classList.remove('none');
      await this.findGo(F.hits.length - 1); // מתחילים מהמופע האחרון (הכי חדש)
    }
    async findStep(d) { const F = this._find; if (!F || !F.hits.length) return; await this.findGo((F.cur + d + F.hits.length) % F.hits.length); }
    // קפיצות בתור — לחיצות מהירות על ▲▼ לא דורסות זו את זו
    findGo(k) { const F = this._find; F.cur = k; F.bar.querySelector('.find-n').textContent = (k + 1) + '/' + F.hits.length; F.q2 = (F.q2 || Promise.resolve()).then(() => this._findGo(k)).catch(() => { }); return F.q2; }
    async _findGo(k) {
      const F = this._find; if (F.cur !== k) return; const h = F.hits[k]; if (!h) return;
      this._holdLoad = Date.now() + 1500; // בזמן הקפיצה לא טוענים הודעות נוספות (זה היה מזיז את המסך)
      const node = await this.ensureIdx(h.i);
      if (!node || F.hits[F.cur] !== h) return;
      // כל החלקים של אותה הודעה (טקסט, כרטיסי כלים) מסומנים; כרטיס סגור שיש בו התאמה — נפתח
      const parts = [...this.$messages.querySelectorAll('[data-idx="' + h.i + '"]')];
      this.clearMarks();
      // קודם פותחים כרטיסים סגורים שיש בהם התאמה (הכרטיס ממלא את התוכן רגע אחרי הפתיחה), ורק אז מסמנים וממרכזים
      const tl = F.text.toLowerCase().replace(/\s+/g, ' '); let opened = false;
      for (const p of parts) for (const d of (p.tagName === 'DETAILS' ? [p] : []).concat([...p.querySelectorAll('details')])) if (!d.open && d.textContent.toLowerCase().replace(/\s+/g, ' ').includes(tl)) { d.open = true; opened = true; }
      if (opened) await new Promise(r => setTimeout(r, 120));
      if (F.hits[F.cur] !== h) return;
      let first = null;
      for (const p of parts) { const marks = this.markIn(p, F.text); if (marks.length && !first) first = marks[0]; }
      const target = first || parts[0];
      if (first) first.classList.add('cur'); else parts[0].classList.add('find-block'); // ההתאמה מפוצלת בין עיצובים — מסמנים את כל הבלוק
      this.unstick(2500); await this.centerOn(target);
      await new Promise(r => setTimeout(r, 200)); if (F.hits[F.cur] === h && target.isConnected) await this.centerOn(target); // בדיקה חוזרת אחרי שהכול התייצב
    }
    // גלילה למרכז שמתייצבת: הודעות שמעל מצוירות רק כשמגיעים אליהן ומשנות גובה — מתקנים עד שהמיקום יציב
    async centerOn(node) {
      const m = this.$messages, fr = () => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
      // הבלוקים שמכילים את ההתאמה מצוירים מיד (בלי דילוג של content-visibility), ובלוק עם גלילה פנימית (פלט של כלי) נגלל אליה
      for (let p = node; p && p !== m; p = p.parentElement) if (p.nodeType === 1) p.style.contentVisibility = 'visible';
      await fr();
      for (let p = node.parentElement; p && p !== m; p = p.parentElement) if (p.scrollHeight > p.clientHeight + 4 && /(auto|scroll)/.test(getComputedStyle(p).overflowY)) { const r = node.getBoundingClientRect(), pr = p.getBoundingClientRect(); p.scrollTop += (r.top - pr.top) - p.clientHeight / 2; }
      let stable = 0;
      for (let k = 0; k < 40 && stable < 3; k++) { // עד שהמיקום יציב 3 פריימים ברצף
        const r = node.getBoundingClientRect(), mr = m.getBoundingClientRect();
        const d = (r.top + r.bottom) / 2 - (mr.top + mr.bottom) / 2;
        if (Math.abs(d) < 4) stable++; else { stable = 0; this._prog = true; m.scrollTop += d; }
        await fr(); this._prog = false;
      }
      this._holdLoad = Date.now() + 400;
    }
    markIn(root, text) {
      // רווח בחיפוש = כל רווח / ירידת שורה בטקסט (כמו בחיפוש בשרת)
      const re = new RegExp(text.trim().split(/\s+/).map(w => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('\\s+'), 'gi');
      const out = [], w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, { acceptNode: n => (n.parentNode && /^(SCRIPT|STYLE|TEXTAREA|INPUT)$/.test(n.parentNode.nodeName)) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT });
      const nodes = []; let n; while ((n = w.nextNode())) { re.lastIndex = 0; if (n.nodeValue && re.test(n.nodeValue)) nodes.push(n); }
      for (const tn of nodes.slice(0, 300)) {
        const s = tn.nodeValue, frag = document.createDocumentFragment(); let last = 0, m; re.lastIndex = 0;
        while ((m = re.exec(s))) { if (!m[0]) { re.lastIndex++; continue; } frag.appendChild(document.createTextNode(s.slice(last, m.index))); const mk = document.createElement('mark'); mk.className = 'find-hit'; mk.textContent = m[0]; frag.appendChild(mk); out.push(mk); last = m.index + m[0].length; }
        frag.appendChild(document.createTextNode(s.slice(last))); tn.parentNode.replaceChild(frag, tn);
      }
      return out;
    }
    clearMarks() { for (const mk of [...this.$messages.querySelectorAll('mark.find-hit')]) { const p = mk.parentNode; p.replaceChild(document.createTextNode(mk.textContent), mk); p.normalize(); } this.$messages.querySelectorAll('.find-block').forEach(e => e.classList.remove('find-block')); }
    // קפיצה להודעה מסוימת (Ctrl+F): נטענת אם היא לא על המסך
    async ensureIdx(i) {
      const q = () => this.$messages.querySelector('[data-idx="' + i + '"]');
      let node = q(); if (node) return node;
      if (i < this.renderStart && this.renderStart - i <= 900) { while (!node && this.renderStart > i) { const b = this.renderStart; await this.loadOlder(); if (this.renderStart === b) break; node = q(); } if (node) return node; }
      if (!this.id) return null;
      const r = await App.api('/api/conversations/' + this.id + '/messages?from=' + Math.max(0, i - 30) + '&limit=200');
      this.clearMessages(); this._results = {}; addResults(this._results, r.messages); this._older = null;
      this.renderStart = r.from; this.renderEnd = r.to; this.msgTotal = r.total; this._archived = r.archived || this._archived; this._detached = r.to < r.total;
      this.renderMessages(r.messages, r.from); this.unstick(2500); this.updateHistEdges();
      return q();
    }
    refusalCard(info, isLast) {
      const card = el('div', 'refusal-card'), cat = info.category ? ` (קטגוריה: <b>${esc(info.category)}</b>)` : '';
      card.innerHTML = `<div class="rf-title">🛑 ${esc(info.modelName || App.modelLabel(info.model) || 'המודל')} סירב לענות: מסנן הבטיחות האוטומטי חסם את הבקשה${cat}</div>
        <div class="rf-body">זו חסימה של מסנן אוטומטי, ולא החלטה של Claude עצמו. היא קורית לפעמים גם בעבודה לגיטימית.${info.explanation ? `<div class="rf-expl">${esc(info.explanation)}</div>` : ''}
        ${info.suggested ? `<div class="rf-ask">👉 <b>כדי להמשיך את השיחה, החלף ל-${esc(info.suggestedName || App.modelLabel(info.suggested))}.</b> במודל הזה אין את המסנן הזה, וכל השיחה נשמרת.</div>` : '<div class="rf-ask">בחר מודל אחר מהרשימה, או נסח את הבקשה אחרת.</div>'}</div>`;
      if (info.suggested && isLast) {
        const bar = el('div', 'rf-actions'), go = el('button', 'btn-approve', `🔄 החלף ל-${esc(info.suggestedName || App.modelLabel(info.suggested))} והמשך`);
        go.onclick = async () => { const label0 = go.textContent; go.disabled = true; go.textContent = 'מחליף...'; if (!(await this.setChat({ model: info.suggested }, 'מודל: ' + (info.suggestedName || info.suggested)))) { go.disabled = false; go.textContent = label0; return; } /* ההחלפה לא נשמרה — לא ממשיכים במודל שחסם */ bar.remove(); card.classList.add('done'); card.appendChild(el('div', 'rf-done', `✅ הוחלף ל-${esc(info.suggestedName || info.suggested)}. ממשיך את השיחה...`)); await this.send('המשך בבקשה מאיפה שעצרת (עברתי למודל אחר כי המסנן של המודל הקודם חסם).'); };
        const stay = el('button', 'btn-deny', 'הישאר במודל הנוכחי'); stay.onclick = () => { bar.remove(); App.toast('נשארת במודל הנוכחי. אפשר לנסח את הבקשה אחרת'); };
        bar.append(go, stay); card.appendChild(bar);
      }
      return card;
    }
    showNotice(text, kind) {
      const n = el('div', 'notice' + (kind === 'error' ? ' error' : kind === 'info' ? ' info' : ''));
      n.textContent = (kind === 'error' ? '❌ ' : kind === 'info' ? 'ℹ️ ' : '⚠️ ') + text;
      if (this.live) this.addBlock(this.live, n); else this.$messages.appendChild(n);
      this.scrollDown(true); return n;
    }

    // ===================== ריצה =====================
    setRunning(on) {
      const changed = this.running !== on; this.running = on; if (on) this.runStart = this.runStart || Date.now(); else this.runStart = 0;
      this.$stop.hidden = !on; this.$work.hidden = !on; this.$composer.classList.toggle('busy', on); if (on) this.syncWork();
      this.$input.placeholder = this.watchNext ? 'כתוב כאן את המשימה של המעקב ושלח — Claude יבצע אותה בכל סבב…' : on ? 'Claude עובד… אפשר להוסיף הודעה' : 'כתוב ל-Claude מה לעשות…';
      renderTabs(); renderConvList(); if (changed) App.emit('chat:running', { chat: this, running: on });
    }
    // סטטוס הריצה בשורת הכלים: רק השעון מתעדכן (המבנה קבוע — כדי שהשורה לא תזוז)
    syncWork() { const t = fmt.clock(Date.now() - (this.runStart || Date.now())); this.$work.querySelector('.ws-time').textContent = t; this.$work.title = 'Claude עובד · ' + t; }

    async send(textOverride, opts = {}) {
      const text = (textOverride != null ? textOverride : this.$input.value).trim();
      if (!text && !this.attachments.length && !this.cmdTag) return;
      if (!hasAuth()) { App.settings && App.settings.open('account'); App.toast('קודם הגדר חיבור (מפתח API או כניסה לחשבון מנוי)'); return; }
      if (!App.state.config.model && App.state.config.accountMode !== 'subscription') { App.settings && App.settings.open('general'); App.toast('קודם בחר מודל'); return; }
      if (this._detached && this.id) await this.load(); // היית באמצע ההיסטוריה (אחרי חיפוש) — חוזרים לסוף לפני שליחה
      this._roundHidden = false; // הודעה שלך — התשובה מוצגת בצ'אט
      // שלחת בזמן הקלטה: המיקרופון נכבה יחד עם השליחה (מה שנשלח = מה שהיה בתיבה; שום טקסט לא ייכנס לתיבה אחרי השליחה)
      try { if (textOverride == null && window.Dictation && window.Dictation.stopForSend) window.Dictation.stopForSend(this); } catch { }
      this.closeSlash();
      const attachments = this.attachments; this.attachments = []; this.renderAttachments();
      this.$input.value = ''; this.autoGrow(); this.hideWelcome(); this.clearDraft();
      const preview = attachments.map(x => x.kind === 'image' ? { type: 'image', source: { media_type: x.mediaType, data: x.data } } : { type: 'text', text: `<attached_file name="${x.name}">` });
      if (text) preview.push({ type: 'text', text });
      const research = !!(opts.research || this.researchNext); const rsDepth = this.researchDepth || 'standard'; if (this.researchNext) this.setResearch(false);
      const cmd = this.cmdTag ? this.cmdTag.name : null; if (cmd) this.setCmd(null);
      const watch = text && this.watchNext ? this.watchNext : null; if (watch) { this.watchNext = null; this.renderTags(); }
      // מעקב "רק בחלון המעקב": המשימה לא נכנסת לצ'אט בכלל — סבב 1 רץ מיד בנפרד (גם אם Claude עובד עכשיו בצ'אט), והכל מוצג רק בחלון המעקב
      if (watch && watch.actionsInDock) {
        try {
          const body = { conversationId: this.id, text, attachments, watch, research, researchDepth: research ? rsDepth : App.state.config.researchDepth, command: cmd };
          if (!this.id) { if (this.projectId) body.projectId = this.projectId; if (this.folderId) body.folderId = this.folderId; body.settings = this.settings(); }
          const r = await App.api('/api/chat', { method: 'POST', body });
          if (!this.id) { this.pin = body.settings; this.draft = {}; this.id = r.conversationId; this.title = r.title || this.title; if (r.workingDir) this.workingDir = r.workingDir; if (r.projectId) this.projectId = r.projectId; if (r.code) this.code = r.code; renderTabs(); this.updateCwd(); loadConversations(); }
          if (r.watch && App.watches) App.watches.upsert(r.watch);
          App.toast('⏱ המעקב נפתח — סבב 1 רץ עכשיו בחלון המעקב בלבד; הצ\'אט נשאר נקי ואפשר להמשיך לדבר', 3400);
          setTimeout(() => { try { App.watches && App.watches.focusDock(this, r.watch && r.watch.id); } catch { } }, 250);
        } catch (e) { // לא נשלח: הכל חוזר כמו שהיה (המשימה, הקבצים, תגית המעקב) — שליחה חוזרת שוב פותחת מעקב, לא הודעה רגילה בצ'אט
          this.$input.value = text; this.autoGrow(); this.attachments = attachments; this.renderAttachments(); this.watchNext = watch; this.renderTags(); if (cmd && this.setCmd) try { this.setCmd(this.cmdTag || { name: cmd }); } catch { } if (research && this.setResearch) try { this.setResearch(true); } catch { } this.showNotice(e.message, 'error');
        }
        return;
      }
      // Claude באמצע עבודה: ההודעה מצטרפת למשימה הנוכחית
      if (this.running && this.id) {
        try {
          const r = await App.api('/api/chat', { method: 'POST', body: { conversationId: this.id, text, attachments, research, command: cmd, watch } });
          if (r.watch && App.watches) App.watches.upsert(r.watch);
          if (r.queued) { if (!this.$messages.querySelector(`[data-queue-id="${r.id}"]`)) { const b = this.userBubble(preview, r.ts, { queued: r.id, cmd }); if (this.live) this.$messages.insertBefore(b, this.live.msg.nextSibling); } this.scrollDown(true); App.toast('ההודעה נוספה: Claude יקרא אותה בצעד הבא שלו'); return; }
        } catch (e) { this.showNotice(e.message, 'error'); return; }
      }
      this.userBubble(preview, Date.now(), { cmd }); this.scrollDown(true);
      this.live = this.assistantBubble(Date.now()); this.setTyping(this.live, true); this.setRunning(true); this.scrollDown(true);
      try {
        const body = { conversationId: this.id, text, attachments, detach: true, research, command: cmd, researchDepth: research ? rsDepth : App.state.config.researchDepth, remote: this.remote, watch };
        if (!this.id) { if (this.projectId) body.projectId = this.projectId; if (this.folderId) body.folderId = this.folderId; body.settings = this.settings(); }
        const r = await App.api('/api/chat', { method: 'POST', body });
        if (!this.id && body.settings) { this.pin = body.settings; this.draft = {}; }
        this.id = r.conversationId || r.id; this.title = r.title || this.title; if (r.workingDir) this.workingDir = r.workingDir; if (r.projectId) this.projectId = r.projectId;
        if (r.watch && App.watches) App.watches.upsert(r.watch);
        renderTabs(); this.updateCwd(); loadConversations();
        this.attachLoop();
      } catch (e) {
        this.finishBlocks(this.live); this.showNotice(e.message, 'error'); this.live = null; this.setRunning(false);
      }
    }

    async stop() {
      if (!this.running || !this.id) return;
      App.emit('chat:userstop', { id: this.id });
      this.$stop.disabled = true; this.$stop.title = 'עוצר...';
      try { await App.api('/api/stop', { method: 'POST', body: { conversationId: this.id } }); } catch { }
      this.$stop.disabled = false; this.$stop.title = 'עצור את Claude (Esc)';
    }

    // חיבור לריצה בשרת (גם אחרי רענון / טאב אחר): snapshot → replay → live → done. מתחבר מחדש אם החיבור נופל
    // ===== טיוטה של תיבת הכתיבה (HOT-UPDATE-PLAN 0.6): נשמרת לכל צ'אט, חוזרת אחרי רענון / הפעלה מחדש, נמחקת בשליחה =====
    draftKey() { return 'draft:' + (this.id || 'new:' + (this.projectId || '')); }
    saveDraftSoon() { clearTimeout(this._draftT); this._draftT = setTimeout(() => { const v = this.$input ? this.$input.value : ''; if (v) ls.set(this.draftKey(), v); else ls.del(this.draftKey()); }, 300); }
    restoreDraft() { if (!this.$input || this.$input.value) return; const v = ls.get(this.draftKey()); if (v) { this.$input.value = v; try { this.autoGrow(); } catch { } } }
    clearDraft() { clearTimeout(this._draftT); ls.del(this.draftKey()); }

    async attachLoop() {
      if (this._attaching) return; this._attaching = true;
      const convId = this.id;
      try {
        while (!this.closed && this.id === convId) {
          const ac = this.abort = new AbortController(); let res, finished = false;
          try { res = await fetch('/api/attach?conv=' + encodeURIComponent(convId), { signal: ac.signal, cache: 'no-store' }); } catch (e) { if (ac.signal.aborted) break; await sleep(1500); continue; }
          if (!res.ok && res.status !== 503) break; // 503 = השרת מתחלף (detach) — מנסים שוב
          if (!res.ok) { await sleep(1000); continue; }
          try {
            await readSSE(res, (ev, d) => { if (ev === 'snapshot') this.onSnapshot(d); else { if (ev === 'done') finished = true; this.handleEvent(ev, d); } });
          } catch (e) { if (ac.signal.aborted) break; }
          if (finished) break;
          // השרת מתחלף / עולה מחדש: כשל רשת לא מסיים את הלולאה — מנסים כל שנייה עד 60 שניות. רק תשובה תקינה בלי השיחה מסיימת
          let r = null; const until = Date.now() + 60000;
          for (;;) { r = await App.api('/api/running').catch(() => null); if ((r && Array.isArray(r.running)) || this.closed || this.id !== convId || Date.now() > until) break; await sleep(1000); }
          if (!r || !Array.isArray(r.running) || !r.running.includes(convId)) break;
          await sleep(900);
        }
      } finally { this._attaching = false; this.abort = null; if (this.running && !this.closed) this.finalizeRun(); }
    }
    onSnapshot(s) {
      const conv = s.conv || {};
      this.title = conv.title || this.title; this.workingDir = conv.workingDir || this.workingDir; this.projectId = conv.projectId || null; this.code = conv.code || this.code; this.remote = this.remote || !!conv.remoteControl; this.syncRules(conv);
      if (conv.pin !== undefined) { this.pin = conv.pin || null; this.importedFrom = conv.importedFrom || null; this.syncControls(); }
      this.researchId = conv.researchId || null; { const A = (conv.archive && conv.archive.count) || 0; this.renderHistory(conv.messages || [], conv.msgOffset != null ? { offset: conv.msgOffset, total: conv.msgTotal, archived: A } : { offset: A, archived: A }); } this.hideWelcome(); this.showUsage(conv.usage); this.updateCwd(); renderTabs();
      for (const q of s.queued || []) { const b = this.userBubble(q.content, q.ts, { queued: q.id, from: q.from, fromInfo: q.fromInfo, watch: q.watch, flow: q.flow }); b.dataset.queueId = q.id; }
      if (s.running) {
        this.runStart = s.startedAt || Date.now(); this.setRunning(true);
        this.live = this.assistantBubble(Date.now()); this.live.start = s.startedAt || Date.now(); this.setTyping(this.live, true);
        for (const a of s.agents || []) App.emit('agent:update', a); for (const r of s.research || []) App.emit('research:update', r);
      } else this.setRunning(false);
      this.scrollDown(true);
    }
    finalizeRun() {
      const a = this.live;
      if (a) { this.clearWaiting(a); this.finishBlocks(a); a.body.querySelectorAll('.tool.running').forEach(c => this.setToolResult(c, 'בוטל', true)); this.setBubbleTime(a, Date.now(), a.model); if (!a.body.querySelector('.md, .tool, .thinking, .notice') || a.msg.classList.contains('watch-hidden')) a.msg.remove(); }
      document.querySelectorAll('.msg[data-queue-id] .queued-tag').forEach(t => { if (t.textContent.startsWith('⏳')) t.remove(); });
      this.live = null; this.setRunning(false); loadConversations();
      refreshBudget();
      try { this.trimHistory(); } catch { }
      if (this._reloadAfterRun) setTimeout(() => { if (this._reloadAfterRun && !this.running && !this.closed) { this._reloadAfterRun = false; this.load().catch(() => { }); } }, 300); // נמחק רק כשהטעינה באמת רצה
    }

    handleEvent(ev, d) {
      let a = this.live;
      if (!a) {
        if (!['done', 'usage', 'model', 'conversation', 'agent_update', 'research_update', 'rate_limit', 'user_queued', 'cli_init'].includes(ev)) { a = this.live = this.assistantBubble(Date.now()); if (this._roundHidden) a.msg.classList.add('watch-hidden'); this.setRunning(true); }
      }
      if (ev === 'api_wait' && a) { this.setTyping(a, false); this.setWaiting(a, d); this.scrollDown(); return; }
      if (a && !['usage', 'turn_usage', 'done', 'model', 'conversation', 'agent_update', 'research_update', 'rate_limit', 'user_queued', 'thinking_tokens', 'cli_init'].includes(ev)) this.clearWaiting(a);
      switch (ev) {
        case 'conversation': if (this.id !== d.id) { this.id = d.id; } loadConversations(); break;
        case 'model': if (a) { a.model = d.model; this.setBubbleTime(a, null, d.model); } break;
        case 'text_start': this.setTyping(a, false); this.newTextBlock(a); break;
        case 'text': if (a.currentType !== 'text') this.newTextBlock(a); a.current.dataset.raw += d.text; this.renderLater(a.current); break;
        case 'thinking_start': this.setTyping(a, false); if (cfgShowThinking()) this.newThinkingBlock(a); else { a.currentType = 'thinking-hidden'; this.setTyping(a, true); } break;
        case 'thinking': if (a.currentType === 'thinking') { a.current.querySelector('.content').textContent += d.text; this.scrollDown(); } break;
        case 'thinking_tokens': if (a && a.currentType === 'thinking' && a.current.classList.contains('live')) { const c = a.current.querySelector('.content'); if (!c.textContent.trim()) c.textContent = `חושב… (כ-${d.tokens} טוקנים של חשיבה)`; } break;
        case 'thinking_stop': if (a.currentType === 'thinking') { this.stopThinking(a.current); if (d.ms) a.current.querySelector('.t-clock').textContent = fmt.dur(d.ms); } break;
        case 'fallback': this.addBlock(a, el('div', 'notice info', `🛡️ מסנן הבטיחות של ${esc(App.modelLabel(d.from))} חסם את הבקשה (${esc(d.category || '')}), אז היא עוברת אוטומטית ל-${esc(App.modelLabel(d.to))}`)); a.model = d.to; this.setBubbleTime(a, null, d.to); break;
        case 'compaction': this.addBlock(a, el('div', 'notice info', '♾️ השיחה ארוכה: מסכם את החלק הישן כדי שהשיחה תמשיך בלי הגבלה...')); break;
        case 'tool_start': { this.setTyping(a, false); this.finishBlocks(a); const card = this.toolCard(d.id, d.name); this.addBlock(a, card); a.current = card; a.currentType = 'tool'; this.scrollDown(); break; }
        case 'server_tool_start': { this.setTyping(a, false); this.finishBlocks(a); const card = this.toolCard(d.id, d.name === 'web_search' ? 'WebSearch' : d.name === 'web_fetch' ? 'WebFetch' : d.name); this.addBlock(a, card); a.current = card; a.currentType = 'tool'; break; }
        case 'server_tool_input': { const c = this.toolCards[d.id]; if (c) this.setToolInput(c, d.input); break; }
        case 'server_tool_result': { const c = this.toolCards[d.id]; if (c) this.setToolResult(c, (d.items || []).map(i => `${i.title || ''}\n${i.url}`).join('\n\n') || (d.error ? 'שגיאה: ' + d.error : '(אין תוצאות)'), !!d.error, null, Date.now()); break; }
        case 'tool_input': { const c = this.toolCards[d.id]; if (c) { c.dataset.start = Date.now(); this.setToolInput(c, d.input); } break; }
        case 'approval_required': this.approvalCard(a, d); break;
        case 'approval_done': { const c = this.toolCards[d.id]; if (c) { const bar = c.querySelector('.approve-bar'); if (bar) bar.remove(); c.querySelector('.t-status').textContent = d.approved ? '⏳ עובד...' : '🚫 נדחה'; } document.querySelectorAll(`.ask-card[data-id="${d.id}"]`).forEach(x => x.remove()); break; }
        case 'ask_user': this.askCard(a, d); break;
        case 'tool_result': { const c = this.toolCards[d.id]; if (c) this.setToolResult(c, d.output, d.is_error, d.ms, Date.now()); this.setTyping(a, true); this.scrollDown(); break; }
        case 'user_queued': { if (!this.$messages.querySelector(`[data-queue-id="${d.id}"]`)) { const b = this.userBubble(d.content, d.ts, { queued: d.id, from: d.from, fromInfo: d.fromInfo, watch: d.watch, flow: d.flow }); if (this.live) this.$messages.insertBefore(b, this.live.msg.nextSibling); this.scrollDown(); } break; }
        case 'user_injected': {
          if (d.silent) break;
          this.finishBlocks(a); this.setBubbleTime(a, Date.now(), a.model);
          if (!a.body.querySelector('.md, .tool, .thinking, .notice')) a.msg.remove();
          let qb = this.$messages.querySelector(`.msg[data-queue-id="${d.id}"]`);
          if (!qb) qb = this.userBubble(d.content, d.ts, { injected: true, from: d.from, fromInfo: d.fromInfo });
          const tag = qb.querySelector('.queued-tag'); if (tag) tag.textContent = '✅ Claude קרא את זה';
          this.$messages.appendChild(qb);
          const nb = this.assistantBubble(Date.now()); nb.model = a.model; this.live = nb; this.setTyping(nb, true); this.scrollDown(true); break;
        }
        case 'usage': this.showUsage(d); App.emit('usage:changed', d); refreshBudget(); break;
        case 'turn_usage': if (a) { a.turnUse = d; this.setBubbleTime(a, Date.now(), a.model); } break;
        case 'answer_rejected': this.rejectLive(a, d.reason); break;
        case 'rate_limit': App.emit('usage:rate', d); break;
        case 'agent_update': App.emit('agent:update', d); break;
        case 'research_update': App.emit('research:update', d); break;
        case 'cli_init': this.cliInfo = d; break;
        case 'research_started': if (!d.fromTool) { this.addBlock(a, this.researchCard(d.id, d.question)); this.scrollDown(true); } break; // מ-research_start: הכרטיס נכנס מיד אחרי כרטיס הכלי
        case 'notice': {
          if (d.transient && this.pane.querySelector('.notice.transient')) { this.pane.querySelector('.notice.transient').textContent = '⚠️ ' + d.text; break; }
          const n = this.showNotice(d.text, d.info ? 'info' : 'warn'); if (d.transient) n.classList.add('transient'); break;
        }
        case 'refusal': this.finishBlocks(a); this.addBlock(a, this.refusalCard(d, true)); this.scrollDown(true); break;
        case 'stopped': this.finishBlocks(a); this.showNotice('Claude נעצר לפי בקשתך. אפשר להמשיך לכתוב, והשיחה ממשיכה מאותה נקודה.', 'info'); break;
        case 'queued_left': App.toast('ההודעה שהוספת נשמרה. שלח "תמשיך" כדי ש-Claude יענה עליה', 4000); break;
        case 'error': this.finishBlocks(a); this.showNotice(d.message, 'error'); break;
        case 'remote_control': this.remote = !!d.enabled; this.remoteUrl = d.url || null; this.syncControls(); break;
        case 'done': this.showUsage(d.usage); this.finalizeRun(); break;
      }
    }
    approvalCard(a, d) {
      const card = this.toolCards[d.id];
      const mk = host => {
        const plan = d.name === 'ExitPlanMode' && d.input && d.input.plan;
        const bar = el('div', 'approve-bar', `<span>${plan ? 'Claude מציע את התוכנית הזו. לאשר ולהמשיך?' : 'Claude רוצה לבצע את הפעולה הזו' + (d.title ? ': ' + esc(d.title) : '') + '. לאשר?'}</span>`);
        const ok = el('button', 'btn-approve', '✔ אשר'), no = el('button', 'btn-deny', '✖ דחה');
        const answer = (approved, always) => { bar.remove(); App.api('/api/approve', { method: 'POST', body: { requestId: d.requestId, approved, always: !!always } }); };
        ok.onclick = () => answer(true); no.onclick = () => answer(false);
        bar.append(ok); if (d.suggestions) { const al = el('button', 'btn-ghost', '✔ אשר תמיד'); al.onclick = () => answer(true, true); bar.append(al); } bar.append(no);
        host.appendChild(bar);
        if (plan) { const pm = el('div', 'md plan-md', renderMarkdown(plan)); host.insertBefore(pm, bar); }
        return bar;
      };
      if (card) { card.open = true; card.querySelector('.t-status').textContent = '✋ ממתין לאישור'; mk(card); }
      else { const box = el('div', 'tool err approval-float', `<summary style="padding:8px 12px">✋ ${esc(infoOf(d.name || '').label)}: ${esc(infoOf(d.name || '').arg(d.input || {}))}</summary>`); mk(box); this.addBlock(a, box); }
      this.scrollDown(true); App.emit('chat:attention', { chat: this });
    }
    askCard(a, d) {
      const card = el('div', 'ask-card'); card.dataset.id = d.id;
      const answers = {};
      (d.questions || []).forEach((q, qi) => {
        const box = el('div', 'ask-q'); box.innerHTML = `<div class="ask-h">${esc(q.header || '')}</div><div class="ask-t">${esc(q.question || '')}</div>`;
        const opts = el('div', 'ask-opts');
        (q.options || []).forEach(o => {
          const b = el('button', 'ask-opt'); b.innerHTML = `<b>${esc(o.label)}</b>${o.description ? `<small>${esc(o.description)}</small>` : ''}`;
          b.onclick = () => {
            if (q.multiSelect) { b.classList.toggle('on'); const sel = [...opts.querySelectorAll('.ask-opt.on')].map(x => x.querySelector('b').textContent); answers[q.question] = sel.join(', '); }
            else { opts.querySelectorAll('.ask-opt').forEach(x => x.classList.remove('on')); b.classList.add('on'); answers[q.question] = o.label; }
          };
          opts.appendChild(b);
        });
        const other = el('input', 'text-input'); other.placeholder = 'או כתוב תשובה אחרת…'; other.oninput = () => { if (other.value.trim()) { opts.querySelectorAll('.ask-opt').forEach(x => x.classList.remove('on')); answers[q.question] = other.value.trim(); } };
        box.append(opts, other); card.appendChild(box);
      });
      const bar = el('div', 'approve-bar'); const send = el('button', 'btn-approve', '✔ שלח תשובות'); const skip = el('button', 'btn-deny', 'דלג');
      send.onclick = () => { App.api('/api/approve', { method: 'POST', body: { requestId: d.requestId, approved: true, answers } }); card.remove(); };
      skip.onclick = () => { App.api('/api/approve', { method: 'POST', body: { requestId: d.requestId, approved: false, message: 'The user skipped the questions.' } }); card.remove(); };
      bar.append(send, skip); card.appendChild(bar); this.addBlock(a, card); this.scrollDown(true); App.emit('chat:attention', { chat: this });
    }

    // ===================== טעינת שיחה שמורה =====================
    async load() {
      if (!this.id) { this.loaded = true; return; }
      try {
        const conv = await App.api('/api/conversations/' + this.id);
        this.title = conv.title || this.title; this.workingDir = conv.workingDir || this.workingDir; this.projectId = conv.projectId || null; this.code = conv.code || this.code; this.remote = !!conv.remoteControl; this.syncRules(conv);
        this.pin = conv.pin || null; this.role = conv.role || null; this.managedBy = conv.managedBy || null; this.importedFrom = conv.importedFrom || null; this.syncControls();
        this.loaded = true; this.researchId = conv.researchId || null; this.hideWelcome(); this.renderHistory(conv.messages || [], { offset: conv.msgOffset || 0, total: conv.msgTotal, archived: (conv.archive && conv.archive.count) || 0 }); this.showUsage(conv.usage); this.updateCwd();
        this.restoreDraft();
        if (conv.running) this.attachLoop();
      } catch (e) { App.toast('לא הצלחתי לפתוח: ' + e.message); this.id = null; this.loaded = true; }
      renderTabs();
    }
    destroy() { this.closed = true; try { this.abort && this.abort.abort(); } catch { } this.pane.remove(); }
  }

  const TASKS = new Set(['agent', 'Agent', 'Task', 'deep_research']);
  const TEXT_EXT = /\.(txt|md|csv|json|js|ts|jsx|tsx|py|html|css|xml|yml|yaml|ini|log|sql|sh|ps1|bat|java|c|cpp|h|cs|go|rs|php|rb|kt|swift|vue|svelte|env|toml|cfg|conf)$/i;
  function shellOf(name, input) { if (name === 'Bash') return 'bash'; if (name === 'PowerShell') return 'powershell'; if (name === 'run_command') return (input && input.shell) || (/win/i.test(navigator.platform) ? 'powershell' : 'bash'); return ''; }
  const readAs = (file, how) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(r.error); how === 'text' ? r.readAsText(file) : r.readAsDataURL(file); });
  const cfgShowThinking = () => !App.state.config || App.state.config.showThinking !== false;
  const hasAuth = () => { const c = App.state.config; return !!(c && (c.accountMode === 'subscription' ? c.cliLoggedIn !== false : c.hasApiKey)); };
  async function readSSE(res, onEvent) {
    const reader = res.body.getReader(), dec = new TextDecoder(); let buf = '';
    while (true) {
      const { value, done } = await reader.read(); if (done) break;
      buf += dec.decode(value, { stream: true }); let i;
      while ((i = buf.indexOf('\n\n')) !== -1) {
        const raw = buf.slice(0, i); buf = buf.slice(i + 2);
        const ev = (raw.match(/^event: (.*)$/m) || [])[1], line = (raw.match(/^data: (.*)$/m) || [])[1];
        if (ev && line) { try { onEvent(ev, JSON.parse(line)); } catch (e) { console.error('[sse]', e); } }
      }
    }
  }

  // ===================== חלוניות שיחה (הטאבים והרשימה הם של projects.js) =====================
  const saveTabs = () => { };
  const renderTabs = () => App.emit('tabs:render');
  const renderConvList = () => App.emit('list:render');
  const loadConversations = () => App.emit('convs:reload');
  function activate(c) {
    if (!c) return; active = c;
    for (const x of chats) x.pane.classList.toggle('active', x === c);
    if (!c.loaded) c.load();
    c.syncControls(); c.updateHead(); c.showUsage(); c.updateSetupHint();
    if (c.id) history.replaceState(null, '', location.search + '#' + c.id); else history.replaceState(null, '', location.pathname + location.search);
    setTimeout(() => c.$input.focus(), 30);
    App.emit('chat:activated', { chat: c });
    renderTabs();
  }
  function newChat(o = {}) {
    const pid = o.projectId || (App.projects && App.projects.activeId && App.projects.activeId()) || null;
    const pr = pid && App.projects.get ? App.projects.get(pid) : null;
    const c = new Chat({ workingDir: (pr && pr.dir) || o.workingDir || null, projectId: pid }); c.folderId = o.folderId || null; chats.push(c); c.loaded = true;
    if (o.focus !== false) activate(c); else renderTabs();
    App.emit('chat:created', { chat: c }); return c;
  }
  async function openConversation(id) {
    let c = chats.find(x => x.id === id);
    if (!c) { c = new Chat({ id }); chats.push(c); App.emit('chat:created', { chat: c }); }
    activate(c); return c;
  }
  // סוגר את החלונית (השיחה עצמה נשמרת בשרת; אם עובדת — ממשיכה ברקע)
  function closeTab(c) {
    const i = chats.indexOf(c); if (i < 0) return;
    chats.splice(i, 1); c.destroy(); App.emit('chat:closed', { chat: c });
    if (active === c) active = null;
    renderTabs();
  }
  async function renameChat(c) {
    const t = await App.prompt('שם חדש לשיחה:', c.title, { title: 'שנה שם' });
    if (t && t.trim() && c.id) { await App.api('/api/conversations/' + c.id, { method: 'PATCH', body: { title: t.trim() } }); c.title = t.trim(); c.updateHead && c.updateHead(); loadConversations(); }
  }

  // ===================== מודלים / תקציב =====================
  async function loadModels(quiet) {
    const c = App.state.config;
    if (c && (c.accountMode === 'subscription' || c.hasApiKey)) {
      try {
        const prev = new Set(App.state.models.map(m => m.id));
        App.state.models = (await App.api('/api/models')).models;
        if (prev.size) { const added = App.state.models.filter(m => !prev.has(m.id)); if (added.length) App.toast('🆕 מודל חדש זמין: ' + added.map(m => m.name).join(', '), 5000); }
        if (!App.state.config.model && App.state.models.length) { const best = App.state.models.find(m => /sonnet/i.test(m.id)) || App.state.models[0]; await App.saveConfig({ model: best.id }); }
      } catch (e) { App.state.models = []; if (!quiet) App.toast('שגיאה בטעינת מודלים: ' + e.message, 5000); }
    } else App.state.models = [];
    for (const c2 of chats) c2.syncControls();
    return App.state.models;
  }
  App.loadModels = loadModels;
  function refreshBudget() { App.emit('usage:refresh'); }

  // ===================== סוכנים (מונה לכל שיחה) =====================
  async function pollAgents() {
    try {
      const r = await App.api('/api/agents?conv=all'); const list = (r.agents || []).filter(a => !['done', 'error', 'stopped', 'interrupted'].includes(a.status));
      for (const c of chats) c.setAgents(list.filter(a => !c.id || a.convId === c.id));
    } catch { }
  }

  // ===================== ה-API החיצוני =====================
  App.chats = {
    active: () => active, list: () => chats.slice(), byConvId: id => chats.find(c => c.id === id) || null,
    newChat, openConversation, closeTab, activate,
    async setDir(dir) { if (App.workspace) { await App.workspace.add(dir); App.toast('📂 נוספה ל-Workspace: ' + dir, 3500); } },
    renameChat,
    insertIntoInput(text, o = {}) { const c = o.chat || active; if (c) c.insertText(text); },
    async attachPath(p) {
      const c = active; if (!c) return;
      try {
        if (/\.(png|jpe?g|gif|webp)$/i.test(p)) { const r = await fetch('/api/fs/raw?path=' + encodeURIComponent(p)); const b = await r.blob(); await c.addFiles([new File([b], App.baseName(p), { type: b.type || 'image/png' })]); }
        else { const r = await App.api('/api/fs/read?path=' + encodeURIComponent(p)); c.attachments.push({ kind: 'text', name: App.baseName(p), text: r.text || '' }); c.renderAttachments(); }
      } catch (e) { c.insertText('"' + p + '"'); }
    },
    cycle(d) { if (App.projects && App.projects.cycleChat) App.projects.cycleChat(d); }
  };

  // ===================== גרירה: קבצים לצ'אט (priority 50) / נתיב מהסייר =====================
  App.registerDrop({ name: 'chat', priority: 50, handle: async (snap) => {
    const c = active; if (!c) return false;
    if (snap.pathData) { c.insertText(/\s/.test(snap.pathData) ? '"' + snap.pathData + '"' : snap.pathData); return true; }
    if (snap.files && snap.files.length) { await c.addFiles(snap.files); return true; }
    return false;
  } });

  // ===================== אתחול =====================
  let chatsReadyResolve; App.chatsReady = new Promise(r => (chatsReadyResolve = r));
  App.on('flow:event', ev => {
    const d = ev && ev.data; if (!d || !d.convId) return;
    const c = chats.find(x => x.id === d.convId); if (!c) return;
    if (ev.type === 'flow_run' || ev.type === 'flow_run_end') { c.flowRun = d; if (d.flowId) c.flowId = d.flowId; c.paintFlowButton(); }
  });
  App.on('instructions:changed', () => { for (const c of chats) c.updateRuleButtons(); });
  // הגדרות הצ'אט השתנו (פורמט שעה / שניות / חלון שאלות-ותשובות): השיחות הפתוחות מצוירות מחדש מיד, בלי לאבד את מקום הגלילה
  App.on('chatui:changed', () => {
    for (const c of chats) {
      if (!c.loaded || !c.id) continue;
      if (c.running) { c.$messages.querySelectorAll('.msg.assistant .md:not(.cursor)').forEach(md => { if (md.dataset.raw != null) md.innerHTML = renderMarkdown(md.dataset.raw); }); continue; }
      const at = c.$messages.scrollTop, stuck = c.stick; c.load().then(() => { if (!stuck) c.$messages.scrollTop = at; }).catch(() => { });
    }
  });
  // מעקב עבר ל"רק בחלון המעקב" (או חזר) — הצ'אט נטען מחדש בלי / עם סבבי המעקב
  App.on('watch:dockmode', d => { for (const c of chats) if (d && c.id === d.convId && c.loaded) { if (!c.running) c.load(); else c._reloadAfterRun = true; } }); // באמצע ריצה: נטען מחדש כשהיא מסתיימת
  // שיחה פתוחה שהשתנתה בלי ריצה (הודעה מצ'אט ב-VS Code ש-Claude ענה לה ברקע, העתקה וכו') — טוענים אותה מחדש
  App.on('chat:updated', d => { for (const c of chats) if (d && c.id === d.id && !c.running && !c._attaching && c.loaded) { const at = c.scroller ? c.scroller.scrollTop : 0; c.load().then(() => { try { c.scrollDown && c.scrollDown(true); } catch { } }).catch(() => { }); } });
  App.ready(async () => {
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && !document.querySelector('.modal-backdrop, .lightbox') && active && active.running && !(active._find && !active._find.bar.hidden && document.activeElement === active._find.q)) active.stop(); });
  // Ctrl+F — חיפוש בשיחה הפתוחה (בכל ההיסטוריה)
  document.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey && (e.key === 'f' || e.key === 'F' || e.code === 'KeyF') && active && !document.querySelector('.modal-backdrop')) { e.preventDefault(); active.openFind(); } }, true);
    setInterval(() => { for (const c of chats) c.tick(); }, 250);
    setInterval(pollAgents, 2000); setInterval(() => loadModels(true), 5 * 60 * 1000);
    App.on('config:changed', () => { for (const c of chats) { c.syncControls(); c.updateSetupHint(); c.updateHead(); } renderTabs(); });
    chatsReadyResolve();
    loadModels(true);
    if (!App.state.config.hasApiKey && App.state.config.accountMode !== 'subscription') App.settings && setTimeout(() => App.settings.open('account'), 400);
    pollAgents();
  });
})();
