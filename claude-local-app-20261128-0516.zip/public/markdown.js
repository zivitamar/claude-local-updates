// ============================================================
//  ממיר Markdown ל-HTML (קטן, בטוח, בלי ספריות חיצוניות)
// ============================================================
(function () {
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  // הדגשת תחביר פשוטה
  const KEYWORDS = new Set(('if else elif for while do return function def class const let var import from export default new try catch except finally ' +
    'throw raise async await yield break continue switch case in of not and or is None True False null undefined true false this self ' +
    'public private static void int string bool echo fi then esac lambda with as pass print struct enum interface type package func go').split(' '));
  function highlight(code, lang) {
    if (code.length > 50000) return esc(code);
    const hashComment = /^(py|python|sh|bash|shell|ps1|powershell|ruby|rb|yaml|yml|r|toml|dockerfile)$/i.test(lang || '');
    const re = hashComment
      ? /(#[^\n]*)|("(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*')|(\b\d+(?:\.\d+)?\b)|([A-Za-z_$][\w$]*)/g
      : /(\/\/[^\n]*|\/\*[\s\S]*?\*\/|<!--[\s\S]*?-->)|("(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*'|`(?:\\.|[^`\\])*`)|(\b\d+(?:\.\d+)?\b)|([A-Za-z_$][\w$]*)/g;
    let out = '', last = 0, m;
    while ((m = re.exec(code))) {
      out += esc(code.slice(last, m.index));
      if (m[1]) out += `<span class="tok-c">${esc(m[1])}</span>`;
      else if (m[2]) out += `<span class="tok-s">${esc(m[2])}</span>`;
      else if (m[3]) out += `<span class="tok-n">${esc(m[3])}</span>`;
      else if (KEYWORDS.has(m[4])) out += `<span class="tok-k">${esc(m[4])}</span>`;
      else out += esc(m[4]);
      last = re.lastIndex;
    }
    return out + esc(code.slice(last));
  }

  // נתיב קובץ (כמו ב-VS Code): C:\… / \\שרת\… / ‎/home/… / ~/… — יוצג כקישור שנפתח בלחיצה
  const POSIX_ROOTS = 'home|root|usr|etc|var|opt|tmp|mnt|srv|media|data|Users|Volumes|Applications|Library|private|proc|sys|dev|run|boot|workspace|workspaces|app|code|projects';
  const PATH_RE = new RegExp('^(?:[A-Za-z]:[\\\\/]|\\\\\\\\[^\\\\\\s]+\\\\|~[\\\\/]|/(?:' + POSIX_ROOTS + ')(?:/|$))');
  const looksPath = s => { s = String(s || '').trim(); return s.length >= 3 && s.length < 600 && !/[\n<>"|*?]/.test(s.replace(/^\\\\\?\\/, '')) && PATH_RE.test(s); };
  // ---------- נתיבים מוחלטים בטקסט → כרטיס כחול לחיץ (הבעלים 26/11) ----------
  //  C:\… · \\שרת\… · ~/… · ‎/home/…  — עם עברית ורווחים, בתוך מרכאות, בסוף משפט (הנקודה לא נכנסת לנתיב)
  //  רווחים מותרים רק בנתיב Windows: בתיקייה שנגמרת ב-\ , בשם קובץ עם סיומת, או כשהנתיב רץ עד סוף השורה.
  //  כשיש ספק (נתיב עם רווח) — data-alt = הקריאה בלי הרווחים; pathlinks.js בודק במחשב איזה מהם קיים.
  const P_START = /(?<![A-Za-z0-9_])[A-Za-z]:[\\/]|(?<![\\\w])\\\\(?=[^\\\s\/<>"|?*:]+\\)|(?<![\w\\\/.~])~[\\\/]|(?<![\w\\\/.:~])\/(?:home|root|usr|etc|var|opt|tmp|mnt|srv|media|data|Users|Volumes|Applications|Library|private|proc|sys|dev|run|boot|workspace|workspaces|app|code|projects)\/(?=[^\s\/])/g;
  const P_STOP = /[<>"|?*:`\u0000-\u001f]/;
  const P_EXT = /\.[A-Za-z0-9]{1,8}(?=$|[\s,;)\]}'"”’»]|:\d|[.,:;!?](?:[\s)\]'"”’»]|$))/g;
  const P_SKIP = /\b[A-Za-z][A-Za-z0-9+.-]+:\/\/[^\s<>"]+|!?\[[^\]\n]*\]\([^)\n]*\)/g;
  const P_QUOTE = { '"': '"', "'": "'", '“': '”', '”': '”', '„': '“', '«': '»', '‘': '’' };
  const nWords = s => s.split(' ').length;
  const segOk = (seg, maxW) => !/^\s|\s$|\s\s|\t/.test(seg) && nWords(seg) <= maxW && seg.length <= 120;
  function trimTail(line, s, k, min) {
    const pairs = { ')': '(', ']': '[', '}': '{' };
    for (;;) {
      if (k - s <= min) return k;
      const p = line.slice(s, k), c = p.slice(-1);
      if (/[.,;:!?'"`”’»\s]/.test(c)) { k--; continue; }
      if (pairs[c] && p.split(pairs[c]).length < p.split(c).length) { k--; continue; }
      return k;
    }
  }
  // מאריך נתיב מנקודת ההתחלה s (שורש באורך rl) → { end, alt }
  function extendPath(line, s, rl) {
    const n = line.length, win = /^(?:[A-Za-z]:|\\\\)/.test(line.slice(s, s + 2)), sep = line[s + rl - 1] === '/' ? '/' : '\\';
    const isSep = ch => ch === '\\' || ch === '/';
    const tokEnd = from => { let k = from; while (k < n && !/\s/.test(line[k]) && !P_STOP.test(line[k])) k++; return trimTail(line, s, k, rl); };
    // מרכאות: "C:\Program Files\…" — כל מה שבין המרכאות
    const q = P_QUOTE[line[s - 1]];
    if (q) { const e = line.indexOf(q, s + rl); if (e > s) { const c = line.slice(s, e); if (!/[<>"|?*\u0000-\u001f]/.test(c) && !/:/.test(c.slice(2)) && c.trim().length >= rl) return { end: s + c.replace(/\s+$/, '').length }; } }
    if (!win) return { end: tokEnd(s + rl) };
    let segStart = s + rl, spaced = false;
    for (;;) {
      let j = segStart;
      while (j < n && !isSep(line[j]) && !P_STOP.test(line[j])) j++;
      const seg = line.slice(segStart, j);
      if (j < n && isSep(line[j])) {
        if (/\s/.test(seg)) {
          if (seg.trim() === '' || line[j] !== sep || !segOk(seg, 5) || /\.[A-Za-z0-9]{1,8}$/.test(seg.split(' ')[0])) return { end: tokEnd(segStart), alt: null };
          spaced = true;
        }
        segStart = j + 1; continue;
      }
      // הקטע האחרון (שם הקובץ / התיקייה)
      const tok = tokEnd(segStart), alt = spaced ? tokEnd(s + rl) : null;
      if (!/\s/.test(seg)) return { end: tok, alt: alt !== tok ? alt : null };
      if (/^\s/.test(seg)) return { end: segStart, alt: alt !== segStart ? alt : null }; // נגמר ב-\ ואחריו רווח
      P_EXT.lastIndex = 0; let m;
      const sub = line.slice(segStart);
      while ((m = P_EXT.exec(sub)) && m.index + m[0].length <= seg.length) {
        const name = sub.slice(0, m.index + m[0].length);
        if (segOk(name, 6)) return { end: segStart + name.length, alt: name.includes(' ') || spaced ? tokEnd(s + rl) : null };
        break;
      }
      // נתיב שרץ עד סוף השורה (C:\…\שולחן העבודה\קלוד API)
      if (j === n) { const e = trimTail(line, s, n, rl), fin = line.slice(segStart, e); if (fin && segOk(fin, 4)) return { end: e, alt: tokEnd(s + rl) }; }
      return { end: tok, alt: alt !== tok ? alt : null };
    }
  }
  function findPaths(str) {
    const out = [], text = String(str || '');
    let off = 0;
    for (const line of text.split('\n')) {
      if (line.length > 6000) { off += line.length + 1; continue; }
      const skip = []; let m; P_SKIP.lastIndex = 0;
      while ((m = P_SKIP.exec(line))) skip.push([m.index, m.index + m[0].length]);
      const re = new RegExp(P_START.source, 'g');
      while ((m = re.exec(line))) {
        const s = m.index;
        if (skip.some(r => s >= r[0] && s < r[1])) continue;
        const r = extendPath(line, s, m[0].length), p = line.slice(s, r.end);
        if (p.length >= 3 && p.length < 600) { out.push({ index: off + s, path: p, alt: r.alt != null && r.alt > s && r.alt < r.end ? line.slice(s, r.alt) : null }); re.lastIndex = Math.max(r.end, s + 1); }
        if (out.length > 500) return out;
      }
      off += line.length + 1;
    }
    return out;
  }
  const IMG_P = /\.(png|jpe?g|gif|webp|bmp|svg|ico|avif)$/i, VID_P = /\.(mp4|webm|mov|m4v|ogv|mkv)$/i, AUD_P = /\.(mp3|wav|ogg|oga|m4a|flac|opus|aac)$/i, DOC_P = /\.(pdf|docx?|dotx|xlsx?|xlsm|pptx?|odt|ods|odp|rtf|csv|tsv|epub)$/i;
  function pathKind(p) {
    const c = String(p).replace(/(?::\d+(?::\d+)?|#L\d+(?:-L?\d+)?)$/, '');
    if (/[\\/]$/.test(c) || /^[A-Za-z]:$/.test(c)) return 'dir';
    if (IMG_P.test(c)) return 'image'; if (VID_P.test(c)) return 'video'; if (AUD_P.test(c)) return 'audio'; if (DOC_P.test(c)) return 'doc';
    return /\.[A-Za-z0-9]{1,8}$/.test(c.split(/[\\/]/).pop()) ? 'file' : 'dir';
  }
  // כרטיס נתיב: אייקון · קישור כחול (נפתח במחשב) · 👁 תצוגה מקדימה בצ'אט · 📋 העתקה. האייקונים ב-CSS — innerText נשאר הנתיב בלבד
  function cardHtml(p, alt) {
    const e = esc(p);
    return `<span class="path-card" dir="ltr" data-kind="${pathKind(p)}" data-path="${e}"${alt ? ` data-alt="${esc(alt)}"` : ''}><span class="pc-ic" aria-hidden="true"></span>` +
      `<span class="path-link pc-link" data-path="${e}" title="${e}&#10;לחיצה: פתיחה במחשב · Ctrl+לחיצה: בתוך האפליקציה · קליק ימני: עוד">${e}</span>` +
      `<button type="button" class="pc-btn pc-eye" title="תצוגה מקדימה כאן בצ'אט" aria-label="תצוגה מקדימה"></button><button type="button" class="pc-btn pc-copy" title="העתק נתיב" aria-label="העתק נתיב"></button></span>`;
  }
  // טקסט שכולו נתיב אחד (בלי שום דבר אחר) → הנתיב; אחרת null
  function soloPath(t) {
    t = String(t || '').trim().replace(/^(["'“«])(.*)(["'”»])$/, '$2');
    if (!t || /\n/.test(t)) return null;
    const f = findPaths(t);
    return f.length === 1 && f[0].index === 0 && f[0].path.length === t.length ? t : null;
  }
  const pathCode = c => { const p = soloPath(c); return p ? cardHtml(p) : `<code>${esc(c)}</code>`; };
  function inline(text) {
    const codes = [], held = [];
    const hold = h => { held.push(h); return `\u0001${held.length - 1}\u0001`; };
    text = text.replace(/`([^`\n]+)`/g, (_, c) => { codes.push(c); return `\u0000${codes.length - 1}\u0000`; });
    // נתיבים מוחלטים → כרטיסים (נסרקים בטקסט הגולמי, לפני ה-escape)
    const cards = [], fp = findPaths(text);
    if (fp.length) { let o = '', at = 0; for (const x of fp) { o += text.slice(at, x.index) + `\u0002${cards.length}\u0002`; cards.push(cardHtml(x.path, x.alt)); at = x.index + x.path.length; } text = o + text.slice(at); }
    text = esc(text);
    text = text
      .replace(/!\[([^\]]*)\]\((https?:\/\/[^\s)]+)\)/g, (_, a, u) => hold(`<img src="${u}" alt="${a}" style="max-width:100%">`))
      .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, (_, t, u) => hold(`<a href="${u}" target="_blank" rel="noopener">${t}</a>`))
      // קישור Markdown לקובץ: [שם](C:\…) / [שם](src/a.js#L12) — נפתח במחשב, לא בדפדפן
      .replace(/\[([^\]]+)\]\(((?:[A-Za-z]:[\\/]|~[\\/]|\.{1,2}[\\/]|\/|[^\s()\\/:]+[\\/])[^\s()]*|[^\s()\\/:#]+\.[A-Za-z0-9]{1,8}(?:#L\d+(?:-L?\d+)?)?)\)/g, (m, t, target) => /^\/\//.test(target) ? m : hold(`<a class="path-link" href="#" data-path="${target}">${t}</a>`))
      .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
      .replace(/__([^_]+)__/g, '<strong>$1</strong>')
      .replace(/(^|[^*\w])\*([^*\n]+)\*(?!\w)/g, '$1<em>$2</em>')
      .replace(/~~([^~]+)~~/g, '<del>$1</del>')
      .replace(/(^|[\s(])(https?:\/\/[^\s<)\u0001]+)/g, '$1<a href="$2" target="_blank" rel="noopener">$2</a>');
    return text.replace(/\u0001(\d+)\u0001/g, (_, i) => held[+i]).replace(/\u0002(\d+)\u0002/g, (_, i) => cards[+i]).replace(/\u0000(\d+)\u0000/g, (_, i) => pathCode(codes[+i]));
  }

  // ---------- טבלאות (הבעלים 26/11): נקלטות גם בלי שורה ריקה לפניהן, מעוצבות, ו-Claude שולט בצבע ----------
  //  שורת עיצוב (לא נראית) מעל הטבלה: <!-- table color=green header=blue style=grid,compact,full,first,plain title="…" -->
  //  צבע לתא: {green} בתחילת התא · צבע לשורה: {row:yellow} בתחילת התא הראשון · {#hex} — כל צבע
  const T_COLORS = { blue: '#3b82f6', green: '#16a34a', red: '#dc2626', orange: '#ea580c', purple: '#9333ea', teal: '#0d9488', pink: '#db2777', gray: '#64748b', grey: '#64748b', yellow: '#ca8a04', gold: '#b45309', indigo: '#4f46e5', cyan: '#0891b2', brown: '#92400e', black: '#334155', accent: 'var(--accent)',
    'כחול': '#3b82f6', 'ירוק': '#16a34a', 'אדום': '#dc2626', 'כתום': '#ea580c', 'סגול': '#9333ea', 'טורקיז': '#0d9488', 'ורוד': '#db2777', 'אפור': '#64748b', 'צהוב': '#ca8a04', 'זהב': '#b45309', 'תכלת': '#0891b2', 'חום': '#92400e', 'שחור': '#334155' };
  const tColor = v => { v = String(v || '').trim().toLowerCase(); if (T_COLORS[v]) return T_COLORS[v]; return /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/.test(v) ? v : null; };
  const SEP_RE = /^\s*\|?\s*:?-+:?\s*(\|\s*:?-+:?\s*)*\|?\s*$/;
  const TDIR_RE = /^\s*<!--\s*table\b([\s\S]*?)-->\s*$/i, COMMENT_RE = /^\s*<!--[\s\S]*?-->\s*$/;
  // מפריד תאים: | שלא בתוך `קוד` ולא \|
  function splitRow(line) {
    const s = String(line).trim(), prot = new Set(), re = /`[^`\n]+`/g; let m;
    while ((m = re.exec(s))) for (let k = m.index; k < m.index + m[0].length; k++) prot.add(k);
    const cells = []; let cur = '';
    for (let k = 0; k < s.length; k++) {
      if (s[k] === '\\' && s[k + 1] === '|') { cur += '|'; k++; continue; }
      if (s[k] === '|' && !prot.has(k)) { cells.push(cur); cur = ''; continue; }
      cur += s[k];
    }
    cells.push(cur);
    if (cells.length > 1 && /^\|/.test(s) && !cells[0].trim()) cells.shift();
    if (cells.length > 1 && /\|$/.test(s) && !/\\\|$/.test(s) && !cells[cells.length - 1].trim()) cells.pop();
    return cells.map(c => c.trim());
  }
  const isTableAt = (lines, i) => { const l = lines[i], s = lines[i + 1]; if (l == null || s == null || !l.includes('|') || !/-/.test(s) || !SEP_RE.test(s)) return false; return s.includes('|') || splitRow(l).length === splitRow(s).length; };
  function tableOpts(attrs) {
    const o = {}, re = /([A-Za-z֐-׿]+)\s*[=:]\s*(?:"([^"]*)"|'([^']*)'|([^\s"']+))/g; let m;
    while ((m = re.exec(attrs || ''))) o[m[1].toLowerCase()] = m[2] != null ? m[2] : m[3] != null ? m[3] : m[4];
    return o;
  }
  const RTL_CH = /[֐-׿؀-ۿ]/, LTR_CH = /[A-Za-zÀ-ɏ]/;
  const dirOf = s => { for (const ch of String(s).replace(/\{[^}]*\}|`[^`]*`|https?:\S+/g, '')) { if (RTL_CH.test(ch)) return 'rtl'; if (LTR_CH.test(ch)) return 'ltr'; } return ''; };
  const plainOf = c => String(c).replace(/^\{[^}]*\}\s*/, '').replace(/\*\*|__|`|~~/g, '').trim();
  const NUM_RE = /^[+\-−±~≈<>≤≥]?\s*[$€₪£¥]?\s*\d[\d,.'\s]*(?:%|‰|×|x|₪|\$|€|[A-Za-z]{1,3})?$/;
  const cellHtml = c => String(c).split(/<br\s*\/?>/i).map(inline).join('<br>'); // <br> בתוך תא = שורה חדשה
  function cellColor(c) { const m = String(c).match(/^\{\s*(row\s*:\s*)?(#[0-9a-fA-F]{3,6}|[A-Za-z֐-׿]+)\s*\}\s*/); if (!m) return null; const col = tColor(m[2]); return col ? { row: !!m[1], color: col, rest: String(c).slice(m[0].length) } : null; }
  function tableHtml(head, sep, rows, opts) {
    opts = opts || {};
    const n = head.length, aligns = splitRow(sep).map(c => /^:-+:$/.test(c) ? 'c' : /-:$/.test(c) ? 'r' : /^:-/.test(c) ? 'l' : '');
    rows = rows.map(r => { r = r.slice(0, n); while (r.length < n) r.push(''); return r; });
    // עמודה של מספרים / סימנים קצרים (✅ ❌ 3) — במרכז, ספרות ברוחב אחיד
    const kind = head.map((_, k) => { const vals = rows.map(r => plainOf(r[k])).filter(Boolean); if (!vals.length) return ''; if (vals.every(v => NUM_RE.test(v))) return 'num'; if (vals.every(v => [...v].length <= 3)) return 'short'; return ''; });
    const dir = dirOf(head.join(' ')) || dirOf(rows.map(r => r.join(' ')).join(' '));
    const styles = String(opts.style || '').toLowerCase().split(/[\s,;|]+/).filter(Boolean);
    const cls = ['md-tbl', ...styles.filter(s => /^(plain|grid|compact|full|first)$/.test(s))];
    const tc = tColor(opts.color), th = tColor(opts.header);
    const vars = (tc ? `--tc:${tc};` : '') + (th ? `--th:${th};` : '');
    const al = k => { const a = aligns[k] || (kind[k] ? 'c' : ''); return a ? ` class="${a}"` : ''; };
    const td = (c, k) => {
      const c0 = cellColor(c), cc = c0 && !c0.row ? c0 : null; const color = cc ? cc.color : null; const text = cc ? cc.rest : c; // {row:…} נחשב רק בתא הראשון (tr)
      const classes = [aligns[k] || (kind[k] ? 'c' : ''), kind[k] === 'num' ? 'num' : '', color ? 'cc' : ''].filter(Boolean).join(' ');
      const body = kind[k] === 'num' ? `<bdi dir="ltr">${cellHtml(text)}</bdi>` : cellHtml(text);
      return `<td${classes ? ` class="${classes}"` : ''}${color ? ` style="--cc:${color}"` : ''}>${body}</td>`;
    };
    const tr = r => { const rc = cellColor(r[0]); const rowC = rc && rc.row ? rc.color : null; if (rowC) r = [rc.rest, ...r.slice(1)]; return `<tr${rowC ? ` class="rc" style="--rc:${rowC}"` : ''}>` + r.map(td).join('') + '</tr>'; };
    const title = opts.title ? `<div class="md-tbl-title">${inline(opts.title)}</div>` : '';
    return `<div class="${cls.join(' ')}"${dir ? ` dir="${dir}"` : ''}${vars ? ` style="${vars}"` : ''}>${title}<button class="copy-table" type="button" title="העתק את הטבלה (נדבקת כטבלה גם ב-Excel וב-Word)">📋</button>` +
      `<div class="md-tbl-scroll${rows.length > 14 ? ' tall' : ''}"><table><thead><tr>` + head.map((c, k) => { const hc = cellColor(c); return `<th${al(k)}${hc ? ` style="--th:${hc.color}"` : ''}>${cellHtml(hc ? hc.rest : c)}</th>`; }).join('') + '</tr></thead><tbody>' +
      rows.map(tr).join('') + '</tbody></table></div></div>';
  }

  function render(src) {
    const lines = String(src || '').replace(/\r\n/g, '\n').split('\n');
    const html = [];
    let i = 0, tOpts = null;
    while (i < lines.length) {
      const line = lines[i];
      // שורת הערה (<!-- … -->) לא מוצגת; <!-- table … --> = עיצוב לטבלה שאחריה
      if (COMMENT_RE.test(line)) { const d = line.match(TDIR_RE); tOpts = d ? tableOpts(d[1]) : tOpts; i++; continue; }
      if (isTableAt(lines, i)) {
        const head = splitRow(line), sep = lines[i + 1];
        i += 2;
        const rows = [];
        while (i < lines.length && lines[i].includes('|') && lines[i].trim() && !COMMENT_RE.test(lines[i])) rows.push(splitRow(lines[i++]));
        html.push(tableHtml(head, sep, rows, tOpts)); tOpts = null;
        continue;
      }
      if (line.trim()) tOpts = null; // שורת העיצוב שייכת רק לטבלה שמיד אחריה
      const fence = line.match(/^\s*(```|~~~)\s*([\w+#.-]*)/);
      if (fence) {
        const lang = fence[2] || '';
        const buf = [];
        i++;
        while (i < lines.length && !lines[i].trim().startsWith(fence[1])) buf.push(lines[i++]);
        i++;
        const code = buf.join('\n');
        // בלוק קוד שכולו נתיבים (נתיב בשורה) — לא בלוק קוד אלא כרטיסים
        const plines = code.split('\n').map(x => x.trim()).filter(Boolean);
        if (plines.length && plines.length <= 30 && plines.every(x => soloPath(x))) { html.push(`<div class="pc-solo">${plines.map(x => cardHtml(soloPath(x))).join('')}</div>`); continue; }
        html.push(`<div class="code-block"><div class="code-head"><span>${esc(lang || 'code')}</span><button class="copy-code">📋 העתק</button></div><pre><code>${highlight(code, lang)}</code></pre></div>`);
        continue;
      }
      if (/^\s*$/.test(line)) { i++; continue; }
      const h = line.match(/^(#{1,6})\s+(.*)$/);
      if (h) { html.push(`<h${h[1].length}>${inline(h[2])}</h${h[1].length}>`); i++; continue; }
      if (/^\s*([-*_])(\s*\1){2,}\s*$/.test(line)) { html.push('<hr>'); i++; continue; }
      if (/^\s*>/.test(line)) {
        const buf = [];
        while (i < lines.length && /^\s*>/.test(lines[i])) buf.push(lines[i++].replace(/^\s*>\s?/, ''));
        html.push(`<blockquote>${render(buf.join('\n'))}</blockquote>`);
        continue;
      }
      const li = line.match(/^(\s*)([-*+]|\d+[.)])\s+(.*)$/);
      if (li) {
        const ordered = /\d/.test(li[2]);
        const items = [];
        while (i < lines.length) {
          const m = lines[i].match(/^(\s*)([-*+]|\d+[.)])\s+(.*)$/);
          if (m) { items.push({ indent: m[1].length, text: m[3] }); i++; }
          else if (/^\s{2,}\S/.test(lines[i]) && items.length) { items[items.length - 1].text += '\n' + lines[i].trim(); i++; }
          else break;
        }
        const base = items[0].indent;
        const n0 = ordered ? parseInt(li[2], 10) : 1; // רשימה ממוספרת שממשיכה אחרי בלוק קוד ("3. …") — המספור נשמר
        let out = `<${ordered ? 'ol' : 'ul'}${ordered && n0 > 1 ? ` start="${n0}"` : ''}>`;
        for (const it of items) {
          const t = inline(it.text).replace(/\n/g, '<br>');
          out += it.indent > base ? `<li style="margin-right:${Math.min(it.indent - base, 8) * 8}px;list-style:circle">${t}</li>` : `<li>${t}</li>`;
        }
        html.push(out + `</${ordered ? 'ol' : 'ul'}>`);
        continue;
      }
      const buf = [];
      // פסקה נעצרת גם בטבלה / בשורת עיצוב — טבלה מיד אחרי שורת טקסט (בלי שורה ריקה) נקלטת כטבלה
      while (i < lines.length && lines[i].trim() && !/^(#{1,6}\s|\s*(```|~~~)|\s*>|\s*([-*+]|\d+[.)])\s)/.test(lines[i]) && !COMMENT_RE.test(lines[i]) && !isTableAt(lines, i)) buf.push(lines[i++]);
      if (!buf.length) buf.push(lines[i++]);
      html.push(`<p>${buf.map(inline).join('<br>')}</p>`);
    }
    return html.join('\n');
  }

  // ---------- שאלות ותשובות: חלון ייעודי ----------
  //  (א) בלוק מפורש :::qa … ::: עם "### שאלה" ואחריה התשובה (Claude מתבקש לכתוב כך כשההגדרה פועלת)
  //  (ב) זיהוי אוטומטי: לפחות 2 זוגות "ש: / שאלה: / Q:" ואחריהם "ת: / תשובה: / A:"
  const qaOn = () => { try { return !(window.App && App.chatUi && App.chatUi().qaBox === false); } catch { return true; } };
  const Q_RE = /^\s*(?:\*\*)?\s*(?:ש|שאלה|Q|Question)\s*\d*\s*[:.\-]\s*(?:\*\*)?\s*(.*)$/i, A_RE = /^\s*(?:\*\*)?\s*(?:ת|תשובה|A|Answer)\s*\d*\s*[:.\-]\s*(?:\*\*)?\s*(.*)$/i;
  function qaHtml(items, title) {
    const cards = items.map((it, k) => `<details class="qa-item" open><summary><span class="qa-num">${k + 1}</span><span class="qa-q">${inline(it.q.replace(/\*\*$/, '').trim())}</span></summary><div class="qa-a">${render(it.a.trim() || '—')}</div></details>`).join('');
    return `<div class="qa-box"><div class="qa-head"><span class="qa-title">❓ ${esc(title || 'שאלות ותשובות')}</span><span class="qa-count">${items.length}</span><button class="qa-toggle" type="button" title="פתח / סגור את כל התשובות">סגור הכל</button></div>${cards}</div>`;
  }
  // מחלק את הטקסט לקטעים רגילים ולקטעי שאלות-ותשובות (בלי לגעת במה שבתוך בלוקי קוד)
  function splitQa(src) {
    const lines = src.split('\n'), out = []; let buf = [], fence = null;
    const flush = () => { if (buf.length) out.push({ md: buf.join('\n') }); buf = []; };
    for (let i = 0; i < lines.length; i++) {
      const ln = lines[i], f = ln.match(/^\s*(```|~~~)/);
      if (fence) { buf.push(ln); if (f && ln.trim().startsWith(fence)) fence = null; continue; }
      if (f) { fence = f[1]; buf.push(ln); continue; }
      const open = ln.match(/^\s*:::\s*qa\b\s*(.*)$/i);
      if (open) {
        const body = []; let j = i + 1, inF = null;
        for (; j < lines.length; j++) { const g = lines[j].match(/^\s*(```|~~~)/); if (inF) { if (g && lines[j].trim().startsWith(inF)) inF = null; } else if (g) inF = g[1]; else if (/^\s*:::\s*$/.test(lines[j])) break; body.push(lines[j]); }
        const items = []; let cur = null, inF2 = null;
        for (const b of body) {
          const g = b.match(/^\s*(```|~~~)/); if (inF2) { if (g && b.trim().startsWith(inF2)) inF2 = null; if (cur) cur.a += b + '\n'; continue; } if (g) inF2 = g[1];
          const h = !inF2 && b.match(/^\s*#{2,4}\s+(.*)$/);
          if (h) { cur = { q: h[1], a: '' }; items.push(cur); } else if (cur) cur.a += b + '\n'; else if (b.trim()) { cur = { q: b, a: '' }; items.push(cur); }
        }
        if (items.length) { flush(); out.push({ qa: items, title: open[1].trim() }); } else buf.push(...body);
        i = j; continue;
      }
      // זיהוי אוטומטי של ש:/ת:
      if (Q_RE.test(ln) && !A_RE.test(ln)) {
        const items = []; let j = i, cur = null, stage = '';
        for (; j < lines.length; j++) {
          const l = lines[j], q = !A_RE.test(l) && l.match(Q_RE), a = l.match(A_RE);
          if (q) { if (cur && stage !== 'a') break; cur = { q: q[1], a: '' }; items.push(cur); stage = 'q'; }
          else if (a && cur && stage === 'q') { cur.a = a[1] + '\n'; stage = 'a'; }
          else if (cur && stage === 'a' && (l.trim() || (lines[j + 1] && (Q_RE.test(lines[j + 1]) || lines[j + 1].trim())))) cur.a += l + '\n';
          else if (cur && stage === 'q' && l.trim()) cur.q += ' ' + l.trim();
          else if (!l.trim() && stage === 'a') continue;
          else break;
        }
        const ok = items.filter(x => x.a.trim()).length;
        if (ok >= 2 && ok === items.length) { flush(); out.push({ qa: items }); i = j - 1; continue; }
      }
      buf.push(ln);
    }
    flush(); return out;
  }
  function renderAll(src) {
    src = String(src || '').replace(/\r\n/g, '\n');
    if (!/:::\s*qa|^\s*(?:\*\*)?\s*(?:ש|שאלה|Q|Question)\s*\d*\s*[:.\-]/im.test(src)) return render(src);
    const parts = splitQa(src), on = qaOn();
    return parts.map(p => p.md != null ? render(p.md) : on ? qaHtml(p.qa, p.title) : render(p.qa.map(x => `### ${x.q}\n${x.a}`).join('\n'))).join('\n');
  }
  // פתח / סגור הכל
  if (typeof document !== 'undefined') document.addEventListener('click', e => {
    const b = e.target && e.target.closest && e.target.closest('.qa-toggle'); if (!b) return;
    const box = b.closest('.qa-box'), items = [...box.querySelectorAll(':scope > .qa-item')], anyOpen = items.some(d => d.open);
    items.forEach(d => (d.open = !anyOpen)); b.textContent = anyOpen ? 'פתח הכל' : 'סגור הכל';
  });

  // העתקת טבלה: HTML (נדבק כטבלה ב-Excel / Word) + טקסט עם טאבים
  if (typeof document !== 'undefined') document.addEventListener('click', async e => {
    const b = e.target && e.target.closest && e.target.closest('.copy-table'); if (!b) return;
    e.stopPropagation();
    const t = b.closest('.md-tbl').querySelector('table'); if (!t) return;
    const tsv = [...t.rows].map(r => [...r.cells].map(c => c.innerText.replace(/\s*\n\s*/g, ' ').trim()).join('\t')).join('\n');
    let ok = false;
    try { if (window.ClipboardItem && navigator.clipboard && navigator.clipboard.write) { await navigator.clipboard.write([new ClipboardItem({ 'text/html': new Blob([t.outerHTML], { type: 'text/html' }), 'text/plain': new Blob([tsv], { type: 'text/plain' }) })]); ok = true; } } catch { }
    if (!ok) { try { if (window.App && App.copyText) App.copyText(tsv, ''); else await navigator.clipboard.writeText(tsv); ok = true; } catch { } }
    b.textContent = ok ? '✅' : '⚠'; b.classList.add('done'); setTimeout(() => { b.textContent = '📋'; b.classList.remove('done'); }, 1400);
  });

  window.renderMarkdown = renderAll;
  window.renderMarkdown.looksPath = looksPath;
  window.renderMarkdown.highlight = highlight; // הדגשת תחביר — גם לתצוגת קבצים
  window.renderMarkdown.findPaths = findPaths;
  window.renderMarkdown.cardHtml = cardHtml; // כרטיס נתיב (גם להודעות המשתמש)
  window.renderMarkdown.soloPath = soloPath;
  window.renderMarkdown.pathKind = pathKind;
  window.escapeHtml = esc;
})();
