// ============================================================
//  sound.js — מנוע הצלילים. השרת מזהה לבד מה Claude עושה (כלי, סיום, סירוב, סוכן, מחקר, מעקב…) ושולח אירוע 'sound';
//  כאן בוחרים את הפרופיל (ברירת מחדל / לפי פרויקט) ומנגנים במקביל — Claude לא מנגן ולא מחכה לשום דבר.
//  מקורות: 'syn:<id>' ספרייה מסונתזת · 'voice' / 'voice:<קול>' המשפט של האירוע · 'phrase:<קול>:<מפתח>' · 'custom:<id>' הקלטה/קובץ שלי (עם חיתוך)
//  מתג ראשי: config.sounds.master === false → אין שום צליל, לא משנה מה.
//  App.sound = { chime, play, preview, handle, log, stats, profileFor, eventCfg, voices, ... }
// ============================================================
(function () {
  const App = window.App, CAT = window.SOUND_CATALOG, LIB = window.SOUND_LIB;
  let ctx = null, master = null, analyser = null;
  const stats = { played: 0, lastAt: 0, ctxState: 'none', notes: 0, skipped: 0 };
  const log = []; // יומן כל מה שנוגן / דולג — גם להוכחה וגם לרשימה "מה נוגן לאחרונה"
  const buffers = new Map(); let manifest = null;
  function getCtx() {
    if (ctx) return ctx;
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return null;
    try { ctx = new AC(); } catch { return null; }
    master = ctx.createGain(); analyser = ctx.createAnalyser(); analyser.fftSize = 2048;
    master.connect(analyser); analyser.connect(ctx.destination);
    return ctx;
  }
  function unlock() { const c = getCtx(); if (c && c.state === 'suspended') c.resume().catch(() => { }); }
  for (const ev of ['pointerdown', 'keydown']) window.addEventListener(ev, unlock, { capture: true, passive: true });

  // ---------- הגדרות ----------
  const DEF = () => ({ master: true, volume: 0.8, level: 1, speed: 1, chats: {}, profiles: [{ id: 'default', name: 'ברירת מחדל', voice: 'asaf', events: {} }], projectProfiles: {}, custom: [] });
  // הקולות הישנים (קול "גבוה" ו"רובוט" — שניהם היו אותו קול) → הקולות החדשים
  const VMAP = { high: 'female', robot: 'deep' };
  const vid = v => VMAP[v] || v || 'asaf';
  function S() {
    const c = (App.state && App.state.config) || {}; const s = c.sounds && typeof c.sounds === 'object' ? c.sounds : DEF();
    if (!Array.isArray(s.profiles) || !s.profiles.length) s.profiles = DEF().profiles;
    if (!s.projectProfiles) s.projectProfiles = {}; if (!Array.isArray(s.custom)) s.custom = [];
    if (![1, 2, 3].includes(s.level)) s.level = 1; if (!(s.speed > 0)) s.speed = 1; if (!s.chats || typeof s.chats !== 'object') s.chats = {};
    for (const p of s.profiles) p.voice = vid(p.voice);
    if (!c.sounds && c.chime === false) { s.profiles[0].events['ev:finish'] = { on: false }; } // מהגדרה הישנה "צליל בסיום עבודה"
    return s;
  }
  // פרופיל: של הפרויקט (אם נבחר) → של המחשב שממנו הגיע הצליל (אם נבחר) → ברירת מחדל
  function profileFor(projectId, machine) { const s = S(); const mc = machineCfg(machine); const id = (projectId && s.projectProfiles[projectId]) || mc.profile || 'default'; return s.profiles.find(p => p.id === id) || s.profiles[0]; }
  // הגדרות צליל לכל מחשב ברשת: mute · vol · level · profile · onlyViewing (רק כשהוא המחשב שעל המסך)
  function machineCfg(id) { const s = S(); return (id && s.machines && s.machines[id]) || {}; }
  function eventCfg(profile, key) { const d = (CAT.byKey[key] || { def: { on: false, src: 'voice' } }).def; const o = (profile.events || {})[key] || {}; return { on: o.on != null ? !!o.on : d.on, src: o.src || d.src, vol: o.vol != null ? +o.vol : 1 }; }

  // ---------- טעינת קבצים ----------
  async function loadManifest() { if (manifest) return manifest; try { manifest = await (await fetch('/sounds/voices/manifest.json', { cache: 'no-store' })).json(); } catch { manifest = { voices: [], clips: {} }; } return manifest; }
  async function bufferFor(url) {
    if (buffers.has(url)) return buffers.get(url);
    const p = (async () => { const c = getCtx(); const ab = await (await fetch(url)).arrayBuffer(); return await c.decodeAudioData(ab); })();
    buffers.set(url, p); p.catch(() => buffers.delete(url)); return p;
  }
  // מהירות דיבור בלי לשנות את גובה הקול (WSOLA): מסגרות של 30ms בחפיפה, כל אחת במקום הדומה ביותר לרציפות הטבעית
  const stretched = new Map();
  function stretch(buf, rate) {
    if (!buf || Math.abs(rate - 1) < 0.02) return buf;
    const c = getCtx(), sr = buf.sampleRate, x = buf.getChannelData(0);
    const N = Math.round(sr * 0.03), Hs = N >> 1, tol = Math.round(N / 4), win = new Float32Array(N);
    for (let i = 0; i < N; i++) win[i] = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / (N - 1));
    const outLen = Math.ceil(x.length / rate) + N, y = new Float32Array(outLen), ws = new Float32Array(outLen);
    let prev = 0;
    for (let k = 0, o = 0; o + N < outLen; k++, o += Hs) {
      const nom = Math.round(o * rate); if (nom >= x.length) break;
      let best = nom;
      if (k > 0) { const ref = prev + Hs; let bc = -Infinity; for (let d = -tol; d <= tol; d += 2) { const p = nom + d; if (p < 0 || p + N > x.length) continue; let cc = 0; for (let i = 0; i < N; i += 3) cc += x[p + i] * (x[ref + i] || 0); if (cc > bc) { bc = cc; best = p; } } }
      for (let i = 0; i < N; i++) { y[o + i] += (x[best + i] || 0) * win[i]; ws[o + i] += win[i]; }
      prev = best;
    }
    const len = Math.max(1, Math.round(x.length / rate)), out = c.createBuffer(1, len, sr), z = out.getChannelData(0);
    for (let i = 0; i < len; i++) z[i] = ws[i] > 1e-3 ? y[i] / ws[i] : 0;
    return out;
  }
  async function voiceClip(voice, key) {
    const m = await loadManifest(); voice = vid(voice); const c = ((m.clips || {})[voice] || {})[key]; if (!c) return null;
    // ?v= גרסת הבנייה: קול שנבנה מחדש לא נלקח מהמטמון של הדפדפן
    const url = '/sounds/voices/' + c.file + '?v=' + encodeURIComponent(m.generatedAt || ''), rate = +(S().speed || 1).toFixed(2), buf0 = await bufferFor(url);
    let buf = buf0; if (Math.abs(rate - 1) >= 0.02) { const sk = url + '@' + rate; if (!stretched.has(sk)) stretched.set(sk, stretch(buf0, rate)); buf = stretched.get(sk); }
    return { buf, start: 0, end: buf.duration };
  }
  // רמת השיחה: הגדרה של השיחה (קליק ימני) > הכללית
  function chatCfg(conv) { const s = S(); return (conv && s.chats[conv]) || {}; }
  function levelFor(conv, machine) { const c = chatCfg(conv); if ([1, 2, 3].includes(c.level)) return c.level; const m = machineCfg(machine); return [1, 2, 3].includes(m.level) ? m.level : S().level; }
  async function customClip(id) { const it = S().custom.find(x => x.id === id); if (!it) return null; const buf = await bufferFor('/api/sounds/custom/' + id + '/file'); const end = it.end != null ? it.end : buf.duration; return { buf, start: Math.max(0, it.start || 0), end: Math.min(buf.duration, end), gain: it.gain || 1 }; }

  // ---------- ניגון ----------
  let voiceBusyUntil = 0; const lastPlay = new Map();
  function measure(entry, dur) { // שיא העוצמה שעבר בפועל דרך גרף השמע בזמן הצליל (עובד גם כשהמערכת מושתקת)
    if (!analyser) return; const data = new Float32Array(analyser.fftSize); let peak = 0; const until = performance.now() + Math.min(4000, dur * 1000 + 120);
    const iv = setInterval(() => { analyser.getFloatTimeDomainData(data); for (let i = 0; i < data.length; i++) { const v = Math.abs(data[i]); if (v > peak) peak = v; } if (performance.now() > until) { clearInterval(iv); entry.peak = +peak.toFixed(3); } }, 15);
  }
  // מנגן מקור אחד. מחזיר {dur} או null
  async function playSrc(src, { vol = 1, voice = 'asaf', key = '', queueVoice = false } = {}) {
    const c = getCtx(); if (!c) return null; if (c.state === 'suspended') { try { await c.resume(); } catch { } }
    const s = S(); const gain = (s.volume == null ? 0.8 : s.volume) * vol;
    const out = c.createGain(); out.gain.value = gain; out.connect(master);
    if (src.startsWith('syn:')) { const d = LIB.play(c, out, src.slice(4), c.currentTime + 0.01, 1); return d ? { dur: d } : null; }
    let clip = null;
    if (src === 'voice') clip = await voiceClip(voice, key);
    else if (src.startsWith('voice:')) clip = await voiceClip(src.slice(6), key);
    else if (src.startsWith('phrase:')) { const [, v, ...k] = src.split(':'); clip = await voiceClip(v, k.join(':')); }
    else if (src.startsWith('custom:')) clip = await customClip(src.slice(7));
    if (!clip) return null;
    let when = c.currentTime + 0.01;
    if (queueVoice) { when = Math.max(when, voiceBusyUntil); if (when - c.currentTime > 2.5) return { dur: 0, dropped: true }; } // לא מצטבר תור ארוך של קולות
    const dur = Math.max(0.02, clip.end - clip.start);
    const g = c.createGain(); g.gain.value = clip.gain || 1; g.connect(out);
    const node = c.createBufferSource(); node.buffer = clip.buf; node.connect(g);
    node.start(when, clip.start, dur);
    if (queueVoice) voiceBusyUntil = when + dur + 0.08;
    return { dur, startsIn: +(when - c.currentTime).toFixed(3), clipStart: clip.start, clipEnd: clip.end };
  }
  function on() { const s = S(); return s.master !== false; }
  // אירוע מהשרת: {keys:[...], conv, project}
  const RANK = k => /^(cmd|chrome|pc|app|mcp):/.test(k) ? 0 : /^ev:(screenshot|image)$/.test(k) ? 1 : /^tool:/.test(k) ? 2 : 0;
  async function handle(ev) {
    const keys = (ev && ev.keys) || []; if (!keys.length) return;
    const entry = { at: Date.now(), keys, conv: ev.conv || null, project: ev.project || null };
    log.push(entry); if (log.length > 300) log.shift();
    if (!on()) { entry.skip = 'מתג ראשי כבוי'; stats.skipped++; return emitLog(entry); }
    const cc = chatCfg(ev.conv);
    if (cc.mute) { entry.skip = 'השיחה מושתקת'; stats.skipped++; return emitLog(entry); }
    // צליל ממחשב ברשת (גם המחשב שלך כשאתה עובד על מחשב אחר): לפי ההגדרות של אותו מחשב
    const mid = ev.machine || null, mc = machineCfg(mid); if (mid) { entry.machine = mid; entry.machineName = ev.machineName || ''; }
    if (mid && (S().otherMachines === false && mid !== ((window.MESH && MESH.remote) || (App.mesh && App.mesh.selfId())))) { entry.skip = 'צלילים ממחשבים אחרים כבויים'; stats.skipped++; return emitLog(entry); }
    if (mid && mc.mute) { entry.skip = 'המחשב מושתק'; stats.skipped++; return emitLog(entry); }
    if (mid && mc.onlyViewing && mid !== ((window.MESH && MESH.remote) || (App.mesh && App.mesh.selfId()))) { entry.skip = 'מושמע רק כשעובדים על המחשב הזה'; stats.skipped++; return emitLog(entry); }
    const lvl = levelFor(ev.conv, mid); entry.level = lvl;
    const prof = profileFor(ev.project, mid); entry.profile = prof.id;
    const cand = [...keys].sort((a, b) => RANK(a) - RANK(b)).filter(k => (CAT.levelOf ? CAT.levelOf(k) : 3) <= lvl).map(k => ({ k, c: eventCfg(prof, k) })).filter(x => x.c.on);
    if (!cand.length) { entry.skip = keys.some(k => (CAT.levelOf ? CAT.levelOf(k) : 3) > lvl) ? 'מעל רמת הצלילים (' + (CAT.LEVELS || {})[lvl] + ')' : 'כבוי לאירוע הזה'; return emitLog(entry); }
    const { k, c } = cand[0]; entry.key = k; entry.src = c.src;
    const now = Date.now(); if (now - (lastPlay.get(k) || 0) < 250) { entry.skip = 'מהיר מדי (אותו אירוע לפני פחות מ-250ms)'; return emitLog(entry); }
    lastPlay.set(k, now);
    try {
      // מגבלת מנוי: המשפט עם הנותר ("…נותרו ארבעים אחוז") במקום המשפט הכללי
      // מעבר שלב במחקר: "החוקרים יצאו לחקור" / "כותב את הדוח"
      const VAR = { 'ev:limit': 'x:limit_', 'ev:research_stage': 'x:rstage_' };
      const vk = VAR[k] && ev.variant && /^voice/.test(c.src) ? VAR[k] + ev.variant : k; if (vk !== k) entry.variant = ev.variant;
      const r = await playSrc(c.src, { vol: c.vol * (cc.vol != null ? cc.vol : 1) * (mid && mc.vol != null ? +mc.vol : 1), voice: prof.voice || 'asaf', key: vk, queueVoice: !c.src.startsWith('syn:') });
      if (!r) entry.skip = 'המקור לא נמצא'; else if (r.dropped) entry.skip = 'דולג — כבר מתנגנים קולות'; else { entry.played = true; entry.dur = +r.dur.toFixed(3); entry.startsIn = r.startsIn; stats.played++; stats.lastAt = Date.now(); stats.ctxState = ctx && ctx.state; measure(entry, r.dur + (r.startsIn || 0)); }
    } catch (e) { entry.skip = 'שגיאה: ' + e.message; }
    emitLog(entry);
  }
  function emitLog(entry) { try { App.emit('sound:played', entry); } catch { } }
  // השמעה מהממשק (כפתור ▶): עוקף את מתג האירוע, לא את המתג הראשי (אלא אם force)
  async function preview(src, { voice, key, force } = {}) {
    if (!force && !on()) { App.toast && App.toast('🔇 הצלילים כבויים (מתג ראשי)', 1800); return null; }
    const entry = { at: Date.now(), keys: [key || src], preview: true, src };
    const r = await playSrc(src, { voice: voice || (profileFor(null).voice), key: key || '', queueVoice: false });
    if (r) { entry.played = true; entry.dur = +r.dur.toFixed(3); measure(entry, r.dur); } else entry.skip = 'המקור לא נמצא';
    log.push(entry); emitLog(entry); return r;
  }
  // תאימות: הצליל הישן של "Claude סיים"
  function chime(force) { return handle({ keys: ['ev:finish'], forceTest: !!force }), true; }
  // ניתוח צליל (בלי להשמיע): רינדור לא-מקוון → משך, שיא, שקט בקצוות — הוכחה שהחיתוך מדויק
  async function analyze(src, { voice = 'asaf', key = '' } = {}) {
    getCtx(); let clip = null, sr = 44100;
    if (src.startsWith('syn:')) { const off = new OfflineAudioContext(1, sr * 4, sr); const d = LIB.play(off, off.destination, src.slice(4), 0, 1); const b = await off.startRendering(); return stat(b.getChannelData(0).subarray(0, Math.ceil((d + 0.06) * sr)), sr); }
    if (src === 'voice' || src.startsWith('voice:')) clip = await voiceClip(src === 'voice' ? voice : src.slice(6), key);
    else if (src.startsWith('phrase:')) { const [, v, ...k] = src.split(':'); clip = await voiceClip(v, k.join(':')); }
    else if (src.startsWith('custom:')) clip = await customClip(src.slice(7));
    if (!clip) return null; const ch = clip.buf.getChannelData(0); sr = clip.buf.sampleRate;
    return stat(ch.subarray(Math.floor(clip.start * sr), Math.ceil(clip.end * sr)), sr);
  }
  function stat(x, sr) { let pk = 0; for (const v of x) pk = Math.max(pk, Math.abs(v)); const thr = Math.max(0.003, pk * 0.02); let a = 0, b = x.length - 1; while (a < x.length && Math.abs(x[a]) < thr) a++; while (b > a && Math.abs(x[b]) < thr) b--; return { dur: +(x.length / sr).toFixed(3), peak: +pk.toFixed(3), leadMs: Math.round(a / sr * 1000), tailMs: Math.round((x.length - 1 - b) / sr * 1000) }; }

  App.on && App.on('sound:event', ev => handle(ev));
  App.sound = { chime, unlock, stats, log, handle, preview, playSrc, analyze, profileFor, eventCfg, chatCfg, machineCfg, levelFor, stretch, settings: S, defaults: DEF, manifest: loadManifest, voices: async () => (await loadManifest()).voices || [] };
})();
