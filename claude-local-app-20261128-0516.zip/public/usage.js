// ============================================================
//  usage.js — בר השימוש בסרגל העליון, הכי פשוט שאפשר:
//   מצב API (טוקנים): כסף — כמה נשאר מתוך כמה.
//   מצב מנוי: USAGE — כמה אחוז השתמשת וכמה נשאר (נתונים אמיתיים מהחשבון, כפי ש-Claude Code מדווח).
//  וגם תג החשבון (מנוי + שם משתמש / מפתח API).
// ============================================================
(function () {
  const App = window.App, $ = App.$, fmt = App.fmt;
  const money = fmt.money;
  let last = null, busy = false;

  App.usage = { get data() { return last; }, refresh: force => refresh(force) };

  async function refresh(force) {
    if (busy) return last; busy = true;
    try { const u = last = await App.api('/api/usage' + (force ? '?refresh=1' : '')); render(u); App.emit('usage:data', u); }
    catch (e) { $('budgetTitle').textContent = 'USAGE'; $('budgetLabel').textContent = '—'; $('budgetFill').classList.add('none'); }
    finally { busy = false; }
    return last;
  }

  function setBar(pct, known) {
    const fill = $('budgetFill');
    fill.classList.toggle('none', !known);
    if (known) { fill.style.width = Math.max(2, pct) + '%'; fill.classList.toggle('mid', pct >= 60 && pct < 85); fill.classList.toggle('high', pct >= 85); }
    else { fill.style.width = ''; fill.classList.remove('mid', 'high'); }
  }

  function render(u) {
    const title = $('budgetTitle'), label = $('budgetLabel');
    if (u.mode === 'subscription') {
      title.textContent = 'USAGE';
      const s = u.subscription;
      if (s && s.ok && s.windows.length) {
        const main = s.windows.reduce((a, b) => (b.utilization > a.utilization ? b : a));
        const used = Math.round(main.utilization);
        label.innerHTML = `<bdi>${used}% בשימוש</bdi> · <bdi>נשאר ${Math.max(0, 100 - used)}%</bdi>`;
        label.title = s.windows.map(w => `${w.label}: ${Math.round(w.utilization)}%` + (w.resetsAt ? ` · איפוס ${App.fmt.fullDateTime(w.resetsAt)}` : '')).join('\n');
        setBar(main.utilization, true);
      } else { label.textContent = u.subscriptionError ? 'לא מחובר' : 'טוען…'; setBar(0, false); }
    } else {
      const t = u.usage || {}, spent = t.totalCostUSD || 0, budget = u.creditBudgetUSD || 0;
      title.textContent = 'API';
      if (budget > 0) { setBar(Math.min(100, spent / budget * 100), true); label.innerHTML = `<bdi>נשאר ${money(Math.max(0, budget - spent))}</bdi> <bdi>מתוך ${money(budget)}</bdi>`; }
      else { setBar(0, false); label.innerHTML = `<bdi>נוצל ${money(spent)}</bdi>`; }
      label.title = budget > 0 ? '' : 'אפשר להגדיר תקציב בהגדרות › חשבון';
    }
  }

  // תג החשבון בסרגל העליון: מנוי (סוג + משתמש) או מפתח API. לחיצה = הגדרות › חשבון
  function renderBadge() {
    const c = App.state.config; if (!c) return;
    const sub = c.accountMode === 'subscription', badge = $('accountBadge');
    badge.classList.toggle('sub', sub);
    $('accIcon').textContent = sub ? '👑' : '🔑';
    if (sub) {
      const plan = last && last.subscription && last.subscription.plan ? last.subscription.plan.replace(/^Claude\s*/i, '').replace(/\s*account$/i, '') : 'מנוי';
      const who = c.cliEmail ? ' · ' + c.cliEmail.split('@')[0] : '';
      $('accText').textContent = c.cliLoggedIn === false ? 'מנוי (לא מחובר)' : plan + who;
      badge.title = c.cliLoggedIn === false ? 'לא מחובר — לחץ להתחברות' : 'מחובר כ-' + (c.cliEmail || '');
    } else {
      $('accText').textContent = c.hasApiKey ? 'API · ' + c.apiKeyPreview : 'API (אין מפתח)';
      badge.title = 'מצב API';
    }
  }
  App.on('config:changed', renderBadge); App.on('usage:data', renderBadge);

  // עדכון מיידי מאירוע rate_limit של Claude Code בזמן ריצה (utilization 0..1)
  App.on('usage:rate', d => {
    if (!last || !last.subscription || !d.info || !d.info.unifiedWindows) return;
    for (const [k, w] of Object.entries(d.info.unifiedWindows)) { const cur = last.subscription.windows.find(x => x.key === k); if (cur && typeof w.utilization === 'number') { cur.utilization = w.utilization * 100; if (w.resetsAt) cur.resetsAt = w.resetsAt * 1000; } }
    render(last);
  });
  let t = null; const soon = () => { clearTimeout(t); t = setTimeout(() => refresh(), 600); };
  App.on('account:changed', async () => { try { await App.loadConfig(); } catch { } refresh(true); });
  App.on('usage:refresh', soon); App.on('usage:changed', soon); App.on('config:changed', soon);
  App.ready(() => { renderBadge(); refresh(); setInterval(() => refresh(), 30000); setInterval(() => refresh(true), 5 * 60 * 1000); });
})();
