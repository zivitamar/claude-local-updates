'use strict';
// ============================================================
//  "📥 מ-VS Code" — כל הצ'אטים של Claude Code מכל חלונות ה-VS Code (חיפוש), ו"פתח כאן" = העתק מדויק לשיחה חדשה:
//  אותו סשן (fork רשמי — המקור לא משתנה), אותה תיקייה (CLAUDE.md, זיכרון, הוקים, הגדרות), אותו מודל והרשאות.
//  אותה פעולה זמינה ל-Claude עצמו בכלים vscode_chats / vscode_chat_open.
// ============================================================
(function () {
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ago = t => { const m = Math.round((Date.now() - t) / 60000); return m < 1 ? 'עכשיו' : m < 60 ? 'לפני ' + m + ' דק\'' : m < 1440 ? 'לפני ' + Math.round(m / 60) + ' שע\'' : 'לפני ' + Math.round(m / 1440) + ' ימים'; };
  const shortModel = id => { const m = App.modelLabel ? App.modelLabel(id) : ''; return m && m !== id ? m : String(id || '').replace(/^claude-/, ''); };
  async function open() {
    const body = App.el('div', 'vsi');
    body.innerHTML = `<p class="vsi-help">כל הצ'אטים של Claude מכל חלונות ה-VS Code במחשב. <b>פתח כאן</b> יוצר שיחה חדשה שממשיכה <b>בדיוק מאותה נקודה</b> — עם כל ההיסטוריה, באותה תיקייה (אותו CLAUDE.md, זיכרון, הוקים והגדרות), אותו מודל ואותן הרשאות. הצ'אט ב-VS Code לא משתנה.</p>
      <div class="vsi-bar"><input type="search" class="text-input vsi-q" placeholder="🔍 חיפוש לפי שם הצ'אט או ההודעה הראשונה…"><label class="vsi-all"><input type="checkbox" class="vsi-src"> גם צ'אטים מהטרמינל</label></div>
      <div class="vsi-count ag-dim"></div><div class="vsi-list"></div>`;
    const m = App.modal({ title: '📥 צ\'אטים מ-VS Code', body, cls: 'vsi-modal' });
    const q = body.querySelector('.vsi-q'), list = body.querySelector('.vsi-list'), cnt = body.querySelector('.vsi-count'), src = body.querySelector('.vsi-src');
    let seq = 0;
    async function load() {
      const my = ++seq; list.innerHTML = '<div class="ag-dim">טוען…</div>';
      let r; try { r = await App.api('/api/vscode/chats?limit=200&q=' + encodeURIComponent(q.value.trim()) + (src.checked ? '&source=all' : '')); } catch (e) { if (my === seq) list.innerHTML = '<div class="notice error">❌ ' + esc(e.message) + '</div>'; return; }
      if (my !== seq) return;
      cnt.textContent = (q.value.trim() ? r.items.length + ' תוצאות מתוך ' : '') + r.total + ' צ\'אטים';
      list.innerHTML = '';
      if (!r.items.length) { list.innerHTML = '<div class="ag-empty">לא נמצא צ\'אט מתאים</div>'; return; }
      for (const c of r.items) {
        const row = App.el('div', 'vsi-row' + (c.live ? ' live' : ''));
        row.innerHTML = `<div class="vsi-main"><b class="vsi-t">${esc(c.title)}</b><small class="ag-dim">${c.live ? (c.live.status === 'busy' ? '<span class="vsi-dot busy"></span>פתוח ועובד עכשיו' : '<span class="vsi-dot"></span>פתוח ב-VS Code') : 'סגור'} · ${esc(ago(c.lastTs))} · ${esc(shortModel(c.model) || '?')} · <bdi dir="ltr">${esc(c.cwd)}</bdi></small></div><button class="btn-primary vsi-go">פתח כאן</button>`;
        row.querySelector('.vsi-go').onclick = async ev => {
          const b = ev.currentTarget; b.disabled = true; b.textContent = 'מעתיק…';
          try {
            const res = await App.api('/api/vscode/import', { method: 'POST', body: { sessionId: c.sessionId } });
            m.close(); try { await App.projects.reload(); } catch { }
            await App.chats.openConversation(res.id);
            App.toast('📥 נפתח כאן: ' + res.title + ' (' + res.messages + ' הודעות) — ממשיך מאותה נקודה', 4500);
          } catch (e) { b.disabled = false; b.textContent = 'פתח כאן'; App.toast('❌ ' + e.message, 5000); }
        };
        list.appendChild(row);
      }
    }
    let t = null; q.oninput = () => { clearTimeout(t); t = setTimeout(load, 220); }; src.onchange = load;
    await load(); setTimeout(() => q.focus(), 50);
  }
  App.vscodeImport = { open };
  document.addEventListener('DOMContentLoaded', () => { const b = document.getElementById('vscodeImportBtn'); if (b) b.onclick = open; });
  { const b = document.getElementById('vscodeImportBtn'); if (b) b.onclick = open; }
})();
