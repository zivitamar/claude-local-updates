// ============================================================
//  c2c.js — 🤝 הודעות בין Claude-ים שממתינות לאישור שלך (הגדרות → הרשאות → "כל בקשה באישורך")
//  כרטיס צף בראש אזור הצ'אט, לא משנה איזה צ'אט פתוח: מאיזה צ'אט, לאיזה צ'אט, הטקסט המלא — "אשר ושלח" / "דחה".
//  ההודעה מגיעה לצ'אט היעד רק אחרי שאישרת. האישור נבדק בשרת: רק מחלון האפליקציה (Claude לא יכול לאשר לעצמו)
// ============================================================
(function () {
  'use strict';
  const el = App.el, esc = App.esc;
  const pend = new Map();
  let box = null;
  function host() {
    if (box && document.body.contains(box)) return box;
    box = el('div', 'c2c-stack'); box.id = 'c2cStack';
    (document.getElementById('chatstack') || document.body).appendChild(box);
    return box;
  }
  function render() {
    const b = host(); b.innerHTML = ''; b.hidden = !pend.size;
    for (const p of pend.values()) {
      const o = p.origin || {}, t = p.target || {};
      const c = el('div', 'c2c-card'); c.dataset.id = p.id;
      c.innerHTML = `<div class="c2c-h">🤝 <b>Claude בצ'אט ${esc(o.code || '?')}</b>${o.title ? ' «' + esc(o.title) + '»' : ''}${o.machine ? ' · ' + esc(o.machine) : ''} רוצה לשלוח לצ'אט <b>${esc(t.code || '?')}</b>${t.title ? ' «' + esc(t.title) + '»' : ''}:</div>
        <div class="c2c-text"></div>
        <div class="c2c-bar"><button class="btn-primary c2c-ok">אשר ושלח</button><button class="btn-ghost c2c-no">דחה</button><span class="c2c-note">ההודעה תגיע לשם רק אם תאשר · הגדרות → הרשאות → תקשורת בין Claude-ים</span></div>`;
      c.querySelector('.c2c-text').textContent = p.text;
      c.querySelector('.c2c-ok').onclick = () => decide(p, 'approve');
      c.querySelector('.c2c-no').onclick = () => decide(p, 'reject');
      b.appendChild(c);
    }
  }
  async function decide(p, d) {
    try { const r = await App.api('/api/c2c/' + p.id + '/' + d, { method: 'POST', body: {} }).catch(e => { if (e && e.status === 502) return { error: e.message }; throw e; }); pend.delete(p.id); render(); if (r && r.error) { App.toast('❌ אושר, אבל ההודעה לא נמסרה: ' + r.error, 6000); return; } if (r && r.decision === 'expired') { App.toast('⌛ ההודעה פגה (24 שעות) — לא נשלחה', 5000); return; } if (r && r.decision === 'gone') { App.toast('הצ\'אט שאליו נשלחה נמחק — ההודעה לא נשלחה', 5000); return; } App.toast(d === 'approve' ? '🤝 אושר — ההודעה נשלחה לצ\'אט ' + ((p.target || {}).code || '') : 'ההודעה נדחתה ולא נשלחה', 2200); }
    catch (e) { App.toast('❌ ' + e.message, 4000); }
  }
  async function load() { try { const r = await App.api('/api/c2c/pending'); pend.clear(); for (const p of r.pending || []) pend.set(p.id, p); render(); } catch { } }
  App.on('c2c:event', ({ type, data }) => { if (type === 'c2c_pending') pend.set(data.id, data); else pend.delete(data.id); render(); });
  App.c2c = { pending: () => [...pend.values()], load, render };
  App.ready(load);
})();
