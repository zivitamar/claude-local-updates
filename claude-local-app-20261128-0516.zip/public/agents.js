// ============================================================
//  agents.js — פאנל "סוכנים" + "מחקר עמוק" + מציג סוכן + מציג מחקר + אייקוני כלים (App.toolIcon)
//  חוזה: docs/UI-CONTRACT.md · הנתונים תמיד מהשרת (/api/agents, /api/research, /api/running + SSE),
//  כך שרענון דף באמצע ריצה לא מאבד כלום. כל מה שרלוונטי לבדיקה חושף data-* ו-id יציבים.
// ============================================================
(function () {
  'use strict';
  const App = window.App;
  if (!App) { console.error('[agents] window.App missing'); return; }

  // ---------- כלים קטנים ----------
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const $ = id => document.getElementById(id);
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const TERMINAL = new Set(['done', 'error', 'stopped', 'interrupted', 'refused']);
  const isTerm = s => TERMINAL.has(s);
  const md = text => (window.renderMarkdown ? window.renderMarkdown(text || '') : esc(text || ''));
  // מנוי: אין דולרים בכלל — רק אחוז מהמנוי (אם ידוע). API: עלות בדולר
  const isSub = () => (App.state.config || {}).accountMode === 'subscription';
  const pctTxt = p => { if (!p) return ''; const a = []; if (p.seven_day != null) a.push(App.fmt.pct(p.seven_day) + ' מהשבועי'); if (p.five_hour != null) a.push(App.fmt.pct(p.five_hour) + ' מ-5 השעות'); return a.join(' · '); };
  // ערך העלות בחלון סוכן / מחקר: כל הבלוק (כולל האייקון 💲) מוסתר כשאין ערך; במנוי — אחוז מהמנוי בלי 💲
  const setCost = (b, txt) => { const w = b.closest('.ag-costw') || b; w.hidden = !txt; b.textContent = txt; const ic = w.querySelector && w.querySelector('.ag-cost-ic'); if (ic) ic.hidden = isSub(); w.title = isSub() ? 'שימוש מהמנוי' : 'עלות'; };
  const money = (c, pct) => { if (isSub()) return pctTxt(pct); c = Number(c) || 0; return c > 0 && c < 0.0005 ? '<$0.001' : App.fmt.money(c); };
  const tokTxt = t => (t ? `↓${App.fmt.num(t.input || 0)} ↑${App.fmt.num(t.output || 0)}` : '');
  const hostOf = u => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return ''; } };
  const clip = (s, n) => { s = String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
  // שורת פעילות: "תווית בעברית: ערך LTR" (פקודה / נתיב / כתובת). הערך נחתך בסופו עם …, לא בתחילתו
  function setAct(node, text) {
    text = String(text == null ? '' : text);
    node.title = text;
    const m = /^([^:]{2,40}):\s+(\S[\s\S]*)$/.exec(text);
    if (m && /[֐-׿]/.test(m[1]) && !/[֐-׿]/.test(m[2])) {
      if (node._act === text) return;
      node._act = text; node.classList.add('split');
      node.innerHTML = '<span class="ag-act-l"></span><span class="ag-act-c"></span>';
      node.firstChild.textContent = m[1] + ':'; node.lastChild.textContent = m[2];
    } else {
      node.classList.remove('split');
      if (node._act !== text || node.firstElementChild) { node._act = text; node.textContent = text; }
    }
  }
  const shortModel = id => { id = String(id || ''); const m = App.modelLabel ? App.modelLabel(id) : id; return m && m !== id ? m : id.replace(/^claude-/, ''); };
  const kindLabel = k => ({ agent: 'סוכן', research: 'חוקר', 'cli-task': 'משימת CLI' }[k] || k || 'סוכן');
  const DEPTH_LABEL = { quick: 'מהיר', standard: 'רגיל', deep: 'עמוק' };
  const guard = (name, fn) => { try { return fn(); } catch (e) { console.error('[agents:' + name + ']', e); } };

  // ============================================================
  //  1) אייקוני כלים — App.toolIcon / App.toolLabel / App.toolSummary
  // ============================================================
  const ICONS = {};
  const def = (key, label, inner) => { ICONS[key] = { label, inner }; };
  const MONO = "Consolas,'Cascadia Mono','Courier New',monospace";
  // --- shells: שלושה אייקונים שונים לגמרי ---
  def('bash', 'Bash',
    `<rect x="1.5" y="1.5" width="21" height="21" rx="5.5" fill="#1b6fd9" stroke="#74b0ff" stroke-width=".9"/>` +
    `<text x="4.4" y="16.7" direction="ltr" font-family="${MONO}" font-size="14" font-weight="700" fill="#fff">$</text>` +
    `<rect x="12.8" y="15.2" width="6.4" height="2.4" rx="1.2" fill="#fff"/>`);
  def('cmd', 'CMD',
    `<rect x="1.5" y="3" width="21" height="18" rx="2.6" fill="#0a0a0a" stroke="#a0a0a0" stroke-width="1.2"/>` +
    `<path d="M1.5 5.6A2.6 2.6 0 014.1 3h15.8a2.6 2.6 0 012.6 2.6V7.4H1.5z" fill="#e4e4e4"/>` +
    `<circle cx="4.6" cy="5.2" r=".9" fill="#555"/><circle cx="7.2" cy="5.2" r=".9" fill="#555"/>` +
    `<text x="3.3" y="17.6" direction="ltr" font-family="${MONO}" font-size="8" font-weight="700" fill="#f2f2f2">C:\\</text>` +
    `<rect x="15.7" y="15.2" width="3.8" height="2.4" fill="#f2f2f2"/>`);
  def('powershell', 'PowerShell',
    `<rect x="1.5" y="1.5" width="21" height="21" rx="5.5" fill="#0f2f6e" stroke="#4f86e0" stroke-width=".9"/>` +
    `<path d="M5.4 7.4l6.3 4.7-6.3 4.7" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" fill="none"/>` +
    `<path d="M13.2 17.4h6" stroke="#fff" stroke-width="2.4" stroke-linecap="round"/>`);
  // --- קבצים ---
  def('read', 'קריאת קובץ',
    `<path d="M12 6.6C10 5 7 4.6 3.4 4.9v12.5c3.6-.3 6.6.1 8.6 1.7 2-1.6 5-2 8.6-1.7V4.9C17 4.6 14 5 12 6.6z" fill="#27364f" stroke="#6fb0ff" stroke-width="1.5" stroke-linejoin="round"/>` +
    `<path d="M12 6.6v12.5" stroke="#6fb0ff" stroke-width="1.5"/>` +
    `<path d="M6 8.6h3.4M6 11.2h3.4M14.6 8.6H18M14.6 11.2H18" stroke="#a9ceff" stroke-width="1.2" stroke-linecap="round"/>`);
  def('write', 'כתיבת קובץ',
    `<path d="M6 2.8h8.4L19 7.4v13.8H6z" fill="#243a2c" stroke="#6fd07a" stroke-width="1.5" stroke-linejoin="round"/>` +
    `<path d="M14.2 2.9v4.7H19" fill="none" stroke="#6fd07a" stroke-width="1.5" stroke-linejoin="round"/>` +
    `<path d="M12.5 11.4v6M9.5 14.4h6" stroke="#b7f0bc" stroke-width="1.9" stroke-linecap="round"/>`);
  def('edit', 'עריכת קובץ',
    `<path d="M16.6 3.4a2.4 2.4 0 013.4 3.4L8 18.8l-4.4 1 1-4.4z" fill="#4a3320" stroke="#f2a65a" stroke-width="1.5" stroke-linejoin="round"/>` +
    `<path d="M14.6 5.4l3.4 3.4" stroke="#f2a65a" stroke-width="1.5"/>`);
  def('multiedit', 'כמה עריכות',
    `<path d="M17 2.8a2.2 2.2 0 013.1 3.1L10.4 15.6l-4 .9.9-4z" fill="#4a3320" stroke="#f2a65a" stroke-width="1.4" stroke-linejoin="round"/>` +
    `<path d="M3.6 19h16.8M3.6 21.6h10.4" stroke="#f2a65a" stroke-width="1.6" stroke-linecap="round" opacity=".85"/>`);
  def('folder', 'תיקייה',
    `<path d="M2.8 6.6a2 2 0 012-2h4.3l2.1 2.5h7.9a2 2 0 012 2v8.9a2 2 0 01-2 2H4.8a2 2 0 01-2-2z" fill="#5a4416" stroke="#f0c04a" stroke-width="1.5" stroke-linejoin="round"/>` +
    `<path d="M2.8 9.6h18.4" stroke="#f0c04a" stroke-width="1.3" opacity=".7"/>`);
  def('search', 'חיפוש קבצים',
    `<circle cx="10.2" cy="10.2" r="6.2" fill="#143a46" stroke="#5ed0ea" stroke-width="1.8"/>` +
    `<path d="M14.9 14.9l5.7 5.7" stroke="#5ed0ea" stroke-width="2.5" stroke-linecap="round"/>` +
    `<path d="M7.4 8.3a3.4 3.4 0 012.1-1.5" stroke="#b7eefb" stroke-width="1.3" stroke-linecap="round" fill="none"/>`);
  def('grep', 'חיפוש בתוכן',
    `<circle cx="10.2" cy="10.2" r="6.2" fill="#143a46" stroke="#5ed0ea" stroke-width="1.8"/>` +
    `<path d="M7.2 8.4h6M7.2 10.4h6M7.2 12.4h3.6" stroke="#b7eefb" stroke-width="1.3" stroke-linecap="round"/>` +
    `<path d="M14.9 14.9l5.7 5.7" stroke="#5ed0ea" stroke-width="2.5" stroke-linecap="round"/>`);
  def('glob', 'חיפוש לפי תבנית',
    `<path d="M5.4 2.8h9L19 7.4v13.8H5.4z" fill="#143a46" stroke="#5ed0ea" stroke-width="1.5" stroke-linejoin="round"/>` +
    `<path d="M14.2 2.9v4.7H19" fill="none" stroke="#5ed0ea" stroke-width="1.5" stroke-linejoin="round"/>` +
    `<path d="M12.2 10.4v7M9.2 11.9l6 4M15.2 11.9l-6 4" stroke="#b7eefb" stroke-width="1.7" stroke-linecap="round"/>`);
  // --- רשת ---
  const GLOBE = (cx, cy, r) => `<circle cx="${cx}" cy="${cy}" r="${r}" fill="#13323f" stroke="#58b8ff" stroke-width="1.5"/>` +
    `<ellipse cx="${cx}" cy="${cy}" rx="${(r * 0.42).toFixed(2)}" ry="${r}" fill="none" stroke="#58b8ff" stroke-width="1.2"/>` +
    `<path d="M${cx - r} ${cy}h${2 * r}M${(cx - r * 0.84).toFixed(2)} ${(cy - r * 0.5).toFixed(2)}h${(r * 1.68).toFixed(2)}M${(cx - r * 0.84).toFixed(2)} ${(cy + r * 0.5).toFixed(2)}h${(r * 1.68).toFixed(2)}" stroke="#58b8ff" stroke-width="1.1"/>`;
  def('websearch', 'חיפוש ברשת',
    GLOBE(10.4, 10.4, 7.2) +
    `<circle cx="17" cy="17" r="3.7" fill="#0f2a38" stroke="#7de3ff" stroke-width="1.7"/>` +
    `<path d="M19.7 19.7l2.3 2.3" stroke="#7de3ff" stroke-width="2.1" stroke-linecap="round"/>`);
  def('webfetch', 'קריאת דף',
    GLOBE(10.8, 10.8, 7.8) +
    `<circle cx="18" cy="18" r="4.7" fill="#183326" stroke="#6fd07a" stroke-width="1.5"/>` +
    `<path d="M18 15.6v4.4M16.1 18.3l1.9 1.9 1.9-1.9" stroke="#b7f0bc" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`);
  // --- סוכנים ---
  def('agent', 'סוכן',
    `<rect x="4.5" y="8" width="15" height="11.5" rx="3.4" fill="#2f2750" stroke="#a78bfa" stroke-width="1.6"/>` +
    `<path d="M12 8V4.8" stroke="#a78bfa" stroke-width="1.6" stroke-linecap="round"/><circle cx="12" cy="3.6" r="1.6" fill="#d3c4ff"/>` +
    `<circle cx="9" cy="13" r="1.7" fill="#d3c4ff"/><circle cx="15" cy="13" r="1.7" fill="#d3c4ff"/>` +
    `<path d="M9.4 16.5h5.2" stroke="#d3c4ff" stroke-width="1.5" stroke-linecap="round"/>` +
    `<path d="M2.6 12.2v3.4M21.4 12.2v3.4" stroke="#a78bfa" stroke-width="1.8" stroke-linecap="round"/>`);
  def('research', 'מחקר עמוק',
    `<path d="M9.4 3.4h5.2" stroke="#37d6b4" stroke-width="1.7" stroke-linecap="round"/>` +
    `<path d="M7 15.4h10l1.7 3a1.1 1.1 0 01-1 1.6H6.3a1.1 1.1 0 01-1-1.6z" fill="#37d6b4" opacity=".5"/>` +
    `<path d="M10.4 3.6v5.4L4.9 18.4a2 2 0 001.7 3h10.8a2 2 0 001.7-3L13.6 9V3.6" fill="none" stroke="#37d6b4" stroke-width="1.6" stroke-linejoin="round"/>` +
    `<circle cx="10.6" cy="12.8" r="1" fill="#9af2de"/><circle cx="13.7" cy="14.2" r=".8" fill="#9af2de"/>`);
  // --- שונות ---
  def('todo', 'רשימת משימות',
    `<rect x="3.2" y="3.8" width="4.6" height="4.6" rx="1.2" fill="#25402b" stroke="#6fd07a" stroke-width="1.4"/>` +
    `<path d="M4.4 6.2l1.1 1.1 1.9-2.3" stroke="#b7f0bc" stroke-width="1.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>` +
    `<rect x="3.2" y="9.7" width="4.6" height="4.6" rx="1.2" fill="none" stroke="#9a9a9a" stroke-width="1.4"/>` +
    `<rect x="3.2" y="15.6" width="4.6" height="4.6" rx="1.2" fill="none" stroke="#9a9a9a" stroke-width="1.4"/>` +
    `<path d="M11 6.1h9.6M11 12h9.6M11 17.9h9.6" stroke="#cfcfcf" stroke-width="1.7" stroke-linecap="round"/>`);
  def('notebook', 'מחברת',
    `<rect x="5.6" y="3" width="14" height="18" rx="2" fill="#2a2f46" stroke="#8aa4ff" stroke-width="1.5"/>` +
    `<path d="M3.2 7h4.8M3.2 12h4.8M3.2 17h4.8" stroke="#8aa4ff" stroke-width="1.8" stroke-linecap="round"/>` +
    `<path d="M17.6 8.4l-5.5 5.5-.8 2.6 2.6-.8 5.5-5.5z" fill="#f2a65a" stroke="#f2a65a" stroke-width="1" stroke-linejoin="round"/>`);
  def('skill', 'Skill',
    `<path d="M11.4 3l2.2 6 6.1 2.2-6.1 2.3-2.2 6-2.3-6-6.1-2.3 6.1-2.2z" fill="#4a3d18" stroke="#f0c04a" stroke-width="1.5" stroke-linejoin="round"/>` +
    `<path d="M19.4 2.8v3.6M17.6 4.6h3.6" stroke="#f0c04a" stroke-width="1.4" stroke-linecap="round"/>` +
    `<path d="M19 17.4v3M17.5 18.9h3" stroke="#f0c04a" stroke-width="1.3" stroke-linecap="round"/>`);
  def('toolsearch', 'חיפוש כלי',
    `<path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z" fill="#2c3040" stroke="#c3c8d4" stroke-width="1.5" stroke-linejoin="round"/>`);
  def('plug', 'כלי MCP',
    `<path d="M8.6 2.6v5M15.4 2.6v5" stroke="#4ec9b0" stroke-width="1.9" stroke-linecap="round"/>` +
    `<path d="M5.6 7.6h12.8v3.6a6.4 6.4 0 01-12.8 0z" fill="#183a36" stroke="#4ec9b0" stroke-width="1.6" stroke-linejoin="round"/>` +
    `<path d="M12 17.6v4" stroke="#4ec9b0" stroke-width="1.9" stroke-linecap="round"/>`);
  def('gear', 'כלי',
    `<path d="M12 2.8v2.8M12 18.4v2.8M2.8 12h2.8M18.4 12h2.8M5.5 5.5l2 2M16.5 16.5l2 2M18.5 5.5l-2 2M7.5 16.5l-2 2" stroke="#b0b4bd" stroke-width="2.3" stroke-linecap="round"/>` +
    `<circle cx="12" cy="12" r="6.2" fill="#2a2d33" stroke="#b0b4bd" stroke-width="1.6"/>` +
    `<circle cx="12" cy="12" r="2.4" fill="none" stroke="#b0b4bd" stroke-width="1.6"/>`);

  const NAME_KEY = {
    read_file: 'read', Read: 'read', write_file: 'write', Write: 'write', edit_file: 'edit', Edit: 'edit', MultiEdit: 'multiedit',
    list_directory: 'folder', Glob: 'glob', search_files: 'search', Grep: 'grep', web_search: 'websearch', WebSearch: 'websearch',
    web_fetch: 'webfetch', WebFetch: 'webfetch', agent: 'agent', Task: 'agent', deep_research: 'research', TodoWrite: 'todo',
    NotebookEdit: 'notebook', Skill: 'skill', ToolSearch: 'toolsearch'
  };
  const IS_WIN = /win/i.test((navigator && navigator.platform) || '') || /windows/i.test((navigator && navigator.userAgent) || '');
  // איזה shell רץ? 'bash' | 'cmd' | 'powershell' | null (הכלי אינו פקודת shell)
  function shellOf(name, input) {
    const i = input || {};
    if (name === 'run_command') {
      const sh = String(i.shell || '').toLowerCase();
      if (sh === 'bash' || sh === 'sh') return 'bash';
      if (sh === 'cmd') return 'cmd';
      if (sh === 'powershell' || sh === 'pwsh') return 'powershell';
      return IS_WIN ? 'powershell' : 'bash';
    }
    if (name === 'PowerShell') return 'powershell';
    if (name === 'Bash') {
      const c = String(i.command || '');
      if (/^\s*(cmd(\.exe)?\s+\/[ck]\b|@echo\s+off|call\s+\S+\.(bat|cmd)\b)/i.test(c)) return 'cmd';
      if (/^\s*(powershell(\.exe)?|pwsh(\.exe)?)\b/i.test(c)) return 'powershell';
      return 'bash';
    }
    return null;
  }
  function iconKey(name, input) {
    const sh = shellOf(name, input);
    if (sh) return sh;
    if (NAME_KEY[name]) return NAME_KEY[name];
    if (/^mcp__/i.test(String(name || ''))) return 'plug';
    return 'gear';
  }
  const svgOf = key => { const d = ICONS[key] || ICONS.gear; return `<svg class="tic" data-icon="${ICONS[key] ? key : 'gear'}" viewBox="0 0 24 24" width="22" height="22" role="img" aria-label="${esc(d.label)}" xmlns="http://www.w3.org/2000/svg">${d.inner}</svg>`; };
  const SHELL_NAME = { bash: 'Bash', cmd: 'CMD', powershell: 'PowerShell' };
  const LABELS = {
    read_file: 'קורא קובץ', Read: 'קורא קובץ', write_file: 'כותב קובץ', Write: 'כותב קובץ', edit_file: 'עורך קובץ', Edit: 'עורך קובץ',
    MultiEdit: 'עורך קובץ (כמה עריכות)', list_directory: 'מציג תיקייה', Glob: 'מחפש קבצים (Glob)', search_files: 'מחפש בקבצים',
    Grep: 'מחפש בתוכן (Grep)', web_search: 'חיפוש ברשת', WebSearch: 'חיפוש ברשת', web_fetch: 'קורא דף אינטרנט', WebFetch: 'קורא דף אינטרנט',
    agent: 'סוכן משנה', Task: 'סוכן משנה (Task)', deep_research: 'מחקר עמוק', TodoWrite: 'רשימת משימות', NotebookEdit: 'עורך מחברת',
    Skill: 'מפעיל Skill', ToolSearch: 'מחפש כלי'
  };
  App.toolIconKey = iconKey;
  App.toolIcon = (name, input) => svgOf(iconKey(name, input));
  App.toolLabel = (name, input) => {
    const sh = shellOf(name, input);
    if (sh) return `מריץ פקודה (${SHELL_NAME[sh]})`;
    if (LABELS[name]) return LABELS[name];
    const m = /^mcp__(.+?)__(.+)$/.exec(String(name || ''));
    if (m) return `כלי MCP: ${m[1]} ▸ ${m[2]}`;
    return String(name || 'כלי');
  };
  // תקציר קצר של הקלט של כלי (פקודה / נתיב / שאילתה / כתובת)
  App.toolSummary = (name, input) => {
    const i = input || {};
    if (name === 'TodoWrite') return (Array.isArray(i.todos) ? i.todos.length : 0) + ' משימות';
    const v = i.command != null ? i.command : i.file_path != null ? i.file_path : i.path != null ? i.path : i.pattern != null ? i.pattern
      : i.query != null ? i.query : i.url != null ? i.url : i.description != null ? i.description : i.notebook_path != null ? i.notebook_path
        : i.skill != null ? i.skill : i.prompt != null ? i.prompt : i.question != null ? i.question : '';
    return clip(v, 180);
  };
  const toolIconKeys = () => Object.keys(ICONS);

  // ============================================================
  //  2) שכבת הנתונים (polling + אירועים חיים), ללא תלות בתצוגה
  // ============================================================
  const S = {
    agents: new Map(), research: new Map(), ord: new Map(), ordN: 0,
    running: { agents: 0, research: 0 },
    convTitles: new Map(), convFetchedAt: 0,
    evAt: new Map(), pollStartedAt: 0, lastOk: 0, polls: 0,
    stopping: new Set(), stoppingR: new Set(), strips: new Map(),
    viewers: 0, streams: new Set(), agentViewers: new Map(), researchViewers: new Map(),
    timer: null, polling: false, paintQueued: false
  };

  function upsertAgent(s, fromEvent) {
    if (!s || !s.id) return false;
    const prev = S.agents.get(s.id);
    if (prev && isTerm(prev.status) && !isTerm(s.status)) return false; // לא חוזרים אחורה ממצב סופי
    S.agents.set(s.id, s);
    if (fromEvent) S.evAt.set(s.id, Date.now());
    if (!S.ord.has(s.id)) S.ord.set(s.id, ++S.ordN);
    return true;
  }
  function upsertResearch(s, fromEvent) {
    if (!s || !s.id) return false;
    const prev = S.research.get(s.id);
    if (prev && isTerm(prev.status) && !isTerm(s.status)) return false;
    S.research.set(s.id, s);
    if (fromEvent) S.evAt.set(s.id, Date.now());
    return true;
  }
  function reconcileAgents(list) {
    const fresh = list.filter(a => !S.ord.has(a.id)).sort((a, b) => a.startedAt - b.startedAt);
    for (const a of fresh) S.ord.set(a.id, ++S.ordN); // מספר סוכן יציב: לפי סדר ההתחלה
    const ids = new Set();
    for (const a of list) {
      ids.add(a.id);
      if ((S.evAt.get(a.id) || 0) > S.pollStartedAt) { // אירוע חי שהגיע אחרי שליחת הבקשה: הוא עדכני יותר
        const cur = S.agents.get(a.id);
        if (cur && !isTerm(cur.status)) { if (isTerm(a.status)) S.agents.set(a.id, a); continue; }
      }
      upsertAgent(a, false);
    }
    for (const id of [...S.agents.keys()]) if (!ids.has(id) && Date.now() - ((S.agents.get(id) || {}).startedAt || 0) > 10000) S.agents.delete(id);
  }
  function reconcileResearch(list) {
    const ids = new Set();
    for (const r of list) {
      ids.add(r.id);
      if ((S.evAt.get(r.id) || 0) > S.pollStartedAt) { const cur = S.research.get(r.id); if (cur && !isTerm(cur.status)) { if (isTerm(r.status)) S.research.set(r.id, r); continue; } }
      upsertResearch(r, false);
    }
    for (const id of [...S.research.keys()]) if (!ids.has(id) && Date.now() - ((S.research.get(id) || {}).startedAt || 0) > 10000) S.research.delete(id);
  }

  function convTitle(convId) {
    if (!convId) return '';
    try { const c = App.chats && App.chats.byConvId && App.chats.byConvId(convId); if (c && c.title) return c.title; } catch { }
    return S.convTitles.get(convId) || '';
  }
  async function ensureConvTitles() {
    const unknown = [...S.agents.values(), ...S.research.values()].some(x => x.convId && !convTitle(x.convId));
    if (!unknown || Date.now() - S.convFetchedAt < 8000) return;
    S.convFetchedAt = Date.now();
    try { const r = await App.api('/api/conversations'); for (const c of r.conversations || []) S.convTitles.set(c.id, c.title); schedulePaint(); } catch { }
  }

  const anyLive = () => {
    if (S.running.agents + S.running.research > 0) return true;
    for (const a of S.agents.values()) if (!isTerm(a.status)) return true;
    for (const r of S.research.values()) if (!isTerm(r.status)) return true;
    return false;
  };
  // הפאנל הימני (סוכנים / מחקר) פתוח ואחת מהלשוניות שלי נבחרה
  function viewVisible() {
    const p = $('rightpanel');
    const v = App.view && App.view.rightCurrent;
    return !!p && !p.classList.contains('collapsed') && (v === 'agents' || v === 'research');
  }
  const waitingStrip = () => { for (const r of S.strips.values()) if (Date.now() - r.at < 30000 && r.strip.dataset.status !== 'missing' && r.strip.dataset.status && r.strip.dataset.status === 'waiting') return true; return false; };
  const wantFast = () => !document.hidden && (S.viewers > 0 || anyLive() || viewVisible() || waitingStrip());

  async function poll() {
    if (S.polling) return;
    S.polling = true;
    S.pollStartedAt = Date.now();
    try {
      const [a, r, run, fl] = await Promise.all([
        App.api('/api/agents?conv=all').catch(() => null),
        App.api('/api/research').catch(() => null),
        App.api('/api/running').catch(() => null),
        App.api('/api/research-folders').catch(() => null)
      ]);
      if (fl && Array.isArray(fl.folders)) S.folders = fl.folders;
      if (a) reconcileAgents(a.agents || []);
      if (r) reconcileResearch(r.research || []);
      if (run) S.running = { agents: Number(run.agents) || 0, research: Number(run.research) || 0 };
      if (a || r || run) { S.lastOk = Date.now(); S.polls++; }
    } catch (e) { console.error('[agents poll]', e); }
    finally { S.polling = false; paintAll(); ensureConvTitles(); schedulePoll(); }
  }
  function schedulePoll() {
    clearTimeout(S.timer);
    S.timer = setTimeout(poll, wantFast() ? 1200 : 4000);
  }
  let refreshT = null;
  function refresh() { clearTimeout(refreshT); refreshT = setTimeout(() => { clearTimeout(S.timer); poll(); }, 120); return Promise.resolve(); }
  const refreshNow = () => { clearTimeout(S.timer); return poll(); };

  function schedulePaint() {
    if (S.paintQueued) return;
    S.paintQueued = true;
    const go = () => { if (!S.paintQueued) return; S.paintQueued = false; paintAll(); };
    requestAnimationFrame(go); setTimeout(go, 80);
  }
  let lastCounts = '';
  function paintAll() {
    guard('paintPill', paintPill);
    guard('emitChanged', () => { // לצ'יפ בתיבת הכתיבה של הצ'אט: עדכון כשהספירה או הרשימה משתנות
      const sig = runningList().map(a => a.id + ':' + a.status).join(',') + '|' + S.running.agents + '|' + S.running.research;
      if (sig !== lastCounts) { lastCounts = sig; App.emit('agents:changed', { agents: S.running.agents, research: S.running.research, list: runningList() }); }
    });
    guard('paintAgents', paintAgents);
    guard('paintResearchList', paintResearchList);
    guard('updateStrips', updateStrips);
  }

  // ---------- פיל עליון + תגי סרגל הפעילות ----------
  function paintPill() {
    const pill = $('agentsPill'), cnt = $('agentsPillCount');
    const a = S.running.agents, r = S.running.research, total = a + r;
    if (cnt) cnt.textContent = String(total);
    if (pill) {
      pill.classList.toggle('busy', total > 0);
      pill.title = total ? `רצים עכשיו: ${a} סוכנים · ${r} מחקרים — לחיצה פותחת את הפאנל` : 'אין סוכנים שרצים עכשיו (לחיצה פותחת את הפאנל)';
      pill.dataset.agents = String(a); pill.dataset.research = String(r);
    }
    const ba = $('actAgentsBadge'), br = $('actResearchBadge');
    if (ba) { ba.hidden = a <= 0; ba.textContent = String(a); }
    if (br) { br.hidden = r <= 0; br.textContent = String(r); }
  }

  // ---------- שעונים חיים (כל שנייה) ----------
  function setClock(node, start, end) {
    if (!node) return;
    node.dataset.start = String(start || 0);
    if (end) { node.dataset.end = String(end); node.textContent = App.fmt.dur(end - start); }
    else { delete node.dataset.end; node.textContent = App.fmt.clock(Date.now() - start); }
  }
  setInterval(() => {
    const now = Date.now();
    document.querySelectorAll('.ag-clock[data-start]:not([data-end])').forEach(n => { n.textContent = App.fmt.clock(now - Number(n.dataset.start)); });
  }, 1000);

  // ============================================================
  //  3) פעולות עצירה
  // ============================================================
  async function stopAgent(id) {
    S.stopping.add(id); schedulePaint();
    try {
      const r = await App.api(`/api/agents/${id}/stop`, { method: 'POST', body: {} });
      if (r && r.stopped === false) { S.stopping.delete(id); App.toast('הסוכן כבר לא רץ'); }
    } catch (e) { S.stopping.delete(id); App.toast('העצירה נכשלה: ' + e.message, 3500); }
    refresh();
    setTimeout(() => { const a = S.agents.get(id); if (a && !isTerm(a.status) && S.stopping.has(id)) { S.stopping.delete(id); schedulePaint(); } }, 10000);
  }
  async function stopResearch(id) {
    S.stoppingR.add(id); schedulePaint();
    try {
      const r = await App.api(`/api/research/${id}/stop`, { method: 'POST', body: {} });
      if (r && r.stopped === false) { S.stoppingR.delete(id); App.toast('המחקר כבר לא רץ'); }
    } catch (e) { S.stoppingR.delete(id); App.toast('העצירה נכשלה: ' + e.message, 3500); }
    refresh();
    setTimeout(() => { const r = S.research.get(id); if (r && !isTerm(r.status) && S.stoppingR.has(id)) { S.stoppingR.delete(id); schedulePaint(); } }, 10000);
  }
  // stopAll({scope:'all'|'conv', convId?, confirm?:bool}) — עוצר את כל הסוכנים (וגם מחקרים שרצים) בהיקף שנבחר
  async function stopAll(opts = {}) {
    const convId = opts.convId || (opts.scope === 'conv' ? ((App.chats && App.chats.active && App.chats.active()) || {}).id || null : null);
    if (opts.scope === 'conv' && !convId) { App.toast('לשיחה הפעילה אין עדיין סוכנים'); return { stopped: 0 }; }
    const inScope = x => !convId || x.convId === convId;
    await refreshNow();
    const runA = [...S.agents.values()].filter(a => !isTerm(a.status) && inScope(a));
    const runR = [...S.research.values()].filter(r => !isTerm(r.status) && inScope(r));
    if (!runA.length && !runR.length) { App.toast('אין סוכנים שרצים'); return { stopped: 0 }; }
    if (opts.confirm !== false) {
      const where = convId ? 'בשיחה הפעילה' : 'בכל השיחות';
      const msg = `לעצור ${runA.length} סוכנים${runR.length ? ' ו-' + runR.length + ' מחקרים' : ''} ${where}?\nהעבודה שכבר נעשתה נשמרת, אבל הם לא ימשיכו.`;
      const ok = await App.confirm(msg, { danger: true, okText: '■ עצור הכל', title: 'עצירת סוכנים' });
      if (!ok) return { cancelled: true, stopped: 0 };
    }
    runA.forEach(a => S.stopping.add(a.id)); runR.forEach(r => S.stoppingR.add(r.id)); schedulePaint();
    let n = 0;
    try {
      // קודם מחקרים: אחרת החוקרים שלהם נעצרים "כשגיאה" והמחקר מסתיים בשגיאה במקום "נעצר"
      await Promise.all(runR.map(r => App.api(`/api/research/${r.id}/stop`, { method: 'POST', body: {} }).catch(() => null)));
      const res = await App.api('/api/agents/stop-all', { method: 'POST', body: convId ? { conversationId: convId } : {} });
      n = res.stopped || 0;
      App.toast(`נעצרו ${n} סוכנים${runR.length ? ' ו-' + runR.length + ' מחקרים' : ''}`);
    } catch (e) { App.toast('העצירה נכשלה: ' + e.message, 4000); runA.forEach(a => S.stopping.delete(a.id)); runR.forEach(r => S.stoppingR.delete(r.id)); }
    refresh();
    return { stopped: n, research: runR.length };
  }
  const runningCount = () => S.running.agents + S.running.research;
  // סוכנים שרצים עכשיו (סיכומים: id, description, activity, status, startedAt, convId, …) — לצ'יפ "N סוכנים" בצ'אט
  const runningList = () => [...S.agents.values()].filter(a => !isTerm(a.status)).sort((a, b) => a.startedAt - b.startedAt);
  const runningResearchList = () => [...S.research.values()].filter(r => !isTerm(r.status)).sort((a, b) => a.startedAt - b.startedAt);
  // עצירה לפי מזהה: סוכן או מחקר
  const stopById = id => (S.research.has(id) && !S.agents.has(id) ? stopResearch(id) : stopAgent(id));

  // ============================================================
  //  4) תצוגת "סוכנים" בפאנל הצד
  // ============================================================
  const AV = { root: null, cards: new Map(), doneShown: 50 };
  const STATUS_TXT = { running: 'רץ', queued: 'בתור', done: 'הסתיים', error: 'שגיאה', stopped: 'נעצר', interrupted: 'הופסק', refused: 'Claude סירב', planning: 'מתכנן', researching: 'חוקר', writing: 'כותב' };
  const STATUS_IC = { done: '✅', error: '❌', stopped: '■', interrupted: '⚠️', refused: '🚫', queued: '⏳' };
  const chipText = st => (STATUS_IC[st] ? STATUS_IC[st] + ' ' : '') + (STATUS_TXT[st] || st);

  // מסנכרן רשימת כרטיסים ב-DOM בלי לבנות מחדש: משאיר אלמנטים קיימים, מזיז רק מה שהשתנה
  function syncList(container, items, hostMap, make, patch) {
    let ref = container.firstElementChild;
    for (const a of items) {
      let c = hostMap.get(a.id);
      if (!c) { c = make(a); hostMap.set(a.id, c); }
      patch(c, a);
      if (c.el === ref) ref = ref.nextElementSibling;
      else container.insertBefore(c.el, ref);
    }
    while (ref) { const nx = ref.nextElementSibling; ref.remove(); ref = nx; }
  }

  function buildAgentsView() {
    const body = $('agentsBody'), tools = $('agentsTools');
    if (!body) return;
    const rf = el('button', 'icon-btn'); rf.id = 'agRefresh'; rf.type = 'button'; rf.textContent = '↻'; rf.title = 'רענן עכשיו';
    rf.onclick = () => { refreshNow(); App.toast('מרענן…', 800); };
    if (tools) tools.appendChild(rf);
    body.innerHTML = `
      <div class="ag-root" id="agRoot">
        <div class="ag-sum">
          <div class="ag-sum-line"><span class="ag-sum-run" id="agSumRun"><b id="agRunCount">0</b> רצים</span><span class="ag-sep">·</span><span class="ag-sum-done"><b id="agDoneCount">0</b> הסתיימו</span><span class="ag-sum-q" id="agQueued" hidden></span></div>
          <div class="ag-stopall-wrap">
            <button type="button" class="ag-stopall" id="agStopAll" title="עוצר את כל הסוכנים והמחקרים הרצים, בכל השיחות"><i class="ag-sq"></i> עצור את כל הסוכנים</button>
            <button type="button" class="ag-stopall-more" id="agStopMore" title="אפשרויות עצירה">▾</button>
          </div>
        </div>
        <div class="ag-group" id="agGroupRun" data-group="running">
          <h4 class="ag-gh">רצים עכשיו <span class="ag-gc" id="agGhRun">0</span></h4>
          <div class="ag-list" id="agListRun"></div>
          <div class="ag-empty" id="agEmptyRun">אין סוכנים שרצים</div>
        </div>
        <div class="ag-group" id="agGroupDone" data-group="done" hidden>
          <h4 class="ag-gh">הסתיימו <span class="ag-gc" id="agGhDone">0</span></h4>
          <div class="ag-list" id="agListDone"></div>
          <button type="button" class="ag-more" id="agMore" hidden>הצג עוד</button>
        </div>
      </div>`;
    AV.root = $('agRoot'); AV.listRun = $('agListRun'); AV.listDone = $('agListDone');
    $('agStopAll').onclick = () => stopAll({ scope: 'all' });
    $('agStopMore').onclick = e => {
      const r = e.currentTarget.getBoundingClientRect();
      const chat = App.chats && App.chats.active && App.chats.active();
      App.menu(Math.round(r.left), Math.round(r.bottom + 4), [
        { icon: '■', label: 'עצור את כל הסוכנים (כל השיחות)', onClick: () => stopAll({ scope: 'all' }) },
        { icon: '💬', label: 'רק השיחה הפעילה', hint: chat && chat.title ? clip(chat.title, 18) : '', disabled: !(chat && chat.id), onClick: () => stopAll({ scope: 'conv' }) }
      ]);
    };
    $('agMore').onclick = () => { AV.doneShown += 50; schedulePaint(); };
  }

  function makeCard(s) {
    const root = el('div', 'ag-card');
    root.tabIndex = 0; root.setAttribute('role', 'button');
    root.dataset.agentId = s.id;
    root.innerHTML = `
      <div class="ag-r1"><span class="ag-st" aria-hidden="true"></span><span class="ag-num"></span><span class="ag-desc"></span>
        <button type="button" class="ag-stop" title="עצור את הסוכן הזה"><i class="ag-sq"></i><span class="ag-stop-t">עצור</span></button></div>
      <div class="ag-activity"></div>
      <div class="ag-badges"><span class="ag-kind"></span><span class="ag-model ag-ltr"></span><span class="ag-sid ag-ltr"></span></div>
      <div class="ag-stats"><span class="ag-s-clock" title="זמן ריצה">⏱ <span class="ag-clock"></span></span><span class="ag-s-steps" title="צעדים"></span><span class="ag-s-tok ag-ltr" title="טוקנים: קלט / פלט"></span><span class="ag-s-cost" title="עלות"></span></div>
      <div class="ag-conv"></div>`;
    const q = sel => root.querySelector(sel);
    const c = { id: s.id, el: root, sig: '', r: { st: q('.ag-st'), num: q('.ag-num'), desc: q('.ag-desc'), stop: q('.ag-stop'), stopT: q('.ag-stop-t'), act: q('.ag-activity'), kind: q('.ag-kind'), model: q('.ag-model'), sid: q('.ag-sid'), clock: q('.ag-clock'), steps: q('.ag-s-steps'), tok: q('.ag-s-tok'), cost: q('.ag-s-cost'), conv: q('.ag-conv') } };
    root.addEventListener('click', e => { if (e.target.closest('.ag-stop')) return; openAgent(s.id); });
    root.addEventListener('keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && e.target === root) { e.preventDefault(); openAgent(s.id); } });
    c.r.stop.addEventListener('click', e => { e.stopPropagation(); e.preventDefault(); stopAgent(s.id); });
    return c;
  }
  function patchCard(c, s) {
    const live = !isTerm(s.status);
    if (!live) S.stopping.delete(s.id);
    const stopping = live && S.stopping.has(s.id);
    const ct = convTitle(s.convId);
    const sig = [s.status, s.description, s.activity, s.steps, s.tokens && s.tokens.input, s.tokens && s.tokens.output, s.costUSD, s.model, s.kind, s.endedAt, ct, stopping, s.error, s.resultPreview].join('\u0001');
    if (sig === c.sig) return;
    c.sig = sig;
    const r = c.r, e0 = c.el;
    e0.dataset.status = s.status; e0.dataset.kind = s.kind || 'agent';
    if (s.parentToolId) e0.dataset.parentToolId = s.parentToolId; else delete e0.dataset.parentToolId;
    r.st.className = 'ag-st st-' + s.status; r.st.textContent = STATUS_IC[s.status] || '';
    r.st.title = STATUS_TXT[s.status] || s.status;
    r.num.textContent = '#' + (S.ord.get(s.id) || '');
    r.desc.textContent = s.description || 'סוכן'; r.desc.title = s.description || '';
    r.stop.hidden = !live; r.stop.disabled = stopping; r.stop.classList.toggle('stopping', stopping);
    r.stopT.textContent = stopping ? 'עוצר…' : 'עצור';
    let act = s.activity || '';
    if (s.status === 'done' && s.resultPreview) act = s.resultPreview;
    else if (s.status === 'error') act = s.error || act;
    r.act.className = 'ag-activity' + (live ? ' live' : ' fin'); r.act._act = null; setAct(r.act, act);
    r.kind.textContent = kindLabel(s.kind); r.kind.dataset.kind = s.kind || 'agent';
    r.model.textContent = shortModel(s.model); r.model.title = s.model || '';
    r.sid.textContent = String(s.id).slice(0, 6); r.sid.title = 'מזהה הסוכן: ' + s.id;
    setClock(r.clock, s.startedAt, live ? 0 : (s.endedAt || s.startedAt));
    r.steps.textContent = `⚙ ${s.steps || 0} צעדים`;
    r.tok.textContent = tokTxt(s.tokens);
    r.cost.textContent = money(s.costUSD, s.pct); r.cost.hidden = !r.cost.textContent;
    const where = ct ? '💬 ' + ct : (s.kind === 'research' || s.researchId ? '🔬 מחקר' : (s.convId ? '' : '💬 ללא שיחה'));
    r.conv.textContent = where; r.conv.title = where; r.conv.hidden = !where;
  }
  function paintAgents() {
    if (!AV.root) return;
    const all = [...S.agents.values()];
    const live = all.filter(a => !isTerm(a.status)).sort((a, b) => a.startedAt - b.startedAt);
    const done = all.filter(a => isTerm(a.status)).sort((a, b) => (b.endedAt || b.startedAt) - (a.endedAt || a.startedAt));
    const shown = done.slice(0, AV.doneShown);
    $('agRunCount').textContent = String(live.length);
    $('agDoneCount').textContent = String(done.length);
    $('agGhRun').textContent = String(live.length); $('agGhDone').textContent = String(done.length);
    $('agSumRun').classList.toggle('zero', live.length === 0);
    const queued = live.filter(a => a.status === 'queued').length;
    const qEl = $('agQueued'); qEl.hidden = !queued; qEl.textContent = queued ? `(${queued} בתור)` : '';
    const stopBtn = $('agStopAll');
    const nLive = live.length + [...S.research.values()].filter(r => !isTerm(r.status)).length;
    stopBtn.disabled = nLive === 0; stopBtn.dataset.running = String(live.length);
    $('agStopMore').disabled = nLive === 0;
    $('agEmptyRun').hidden = live.length > 0;
    $('agGroupDone').hidden = done.length === 0;
    syncList(AV.listRun, live, AV.cards, makeCard, patchCard);
    syncList(AV.listDone, shown, AV.cards, makeCard, patchCard);
    for (const [id, c] of AV.cards) if (!c.el.isConnected) AV.cards.delete(id);
    const more = $('agMore'); more.hidden = done.length <= AV.doneShown; more.textContent = `הצג עוד (${Math.max(0, done.length - AV.doneShown)})`;
  }

  // ============================================================
  //  5) תצוגת "מחקר עמוק" בפאנל הצד + חלון מחקר חדש
  // ============================================================
  const RV = { root: null, cards: new Map(), groups: new Map(), q: '' };
  const lsGet = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : v; } catch { return d; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch { } };
  const collapsedSet = () => { try { return new Set(JSON.parse(lsGet('rs.collapsed', '[]'))); } catch { return new Set(); } };
  function buildResearchView() {
    const body = $('researchBody'), tools = $('researchTools');
    if (!body) return;
    if (tools) {
      const nb = el('button', 'btn-primary rs-new-btn'); nb.id = 'rsNewBtn'; nb.type = 'button'; nb.textContent = '🔬 מחקר חדש';
      nb.onclick = () => openNewResearch();
      const fb = el('button', 'btn-ghost rs-new-btn'); fb.id = 'rsNewFolderBtn'; fb.type = 'button'; fb.textContent = '📁 תיקייה חדשה'; fb.title = 'תיקייה חדשה לארגון המחקרים';
      fb.onclick = () => newFolder();
      tools.append(nb, fb);
    }
    body.innerHTML = `
      <div class="rs-root" id="rsRoot">
        <div class="rs-find"><input type="search" id="rsSearch" class="text-input rs-search" placeholder="חיפוש במחקרים (כותרת, שאלה, דוח)…" autocomplete="off" spellcheck="false"><button type="button" class="rs-find-x" id="rsSearchX" title="נקה חיפוש" hidden>✕</button></div>
        <div class="rs-sum"><span><b id="rsRunCount">0</b> רצים</span><span class="ag-sep">·</span><span><b id="rsDoneCount">0</b> הסתיימו</span></div>
        <div class="rs-list" id="rsList"></div>
        <div class="ag-empty" id="rsEmpty">אין מחקרים</div>
      </div>`;
    RV.root = $('rsRoot'); RV.list = $('rsList');
    const inp = $('rsSearch'), x = $('rsSearchX');
    inp.addEventListener('input', () => { RV.q = inp.value; x.hidden = !inp.value; paintResearchList(); });
    x.onclick = () => { inp.value = ''; RV.q = ''; x.hidden = true; paintResearchList(); inp.focus(); };
  }

  // ----- פעולות על מחקרים: כותרת / תיקייה / מחיקה -----
  const folderName = id => { const f = (S.folders || []).find(x => x.id === id); return f ? f.name : ''; };
  async function moveResearch(id, folderId) {
    try { await App.api(`/api/research/${id}/meta`, { method: 'POST', body: { folderId: folderId || null } }); await refreshNow(); }
    catch (e) { App.toast('לא הצלחתי להעביר: ' + e.message, 3500); }
  }
  async function newFolder(thenMoveId) {
    const name = await App.prompt('שם התיקייה', '', { title: '📁 תיקייה חדשה', okText: 'צור', placeholder: 'למשל: אתרים, כלי עבודה…' });
    if (name == null || !String(name).trim()) return null;
    try {
      const r = await App.api('/api/research-folders', { method: 'POST', body: { name: String(name).trim() } });
      S.folders = r.folders || S.folders;
      if (thenMoveId && r.folder) await moveResearch(thenMoveId, r.folder.id); else await refreshNow();
      return r.folder;
    } catch (e) { App.toast('לא הצלחתי ליצור תיקייה: ' + e.message, 3500); return null; }
  }
  async function renameFolder(f) {
    const name = await App.prompt('שם התיקייה', f.name, { title: '✏️ שינוי שם תיקייה', okText: 'שמור' });
    if (name == null || !String(name).trim()) return;
    try { const r = await App.api('/api/research-folders', { method: 'POST', body: { id: f.id, name: String(name).trim() } }); S.folders = r.folders || S.folders; paintResearchList(); } catch (e) { App.toast('שגיאה: ' + e.message, 3000); }
  }
  async function deleteFolder(f) {
    const n = [...S.research.values()].filter(r => !r.retriedAs && r.folderId === f.id).length;
    if (!(await App.confirm(`למחוק את התיקייה "${f.name}"?${n ? `\n${n} מחקרים בתוכה לא יימחקו — הם יחזרו ל"ללא תיקייה".` : ''}`, { okText: 'מחק תיקייה', danger: true, title: 'מחיקת תיקייה' }))) return;
    try { const r = await App.api('/api/research-folders/' + f.id, { method: 'DELETE' }); S.folders = r.folders || []; await refreshNow(); } catch (e) { App.toast('שגיאה: ' + e.message, 3000); }
  }
  async function renameResearch(id) {
    const s0 = S.research.get(id); if (!s0) return;
    const t = await App.prompt('כותרת המחקר', s0.title || '', { title: '✏️ שינוי כותרת', okText: 'שמור' });
    if (t == null || !String(t).trim()) return;
    try { await App.api(`/api/research/${id}/meta`, { method: 'POST', body: { title: String(t).trim() } }); await refreshNow(); } catch (e) { App.toast('שגיאה: ' + e.message, 3000); }
  }
  async function deleteResearch(id) {
    const s0 = S.research.get(id); if (!s0) return;
    const live = !isTerm(s0.status);
    if (!(await App.confirm(`למחוק את המחקר "${s0.title || s0.question}"?${live ? '\nהמחקר רץ עכשיו — הוא ייעצר ויימחק.' : ''}\nגם שיחת המחקר שלו והניסיונות החוזרים יימחקו. אי אפשר לשחזר.`, { okText: 'מחק', danger: true, title: 'מחיקת מחקר' }))) return;
    try {
      await App.api('/api/research/' + id, { method: 'DELETE' });
      const v = S.researchViewers.get(id); if (v) v.m.close();
      for (const [k, r] of [...S.research]) if (k === id || ((r.chainId || r.id) === (s0.chainId || s0.id))) { S.research.delete(k); const c = RV.cards.get(k); if (c) { c.el.remove(); RV.cards.delete(k); } }
      paintResearchList(); refreshNow();
    } catch (e) { App.toast('לא הצלחתי למחוק: ' + e.message, 3500); }
  }
  function pickFolder(id) {
    const s0 = S.research.get(id); if (!s0) return;
    const box = el('div', 'rs-pickf');
    const mk = (label, fid, on) => { const b = el('button', 'rs-pickf-b' + (on ? ' on' : ''), label); b.type = 'button'; b.onclick = () => { m.close(); moveResearch(id, fid); }; box.appendChild(b); };
    mk('📂 ללא תיקייה', '', !s0.folderId);
    for (const f of (S.folders || [])) mk('📁 ' + f.name, f.id, s0.folderId === f.id);
    const nf = el('button', 'rs-pickf-b rs-pickf-new', '＋ תיקייה חדשה…'); nf.type = 'button'; nf.onclick = () => { m.close(); newFolder(id); }; box.appendChild(nf);
    const m = App.modal({ title: 'העבר לתיקייה', body: box, cls: 'small' });
  }

  function makeResCard(s) {
    const root = el('div', 'rs-card');
    root.tabIndex = 0; root.setAttribute('role', 'button'); root.dataset.researchId = s.id; root.draggable = true;
    root.innerHTML = `
      <div class="rs-r1"><span class="ag-st"></span><span class="rs-depth"></span><span class="rs-phase"></span>
        <button type="button" class="ag-stop rs-stop" title="עצור את המחקר"><i class="ag-sq"></i><span class="ag-stop-t">עצור</span></button></div>
      <div class="rs-title"></div>
      <div class="rs-q"></div>
      <div class="rs-progress"><div class="rs-bar"><i></i></div><span class="rs-ptxt"></span></div>
      <div class="ag-stats"><span class="ag-s-clock" title="זמן ריצה">⏱ <span class="ag-clock"></span></span><span class="rs-srcs" title="מקורות"></span><span class="ag-s-cost" title="עלות"></span><span class="rs-mdl ag-dim ag-ltr"></span></div>
      <div class="rs-acts"><button type="button" class="rs-act-b" data-act="rename" title="שנה כותרת">✏️</button><button type="button" class="rs-act-b" data-act="move" title="העבר לתיקייה">📁</button><button type="button" class="rs-act-b rs-act-del" data-act="del" title="מחק את המחקר">🗑</button></div>`;
    const q = sel => root.querySelector(sel);
    const c = { id: s.id, el: root, sig: '', bar: q('.rs-bar'), r: { st: q('.ag-st'), depth: q('.rs-depth'), phase: q('.rs-phase'), stop: q('.rs-stop'), stopT: q('.ag-stop-t'), title: q('.rs-title'), q: q('.rs-q'), bar: q('.rs-bar i'), ptxt: q('.rs-ptxt'), clock: q('.ag-clock'), srcs: q('.rs-srcs'), cost: q('.ag-s-cost'), mdl: q('.rs-mdl') } };
    root.addEventListener('click', e => {
      if (e.target.closest('.rs-stop')) return;
      const ab = e.target.closest('.rs-act-b');
      if (ab) { e.stopPropagation(); const id = root.dataset.researchId; if (ab.dataset.act === 'rename') renameResearch(id); else if (ab.dataset.act === 'move') pickFolder(id); else deleteResearch(id); return; }
      openResearch(root.dataset.researchId);
    });
    root.addEventListener('keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && e.target === root) { e.preventDefault(); openResearch(root.dataset.researchId); } if (e.key === 'Delete' && e.target === root) { e.preventDefault(); deleteResearch(root.dataset.researchId); } });
    root.addEventListener('dragstart', e => { try { e.dataTransfer.setData('text/plain', 'rs:' + root.dataset.researchId); e.dataTransfer.effectAllowed = 'move'; } catch { } root.classList.add('dragging'); });
    root.addEventListener('dragend', () => root.classList.remove('dragging'));
    c.r.stop.addEventListener('click', e => { e.stopPropagation(); e.preventDefault(); stopResearch(root.dataset.researchId); });
    return c;
  }
  function researchProgress(s) {
    const subs = s.subquestions || [];
    const total = subs.length, done = subs.filter(x => x.status === 'done').length;
    return { total, done, pct: s.status === 'done' ? 100 : total ? Math.round(done / total * 100) : 0 };
  }
  const EFF_LBL = { low: 'Low', medium: 'Medium', high: 'High', xhigh: 'Extra high', max: 'Max', ultracode: 'ULTRACODE' };
  const modelTxt = s => (s.model ? shortModel(s.model) : '') + (s.effort && EFF_LBL[s.effort] ? ' · ' + EFF_LBL[s.effort] : '');
  function patchResCard(c, s) {
    const live = !isTerm(s.status);
    if (!live) S.stoppingR.delete(s.id);
    const stopping = live && S.stoppingR.has(s.id);
    const p = researchProgress(s);
    const sig = [s.status, s.noResearch, s.summaryReady, s.opts && s.opts.minSources, s.opts && s.opts.maxSources, s.rounds, s.phase, s.question, s.title, s.depth, p.done, p.total, s.sourcesCount, s.costUSD, s.endedAt, stopping, s.attempt, s.loop && s.loop.count, s.model, s.effort].join('\u0001');
    if (sig === c.sig) return; c.sig = sig;
    const r = c.r;
    c.el.dataset.status = s.status;
    r.st.className = 'ag-st st-' + (live ? 'running' : (s.status === 'done' && s.noResearch ? 'warn' : s.status)); r.st.textContent = (s.status === 'done' && s.noResearch) ? '⚠️' : (STATUS_IC[s.status] || '');
    r.depth.textContent = DEPTH_LABEL[s.depth] || s.depth || ''; r.depth.dataset.depth = s.depth || '';
    r.phase.textContent = s.phase || STATUS_TXT[s.status] || ''; r.phase.title = s.phase || '';
    r.stop.hidden = !live; r.stop.disabled = stopping; r.stopT.textContent = stopping ? 'עוצר…' : 'עצור';
    r.title.textContent = s.title || s.question || ''; r.title.title = s.title || '';
    r.q.textContent = s.question || ''; r.q.title = s.question || '';
    r.bar.style.width = (live && !p.total ? 8 : p.pct) + '%';
    c.bar.classList.toggle('indet', live && !p.total);
    r.ptxt.textContent = p.total ? `${p.done}/${p.total} חוקרים` : (live ? 'מתכנן…' : '');
    setClock(r.clock, s.startedAt, live ? 0 : (s.endedAt || s.startedAt));
    { const g = srcGoal(s.opts); r.srcs.textContent = `📚 ${s.sourcesCount || 0}${g ? '/' + g : ''} מקורות`; }
    r.cost.textContent = [s.tokens && (s.tokens.input || s.tokens.output) ? '🔢 ' + App.fmt.num((s.tokens.input || 0) + (s.tokens.output || 0)) + ' טוקנים' : '', money(s.costUSD, s.pct)].filter(Boolean).join(' · '); r.cost.hidden = !r.cost.textContent;
    r.mdl.textContent = modelTxt(s); r.mdl.hidden = !r.mdl.textContent;
  }
  // קבוצה = תיקייה (או "ללא תיקייה") עם כותרת מתקפלת; גם יעד לגרירה
  function makeGroup(g) {
    const root = el('section', 'rs-grp'); root.dataset.folder = g.id;
    root.innerHTML = `<header class="rs-grp-h"><button type="button" class="rs-grp-t"><span class="rs-grp-ar">▾</span><span class="rs-grp-n"></span><span class="rs-grp-c"></span></button><span class="rs-grp-b"><button type="button" class="rs-act-b" data-fa="rename" title="שנה שם">✏️</button><button type="button" class="rs-act-b rs-act-del" data-fa="del" title="מחק תיקייה (המחקרים נשמרים)">🗑</button></span></header><div class="rs-grp-list"></div>`;
    const G = { id: g.id, el: root, head: root.querySelector('.rs-grp-h'), name: root.querySelector('.rs-grp-n'), cnt: root.querySelector('.rs-grp-c'), list: root.querySelector('.rs-grp-list'), btns: root.querySelector('.rs-grp-b'), g };
    root.querySelector('.rs-grp-t').onclick = () => { const cs = collapsedSet(); cs.has(g.id) ? cs.delete(g.id) : cs.add(g.id); lsSet('rs.collapsed', JSON.stringify([...cs])); paintResearchList(); };
    root.addEventListener('click', e => { const b = e.target.closest('[data-fa]'); if (!b) return; const f = (S.folders || []).find(x => x.id === g.id); if (!f) return; if (b.dataset.fa === 'rename') renameFolder(f); else deleteFolder(f); });
    const over = e => { e.preventDefault(); try { e.dataTransfer.dropEffect = 'move'; } catch { } root.classList.add('drop'); };
    root.addEventListener('dragenter', over); root.addEventListener('dragover', over);
    root.addEventListener('dragleave', e => { if (!root.contains(e.relatedTarget)) root.classList.remove('drop'); });
    root.addEventListener('drop', e => {
      e.preventDefault(); root.classList.remove('drop');
      let t = ''; try { t = e.dataTransfer.getData('text/plain') || ''; } catch { }
      if (t.startsWith('rs:')) moveResearch(t.slice(3), root.dataset.folder);
    });
    return G;
  }
  function paintResearchList() {
    if (!RV.root) return;
    const raw = [...S.research.values()].filter(r => !r.retriedAs); // ניסיון שהוחלף בניסיון חדש לא מוצג
    const q = (RV.q || '').trim().toLowerCase();
    const hit = r => !q || [r.title, r.question, r.reportPreview, STATUS_TXT[r.status], r.phase, folderName(r.folderId)].some(x => String(x || '').toLowerCase().includes(q));
    const shown = raw.filter(hit).sort((a, b) => b.startedAt - a.startedAt);
    const live = raw.filter(r => !isTerm(r.status)).length;
    $('rsRunCount').textContent = String(live); $('rsDoneCount').textContent = String(raw.length - live);
    const empty = $('rsEmpty'); empty.hidden = shown.length > 0; empty.textContent = raw.length ? 'לא נמצאו מחקרים שמתאימים לחיפוש' : 'אין מחקרים';
    const folders = S.folders || [], fids = new Set(folders.map(f => f.id));
    const cs = collapsedSet();
    const groups = [...folders.map(f => ({ id: f.id, name: f.name, folder: true })), { id: '', name: folders.length ? 'ללא תיקייה' : '', folder: false }];
    let last = null;
    for (const g of groups) {
      let G = RV.groups.get(g.id); if (!G) { G = makeGroup(g); RV.groups.set(g.id, G); }
      G.g = g;
      const items = shown.filter(r => (r.folderId && fids.has(r.folderId) ? r.folderId : '') === g.id);
      G.name.textContent = (g.folder ? '📁 ' : '📂 ') + g.name; G.cnt.textContent = String(items.length);
      G.head.hidden = !g.name; G.btns.hidden = !g.folder;
      const collapsed = !!g.name && cs.has(g.id) && !q;
      G.el.classList.toggle('collapsed', collapsed); G.el.querySelector('.rs-grp-ar').textContent = collapsed ? '◂' : '▾';
      G.el.hidden = (q && !items.length) || (!g.folder && !g.name && !items.length);
      G.list.hidden = collapsed;
      syncList(G.list, items, RV.cards, makeResCard, patchResCard);
      if (G.el.parentNode !== RV.list || (last ? G.el.previousElementSibling !== last : RV.list.firstElementChild !== G.el)) { if (last) last.after(G.el); else RV.list.prepend(G.el); }
      last = G.el;
    }
    for (const [id, G] of [...RV.groups]) if (!groups.some(g => g.id === id)) { G.el.remove(); RV.groups.delete(id); }
    for (const [id, c] of RV.cards) if (!c.el.isConnected || !S.research.has(id) || S.research.get(id).retriedAs) { c.el.remove(); RV.cards.delete(id); }
  }

  // בורר מודל + effort (משותף לחלון "מחקר חדש" ולחלון העריכה אחרי סירוב). effort שהמודל לא תומך בו נחסם
  const EFFS = [['default', 'ברירת מחדל (כמו בהגדרות)'], ['low', 'Low'], ['medium', 'Medium'], ['high', 'High'], ['xhigh', 'Extra high'], ['max', 'Max']];
  function modelEffortRow(defModel, defEffort) {
    const wrap = el('div', 'rs-mrow');
    wrap.innerHTML = `<label class="field"><span>מודל המחקר</span><select class="rs-msel"></select></label><label class="field"><span>Effort (עומק חשיבה)</span><select class="rs-esel"></select></label>`;
    const ms = wrap.querySelector('.rs-msel'), es = wrap.querySelector('.rs-esel');
    const infoOf = id => (App.state.models || []).find(m => m.id === id) || null;
    const syncEff = () => {
      const info = infoOf(ms.value), eff = info ? info.effort : undefined;
      const prev = es.value || defEffort || 'default', pi = Math.max(0, EFFS.findIndex(e => e[0] === prev));
      es.innerHTML = '';
      for (const [v, l] of EFFS) { const o = new Option(l, v); if (v !== 'default' && info && (eff === null || (eff && !eff[v]))) o.disabled = true; es.appendChild(o); }
      let pick = 'default'; for (let i = pi; i >= 0; i--) { const o = es.options[i]; if (o && !o.disabled) { pick = o.value; break; } }
      es.value = pick;
    };
    const fill = () => {
      const models = App.state.models || [], c = App.state.config || {};
      const want = ms.value || defModel || c.researchModel || c.model || '';
      const hitM = models.find(m => m.id === want) || models.find(m => m.resolved && m.resolved === want);
      ms.innerHTML = '';
      if (want && !hitM) ms.appendChild(new Option(App.modelLabel(want) || want, want));
      for (const m of models) ms.appendChild(new Option(m.name + (m.id !== m.name ? '  (' + m.id + ')' : ''), m.id));
      ms.value = hitM ? hitM.id : want; syncEff();
    };
    ms.onchange = syncEff;
    fill();
    if (!(App.state.models || []).length && App.loadModels) Promise.resolve(App.loadModels(true)).then(fill).catch(() => { });
    return { el: wrap, get: () => ({ model: ms.value, effort: es.value }) };
  }
  // מסלול הלולאה (5 ניסיונות בכל מודל): המודל שנבחר ואחריו הרשימה הקבועה, בלי כפילות
  const LOOP_IDS = ['claude-opus-5-5', 'claude-opus-4-8', 'claude-opus-4-6', 'claude-sonnet-4-6'];
  function loopPathText(model) {
    const canon = id => { const m = (App.state.models || []).find(x => x.id === id); return (m && m.resolved) || id; };
    const nm = id => { const ms = App.state.models || []; const m = ms.find(x => x.id === id) || ms.find(x => x.resolved === id && x.id !== 'default'); return m ? m.name : shortModel(id); };
    const first = model || LOOP_IDS[0];
    const ids = [first, ...LOOP_IDS.filter(x => canon(x) !== canon(first))];
    return ids.map(nm).join(' ← ') + ' (5 ניסיונות בכל מודל)';
  }

  // יעד המקורות לתצוגה: "20–50" / "≥20" / "≤50" / "30" (מינימום = מקסימום)
  function srcGoal(o) { o = o || {}; const mn = o.minSources || 0, mx = o.maxSources || 0; if (mn && mx) return mn === mx ? String(mn) : mn + '–' + mx; if (mn) return '≥' + mn; if (mx) return '≤' + mx; return ''; }
  // אפשרויות המחקר: מחולל נושאים (קלוד אחר), מינימום מקורות (חובה), פורמט הסיכום
  const SUM_FORMATS = [['list', '📋 רשימה מסודרת'], ['table', '📊 טבלה'], ['top3', '🥇 3 הכי טובים'], ['top5', '🏅 5 הכי טובים'], ['keypoints', '• נקודות מפתח']];
  const SUM_LENGTHS = [['xshort', 'קצר מאוד'], ['short', 'קצר'], ['medium', 'בינוני'], ['long', 'ארוך']];
  function researchOptionsUI(getQuestion) {
    const wrap = el('div', 'rs-opts');
    wrap.innerHTML = `
      <div class="rs-opt rs-opt-topics">
        <div class="rs-opt-h"><b>🧭 נושאים למחקר</b><span class="ag-dim">אופציונלי — לכל נושא יוצא חוקר ייעודי. אפשר לכתוב בעצמך או לבקש מקלוד אחר</span></div>
        <div class="rs-opt-row">
          <button type="button" class="btn-ghost rs-tgen">✨ מחולל נושאים</button>
          <label class="rs-opt-row">כמה נושאים <select class="rs-tn"><option>3</option><option selected>5</option><option>8</option><option>12</option></select></label>
          <span class="rs-tstat"></span>
        </div>
        <div class="rs-tlist"></div>
        <div class="rs-opt-row"><input type="text" class="text-input rs-tadd" placeholder="הוסף נושא משלך (Enter)…" maxlength="200" style="flex:1"><button type="button" class="btn-ghost rs-tadd-b">＋ הוסף</button></div>
      </div>
      <div class="rs-opt rs-opt-agents">
        <div class="rs-opt-h"><b>🤖 חוקרים</b></div>
        <div class="rs-opt-row"><div class="rs-chips rs-agmode"><button type="button" class="rs-chip on" data-m="auto">מומלץ</button><button type="button" class="rs-chip" data-m="topics">לפי הנושאים <span class="rs-agn"></span></button><button type="button" class="rs-chip" data-m="fixed">מספר:</button></div><input type="number" min="1" max="30" value="6" class="text-input rs-agfix" style="width:70px"></div>
      </div>
      <div class="rs-opt rs-opt-min">
        <div class="rs-opt-h"><b>📚 מקורות</b><span class="ag-dim">מקור = דף שנקרא. מינימום ומקסימום נאכפים (0 = ללא)</span></div>
        <div class="rs-opt-row rs-src-row"><span class="rs-src-l">מינימום</span><input type="number" min="0" max="1000" step="1" value="0" class="text-input rs-minsrc" title="0 = בלי מינימום"><div class="rs-chips rs-minchips">${[0, 20, 50, 100, 200].map(n => `<button type="button" class="rs-chip" data-min="${n}">${n ? n : 'ללא'}</button>`).join('')}</div></div>
        <div class="rs-opt-row rs-src-row"><span class="rs-src-l">מקסימום</span><input type="number" min="0" max="1000" step="1" value="0" class="text-input rs-maxsrc" title="0 = בלי מקסימום"><div class="rs-chips rs-maxchips">${[0, 10, 30, 50, 100].map(n => `<button type="button" class="rs-chip" data-max="${n}">${n ? n : 'ללא'}</button>`).join('')}</div></div>
        <div class="rs-src-err" hidden></div>
      </div>
      <div class="rs-opt rs-opt-sum">
        <div class="rs-opt-h"><b>📌 סיכום</b><span class="ag-dim">קלוד חייב לצרף סיכום מתומצת ומדויק בחלונית "סיכום"</span></div>
        <div class="rs-chips rs-sumf">${SUM_FORMATS.map(f => `<button type="button" class="rs-chip" data-f="${f[0]}">${f[1]}</button>`).join('')}</div>
        <div class="rs-opt-row"><span class="ag-dim">אורך:</span><div class="rs-chips rs-suml">${SUM_LENGTHS.map(f => `<button type="button" class="rs-chip" data-l="${f[0]}">${f[1]}</button>`).join('')}</div></div>
        <textarea class="text-input rs-sumpoints" rows="2" maxlength="600" placeholder="מה בדיוק לסכם? למשל: 3 האתרים הכי טובים · או: מה הפתרון לבעיה X (3 הפתרונות הכי טובים)"></textarea>
      </div>`;
    const q = sel => wrap.querySelector(sel);
    // ----- נושאים -----
    const tlist = q('.rs-tlist'), tstat = q('.rs-tstat');
    const addTopic = (text, checked = true) => {
      const row = el('div', 'rs-titem'); row.innerHTML = '<input type="checkbox"><input type="text" class="text-input" maxlength="200"><button type="button" class="rs-tdel" title="הסר">✕</button>';
      row.querySelector('input[type=checkbox]').checked = checked; row.querySelector('input[type=text]').value = text;
      row.querySelector('.rs-tdel').onclick = () => row.remove(); tlist.appendChild(row);
    };
    const addManual = () => { const i = q('.rs-tadd'); const v = i.value.trim(); if (!v) return; addTopic(v); i.value = ''; };
    q('.rs-tadd-b').onclick = addManual; q('.rs-tadd').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); addManual(); } });
    q('.rs-tgen').onclick = async () => {
      const question = getQuestion().trim(); const b = q('.rs-tgen');
      if (!question) { tstat.className = 'rs-tstat err'; tstat.textContent = 'כתוב קודם את שאלת המחקר'; return; }
      b.disabled = true; tstat.className = 'rs-tstat'; tstat.textContent = 'קלוד אחר מציע נושאים…';
      try {
        const r = await App.api('/api/research-topics', { method: 'POST', body: { question, count: parseInt(q('.rs-tn').value, 10) || 5 } });
        tlist.querySelectorAll('.rs-titem.gen').forEach(x => x.remove());
        for (const t of r.topics || []) { addTopic(t); tlist.lastElementChild.classList.add('gen'); }
        tstat.textContent = `${(r.topics || []).length} נושאים. סמן / ערוך / הסר, ואפשר להוסיף משלך`;
      } catch (e) { tstat.className = 'rs-tstat err'; tstat.textContent = e.message; }
      b.disabled = false;
    };
    // ----- מינימום ומקסימום מקורות -----
    const minI = q('.rs-minsrc'), maxI = q('.rs-maxsrc'), srcErr = q('.rs-src-err');
    const numOf = i => Math.max(0, Math.min(1000, parseInt(i.value, 10) || 0));
    const srcError = () => { const mn = numOf(minI), mx = numOf(maxI); return mx > 0 && mn > mx ? `המקסימום (${mx}) קטן מהמינימום (${mn}).` : ''; };
    const syncMin = () => {
      q('.rs-minchips').querySelectorAll('.rs-chip').forEach(c => c.classList.toggle('on', String(c.dataset.min) === String(numOf(minI))));
      q('.rs-maxchips').querySelectorAll('.rs-chip').forEach(c => c.classList.toggle('on', String(c.dataset.max) === String(numOf(maxI))));
      const e = srcError(); srcErr.hidden = !e; srcErr.textContent = e; wrap.classList.toggle('rs-invalid', !!e);
    };
    q('.rs-minchips').querySelectorAll('.rs-chip').forEach(c => (c.onclick = () => { minI.value = c.dataset.min; syncMin(); }));
    q('.rs-maxchips').querySelectorAll('.rs-chip').forEach(c => (c.onclick = () => { maxI.value = c.dataset.max; syncMin(); }));
    minI.addEventListener('input', syncMin); maxI.addEventListener('input', syncMin); syncMin();
    // ----- כמה חוקרים: מומלץ (Claude מחליט) · לפי הנושאים (הנושא הראשי + הנושאים שסומנו) · מספר קבוע -----
    const agM = { v: 'auto' }, agFix = q('.rs-agfix');
    const topicsChecked = () => [...tlist.querySelectorAll('.rs-titem')].filter(r => r.querySelector('input[type=checkbox]').checked && r.querySelector('input[type=text]').value.trim()).length;
    const syncAg = () => { q('.rs-agmode').querySelectorAll('.rs-chip').forEach(c => c.classList.toggle('on', c.dataset.m === agM.v)); agFix.disabled = agM.v !== 'fixed'; q('.rs-agn').textContent = '(' + (topicsChecked() + 1) + ')'; };
    q('.rs-agmode').querySelectorAll('.rs-chip').forEach(c => (c.onclick = () => { agM.v = c.dataset.m; syncAg(); if (agM.v === 'fixed') agFix.focus(); }));
    new MutationObserver(syncAg).observe(tlist, { childList: true, subtree: true, attributes: true }); tlist.addEventListener('input', syncAg); tlist.addEventListener('change', syncAg); syncAg();
    // ----- סיכום -----
    const sf = new Set(), sumL = { v: 'short' };
    q('.rs-sumf').querySelectorAll('.rs-chip').forEach(c => (c.onclick = () => { const f = c.dataset.f; sf.has(f) ? sf.delete(f) : sf.add(f); c.classList.toggle('on', sf.has(f)); }));
    const syncL = () => q('.rs-suml').querySelectorAll('.rs-chip').forEach(c => c.classList.toggle('on', c.dataset.l === sumL.v));
    q('.rs-suml').querySelectorAll('.rs-chip').forEach(c => (c.onclick = () => { sumL.v = c.dataset.l; syncL(); })); syncL();
    return {
      el: wrap,
      error: srcError,
      get: () => ({
        minSources: numOf(minI), maxSources: numOf(maxI),
        topics: [...tlist.querySelectorAll('.rs-titem')].filter(r => r.querySelector('input[type=checkbox]').checked).map(r => r.querySelector('input[type=text]').value.trim()).filter(Boolean),
        summary: { formats: [...sf], length: sumL.v, points: q('.rs-sumpoints').value.trim() },
        agents: agM.v === 'fixed' ? { mode: 'fixed', n: Math.max(1, Math.min(30, parseInt(agFix.value, 10) || 1)) } : { mode: agM.v }
      })
    };
  }

  // החלון של "מחקר חדש"
  function openNewResearch() {
    const cfgDepth = (App.state.config && App.state.config.researchDepth) || 'standard';
    let depth = ['quick', 'standard', 'deep'].includes(cfgDepth) ? cfgDepth : 'standard';
    const box = el('div', 'rs-new');
    const OPTS = [
      ['quick', '⚡ מהיר', '', 'כ-<bdi>1–2</bdi> דקות'],
      ['standard', '🔬 רגיל', '', 'כ-<bdi>3–6</bdi> דקות'],
      ['deep', '🧠 עמוק', '', 'כ-<bdi>6–15</bdi> דקות']
    ];
    box.innerHTML = `
      <label class="field">
        <textarea id="rsNewQ" rows="5" maxlength="4000" placeholder="מה לחקור?"></textarea>
</label>
      <div class="rs-mslot"></div>
      <div class="rs-oslot"></div>
      <div class="field"><span>עומק המחקר</span><div class="rs-depths" role="radiogroup">${OPTS.map(o => `
        <button type="button" class="rs-depth-opt" role="radio" data-depth="${o[0]}"><b>${o[1]}</b><span>${o[2]}</span><em>${o[3]}</em></button>`).join('')}</div>
</div>
      <div class="rs-new-err" id="rsNewErr" hidden></div>
      <div class="rs-new-foot"><button type="button" class="btn-ghost" id="rsNewCancel">ביטול</button><button type="button" class="btn-primary" id="rsNewGo">🔬 התחל מחקר</button></div>`;
    const me = modelEffortRow('', 'default'); box.querySelector('.rs-mslot').appendChild(me.el);
    const ou = researchOptionsUI(() => box.querySelector('#rsNewQ').value); box.querySelector('.rs-oslot').appendChild(ou.el);
    const m = App.modal({ title: '🔬 מחקר חדש', body: box, wide: true, cls: 'rs-new-modal' });
    const q = box.querySelector('#rsNewQ'), go = box.querySelector('#rsNewGo'), err = box.querySelector('#rsNewErr');
    const setDepth = d => { depth = d; box.querySelectorAll('.rs-depth-opt').forEach(b => { const on = b.dataset.depth === d; b.classList.toggle('on', on); b.setAttribute('aria-checked', on ? 'true' : 'false'); }); };
    box.querySelectorAll('.rs-depth-opt').forEach(b => (b.onclick = () => setDepth(b.dataset.depth)));
    setDepth(depth);
    const sync = () => { go.disabled = !q.value.trim(); };
    q.addEventListener('input', sync); sync();
    const submit = async () => {
      const question = q.value.trim(); if (!question) return;
      { const oe = ou.error(); if (oe) { err.hidden = false; err.textContent = oe; return; } }
      go.disabled = true; go.textContent = 'מתחיל…'; err.hidden = true;
      try {
        const { model, effort } = me.get();
        const r = await App.api('/api/research', { method: 'POST', body: { question, depth, model, effort, opts: ou.get() } });
        m.close(); await refreshNow(); openResearch(r.id);
      } catch (e) { err.hidden = false; err.textContent = 'לא הצלחתי להתחיל: ' + e.message; go.disabled = false; go.textContent = '🔬 התחל מחקר'; }
    };
    go.onclick = submit;
    q.addEventListener('keydown', e => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); submit(); } });
    box.querySelector('#rsNewCancel').onclick = () => m.close();
    setTimeout(() => q.focus(), 40);
    return m;
  }

  // ============================================================
  //  6) SSE קטן (fetch + ReadableStream)
  // ============================================================
  function openStream(url, onEvent) {
    const ac = new AbortController();
    S.streams.add(ac);
    let closed = false;
    (async () => {
      try {
        const res = await fetch(url, { signal: ac.signal, cache: 'no-store', headers: { accept: 'text/event-stream' } });
        if (!res.ok) { let msg = 'HTTP ' + res.status; try { msg = (await res.json()).error || msg; } catch { } onEvent('__error', { message: msg, status: res.status }); return; }
        const reader = res.body.getReader(), dec = new TextDecoder('utf-8');
        let buf = '';
        for (;;) {
          const { value, done } = await reader.read();
          if (done) break;
          buf += dec.decode(value, { stream: true }).replace(/\r\n/g, '\n');
          let i;
          while ((i = buf.indexOf('\n\n')) >= 0) {
            const raw = buf.slice(0, i); buf = buf.slice(i + 2);
            let type = 'message', data = '';
            for (const line of raw.split('\n')) {
              if (!line || line[0] === ':') continue;
              if (line.startsWith('event:')) type = line.slice(6).trim();
              else if (line.startsWith('data:')) data += (data ? '\n' : '') + line.slice(5).replace(/^ /, '');
            }
            if (!data) continue;
            let d; try { d = JSON.parse(data); } catch { continue; }
            try { onEvent(type, d); } catch (e) { console.error('[agents stream]', e); }
          }
        }
        if (!ac.signal.aborted) onEvent('__eof', {});
      } catch (e) { if (e.name !== 'AbortError' && !ac.signal.aborted) onEvent('__error', { message: e.message }); }
      finally { S.streams.delete(ac); }
    })();
    return { close() { if (!closed) { closed = true; ac.abort(); S.streams.delete(ac); } } };
  }

  // ============================================================
  //  7) תמליל סוכן (טרנסקריפט חי)
  // ============================================================
  const fmtMs = ms => (ms < 1000 ? Math.round(ms) + 'ms' : (ms / 1000).toFixed(ms < 10000 ? 1 : 0) + 's');
  const toolStateHtml = ev => (ev.is_error
    ? `<span class="ag-ts err">✗ שגיאה${ev.ms != null ? ' · ' + fmtMs(ev.ms) : ''}</span>`
    : `<span class="ag-ts ok">✓${ev.ms != null ? ' ' + fmtMs(ev.ms) : ''}</span>`);
  const PROMPT_PREFIX = { bash: '$', cmd: 'C:\\>', powershell: 'PS>' };
  function inputDetails(obj) {
    const d = el('details', 'ag-in');
    d.innerHTML = '<summary>קלט <span class="ag-dim">(פרטים)</span></summary><pre class="ag-pre ag-ltr"></pre>';
    let txt; try { txt = JSON.stringify(obj, null, 2); } catch { txt = String(obj); }
    d.querySelector('pre').textContent = txt;
    return d;
  }

  function createTranscript(scroller) {
    const T = { stick: true, lastType: null, cur: null, tools: new Map(), count: 0, quiet: false, final: null, lastText: null };
    const root = el('div', 'ag-tx');
    scroller.appendChild(root);
    T.root = root;
    const jump = el('button', 'ag-jump', '⬇ לסוף'); jump.type = 'button'; jump.hidden = true;
    // גלילה אוטומטית רק כל עוד המשתמש בסוף. מזהים גלילה למעלה גם לפני שאירוע ה-scroll הגיע (autoTop = המקום שבו עצרנו בעצמנו)
    const toBottom = () => { scroller.scrollTop = scroller.scrollHeight; T.autoTop = scroller.scrollTop; };
    jump.onclick = () => { T.stick = true; toBottom(); jump.hidden = true; };
    T.jump = jump; T.toBottom = toBottom; T.autoTop = 0;
    scroller.addEventListener('scroll', () => { const d = scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight; T.stick = d < 80; if (T.stick) T.autoTop = scroller.scrollTop; jump.hidden = T.stick; });
    const follow = () => {
      if (T.quiet) return;
      if (T.stick && scroller.scrollTop < T.autoTop - 30) T.stick = false;
      if (T.stick) toBottom(); else jump.hidden = false;
    };
    T.follow = follow;
    root.addEventListener('click', e => {
      const b = e.target.closest('.copy-code');
      if (b) { const cb = b.closest('.code-block'); if (cb) App.copyText(cb.querySelector('code').textContent, 'הקוד הועתק'); }
    });
    T.clear = () => { root.innerHTML = ''; T.lastType = null; T.cur = null; T.tools.clear(); T.count = 0; T.final = null; T.lastText = null; };

    const renderSoon = b => { if (b.timer) return; b.timer = setTimeout(() => { b.timer = 0; b.el.innerHTML = md(b.text); follow(); }, 110); };
    T.add = ev => {
      if (!ev || !ev.type) return;
      T.count++;
      const type = ev.type;
      // אותו כלל מיזוג כמו בשרת: text/thinking רצופים הם בלוק אחד
      if ((type === 'text' || type === 'thinking') && T.lastType === type && T.cur) {
        T.cur.text += ev.text || '';
        if (type === 'text') renderSoon(T.cur);
        else { T.cur.body.textContent = T.cur.text; T.cur.tail.textContent = clip(T.cur.text.slice(-120), 90); T.cur.len.textContent = T.cur.text.length + ' תווים'; }
        follow(); return;
      }
      T.lastType = type; T.cur = null;
      switch (type) {
        case 'prompt': {
          const d = el('details', 'ag-ev ag-ev-prompt');
          d.innerHTML = `<summary><span class="ag-ev-ic">📝</span> המשימה שניתנה לסוכן <span class="ag-dim">${esc(clip(ev.text, 110))}</span></summary><div class="ag-pre ag-text-pre"></div>`;
          d.querySelector('.ag-pre').textContent = ev.text || '';
          root.appendChild(d); break;
        }
        case 'thinking': {
          const d = el('details', 'ag-ev ag-ev-think');
          d.innerHTML = `<summary><span class="ag-ev-ic">💭</span> חשיבה <span class="ag-dim ag-len"></span><span class="ag-tail ag-dim"></span></summary><div class="ag-think-body"></div>`;
          const b = { type, text: ev.text || '', el: d, body: d.querySelector('.ag-think-body'), tail: d.querySelector('.ag-tail'), len: d.querySelector('.ag-len') };
          b.body.textContent = b.text; b.tail.textContent = clip(b.text.slice(-120), 90); b.len.textContent = b.text.length + ' תווים';
          root.appendChild(d); T.cur = b; break;
        }
        case 'text': {
          const d = el('div', 'ag-ev ag-ev-text md');
          const b = { type, text: ev.text || '', el: d, timer: 0 };
          d.innerHTML = md(b.text);
          root.appendChild(d); T.cur = b; T.lastText = b; break;
        }
        case 'tool': case 'server_tool': {
          const input = ev.input || {};
          const key = iconKey(ev.name, input);
          const card = el('div', 'ag-ev ag-ev-tool running' + (type === 'server_tool' ? ' srv' : ''));
          card.dataset.toolId = ev.id || ''; card.dataset.tool = ev.name || ''; card.dataset.icon = key;
          const sh = shellOf(ev.name, input);
          card.innerHTML = `<div class="ag-tool-head"><span class="ag-tic" title="${esc(ev.name)}">${svgOf(key)}</span><span class="ag-tool-label">${esc(App.toolLabel(ev.name, input))}</span><span class="ag-tool-arg ag-ltr">${esc(sh ? '' : App.toolSummary(ev.name, input))}</span><span class="ag-tool-state"><span class="ag-ts run">⏳ רץ…</span></span></div><div class="ag-tool-body"></div>`;
          const bd = card.querySelector('.ag-tool-body');
          if (sh) { const pre = el('pre', 'ag-pre ag-cmd ag-ltr'); pre.dataset.shell = sh; pre.textContent = (PROMPT_PREFIX[sh] || '$') + ' ' + String(input.command || ''); bd.appendChild(pre); }
          else if (ev.name === 'write_file' || ev.name === 'Write') bd.appendChild(inputDetails({ path: input.path || input.file_path, 'תוכן (תווים)': String(input.content || '').length }));
          else if (Object.keys(input).length > 1) bd.appendChild(inputDetails(input));
          root.appendChild(card);
          if (ev.id) T.tools.set(ev.id, card);
          break;
        }
        case 'tool_result': {
          let card = T.tools.get(ev.id);
          if (!card) { card = el('div', 'ag-ev ag-ev-tool running'); card.dataset.toolId = ev.id || ''; card.innerHTML = `<div class="ag-tool-head"><span class="ag-tic">${svgOf('gear')}</span><span class="ag-tool-label">תוצאת כלי</span><span class="ag-tool-arg"></span><span class="ag-tool-state"></span></div><div class="ag-tool-body"></div>`; root.appendChild(card); }
          card.classList.remove('running'); card.classList.add(ev.is_error ? 'err' : 'ok');
          card.querySelector('.ag-tool-state').innerHTML = toolStateHtml(ev);
          const out = String(ev.output == null ? '' : ev.output);
          if (out.trim()) {
            const n = out.split('\n').length, shortOut = n <= 6 && out.length < 500;
            const d = el('details', 'ag-out');
            if (shortOut || ev.is_error) d.open = true;
            d.innerHTML = `<summary>פלט <span class="ag-dim">(${n} שורות${out.length > 3999 ? ', קוצר' : ''})</span>${shortOut ? '' : `<span class="ag-dim ag-tail ag-ltr">${esc(clip(out.split('\n').find(x => x.trim()) || '', 90))}</span>`}</summary><pre class="ag-pre ag-ltr"></pre>`;
            d.querySelector('pre').textContent = out;
            card.querySelector('.ag-tool-body').appendChild(d);
          }
          break;
        }
        case 'server_result': {
          let card = T.tools.get(ev.id);
          if (!card) { card = el('div', 'ag-ev ag-ev-tool srv running'); card.innerHTML = `<div class="ag-tool-head"><span class="ag-tic">${svgOf(ev.name === 'web_fetch' ? 'webfetch' : 'websearch')}</span><span class="ag-tool-label">${esc(ev.name || '')}</span><span class="ag-tool-arg"></span><span class="ag-tool-state"></span></div><div class="ag-tool-body"></div>`; root.appendChild(card); }
          card.classList.remove('running'); card.classList.add(ev.error ? 'err' : 'ok');
          const items = ev.items || [];
          card.querySelector('.ag-tool-state').innerHTML = ev.error ? `<span class="ag-ts err">✗ ${esc(ev.error)}</span>` : `<span class="ag-ts ok">✓ ${items.length} תוצאות</span>`;
          if (items.length) {
            const ul = el('div', 'ag-results');
            for (const it of items) {
              const a = el('a', 'ag-res'); a.href = it.url; a.target = '_blank'; a.rel = 'noopener';
              a.innerHTML = `<span class="ag-res-t">${esc(it.title || hostOf(it.url) || it.url)}</span><span class="ag-res-u ag-ltr">${esc(it.url)}</span>${it.pageAge ? `<span class="ag-res-age ag-ltr">${esc(it.pageAge)}</span>` : ''}`;
              ul.appendChild(a);
            }
            card.querySelector('.ag-tool-body').appendChild(ul);
          }
          break;
        }
        case 'notice': root.appendChild(el('div', 'ag-ev ag-ev-notice', 'ℹ️ ' + esc(ev.text))); break;
        case 'error': root.appendChild(el('div', 'ag-ev ag-ev-error', '⚠ ' + esc(ev.text))); break;
        case 'end': root.appendChild(el('div', 'ag-ev ag-ev-end', `— ${esc(STATUS_TXT[ev.status] || ev.status || 'הסתיים')} —`)); break;
        default: root.appendChild(el('div', 'ag-ev ag-ev-notice', esc(type))); break;
      }
      follow();
    };
    return T;
  }

  // ============================================================
  //  8) מציג הסוכן (modal)
  // ============================================================
  const SESSION_KEY = 'agents.openViewer';
  const remember = (kind, id) => { try { sessionStorage.setItem(SESSION_KEY, JSON.stringify({ kind, id })); } catch { } };
  const forget = (kind, id) => { try { const v = JSON.parse(sessionStorage.getItem(SESSION_KEY) || 'null'); if (v && v.kind === kind && v.id === id) sessionStorage.removeItem(SESSION_KEY); } catch { } };

  function openAgent(id) {
    if (!id) return null;
    const ex = S.agentViewers.get(id);
    if (ex && ex.m.el.isConnected) { ex.m.el.parentNode.appendChild(ex.m.el); return ex; }
    const root = el('div', 'ag-vw');
    root.dataset.agentId = id;
    root.innerHTML = `
      <div class="ag-vw-top">
        <div class="ag-vw-row1">
          <span class="ag-chip st" data-r="status">…</span><span class="ag-chip kind" data-r="kind"></span><span class="ag-chip model ag-ltr" data-r="model"></span>
          <span class="ag-spacer"></span>
          <button type="button" class="ag-vw-stop btn-danger" data-r="stop" hidden><i class="ag-sq"></i> <span class="ag-stop-t">עצור סוכן</span></button>
          <button type="button" class="btn-ghost ag-vw-copy" data-r="copyAll" title="העתק את כל התמליל כטקסט">📋 תמליל</button>
        </div>
        <div class="ag-vw-row2">
          <span title="זמן ריצה">⏱ <b class="ag-clock" data-r="clock"></b></span><span title="צעדים">⚙ <b data-r="steps">0</b> צעדים</span>
          <span title="טוקנים: קלט / פלט" class="ag-ltr" data-r="tok"></span><span class="ag-costw"><i class="ag-cost-ic">💲 </i><b data-r="cost"></b></span>
          <span class="ag-vw-conv" data-r="conv" hidden></span><a href="#" class="ag-vw-res" data-r="resLink" hidden>🔬 למחקר ▸</a>
        </div>
      </div>
      <div class="ag-vw-scroll" data-r="scroll"></div>
      <div class="ag-vw-foot"><span class="ag-st st-running" data-r="fst"></span><span class="ag-foot-act" data-r="act">מתחבר…</span><span class="ag-foot-live" data-r="live">🔴 חי</span></div>`;
    const R = {}; root.querySelectorAll('[data-r]').forEach(n => (R[n.dataset.r] = n));
    let stream = null, closedByUser = false, retries = 0, full = null;
    const m = App.modal({
      title: 'סוכן', cls: 'xwide ag-vw-box', sticky: true, body: root,
      onClose: () => { closedByUser = true; if (stream) stream.close(); S.viewers--; S.agentViewers.delete(id); forget('agent', id); }
    });
    S.viewers++;
    const T = createTranscript(R.scroll);
    R.scroll.parentNode.insertBefore(T.jump, R.scroll.nextSibling);
    const viewer = { id, m, root, T, get full() { return full; } };
    S.agentViewers.set(id, viewer);
    remember('agent', id);

    const head = sum => {
      if (!sum) return;
      const live = !isTerm(sum.status);
      root.dataset.status = sum.status;
      R.status.className = 'ag-chip st st-' + sum.status; R.status.textContent = chipText(sum.status);
      R.kind.textContent = kindLabel(sum.kind); R.model.textContent = shortModel(sum.model); R.model.title = sum.model || '';
      m.setTitle('🤖 ' + (sum.description || 'סוכן'));
      setClock(R.clock, sum.startedAt, live ? 0 : (sum.endedAt || sum.startedAt));
      R.steps.textContent = String(sum.steps || 0); R.tok.textContent = tokTxt(sum.tokens); setCost(R.cost, money(sum.costUSD, sum.pct));
      const stopping = live && S.stopping.has(id);
      R.stop.hidden = !live; R.stop.disabled = stopping; R.stop.querySelector('.ag-stop-t').textContent = stopping ? 'עוצר…' : 'עצור סוכן';
      const ct = convTitle(sum.convId); R.conv.hidden = !ct; R.conv.textContent = ct ? '💬 ' + ct : '';
      R.resLink.hidden = !sum.researchId; R.resLink.dataset.researchId = sum.researchId || '';
      setAct(R.act, live ? (sum.activity || '') : (STATUS_TXT[sum.status] || '') + (sum.error ? ': ' + sum.error : ''));
      R.fst.className = 'ag-st st-' + sum.status; R.fst.textContent = STATUS_IC[sum.status] || '';
      R.live.hidden = !live;
    };
    const showFinal = f => {
      if (!f) return;
      if (T.final) { T.final.remove(); T.final = null; }
      if (!f.result && !f.error) return;
      const box = el('section', 'ag-final' + (f.status === 'error' ? ' err' : f.status === 'stopped' ? ' stopped' : ''));
      box.innerHTML = `<header><span>📄 דוח סופי${f.status === 'stopped' ? ' <small>(חלקי: הסוכן נעצר)</small>' : ''}</span><span class="ag-spacer"></span><button type="button" class="btn-ghost ag-copy-final">📋 העתק</button></header>${f.error ? `<div class="ag-final-err">⚠ ${esc(f.error)}</div>` : ''}<div class="md ag-final-body"></div>`;
      box.querySelector('.ag-final-body').innerHTML = md(f.result || '');
      // הטקסט האחרון של הסוכן הוא בדרך כלל הדוח עצמו: לא מציגים אותו פעמיים
      if (T.lastText && f.result && T.lastText.text.trim() === String(f.result).trim()) { T.lastText.el.hidden = true; T.lastText.el.dataset.dup = '1'; }
      box.querySelector('.ag-copy-final').onclick = () => App.copyText(f.result || '', 'הדוח הועתק');
      box.addEventListener('click', e => { const b = e.target.closest('.copy-code'); if (b) App.copyText(b.closest('.code-block').querySelector('code').textContent, 'הקוד הועתק'); });
      T.root.appendChild(box); T.final = box;
      T.follow();
    };
    const fetchFull = async () => { try { const r = await App.api('/api/agents/' + id); full = r.agent; showFinal(full); head(full.summary || full); } catch { } };
    R.stop.onclick = () => { stopAgent(id); head((full && full.summary) || S.agents.get(id)); };
    R.resLink.onclick = e => { e.preventDefault(); if (R.resLink.dataset.researchId) openResearch(R.resLink.dataset.researchId); };
    R.copyAll.onclick = () => App.copyText(T.root.innerText, 'התמליל הועתק');

    const connect = () => {
      stream = openStream(`/api/agents/${id}/stream`, (type, d) => {
        if (closedByUser) return;
        switch (type) {
          case 'snapshot': {
            full = d.agent; retries = 0;
            T.clear(); T.quiet = true; T.stick = true;
            for (const ev of full.events || []) T.add(ev);
            T.quiet = false;
            if (full.truncated) T.root.insertAdjacentHTML('afterbegin', '<div class="ag-ev ag-ev-notice">ℹ️ התמליל ארוך: מוצגים האירועים האחרונים בלבד.</div>');
            head(full.summary || full);
            if (isTerm(full.status)) showFinal(full);
            T.stick = true; T.toBottom(); break;
          }
          case 'event': T.add(d); break;
          case 'update': { upsertAgent(d, true); head(d); schedulePaint(); break; }
          case 'end': { upsertAgent(d, true); head(d); fetchFull(); schedulePaint(); refresh(); break; }
          case '__eof': case '__error': {
            const cur = S.agents.get(id) || (full && full.summary);
            if (d && d.status === 404) { R.act.textContent = 'הסוכן לא נמצא (ייתכן שנמחק).'; R.live.hidden = true; break; }
            if (cur && isTerm(cur.status)) { R.live.hidden = true; break; }
            if (retries++ < 30) setTimeout(() => { if (!closedByUser) connect(); }, 1200);
            else { R.live.hidden = true; R.act.textContent = 'החיבור לשרת אבד'; }
            break;
          }
        }
      });
    };
    connect();
    return viewer;
  }

  // ============================================================
  //  9) מציג המחקר (modal)
  // ============================================================
  const STEPS = [['plan', 'תכנון'], ['research', 'חקירה במקביל'], ['synth', 'סינתזה'], ['report', 'דוח']];
  // הפניות [n] בטקסט הופכות לקישורים שמדגישים את המקור המתאים
  function linkCites(root, sources) {
    const byN = new Map((sources || []).map(s => [String(s.n), s]));
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: n => (n.parentElement && n.parentElement.closest('a,code,pre,.code-block')) ? NodeFilter.FILTER_REJECT : (/\[\d{1,3}\]/.test(n.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT)
    });
    const nodes = []; while (walker.nextNode()) nodes.push(walker.currentNode);
    for (const n of nodes) {
      const frag = document.createDocumentFragment(); const re = /\[(\d{1,3})\]/g; let last = 0, mm;
      while ((mm = re.exec(n.nodeValue))) {
        frag.appendChild(document.createTextNode(n.nodeValue.slice(last, mm.index)));
        const s = byN.get(mm[1]);
        const a = el('a', 'rs-cite' + (s ? '' : ' missing')); a.textContent = mm[0]; a.dataset.n = mm[1]; a.href = '#src-' + mm[1];
        if (s) a.title = (s.title || s.url) + ' — ' + hostOf(s.url);
        frag.appendChild(a); last = re.lastIndex;
      }
      frag.appendChild(document.createTextNode(n.nodeValue.slice(last)));
      n.parentNode.replaceChild(frag, n);
    }
  }

  function openResearch(id) {
    if (!id) return null;
    const ex = S.researchViewers.get(id);
    if (ex && ex.m.el.isConnected) { ex.m.el.parentNode.appendChild(ex.m.el); return ex; }
    const root = el('div', 'rs-vw');
    root.dataset.researchId = id;
    root.innerHTML = `
      <div class="rs-vw-top">
        <div class="rs-vw-q" data-r="q"></div>
        <div class="ag-vw-row1">
          <span class="ag-chip st" data-r="status">…</span><span class="ag-chip depth" data-r="depth"></span><span class="rs-vw-phase" data-r="phase"></span>
          <span class="ag-spacer"></span>
          <button type="button" class="ag-vw-stop btn-danger" data-r="stop" hidden><i class="ag-sq"></i> <span class="ag-stop-t">עצור מחקר</span></button>
        </div>
        <div class="ag-vw-row2">
          <span title="זמן ריצה">⏱ <b class="ag-clock" data-r="clock"></b></span><span title="מקורות שצוטטו">📚 <b data-r="srcn">0</b> מקורות</span><span data-r="seen" class="ag-dim"></span>
          <span class="ag-ltr" data-r="tok" title="טוקנים"></span><span class="ag-costw"><i class="ag-cost-ic">💲 </i><b data-r="cost"></b></span><span class="ag-ltr ag-dim" data-r="model"></span><span class="ag-vw-conv" data-r="conv" hidden></span>
        </div>
        <ol class="rs-timeline" data-r="timeline">${STEPS.map((s, i) => `<li class="rs-step" data-step="${s[0]}" data-state="pending"><span class="rs-step-n">${i + 1}</span><span class="rs-step-l">${s[1]}</span><small class="rs-step-s"></small></li>`).join('')}</ol>
      </div>
      <div class="rs-refuse" data-r="refuse" hidden></div>
      <div class="rs-tabbar">
        <div class="rs-tabs" role="tablist">
          <button type="button" class="rs-tab" role="tab" data-tab="summary">📌 סיכום</button>
          <button type="button" class="rs-tab" role="tab" data-tab="report">📄 הדוח</button>
          <button type="button" class="rs-tab" role="tab" data-tab="plan">🧭 תוכנית המחקר <span class="ag-gc" data-r="plann">0</span></button>
          <button type="button" class="rs-tab" role="tab" data-tab="sources">📚 מקורות <span class="ag-gc" data-r="srcc">0</span></button>
          <button type="button" class="rs-tab" role="tab" data-tab="log">🕓 יומן פעילות</button>
        </div>
        <div class="rs-tabact">
          <span class="ag-dim rs-rstate" data-r="reportState"></span>
          <button type="button" class="btn-ghost rs-act" data-r="copy" disabled title="העתק את הדוח">📋 העתק</button>
          <button type="button" class="btn-ghost rs-act" data-r="dl" disabled title="הורד את הדוח כקובץ Markdown">⬇ הורד (MD)</button>
          <button type="button" class="btn-ghost rs-act" data-r="toChat" disabled title="הכנס את הדוח לתיבת הכתיבה של הצ'אט">💬 הכנס לצ'אט</button>
        </div>
      </div>
      <div class="rs-panes">
        <section class="rs-pane" data-pane="summary" hidden>
          <div class="rs-sumcard md" data-r="summary"><div class="ag-empty">הסיכום ייכתב בסוף המחקר.</div></div>
          <div class="rs-glance" data-r="glance"></div>
        </section>
        <section class="rs-pane" data-pane="report" hidden>
          <div class="rs-report md" data-r="report"><div class="ag-empty">הדוח ייכתב אחרי שהחוקרים יסיימו.</div></div>
        </section>
        <section class="rs-pane" data-pane="plan" hidden>
          <div class="rs-explain"><b>מה זו תוכנית המחקר?</b> לפני שהחיפוש מתחיל, קלוד מפרק את השאלה שלך לתת-שאלות עצמאיות. לכל תת-שאלה יוצא חוקר נפרד (סוכן) שמחפש ברשת במקביל לאחרים, ובסוף כל הממצאים מאוחדים לדוח אחד. כאן רואים מי חוקר מה, מה מצבו, ואת הממצאים שלו.</div>
          <div class="rs-topics" data-r="topics" hidden></div>
          <div class="rs-plan" data-r="plan"><div class="ag-empty">המתכנן עדיין מפרק את השאלה לתת-שאלות…</div></div>
        </section>
        <section class="rs-pane" data-pane="sources" hidden>
          <div class="rs-src-tools">
            <input type="search" class="text-input rs-srcq" data-r="srcq" placeholder="חיפוש במקורות ובחיפושים — למשל github, reddit, מחיר…" autocomplete="off" spellcheck="false">
            <span class="ag-dim rs-srcfound" data-r="srcfound"></span>
          </div>
          <div class="rs-domains" data-r="domains"></div>
          <div class="rs-sources" data-r="sources"><div class="ag-empty">עדיין לא נאספו מקורות.</div></div>
          <details class="rs-queries"><summary>🔎 חיפושים שקלוד ביצע <span class="ag-gc" data-r="queryc">0</span></summary><div class="rs-qlist" data-r="queries"></div></details>
        </section>
        <section class="rs-pane" data-pane="log" hidden>
          <div class="rs-log" data-r="log"></div>
        </section>
      </div>`;
    const R = {}; root.querySelectorAll('[data-r]').forEach(n => (R[n.dataset.r] = n));
    let stream = null, closedByUser = false, retries = 0;
    const TABS = ['summary', 'report', 'plan', 'sources', 'log'];

    const st = { tab: '', tabTouched: false, srcFilter: '', rounds: 0, pollT: 0, full: null, sum: null, report: '', reportTimer: 0, fetchT: 0, lastFetch: 0, logLast: '', subs: [], initialSrc: false, wasWriting: false };
    const m = App.modal({
      title: '🔬 מחקר עמוק', cls: 'xwide rs-vw-box', sticky: true, body: root,
      onClose: () => { closedByUser = true; if (stream) stream.close(); clearInterval(st.pollT); clearTimeout(st.fetchT); clearTimeout(st.reportTimer); S.viewers--; S.researchViewers.delete(id); forget('research', id); }
    });
    S.viewers++;
    const viewer = { id, m, root, st };
    S.researchViewers.set(id, viewer);
    remember('research', id);

    // ----- כרטיסיות -----
    const setTab = (name, byUser) => {
      if (!TABS.includes(name)) name = 'plan';
      if (byUser) st.tabTouched = true;
      st.tab = name;
      root.querySelectorAll('.rs-tab').forEach(b => { const on = b.dataset.tab === name; b.classList.toggle('on', on); b.setAttribute('aria-selected', on ? 'true' : 'false'); });
      root.querySelectorAll('.rs-pane').forEach(p => { p.hidden = p.dataset.pane !== name; });
    };
    root.querySelectorAll('.rs-tab').forEach(b => (b.onclick = () => setTab(b.dataset.tab, true)));
    const pickTab = () => { // כרטיסייה ברירת מחדל חכמה, כל עוד המשתמש לא בחר בעצמו: מחקר שהסתיים עם סיכום → סיכום; הסתיים בלי סיכום → דוח; רץ → תוכנית
      if (st.tabTouched) return;
      const sum = st.sum || {}, full = st.full || {}; const status = sum.status || full.status; if (!status) return;
      const hasSummary = !!(full.summaryText || sum.summaryReady);
      setTab(!isTerm(status) ? 'plan' : hasSummary ? 'summary' : (st.report ? 'report' : 'plan'));
    };
    setTab('plan');

    const logAdd = (text, t) => {
      if (!text || text === st.logLast) return; st.logLast = text;
      const row = el('div', 'rs-log-row'); row.innerHTML = `<time class="ag-ltr">${esc(App.fmt.time(t || Date.now()))}</time><span></span>`;
      row.querySelector('span').textContent = text;
      R.log.appendChild(row);
      while (R.log.children.length > 300) R.log.firstElementChild.remove();
      R.log.scrollTop = R.log.scrollHeight;
    };

    // ----- ציר זמן: תכנון → חקירה במקביל → סינתזה → דוח -----
    const paintSteps = () => {
      const sum = st.sum || (st.full && st.full.summary) || {}; const full = st.full || {};
      const status = sum.status || full.status; if (!status) return;
      if (status === 'writing') st.wasWriting = true;
      const subs = sum.subquestions || full.subquestions || [];
      const hasReport = (st.report || '').length > 0;
      const order = ['plan', 'research', 'synth', 'report'];
      let active;
      if (status === 'planning') active = 'plan';
      else if (status === 'researching') active = 'research';
      else if (status === 'writing') active = hasReport ? 'report' : 'synth';
      else if (status === 'done') active = null;
      else active = !subs.length ? 'plan' : hasReport ? 'report' : st.wasWriting ? 'synth' : 'research'; // נעצר/שגיאה: השלב האחרון
      const idx = active ? order.indexOf(active) : order.length;
      const states = {};
      order.forEach((k, i) => { states[k] = i < idx ? 'done' : i === idx ? (isTerm(status) && status !== 'done' ? (status === 'stopped' ? 'stopped' : 'failed') : 'active') : 'pending'; });
      const done = subs.filter(x => x.status === 'done').length;
      const words = (st.report || '').split(/\s+/).filter(Boolean).length;
      const sub = {
        plan: states.plan === 'done' ? `${subs.length} תת-שאלות` : 'מפרק לתת-שאלות…',
        research: subs.length ? `${done}/${subs.length} חוקרים סיימו` : '',
        synth: states.synth === 'active' ? 'כותב את המסקנות…' : states.synth === 'done' ? 'הושלם' : '',
        report: states.report === 'active' ? `${words} מילים…` : states.report === 'done' ? `${words} מילים` : ''
      };
      R.timeline.querySelectorAll('.rs-step').forEach(li => {
        const k = li.dataset.step; li.dataset.state = states[k];
        li.querySelector('.rs-step-s').textContent = states[k] === 'pending' ? '' : sub[k] || '';
        li.querySelector('.rs-step-n').textContent = states[k] === 'done' ? '✓' : states[k] === 'failed' ? '✕' : states[k] === 'stopped' ? '⏹' : String(order.indexOf(k) + 1);
      });
    };

    // ----- כותרת -----
    const head = (sum, full) => {
      sum = sum || {}; full = full || {};
      const status = sum.status || full.status; if (!status) return;
      const live = !isTerm(status);
      root.dataset.status = status;
      R.q.textContent = sum.question || full.question || ''; R.q.title = R.q.textContent;
      m.setTitle('🔬 ' + clip(sum.title || full.title || R.q.textContent, 70));
      const soft = status === 'done' && (sum.noResearch || full.noResearch);
      R.status.className = 'ag-chip st st-' + (live ? 'running' : (soft ? 'warn' : status)); R.status.textContent = soft ? '⚠️ תשובה בלי חוקרים' : chipText(status);
      const d = sum.depth || full.depth; R.depth.textContent = DEPTH_LABEL[d] || d || ''; R.depth.dataset.depth = d || '';
      R.phase.textContent = sum.phase || full.phase || '';
      const stopping = live && S.stoppingR.has(id);
      R.stop.hidden = !live; R.stop.disabled = stopping; R.stop.querySelector('.ag-stop-t').textContent = stopping ? 'עוצר…' : 'עצור מחקר';
      setClock(R.clock, sum.startedAt || full.startedAt, live ? 0 : (sum.endedAt || full.endedAt || sum.startedAt));
      const srcCount = (full.sources && full.sources.length) || sum.sourcesCount || 0;
      { const g = srcGoal(sum.opts || full.opts); R.srcn.textContent = srcCount + (g ? '/' + g : ''); }
      const seenN = sum.seenCount != null ? sum.seenCount : full.seenCount;
      R.seen.textContent = seenN ? `(${seenN} תוצאות חיפוש נסרקו)` : '';
      if (full.tokens || sum.tokens) R.tok.textContent = tokTxt(sum.tokens || full.tokens);
      setCost(R.cost, money(sum.costUSD != null ? sum.costUSD : full.costUSD, sum.pct || full.pct));
      R.model.textContent = modelTxt({ model: sum.model || full.model, effort: sum.effort || full.effort }); R.model.title = (sum.model || full.model || '') + ((sum.effort || full.effort) ? ' · effort: ' + (sum.effort || full.effort) : '');
      R.conv.hidden = true; // שיחת המחקר היא לא צ'אט — לא מציגים אותה
      paintSteps(); paintRefuse(sum, full); followCheck(sum); pollTerminal(); paintExtras(); pickTab();
    };

    // לולאת ניסיונות: כש-Claude סירב והשרת יוצא לניסיון הבא — החלון הפתוח עובר לניסיון החדש (הזרם של המחקר המסורב כבר נסגר, לכן בודקים בשאילתה)
    const followCheck = d => {
      if (!d || !d.retriedAs || st.retriedInit === undefined || d.retriedAs === st.retriedInit || st.following) return;
      st.following = true; const nid = d.retriedAs;
      setTimeout(() => { if (closedByUser || S.researchViewers.get(id) !== viewer) return; m.close(); refreshNow().then(() => openResearch(nid)); }, 500);
    };
    const pollTerminal = () => {
      const need = () => { const s = st.sum || {}; return isTerm(s.status) && s.loop && s.loop.active; };
      if (st.pollT || closedByUser || !need()) return;
      st.pollT = setInterval(async () => {
        if (closedByUser || !need()) { clearInterval(st.pollT); st.pollT = 0; return; }
        try { const r = await App.api('/api/research/' + id); if (r.research && !closedByUser) { st.full = r.research; st.sum = r.research.summary || st.sum; head(st.sum, st.full); } } catch { }
      }, 1500);
    };
    // ----- סירוב / שגיאה / לולאת ניסיונות: באנר עם 4 כפתורים -----
    const RETRY_MODES = {
      once: { label: '🔁 נסה לצאת שוב', busy: 'מתחיל…' },
      loop: { label: '♾️ נסה שוב בלופ עד שקלוד יסכים', busy: 'מתחיל לולאה…' },
      edit: { label: '✏️ ערוך ונסה שוב עד שקלוד יסכים', busy: '' },
      rephrase: { label: "🔄 שלח לצ'אט קלוד אחר שינסח מחדש (אותה משמעות, פחות בעייתי)", busy: 'קלוד אחר מנסח מחדש…' }
    };
    const doRetry = async (mode, question, btn) => {
      const btns = [...R.refuse.querySelectorAll('button')]; btns.forEach(b => (b.disabled = true));
      const old = btn ? btn.textContent : ''; if (btn && RETRY_MODES[mode].busy) btn.textContent = RETRY_MODES[mode].busy;
      try {
        const r = await App.api(`/api/research/${id}/retry`, { method: 'POST', body: { mode, question } });
        await refreshNow(); m.close(); openResearch(r.id);
        return true;
      } catch (e) { st.retryErr = e.message; R.refuse._key = null; paintRefuse(st.sum, st.full); App.toast('לא הצלחתי לנסות שוב: ' + e.message, 4500); return false; }
    };
    const editAndRetry = () => {
      const box = el('div', 'rs-new');
      const me = modelEffortRow((st.sum && st.sum.model) || (st.full && st.full.model) || '', (st.sum && st.sum.effort) || (st.full && st.full.effort) || 'default');
      box.innerHTML = `<div class="rs-edit-note">ערוך את הבקשה, ואם תרצה גם את המודל וה-effort. כשתלחץ, המחקר יצא מחדש בלולאה — שוב ושוב — עד שקלוד יסכים לבצע אותו.</div>
        <label class="field"><textarea id="rsEditQ" rows="7" maxlength="4000"></textarea></label>
        <div class="rs-mslot"></div>
        <div class="rs-edit-note rs-loop-path"></div>
        <div class="rs-new-err" id="rsEditErr" hidden></div>
        <div class="rs-new-foot"><button type="button" class="btn-ghost" id="rsEditCancel">ביטול</button><button type="button" class="btn-primary" id="rsEditGo">♾️ נסה בלופ עד שקלוד יסכים</button></div>`;
      const dm = App.modal({ title: '✏️ עריכת הבקשה', body: box, wide: true, cls: 'rs-new-modal' });
      const q = box.querySelector('#rsEditQ'), go = box.querySelector('#rsEditGo'), err = box.querySelector('#rsEditErr');
      q.value = (st.sum && st.sum.question) || (st.full && st.full.question) || '';
      box.querySelector('.rs-mslot').appendChild(me.el);
      const pathEl = box.querySelector('.rs-loop-path'); const showPath = () => { pathEl.textContent = 'מסלול הלולאה: ' + loopPathText(me.get().model); }; showPath(); me.el.querySelector('.rs-msel').addEventListener('change', showPath);
      const sync = () => { go.disabled = !q.value.trim(); }; q.addEventListener('input', sync); sync();
      box.querySelector('#rsEditCancel').onclick = () => dm.close();
      go.onclick = async () => {
        const question = q.value.trim(); if (!question) return;
        go.disabled = true; go.textContent = 'מתחיל…'; err.hidden = true;
        try { const { model, effort } = me.get(); const r = await App.api(`/api/research/${id}/retry`, { method: 'POST', body: { mode: 'edit', question, model, effort } }); dm.close(); await refreshNow(); m.close(); openResearch(r.id); }
        catch (e) { err.hidden = false; err.textContent = 'לא הצלחתי להתחיל: ' + e.message; go.disabled = false; go.textContent = '♾️ נסה בלופ עד שקלוד יסכים'; }
      };
      setTimeout(() => q.focus(), 40);
    };
    const paintRefuse = (sum, full) => {
      sum = sum || {}; full = full || {};
      const status = sum.status || full.status; const lp = sum.loop !== undefined ? sum.loop : full.loop;
      const attempt = sum.attempt || full.attempt || 1, orig = sum.originalQuestion || full.originalQuestion, reph = sum.rephrased || full.rephrased;
      const refusal = sum.refusal || full.refusal, err = sum.error || full.error, next = sum.retriedAs || full.retriedAs;
      if (st.retriedInit === undefined) st.retriedInit = next || null;
      const soft = status === 'done' && (sum.noResearch || full.noResearch), model = sum.model || full.model;
      const key = [status, soft, sum.loopEnded || full.loopEnded, lp && lp.active, lp && lp.count, lp && lp.state, lp && lp.model, attempt, !!orig, next, (refusal && refusal.text) || err || '', sum.question || full.question, st.retryErr || ''].join('|');
      if (R.refuse._key === key) return; R.refuse._key = key;
      const box = R.refuse; box.innerHTML = ''; box.className = 'rs-refuse'; box.hidden = true;
      const note = (cls, html) => { const d = el('div', cls, html); box.appendChild(d); return d; };
      const origInfo = () => { if (orig) { const d = el('details', 'rs-refuse-det', `<summary>${reph ? 'הנוסח נכתב מחדש ע״י קלוד אחר' : 'הנוסח נערך'} — הנוסח המקורי</summary><div class="rs-refuse-pre"></div>`); d.querySelector('.rs-refuse-pre').textContent = orig; box.appendChild(d); } };
      const live = !isTerm(status);
      const loopEnded = sum.loopEnded || full.loopEnded;
      const addRetry = modes => {
        const row = el('div', 'rs-refuse-btns');
        for (const k of modes) {
          const b = el('button', k === 'once' ? 'btn-primary' : 'btn-ghost', RETRY_MODES[k].label); b.dataset.mode = k;
          b.onclick = () => (k === 'edit' ? editAndRetry() : doRetry(k, undefined, b));
          row.appendChild(b);
        }
        box.appendChild(row);
        note('rs-refuse-s rs-loop-path', 'לולאה (♾️ ו-✏️): 5 ניסיונות בכל מודל — ' + esc(loopPathText((st.sum && st.sum.model) || (st.full && st.full.model) || '')));
        if (st.retryErr) { const w = el('div', 'rs-refuse-warn'); w.textContent = '⚠️ ' + st.retryErr; box.appendChild(w); }
      };
      if (lp && lp.active) {   // לולאה פעילה (גם בין ניסיון לניסיון)
        box.hidden = false; box.classList.add('loop');
        note('rs-refuse-t', `♾️ לולאת ניסיונות פעילה — ניסיון ${lp.count} מתוך ${lp.max}`);
        if (lp.model) note('rs-refuse-s', `מודל נוכחי: <b>${esc(shortModel(lp.model))}</b> · שלב ${lp.stage} מתוך ${lp.stages} (${lp.perModel || 5} ניסיונות בכל מודל)`);
        note('rs-refuse-s', lp.state === 'waiting' ? 'קלוד סירב בניסיון הזה. ממתין רגע ויוצא לניסיון הבא…' : (live ? 'קלוד עובד על המחקר. אם יסרב — המערכת תנסה שוב אוטומטית עד שיסכים.' : ''));
        origInfo();
        const row = el('div', 'rs-refuse-btns'); const b = el('button', 'btn-ghost', '⏹ עצור את הלולאה');
        b.onclick = async () => { b.disabled = true; try { await App.api(`/api/research/${id}/stop-loop`, { method: 'POST', body: {} }); } catch { } fetchFull(false); };
        row.appendChild(b); box.appendChild(row); return;
      }
      if (soft) {   // הסתיים בלי חוקרים ובלי מקורות: תשובה ישירה, לא מחקר
        box.hidden = false; box.classList.add('warn');
        note('rs-refuse-t', '⚠️ זו תשובה ולא מחקר');
        note('rs-refuse-s', 'קלוד ענה ישירות: לא הופעלו חוקרים ולא נאספו מקורות. ייתכן שהוא סירב לבקשה בתוך התשובה עצמה — קרא את התשובה למטה.' + (attempt > 1 ? ` (ניסיון ${attempt}, מודל ${esc(shortModel(model))})` : ''));
        if (loopEnded === 'max') note('rs-refuse-s', '♾️ הלולאה סיימה את כל הניסיונות (5 בכל מודל) — אף מודל לא ביצע מחקר.');
        origInfo(); if (!next) addRetry(['once', 'loop', 'edit']); return;
      }
      if (status === 'done' && attempt > 1) {   // הצליח אחרי ניסיונות חוזרים
        box.hidden = false; box.classList.add('ok');
        note('rs-refuse-t', `✅ קלוד הסכים בניסיון ${attempt}`); origInfo(); return;
      }
      if (status !== 'refused' && status !== 'error') return;
      box.hidden = false; box.classList.add(status);
      if (status === 'refused') {
        note('rs-refuse-t', '🚫 Claude סירב לבצע את המחקר');
        note('rs-refuse-s', 'מסנן הבטיחות של המודל חסם את הבקשה, ולכן שום חיפוש לא רץ ולא נכתב דוח. זו לא תקלה באפליקציה, והמחקר לא "הושלם". הסיבה שהמודל החזיר:');
        const d = el('details', 'rs-refuse-det', '<summary>הודעת הסירוב המלאה</summary><div class="rs-refuse-pre ag-ltr"></div>'); d.open = true; d.querySelector('.rs-refuse-pre').textContent = (refusal && refusal.text) || err || ''; box.appendChild(d);
      } else {
        note('rs-refuse-t', '❌ המחקר נכשל');
        const d = el('details', 'rs-refuse-det', '<summary>פרטי השגיאה</summary><div class="rs-refuse-pre ag-ltr"></div>'); d.open = true; d.querySelector('.rs-refuse-pre').textContent = err || ''; box.appendChild(d);
      }
      if (attempt > 1) note('rs-refuse-s', `ניסיון מספר ${attempt}.`);
      origInfo();
      if (next) {
        const row = el('div', 'rs-refuse-btns'); const b = el('button', 'btn-primary', 'כבר נוסה שוב — פתח את הניסיון הבא ▸'); b.onclick = () => { m.close(); openResearch(next); }; row.appendChild(b); box.appendChild(row); return;
      }
      if (loopEnded === 'max') note('rs-refuse-s', '♾️ הלולאה סיימה את כל הניסיונות (5 בכל מודל) — אף מודל לא הסכים.');
      addRetry(status === 'refused' ? ['once', 'loop', 'edit', 'rephrase'] : ['once', 'loop', 'edit']);
    };

    // ----- תוכנית (תת-שאלות) -----
    const paintPlan = () => {
      const sum = st.sum || {}; const full = st.full || {};
      const subs = (sum.subquestions && sum.subquestions.length ? sum.subquestions : (full.subquestions || []));
      R.plann.textContent = String(subs.length);
      if (!subs.length) return;
      const empty = R.plan.querySelector('.ag-empty'); if (empty) empty.remove();
      subs.forEach((s, i) => {
        let card = R.plan.children[i];
        if (!card) {
          card = el('div', 'rs-sub'); card.dataset.idx = String(i);
          card.innerHTML = `<div class="rs-sub-head"><span class="rs-sub-n">${i + 1}</span><span class="rs-sub-q"></span><span class="ag-chip st rs-sub-st"></span></div><div class="rs-sub-act"></div><div class="rs-sub-btns"><button type="button" class="ag-mini rs-sub-open">פתח את הסוכן ▸</button><button type="button" class="ag-mini rs-sub-find" hidden>ממצאים ▾</button></div><div class="rs-sub-findings md" hidden></div>`;
          card.addEventListener('click', e => {
            const fb = e.target.closest('.rs-sub-find');
            if (fb) { e.stopPropagation(); const f = card.querySelector('.rs-sub-findings'); f.hidden = !f.hidden; fb.textContent = f.hidden ? 'ממצאים ▾' : 'ממצאים ▴'; return; }
            if (e.target.closest('.rs-cite') || e.target.closest('a') || e.target.closest('.rs-sub-findings')) return;
            if (card.dataset.agentId) openAgent(card.dataset.agentId);
          });
          R.plan.appendChild(card);
        }
        const fs = (full.subquestions || [])[i] || {};
        const key = [s.q, s.status, s.activity, s.agentId, (fs.findings || '').length, (full.sources || []).length].join('|');
        if (card._key !== key) {
          card._key = key;
          card.dataset.status = s.status; if (s.agentId) card.dataset.agentId = s.agentId;
          card.classList.toggle('openable', !!s.agentId);
          card.querySelector('.rs-sub-q').textContent = s.q;
          const stEl = card.querySelector('.rs-sub-st'); const stat = s.status || 'queued';
          stEl.className = 'ag-chip st rs-sub-st st-' + stat; stEl.textContent = chipText(stat);
          const act = card.querySelector('.rs-sub-act'); act.className = 'rs-sub-act' + (stat === 'running' ? ' live' : ''); act._act = null; setAct(act, s.activity || '');
          const ob = card.querySelector('.rs-sub-open'); ob.hidden = !s.agentId;
          ob.onclick = e => { e.stopPropagation(); if (s.agentId) openAgent(s.agentId); };
          const fbtn = card.querySelector('.rs-sub-find'), fbox = card.querySelector('.rs-sub-findings');
          if (fs.findings) { fbtn.hidden = false; fbox.innerHTML = md(fs.findings); linkCites(fbox, full.sources); } else fbtn.hidden = true;
        }
        const prev = st.subs[i];
        if (!prev || prev.status !== s.status || (prev.activity !== s.activity && s.status === 'running')) logAdd(`חוקר ${i + 1}: ${s.activity || STATUS_TXT[s.status] || s.status}`);
        st.subs[i] = { status: s.status, activity: s.activity };
      });
    };

    // ----- מקורות (עם חיפוש, דומיינים וחיפושים שבוצעו) -----
    const hay = x => ((x.title || '') + ' ' + (x.url || '') + ' ' + hostOf(x.url) + ' ' + (x.snippets || []).join(' ')).toLowerCase();
    const applySrcFilter = () => {
      const f = st.srcFilter;
      let shown = 0, total = 0;
      R.sources.querySelectorAll('.rs-src').forEach(row => { total++; const hit = !f || (row._hay || '').includes(f); row.hidden = !hit; if (hit) shown++; });
      let qShown = 0, qTotal = 0;
      R.queries.querySelectorAll('.rs-q-row').forEach(row => { qTotal++; const hit = !f || (row._hay || '').includes(f); row.hidden = !hit; if (hit) qShown++; });
      R.srcfound.textContent = f ? `${shown} מתוך ${total} מקורות · ${qShown} מתוך ${qTotal} חיפושים` : '';
      R.domains.querySelectorAll('.rs-dom').forEach(c => c.classList.toggle('on', !!f && c.dataset.host === f));
      const qd = R.queries.closest('details'); if (qd && f && qShown && !qd.open) qd.open = true;
    };
    R.srcq.addEventListener('input', () => { st.srcFilter = R.srcq.value.trim().toLowerCase(); applySrcFilter(); });
    const paintDomains = () => {
      const srcs = (st.full && st.full.sources) || [];
      const key = srcs.length + '|' + st.srcFilter; if (R.domains._k === key) return; R.domains._k = key;
      const cnt = new Map(); for (const x of srcs) { const h = hostOf(x.url); if (h) cnt.set(h, (cnt.get(h) || 0) + 1); }
      const top = [...cnt.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])).slice(0, 16);
      R.domains.innerHTML = '';
      for (const [h, n] of top) { const c = el('button', 'rs-dom' + (st.srcFilter === h ? ' on' : ''), `${esc(h)} <b>${n}</b>`); c.type = 'button'; c.dataset.host = h; c.title = 'סנן לפי ' + h; c.onclick = () => { const v = st.srcFilter === h ? '' : h; R.srcq.value = v; st.srcFilter = v; applySrcFilter(); }; R.domains.appendChild(c); }
      R.domains.hidden = !top.length;
    };
    const paintQueries = () => {
      const qs = (st.full && st.full.queries) || [];
      R.queryc.textContent = String(qs.length);
      if ((R.queries._n || 0) === qs.length) return; R.queries._n = qs.length;
      R.queries.innerHTML = '';
      qs.forEach((q, i) => { const row = el('div', 'rs-q-row'); row._hay = String(q.q || '').toLowerCase(); const sub = q.sub != null ? `חוקר ${q.sub + 1}` : 'קלוד הראשי'; row.innerHTML = `<span class="rs-q-n">${i + 1}</span><span class="rs-q-t ag-ltr"></span><small class="ag-dim">${esc(sub)}</small>`; row.querySelector('.rs-q-t').textContent = q.q; R.queries.appendChild(row); });
      applySrcFilter();
    };
    const paintSources = () => {
      const srcs = (st.full && st.full.sources) || [];
      const first = !st.initialSrc; st.initialSrc = true;
      R.srcc.textContent = String(srcs.length);
      if (!srcs.length) return;
      const empty = R.sources.querySelector('.ag-empty'); if (empty) empty.remove();
      for (const s of srcs) {
        let row = R.sources.querySelector(`.rs-src[data-n="${s.n}"]`);
        const isNew = !row;
        if (!row) { row = el('div', 'rs-src'); row.dataset.n = String(s.n); R.sources.appendChild(row); }
        if (isNew && !first) logAdd(`נוסף מקור [${s.n}]: ${clip(s.title || s.url, 60)}`);
        const key = [s.title, (s.snippets || []).join('|')].join('#'); if (row._key === key) continue; row._key = key;
        row._hay = hay(s);
        row.innerHTML = `<span class="rs-src-n">[${s.n}]</span><div class="rs-src-b"><a class="rs-src-t" target="_blank" rel="noopener"></a><div class="rs-src-h ag-ltr"></div><a class="rs-src-u ag-ltr" target="_blank" rel="noopener"></a>${(s.snippets || []).map(() => '<q class="rs-src-sn"></q>').join('')}</div>`;
        const a = row.querySelector('.rs-src-t'); a.href = s.url; a.textContent = s.title || hostOf(s.url) || s.url;
        row.querySelector('.rs-src-h').textContent = hostOf(s.url);
        const u = row.querySelector('.rs-src-u'); u.href = s.url; u.textContent = s.url;
        row.querySelectorAll('.rs-src-sn').forEach((q, i) => { q.textContent = s.snippets[i]; });
      }
      paintDomains(); applySrcFilter();
    };

    // ----- סיכום, "במבט אחד", נושאים -----
    const paintTopics = () => {
      const sum = st.sum || {}, full = st.full || {}; const opts = sum.opts || full.opts || {}; const tp = opts.topics || [];
      R.topics.hidden = !tp.length; if (!tp.length) return;
      const subs = sum.subquestions && sum.subquestions.length ? sum.subquestions : (full.subquestions || []);
      const items = tp.map((t, i) => { const hit = subs.find(q => new RegExp('^TOPIC-' + (i + 1) + '\\b', 'i').test(q.q || '')); const ic = !hit ? '⏳' : hit.status === 'done' ? '✅' : hit.status === 'running' ? '🔄' : '•'; return { t, ic }; });
      const key = items.map(x => x.ic + x.t).join('|'); if (R.topics._k === key) return; R.topics._k = key;
      R.topics.innerHTML = `<b>🧭 הנושאים שבחרת (${tp.length})</b> <span class="ag-dim">— לכל נושא יוצא חוקר ייעודי</span>`;
      const ul = el('ol', 'rs-topic-list'); for (const x of items) { const li = el('li'); li.textContent = x.ic + ' ' + x.t; ul.appendChild(li); } R.topics.appendChild(ul);
    };
    const paintExtras = () => {
      const sum = st.sum || {}, full = st.full || {};
      const opts = sum.opts || full.opts || {}, min = opts.minSources || 0, max = opts.maxSources || 0;
      const blockedN = sum.blockedCalls || full.blockedCalls || 0;
      const status = sum.status || full.status, live = !isTerm(status);
      const nSrc = (full.sources && full.sources.length) || sum.sourcesCount || 0;
      const subs = (sum.subquestions && sum.subquestions.length ? sum.subquestions : (full.subquestions || []));
      const doneSubs = subs.filter(x => x.status === 'done').length;
      const qn = sum.queriesCount != null ? sum.queriesCount : (full.queries || []).length;
      const rounds = sum.rounds || full.rounds || 0, missed = sum.minSourcesMissed || full.minSourcesMissed;
      const sTxt = full.summaryText || '';
      const sKey = 'S' + sTxt.length + '|' + (full.sources || []).length;
      if (R.summary._k !== sKey) {
        R.summary._k = sKey;
        if (sTxt) { R.summary.classList.remove('empty'); R.summary.innerHTML = md(sTxt); linkCites(R.summary, full.sources || []); }
        else { R.summary.classList.add('empty'); R.summary.innerHTML = `<div class="ag-empty">${live ? 'הסיכום ייכתב בסוף המחקר — קלוד חייב לצרף אותו.' : 'לא התקבל סיכום למחקר הזה.'}</div>`; }
      }
      const gKey = [nSrc, min, max, blockedN, doneSubs, subs.length, qn, rounds, !!missed, live].join('|');
      if (R.glance._k !== gKey) {
        R.glance._k = gKey;
        const goal = max || min, pct = goal ? Math.min(100, Math.round(nSrc / goal * 100)) : 0;
        const cards = [];
        const lim = [min ? 'מינימום ' + min : '', max ? 'מקסימום ' + max : ''].filter(Boolean).join(' · ');
        const st = [];
        if (min) st.push(nSrc >= min ? '✓ המינימום הושג' : (!live && missed ? '✕ המינימום לא הושג' : 'עוד ' + (min - nSrc) + ' עד המינימום'));
        if (max) st.push(nSrc >= max ? '✓ הגיע למקסימום — חיפוש נוסף חסום' + (blockedN ? ` (${blockedN} ניסיונות נחסמו)` : '') : 'עד ' + max + ' מקורות');
        cards.push(`<div class="rs-gl"><b>${nSrc}</b><span>מקורות${lim ? ' · ' + lim : ''}</span>${goal ? `<div class="rs-gl-bar${(!min || nSrc >= min) ? ' ok' : ''}"><i style="width:${pct}%"></i></div><em>${st.join(' · ')}</em>` : ''}</div>`);
        cards.push(`<div class="rs-gl"><b>${doneSubs}/${subs.length}</b><span>חוקרים סיימו</span></div>`);
        cards.push(`<div class="rs-gl"><b>${qn}</b><span>חיפושים בוצעו</span></div>`);
        if (rounds) cards.push(`<div class="rs-gl"><b>${rounds}</b><span>סבבי המשך</span><em>קלוד נשלח להמשיך לחקור</em></div>`);
        R.glance.innerHTML = cards.join('');
      }
      paintTopics(); paintQueries();
    };

    // ----- דוח -----
    const renderReport = () => {
      const txt = st.report || '';
      if (!txt) { R.report.innerHTML = '<div class="ag-empty">הדוח ייכתב אחרי שהחוקרים יסיימו.</div>'; for (const b of [R.copy, R.dl, R.toChat]) b.disabled = true; return; }
      R.report.innerHTML = md(txt);
      linkCites(R.report, (st.full && st.full.sources) || []);
      const live = st.sum && !isTerm(st.sum.status);
      R.reportState.textContent = live ? '(נכתב עכשיו…)' : '';
      for (const b of [R.copy, R.dl]) b.disabled = false;
      const canChat = !!(App.chats && App.chats.insertIntoInput);
      R.toChat.disabled = !canChat; R.toChat.hidden = !canChat;
    };
    const reportSoon = () => {
      if (st.reportTimer) return;
      st.reportTimer = setTimeout(() => {
        st.reportTimer = 0;
        const sc = root.querySelector('[data-pane="report"]'); const atBottom = sc.scrollHeight - sc.scrollTop - sc.clientHeight < 90;
        renderReport(); paintSteps();
        if (atBottom && st.sum && st.sum.status === 'writing') sc.scrollTop = sc.scrollHeight;
      }, 150);
    };
    R.copy.onclick = () => App.copyText(st.report, 'הדוח הועתק');
    R.dl.onclick = () => {
      const q = (st.full && st.full.question) || 'research';
      const name = ('מחקר-' + q.replace(/[\\/:*?"<>|\r\n]+/g, ' ').trim().slice(0, 50)).replace(/\s+/g, '-') + '.md';
      const blob = new Blob([`# ${q}\n\n${st.report}\n`], { type: 'text/markdown;charset=utf-8' });
      const a = el('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click();
      setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
    };
    R.toChat.onclick = () => { if (App.chats && App.chats.insertIntoInput) { App.chats.insertIntoInput(`${(st.full && st.full.question) || ''}\n\n${st.report}`); App.toast('הדוח הוכנס לתיבת הכתיבה'); m.close(); } };
    R.stop.onclick = () => { stopResearch(id); head(st.sum, st.full); };
    // ציטוט [n] → גלילה והדגשה של המקור
    root.addEventListener('click', e => {
      const c = e.target.closest('.rs-cite'); if (c) {
        e.preventDefault(); setTab('sources', true);
        const row = R.sources.querySelector(`.rs-src[data-n="${c.dataset.n}"]`);
        if (!row) { App.toast('המקור [' + c.dataset.n + '] לא נמצא ברשימה', 1800); return; }
        row.scrollIntoView({ block: 'center', behavior: 'smooth' });
        R.sources.querySelectorAll('.rs-src.hl').forEach(x => x.classList.remove('hl'));
        row.classList.add('hl'); setTimeout(() => row.classList.remove('hl'), 2600);
        return;
      }
      const b = e.target.closest('.copy-code'); if (b) App.copyText(b.closest('.code-block').querySelector('code').textContent, 'הקוד הועתק');
    });

    const applyFull = (full, final) => {
      if (!full) return;
      st.full = full;
      if ((full.rounds || 0) !== st.rounds) { st.rounds = full.rounds || 0; st.report = full.report || ''; } // סבב המשך התחיל: הדוח נכתב מחדש
      if (final || (full.report || '').length >= (st.report || '').length) st.report = full.report || '';
      if (!st.sum) st.sum = full.summary || null;
      head(st.sum || full.summary, full); paintPlan(); paintSources(); renderReport(); paintSteps(); paintExtras();
    };
    const fetchFull = async final => {
      st.lastFetch = Date.now();
      try { const r = await App.api('/api/research/' + id); applyFull(r.research, final); } catch { }
    };
    const fetchSoon = () => {
      if (st.fetchT) return;
      const wait = Math.max(0, 1000 - (Date.now() - st.lastFetch));
      st.fetchT = setTimeout(() => { st.fetchT = 0; fetchFull(false); }, wait);
    };

    const connect = () => {
      stream = openStream(`/api/research/${id}/stream`, (type, d) => {
        if (closedByUser) return;
        switch (type) {
          case 'snapshot': {
            retries = 0; const full = d.research;
            st.full = full; st.sum = full.summary; st.report = full.report || ''; st.subs = []; R.log.innerHTML = ''; st.logLast = ''; st.initialSrc = false;
            logAdd('המחקר התחיל', full.startedAt);
            if (full.subquestions && full.subquestions.length) logAdd(`התוכנית: ${full.subquestions.length} תת-שאלות`, full.startedAt);
            head(full.summary, full); paintPlan(); paintSources(); renderReport(); paintSteps(); paintExtras(); pickTab();
            if (isTerm(full.status)) logAdd(full.status === 'done' ? `הושלם: ${(full.sources || []).length} מקורות, ${App.fmt.dur((full.endedAt || Date.now()) - full.startedAt)}` : `${STATUS_TXT[full.status] || full.status}${full.phase ? ': ' + full.phase : ''}`, full.endedAt);
            break;
          }
          case 'update': {
            const prev = st.sum; st.sum = d; upsertResearch(d, true);
            if (!prev || prev.phase !== d.phase) logAdd(d.phase);
            if (prev && prev.sourcesCount !== d.sourcesCount) logAdd(`מקורות שצוטטו: ${d.sourcesCount}`);
            head(d, st.full); paintPlan(); paintSteps(); schedulePaint(); fetchSoon(); break;
          }
          case 'delta': { st.report += typeof d === 'string' ? d : (d && d.text) || ''; reportSoon(); break; }
          case 'end': {
            st.sum = d; upsertResearch(d, true); head(d, st.full);
            logAdd(d.status === 'done' ? 'הושלם' : (STATUS_TXT[d.status] || d.status) + (d.error ? ': ' + d.error : ''));
            fetchFull(true).then(() => paintSteps()); schedulePaint(); refresh(); break;
          }
          case '__eof': case '__error': {
            if (d && d.status === 404) { R.phase.textContent = 'המחקר לא נמצא'; break; }
            const cur = S.research.get(id) || st.sum;
            if (cur && isTerm(cur.status)) break;
            if (retries++ < 30) setTimeout(() => { if (!closedByUser) connect(); }, 1200);
            break;
          }
        }
      });
    };
    connect();
    return viewer;
  }

  // ============================================================
  //  10) פתיחה לפי מזהה כלי + קישוט כרטיס כלי בצ'אט
  // ============================================================
  function entityForTool(toolId, name) {
    if (!toolId) return null;
    if (!name || name === 'deep_research') for (const r of S.research.values()) if (r.parentToolId === toolId) return { kind: 'research', s: r };
    const list = [...S.agents.values()].filter(a => a.parentToolId === toolId && !a.researchId);
    if (list.length) { list.sort((a, b) => (isTerm(a.status) - isTerm(b.status)) || a.startedAt - b.startedAt); return { kind: 'agent', s: list[0] }; }
    return null;
  }
  async function openByToolId(toolId, convId, name) {
    let ent = entityForTool(toolId, name);
    if (!ent) { await refreshNow(); ent = entityForTool(toolId, name); }
    if (!ent) { App.toast('הסוכן עדיין לא נרשם, נסה שוב בעוד רגע', 2200); return null; }
    return ent.kind === 'research' ? openResearch(ent.s.id) : openAgent(ent.s.id);
  }

  function decorateToolCard(card, o) {
    try {
      if (!card || !o || !o.toolId) return null;
      if (card.__agStrip) return card.__agStrip;
      const sum = card.querySelector(':scope > summary') || card.querySelector('summary');
      if (!sum) return null;
      card.classList.add('ag-decorated');
      const strip = el('div', 'ag-strip');
      strip.dataset.for = o.toolId; strip.dataset.status = 'waiting';
      strip.innerHTML = `<span class="ag-st st-queued"></span><span class="ag-strip-act">ממתין לסוכן…</span><span class="ag-strip-meta"><span class="ag-clock"></span><span class="ag-strip-steps"></span><span class="ag-strip-cost"></span></span><button type="button" class="ag-mini ag-strip-stop" hidden title="עצור"><i class="ag-sq"></i> עצור</button><button type="button" class="ag-mini ag-strip-open" title="פתח את מציג הסוכן">פתח מציג ▸</button>`;
      sum.appendChild(strip);
      const rec = { card, strip, toolId: o.toolId, name: o.name || '', convId: o.convId || null, at: Date.now(), polls0: S.polls };
      const swallow = ev => { ev.preventDefault(); ev.stopPropagation(); };
      strip.addEventListener('click', e => { if (!e.target.closest('button')) e.stopPropagation(); });
      strip.querySelector('.ag-strip-open').addEventListener('click', e => { swallow(e); openByToolId(rec.toolId, rec.convId, rec.name); });
      strip.querySelector('.ag-strip-stop').addEventListener('click', e => { swallow(e); const ent = entityForTool(rec.toolId, rec.name); if (!ent) return; if (ent.kind === 'research') stopResearch(ent.s.id); else stopAgent(ent.s.id); });
      rec.api = { strip, update: () => updateStrip(rec), detach() { strip.remove(); S.strips.delete(card); card.classList.remove('ag-decorated'); delete card.__agStrip; } };
      card.__agStrip = rec.api;
      S.strips.set(card, rec);
      updateStrip(rec);
      refresh();
      return rec.api;
    } catch (e) { console.error('[agents decorate]', e); return null; }
  }
  function updateStrip(rec) {
    const ent = entityForTool(rec.toolId, rec.name);
    const strip = rec.strip, q = sel => strip.querySelector(sel);
    if (!ent) {
      const missed = S.polls - rec.polls0 >= 2 && Date.now() - rec.at > 4000;
      setAct(q('.ag-strip-act'), missed ? 'אין רשומת סוכן לקריאה הזו' : 'ממתין לסוכן…');
      strip.dataset.status = missed ? 'missing' : 'waiting';
      q('.ag-strip-open').hidden = missed; q('.ag-strip-stop').hidden = true;
      return;
    }
    const s = ent.s, live = !isTerm(s.status);
    strip.dataset.status = s.status; strip.dataset.kind = ent.kind; strip.dataset.entityId = s.id;
    const stEl = q('.ag-st'); stEl.className = 'ag-st st-' + (live ? 'running' : s.status); stEl.textContent = STATUS_IC[s.status] || '';
    let act;
    if (ent.kind === 'research') { const p = researchProgress(s); act = (s.phase || '') + (p.total && live ? ` · ${p.done}/${p.total} חוקרים` : '') + ` · 📚 ${s.sourcesCount || 0}`; }
    else act = live ? (s.activity || '') : (STATUS_TXT[s.status] || '') + (s.error ? ': ' + s.error : '');
    setAct(q('.ag-strip-act'), act);
    setClock(q('.ag-clock'), s.startedAt, live ? 0 : (s.endedAt || s.startedAt));
    q('.ag-strip-steps').textContent = ent.kind === 'agent' ? `⚙ ${s.steps || 0}` : '';
    { const ce = q('.ag-strip-cost'); ce.textContent = money(s.costUSD, s.pct); ce.hidden = !ce.textContent; }
    const stopB = q('.ag-strip-stop'); const stopping = live && (ent.kind === 'research' ? S.stoppingR.has(s.id) : S.stopping.has(s.id));
    stopB.hidden = !live; stopB.disabled = stopping; stopB.lastChild.textContent = stopping ? ' עוצר…' : ' עצור';
    q('.ag-strip-open').hidden = false;
  }
  function updateStrips() {
    for (const [card, rec] of S.strips) {
      if (!card.isConnected && Date.now() - rec.at > 3000) { S.strips.delete(card); continue; }
      updateStrip(rec);
    }
  }

  // ============================================================
  //  11) חשיפה: App.agents + אירועי core
  // ============================================================
  App.agents = {
    refresh: () => refreshNow(),
    openAgent, openResearch, openByToolId, decorateToolCard, stopAll, stopAgent, stopResearch, runningCount, runningList, runningResearchList,
    stop: stopById,
    newResearch: () => openNewResearch(),
    list: () => [...S.agents.values()],
    listResearch: () => [...S.research.values()],
    _debug: { S, streams: () => S.streams.size, viewers: () => S.viewers, icons: toolIconKeys }
  };

  App.on('agent:update', s => { if (s && s.id && upsertAgent(s, true)) schedulePaint(); });
  App.on('research:update', s => { if (s && s.id && upsertResearch(s, true)) schedulePaint(); });
  App.on('view:shown', name => { if (name === 'agents' || name === 'research') refreshNow(); });

  App.ready(() => {
    guard('buildAgentsView', buildAgentsView);
    guard('buildResearchView', buildResearchView);
    guard('restoreViewer', () => {
      let v = null; try { v = JSON.parse(sessionStorage.getItem(SESSION_KEY) || 'null'); } catch { }
      if (v && v.id) setTimeout(() => { if (v.kind === 'research') openResearch(v.id); else openAgent(v.id); }, 350); // רענון דף באמצע ריצה: המציג חוזר
    });
    poll();
  });
})();
