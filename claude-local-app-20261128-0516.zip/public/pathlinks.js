// ============================================================
//  pathlinks.js — נתיבי קבצים בצ'אט כקישורים (כמו ב-VS Code) + מציג תמונות/סרטונים בחצי חלון עם זום
//  * כל נתיב ש-Claude קורא / כותב / עורך / מחפש בו (כרטיסי הכלים), נתיבים בתוצאות (Glob, Grep…) ונתיבים בטקסט שלו — קישור.
//  * לחיצה: תמונה / סרטון / שמע → נפתח כאן בחצי חלון (זום בגלגלת, גרירה להזזה, התאמה / 100%; סרטון: ניגון, קפיצה, מהירות).
//           קובץ אחר → "הצג במיקום": סייר הקבצים נפתח והקובץ מסומן. תיקייה → נפתחת.
//           (כשעובדים על מחשב אחר ברשת — הקובץ מוצג כאן באפליקציה, כי החלון של המחשב ההוא לא מול העיניים שלך)
//  * Ctrl+לחיצה: תצוגה בתוך האפליקציה. קליק ימני: כל האפשרויות + העתקת הנתיב.
//  App.paths = { open, show, close, mark, linkifyPre, resolve, state }
// ============================================================
(function () {
  'use strict';
  const App = window.App;
  if (!App || window.__pathLinksLoaded) return;
  window.__pathLinksLoaded = true;

  const enc = encodeURIComponent;
  const IMG = /\.(png|jpe?g|gif|webp|bmp|svg|ico|avif)$/i, VID = /\.(mp4|webm|mov|m4v|ogv|mkv)$/i, AUD = /\.(mp3|wav|ogg|oga|m4a|flac|opus|aac)$/i;
  const kindOf = p => (IMG.test(p) ? 'image' : VID.test(p) ? 'video' : AUD.test(p) ? 'audio' : '');
  const remote = () => !!(window.MESH && window.MESH.remote);
  const rw = u => (window.MESH && window.MESH.rw ? window.MESH.rw(u) : u);
  const isAbs = p => /^([A-Za-z]:[\\/]|\\\\|\/|~)/.test(p);
  const fmtSize = n => (n == null ? '' : n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : n < 1073741824 ? (n / 1048576).toFixed(1) + ' MB' : (n / 1073741824).toFixed(2) + ' GB');
  const fmtTime = s => { if (!isFinite(s)) return '0:00'; s = Math.max(0, s); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = Math.floor(s % 60); return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0'); };

  // ---------- נתיב: ניקוי ופתרון יחסי ----------
  function clean(raw) {
    let p = String(raw || '').trim().replace(/^["'`]+|["'`]+$/g, '');
    let line = 0, m;
    if (/^file:\/\//i.test(p)) { p = p.replace(/^file:\/\/\/?/i, ''); if (!/^[A-Za-z]:/.test(p) && !p.startsWith('/')) p = '/' + p; }
    if ((m = p.match(/#L(\d+)(?:-L?\d+)?$/))) { line = +m[1]; p = p.slice(0, m.index); }
    if ((m = p.match(/^(.*?[^:\\/]):(\d+)(?::\d+)?$/)) && !/^[A-Za-z]$/.test(m[1])) { line = +m[2]; p = m[1]; }
    if (/%[0-9A-Fa-f]{2}/.test(p)) { try { p = decodeURIComponent(p); } catch { } }
    return { path: p, line };
  }
  function resolve(raw, base) {
    const c = clean(raw); let p = c.path;
    if (!isAbs(p) && base) { const sep = /^[A-Za-z]:|\\/.test(base) ? '\\' : '/'; p = String(base).replace(/[\\/]+$/, '') + sep + (p === '.' ? '' : p.replace(/^\.[\\/]/, '').replace(/[\\/]/g, sep)); p = p.replace(/[\\/]+$/, '') || p; }
    return { path: p, line: c.line };
  }
  const baseOf = el => {
    if (el.dataset.base) return el.dataset.base;
    const c = App.chats && App.chats.list && App.chats.list().find(x => x.pane && x.pane.contains(el));
    return (c && c.workingDir) || (App.explorer && App.explorer.getRoot && App.explorer.getRoot()) || '';
  };

  // ---------- סימון רכיב כקישור ----------
  function mark(el, path, base) {
    if (!el || !path) return el;
    el.classList.add('path-link'); el.dataset.path = String(path); if (base) el.dataset.base = base;
    el.title = String(path) + '\nלחיצה: פתיחה כאן, בתוך האפליקציה · קליק ימני: המיקום במחשב, עריכה ועוד';
    return el;
  }
  // תוצאה של כלי: שורות שהן נתיב (Glob / Grep / LS) — או נתיבים מלאים בתוך הטקסט (כל כלי אחר)
  const LINE_PATH = /^(\s*)((?:[A-Za-z]:[\\/]|\\\\)[^:*?"<>|\r\n]*[^:*?"<>|\r\n\s]|\/[^:*?"<>|\r\n]*[^:*?"<>|\r\n\s])(?=:\d+[:-]|\s*$)/;
  function linkifyPre(pre, base, mode) {
    if (!pre) return 0;
    const text = pre.textContent || ''; if (!text || text.length > 400000) return 0;
    const lines = text.split('\n'); if (lines.length > 5000) return 0;
    const frag = document.createDocumentFragment(); let hits = 0;
    const link = p => { const s = document.createElement('span'); s.textContent = p; mark(s, p, base); hits++; return s; };
    if (mode === 'lines') {
      lines.forEach((ln, i) => {
        const m = LINE_PATH.exec(ln);
        if (m && m[2].length > 3 && (/^([A-Za-z]:|\\\\)/.test(m[2]) || (window.renderMarkdown && renderMarkdown.looksPath(m[2])))) { if (m[1]) frag.append(m[1]); frag.append(link(m[2])); frag.append(ln.slice(m[1].length + m[2].length)); }
        else frag.append(ln);
        if (i < lines.length - 1) frag.append('\n');
      });
    } else {
      if (text.length > 60000 || !(window.renderMarkdown && renderMarkdown.findPaths)) return 0;
      const found = renderMarkdown.findPaths(text); if (!found.length) return 0;
      let at = 0; for (const f of found) { frag.append(text.slice(at, f.index)); frag.append(link(f.path)); at = f.index + f.path.length; } frag.append(text.slice(at));
    }
    if (hits) { pre.textContent = ''; pre.append(frag); }
    return hits;
  }

  // ---------- פעולות ----------
  async function statOf(p) { try { return await App.api('/api/fs/stat?path=' + enc(p)); } catch (e) { return { path: p, exists: false, error: e.message }; } }
  async function osCall(op, p) {
    try { await App.api('/api/fs/' + op, { method: 'POST', body: { path: p } }); return true; }
    catch (e) { App.toast((op === 'reveal' ? 'לא הצלחתי להציג בסייר: ' : 'הפתיחה נכשלה: ') + e.message, 4000); return false; }
  }
  async function inApp(p) { if (App.explorer && App.explorer.openFile) return App.explorer.openFile(p); }
  async function copy(p) { try { await navigator.clipboard.writeText(p); App.toast('📋 הנתיב הועתק'); } catch { App.toast(p, 5000); } }

  // לחיצה על נתיב: כל קובץ נפתח כאן, בתוך האפליקציה (חצי חלון). תיקייה — בעץ הקבצים של האפליקציה
  async function open(raw, o = {}) {
    const { path } = resolve(raw, o.base);
    if (!path) return;
    if (kindOf(path)) return show(path);
    const st = await statOf(path);
    if (!st || !st.exists) { App.toast('הנתיב לא קיים ' + (remote() ? 'במחשב הזה' : 'במחשב') + ': ' + path, 4500); return; }
    if (st.dir) {
      try { if (App.explorer && await App.explorer.reveal(st.path)) return; } catch { }
      if (!remote() && await osCall('open', st.path)) App.toast('📂 התיקייה נפתחה: ' + App.baseName(st.path), 2200); else App.toast('📁 ' + st.path, 4500);
      return;
    }
    return show(st.path);
  }
  function menuFor(e, raw, base) {
    const { path } = resolve(raw, base);
    App.menu(e.clientX, e.clientY, [
      { icon: '👁', label: 'הצג כאן (בתוך האפליקציה)', onClick: () => open(path) },
      !remote() && { icon: '📂', label: 'פתח את המיקום במחשב (סייר הקבצים)', onClick: () => osCall('reveal', path) },
      { icon: '✏️', label: 'פתח לעריכה באפליקציה', onClick: () => inApp(path) },
      { icon: '🗂', label: 'הצג בעץ הקבצים של האפליקציה', onClick: async () => { try { await App.explorer.reveal(path); } catch (er) { App.toast(er.message, 3500); } } },
      !remote() && { icon: '↗', label: 'פתח באפליקציה ברירת המחדל', onClick: () => osCall('open', path) },
      { sep: true },
      { icon: '📋', label: 'העתק נתיב', hint: path.length > 46 ? '…' + path.slice(-44) : path, onClick: () => copy(path) }
    ]);
  }
  const linkOf = e => (e.target && e.target.closest ? e.target.closest('.path-link') : null);
  document.addEventListener('click', e => {
    const a = linkOf(e); if (!a || e.button !== 0 || a.closest('.path-card')) return; // כרטיס נתיב — מטופל למטה
    e.preventDefault(); e.stopPropagation(); // בתוך כותרת כרטיס כלי: לא לפתוח/לסגור את הכרטיס
    const raw = a.dataset.path || a.textContent, base = baseOf(a);
    if (e.ctrlKey || e.metaKey) return inApp(resolve(raw, base).path);
    open(raw, { base });
  }, true);
  document.addEventListener('auxclick', e => { if (linkOf(e)) { e.preventDefault(); e.stopPropagation(); } }, true); // לחיצה אמצעית: לא חלון חדש
  document.addEventListener('contextmenu', e => { const a = linkOf(e); if (!a) return; e.preventDefault(); e.stopPropagation(); menuFor(e, a.dataset.path || a.textContent, baseOf(a)); }, true);

  // ===================== המציג: חצי חלון ליד הצ'אט =====================
  let V = null;
  const W_KEY = 'claude.mediaPanelW';
  function panel() {
    if (V) return V;
    const ws = document.getElementById('workspace'), cs = document.getElementById('chatstack');
    const sp = App.el('div', 'splitter mp-splitter'); sp.title = 'גרור לשינוי רוחב';
    const root = App.el('aside', 'mediapanel'); root.id = 'mediapanel'; root.tabIndex = -1;
    root.innerHTML = `
      <div class="mp-head">
        <span class="mp-ic"></span>
        <div class="mp-titles"><span class="mp-name"></span><span class="mp-path path-link" dir="ltr"></span></div>
        <div class="mp-tools">
          <button class="mp-btn mp-zout" title="הקטן (−)">－</button><button class="mp-zoom" title="לחיצה: התאמה לחלון / 100%">100%</button><button class="mp-btn mp-zin" title="הגדל (+)">＋</button>
          <button class="mp-btn mp-fit" title="התאם לחלון (0)">⤢</button><button class="mp-btn mp-one" title="גודל אמיתי 100% (1)">1:1</button>
          <span class="mp-sep"></span>
          <button class="mp-btn mp-view" hidden></button><button class="mp-btn mp-edit" title="פתח לעריכה באפליקציה" hidden>✏️</button><button class="mp-btn mp-reveal" title="פתח את המיקום במחשב (סייר הקבצים)">📂</button><button class="mp-btn mp-ext" title="פתח באפליקציה ברירת המחדל">↗</button><button class="mp-btn mp-copy" title="העתק נתיב">📋</button>
          <button class="mp-btn mp-close" title="סגור (Esc)">✕</button>
        </div>
      </div>
      <div class="mp-stage" tabindex="0"><div class="mp-msg" hidden></div></div>
      <div class="mp-foot">
        <div class="mp-vctl" hidden>
          <button class="mp-btn mp-play" title="נגן / עצור (רווח)">▶</button>
          <span class="mp-time">0:00</span><input type="range" class="mp-seek" min="0" max="1000" value="0" step="1" title="קפיצה"><span class="mp-dur">0:00</span>
          <button class="mp-btn mp-mute" title="השתק">🔊</button><input type="range" class="mp-vol" min="0" max="100" value="100" title="עוצמה">
          <select class="mp-rate" title="מהירות"><option value="0.5">0.5×</option><option value="0.75">0.75×</option><option value="1" selected>1×</option><option value="1.25">1.25×</option><option value="1.5">1.5×</option><option value="2">2×</option></select>
          <button class="mp-btn mp-loop" title="חזרה בלולאה">🔁</button>
        </div>
        <span class="mp-info"></span>
      </div>`;
    cs.after(sp, root);
    const q = s => root.querySelector(s);
    V = { root, sp, stage: q('.mp-stage'), msg: q('.mp-msg'), media: null, kind: '', path: '', s: 1, tx: 0, ty: 0, fitMode: true, nw: 0, nh: 0, st: null };
    // רוחב: חצי מהאזור של הצ'אט (או מה שגררת בפעם הקודמת)
    sp.addEventListener('pointerdown', e => {
      e.preventDefault(); sp.setPointerCapture(e.pointerId); sp.classList.add('drag');
      const x0 = e.clientX, w0 = root.getBoundingClientRect().width, max = ws.getBoundingClientRect().width - 380;
      const mv = ev => { root.style.width = Math.max(260, Math.min(max, w0 - (ev.clientX - x0))) + 'px'; };
      const up = () => { sp.classList.remove('drag'); sp.removeEventListener('pointermove', mv); sp.removeEventListener('pointerup', up); try { localStorage.setItem(W_KEY, String(Math.round(root.getBoundingClientRect().width))); } catch { } };
      sp.addEventListener('pointermove', mv); sp.addEventListener('pointerup', up);
    });
    q('.mp-close').onclick = () => close();
    q('.mp-zin').onclick = () => zoomBy(1.25); q('.mp-zout').onclick = () => zoomBy(1 / 1.25);
    q('.mp-fit').onclick = () => fit(); q('.mp-one').onclick = () => setScale(1);
    q('.mp-zoom').onclick = () => (V.fitMode ? setScale(1) : fit());
    q('.mp-reveal').onclick = () => (remote() ? App.explorer.reveal(V.path).catch(er => App.toast(er.message, 3500)) : osCall('reveal', V.path));
    q('.mp-ext').onclick = () => osCall('open', V.path);
    q('.mp-copy').onclick = () => copy(V.path);
    q('.mp-view').onclick = () => { if (!V.data) return; const order = { json: ['tree', 'raw'], markdown: ['rendered', 'source'], html: ['rendered', 'source'] }[V.data.kind]; if (!order) return; V.view = order[(order.indexOf(V.view) + 1) % order.length]; renderFile(V, V.data); };
    q('.mp-edit').onclick = () => inApp(V.path);
    // זום בגלגלת (סביב העכבר), גרירה להזזה, לחיצה כפולה: התאמה ↔ 100%
    V.stage.addEventListener('wheel', e => { if (V.kind === 'file') { if (e.ctrlKey) { e.preventDefault(); zoomBy(e.deltaY < 0 ? 1.1 : 1 / 1.1); } return; } if (!V.media || V.kind === 'audio') return; e.preventDefault(); const r = V.stage.getBoundingClientRect(); zoomBy(Math.exp(-e.deltaY * 0.0015), e.clientX - r.left, e.clientY - r.top); }, { passive: false });
    let drag = null;
    V.stage.addEventListener('pointerdown', e => {
      if (e.button !== 0 || !V.media || V.kind === 'audio' || e.target.closest('.mp-bigplay')) return;
      drag = { x: e.clientX, y: e.clientY, tx: V.tx, ty: V.ty, moved: false }; V.stage.setPointerCapture(e.pointerId); V.stage.classList.add('grabbing');
    });
    V.stage.addEventListener('pointermove', e => { if (!drag) return; const dx = e.clientX - drag.x, dy = e.clientY - drag.y; if (Math.abs(dx) + Math.abs(dy) > 3) drag.moved = true; if (drag.moved) { V.tx = drag.tx + dx; V.ty = drag.ty + dy; V.fitMode = false; apply(); } });
    V.stage.addEventListener('pointerup', () => { if (!drag) return; const was = drag; drag = null; V.stage.classList.remove('grabbing'); if (!was.moved && V.kind === 'video') togglePlay(); });
    V.stage.addEventListener('dblclick', e => { if (!V.media || V.kind === 'audio') return; const r = V.stage.getBoundingClientRect(); if (V.fitMode) setScale(V.kind === 'image' ? 1 : V.s * 2, e.clientX - r.left, e.clientY - r.top); else fit(); });
    new ResizeObserver(() => { if (V.media && V.fitMode) fit(); else if (V.media) apply(); }).observe(V.stage);
    // מקלדת: פעילה כשהמציג "בפוקוס" — נפתח עכשיו או שלחצת בתוכו לאחרונה (לחיצה בצ'אט מחזירה את המקשים לצ'אט)
    document.addEventListener('pointerdown', e => { V.hot = !!(e.target.closest && e.target.closest('#mediapanel')); }, true);
    document.addEventListener('keydown', e => {
      if (!V.hot || V.root.hidden || e.ctrlKey || e.metaKey || e.altKey || document.querySelector('.modal-backdrop')) return;
      const inField = e.target.closest && e.target.closest('input,select,textarea,[contenteditable="true"]');
      if (inField && (e.key !== 'Escape' || !inField.closest('#mediapanel'))) return;
      const k = e.key;
      if (k === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); }
      else if (k === '+' || k === '=') { e.preventDefault(); zoomBy(1.25); } else if (k === '-' || k === '_') { e.preventDefault(); zoomBy(1 / 1.25); }
      else if (k === '0') { e.preventDefault(); fit(); } else if (k === '1') { e.preventDefault(); setScale(1); }
      else if (V.kind !== 'image' && V.media && (k === ' ' || k === 'k')) { e.preventDefault(); togglePlay(); }
      else if (V.kind !== 'image' && V.media && (k === 'ArrowLeft' || k === 'ArrowRight')) { e.preventDefault(); V.media.currentTime = Math.max(0, V.media.currentTime + (k === 'ArrowRight' ? 5 : -5)); }
    }, true);
    // בקרי וידאו (משלנו — כך שהזום מגדיל רק את התמונה, לא את הכפתורים)
    const play = q('.mp-play'), seek = q('.mp-seek'), mute = q('.mp-mute'), vol = q('.mp-vol'), rate = q('.mp-rate'), loop = q('.mp-loop');
    play.onclick = () => togglePlay();
    seek.oninput = () => { const m = V.media; if (m && isFinite(m.duration)) m.currentTime = (seek.value / 1000) * m.duration; };
    mute.onclick = () => { const m = V.media; if (!m) return; m.muted = !m.muted; paintVctl(); };
    vol.oninput = () => { const m = V.media; if (!m) return; m.volume = vol.value / 100; m.muted = m.volume === 0; paintVctl(); };
    rate.onchange = () => { if (V.media) V.media.playbackRate = Number(rate.value) || 1; };
    loop.onclick = () => { if (V.media) { V.media.loop = !V.media.loop; paintVctl(); } };
    return V;
  }
  function paintVctl() {
    if (!V || !V.media || V.kind === 'image') return; const m = V.media, q = s => V.root.querySelector(s);
    q('.mp-play').textContent = m.paused ? '▶' : '⏸';
    q('.mp-time').textContent = fmtTime(m.currentTime); q('.mp-dur').textContent = fmtTime(m.duration);
    if (isFinite(m.duration) && m.duration > 0 && document.activeElement !== q('.mp-seek')) q('.mp-seek').value = Math.round((m.currentTime / m.duration) * 1000);
    q('.mp-mute').textContent = m.muted || m.volume === 0 ? '🔇' : '🔊';
    q('.mp-loop').classList.toggle('on', !!m.loop);
    const big = V.stage.querySelector('.mp-bigplay'); if (big) big.hidden = !m.paused;
  }
  function togglePlay() { const m = V && V.media; if (!m || V.kind === 'image') return; if (m.paused) m.play().catch(e => App.toast('הניגון נכשל: ' + e.message, 4000)); else m.pause(); }
  function apply() {
    if (!V || !V.media || V.kind === 'audio') return;
    V.media.style.width = V.nw + 'px'; V.media.style.height = V.nh + 'px';
    V.media.style.transform = `translate(${V.tx}px, ${V.ty}px) scale(${V.s})`;
    V.stage.classList.toggle('pixel', V.kind === 'image' && V.s >= 2);
    V.root.querySelector('.mp-zoom').textContent = Math.round(V.s * 100) + '%';
    info();
  }
  function fitScale() { const r = V.stage.getBoundingClientRect(); const pad = 16; const f = Math.min((r.width - pad * 2) / V.nw, (r.height - pad * 2) / V.nh); return V.kind === 'image' ? Math.min(f, V.nw < 260 && V.nh < 260 ? 8 : 1) : f; }
  function center() { const r = V.stage.getBoundingClientRect(); V.tx = (r.width - V.nw * V.s) / 2; V.ty = (r.height - V.nh * V.s) / 2; }
  function docZoom(z) { if (!V) return; V.dz = Math.max(0.5, Math.min(3, z)); const d = V.stage.querySelector('.mp-doc'); if (d && !(V.data && V.data.kind === 'pdf')) d.style.zoom = V.dz; V.root.querySelector('.mp-zoom').textContent = Math.round(V.dz * 100) + '%'; info(); }
  function fit() { if (V && V.kind === 'file') return docZoom(1); if (!V || !V.media || !V.nw) return; V.s = Math.max(0.01, fitScale()); V.fitMode = true; center(); apply(); }
  function setScale(s, cx, cy) {
    if (V && V.kind === 'file') return docZoom(s);
    if (!V || !V.media || !V.nw) return; const r = V.stage.getBoundingClientRect();
    if (cx == null) { cx = r.width / 2; cy = r.height / 2; }
    const ns = Math.max(0.02, Math.min(40, s)); V.tx = cx - (cx - V.tx) * (ns / V.s); V.ty = cy - (cy - V.ty) * (ns / V.s); V.s = ns; V.fitMode = false; apply();
  }
  function zoomBy(f, cx, cy) { if (V && V.kind === 'file') return docZoom((V.dz || 1) * f); if (V && V.media) setScale(V.s * f, cx, cy); }
  function info() {
    if (!V) return; const parts = [];
    if (V.nw) parts.push(V.nw + '×' + V.nh);
    if (V.st && V.st.size != null) parts.push(fmtSize(V.st.size));
    if (V.kind !== 'image' && V.media && isFinite(V.media.duration)) parts.push(fmtTime(V.media.duration));
    if (V.kind !== 'audio' && V.media) parts.push('זום ' + Math.round(V.s * 100) + '%' + (V.fitMode ? ' (מותאם לחלון)' : ''));
    const cnt = (n, one, many) => (n === 1 ? one : n + ' ' + many);
    if (V.kind === 'file' && V.data) { const d = V.data; parts.push({ pdf: 'PDF', doc: 'מסמך', sheets: d.sheets ? cnt(d.sheets.length, 'גיליון אחד', 'גיליונות') : 'גיליון', table: cnt((d.rows || []).length, 'שורה אחת', 'שורות'), slides: cnt((d.slides || []).length, 'שקף אחד', 'שקפים'), json: 'JSON', markdown: 'Markdown', html: 'HTML', text: d.text != null ? cnt(d.text.split('\n').length, 'שורה אחת', 'שורות') : 'טקסט', archive: cnt(d.total || (d.entries || []).length, 'פריט אחד', 'פריטים'), binary: 'בינארי' }[d.kind] || d.kind); if (d.kind !== 'pdf') parts.push('זום ' + Math.round((V.dz || 1) * 100) + '%'); if (d.mtime) parts.push(App.fmt.fullDateTime(d.mtime)); }
    if (remote()) parts.push('🖥 מהמחשב המרוחק');
    // כל חלק מבודד (FSI…PDI): "115 B" / "6 שורות" / התאריך לא מתערבבים זה בזה בשורה הימנית-שמאלית
    V.root.querySelector('.mp-info').textContent = parts.map(p => '\u2068' + p + '\u2069').join(' · ');
  }
  function showMsg(t) { V.msg.hidden = !t; V.msg.textContent = t || ''; }

  // ---------- פתיחת החלון (משותף לכל הסוגים) ----------
  function openPanel(path, kind) {
    const P = panel();
    const wasHidden = P.root.hidden || !P.root.isConnected || !P.root.style.width;
    P.root.hidden = false; P.sp.hidden = false;
    if (wasHidden) {
      let w = 0; try { w = Number(localStorage.getItem(W_KEY)) || 0; } catch { }
      const cs = document.getElementById('chatstack').getBoundingClientRect().width, avail = cs + (P.root.getBoundingClientRect().width || 0);
      P.root.style.width = Math.round(w > 200 ? Math.min(w, avail - 360) : avail / 2) + 'px';
    }
    if (P.media) { try { P.media.pause && P.media.pause(); P.media.removeAttribute('src'); P.media.load && P.media.load(); } catch { } P.media.remove(); P.media = null; }
    P.stage.querySelectorAll('.mp-bigplay, .mp-doc').forEach(x => x.remove());
    Object.assign(P, { path, kind, s: 1, tx: 0, ty: 0, fitMode: true, nw: 0, nh: 0, st: null, dz: 1, data: null, view: '' });
    P.root.dataset.fkind = ''; P.root.dataset.kind = kind; P.stage.classList.toggle('video', kind === 'video' || kind === 'audio'); P.stage.classList.toggle('doc', kind === 'file');
    P.root.querySelector('.mp-name').textContent = App.baseName(path);
    const pe = P.root.querySelector('.mp-path'); pe.textContent = path; pe.dataset.path = path; pe.title = path + '\nלחיצה: הצג במיקום';
    P.root.querySelector('.mp-vctl').hidden = kind !== 'video' && kind !== 'audio';
    P.root.querySelectorAll('.mp-ext').forEach(b => (b.hidden = remote()));
    P.root.querySelector('.mp-view').hidden = true; P.root.querySelector('.mp-edit').hidden = true;
    return P;
  }

  // ---------- כל שאר הקבצים: תצוגה לפי הסוג (השרת ממיר: /api/fs/preview) ----------
  const FILE_IC = { pdf: '📕', doc: '📄', sheets: '📊', table: '📊', slides: '📽', json: '🧾', markdown: '📝', html: '🌐', text: '📃', archive: '🗜', binary: '⬛' };
  const hl = (code, lang) => (window.renderMarkdown && renderMarkdown.highlight && code.length < 400000 ? renderMarkdown.highlight(code, lang) : esc(code));
  const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  function codeHtml(text, lang) {
    const n = text.split('\n').length; let g = ''; for (let i = 1; i <= n; i++) g += i + '\n';
    return `<div class="fv-code"><pre class="fv-gutter" aria-hidden="true">${g}</pre><pre class="fv-src" dir="ltr"><code>${hl(text, lang)}</code></pre></div>`;
  }
  function jsonTree(v, key, idx, depth) {
    const t = Array.isArray(v) ? 'arr' : v === null ? 'null' : typeof v;
    const k = key != null ? `<span class="jk">${esc(JSON.stringify(key))}</span><span class="jp">: </span>` : idx != null ? `<span class="ji">${idx}</span><span class="jp">: </span>` : '';
    if (t === 'arr' || t === 'object') {
      const ents = t === 'arr' ? v.map((x, i) => [i, x]) : Object.entries(v);
      if (!ents.length) return `<div class="jl">${k}<span class="jb">${t === 'arr' ? '[ ]' : '{ }'}</span></div>`;
      const kids = ents.slice(0, 3000).map(([kk, x]) => t === 'arr' ? jsonTree(x, null, kk, depth + 1) : jsonTree(x, kk, null, depth + 1)).join('') + (ents.length > 3000 ? `<div class="jl jc">… ועוד ${ents.length - 3000}</div>` : '');
      return `<details class="jn"${depth < 2 ? ' open' : ''}><summary>${k}<span class="jb">${t === 'arr' ? '[' : '{'}</span><span class="jc">${ents.length} ${t === 'arr' ? 'פריטים' : 'שדות'}</span></summary><div class="jkids">${kids}</div><div class="jb">${t === 'arr' ? ']' : '}'}</div></details>`;
    }
    const val = t === 'string' ? `<span class="jstr">${esc(JSON.stringify(v))}</span>` : t === 'number' ? `<span class="jnum">${v}</span>` : t === 'boolean' ? `<span class="jbool">${v}</span>` : '<span class="jnull">null</span>';
    return `<div class="jl">${k}${val}</div>`;
  }
  // כיוון הטבלה: גיליון שסומן "מימין לשמאל" (או שרוב התאים שלו בעברית/ערבית) — RTL; כל השאר כמו באקסל: A משמאל
  const sheetRtl = (rows, flag) => {
    if (flag != null && flag !== false) return true;
    let rtl = 0, ltr = 0;
    for (const r of rows.slice(0, 200)) for (const c of r) { const s = String(c == null ? '' : c); if (/[֐-׿؀-ۿ]/.test(s)) rtl++; else if (/[A-Za-z]/.test(s)) ltr++; }
    return rtl > ltr;
  };
  function tableHtml(rows, cap, rtlFlag) {
    if (!rows.length) return '<div class="fv-empty-note">ריק</div>';
    const w = Math.max(...rows.map(r => r.length)), head = rows[0], col = i => { let s = ''; i++; while (i) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };
    return `<div class="fv-tablewrap" dir="${sheetRtl(rows, rtlFlag || null) ? 'rtl' : 'ltr'}"><table class="fv-grid"><thead><tr><th class="fv-rn"></th>${Array.from({ length: w }, (_, i) => `<th>${col(i)}</th>`).join('')}</tr></thead><tbody>${rows.map((r, ri) => `<tr><td class="fv-rn">${ri + 1}</td>${Array.from({ length: w }, (_, i) => `<td dir="auto">${esc(r[i] == null ? '' : r[i])}</td>`).join('')}</tr>`).join('')}</tbody></table></div>${cap ? `<div class="fv-note">${esc(cap)}</div>` : ''}`;
  }
  const fmtDate = ms => (ms ? App.fmt.fullDateTime(ms) : '');
  function renderFile(P, d) {
    const box = P.stage.querySelector('.mp-doc'); const view = P.view; let h = '';
    const note = (d.note ? `<div class="fv-note">${esc(d.note)}</div>` : '') + (d.truncated ? '<div class="fv-note">הקובץ גדול — מוצגים 4 MB ראשונים</div>' : '');
    const vb = P.root.querySelector('.mp-view'), eb = P.root.querySelector('.mp-edit');
    const views = { json: [['tree', '🌳 עץ'], ['raw', '{ } טקסט']], markdown: [['rendered', '📖 מעוצב'], ['source', '📝 מקור']], html: [['rendered', '🌐 דף'], ['source', '📝 קוד']] }[d.kind];
    vb.hidden = !views; if (views) { const cur = views.find(v => v[0] === view) || views[0]; P.view = cur[0]; const next = views[(views.indexOf(cur) + 1) % views.length]; vb.textContent = next[1]; vb.title = 'החלף תצוגה'; }
    eb.hidden = !['json', 'markdown', 'html', 'text', 'table'].includes(d.kind) || /^(doc|dot|xls|xlt|ppt|pps|rtf)$/.test(d.ext || '');
    switch (d.kind) {
      case 'pdf': h = `<iframe class="fv-pdf" src="${esc(rw('/api/fs/raw?path=' + enc(d.path) + '&_=' + Math.floor(d.mtime || 0)) + '#navpanes=0&view=FitH')}"></iframe>`; break;
      case 'doc': h = `<div class="fv-paper">${d.html || '<p class="fv-empty-note">המסמך ריק</p>'}</div>`; break;
      case 'markdown': h = P.view === 'source' ? codeHtml(d.text, 'markdown') : `<div class="md fv-md">${renderMarkdown(d.text)}</div>`; break;
      case 'html': h = P.view === 'source' ? codeHtml(d.text, 'html') : `<iframe class="fv-html" sandbox="" referrerpolicy="no-referrer"></iframe>`; break;
      case 'json': {
        let parsed, err = '';
        try { parsed = d.lines ? d.text.split('\n').filter(l => l.trim()).map(l => JSON.parse(l)) : JSON.parse(d.text.replace(/^﻿/, '')); } catch (e) { err = e.message; }
        if (err) h = `<div class="fv-note err">JSON לא תקין: ${esc(err)}</div>` + codeHtml(d.text, 'json');
        else if (P.view === 'raw' || d.text.length > 1500000) h = codeHtml(JSON.stringify(parsed, null, 2), 'json');
        else h = `<div class="fv-json" dir="ltr">${jsonTree(parsed, null, null, 0)}</div>`;
        break;
      }
      case 'table': h = tableHtml(d.rows, d.rows.length >= 2000 ? 'מוצגות 2,000 השורות הראשונות' : ''); break;
      case 'sheets': {
        const si = Math.min(P.sheet || 0, d.sheets.length - 1);
        h = `<div class="fv-tabs">${d.sheets.map((s, i) => `<button class="fv-tab${i === si ? ' on' : ''}" data-sheet="${i}">${esc(s.name)}</button>`).join('')}</div>` + (d.sheets.length ? tableHtml(d.sheets[si].rows, d.sheets[si].truncated ? 'הגיליון גדול — מוצג חלק ממנו' : '', d.sheets[si].rtl) : '<div class="fv-empty-note">אין גיליונות</div>');
        break;
      }
      case 'slides': h = `<div class="fv-slides">${d.slides.map(s => `<div class="fv-slide"><div class="fv-sn">שקף ${s.n}</div>${s.title ? `<h3 dir="auto">${esc(s.title)}</h3>` : ''}${s.lines.length ? `<ul>${s.lines.map(l => `<li dir="auto">${esc(l).replace(/\n/g, '<br>')}</li>`).join('')}</ul>` : ''}${(s.images || []).map(u => `<img src="${u}" alt="">`).join('')}${s.notes ? `<div class="fv-notes">📝 ${esc(s.notes)}</div>` : ''}</div>`).join('') || '<div class="fv-empty-note">אין שקפים</div>'}</div>`; break;
      case 'archive': h = `<div class="fv-note">${esc(d.note || '')} ${d.entries.length} פריטים${d.total > d.entries.length ? ' (מוצגים ' + d.entries.length + ')' : ''}</div><div class="fv-tablewrap"><table class="fv-grid fv-arch"><thead><tr><th>שם</th><th>גודל</th><th>תאריך</th></tr></thead><tbody>${d.entries.map(e => `<tr><td dir="ltr">${e.dir ? '📁 ' : ''}${esc(e.name)}</td><td>${e.dir ? '' : fmtSize(e.size)}</td><td>${esc(fmtDate(e.date))}</td></tr>`).join('')}</tbody></table></div>`; break;
      case 'binary': h = `<div class="fv-note">${esc(d.note || 'קובץ בינארי — אין לו תצוגה כטקסט.')} ${remote() ? '' : 'אפשר ↗ לפתוח אותו באפליקציה של המחשב.'}</div>${d.hex ? `<pre class="fv-hex" dir="ltr">${esc(d.hex)}</pre>` : ''}`; break;
      default: h = codeHtml(d.text || '', d.lang);
    }
    box.innerHTML = note + h;
    if (d.kind === 'html' && P.view !== 'source') box.querySelector('.fv-html').srcdoc = d.text;
    box.querySelectorAll('.fv-tab').forEach(b => (b.onclick = () => { P.sheet = +b.dataset.sheet; renderFile(P, d); }));
    box.style.zoom = d.kind === 'pdf' ? 1 : P.dz;
    P.root.querySelectorAll('.mp-zout,.mp-zin,.mp-zoom,.mp-fit,.mp-one').forEach(b => (b.hidden = d.kind === 'pdf'));
    info();
  }
  async function showFile(path) {
    const P = openPanel(path, 'file');
    P.root.querySelector('.mp-ic').textContent = '📄';
    const box = App.el('div', 'mp-doc'); P.stage.appendChild(box);
    showMsg('טוען…'); info();
    let d; try { d = await App.api('/api/fs/preview?path=' + enc(path)); } catch (e) { if (P.path === path) showMsg('לא הצלחתי לפתוח את הקובץ:\n' + e.message); return; }
    if (P.path !== path) return;
    showMsg(''); P.data = d; P.st = { size: d.size, mtime: d.mtime };
    if (d.kind === 'media') return show(path);
    if (d.kind === 'dir') { close(); return open(path); }
    P.root.dataset.fkind = d.kind; P.root.querySelector('.mp-ic').textContent = FILE_IC[d.kind] || '📄';
    renderFile(P, d);
    P.hot = true; setTimeout(() => { try { P.stage.focus({ preventScroll: true }); } catch { } }, 0);
  }

  async function show(rawPath) {
    const { path } = clean(rawPath); const kind = kindOf(path);
    if (!kind) return showFile(path);
    const P = openPanel(path, kind);
    P.root.querySelector('.mp-ic').textContent = kind === 'video' ? '🎬' : kind === 'audio' ? '🎵' : '🖼';
    P.root.querySelectorAll('.mp-zout,.mp-zin,.mp-zoom,.mp-fit,.mp-one').forEach(b => (b.hidden = kind === 'audio'));
    showMsg('טוען…'); info();
    const st = await statOf(path); if (P.path !== path) return;
    P.st = st;
    if (!st.exists) { showMsg('הקובץ לא קיים' + (remote() ? ' במחשב הזה' : '') + ':\n' + path); info(); return; }
    const src = rw('/api/fs/raw?path=' + enc(st.path || path) + '&_=' + Math.floor(st.mtime || 0));
    let m;
    if (kind === 'image') {
      m = new Image(); m.alt = App.baseName(path); m.draggable = false; m.className = 'mp-media';
      m.onload = () => { if (P.media !== m) return; P.nw = m.naturalWidth || 300; P.nh = m.naturalHeight || 150; showMsg(''); fit(); };
      m.onerror = () => { if (P.media === m) showMsg('לא הצלחתי להציג את התמונה:\n' + path); };
    } else {
      m = document.createElement(kind === 'video' ? 'video' : 'audio'); m.className = 'mp-media'; m.preload = 'metadata'; m.playsInline = true;
      if (kind === 'audio') m.controls = true;
      m.onloadedmetadata = () => { if (P.media !== m) return; showMsg(''); if (kind === 'video') { P.nw = m.videoWidth || 640; P.nh = m.videoHeight || 360; fit(); } paintVctl(); info(); };
      m.onerror = () => { if (P.media !== m) return; showMsg((kind === 'video' ? 'הדפדפן לא מצליח לנגן את הסרטון הזה (פורמט / קידוד שלא נתמך).' : 'לא הצלחתי לנגן את הקובץ.') + (remote() ? '' : '\nאפשר ↗ לפתוח אותו בנגן של המחשב.') + '\n' + path); };
      for (const ev of ['play', 'pause', 'timeupdate', 'durationchange', 'volumechange', 'ended', 'ratechange']) m.addEventListener(ev, paintVctl);
      if (kind === 'video') { const big = App.el('button', 'mp-bigplay', '▶'); big.title = 'נגן'; big.onclick = e => { e.stopPropagation(); togglePlay(); }; P.stage.appendChild(big); }
    }
    P.media = m; m.src = src;
    P.stage.prepend(m);
    P.root.querySelector('.mp-rate').value = '1';
    P.hot = true; setTimeout(() => { try { P.stage.focus({ preventScroll: true }); } catch { } }, 0);
  }
  function close() {
    if (!V) return;
    if (V.media) { try { V.media.pause && V.media.pause(); V.media.removeAttribute('src'); V.media.load && V.media.load(); } catch { } V.media.remove(); V.media = null; }
    V.root.hidden = true; V.sp.hidden = true; V.path = ''; V.kind = ''; V.hot = false;
  }
  function state() {
    if (!V || V.root.hidden) return { open: false };
    const r = V.root.getBoundingClientRect(), ws = document.getElementById('workspace').getBoundingClientRect(), m = V.media;
    return {
      open: true, path: V.path, kind: V.kind, scale: +V.s.toFixed(4), fitMode: V.fitMode, tx: Math.round(V.tx), ty: Math.round(V.ty), natural: [V.nw, V.nh],
      width: Math.round(r.width), workspaceWidth: Math.round(ws.width), msg: V.msg.hidden ? '' : V.msg.textContent,
      media: m ? { src: m.getAttribute('src'), paused: m.paused, currentTime: m.currentTime, duration: m.duration, muted: m.muted, readyState: m.readyState, rate: m.playbackRate, complete: m.complete } : null,
      info: V.root.querySelector('.mp-info').textContent
    };
  }

  // ===================== כרטיס נתיב בצ'אט (.path-card): פתיחה במחשב · 📋 העתקה · 👁 הצצה (ריחוף / לחיצה) =====================
  const PEEK_TTL = 8000, THUMB_MAX = 25 * 1048576, peekCache = new Map();
  async function peekOf(p) {
    const c = peekCache.get(p); if (c && Date.now() - c.t < PEEK_TTL) return c.v;
    const v = App.api('/api/fs/peek?path=' + enc(p)).catch(e => ({ path: p, exists: false, error: e.message }));
    peekCache.set(p, { t: Date.now(), v }); if (peekCache.size > 300) peekCache.delete(peekCache.keys().next().value);
    return v;
  }
  // נתיב עם רווח שאולי לא שלו (data-alt): בודקים במחשב מה קיים; אם רק הקצר — הכרטיס מתקצר והשאר חוזר להיות טקסט
  async function cardPath(card) {
    if (card.dataset.resolved) return { path: card.dataset.path, st: await peekOf(card.dataset.path) };
    const p = card.dataset.path, alt = card.dataset.alt;
    let st = await peekOf(p);
    if ((!st || !st.exists) && alt && p.startsWith(alt)) {
      const s2 = await peekOf(alt);
      if (s2 && s2.exists) {
        st = s2; const link = card.querySelector('.pc-link');
        card.dataset.path = alt; link.dataset.path = alt; link.textContent = alt; link.title = alt;
        if (window.renderMarkdown && renderMarkdown.pathKind) card.dataset.kind = renderMarkdown.pathKind(alt);
        card.after(document.createTextNode(p.slice(alt.length)));
      }
    }
    delete card.dataset.alt; card.dataset.resolved = '1';
    if (st) card.classList.toggle('missing', !st.exists);
    return { path: card.dataset.path, st };
  }
  async function openCard(card) {
    const { path, st } = await cardPath(card);
    if (!st || !st.exists) { App.toast('הנתיב לא קיים ' + (remote() ? 'במחשב הזה' : 'במחשב') + ': ' + path, 4500); return; }
    if (remote()) return st.dir ? open(path) : show(path); // מחשב מרוחק: החלון שלו לא מול העיניים — מציגים כאן
    if (await osCall('open', st.path || path)) App.toast((st.dir ? '📂 התיקייה נפתחה: ' : '↗ נפתח במחשב: ') + App.baseName(st.path || path), 2200);
  }
  function copyCard(card, btn) {
    const p = card.dataset.path;
    copy(p);
    if (btn) { btn.classList.add('done'); setTimeout(() => btn.classList.remove('done'), 1200); }
  }

  let POP = null, popCard = null, noHover = null, hoverT = 0, hideT = 0, popSeq = 0;
  function popEl() {
    if (POP) return POP;
    POP = App.el('div', 'pc-pop'); POP.hidden = true; POP.setAttribute('role', 'dialog'); POP.dir = 'rtl';
    document.body.appendChild(POP);
    POP.addEventListener('pointerenter', () => clearTimeout(hideT));
    POP.addEventListener('pointerleave', () => { if (!POP.classList.contains('pinned')) hideT = setTimeout(hidePop, 260); });
    POP.addEventListener('click', e => {
      const b = e.target.closest('[data-act]'); if (!b || !popCard) return;
      e.preventDefault(); e.stopPropagation();
      const card = popCard, act = b.dataset.act;
      if (act === 'open') openCard(card);
      else if (act === 'show') { hidePop(); const p = card.dataset.path; card.dataset.kind === 'dir' ? open(p) : show(p); }
      else if (act === 'copy') copyCard(card, b);
      else if (act === 'close') hidePop();
      else if (act === 'entry') { const p = b.dataset.p; if (p) { hidePop(); open(p); } }
    });
    return POP;
  }
  function hidePop() { clearTimeout(hoverT); clearTimeout(hideT); popSeq++; if (POP) { POP.hidden = true; POP.classList.remove('pinned'); POP.innerHTML = ''; } if (popCard) popCard.classList.remove('peeking'); popCard = null; }
  function placePop(card) {
    if (!POP || POP.hidden) return;
    const r = card.getBoundingClientRect(), vw = innerWidth, vh = innerHeight, pw = POP.offsetWidth, ph = POP.offsetHeight;
    let top = r.bottom + 6; if (top + ph > vh - 8 && r.top - ph - 6 > 8) top = r.top - ph - 6;
    const left = Math.max(8, Math.min(vw - pw - 8, r.left));
    POP.style.top = Math.max(8, top) + 'px'; POP.style.left = left + 'px';
  }
  const joinP = (dir, name) => dir.replace(/[\\/]+$/, '') + (/^[A-Za-z]:|\\/.test(dir) ? '\\' : '/') + name;
  function popBody(path, st) {
    const name = App.baseName(path) || path;
    if (!st || !st.exists) return `<div class="pcp-head"><span class="pcp-ic">⚠️</span><span class="pcp-name" dir="ltr">${esc(name)}</span></div><div class="pcp-msg">${st && st.blocked ? 'נתיב רשת — אין הצצה (אפשר לפתוח במחשב)' : 'הנתיב לא קיים ' + (remote() ? 'במחשב הזה' : 'במחשב')}</div>`;
    let h = '', meta = '';
    if (st.dir) {
      meta = st.total === 1 ? 'פריט אחד' : (st.total || 0) + ' פריטים';
      h = (st.entries || []).length ? `<ul class="pcp-list" dir="ltr">${st.entries.map(e => `<li><button type="button" data-act="entry" data-p="${esc(joinP(st.path || path, e.name))}" title="${esc(e.name)}">${e.dir ? '📁' : '📄'} ${esc(e.name)}</button></li>`).join('')}</ul>` + (st.total > st.entries.length ? `<div class="pcp-more">… ועוד ${st.total - st.entries.length}</div>` : '') : '<div class="pcp-msg">התיקייה ריקה</div>';
      if (st.error) h = `<div class="pcp-msg">אין גישה לתיקייה (${esc(st.error)})</div>`;
    } else {
      meta = fmtSize(st.size);
      if (st.kind === 'image') h = st.size <= THUMB_MAX ? `<div class="pcp-thumb"><img alt="" draggable="false" src="${esc(rw('/api/fs/raw?path=' + enc(st.path || path) + '&_=' + Math.floor(st.mtime || 0)))}"></div>` : '<div class="pcp-msg">תמונה גדולה מדי לתצוגה מקדימה</div>';
      else if (st.kind === 'text') h = (st.lines || []).length && st.lines.some(l => l) ? `<pre class="pcp-text" dir="ltr">${esc(st.lines.join('\n'))}${st.more ? '\n…' : ''}</pre>` : '<div class="pcp-msg">הקובץ ריק</div>';
      else h = `<div class="pcp-msg">${st.kind === 'doc' ? 'מסמך — אפשר להציג אותו כאן באפליקציה' : 'קובץ בינארי — אין תצוגה כטקסט'}</div>`;
    }
    if (st.mtime) meta += ' · ' + App.fmt.fullDateTime(st.mtime);
    const ic = st.dir ? '📁' : st.kind === 'image' ? '🖼' : st.kind === 'doc' ? '📑' : '📄';
    return `<div class="pcp-head"><span class="pcp-ic">${ic}</span><span class="pcp-name" dir="ltr" title="${esc(st.path || path)}">${esc(name)}</span><span class="pcp-meta">${esc(meta)}</span></div>${h}` +
      `<div class="pcp-foot"><button type="button" data-act="open">${st.dir ? '📂 פתח במחשב' : '↗ פתח במחשב'}</button><button type="button" data-act="show">👁 ${st.dir ? 'בעץ הקבצים' : 'הצג באפליקציה'}</button><button type="button" data-act="copy">📋 העתק נתיב</button></div>`;
  }
  async function showPop(card, pinned) {
    clearTimeout(hideT); clearTimeout(hoverT); // הצצה נעוצה מבטלת הצצת-ריחוף ממתינה (שהייתה מחליפה אותה ללא-נעוצה)
    const P = popEl();
    if (popCard && popCard !== card) popCard.classList.remove('peeking');
    popCard = card; card.classList.add('peeking'); P.classList.toggle('pinned', !!pinned);
    const seq = ++popSeq;
    P.innerHTML = `<div class="pcp-msg">טוען…</div>`; P.hidden = false; placePop(card);
    const { path, st } = await cardPath(card);
    if (seq !== popSeq) return;
    P.dataset.path = path; P.dataset.kind = st && st.exists ? (st.dir ? 'dir' : st.kind) : 'missing';
    P.innerHTML = popBody(path, st) + (pinned ? '<button type="button" class="pcp-x" data-act="close" title="סגור (Esc)" aria-label="סגור">✕</button>' : '');
    placePop(card);
    const img = P.querySelector('.pcp-thumb img'); if (img) img.onload = () => placePop(card);
  }
  // לחיצות בכרטיס: 👁 / 📋 / הקישור (נפתח במחשב; Ctrl — בתוך האפליקציה)
  document.addEventListener('click', e => {
    const card = e.target.closest && e.target.closest('.path-card'); if (!card || e.button !== 0) return;
    e.preventDefault(); e.stopPropagation();
    if (e.target.closest('.pc-copy')) return copyCard(card, e.target.closest('.pc-copy'));
    if (e.target.closest('.pc-eye')) return (popCard === card && POP && !POP.hidden && POP.classList.contains('pinned')) ? hidePop() : showPop(card, true);
    clearTimeout(hoverT); noHover = card; // לחיצה = כוונה לפתוח, לא להציץ: בלי הצצת-ריחוף עד שהעכבר יוצא מהכרטיס
    if (POP && !POP.hidden && !POP.classList.contains('pinned')) hidePop();
    if (e.ctrlKey || e.metaKey) return cardPath(card).then(r => inApp(r.path));
    openCard(card);
  }, true);
  // ריחוף: הצצה אחרי חצי שנייה (לא בטלפון / מגע)
  document.addEventListener('pointerover', e => {
    if (e.pointerType === 'touch') return;
    const card = e.target.closest && e.target.closest('.path-card'); if (!card || card === noHover) return;
    clearTimeout(hideT);
    if (popCard === card && POP && !POP.hidden) return;
    if (POP && POP.classList.contains('pinned') && !POP.hidden) return;
    clearTimeout(hoverT); hoverT = setTimeout(() => showPop(card, false), 500);
  });
  document.addEventListener('pointerout', e => {
    const card = e.target.closest && e.target.closest('.path-card'); if (!card || card.contains(e.relatedTarget)) return;
    if (noHover === card) noHover = null;
    clearTimeout(hoverT);
    if (POP && !POP.hidden && !POP.classList.contains('pinned') && popCard === card) hideT = setTimeout(hidePop, 260);
  });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && POP && !POP.hidden) { e.stopPropagation(); hidePop(); } }, true);
  document.addEventListener('pointerdown', e => { if (POP && !POP.hidden && !(e.target.closest && (e.target.closest('.pc-pop') || e.target.closest('.path-card')))) hidePop(); }, true);
  window.addEventListener('scroll', e => { if (POP && !POP.hidden && !(e.target.closest && e.target.closest('.pc-pop'))) { if (POP.classList.contains('pinned') && popCard && popCard.isConnected) placePop(popCard); else hidePop(); } }, true);
  window.addEventListener('resize', () => { if (POP && !POP.hidden && popCard) placePop(popCard); });

  App.paths = { open, show, close, mark, linkifyPre, resolve, kindOf, state, peek: showPop, hidePeek: hidePop, cardPath, _zoom: (f, x, y) => zoomBy(f, x, y), _fit: () => fit() };
})();
