// ============================================================
//  watches.js — מערכת המעקבים בממשק:
//   • חלונית "מעקב" מכפתור בתיבת הכתיבה (כל כמה זמן · למשך כמה זמן / ללא הגבלה · עצירה לפי המנוי · שם)
//   • חלון "מעקב" בתוך הצ'אט (מעל ההודעות): מצב, ספירה לאחור, סבבים ותוצאות, עצור / השהה / הפעל עכשיו
//   • מונה ליד הכפתור (מעקבים פתוחים בשיחה) — לחיצה מביאה לחלון המעקב
//   • אזור "מעקבים" בחלונית הצד: כל המעקבים מכל השיחות, מעבר לשיחה ושליטה
//  עדכונים חיים מהשרת: אירועי watch_update / watch_removed (דרך /api/events ב-projects.js)
// ============================================================
(function () {
  const App = window.App, $ = App.$, el = App.el, esc = App.esc;
  const S = { list: new Map(), loaded: false, open: new Set(), runs: new Map(), lastPop: null };
  const ls = { get: k => { try { return localStorage.getItem(k); } catch { return null; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch { } } };
  const isActive = w => w.status === 'active' || w.status === 'paused';
  const unitMin = { m: 1, h: 60, d: 1440 };
  const every = m => m % 1440 === 0 ? (m / 1440 === 1 ? 'כל יום' : `כל ${m / 1440} ימים`) : m % 60 === 0 ? (m / 60 === 1 ? 'כל שעה' : `כל ${m / 60} שע'`) : (m === 1 ? 'כל דקה' : `כל ${m} דק'`);
  const dur = m => m == null ? 'ללא הגבלה' : m % 1440 === 0 ? `${m / 1440} ימים` : m % 60 === 0 ? `${m / 60} שע'` : `${m} דק'`;
  const clk = ms => { const s = Math.max(0, Math.round(ms / 1000)); const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60), x = s % 60; const p = n => String(n).padStart(2, '0'); return d ? `${d}י' ${h}:${p(m)}` : h ? `${h}:${p(m)}:${p(x)}` : `${p(m)}:${p(x)}`; };
  // שני סטטוסים בלבד: ✅ תקין / ❌ לא תקין (warn). error/nostatus/interrupted — רק בסבבים ישנים, מלפני חוק הסטטוס
  const stIcon = s => ({ ok: '✅', warn: '❌', error: '❌', running: '⏳', interrupted: '⏸', skipped: '⏭', nostatus: '❔' }[s] || '•');
  const runText = r => r.status === 'running' ? '' : (r.summary || '') + (r.problem ? ' — ' + r.problem : '');
  const statusLbl = w => ({ active: 'פעיל', paused: 'מושהה', stopped: 'נעצר', done: 'הסתיים', usage: 'נעצר (מנוי)' }[w.status] || w.status);
  const describe = o => `${every(o.everyMin)} · ${o.durationMin == null ? 'ללא הגבלה' : 'למשך ' + dur(o.durationMin)}${o.stopAtRemainingPct != null ? ` · עצירה ב-${o.stopAtRemainingPct}% מנוי` : ''}`;
  const chatTitle = convId => { try { const c = App.chats.byConvId(convId); if (c) return (c.title || '') + (c.code ? ' · ' + c.code : ''); } catch { } const x = S.convs && S.convs.get(convId); return x ? (x.title || '') + (x.code ? ' · ' + x.code : '') : 'שיחה'; };

  // ---------- נתונים ----------
  async function load() {
    const first = !S.loaded;
    try { const r = await App.api('/api/watches'); S.list = new Map((r.watches || []).map(w => [w.id, w])); S.loaded = true; }
    catch { }
    // בטעינה הראשונה: שיחות שיש בהן מעקב "רק בחלון המעקב" נטענות מחדש בלי הסבבים
    if (first) for (const convId of new Set([...S.list.values()].filter(w => w.actionsInDock).map(w => w.convId))) App.emit('watch:dockmode', { convId });
    try { const c = await App.api('/api/conversations'); S.convs = new Map((c.conversations || []).map(x => [x.id, x])); } catch { }
    paintAll();
  }
  function upsert(w) { if (!w || !w.id) return; S.list.set(w.id, { ...(S.list.get(w.id) || {}), ...w }); if (S.runs.has(w.id) && S.open.has(w.id)) fetchRuns(w.id); paintAll(); }
  async function fetchRuns(id) { try { const r = await App.api('/api/watches/' + id); S.runs.set(id, r.watch.runs || []); S.list.set(id, { ...(S.list.get(id) || {}), ...r.watch, runs: undefined }); paintAll(); } catch { } }
  async function act(id, what) {
    try { const r = await App.api('/api/watches/' + id + '/' + what, { method: 'POST', body: {} }); upsert(r.watch); App.toast({ stop: '⏹ המעקב נעצר', pause: '⏸ המעקב הושהה', resume: '▶ המעקב חזר לפעול — סבב עכשיו', run: '⟳ סבב מתחיל עכשיו' }[what] || 'בוצע', 2200); }
    catch (e) { App.toast('❌ ' + e.message, 4000); }
  }
  async function remove(id) { try { await App.api('/api/watches/' + id, { method: 'DELETE' }); S.list.delete(id); paintAll(); } catch (e) { App.toast('❌ ' + e.message); } }
  const forConv = convId => [...S.list.values()].filter(w => w.convId === convId);

  // ---------- חלונית יצירה (מכפתור "מעקב" בתיבת הכתיבה) ----------
  function buildPop(pane, pop) {
    const saved = (() => { try { return JSON.parse(ls.get('watch.last') || 'null'); } catch { return null; } })() || { ev: 5, evU: 'm', du: 1, duU: 'h', unl: false, pct: '', dock: false };
    pop.innerHTML = `
      <div class="rl-head"><span>⏱ מעקב חדש</span><small>Claude יתעורר לבד ויבצע את המשימה</small></div>
      <div class="wp-form">
        <label class="wp-row"><span>כל</span><input type="number" min="1" step="1" class="text-input wp-ev"><select class="wp-evu"><option value="m">דקות</option><option value="h">שעות</option><option value="d">ימים</option></select></label>
        <label class="wp-row"><span>למשך</span><input type="number" min="1" step="1" class="text-input wp-du"><select class="wp-duu"><option value="m">דקות</option><option value="h">שעות</option><option value="d">ימים</option></select></label>
        <label class="wp-check"><input type="checkbox" class="wp-unl"> ללא הגבלת זמן (עד שאעצור)</label>
        <div class="wp-row wp-pctrow"><span>עצור כשנשאר</span><div class="rs-chips wp-pcts">${['', 50, 40, 25].map(v => `<button type="button" class="rs-chip" data-p="${v}">${v === '' ? 'לא' : v + '%'}</button>`).join('')}</div><input type="number" min="1" max="99" class="text-input wp-pct" placeholder="%"><small class="ag-dim">מהמנוי (שבועי)</small></div>
        <label class="wp-row"><span>שם</span><input type="text" maxlength="40" class="text-input wp-name" placeholder="אופציונלי — למשל: שומר על השרת"></label>
        <label class="wp-check wp-dockrow"><input type="checkbox" class="wp-dock"> רק בחלון המעקב — הסבבים רצים בנפרד ובמקביל, והצ'אט נשאר נקי</label>
        <label class="wp-check wp-fixrow"><input type="checkbox" class="wp-fix" checked> 🔧 מצב תיקון — כשמשהו לא תקין: Claude מתקן עד שהכל תקין (השעון עוצר), ורק אז דוח</label>
        <div class="wp-sum"></div>
        <div class="wp-err" hidden></div>
        <button type="button" class="btn-primary wp-go">⏱ הפעל — המשימה היא ההודעה שאכתוב</button>
      </div>`;
    const q = s => pop.querySelector(s);
    q('.wp-ev').value = saved.ev; q('.wp-evu').value = saved.evU; q('.wp-du').value = saved.du; q('.wp-duu').value = saved.duU; q('.wp-unl').checked = !!saved.unl; q('.wp-pct').value = saved.pct || ''; q('.wp-dock').checked = !!saved.dock;
    const read = () => {
      const ev = Math.round(Number(q('.wp-ev').value) * unitMin[q('.wp-evu').value]), unl = q('.wp-unl').checked;
      const du = unl ? null : Math.round(Number(q('.wp-du').value) * unitMin[q('.wp-duu').value]);
      const pv = q('.wp-pct').value.trim(), pct = pv === '' ? null : Math.round(Number(pv));
      return { everyMin: ev, durationMin: du, stopAtRemainingPct: pct, name: q('.wp-name').value.trim() || undefined, ...(q('.wp-dock').checked ? { actionsInDock: true } : {}), fixMode: !q('.wp-fix') || q('.wp-fix').checked };
    };
    const err = () => { const o = read(); if (!(o.everyMin >= 1)) return 'כל כמה זמן — לפחות דקה אחת'; if (o.durationMin != null && !(o.durationMin >= 1)) return 'משך — לפחות דקה אחת, או "ללא הגבלה"'; if (o.durationMin != null && o.durationMin < o.everyMin) return 'המשך קצר מהמרווח — יהיה רק סבב אחד'; if (o.stopAtRemainingPct != null && !(o.stopAtRemainingPct >= 1 && o.stopAtRemainingPct <= 99)) return 'אחוז המנוי: 1–99'; return ''; };
    const sync = () => {
      q('.wp-du').disabled = q('.wp-duu').disabled = q('.wp-unl').checked;
      const o = read(), e = err(); q('.wp-err').hidden = !e; q('.wp-err').textContent = e;
      q('.wp-sum').textContent = e ? '' : describe(o) + (o.durationMin != null ? ` · ${Math.ceil(o.durationMin / o.everyMin).toLocaleString('en-US')} סבבים` : ' · סבבים ללא הגבלה') + (o.actionsInDock ? ' · רק בחלון המעקב' : '');
      pop.querySelectorAll('.wp-pcts .rs-chip').forEach(c => c.classList.toggle('on', String(c.dataset.p) === String(q('.wp-pct').value.trim())));
    };
    pop.querySelectorAll('.wp-pcts .rs-chip').forEach(c => (c.onclick = () => { q('.wp-pct').value = c.dataset.p; sync(); }));
    pop.querySelectorAll('input,select').forEach(i => i.addEventListener('input', sync)); sync();
    q('.wp-go').onclick = () => {
      if (err()) { sync(); return; }
      const o = read(); ls.set('watch.last', JSON.stringify({ ev: q('.wp-ev').value, evU: q('.wp-evu').value, du: q('.wp-du').value, duU: q('.wp-duu').value, unl: q('.wp-unl').checked, pct: q('.wp-pct').value, dock: q('.wp-dock').checked }));
      pane.watchNext = o; pane.renderTags(); pop.hidden = true; pane.$input.focus();
    };
  }

  // ---------- חלון "מעקב" בתוך הצ'אט ----------
  // "רק בחלון המעקב": הטאב הראשון הוא "פעולות" — שם רואים חי מה Claude עושה בסבב
  const tabs = new Map(); const tabOf = id => tabs.get(id) || 'runs'; // ברירת מחדל: הסבבים עם הסיכום של כל סבב; "פעולות" = הפירוט צעד-צעד
  const acts = new Map(); // id -> rounds (מה Claude עשה בכל סבב)
  const openRounds = new Map(); // id -> Set(n) של סבבים שפתחת/סגרת ידנית בטאב "פעולות" (נשמר בין רענונים)
  const actsBusy = new Map();
  async function fetchActs(id) {
    if (actsBusy.get(id)) { actsBusy.set(id, 2); return; } actsBusy.set(id, 1);
    try { const r = await App.api('/api/watches/' + id + '?actions=1'); acts.set(id, r.rounds || []); paintAll(); } catch { }
    const again = actsBusy.get(id) === 2; actsBusy.delete(id); if (again) fetchActs(id);
  }
  function actsHtml(id) {
    const rounds = acts.get(id); if (!rounds) return '<div class="wd-runs-empty">טוען…</div>';
    if (!rounds.length) return '<div class="wd-runs-empty">עוד אין פעולות</div>';
    const w = S.list.get(id) || {}, op = openRounds.get(id);
    return rounds.map(r => {
      const live = r.status === 'running' && w.current === r.n;
      const open = op && op.has(r.n) ? op.get(r.n) : r === rounds[0];
      const pend = r.pending ? (r.pending.ask
        ? `<div class="wa-pend" data-req="${esc(r.pending.requestId)}"><b>❓ Claude שואל:</b> ${esc((r.pending.questions || []).map(q => q.q).join(' · '))}<div class="wa-pend-acts">${(r.pending.questions || []).length === 1 ? (r.pending.questions[0].opts || []).map(o => `<button class="btn-ghost" data-ans="${esc(r.pending.requestId)}" data-q="${esc(r.pending.questions[0].q)}" data-a="${esc(o)}">${esc(o)}</button>`).join('') : ''}<button class="btn-ghost" data-skip="${esc(r.pending.requestId)}">דלג</button></div></div>`
        : `<div class="wa-pend" data-req="${esc(r.pending.requestId)}"><b>⏸ Claude מבקש אישור:</b> ${esc(r.pending.name)} <code>${esc(r.pending.arg || '')}</code><div class="wa-pend-acts"><button class="btn-primary" data-approve="${esc(r.pending.requestId)}">✓ אשר</button><button class="btn-ghost" data-deny="${esc(r.pending.requestId)}">✗ דחה</button></div></div>`) : '';
      return `<details class="wa-round${live ? ' live' : ''}${r.where === 'dock' ? ' dock' : ''}" data-round="${r.n}" ${open ? 'open' : ''}><summary><span class="wd-ic">${stIcon(r.status || 'running')}</span><b>סבב ${r.n}</b><time>${App.fmt.time ? App.fmt.time(r.at) : ''}</time><small>${r.status && r.status !== 'running' ? (r.status === 'ok' ? 'תקין' : 'לא תקין') + ' · ' : ''}${r.items.filter(i => i.t === 'tool').length} פעולות${r.where === 'dock' ? ' · בחלון המעקב' : ''}</small>${live ? `<span class="wa-live">⏳ רץ עכשיו${r.where === 'dock' ? ' — במקביל לצ\'אט' : ''}</span>${r.where === 'dock' ? `<button class="wa-stop" data-stopround="${esc(id)}" title="עצור את הסבב הזה">⏹</button>` : ''}` : ''}</summary>
      <div class="wa-items">${r.items.map(i => i.t === 'tool' ? `<div class="wa-tool ${i.ok === false ? 'err' : ''}"><span>${i.ok === false ? '❌' : i.ok ? '✓' : '⏳'}</span><b>${esc(i.name)}</b><code>${esc(i.arg)}</code></div>` : `<div class="wa-text">${esc(i.s)}</div>`).join('')}${pend}${live && !r.items.length && !pend ? '<div class="wa-text wa-wait">Claude מתחיל את הסבב…</div>' : ''}${r.problem ? `<div class="wa-problem">${r.forced ? '⚖️ ' : '❌ '}${esc(r.problem)}</div>` : ''}</div></details>`;
    }).join('');
  }
  // עריכת מעקב פעיל — בלי לעצור אותו; הסבב הבא כבר לפי ההגדרות החדשות
  function editWatch(w) {
    const body = el('div', 'we-form');
    const split = m => m % 1440 === 0 ? [m / 1440, 'd'] : m % 60 === 0 ? [m / 60, 'h'] : [m, 'm'];
    const [ev, evU] = split(w.everyMin), remain = w.endsAt ? Math.max(1, Math.round((w.endsAt - Date.now()) / 60000)) : 60, [du, duU] = split(remain);
    body.innerHTML = `
      <label class="wp-row"><span>שם</span><input type="text" maxlength="40" class="text-input we-name"></label>
      <label class="wp-col"><span>משימה</span><textarea class="text-input we-prompt" rows="5"></textarea></label>
      <label class="wp-row"><span>כל</span><input type="number" min="1" class="text-input we-ev"><select class="we-evu"><option value="m">דקות</option><option value="h">שעות</option><option value="d">ימים</option></select></label>
      <label class="wp-row"><span>עוד</span><input type="number" min="1" class="text-input we-du"><select class="we-duu"><option value="m">דקות</option><option value="h">שעות</option><option value="d">ימים</option></select></label>
      <label class="wp-check"><input type="checkbox" class="we-unl"> ללא הגבלת זמן</label>
      <div class="wp-row"><span>עצור כשנשאר</span><div class="rs-chips we-pcts">${['', 50, 40, 25].map(v => `<button type="button" class="rs-chip" data-p="${v}">${v === '' ? 'לא' : v + '%'}</button>`).join('')}</div><input type="number" min="1" max="99" class="text-input we-pct" placeholder="%"></div>
      <div class="wp-err" hidden></div>
      <div class="confirm-bar"><button class="btn-ghost we-cancel">ביטול</button><button class="btn-primary we-save">שמור</button></div>`;
    const m = App.modal({ title: '✏️ ' + w.id + ' «' + w.name + '»', body, cls: 'we-modal' });
    const q = s => body.querySelector(s);
    q('.we-name').value = w.name; q('.we-prompt').value = w.prompt || ''; q('.we-ev').value = ev; q('.we-evu').value = evU; q('.we-du').value = du; q('.we-duu').value = duU; q('.we-unl').checked = w.durationMin == null; q('.we-pct').value = w.stopAtRemainingPct == null ? '' : w.stopAtRemainingPct;
    const sync = () => { q('.we-du').disabled = q('.we-duu').disabled = q('.we-unl').checked; body.querySelectorAll('.we-pcts .rs-chip').forEach(c => c.classList.toggle('on', String(c.dataset.p) === String(q('.we-pct').value.trim()))); };
    body.querySelectorAll('.we-pcts .rs-chip').forEach(c => (c.onclick = () => { q('.we-pct').value = c.dataset.p; sync(); }));
    body.querySelectorAll('input,select').forEach(i => i.addEventListener('input', sync)); sync();
    q('.we-cancel').onclick = () => m.close();
    q('.we-save').onclick = async () => {
      const everyMin = Math.round(Number(q('.we-ev').value) * unitMin[q('.we-evu').value]), unl = q('.we-unl').checked, durationMin = unl ? null : Math.round(Number(q('.we-du').value) * unitMin[q('.we-duu').value]);
      const pv = q('.we-pct').value.trim(), pct = pv === '' ? null : Math.round(Number(pv));
      const e = !(everyMin >= 1) ? 'כל כמה זמן — לפחות דקה' : (!unl && !(durationMin >= 1)) ? 'משך — לפחות דקה' : (pct != null && !(pct >= 1 && pct <= 99)) ? 'אחוז: 1–99' : !q('.we-prompt').value.trim() ? 'המשימה ריקה' : '';
      if (e) { q('.wp-err').hidden = false; q('.wp-err').textContent = e; return; }
      try {
        const r = await App.api('/api/watches/' + w.id, { method: 'PATCH', body: { name: q('.we-name').value.trim(), prompt: q('.we-prompt').value, everyMin, durationMin: unl ? null : durationMin, unlimited: unl, stopAtRemainingPct: pct } });
        upsert(r.watch); m.close(); App.toast('✏️ נשמר — המעקב ממשיך עם ההגדרות החדשות', 2600);
      } catch (er) { q('.wp-err').hidden = false; q('.wp-err').textContent = er.message; }
    };
  }
  async function setDockMode(id, on) {
    try {
      const r = await App.api('/api/watches/' + id, { method: 'PATCH', body: { actionsInDock: on } }); upsert(r.watch); App.emit('watch:dockmode', { id, on, convId: r.watch.convId });
      tabs.delete(id); if (on) fetchActs(id);
      App.toast(on ? '● רק בחלון המעקב — מהסבב הבא כל סבב רץ בנפרד, במקביל לצ\'אט, והצ\'אט נשאר נקי' : '○ גם בצ\'אט — מהסבב הבא הסבבים רצים שוב בתוך הצ\'אט', 3200);
    } catch (e) { App.toast('❌ ' + e.message); }
  }
  // 🔒 נעילה לשינויים: Claude לא יכול לעצור / להשהות / להפעיל / לערוך (רק אתה, מכאן)
  async function setLock(id, on) {
    try { const r = await App.api('/api/watches/' + id + '/' + (on ? 'lock' : 'unlock'), { method: 'POST', body: {} }); upsert(r.watch); App.toast(on ? '🔒 המעקב נעול — Claude לא יכול לעצור, להשהות או לערוך אותו' : '🔓 הנעילה בוטלה — Claude יכול שוב לשנות את המעקב כשתבקש', 2800); }
    catch (e) { App.toast('❌ ' + e.message); }
  }
  // ציור מחדש של החלון לא מקפיץ את הגלילה (רשימת הפעולות / הסבבים) בזמן שסבב רץ
  const saveScroll = root => [...root.querySelectorAll('.wd-acts-list, .wd-runs, .wd-prompt')].map(e => [e.closest('.wd-item') && e.closest('.wd-item').dataset.id, e.className, e.scrollTop]).concat([['__root', '', root.scrollTop]]);
  const restoreScroll = (root, keep) => { for (const [id, cls, top] of keep) { if (id === '__root') { root.scrollTop = top; continue; } const it = id && root.querySelector('.wd-item[data-id="' + id + '"]'); const e = it && it.querySelector('.' + String(cls).split(' ')[0]); if (e) e.scrollTop = top; } };
  const actsSig = id => { const r = acts.get(id); return r ? r.map(x => x.n + ':' + x.status + ':' + x.items.length + ':' + x.items.map(i => i.ok == null ? 'n' : i.ok ? 'y' : 'x').join('') + (x.pending ? ':p' + x.pending.requestId : '')).join('|') : '-'; };
  // טאב "סבבים": כל סבב = כרטיס עם הסטטוס (תקין / לא תקין) והסיכום המלא של Claude. האחרון שהסתיים פתוח; לחיצה פותחת/סוגרת (נשמר)
  const openRuns = new Map(); // id -> Map(n -> bool)
  // bad = השורות שהשער של השרת זיהה כתקלה (גם כש-Claude סימן אותן ✅ בטעות, למשל "✅ הדיסק — 97%, הבדיקה נכשלה") — באדום
  const nrm = s => String(s || '').replace(/\*\*/g, '').replace(/[‎‏⁦-⁩﻿]/g, '').trim();
  const reportHtml = (txt, bad) => { const B = new Set((bad || []).map(nrm)); return String(txt || '').split(/\r?\n/).filter(l => l.trim() && !/^(```|---+)$/.test(l.trim())).map(l => { const t = l.trim(); const cls = /^סטטוס: תקין$/.test(t) ? 'ok st' : /^סטטוס: לא תקין$/.test(t) ? 'bad st' : /❌|⚠|🔴|⛔|✖|✗|✘|🚫/.test(t) || B.has(nrm(t)) ? 'bad' : /✅|✔/.test(t) ? 'ok' : ''; return `<div class="wr-l ${cls}">${esc(t.replace(/\*\*/g, ''))}</div>`; }).join(''); };
  function runsHtml(id) {
    const runs = S.runs.get(id); if (!runs) return '<div class="wd-runs-empty">טוען סבבים…</div>';
    if (!runs.length) return '<div class="wd-runs-empty">עוד אין סבבים</div>';
    const w = S.list.get(id) || {}, op = openRuns.get(id), list = [...runs].reverse();
    const newestDone = (list.find(r => r.status !== 'running') || {}).n;
    return list.map(r => {
      const running = r.status === 'running';
      const open = op && op.has(r.n) ? op.get(r.n) : r.n === newestDone;
      const head = running ? (r.queued ? 'ממתין בתור — Claude עובד על משהו אחר' : r.shadow ? 'Claude עובד על הסבב — במקביל לצ\'אט…' : 'Claude עובד על הסבב…') : (r.status === 'ok' ? 'תקין' : 'לא תקין') + (r.problem ? ' — ' + r.problem : '');
      const jump = r.shadow || w.actionsInDock ? `<button class="wd-jump" data-acts="${esc(id)}-${r.n}" title="מה Claude עשה בסבב (פעולות)">⋯</button>` : `<button class="wd-jump" data-jump="${esc(id)}-${r.n}" title="להודעה של הסבב בצ'אט">↓</button>`;
      // 🔎 הבודק העצמאי (מודל נפרד שקרא רק את הפלטים של הסבב): אישר / לא אישר / לא היה זמין — שקיפות מלאה
      // בכל סבב (גם "לא תקין"): הבודק בודק את הסטטוס, כל סימון ✅/❌ וכל עובדה בדיווח. מה שנשאר במחלוקת — מוצג כאן במפורש
      const au = r.audit, me = (au && au.markErrors) || [], un = (au && au.unsupported) || [], agrees = !me.length && !un.length;
      const again = r.auditDemands ? ` · אחרי ${r.auditDemands} בדיקה חוזרת של Claude` : '';
      const MK = m => m === 'both' ? '✅ וגם ❌' : m === 'none' ? 'בלי סימון' : m;
      const disputes = me.map(x => `<div class="wr-disp">• ${esc(x.item)}: בדיווח ${esc(MK(x.mark))} — לפי הפלטים ${esc(x.should)}${x.evidence ? ` (${esc(x.evidence)})` : ''}</div>`).join('') + un.map(x => `<div class="wr-disp">• עובדה שלא נראתה בפלטים: «${esc(x.claim)}» — ${esc(x.why)}</div>`).join('');
      const audHtml = !au || au.verdict === 'off' ? ''
        : au.verdict === 'unavailable' ? `<div class="wr-audit na">🔎 הבודק העצמאי לא היה זמין — הסבב לפי Claude בלבד (${esc(au.reason || '')})</div>`
        : r.cause === 'audit' ? `<div class="wr-audit bad">🔎 הבודק העצמאי לא אישר "תקין": ${esc(au.reason || '')}${again}${disputes}</div>`
        : agrees ? `<div class="wr-audit ok" title="מודל נפרד (${esc(au.model || '')}) קרא רק את מה ש-Claude באמת הריץ וראה בסבב (${au.calls || 0} פעולות) — ואישר את הסטטוס, כל סימון ✅/❌ וכל עובדה בדיווח">🔎 אומת ע"י בודק עצמאי — ${r.status === 'ok' ? 'הכל תקין' : 'כל סימון ✅/❌ נכון'}, לפי ${au.calls || 0} הפלטים של הסבב${again}</div>`
        : `<div class="wr-audit bad">🔎 הבודק העצמאי חולק על הדיווח${again}:${disputes}</div>`;
      const body = !running && open && (r.report || r.reply) ? `<div class="wr-report">${audHtml}${reportHtml(r.report || r.reply, r.problemLines)}</div>` : '';
      return `<div class="wd-run ${esc(r.status)}${r.shadow ? ' dock' : ''}${open && !running ? ' open' : ''}" data-run="${esc(id)}-${r.n}"><span class="wd-ic">${stIcon(r.status)}</span><b>סבב ${r.n}</b><time>${App.fmt.time(r.at)}</time><span class="wd-sum">${esc(head)}</span>${jump}${body}</div>`;
    }).join('');
  }
  function rowHtml(w, inChat) {
    const open = S.open.has(w.id), act = isActive(w);
    const pend = (acts.get(w.id) || []).find(r => r.pending && r.status === 'running');
    const next = pend ? `<span class="wd-next run wd-pend" title="Claude מחכה לך בטאב פעולות">✋ ממתין לאישור שלך</span>` : w.fixing ? `<span class="wd-next run wd-fixing" title="מצב תיקון: השעון של המעקב עוצר עד שכל הפריטים תקינים">🔧 מתקן · ${w.fixing.bad} מתוך ${w.fixing.total} לא תקינים · ניסיון ${w.fixing.attempts || 1}</span>` : w.status === 'paused' && w.pausedRemainingMs != null ? `<span class="wd-next" title="מושהה — בהמשך יישאר לסבב הבא בדיוק הזמן הזה">⏸ נשארו ${clk(w.pausedRemainingMs)}</span>` : w.status === 'active' ? (w.current ? `<span class="wd-next run">⏳ סבב ${w.current} רץ</span>` : `<span class="wd-next" data-next="${w.nextRunAt || 0}">⏱ ${clk((w.nextRunAt || 0) - Date.now())}</span>`) : `<span class="wd-next">${esc(statusLbl(w))}</span>`;
    const last = w.last ? `<span class="wd-last ${esc(w.last.status)}" title="${esc(runText(w.last))}">${stIcon(w.last.status)}</span>` : '';
    const ends = w.endsAt ? `עד ${App.fmt.dateTime(w.endsAt)}` : (act ? 'ללא הגבלה' : '');
    return `<div class="wd-item ${esc(w.status)}${open ? ' open' : ''}" data-id="${esc(w.id)}">
      <div class="wd-row">
        <button class="wd-toggle" data-tog="${esc(w.id)}" title="סבבים ותוצאות">${open ? '▾' : '▸'}</button>
        <span class="wd-id">${esc(w.id)}</span>${w.locked ? `<span class="wd-lock" title="נעול לשינויים — Claude לא יכול לעצור, להשהות או לערוך אותו">🔒</span>` : ''}<b class="wd-name" title="${esc(w.prompt || '')}">${esc(w.name)}</b>${w.actionsInDock ? '<span class="wd-dock" title="הסבבים רצים בנפרד, במקביל לצ\'אט, ומוצגים רק כאן">רק כאן</span>' : ''}
        ${inChat ? '' : `<span class="wd-chat" title="השיחה">💬 ${esc(chatTitle(w.convId))}</span>`}
        <span class="wd-meta">${esc(every(w.everyMin))} · סבב ${w.runCount}${w.okCount || w.warnCount ? ` · ✅${w.okCount}${w.warnCount ? ' ❌' + w.warnCount : ''}` : ''}${ends ? ' · ' + esc(ends) : ''}</span>
        ${next}${last}
        <span class="wd-acts">
          ${inChat ? '' : `<button data-goto="${esc(w.id)}" title="פתח את השיחה">💬</button>`}
          ${act ? `<button data-lock="${esc(w.id)}" class="wd-lockbtn${w.locked ? ' on' : ''}" title="${w.locked ? 'נעול: Claude לא יכול לעצור / להשהות / לערוך את המעקב. לחיצה = ביטול הנעילה' : 'נעל לשינויים: Claude לא יוכל לעצור, להשהות או לערוך את המעקב (רק אתה)'}">${w.locked ? '🔒' : '🔓'}</button>` : ''}
          ${act ? `<button data-edit="${esc(w.id)}" title="עריכה">✏️</button>` : ''}
          ${w.status === 'active' ? `<button data-act="run" data-w="${esc(w.id)}" title="סבב עכשיו">⟳</button><button data-act="pause" data-w="${esc(w.id)}" title="השהה">⏸</button>` : ''}
          ${w.status === 'paused' ? `<button data-act="resume" data-w="${esc(w.id)}" title="המשך">▶</button>` : ''}
          ${act ? `<button data-act="stop" data-w="${esc(w.id)}" class="danger" title="עצור את המעקב">⏹</button>` : `<button data-del="${esc(w.id)}" title="הסר מהרשימה">🗑</button>`}
        </span>
      </div>
      ${open ? `<div class="wd-detail"><div class="wd-prompt"><small>המשימה:</small> ${esc(w.prompt || '')}</div>${w.endReason ? `<div class="wd-end">${esc(w.endReason)}</div>` : ''}
        ${w.locked ? `<div class="wd-locked">🔒 נעול לשינויים — Claude לא יכול לעצור, להשהות, להפעיל או לערוך את המעקב (לא בכלים, לא דרך ה-API ולא בקבצים). רק אתה.${(w.blocked || []).length ? `<div class="wd-blocked">${(w.blocked || []).slice(-3).reverse().map(b => `<span>⛔ ${App.fmt.time ? App.fmt.time(b.at) : ''} ${b.by === 'mesh' ? 'ניסיון מהרשת' : b.by === 'unknown' ? 'ניסיון ממקור שלא אומת' : 'Claude ניסה'}: ${esc(b.what)} — נחסם</span>`).join('')}</div>` : ''}</div>` : ''}
        <div class="wd-tabs"><button data-tab="${esc(w.id)}" data-t="runs" class="${tabOf(w.id) === 'runs' ? 'on' : ''}">סבבים</button><button data-tab="${esc(w.id)}" data-t="acts" class="${tabOf(w.id) === 'acts' ? 'on' : ''}">פעולות</button><button data-dockmode="${esc(w.id)}" class="wd-mode${w.actionsInDock ? ' on' : ''}" title="${w.actionsInDock ? 'רק כאן: כל סבב רץ בנפרד, במקביל לצ\'אט — שום דבר מהמעקב לא נכנס לצ\'אט. לחיצה = הסבבים חוזרים לצ\'אט' : 'גם בצ\'אט: הסבבים רצים בתוך הצ\'אט. לחיצה = הכל רק בחלון המעקב, והצ\'אט נשאר נקי'}">${w.actionsInDock ? '● רק כאן' : '○ גם בצ\'אט'}</button></div>
        ${tabOf(w.id) === 'acts' ? `<div class="wd-acts-list">${actsHtml(w.id)}</div>` : `<div class="wd-runs">${runsHtml(w.id)}</div>`}</div>` : ''}
    </div>`;
  }
  function paintPane(pane) {
    if (!pane || !pane.pane) return;
    const dock = pane.pane.querySelector('.watch-dock'), cnt = pane.pane.querySelector('.cb-wcount');
    const mine = pane.id ? forConv(pane.id) : [], act = mine.filter(isActive);
    if (cnt) { cnt.hidden = !act.length; const n = cnt.querySelector('.wc-n'); if (n) n.textContent = act.length; cnt.classList.toggle('paused', act.length > 0 && act.every(w => w.status === 'paused')); cnt.title = act.length ? `${act.length} מעקבים פתוחים בשיחה הזו: ${act.map(w => w.id + ' «' + w.name + '»').join(', ')} — לחיצה: חלון המעקב` : ''; }
    if (!dock) return;
    const recent = mine.filter(w => !isActive(w) && w.endedAt && Date.now() - w.endedAt < 30 * 60000);
    const show = [...act, ...recent];
    if (!show.length) { dock.hidden = true; dock.innerHTML = ''; return; }
    const collapsed = ls.get('watch.dock.' + pane.id) === '0';
    const sig = JSON.stringify([show.map(w => [w.id, w.status, w.runCount, w.current, w.last && w.last.n, w.last && w.last.status, S.open.has(w.id), (S.runs.get(w.id) || []).length, (S.runs.get(w.id) || []).map(r => r.status).join(''), w.actionsInDock, w.name, w.everyMin, w.editedAt, tabOf(w.id), actsSig(w.id), JSON.stringify([...(openRuns.get(w.id) || new Map())]), (S.runs.get(w.id) || []).map(r => r.n + (r.report ? 'r' : '') + (r.audit ? r.audit.verdict + ((r.audit.markErrors || []).length) + '/' + ((r.audit.unsupported || []).length) + '/' + (r.audit.checks || 0) : '')).join(','), w.locked, (w.blocked || []).map(b => b.at).join(','), w.last && w.last.problem]), collapsed]);
    if (dock._sig === sig) { tickClocks(dock); return; }
    dock._sig = sig; dock.hidden = false;
    const keep = saveScroll(dock);
    dock.innerHTML = `<div class="wd-head"><button class="wd-fold" title="${collapsed ? 'הצג' : 'מזער'}">${collapsed ? '▸' : '▾'}</button><span class="wd-title">⏱ מעקב</span><small>${act.length ? act.length + ' פעילים' : 'הסתיימו'} — Claude מתעורר לבד ומבצע את המשימה; אפשר להמשיך לדבר איתו כרגיל</small></div>${collapsed ? '' : `<div class="wd-list">${show.map(w => rowHtml(w, true)).join('')}</div>`}`;
    restoreScroll(dock, keep);
    dock.querySelector('.wd-fold').onclick = () => { ls.set('watch.dock.' + pane.id, collapsed ? '1' : '0'); dock._sig = ''; paintPane(pane); };
  }
  // לחיצה על המונה / על תג סבב בצ'אט: פותח את חלון המעקב ומדגיש
  function focusDock(pane, id) {
    if (!pane || !pane.id) return;
    ls.set('watch.dock.' + pane.id, '1');
    const mine = forConv(pane.id); const target = id || (mine.find(isActive) || mine[0] || {}).id;
    if (target) { S.open.add(target); fetchRuns(target); if (tabOf(target) === 'acts') fetchActs(target); }
    const dock = pane.pane.querySelector('.watch-dock'); dock._sig = ''; paintPane(pane);
    dock.classList.remove('flash'); void dock.offsetWidth; dock.classList.add('flash');
    const it = target && dock.querySelector(`.wd-item[data-id="${target}"]`); if (it && it.scrollIntoView) it.scrollIntoView({ block: 'nearest' });
  }
  function jumpTo(pane, key) {
    const m = pane.$messages.querySelector(`[data-watch-round="${key}"]`);
    if (!m) { App.toast('ההודעה של הסבב לא טעונה בחלון הזה'); return; }
    if (pane.unstick) pane.unstick(2500); else pane.stick = false; // קפיצה להודעה: לא נמשכים חזרה לתחתית
    m.scrollIntoView({ block: 'center', behavior: 'smooth' }); m.classList.remove('flash'); void m.offsetWidth; m.classList.add('flash');
  }

  // ---------- אזור "מעקבים" בחלונית הצד ----------
  function paintPanel() {
    const body = $('watchesBody'); if (!body) return;
    const all = [...S.list.values()], act = all.filter(isActive), ended = all.filter(w => !isActive(w));
    const badge = $('actWatchesBadge'); if (badge) { badge.textContent = act.length; badge.hidden = !act.length; }
    const sig = JSON.stringify([all.map(w => [w.id, w.status, w.runCount, w.current, w.last && w.last.n, w.last && w.last.status, S.open.has(w.id), (S.runs.get(w.id) || []).map(r => r.status).join(''), w.actionsInDock, w.locked, JSON.stringify(w.fixing || null), w.pausedRemainingMs, (w.blocked || []).map(b => b.at).join(','), tabOf(w.id), actsSig(w.id), JSON.stringify([...(openRuns.get(w.id) || new Map())]), (S.runs.get(w.id) || []).map(r => r.n + (r.report ? 'r' : '') + (r.audit ? r.audit.verdict + ((r.audit.markErrors || []).length) + '/' + ((r.audit.unsupported || []).length) + '/' + (r.audit.checks || 0) : '')).join(','), w.name, w.everyMin, w.editedAt, w.nextRunAt, w.endReason, w.last && w.last.problem]), S.convs ? S.convs.size : 0]);
    if (body._sig === sig) { tickClocks(body); return; }
    body._sig = sig;
    const keepP = saveScroll(body);
    body.innerHTML = !all.length
      ? `<div class="ag-empty wl-empty"><div class="wl-big">⏱</div><b>אין מעקבים</b><p>מעקב = משימה קבועה ש-Claude מבצע לבד כל כמה זמן שתבחר (לבדוק ולתקן). פותחים אותו בכפתור "מעקב" שליד תיבת הכתיבה בשיחה.</p></div>`
      : (act.length ? `<div class="wl-sec">פעילים (${act.length})</div>` + act.map(w => rowHtml(w, false)).join('') : '<div class="wl-sec">אין מעקבים פעילים</div>')
      + (ended.length ? `<div class="wl-sec">הסתיימו (${ended.length})</div>` + ended.map(w => rowHtml(w, false)).join('') : '');
    restoreScroll(body, keepP);
  }
  function paintAll() { try { for (const c of App.chats.list()) paintPane(c); } catch { } paintPanel(); }
  function tickClocks(root) { root.querySelectorAll('[data-next]').forEach(e => { const t = Number(e.dataset.next); if (t) e.textContent = '⏱ ' + (t - Date.now() > 0 ? clk(t - Date.now()) : 'עכשיו'); }); }
  setInterval(() => { document.querySelectorAll('.watch-dock:not([hidden]), #watchesBody').forEach(tickClocks); }, 1000);

  // לחיצות (האצלה אחת לחלון בצ'אט ולחלונית הצד)
  document.addEventListener('click', e => {
    const t = e.target.closest(['data-tog', 'data-act', 'data-jump', 'data-edit', 'data-tab', 'data-dockmode', 'data-goto', 'data-del', 'data-lock', 'data-acts', 'data-approve', 'data-deny', 'data-skip', 'data-ans', 'data-stopround'].map(a => `.watch-dock [${a}], #watchesBody [${a}]`).join(', '));
    if (!t) return;
    e.preventDefault();
    if (t.dataset.lock) { const w = S.list.get(t.dataset.lock); if (w) setLock(w.id, !w.locked); return; }
    if (t.dataset.acts) { const [id, n] = t.dataset.acts.split('-'); tabs.set(id, 'acts'); if (!openRounds.has(id)) openRounds.set(id, new Map()); openRounds.get(id).set(Number(n), true); fetchActs(id); paintAll(); return; }
    if (t.dataset.approve || t.dataset.deny) { App.api('/api/approve', { method: 'POST', body: { requestId: t.dataset.approve || t.dataset.deny, approved: !!t.dataset.approve } }).catch(() => { }); const p = t.closest('.wa-pend'); if (p) p.remove(); return; }
    if (t.dataset.skip) { App.api('/api/approve', { method: 'POST', body: { requestId: t.dataset.skip, approved: false, message: 'The user skipped the questions.' } }).catch(() => { }); const p = t.closest('.wa-pend'); if (p) p.remove(); return; }
    if (t.dataset.ans) { App.api('/api/approve', { method: 'POST', body: { requestId: t.dataset.ans, approved: true, answers: { [t.dataset.q]: t.dataset.a } } }).catch(() => { }); const p = t.closest('.wa-pend'); if (p) p.remove(); return; }
    if (t.dataset.stopround) { App.api('/api/watches/' + t.dataset.stopround + '/stopround', { method: 'POST', body: {} }).then(r => App.toast(r && r.stopped ? '⏹ הסבב נעצר' : 'הסבב כבר הסתיים', 2000)).catch(() => { }); return; }
    if (t.dataset.edit) { const w = S.list.get(t.dataset.edit); if (w) editWatch(w); return; }
    if (t.dataset.tab) { tabs.set(t.dataset.tab, t.dataset.t); if (t.dataset.t === 'acts') fetchActs(t.dataset.tab); paintAll(); return; }
    if (t.dataset.dockmode) { const w = S.list.get(t.dataset.dockmode); if (w) setDockMode(w.id, !w.actionsInDock); return; }
    if (t.dataset.tog) { const id = t.dataset.tog; if (S.open.has(id)) S.open.delete(id); else { S.open.add(id); fetchRuns(id); if (tabOf(id) === 'acts') fetchActs(id); } paintAll(); return; }
    if (t.dataset.act) { const w = S.list.get(t.dataset.w); if (t.dataset.act === 'stop' && w) { App.confirm(`לעצור את המעקב ${w.id} «${w.name}»? Claude לא יתעורר אליו יותר.`, { okText: 'עצור', danger: true, title: 'עצירת מעקב' }).then(ok => ok && act(w.id, 'stop')); return; } act(t.dataset.w, t.dataset.act); return; }
    if (t.dataset.del) { remove(t.dataset.del); return; }
    if (t.dataset.goto) { const w = S.list.get(t.dataset.goto); if (w) openChat(w); return; }
    if (t.dataset.jump) { const [id, n] = t.dataset.jump.split('-'); const w = S.list.get(id); const pane = w && App.chats.byConvId(w.convId); if (pane) { if (App.chats.active() !== pane) openChat(w).then(() => setTimeout(() => jumpTo(App.chats.byConvId(w.convId), id + '-' + n), 600)); else jumpTo(pane, id + '-' + n); } else if (w) openChat(w).then(() => setTimeout(() => { const p = App.chats.byConvId(w.convId); if (p) jumpTo(p, id + '-' + n); }, 900)); }
  });
  async function openChat(w) {
    try { await App.chats.openConversation(w.convId); } catch { }
    setTimeout(() => { const p = App.chats.byConvId(w.convId); if (p) focusDock(p, w.id); }, 500);
  }

  // אירועים חיים מהשרת
  App.on('chatui:changed', () => paintAll()); // פורמט שעה חדש
  App.on('watch:event', ({ type, data }) => {
    if (type === 'watch_update') { upsert(data); if (S.open.has(data.id)) fetchRuns(data.id); if (acts.has(data.id) && (S.open.has(data.id) || (acts.get(data.id) || []).some(r => r.pending))) fetchActs(data.id); }
    else if (type === 'watch_removed') { S.list.delete(data.id); paintAll(); }
    else if (type === 'watch_activity' && data && data.id) {
      if (data.pending) { S.open.add(data.id); tabs.set(data.id, 'acts'); fetchActs(data.id); fetchRuns(data.id); const w = S.list.get(data.id); const pane = w && App.chats.byConvId && App.chats.byConvId(w.convId); if (pane) { try { localStorage.setItem('watch.dock.' + pane.id, '1'); } catch { } } App.toast('✋ מעקב ' + data.id + ': Claude מחכה לאישור / לתשובה שלך בחלון המעקב', 5000); return; } // אישור / שאלה בסבב: החלון נפתח לבד על הבקשה
      if (S.open.has(data.id) && tabOf(data.id) === 'acts') fetchActs(data.id); // סבב בחלון המעקב: פעולה חדשה — מוצגת מיד
    }
  });
  // פתחת / סגרת סבב בטאב "פעולות" — נשמר גם כשהחלון מתרענן מהפעולות החיות
  // פתיחה / סגירה של סבב — רק בלחיצה שלך (נרשם לפני שהדפדפן מחליף מצב), ונשמר גם כשהחלון מתרענן מהפעולות החיות
  document.addEventListener('click', e => {
    const sm = e.target.closest && e.target.closest('.wa-round > summary'); if (sm && !e.target.closest('button')) { const d = sm.parentElement, it = d.closest('.wd-item'); if (it) { const id = it.dataset.id; if (!openRounds.has(id)) openRounds.set(id, new Map()); openRounds.get(id).set(Number(d.dataset.round), !d.open); } return; }
    const rr = e.target.closest && e.target.closest('.wd-run[data-run]'); if (rr && !e.target.closest('button') && !e.target.closest('.wr-report')) { const [id, n] = rr.dataset.run.split('-'); if (!openRuns.has(id)) openRuns.set(id, new Map()); openRuns.get(id).set(Number(n), !rr.classList.contains('open')); paintAll(); }
  }, true);
  App.on('chat:activated', () => paintAll());
  App.on('view:shown', name => { if (name === 'watches') load(); });

  App.watches = { load, upsert, buildPop, paintPane, paintAll, focusDock, describe, list: () => [...S.list.values()], forConv, stop: id => act(id, 'stop'), pause: id => act(id, 'pause'), resume: id => act(id, 'resume'), runNow: id => act(id, 'run'), openChat, setLock, setDockMode, fetchActs };
  App.ready(() => { load(); setInterval(() => { for (const c of App.chats.list()) if (c.id && c.pane && !c._wpainted) { c._wpainted = true; paintPane(c); } }, 1500); });
})();
