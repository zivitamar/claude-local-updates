// ============================================================
//  themes.js — ערכות נושא לכל המערכת + הצבעים של ההודעות שלי (App.theme)
//  • הערכה = <html data-theme="...">; כל הצבעים מוגדרים ב-themes.css. "dark" = המראה המקורי בדיוק.
//  • נשמר בהגדרות (config: theme, userMsgColors) — משותף לתוכנה ולדפדפן — וגם ב-localStorage,
//    כדי שסקריפט קטן ב-<head> של index.html יחיל את הערכה עוד לפני הציור הראשון (בלי הבהוב).
//  • צבעי ההודעות שלי נשמרים לכל ערכה בנפרד: userMsgColors = { [themeId]: { bg, text } } → --user-msg-bg / --user-msg-text על <html>.
// ============================================================
(function () {
  const App = window.App, root = document.documentElement;
  const THEMES = [
    { id: 'dark', name: 'כהה — ברירת מחדל', kind: 'dark', desc: 'המראה המקורי של האפליקציה' },
    { id: 'light', name: 'בהיר — נקי', kind: 'light', desc: 'לבן ונייטרלי, חד וברור' },
    { id: 'cream', name: 'קרם Claude', kind: 'light', desc: 'בהיר וחמים, בסגנון Claude' },
    { id: 'paper', name: 'נייר חם — ספיה', kind: 'light', desc: 'לקריאה ארוכה, רך לעיניים' },
    { id: 'solarized', name: 'Solarized בהיר', kind: 'light', desc: 'הפלטה הקלאסית, בניגודיות משופרת' },
    { id: 'ocean', name: 'אוקיינוס', kind: 'light', desc: 'כחול בהיר ורענן' },
    { id: 'oled', name: 'לילה עמוק — OLED', kind: 'dark', desc: 'שחור מלא, לחדר חשוך ולמסכי OLED' },
    { id: 'nord', name: 'נורד', kind: 'dark', desc: 'כחול-אפור רגוע' },
    { id: 'dracula', name: 'דרקולה', kind: 'dark', desc: 'סגול כהה עם צבעי קוד עזים' },
    { id: 'forest', name: 'יער', kind: 'dark', desc: 'ירוק כהה ושקט' },
    { id: 'graphite', name: 'גרפיט', kind: 'dark', desc: 'אפור-כחול, בסגנון GitHub כהה' },
    { id: 'contrast', name: 'ניגודיות גבוהה', kind: 'hc', desc: 'נגישות: טקסט AAA, גבולות ופוקוס בולטים' }
  ];
  // צבעים מוכנים להודעות שלי — לפי סוג הערכה (כל זוג נבדק: ניגודיות ≥ 7:1)
  const PRESETS = {
    dark: [['כחול', '#1e3a5f', '#e6f0ff'], ['ירוק', '#1f3d2b', '#dcf5e4'], ['סגול', '#3b2d5e', '#eee6ff'], ['ענבר', '#4a3610', '#ffeec4'], ['ורוד', '#4c1f33', '#ffe1ec'], ['טורקיז', '#0f3f3d', '#d6faf5'], ['כתום', '#5a2f1f', '#ffe6da']],
    light: [['כחול', '#dbeafe', '#0b2545'], ['ירוק', '#dcfce7', '#0f3d22'], ['סגול', '#ede9fe', '#2e1065'], ['ענבר', '#fef3c7', '#422006'], ['ורוד', '#ffe4e6', '#4c0519'], ['טורקיז', '#ccfbf1', '#053b35'], ['כתום', '#ffedd5', '#431407']],
    hc: [['כחול', '#003a75', '#ffffff'], ['ירוק', '#00451f', '#ffffff'], ['סגול', '#3b0a66', '#ffffff'], ['צהוב', '#ffd23f', '#000000'], ['לבן', '#ffffff', '#000000'], ['ורוד', '#5c0030', '#ffffff']]
  };
  const LS_T = 'claude.theme', LS_U = 'claude.userMsgColors';
  const HEX = /^#[0-9a-f]{6}$/i, ID = /^[a-z0-9-]{1,32}$/;
  const ls = { get(k) { try { return localStorage.getItem(k); } catch { return null; } }, set(k, v) { try { localStorage.setItem(k, v); } catch { } } };
  const valid = id => THEMES.some(t => t.id === id);
  function cleanMap(m) {
    const o = {};
    if (m && typeof m === 'object') for (const [k, v] of Object.entries(m)) {
      if (!ID.test(k) || !v || typeof v !== 'object') continue;
      const c = {}; if (HEX.test(v.bg || '')) c.bg = v.bg.toLowerCase(); if (HEX.test(v.text || '')) c.text = v.text.toLowerCase();
      if (c.bg || c.text) o[k] = c;
    }
    return o;
  }
  let userMap = {}; try { userMap = cleanMap(JSON.parse(ls.get(LS_U) || '{}')); } catch { userMap = {}; }
  // ---------- צבעים להודעות שאינן שלך: Claude אחר · מנוע המחקר · תזרים · מעקב — לכל ערכה בנפרד: msgTypeColors = { [themeId]: { [type]: { bg, text } } } ----------
  const MSG_TYPES = [
    { id: 'claude', name: '🤖 הודעה מ-Claude אחר', label: '🤖 הודעה מ-Claude אחר — לא ממך · שיחה A123', sample: 'היי, סיימתי את הבדיקה בצד שלי — אפשר להמשיך.' },
    { id: 'research', name: '🔬 הודעה אוטומטית ממנוע המחקר', label: '🔬 הודעה אוטומטית ממנוע המחקר', sample: 'המחקר «דוגמה» הסתיים: 42 מקורות · 2 דקות.' },
    { id: 'flow', name: '⚙ שלב בתזרים', label: '⚙ תזרים "דוגמה" · שלב 2/5 — בדיקה', sample: 'בצע את השלב הבא בתזרים.' },
    { id: 'watch', name: '⏱ סבב מעקב', label: '⏱ מעקב W1 «שומר» · סבב 3', sample: '' }
  ];
  const LS_M = 'claude.msgTypeColors';
  function cleanTypeMap(m) { const o = {}; if (m && typeof m === 'object') for (const [k, v] of Object.entries(m)) { if (!ID.test(k) || !v || typeof v !== 'object') continue; const t = cleanMap(Object.fromEntries(MSG_TYPES.map(x => [x.id, v[x.id]]).filter(([, c]) => c))); if (Object.keys(t).length) o[k] = t; } return o; }
  let typeMap = {}; try { typeMap = cleanTypeMap(JSON.parse(ls.get(LS_M) || '{}')); } catch { typeMap = {}; }
  function applyTypes() { const m = typeMap[current()] || {}; for (const t of MSG_TYPES) { const c = m[t.id] || {}; for (const f of ['bg', 'text']) { const v = '--msg-' + t.id + '-' + f; if (c[f]) root.style.setProperty(v, c[f]); else root.style.removeProperty(v); } } }
  function setTypeColors(type, c, o = {}) {
    if (!MSG_TYPES.some(t => t.id === type)) return null;
    const id = current(), all = { ...(typeMap[id] || {}) }; const cc = cleanMap({ [type]: c || {} })[type]; if (cc) all[type] = cc; else delete all[type];
    if (Object.keys(all).length) typeMap[id] = all; else delete typeMap[id];
    ls.set(LS_M, JSON.stringify(typeMap)); applyTypes(); App.emit('theme:typecolors', { id, type });
    if (o.persist !== false) save({ msgTypeColors: typeMap });
    return (typeMap[id] || {})[type] || null;
  }
  const current = () => { const t = root.getAttribute('data-theme'); return valid(t) ? t : 'dark'; };
  const info = id => THEMES.find(t => t.id === (id || current())) || THEMES[0];

  function applyUser() {
    const c = userMap[current()] || {};
    if (c.bg) root.style.setProperty('--user-msg-bg', c.bg); else root.style.removeProperty('--user-msg-bg');
    if (c.text) root.style.setProperty('--user-msg-text', c.text); else root.style.removeProperty('--user-msg-text');
  }
  // ---------- שמירה בהגדרות (מאוחדת, כדי שגרירת בורר צבע לא תשלח עשרות בקשות) ----------
  let pending = {}, saveT = null, inflight = 0;
  function save(patch) {
    Object.assign(pending, patch); clearTimeout(saveT);
    saveT = setTimeout(async () => {
      const p = pending; pending = {}; saveT = null; inflight++;
      try { await App.saveConfig(p); } catch (e) { App.toast('❌ שמירת ערכת הנושא נכשלה: ' + e.message, 4000); }
      finally { inflight--; }
    }, 250);
  }
  const busy = () => !!saveT || inflight > 0;

  function apply(id, o = {}) {
    if (!valid(id)) id = 'dark';
    root.setAttribute('data-theme', id); ls.set(LS_T, id); applyUser(); applyTypes();
    App.emit('theme:changed', { id });
    if (o.persist !== false) save({ theme: id });
    return id;
  }
  // c = { bg, text } (כל אחד אופציונלי) או null = חזרה לברירת המחדל של הערכה
  function setUserColors(c, o = {}) {
    const id = current(); const m = cleanMap({ [id]: c || {} });
    if (m[id]) userMap[id] = m[id]; else delete userMap[id];
    ls.set(LS_U, JSON.stringify(userMap)); applyUser();
    App.emit('theme:usercolors', { id, colors: userMap[id] || null });
    if (o.persist !== false) save({ userMsgColors: userMap });
    return userMap[id] || null;
  }
  // ---------- סנכרון עם ההגדרות (config = מקור האמת; localStorage = רק בשביל טעינה מהירה) ----------
  let synced = false;
  App.on('config:changed', cfg => {
    if (!cfg || busy()) return;
    if (typeof cfg.theme === 'string' && valid(cfg.theme) && cfg.theme !== current()) apply(cfg.theme, { persist: false });
    if (cfg.userMsgColors && typeof cfg.userMsgColors === 'object') {
      const m = cleanMap(cfg.userMsgColors);
      if (JSON.stringify(m) !== JSON.stringify(userMap)) { userMap = m; ls.set(LS_U, JSON.stringify(userMap)); applyUser(); App.emit('theme:usercolors', { id: current(), colors: userMap[current()] || null }); }
    }
    if (cfg.msgTypeColors && typeof cfg.msgTypeColors === 'object') { const m = cleanTypeMap(cfg.msgTypeColors); if (JSON.stringify(m) !== JSON.stringify(typeMap)) { typeMap = m; ls.set(LS_M, JSON.stringify(typeMap)); applyTypes(); App.emit('theme:typecolors', { id: current() }); } }
    if (!synced) { // פעם ראשונה: בחירה שנעשתה רק בדפדפן הזה (לפני שהשרת ידע לשמור) עוברת להגדרות
      synced = true; const p = {};
      if (cfg.theme === undefined && current() !== 'dark') p.theme = current();
      if (cfg.userMsgColors === undefined && Object.keys(userMap).length) p.userMsgColors = userMap;
      if (Object.keys(p).length) save(p);
    }
  });

  // ---------- צבעים וניגודיות (WCAG 2) ----------
  function parseColor(s) {
    s = String(s || '').trim(); let m;
    if ((m = s.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i))) { let h = m[1]; if (h.length === 3) h = h.replace(/./g, c => c + c); return [0, 2, 4].map(i => parseInt(h.slice(i, i + 2), 16)); }
    if ((m = s.match(/^rgba?\(([^)]+)\)$/i))) return m[1].split(/[\s,/]+/).filter(Boolean).slice(0, 3).map(Number);
    if ((m = s.match(/^color\(srgb ([^)]+)\)$/i))) return m[1].split(/[\s/]+/).filter(Boolean).slice(0, 3).map(v => Math.round(Number(v) * 255));
    return null;
  }
  // כל צבע CSS (כולל var / color-mix) → [r,g,b], דרך אלמנט בדיקה
  function resolve(css) {
    const direct = parseColor(css); if (direct) return direct;
    const s = document.createElement('span'); s.style.cssText = 'position:absolute;width:0;height:0;overflow:hidden;color:' + css; document.body.appendChild(s);
    const c = getComputedStyle(s).color; s.remove(); return parseColor(c);
  }
  const toHex = rgb => rgb ? '#' + rgb.map(v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('') : '';
  const lum = rgb => { const [r, g, b] = rgb.map(v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
  function contrast(a, b) { const x = Array.isArray(a) ? a : resolve(a), y = Array.isArray(b) ? b : resolve(b); if (!x || !y) return 0; const l1 = lum(x), l2 = lum(y); return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05); }
  // מרחק צבע כפי שהעין רואה אותו (CIEDE2000): < 10 = קשה להבדיל בין שני רקעים בשיחה
  function lab(rgb) { const f = v => { v /= 255; return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; const [r, g, b] = rgb.map(f); const x = (r * 0.4124 + g * 0.3576 + b * 0.1805) / 0.95047, y = r * 0.2126 + g * 0.7152 + b * 0.0722, z = (r * 0.0193 + g * 0.1192 + b * 0.9505) / 1.08883; const q = t => t > 0.008856 ? Math.cbrt(t) : 7.787 * t + 16 / 116; return [116 * q(y) - 16, 500 * (q(x) - q(y)), 200 * (q(y) - q(z))]; }
  function deltaE(a, b) {
    const x = Array.isArray(a) ? a : resolve(a), y = Array.isArray(b) ? b : resolve(b); if (!x || !y) return 0;
    const [L1, a1, b1] = lab(x), [L2, a2, b2] = lab(y), R = Math.PI / 180, p7 = v => Math.pow(v, 7);
    const Cb = (Math.hypot(a1, b1) + Math.hypot(a2, b2)) / 2, G = 0.5 * (1 - Math.sqrt(p7(Cb) / (p7(Cb) + p7(25))));
    const a1p = (1 + G) * a1, a2p = (1 + G) * a2, C1 = Math.hypot(a1p, b1), C2 = Math.hypot(a2p, b2);
    const hue = (bb, aa) => { const v = Math.atan2(bb, aa) / R; return v < 0 ? v + 360 : v; }, h1 = hue(b1, a1p), h2 = hue(b2, a2p);
    let dh = h2 - h1; if (C1 * C2 === 0) dh = 0; else if (dh > 180) dh -= 360; else if (dh < -180) dh += 360;
    const dL = L2 - L1, dC = C2 - C1, dH = 2 * Math.sqrt(C1 * C2) * Math.sin(dh * R / 2), Lb = (L1 + L2) / 2, Cp = (C1 + C2) / 2;
    let hb = h1 + h2; if (C1 * C2 !== 0) hb = Math.abs(h1 - h2) > 180 ? (h1 + h2 + (h1 + h2 < 360 ? 360 : -360)) / 2 : (h1 + h2) / 2;
    const T = 1 - 0.17 * Math.cos((hb - 30) * R) + 0.24 * Math.cos(2 * hb * R) + 0.32 * Math.cos((3 * hb + 6) * R) - 0.2 * Math.cos((4 * hb - 63) * R);
    const RT = -Math.sin(2 * 30 * Math.exp(-Math.pow((hb - 275) / 25, 2)) * R) * 2 * Math.sqrt(p7(Cp) / (p7(Cp) + p7(25)));
    const SL = 1 + 0.015 * Math.pow(Lb - 50, 2) / Math.sqrt(20 + Math.pow(Lb - 50, 2)), SC = 1 + 0.045 * Cp, SH = 1 + 0.015 * Cp * T;
    return Math.sqrt(Math.pow(dL / SL, 2) + Math.pow(dC / SC, 2) + Math.pow(dH / SH, 2) + RT * (dC / SC) * (dH / SH));
  }
  // הצבעים בפועל של ההודעה שלי בערכה הנוכחית (מה שנבחר, או ברירת המחדל של הערכה)
  function userEffective() {
    const c = userMap[current()] || {};
    const cs = getComputedStyle(root);
    const defBg = toHex(resolve('var(--user-bg)') || resolve(cs.getPropertyValue('--user-bg'))), defText = toHex(resolve('var(--text)'));
    const bg = c.bg || defBg, text = c.text || defText;
    return { bg, text, defBg, defText, custom: { ...c }, ratio: contrast(bg, text) };
  }

  // הצבעים בפועל של סוג הודעה (מה שבחרת, או ברירת המחדל של הסוג בערכה הנוכחית)
  function typeEffective(type) {
    const c = (typeMap[current()] || {})[type] || {};
    const s = document.createElement('div'); s.className = 'msg user mt-' + type; s.style.cssText = 'position:absolute;left:-9999px;top:0'; s.innerHTML = '<div class="body">x</div>'; document.body.appendChild(s);
    const cs = getComputedStyle(s.firstChild); const curBg = toHex(parseColor(cs.backgroundColor)), curText = toHex(parseColor(cs.color)); s.remove();
    const defBg = toHex(resolve('var(--mt-' + type + '-bg)')), defText = toHex(resolve('var(--mt-' + type + '-text)'));
    const bg = c.bg || defBg || curBg, text = c.text || defText || curText;
    return { bg, text, defBg, defText, custom: { ...c }, ratio: contrast(bg, text) };
  }
  App.theme = {
    msgTypes: MSG_TYPES, typeColors: type => ({ ...((typeMap[current()] || {})[type] || {}) }), setTypeColors, typeEffective,
    list: THEMES, info, current, apply, presets: kind => PRESETS[kind || info().kind] || PRESETS.dark,
    userColors: () => ({ ...(userMap[current()] || {}) }), allUserColors: () => JSON.parse(JSON.stringify(userMap)),
    setUserColors, userEffective, contrast, deltaE, resolve, toHex, parseColor
  };
  // הערכה כבר הוחלה בסקריפט שב-<head>; כאן רק מוודאים שהכל עקבי (ערכה לא מוכרת → ברירת מחדל, וצבעי ההודעות)
  root.setAttribute('data-theme', current()); applyUser(); applyTypes();
})();
