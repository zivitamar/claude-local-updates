'use strict';
// ============================================================
//  updates.js — עדכונים מ-GitHub בממשק: כפתור "⬆ יש עדכון · עדכן" בסרגל העליון (מצב "לפי בחירה", או כשעדכון מוכן),
//  ובלוק "עדכונים" בהגדרות › מערכת (אוטומטי / לפי בחירה / כבוי, בדוק עכשיו, עדכן עכשיו). המצב מגיע חי מהשרת (update_status).
// ============================================================
(() => {
  const App = window.App, el = App.el, esc = App.esc;
  let st = null, btn = null;
  const label = s => !s ? '' : s.status === 'downloading' ? 'מוריד עדכון…' : s.status === 'applying' ? 'מתעדכן — החלון ייטען מחדש…' : s.status === 'ready' ? 'העדכון מוכן' : s.available ? 'יש עדכון חדש' : s.status === 'uptodate' ? 'מעודכן' : s.status === 'error' ? 'בדיקת עדכונים נכשלה' : '';
  function ensureBtn() {
    if (btn) return btn;
    const badge = document.getElementById('accountBadge'); if (!badge) return null;
    btn = el('button', 'update-btn'); btn.type = 'button'; btn.id = 'updateBtn'; btn.hidden = true;
    btn.onclick = async () => { btn.disabled = true; try { await App.api('/api/updates/apply', { method: 'POST' }); App.toast('מתעדכן — החלון ייטען מחדש בעוד רגע'); } catch (e) { App.toast('❌ ' + e.message); btn.disabled = false; } };
    badge.parentNode.insertBefore(btn, badge);
    return btn;
  }
  function render() {
    const b = ensureBtn(); if (!b || !st) return;
    const show = st.enabled && st.available && st.mode !== 'off' && (st.mode === 'manual' || st.status === 'ready');
    b.hidden = !show; b.disabled = st.status === 'applying' || st.status === 'downloading';
    b.textContent = st.status === 'applying' ? '⏳ מתעדכן…' : '⬆ יש עדכון · עדכן';
    b.title = st.latest ? 'גרסה ' + st.latest.build + (st.latest.notes ? ' — ' + st.latest.notes : '') + ' (עכשיו: ' + st.current + ')' : '';
    App.emit('update:render', st);
  }
  App.on('update:status', d => { st = d; render(); });
  App.ready(async () => { try { st = await App.api('/api/updates'); render(); } catch { } });

  // בלוק בהגדרות › מערכת
  App.updates = {
    section() {
      const sec = el('div', 'upd-sec'); sec.style.cssText = 'margin-top:14px;padding-top:12px;border-top:1px solid var(--border,#3d3d3a)';
      const head = el('div', 'upd-head', '<b>⬆ עדכונים</b> <small>מ-GitHub, חתומים — לכל המחשבים שהתוכנה מותקנת בהם</small>'); sec.appendChild(head);
      const seg = el('div', 'seg upd-mode'); seg.style.cssText = 'display:flex;gap:6px;margin:8px 0';
      const line = el('div', 'upd-line'); line.style.cssText = 'font-size:12.5px;color:var(--text-dim,#a6a39b);margin:6px 0';
      const acts = el('div', 'acct-actions');
      const chk = el('button', 'btn-ghost', '🔎 בדוק עכשיו'), go = el('button', 'btn', '⬆ עדכן עכשיו');
      const draw = s => {
        if (!s) return; seg.innerHTML = '';
        for (const [k, t] of [['auto', 'אוטומטי'], ['manual', 'לפי בחירה'], ['off', 'כבוי']]) { const b = el('button', 'btn-ghost' + (s.mode === k ? ' on' : ''), t); b.dataset.mode = k; if (s.mode === k) b.style.cssText = 'background:var(--accent);color:var(--bg,#1f1e1d)'; b.onclick = async () => { await App.saveConfig({ updates: { mode: k } }); try { st = await App.api('/api/updates'); draw(st); render(); } catch { } }; seg.appendChild(b); }
        line.innerHTML = !s.enabled ? 'עדכונים פעילים רק באפליקציה המותקנת (לא בהרצה מהקוד).' : `גרסה מותקנת <bdi dir="ltr">${esc(s.current)}</bdi>` + (s.latest ? ` · אחרונה ב-GitHub <bdi dir="ltr">${esc(s.latest.build)}</bdi>` : '') + ' · ' + esc(label(s)) + (s.error ? ' · ' + esc(s.error) : '') + (s.lastCheck ? ' · נבדק ' + new Date(s.lastCheck).toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' }) : '');
        go.hidden = !s.available; go.disabled = s.status === 'applying';
      };
      chk.onclick = async () => { chk.disabled = true; try { st = await App.api('/api/updates/check', { method: 'POST' }); draw(st); render(); } catch (e) { App.toast('❌ ' + e.message); } chk.disabled = false; };
      go.onclick = () => ensureBtn() && btn.onclick();
      acts.append(chk, go); sec.append(seg, line, acts);
      App.on('update:render', s => draw(s));
      App.api('/api/updates').then(s => { st = s; draw(s); }).catch(() => { line.textContent = 'אין מידע על עדכונים'; });
      return sec;
    }
  };
})();
