// ============================================================
//  claudeview.js — הלשונית "Claude" בסרגל השמאלי (במקום סייר הקבצים): החשבון, עמוד ה-USAGE המלא, המודל, ומה רץ עכשיו.
// ============================================================
(function () {
  const App = window.App, $ = App.$, el = App.el, esc = App.esc, fmt = App.fmt;
  let busy = false, timer = null;
  const shown = () => { const v = $('view-claude'); return v && !v.hidden && !$('sidepanel').classList.contains('collapsed'); };

  function section(title) { const s = el('section', 'cv-sec'); s.appendChild(el('h3', 'cv-h', esc(title))); return s; }
  function row(label, valueHtml) { const r = el('div', 'cv-row'); r.innerHTML = `<span class="cv-k">${esc(label)}</span><span class="cv-v">${valueHtml}</span>`; return r; }
  const planOf = s => { if (!s) return ''; const t = String(s.tier || '').replace('max_', 'Max ').replace('pro', 'Pro'); return (s.plan ? s.plan[0].toUpperCase() + s.plan.slice(1) : 'Claude') + (t && !/^max$/i.test(t) ? ' · ' + t.replace(/^Max\s*/i, '') : ''); };

  async function render() {
    const box = $('claudeBody'); if (!box || busy) return; busy = true;
    if (!box.children.length) box.innerHTML = '<div class="st-loading" style="padding:16px;color:var(--muted)">טוען…</div>';
    try {
      const [acc, u] = await Promise.all([App.api('/api/account').catch(() => null), App.api('/api/usage').catch(() => null)]);
      const cfg = App.state.config || {}; const frag = document.createDocumentFragment();
      // ----- חשבון -----
      const a = section('חשבון'); const card = el('div', 'cv-acct');
      const sub = acc && acc.subscription;
      if (cfg.accountMode === 'subscription' && sub && sub.loggedIn) {
        card.innerHTML = `<div class="cv-av">${esc((sub.email || '?')[0].toUpperCase())}</div><div class="cv-ai"><div class="cv-mail" dir="ltr">${esc(sub.email || '')}</div><div class="cv-plan"><span class="badge">${esc(planOf(sub))}</span>${sub.org ? `<span>${esc(sub.org)}</span>` : ''}</div></div>`;
      } else if (cfg.accountMode === 'subscription') {
        card.innerHTML = '<div class="cv-av off">?</div><div class="cv-ai"><div class="cv-mail">לא מחובר לחשבון</div><div class="cv-plan">כניסה דרך הכפתור למטה</div></div>';
      } else {
        card.innerHTML = `<div class="cv-av api">API</div><div class="cv-ai"><div class="cv-mail">מצב טוקנים (מפתח API)</div><div class="cv-plan" dir="ltr">${esc(cfg.hasApiKey ? cfg.apiKeyPreview : 'אין מפתח')}</div></div>`;
      }
      a.appendChild(card);
      const bar = el('div', 'cv-actions');
      const b1 = el('button', 'btn-ghost', cfg.accountMode === 'subscription' && sub && sub.loggedIn ? '🗂️ החשבונות שלי' : '🔑 כניסה / הגדרות חשבון'); b1.onclick = () => App.settings && App.settings.open('account');
      const b2 = el('button', 'btn-ghost', '⚙️ הגדרות'); b2.onclick = () => App.settings && App.settings.open('general');
      bar.append(b1, b2); a.appendChild(bar); frag.appendChild(a);

      // ----- USAGE -----
      const us = section(cfg.accountMode === 'subscription' ? 'USAGE' : 'API');
      if (u && u.mode === 'subscription') {
        const s = u.subscription;
        if (s && s.ok && s.windows.length) {
          for (const w of s.windows) {
            const used = Math.round(w.utilization), left = Math.max(0, 100 - used), cls = used >= 85 ? 'high' : used >= 60 ? 'mid' : '';
            const r = el('div', 'use-row'); r.innerHTML = `<div class="use-top"><span>${esc(w.label)}</span><b class="${cls === 'high' ? 'hi' : cls}"><bdi>${used}% בשימוש</bdi> · <bdi>נשאר ${left}%</bdi></b></div><div class="use-bar"><i class="${cls}" style="width:${Math.max(1, Math.min(100, used))}%"></i></div>${w.resetsAt ? `<small>איפוס ${new Date(w.resetsAt).toLocaleDateString('he-IL', { weekday: 'long', day: 'numeric', month: 'long' })} (${fmt.until(w.resetsAt)})</small>` : ''}`;
            us.appendChild(r);
          }
        } else us.appendChild(el('div', 'notice error', 'אין נתונים: ' + esc((u && u.subscriptionError) || 'לא מחובר')));
      } else if (u) {
        const t = u.usage || {}, budget = u.creditBudgetUSD || 0, spent = t.totalCostUSD || 0;
        if (budget > 0) { const pct = Math.min(100, spent / budget * 100), cls = pct >= 85 ? 'high' : pct >= 60 ? 'mid' : ''; const r = el('div', 'use-row'); r.innerHTML = `<div class="use-top"><span>תקציב</span><b class="${cls === 'high' ? 'hi' : cls}"><bdi>נשאר ${fmt.money(Math.max(0, budget - spent))}</bdi> <bdi>מתוך ${fmt.money(budget)}</bdi></b></div><div class="use-bar"><i class="${cls}" style="width:${Math.max(1, pct)}%"></i></div>`; us.appendChild(r); }
        else us.appendChild(el('div', 'use-extra', `נוצל ${fmt.money(spent)}`));
      }
      const rb = el('button', 'btn-ghost cv-refresh', '⟳ רענן'); rb.onclick = () => { App.usage && App.usage.refresh(true); render(); }; us.appendChild(rb);
      frag.appendChild(us);

      // ----- מודל ומה רץ עכשיו -----
      const m = section('עכשיו');
      m.appendChild(row('מודל', `<bdi>${esc(App.modelLabel(cfg.model) || 'ברירת מחדל')}</bdi>`));
      const convs = App.projects ? [...(App.projects.list() || [])].flatMap(p => App.projects.chatsOf(p.id)) : [];
      const run = convs.filter(c => c.running).length, done = convs.filter(c => !c.running && c.unseen).length;
      m.appendChild(row('צ\'אטים שעובדים', run ? `<span class="pd run"></span> ${run}` : '0'));
      m.appendChild(row('צ\'אטים שסיימו (לא נקראו)', done ? `<span class="pd done"></span> ${done}` : '0'));
      if (App.agents && App.agents.runningCounts) { const c = App.agents.runningCounts(); m.appendChild(row('סוכנים / מחקרים', `${c.agents || 0} / ${c.research || 0}`)); }
      frag.appendChild(m);
      box.innerHTML = ''; box.appendChild(frag);
    } catch (e) { box.innerHTML = '<div class="notice error">שגיאה בטעינה: ' + esc(e.message) + '</div>'; }
    finally { busy = false; }
  }

  App.claudeView = { render };
  App.ready(() => {
    const again = () => { if (shown()) render(); };
    App.on('view:shown', n => { if (n === 'claude') render(); });
    App.on('usage:data', again); App.on('projects:changed', again); App.on('chat:finished', again); App.on('config:changed', again);
    timer = setInterval(again, 20000);
  });
})();
