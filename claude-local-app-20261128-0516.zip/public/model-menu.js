// ============================================================
//  תפריט המודלים בצ'אט (הבעלים 26/11): Default, ואז משפחות בסדר Fable · Opus · Sonnet · Haiku.
//  לכל משפחה — כל הגרסאות שלה (מהחדשה לישנה). הכינוי של המשפחה ("opus" = תמיד החדש ביותר) מופיע כגרסה שלו עם "החדש ביותר",
//  וגרסה מפורשת שזהה לו לא מופיעה פעמיים. מודל שנבחר ואינו ברשימה — נכנס למשפחה שלו (לא שורה נפרדת).
// ============================================================
(function () {
  const FAMS = [['fable', 'Fable'], ['opus', 'Opus'], ['sonnet', 'Sonnet'], ['haiku', 'Haiku']];
  const famOf = m => {
    if (!m || m.id === 'default') return null;
    const s = (String(m.id || '') + ' ' + String(m.resolved || '')).toLowerCase();
    for (const [k] of FAMS) if (new RegExp('(^|[^a-z])' + k + '([^a-z]|$)').test(s)) return k;
    return null;
  };
  // "claude-opus-4-8" → 4.8 · "claude-opus-5" → 5 · "claude-haiku-4-5-20251001" → 4.5 · "claude-fable-5-2" → 5.2
  const verOf = m => { const x = /(?:fable|opus|sonnet|haiku|mythos)-(\d+)(?:-(\d{1,2}))?(?![\d])/i.exec(String(m.resolved || m.id || '')); return x ? x[1] + (x[2] ? '.' + x[2] : '') : null; };
  const num = v => { const [a, b] = String(v || '0').split('.'); return (+a || 0) * 100 + (+b || 0); };
  function plan(models, cur) {
    models = (models || []).filter(m => m && m.id);
    if (cur && !models.some(m => m.id === cur)) models = [...models, { id: cur, name: cur }];
    const top = models.filter(m => m.id === 'default' || (!famOf(m) && m.id !== cur) || (!famOf(m) && m.id === cur));
    const families = [];
    for (const [k, name] of FAMS) {
      const mem = models.filter(m => famOf(m) === k);
      if (!mem.length) continue;
      const alias = mem.find(m => m.id === k), seen = new Set(), versions = [];
      if (alias) { const v = verOf(alias) || verOf({ id: k + '-' + String(alias.name || '').replace(/^\D+/, '').replace(/\./g, '-') }); /* בלי resolved: הגרסה מהשם ("Opus 5.5") */ versions.push({ model: alias, ver: v ? name + ' ' + v : alias.name, note: 'החדש ביותר', n: num(v) + 0.5 }); seen.add(String(alias.resolved || alias.id)); if (v) seen.add('v:' + v); }
      for (const m of mem) {
        if (m === alias) continue;
        const key = String(m.resolved || m.id), v = verOf(m), vk = 'v:' + (v || m.id);
        const dup = seen.has(key) || seen.has(vk);
        if (dup && m.id !== cur) continue; seen.add(key); seen.add(vk); versions.push({ model: m, ver: v ? name + ' ' + v : (m.name || m.id), note: dup ? 'גרסה קבועה' : '', n: num(v) - (dup ? 0.1 : 0) });
      }
      versions.sort((a, b) => b.n - a.n);
      const sel = versions.find(v => v.model.id === cur) || null;
      families.push({ key: k, name, versions, selected: sel ? { ver: sel.ver.replace(name + ' ', ''), id: sel.model.id } : null });
    }
    return { top, families };
  }
  // תפריט הגרסאות נסגר בלחיצה מחוץ לו / לחלון המודל, וב-Esc
  const closeAll = () => document.querySelectorAll('.mp-fly').forEach(f => f.remove());
  if (typeof document !== 'undefined') {
    document.addEventListener('mousedown', e => { if (!(e.target.closest && (e.target.closest('.mp-fly') || e.target.closest('.cb-modelpop')))) closeAll(); }, true);
    document.addEventListener('keydown', e => { if (e.key === 'Escape') closeAll(); }, true);
  }
  // חשיבה "אוטומטית" (הבעלים 26/11): 🧠 בתוך עיגול של שני חצים שרודפים זה אחרי זה ומסתובבים סביבו
  let abN = 0;
  const autoBrain = () => { const id = 'abm' + (++abN);
    return `<span class="auto-brain" aria-label="חשיבה אוטומטית"><svg class="ab-ring" viewBox="0 0 24 24" aria-hidden="true"><defs><marker id="${id}" viewBox="0 0 6 6" refX="3" refY="3" markerWidth="3.6" markerHeight="3.6" orient="auto"><path d="M0,0 L6,3 L0,6 z" fill="currentColor"/></marker></defs><path d="M12 2.5 A9.5 9.5 0 0 1 18.1 19.3" marker-end="url(#${id})"/><path d="M12 21.5 A9.5 9.5 0 0 1 5.9 4.7" marker-end="url(#${id})"/></svg><span class="ab-b">🧠</span></span>`; };
  // רשימה שטוחה מסודרת להגדרות (הבעלים 26/11): Default, ואז כל ה-Fable, כל ה-Opus, כל ה-Sonnet, כל ה-Haiku — כל משפחה מהגרסה החדשה לישנה;
  // שם ברור בלבד ("Opus 4.8"), בלי הקוד הארוך בסוגריים ובלי כפילויות
  const options = (models, cur) => { const p = plan(models, cur), out = [];
    for (const m of p.top) { if (m.id !== 'default') { out.push([m.id, m.name || m.id]); continue; } const fk = famOf({ id: 'x', resolved: m.resolved }), fn = (FAMS.find(x => x[0] === fk) || [])[1], v = verOf(m); out.push([m.id, 'ברירת מחדל' + (fn && v ? ' — ' + fn + ' ' + v : '')]); }
    for (const f of p.families) for (const v of f.versions) out.push([v.model.id, v.ver + (v.note ? ' — ' + v.note : '')]);
    return out; };
  window.ModelMenu = { plan, famOf, verOf, closeAll, autoBrain, options };
})();
