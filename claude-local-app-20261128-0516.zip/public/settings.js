// ============================================================
//  settings.js — הגדרות מסודרות לפי קטגוריות (תפריט צד) + כל מה שקשור לחשבון בלשונית "חשבון":
//  כניסה / החלפת חשבון / התנתקות (פותח את Chrome לאימות, בדיוק כמו ב-VS Code), מפתח API, שימוש, מודל, הרשאות, תיקיות ופרויקטים,
//  מאגרי הוראות, סוכנים ומחקר, מערכת. כל שינוי נשמר מיד (בלי כפתור "שמור" גדול).
// ============================================================
(function () {
  const App = window.App, $ = App.$, el = App.el, esc = App.esc, fmt = App.fmt;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const TABS = [
    ['account', '👤', 'חשבון'], ['usage', '📊', 'שימוש'], ['model', '🤖', 'מודל וחשיבה'], ['theme', '🎨', 'הגדרות תצוגה'], ['chat', '💬', 'צ\'אט'], ['sounds', '🔊', 'צלילים'], ['perms', '🛡️', 'הרשאות וכלים'],
    ['folders', '📂', 'תיקיות ופרויקטים'], ['instr', '📝', 'מאגרי הוראות'], ['agents', '🔬', 'סוכנים ומחקר'], ['hub', '🌐', 'חיבור מכל מקום'], ['system', 'ℹ️', 'מערכת']
  ];
  let modal = null, current = 'account', contentEl = null, loginPoll = null;

  App.settings = { open, close: () => modal && modal.close() };
  function open(tab) {
    if (modal && modal.el.isConnected) { go(tab || current); return; }
    const body = el('div', 'st-wrap');
    const nav = el('nav', 'st-nav'); contentEl = el('div', 'st-content');
    for (const [id, ic, name] of TABS) { const b = el('button', 'st-tab'); b.dataset.tab = id; b.innerHTML = `<span>${ic}</span>${name}`; b.onclick = () => go(id); nav.appendChild(b); }
    body.append(nav, contentEl);
    modal = App.modal({ title: '⚙️ הגדרות', body, cls: 'xwide settings-modal', onClose: () => { clearInterval(loginPoll); loginPoll = null; modal = null; } });
    go(tab || 'account');
  }
  async function go(tab) {
    if (!TABS.some(t => t[0] === tab)) tab = 'model'; // "general" (כפתור ההגדרות / Ctrl+,) = מודל וכללי
    current = tab;
    modal.body.querySelectorAll('.st-tab').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
    contentEl.innerHTML = '<div class="st-loading">טוען…</div>';
    const box = el('div', 'st-page');
    const pages = { hub: box => App.hubUI.render(box), account: pAccount, usage: pUsage, model: pModel, theme: pTheme, chat: pChat, sounds: box => App.soundsUI.render(box), perms: pPerms, folders: pFolders, instr: pInstr, agents: pAgents, system: pSystem };
    try { await (pages[tab] || pages.model)(box); }
    catch (e) { box.innerHTML = `<div class="notice error">שגיאה: ${esc(e.message)}</div>`; }
    if (current === tab) { contentEl.innerHTML = ''; contentEl.appendChild(box); }
  }

  // ---------- עזרים ----------
  const section = (title, desc) => { const s = el('section', 'st-sec'); s.innerHTML = `<h3>${title}</h3>`; if (desc) s.appendChild(el('div', 'st-sub', desc)); return s; };
  const flash = msg => { App.toast('✅ ' + (msg || 'נשמר'), 1400); };
  async function save(patch, msg) { try { await App.saveConfig(patch); flash(msg); } catch (e) { App.toast('❌ ' + e.message, 4000); } }
  function toggle(title, desc, get, onChange) {
    const l = el('label', 'st-toggle'); const cb = el('input'); cb.type = 'checkbox'; cb.checked = !!get();
    cb.onchange = () => onChange(cb.checked);
    l.append(cb, el('span', 'sw'), el('span', 'st-tt', `<b>${title}</b>`)); if (desc) l.title = desc; return l;
  }
  function field(label, control, hint) { const f = el('label', 'st-field'); f.appendChild(el('span', 'st-lbl', label)); f.appendChild(control); if (hint) f.title = hint; return f; }
  function select(opts, value, onChange) { const s = el('select'); for (const [v, t] of opts) { const o = el('option'); o.value = v; o.textContent = t; s.appendChild(o); } s.value = value; s.onchange = () => onChange(s.value); return s; }
  const cfg = () => App.state.config || {};

  // =========================== חשבון ===========================
  // מתג מצב עבודה (מנוי / API) + שתי לשוניות: "מנוי" (חשבונות Claude שמורים, החלפה בקליק) ו-"API" (מפתחות שמורים)
  async function pAccount(box) {
    const acc = await App.api('/api/account?refresh=1');
    const sub = acc.subscription, mode = acc.mode;
    const mk = (cls, txt, fn, title) => { const b = el('button', cls, txt); b.type = 'button'; b.onclick = fn; if (title) b.title = title; return b; };
    // ---- מתג: על מה המערכת עובדת עכשיו ----
    const isSub = mode === 'subscription';
    const sw = el('div', 'acct-mode');
    sw.innerHTML = `<div class="am-txt"><b>המערכת עובדת עכשיו על:</b> <span class="am-now ${isSub ? 'sub' : 'api'}">${isSub ? '👑 מנוי' : '🔑 API (טוקנים)'}</span></div>`;
    const tg = el('label', 'st-toggle am-switch'); const cb = el('input'); cb.type = 'checkbox'; cb.checked = !isSub; cb.className = 'am-cb';
    tg.append(el('span', 'am-l', '👑 מנוי'), cb, el('span', 'sw'), el('span', 'am-r', '🔑 API'));
    cb.onchange = async () => {
      const m = cb.checked ? 'credits' : 'subscription'; window.__acctTab = m === 'subscription' ? 'sub' : 'api';
      await save({ accountMode: m }, 'מצב: ' + (m === 'subscription' ? 'מנוי' : 'API')); App.state.models = []; await App.loadModels(true); App.usage && App.usage.refresh(true); go('account');
    };
    sw.appendChild(tg); box.appendChild(sw);
    // ---- לשוניות ----
    const tab = window.__acctTab || (isSub ? 'sub' : 'api');
    const tabs = el('div', 'seg acct-tabs');
    for (const [t, label] of [['sub', '👑 מנוי'], ['api', '🔑 API']]) {
      const b = mk('seg-btn' + (tab === t ? ' active' : ''), label, () => { window.__acctTab = t; go('account'); }); b.dataset.tab = t; tabs.appendChild(b);
    }
    box.appendChild(tabs);
    if (tab === 'sub') await subTab(box, acc, sub, mk); else await apiTab(box, acc, mk);
  }

  async function subTab(box, acc, sub, mk) {
    const sec = section('👑 החשבון הפעיל');
    const card = el('div', 'acct-card' + (sub.loggedIn ? ' on' : ''));
    if (!acc.cli.found) card.innerHTML = `<div class="acct-warn">❌ ${esc(acc.cli.error || 'Claude Code לא נמצא')}</div>`;
    else if (sub.loggedIn) {
      card.innerHTML = `<div class="acct-av">${esc((sub.email || '?')[0].toUpperCase())}</div><div class="acct-info"><div class="acct-mail">${esc(sub.email || '')}</div>
        <div class="acct-meta"><span class="badge">${esc(planLabel(sub))}</span><span>${esc(sub.org || '')}</span></div>
        <div class="acct-ok">✅ מחובר · Claude Code ${esc(acc.cli.version || '')}</div></div>`;
    } else card.innerHTML = `<div class="acct-av off">?</div><div class="acct-info"><div class="acct-mail">לא מחובר לחשבון Claude</div><div class="acct-meta">בחר חשבון שמור למטה, או "הוספת חשבון".</div></div>`;
    sec.appendChild(card); box.appendChild(sec);
    if (!acc.cli.found) return;

    const sec2 = section('🗂️ החשבונות שלי', 'כל חשבון שנכנסת אליו נשמר כאן. <b>החלף</b> = קליק אחד, בלי כניסה מחדש. <b>אימות מכשירים</b>: טלפון או מחשב שמתחבר עם חשבון מסומן יקבל גישה. המנוי שהמחשב עובד עליו לא משתנה בגלל זה.');
    const list = el('div', 'acct-list'); sec2.appendChild(list);
    let r = { accounts: [] }; try { r = await App.api('/api/accounts?refresh=1'); } catch (e) { list.appendChild(el('div', 'notice error', '❌ ' + esc(e.message))); }
    if (!r.accounts.length) list.appendChild(el('div', 'st-sub', 'אין עדיין חשבונות שמורים. לחץ "הוספת חשבון".'));
    for (const a of r.accounts) {
      const row = el('div', 'acct-row' + (a.active ? ' on' : '')); row.dataset.id = a.id;
      row.innerHTML = `<div class="acct-av sm">${esc((a.email || '?')[0].toUpperCase())}</div><div class="acct-info"><div class="acct-mail">${esc(a.email || '')}</div>
        <div class="acct-meta"><span class="badge">${esc(planLabel(a))}</span>${a.orgName ? `<span>${esc(a.orgName)}</span>` : ''}${a.active ? '<b class="acct-ok">● בשימוש עכשיו</b>' : ''}${a.expired ? '<b class="acct-warn">⚠ הכניסה פגה — הוסף אותו מחדש</b>' : ''}</div></div>`;
      const acts = el('div', 'acct-row-acts');
      if (!a.active) acts.appendChild(mk('btn-primary acct-switch', '⇄ החלף', async ev => {
        const b = ev.currentTarget; b.disabled = true; b.textContent = 'מחליף…';
        try { await App.api('/api/accounts/' + a.id + '/switch', { method: 'POST', body: {} }); await App.loadConfig(); App.state.models = []; await App.loadModels(true); App.usage && App.usage.refresh(true); App.toast('✅ עברת ל-' + a.email, 3500); }
        catch (e) { App.toast('❌ ' + e.message, 5000); }
        go('account');
      }, 'עבור לחשבון הזה בלי כניסה מחדש'));
      const dv = el('label', 'st-toggle acct-dev'); const dcb = el('input'); dcb.type = 'checkbox'; dcb.checked = !!a.deviceAuth;
      dcb.onchange = async () => { try { await App.api('/api/accounts/' + a.id + '/device', { method: 'POST', body: { on: dcb.checked } }); flash(dcb.checked ? 'מאושר לאימות מכשירים' : 'לא מאושר לאימות מכשירים'); } catch (e) { dcb.checked = !dcb.checked; App.toast('❌ ' + e.message, 4000); } };
      dv.append(dcb, el('span', 'sw'), el('span', 'st-tt', 'אימות מכשירים')); dv.title = 'מכשיר שמתחבר עם החשבון הזה יקבל גישה למערכת';
      acts.appendChild(dv);
      acts.appendChild(mk('btn-ghost acct-del', '🗑️', async () => {
        if (!(await App.confirm('להסיר את ' + a.email + ' מהחשבונות השמורים?' + (a.active ? '\nזה החשבון הפעיל: הוא יישאר מחובר עד שתחליף.' : ''), { danger: true, okText: 'הסר' }))) return;
        try { await App.api('/api/accounts/' + a.id, { method: 'DELETE' }); flash('הוסר'); } catch (e) { App.toast('❌ ' + e.message, 4000); }
        go('account');
      }, 'הסר מהרשימה'));
      row.appendChild(acts); list.appendChild(row);
    }
    const bar = el('div', 'acct-actions'); const loginBox = el('div', 'login-flow'); loginBox.hidden = true;
    bar.appendChild(mk('btn-primary acct-add', sub.loggedIn ? '➕ הוספת חשבון' : '🔑 כניסה לחשבון', () => startLogin(loginBox, { add: true, done: () => go('account') }), 'כניסה לחשבון Claude נוסף. החשבון הפעיל לא מתנתק'));
    if (sub.loggedIn) bar.appendChild(mk('btn-ghost', '🚪 התנתק', async () => {
      if (!(await App.confirm('להתנתק מחשבון ' + (sub.email || '') + '?\nהוא גם יוסר מהחשבונות השמורים. (Claude Code ב-VS Code משתמש באותה כניסה.)', { danger: true, okText: 'התנתק', title: 'התנתקות' }))) return;
      await App.api('/api/account/logout', { method: 'POST', body: {} }); flash('התנתקת'); await App.loadConfig(); App.usage && App.usage.refresh(true); go('account');
    }));
    bar.appendChild(mk('btn-ghost', '⟳ רענן', () => go('account')));
    sec2.append(bar, loginBox); box.appendChild(sec2);
    if (window.__activeLogin) { const L = window.__activeLogin; loginBox.hidden = false; watchLogin(loginBox, L.id || L, { add: !!L.add, done: () => go('account') }); }
  }

  async function apiTab(box, acc, mk) {
    const sec = section('🔑 מפתחות API', 'מקבלים מפתח ב-<a href="https://console.anthropic.com/settings/keys" target="_blank" rel="noopener">console.anthropic.com</a>. המפתחות נשמרים רק במחשב שלך. "השתמש" = המפתח שהמערכת עובדת איתו במצב API.');
    const list = el('div', 'acct-list'); sec.appendChild(list);
    let r = { keys: [] }; try { r = await App.api('/api/apikeys'); } catch (e) { list.appendChild(el('div', 'notice error', '❌ ' + esc(e.message))); }
    if (!r.keys.length) list.appendChild(el('div', 'st-sub', r.envKey ? 'אין מפתחות שמורים (בשימוש מפתח ממשתנה סביבה).' : 'אין עדיין מפתחות. הוסף מפתח למטה.'));
    for (const k of r.keys) {
      const row = el('div', 'acct-row key-row' + (k.active ? ' on' : '')); row.dataset.id = k.id;
      row.innerHTML = `<div class="acct-av sm">🔑</div><div class="acct-info"><div class="key-name"></div><div class="acct-meta"><code dir="ltr"></code><span class="key-acct"></span>${k.active ? '<b class="acct-ok">● בשימוש עכשיו</b>' : ''}</div></div>`;
      row.querySelector('.key-name').textContent = k.name || 'מפתח ללא שם';
      row.querySelector('code').textContent = k.preview;
      row.querySelector('.key-acct').textContent = k.account ? '👤 ' + k.account : '👤 לא שויך לחשבון';
      const acts = el('div', 'acct-row-acts');
      if (!k.active) acts.appendChild(mk('btn-primary key-use', 'השתמש', async () => { try { await App.api('/api/apikeys/' + k.id + '/activate', { method: 'POST', body: {} }); await App.loadConfig(); App.state.models = []; await App.loadModels(true); flash('בשימוש: ' + (k.name || k.preview)); } catch (e) { App.toast('❌ ' + e.message, 4000); } go('account'); }));
      acts.appendChild(mk('btn-ghost key-copy', '📋', async () => { try { const x = await App.api('/api/apikeys/' + k.id + '/reveal'); App.copyText(x.key, 'המפתח הועתק'); } catch (e) { App.toast('❌ ' + e.message, 4000); } }, 'העתק את המפתח המלא'));
      acts.appendChild(mk('btn-ghost key-edit', '✏️', async () => {
        const n = await App.prompt('שם המפתח:', k.name || '', { title: 'עריכת מפתח' }); if (n === null) return;
        const a = await App.prompt('לאיזה חשבון המפתח שייך:', k.account || '', { title: 'עריכת מפתח' }); if (a === null) return;
        try { await App.api('/api/apikeys/' + k.id, { method: 'PATCH', body: { name: n.trim(), account: a.trim() } }); flash('נשמר'); } catch (e) { App.toast('❌ ' + e.message, 4000); }
        go('account');
      }, 'שינוי שם / חשבון'));
      acts.appendChild(mk('btn-ghost key-test', '🧪', async ev => { const b = ev.currentTarget; b.disabled = true; try { const t = await App.api('/api/apikeys/' + k.id + '/test', { method: 'POST', body: {} }); App.toast(t.ok ? '✅ המפתח עובד' : '❌ ' + t.error, 4000); } catch (e) { App.toast('❌ ' + e.message, 4000); } b.disabled = false; }, 'בדוק שהמפתח עובד'));
      acts.appendChild(mk('btn-ghost key-del', '🗑️', async () => {
        if (!(await App.confirm('למחוק את המפתח "' + (k.name || k.preview) + '"?', { danger: true, okText: 'מחק' }))) return;
        try { const x = await App.api('/api/apikeys/' + k.id, { method: 'DELETE' }); flash(x.activated ? 'נמחק · בשימוש עכשיו: ' + x.activated : 'נמחק'); await App.loadConfig(); } catch (e) { App.toast('❌ ' + e.message, 4000); }
        go('account');
      }, 'מחק'));
      row.appendChild(acts); list.appendChild(row);
    }
    const add = el('div', 'key-add');
    const nm = el('input', 'text-input key-in-name'); nm.placeholder = 'שם (למשל: עבודה)';
    const ac = el('input', 'text-input key-in-acct'); ac.placeholder = 'חשבון (למשל: zivitamar011)';
    const kv = el('input', 'text-input key-in-key'); kv.type = 'password'; kv.placeholder = 'sk-ant-...'; kv.dir = 'ltr'; kv.autocomplete = 'off';
    const ab = mk('btn-primary key-add-btn', '➕ שמור מפתח', async () => {
      if (!kv.value.trim()) { App.toast('הדבק מפתח'); return; }
      try { await App.api('/api/apikeys', { method: 'POST', body: { key: kv.value.trim(), name: nm.value.trim(), account: ac.value.trim() } }); flash('המפתח נשמר'); await App.loadConfig(); await App.loadModels(true); } catch (e) { App.toast('❌ ' + e.message, 4000); return; }
      go('account');
    });
    add.append(nm, ac, kv, ab); sec.appendChild(add); box.appendChild(sec);
    const sec2 = section('💰 תקציב');
    const budget = el('input', 'text-input'); budget.type = 'number'; budget.min = 0; budget.step = 1; budget.dir = 'ltr'; budget.placeholder = 'לדוגמה: 50'; budget.value = cfg().creditBudgetUSD || '';
    budget.onchange = () => save({ creditBudgetUSD: parseFloat(budget.value) || 0 });
    sec2.appendChild(field('כמה $ טענת לחשבון הטוקנים', budget, 'משמש לחישוב "כמה נשאר" בבר העליון.'));
    box.appendChild(sec2);
  }
  const planLabel = s => { const m = String(s.tier || '').match(/(\d+x)\b/i); const p = s.plan ? s.plan[0].toUpperCase() + s.plan.slice(1) : 'Claude'; return p + (m ? ' · ' + m[1].toLowerCase() : ''); };

  async function startLogin(box, o = {}) {
    box.hidden = false; box.innerHTML = '<div class="st-loading">מפעיל כניסה…</div>';
    try { const l = await App.api(o.add ? '/api/accounts/add' : '/api/account/login', { method: 'POST', body: { provider: 'claudeai' } }); window.__activeLogin = o.add ? { id: l.id, add: true } : l.id; watchLogin(box, l.id, o); }
    catch (e) { box.innerHTML = `<div class="notice error">❌ ${esc(e.message)}</div>`; }
  }
  function watchLogin(box, id, o) {
    const B = o.add ? '/api/accounts/add/' : '/api/account/login/';
    box.hidden = false; box.innerHTML = '';
    const head = el('div', 'lf-head', '<span class="spin">✳</span> <b>אשר בחלון Chrome שנפתח — החזרה אוטומטית</b>');
    const status = el('div', 'lf-status', 'ממתין לאימות בדפדפן…');
    const more = el('details', 'lf-more'); more.innerHTML = '<summary>הדפדפן לא נפתח, או מבקש להדביק קוד?</summary>';
    const urlRow = el('div', 'row'); const urlIn = el('input', 'text-input'); urlIn.readOnly = true; urlIn.dir = 'ltr'; urlIn.placeholder = 'הקישור יופיע כאן…';
    const copy = el('button', 'btn-ghost', 'העתק קישור'); const opn = el('button', 'btn-ghost', 'פתח בדפדפן');
    urlRow.append(urlIn, copy, opn);
    const codeRow = el('div', 'row'); const codeIn = el('input', 'text-input'); codeIn.placeholder = 'הדבק כאן קוד אימות (רק אם ביקשו)'; codeIn.dir = 'ltr'; const codeBtn = el('button', 'btn-primary', 'שלח קוד');
    codeBtn.onclick = async () => { if (codeIn.value.trim()) { await App.api(B + id + '/code', { method: 'POST', body: { code: codeIn.value.trim() } }); codeIn.value = ''; App.toast('הקוד נשלח'); } };
    codeRow.append(codeIn, codeBtn); more.append(urlRow, codeRow);
    const cancel = el('button', 'btn-ghost', 'בטל כניסה'); cancel.onclick = async () => { await App.api(B + id + '/cancel', { method: 'POST', body: {} }); stop(); box.hidden = true; window.__activeLogin = null; };
    box.append(head, status, more, cancel);
    let url = null; copy.onclick = () => url && App.copyText(url, 'הקישור הועתק'); opn.onclick = () => url && window.open(url, '_blank', 'noopener');
    const t0 = Date.now();
    clearInterval(loginPoll);
    const stop = () => { clearInterval(loginPoll); loginPoll = null; };
    loginPoll = setInterval(async () => {
      let l; try { l = await App.api(B + id); } catch { stop(); return; }
      if (l.url && !url) { url = l.url; urlIn.value = l.url; }
      status.textContent = `ממתין לאימות בדפדפן… ${fmt.clock(Date.now() - t0)}`;
      if (l.status === 'success') {
        stop(); window.__activeLogin = null; await App.loadConfig(); App.state.models = []; await App.loadModels(true); App.usage && App.usage.refresh(true);
        if (o.add && l.importError) App.toast('❌ ' + l.importError, 6000); else App.toast((o.add ? '✅ נוסף: ' : '✅ התחברת כ-') + ((l.imported && l.imported.email) || (l.auth && l.auth.email) || 'החשבון'), 4000); if (o.done) o.done();
      } else if (l.status === 'error' || l.status === 'cancelled') { stop(); window.__activeLogin = null; box.innerHTML = `<div class="notice error">❌ ${esc(l.error || 'הכניסה בוטלה')}</div>`; const again = el('button', 'btn-primary', 'נסה שוב'); again.onclick = () => startLogin(box, o); box.appendChild(again); }
    }, 1000);
  }

  // =========================== שימוש ===========================
  async function pUsage(box) {
    const u = await App.api('/api/usage?refresh=1'); const t = u.usage || {};
    if (u.mode === 'subscription') {
      const sec = section('USAGE'); const sub = u.subscription;
      if (sub && sub.ok && sub.windows.length) {
        for (const w of sub.windows) {
          const used = Math.round(w.utilization), left = Math.max(0, 100 - used), cls = used >= 85 ? 'high' : used >= 60 ? 'mid' : '';
          const r = el('div', 'use-row'); r.innerHTML = `<div class="use-top"><span>${esc(w.label)}</span><b class="${cls === 'high' ? 'hi' : cls}">${used}% בשימוש · נשאר ${left}%</b></div><div class="use-bar"><i class="${cls}" style="width:${Math.max(1, Math.min(100, used))}%"></i></div>${w.resetsAt ? `<small>איפוס ${new Date(w.resetsAt).toLocaleDateString('he-IL', { weekday: 'long', day: 'numeric', month: 'long' })} (${fmt.until(w.resetsAt)})</small>` : ''}`;
          sec.appendChild(r);
        }
      } else sec.appendChild(el('div', 'notice error', 'אין נתונים: ' + esc(u.subscriptionError || 'לא מחובר')));
      const rb = el('button', 'btn-ghost', '⟳ רענן'); rb.onclick = () => go('usage'); sec.appendChild(rb); box.appendChild(sec);
    } else {
      const sec = section('API'); const budget = u.creditBudgetUSD || 0, spent = t.totalCostUSD || 0;
      if (budget > 0) {
        const pct = Math.min(100, spent / budget * 100), cls = pct >= 85 ? 'high' : pct >= 60 ? 'mid' : '';
        const r = el('div', 'use-row'); r.innerHTML = `<div class="use-top"><span>תקציב</span><b class="${cls === 'high' ? 'hi' : cls}">נשאר ${fmt.money(Math.max(0, budget - spent))} מתוך ${fmt.money(budget)}</b></div><div class="use-bar"><i class="${cls}" style="width:${Math.max(1, pct)}%"></i></div>`;
        sec.appendChild(r);
      } else sec.appendChild(el('div', 'use-extra', `נוצל ${fmt.money(spent)} · אפשר להגדיר תקציב בלשונית "חשבון"`));
      const reset = el('button', 'btn-ghost', '🗑️ אפס מונה'); reset.onclick = async () => { if (!(await App.confirm('לאפס את מונה ההוצאה?', { danger: true, okText: 'אפס' }))) return; await App.api('/api/usage/reset', { method: 'POST', body: {} }); App.usage && App.usage.refresh(true); go('usage'); };
      sec.appendChild(reset); box.appendChild(sec);
    }
  }

  // =========================== מודל וחשיבה ===========================
  async function pModel(box) {
    if (!App.state.models.length) await App.loadModels(true);
    const c = cfg(); const sec = section('🤖 מודל — ברירת מחדל לצ\'אט חדש', 'מה שנבחר כאן חל על כל צ\'אט חדש. שינוי מתוך צ\'אט (בכפתור המודל בתיבת הכתיבה) חל רק על אותו צ\'אט.');
    const ms = select([['', '— בחר מודל —'], ...window.ModelMenu.options(App.state.models, c.model || '')], c.model || '', v => { save({ model: v }, 'מודל: ' + App.modelLabel(v)); });
    const rf = el('button', 'btn-ghost', '🔄'); rf.title = 'טען מחדש את רשימת המודלים'; rf.onclick = async () => { await App.loadModels(); go('model'); };
    const row = el('div', 'row'); row.append(ms, rf); sec.appendChild(field('מודל ברירת מחדל', row, 'הרשימה נטענת ישירות מהחשבון שלך, ומתעדכנת לבד — מודל חדש שייצא ייכנס אוטומטית.'));
    sec.appendChild(field('⚙️ Effort', select([['default', 'ברירת מחדל'], ['low', 'Low'], ['medium', 'Medium'], ['high', 'High'], ['xhigh', 'X-High'], ['max', 'Max']], c.effort || 'default', v => save({ effort: v })), 'כמה מאמץ ו"חשיבה" Claude משקיע. גבוה = יסודי יותר, איטי ויקר יותר.'));
    sec.appendChild(field('🧠 חשיבה', select([['auto', 'אוטומטי'], ['on', 'פעיל'], ['off', 'כבוי']], c.thinking === true ? 'on' : c.thinking === false ? 'auto' : (c.thinking || 'auto'), v => save({ thinking: v }))));
    sec.appendChild(toggle('⚡ ULTRACODE', 'מאמץ מקסימלי + חשיבה + עבודת קוד יסודית עם בדיקות. מה שתבחר אחר כך (מאמץ / חשיבה) — זה מה שרץ', () => c.ultracode, v => save(v ? { ultracode: true, thinking: 'on' } : { ultracode: false }).then(() => go('model'))));
    sec.appendChild(toggle('🧠 הצג את החשיבה', 'סיכום המחשבות של Claude, עם שעון שסופר כמה זמן הוא חושב', () => c.showThinking !== false, v => save({ showThinking: v })));
    { const lk = el('button', 'btn-ghost', '🔊 צלילים (סיום עבודה ועוד) — עברו ל"הגדרות › צלילים"'); lk.onclick = () => go('sounds'); sec.appendChild(lk); }
    box.appendChild(sec);
    const sec2 = section('מצב טוקנים (API) בלבד');
    const mt = el('input', 'text-input'); mt.type = 'number'; mt.min = 1024; mt.step = 1024; mt.dir = 'ltr'; mt.value = c.maxTokens || 32000; mt.onchange = () => save({ maxTokens: Math.max(1024, parseInt(mt.value, 10) || 32000) });
    sec2.appendChild(field('📏 מקסימום טוקנים לתשובה', mt));
    sec2.appendChild(toggle('🛡️ מעבר אוטומטי במקרה חסימה', 'כבוי (מומלץ): כשמסנן הבטיחות חוסם, מופיעה הודעה עם כפתור להחלפת מודל. מסומן: המעבר קורה לבד.', () => c.autoFallback === true, v => save({ autoFallback: v })));
    sec2.appendChild(toggle('♾️ שיחה בלי הגבלת אורך', 'כשהשיחה ארוכה מאוד, החלקים הישנים מסוכמים אוטומטית וממשיכים (במנוי Claude Code עושה זאת בעצמו).', () => c.compaction !== false, v => save({ compaction: v })));
    box.appendChild(sec2);
  }

  // =========================== הרשאות וכלים ===========================
  async function pPerms(box) {
    const c = cfg(), sub = c.accountMode === 'subscription';
    const cur = c.permissionMode || (c.autoApprove === false ? 'default' : 'bypassPermissions');
    const sec = section('🛡️ מצב הרשאות — ברירת מחדל לצ\'אט חדש', 'מה Claude מבצע בלי לשאול. חל על כל צ\'אט חדש; הכפתור בתיבת הכתיבה משנה רק את הצ\'אט שבו לחצת.');
    const modes = [['default', '🛡️', 'שאל לפני כל פעולה', 'Claude מבקש אישור לפני הרצת פקודות ועריכת קבצים'], ...(sub ? [['acceptEdits', '✏️', 'אשר עריכות אוטומטית', 'עריכת קבצים בלי לשאול; פקודות עדיין מבקשות אישור'], ['plan', '📝', 'מצב תכנון', 'Claude רק מתכנן ולא משנה כלום עד שתאשר את התוכנית']] : []), ['bypassPermissions', '⚡', 'Auto — גישה מלאה', 'מבצע הכל בלי לשאול']];
    for (const [id, ic, name, desc] of modes) {
      const b = el('button', 'mode-row' + (cur === id ? ' on' : '')); b.innerHTML = `<span class="mi-ic">${ic}</span><span class="mi-body"><b>${name}</b><small>${desc}</small></span>${cur === id ? '<span class="mi-ck">✓</span>' : ''}`;
      b.onclick = async () => { await save({ permissionMode: id, autoApprove: id === 'bypassPermissions' }, 'מצב: ' + name); go('perms'); };
      sec.appendChild(b);
    }
    box.appendChild(sec);
    // 🤝 תקשורת בין Claude-ים (REQUESTS-10): כש-Claude אחד שלך מבקש משהו מ-Claude אחר שלך — כמה סמכות יש לבקשה
    { const trust = c.claudeTrust || 'normal';
      const sc = section('🤝 תקשורת בין Claude-ים', 'כש-Claude אחד שלך מבקש משהו מ-Claude אחר שלך (בצ\'אט אחר או במחשב אחר).');
      const TM = [['open', '🔓', 'פתוח לגמרי — בקשה מ-Claude שלך = בקשה ממך', 'ה-Claude שמקבל מבצע מיד, כאילו אתה כתבת לו — גם מידע רגיש וגם מה שאמרת לו לשמור רק לך. בלי לבקש ממך אישור'], ['normal', '🛡️', 'רגיל — מידע רגיש באישורך', 'עוזרים זה לזה, אבל מה שדורש את ההחלטה או האישור שלך (מידע רגיש, הרשאות) — מחכה לך'], ['approve', '✋', 'כל בקשה באישורך', 'הודעה מ-Claude ל-Claude מגיעה ליעד רק אחרי שאישרת אותה (כרטיס "אשר / דחה" בצ\'אט שאליו היא נשלחה)']];
      for (const [id, ic, name, desc] of TM) {
        const b = el('button', 'mode-row trust-row' + (trust === id ? ' on' : '')); b.dataset.trust = id; b.innerHTML = `<span class="mi-ic">${ic}</span><span class="mi-body"><b>${name}</b><small>${desc}</small></span>${trust === id ? '<span class="mi-ck">✓</span>' : ''}`;
        b.onclick = async () => { await save({ claudeTrust: id }, 'תקשורת בין Claude-ים: ' + name); go('perms'); };
        sc.appendChild(b);
      }
      box.appendChild(sc); }
    if (sub) {
      const sec2 = section('Claude Code', 'במצב מנוי השיחות רצות על Claude Code האמיתי, עם כל הכלים שלו (פקודות, קבצים, חיפוש, רשת, סוכנים, MCP).');
      sec2.appendChild(toggle('טען את ההגדרות של Claude Code', 'CLAUDE.md, שרתי MCP, Skills והרשאות מהקבצים שלך (~/.claude) — כמו ב-VS Code. כבוי = שיחה "נקייה" וקלה יותר.', () => c.cliLoadSettings !== false, v => save({ cliLoadSettings: v })));
      box.appendChild(sec2);
    }
    box.appendChild(chromeSection());
  }

  // =========================== שליטה ב-Chrome שלך (תוסף מקומי) ===========================
  function chromeSection() {
    const sec = section('🌐 שליטה ב-Chrome שלך');
    const p = el('div', 'st-chrome');
    p.innerHTML = `<div class="st-help"><p><b>מה זה?</b> Claude עובד <b>ב-Chrome האמיתי שלך</b> — עם הפרופיל, ההתחברויות והלשוניות הפתוחות שלך (לא Chrome נפרד ולא Chromium) — כמו שאתה גולש: לוחץ, מקליד, גולל, קורא דפים ומצלם. החיבור הוא דרך תוסף קטן שמדבר רק עם האפליקציה במחשב שלך (127.0.0.1). העכבר והמקלדת שלך לא נתפסים.</p>
      <p><b>איך משתמשים?</b> פשוט כותבים לו בצ'אט, למשל: "תיכנס להגדרות הראוטר בלשונית שפתוחה ותבדוק…", או בוחרים "/ שליטה בכרום".</p></div>
      <div class="st-chrome-card"><div class="st-chrome-st">בודק…</div><div class="st-chrome-check" hidden></div></div>
      <div class="st-chrome-steps" hidden><b>התקנה ידנית (אם האוטומטית לא הצליחה):</b><ol>
        <li>ב-Chrome נפתח הדף <code>chrome://extensions</code> — הדלק למעלה מימין <b>"מצב מפתח"</b>.</li>
        <li>לחץ <b>"טעינת פריט לא ארוז"</b> ובחר את התיקייה שנפתחה עכשיו: <code class="st-chrome-dir"></code></li>
        <li>זהו. הסמל של Claude Local יופיע בסרגל התוספים, והסטטוס כאן יהפוך ל"מחובר".</li></ol></div>
      <div class="st-row st-chrome-btns"><button class="btn-primary st-chrome-test" hidden>✔ בדוק שזה עובד</button><button class="btn-primary st-chrome-go">התקן בכרום</button></div>`;
    sec.appendChild(p);
    const st = p.querySelector('.st-chrome-st'), steps = p.querySelector('.st-chrome-steps');
    const paint = async () => {
      try {
        const s = await App.api('/api/chrome-bridge/status');
        p.querySelector('.st-chrome-dir').textContent = s.dir;
        const c0 = (s.connected || [])[0];
        st.innerHTML = c0 ? `<b style="color:var(--ok-text, #7fc78a)">✅ מחובר ל-Chrome שלך</b><small class="ag-dim">Claude יכול לעבוד בו עכשיו · תוסף ${esc(c0.version)}${c0.paused ? ' · מושהה' : ''}</small>` : '<b style="color:var(--err-text, #e5736a)">○ Chrome לא מחובר</b><small class="ag-dim">התוסף לא מותקן, או ש-Chrome סגור</small>';
        const go = p.querySelector('.st-chrome-go');
        if (!go.disabled) { go.textContent = c0 ? '↻ התקן מחדש (רק אם משהו לא עובד)' : 'התקן בכרום'; go.className = c0 ? 'btn-ghost st-chrome-go' : 'btn-primary st-chrome-go'; }
        p.querySelector('.st-chrome-test').hidden = !c0;
        if (c0) steps.hidden = true;
      } catch (e) { st.textContent = e.message; }
    };
    p.querySelector('.st-chrome-test').onclick = async () => {
      const ck = p.querySelector('.st-chrome-check'); ck.hidden = false; ck.textContent = 'בודק…';
      try { const r = await App.api('/api/chrome-bridge/check'); ck.innerHTML = r.ok ? `✅ עובד: Claude רואה עכשיו <b>${r.tabs}</b> לשוניות פתוחות ב-Chrome שלך (בלי לפתוח ובלי לשנות כלום).` : '❌ ' + esc(r.error || 'לא עבד'); }
      catch (e) { ck.textContent = '❌ ' + e.message; }
    };
    p.querySelector('.st-chrome-go').onclick = async () => {
      const b = p.querySelector('.st-chrome-go'); b.disabled = true; b.textContent = 'מתקין ב-Chrome… (כ-10 שניות, בלי לגעת בעכבר)';
      try {
        const r = await App.api('/api/chrome-bridge/install', { method: 'POST', body: {} });
        p.querySelector('.st-chrome-dir').textContent = r.dir;
        if (!r.connected) { steps.hidden = false; st.innerHTML = '<span style="color:var(--err-text, #e5736a)">ההתקנה האוטומטית לא הצליחה</span> <span class="ag-dim">— אפשר לעשות את 3 הצעדים למטה ידנית</span>'; }
      } catch (e) { steps.hidden = false; st.textContent = e.message; }
      b.disabled = false; paint();
    };
    paint(); const iv = setInterval(() => { if (!document.body.contains(p)) return clearInterval(iv); paint(); }, 2000);
    return sec;
  }

  // =========================== תיקיות ופרויקטים ===========================
  async function pFolders(box) {
    const c = cfg(); const sec = section('📂 תיקיית ברירת המחדל (הפרויקט "כללי")', 'התיקייה של הפרויקט "כללי" — שיחות שלא שייכות לפרויקט אחר. כל פרויקט אחר הוא טאב למעלה עם התיקייה שלו.');
    const inp = el('input', 'text-input'); inp.dir = 'ltr'; inp.value = c.workingDir || ''; inp.onchange = () => save({ workingDir: inp.value.trim() });
    const pick = el('button', 'btn-ghost', '📂 בחר…'); pick.onclick = async () => { const r = await App.api('/api/fs/pick-folder', { method: 'POST', body: { initial: inp.value, title: 'תיקיית עבודה ברירת מחדל' } }); if (r && r.path) { inp.value = r.path; save({ workingDir: r.path }); } };
    const row = el('div', 'row'); row.append(inp, pick); sec.appendChild(row); box.appendChild(sec);
    const sec2 = section('📁 פרויקטים', 'פרויקט = תיקייה + השיחות שעובדות עליה. כל פרויקט הוא טאב למעלה (קליק ימני על הטאב: שינוי שם, תיקייה, מחיקה).');
    await App.projects.refresh();
    const list = App.projects.list();
    if (!list.length) sec2.appendChild(el('div', 'st-sub', 'אין עדיין פרויקטים. לחץ "פרויקט חדש".'));
    for (const p of list) {
      const r = el('div', 'proj-row'); r.innerHTML = `<span class="pr-n"><b></b><small dir="ltr"></small></span>`; r.querySelector('b').textContent = p.name; r.querySelector('small').textContent = p.dir;
      const open = el('button', 'btn-ghost', 'פתח'); open.onclick = () => { App.projects.activate(p.id); App.settings.close(); };
      const ren = el('button', 'btn-ghost', '✏️'); ren.onclick = async () => { const n = await App.prompt('שם הפרויקט:', p.name, { title: 'שנה שם' }); if (n && n.trim()) { await App.projects.update(p.id, { name: n.trim() }); go('folders'); } };
      const dir = el('button', 'btn-ghost', '📂'); dir.title = 'החלף תיקייה'; dir.onclick = async () => { const rr = await App.api('/api/fs/pick-folder', { method: 'POST', body: { initial: p.dir } }); if (rr && rr.path) { await App.projects.update(p.id, { dir: rr.path }); go('folders'); } };
      const del = el('button', 'btn-ghost', '🗑️'); del.disabled = !!p.general; if (p.general) del.title = 'אי אפשר למחוק את "כללי"'; del.onclick = async () => { if (!(await App.confirm('למחוק את הפרויקט "' + p.name + '"?\n(השיחות והקבצים נשארים)', { danger: true, okText: 'מחק' }))) return; await App.projects.remove(p.id); go('folders'); };
      r.append(open, ren, dir, del); sec2.appendChild(r);
    }
    const add = el('button', 'btn-primary', '＋ פרויקט חדש'); add.onclick = async () => { const r = await App.api('/api/fs/pick-folder', { method: 'POST', body: { title: 'בחר תיקייה לפרויקט' } }); if (!r || !r.path) return; const n = await App.prompt('שם הפרויקט:', App.baseName(r.path), { title: 'פרויקט חדש' }); if (n === null) return; await App.projects.create({ dir: r.path, name: n.trim() || App.baseName(r.path) }); go('folders'); };
    sec2.appendChild(add); box.appendChild(sec2);
  }

  // =========================== מאגרי הוראות ===========================
  async function pInstr(box) {
    const sec = section('📝 מאגרי הוראות', 'כאן יוצרים ועורכים הוראות. ה-✔ = ברירת המחדל לשיחות. <b>לבחירה לשיחה מסוימת:</b> כפתור "הוראות" בסרגל התחתון של הצ\'אט (אפשר לסמן כמה, וזה חל מיד גם על הסוכנים של השיחה). לדוגמה: "תמיד ענה עד 30 מילים".');
    const listBox = el('div', 'instr-list'); sec.appendChild(listBox);
    async function reload() {
      const r = await App.api('/api/instructions'); listBox.innerHTML = ''; App.emit('instructions:changed');
      if (!r.instructions.length) listBox.appendChild(el('div', 'st-sub', 'אין עדיין הוראות. הוסף אחת למטה.'));
      for (const it of r.instructions) {
        const item = el('div', 'instr-item' + (it.enabled ? ' on' : ''));
        const cb = el('input'); cb.type = 'checkbox'; cb.checked = !!it.enabled; cb.title = 'דלוקה כברירת מחדל לשיחות (לכל שיחה אפשר לבחור אחרת בסרגל התחתון)';
        cb.onchange = async () => { await App.api('/api/instructions', { method: 'POST', body: { id: it.id, enabled: cb.checked } }); reload(); };
        const body = el('div', 'ii-body'); if (it.name) body.appendChild(el('div', 'ii-name', esc(it.name))); const tx = el('div', 'ii-text'); tx.textContent = it.text || ''; body.appendChild(tx);
        body.appendChild(enforcedLine(it));
        const ed = el('button', 'ii-del', '✏️'); ed.title = 'ערוך'; ed.onclick = () => editInstr(it, reload);
        const del = el('button', 'ii-del', '🗑️'); del.title = 'מחק'; del.onclick = async () => { if (!(await App.confirm('למחוק את ההוראה?', { danger: true, okText: 'מחק' }))) return; await App.api('/api/instructions/' + it.id, { method: 'DELETE' }); reload(); };
        item.append(cb, body, ed, del); listBox.appendChild(item);
      }
    }
    await reload();
    // Claude עוד קורא הוראה ששונתה — כשהקריאה מסתיימת, השורה "ההוק אוכף" מתעדכנת
    if (!pInstr._wired) { pInstr._wired = true; App.on('instructions:rules', () => { if (listBox.isConnected) reload(); }); }
    App.api('/api/instructions/rules').then(r => { if (listBox.isConnected && r.instructions.some(i => i.enforcedBy === 'claude')) reload(); }).catch(() => { });
    const add = el('div', 'instr-add'); const nm = el('input'); nm.placeholder = 'שם קצר (לא חובה)'; const tx = el('textarea'); tx.rows = 3; tx.placeholder = 'תוכן ההוראה...';
    const ab = el('button', 'btn-primary', '➕ הוסף הוראה'); ab.onclick = async () => { if (!tx.value.trim()) { App.toast('כתוב תוכן להוראה'); return; } await App.api('/api/instructions', { method: 'POST', body: { name: nm.value.trim(), text: tx.value.trim(), enabled: true } }); nm.value = tx.value = ''; flash('ההוראה נוספה והופעלה'); reload(); };
    add.append(nm, tx, ab); sec.appendChild(add); box.appendChild(sec);
    const sec2 = section('✍️ הוראות אישיות קבועות', 'טקסט חופשי שנשלח תמיד (נשמר כשעוזבים את השדה).');
    const ci = el('textarea', 'text-input'); ci.rows = 4; ci.value = cfg().customInstructions || ''; ci.placeholder = 'לדוגמה: תענה תמיד בקצרה. אני מתכנת Python.'; ci.onchange = () => save({ customInstructions: ci.value });
    sec2.appendChild(ci);
    const pv = el('button', 'btn-ghost', '🔍 הצג מה בדיוק נשלח ל-Claude'); const pvBox = el('pre', 'sys-preview'); pvBox.hidden = true;
    pv.onclick = async () => { const r = await App.api('/api/system-prompt-preview'); pvBox.hidden = false; pvBox.textContent = (r.engine === 'subscription' ? '# מצב מנוי — נוסף להוראות של Claude Code:\n' + r.cliAppend : r.systemPrompt) + '\n\n# הוראות דלוקות (' + r.enabledInstructions.length + '): ' + r.enabledInstructions.map(i => i.name || i.text.slice(0, 20)).join(' | '); };
    sec2.append(pv, pvBox); box.appendChild(sec2);
  }
  // "🛡 ההוק אוכף: …" — מה בדיוק נבדק בכל תשובה, לפי הטקסט הנוכחי של ההוראה (מתעדכן בכל שמירה)
  function enforcedLine(it) {
    const d = el('div', 'ii-enf' + (it.enforced && it.enforced.length ? '' : ' none'));
    d.textContent = it.enforcedPending ? '🛡 ההוק: Claude קורא את ההוראה…' + (it.enforced && it.enforced.length ? ' (בינתיים: ' + it.enforced.join(' · ') + ')' : '')
      : it.enforced && it.enforced.length ? '🛡 ההוק אוכף על כל תשובה: ' + it.enforced.join(' · ') : '🛡 אין בהוראה הזו כלל שאפשר למדוד — ההוק לא חוסם בגללה (Claude עדיין מקבל אותה)';
    d.title = 'ההוק בודק כל תשובה סופית לפני שהיא מוצגת, וחוסם רק לפי מה שכתוב בהוראה. נקרא מחדש בכל פעם שעורכים ושומרים אותה.';
    return d;
  }
  async function editInstr(it, done) {
    const body = el('div', 'confirm-body'); const nm = el('input', 'text-input'); nm.value = it.name || ''; nm.placeholder = 'שם'; const tx = el('textarea', 'text-input'); tx.rows = 6; tx.value = it.text || '';
    const bar = el('div', 'confirm-bar'); const ok = el('button', 'btn-primary', 'שמור'), no = el('button', 'btn-ghost', 'ביטול'); bar.append(no, ok); body.append(nm, tx, bar);
    const m = App.modal({ title: 'עריכת הוראה', body, cls: 'small' }); no.onclick = () => m.close();
    ok.onclick = async () => { await App.api('/api/instructions', { method: 'POST', body: { id: it.id, name: nm.value.trim(), text: tx.value } }); m.close(); flash(); done(); };
  }

  // =========================== סוכנים ומחקר ===========================
  async function pAgents(box) {
    if (!App.state.models.length) await App.loadModels(true).catch(() => { });
    const c = cfg();
    const modelOpts = first => [['', first], ...window.ModelMenu.options(App.state.models, '')]; // (הבעלים 26/11) מסודר לפי משפחה וגרסה, שמות ברורים
    const help = (html) => { const d = el('div', 'st-help'); d.innerHTML = html; return d; };
    // ----- איך זה עובד -----
    const how = section('❓ איך זה עובד — בקצרה');
    how.appendChild(help(`<p><b>🤖 סוכן</b> = עוזר נוסף ש-Claude מפעיל <b>בעצמו</b> כדי לעבוד במקביל על חלק מהמשימה (למשל לחפש בכמה מקומות בבת אחת, או לבדוק כמה קבצים יחד). <b>אתה לא צריך להפעיל אותם</b> — Claude מחליט לבד. כאן קובעים רק <b>באיזה מודל</b> הם עובדים ו<b>כמה</b> מותר בבת אחת.</p>
      <p>👀 רואים כל סוכן שרץ בשבב <b>"סוכנים"</b> שבתיבת הכתיבה ובלשונית <b>"סוכנים"</b> בחלונית הימנית — שם אפשר גם לעצור אותו.</p>
      <p><b>🔬 מחקר מעמיק</b> = לוחצים על ＋ ← "מחקר מעמיק" בתיבת הכתיבה (או "מחקר חדש" בלשונית "מחקר"). Claude מפרק את השאלה לנושאים, מפעיל חוקר לכל נושא, מחפש ברשת מקורות רבים, ובסוף כותב דוח עם סיכום ורשימת מקורות.</p>`));
    box.appendChild(how);
    // ----- סוכנים -----
    const sec = section('🤖 סוכנים');
    sec.appendChild(field('מודל לסוכנים', select(modelOpts('כמו השיחה (ברירת מחדל)'), c.agentModel || '', v => save({ agentModel: v }, v ? 'הסוכנים יעבדו עם ' + App.modelLabel(v) : 'הסוכנים יעבדו עם המודל של השיחה')), 'עובד גם במנוי: חל על כל סוכן ש-Claude מפעיל מעכשיו.'));
    sec.appendChild(help('<small>💡 <b>Haiku</b> = הכי מהיר וחוסך מהמנוי — טוב לחיפושים ובדיקות. <b>Opus</b> = הכי חכם — למשימות קשות. "כמו השיחה" = אותו מודל שבחרת בצ\'אט.</small>'));
    const mp = el('input', 'text-input'); mp.type = 'number'; mp.min = 1; mp.max = 16; mp.dir = 'ltr'; mp.value = c.maxParallelAgents || 4; mp.style.width = '90px';
    mp.onchange = () => { const n = Math.max(1, Math.min(16, parseInt(mp.value, 10) || 4)); mp.value = n; save({ maxParallelAgents: n }, 'עד ' + n + ' סוכנים במקביל'); };
    sec.appendChild(field('כמה סוכנים במקביל (מקסימום)', mp, 'אם Claude ינסה להפעיל יותר — הסוכן הנוסף ימתין עד שאחד מסיים.'));
    sec.appendChild(help('<small>💡 אם Claude ינסה להפעיל יותר מזה בבת אחת — האפליקציה תעצור את הסוכן העודף ותגיד ל-Claude לחכות שאחד יסיים. פחות = חוסך מהמנוי; יותר = מהיר יותר.</small>'));
    const live = el('div', 'st-sub'); sec.appendChild(live);
    const paintLive = async () => { try { const r = await App.api('/api/agents'); const run = (r.agents || []).filter(a => a.status === 'running'); live.textContent = run.length ? `🟢 עכשיו רצים ${run.length} סוכנים: ` + run.slice(0, 4).map(a => a.description || 'סוכן').join(' · ') : '⚪ עכשיו לא רץ אף סוכן.'; } catch { live.textContent = ''; } };
    paintLive(); const iv = setInterval(() => { if (!document.body.contains(live)) return clearInterval(iv); paintLive(); }, 3000);
    box.appendChild(sec);
    // ----- מחקר -----
    const sec2 = section('🔬 מחקר מעמיק');
    sec2.appendChild(field('עומק ברירת מחדל', select([['quick', '⚡ מהיר — 2 נושאים, כמה דקות'], ['standard', '📚 רגיל — 4 נושאים'], ['deep', '🔭 עמוק — 6 נושאים, הכי יסודי']], c.researchDepth || 'standard', v => save({ researchDepth: v }, 'עומק מחקר: ' + ({ quick: 'מהיר', standard: 'רגיל', deep: 'עמוק' })[v])), 'אפשר לשנות לכל מחקר בנפרד בתגית שמופיעה מעל תיבת הכתיבה.'));
    sec2.appendChild(field('מודל למחקר חדש', select(modelOpts('כמו השיחה (ברירת מחדל)'), c.researchModel || '', v => save({ researchModel: v }, v ? 'מחקר חדש יתחיל עם ' + App.modelLabel(v) : 'מחקר חדש — המודל של השיחה')), 'ברירת המחדל בחלון "מחקר חדש" (אפשר לבחור אחר בחלון עצמו). מחקר מתוך צ\'אט רץ על המודל של הצ\'אט.'));
    sec2.appendChild(help('<small>💡 מינימום / מקסימום מקורות ונושאים מכוונים בחלון "מחקר חדש" בלשונית "מחקר".</small>'));
    box.appendChild(sec2);
  }

  // =========================== 💬 צ'אט: איך השיחה נראית ומתנהגת (נשמר במחשב שלך, חל מיד על כל השיחות) ===========================
  const FONTS = ['Segoe UI', 'Arial', 'Tahoma', 'Calibri', 'David', 'Miriam', 'Narkisim', 'Gisha', 'Aharoni', 'Rubik', 'Heebo', 'Assistant', 'Noto Sans Hebrew', 'Frank Ruehl CLM'];
  const CODE_FONTS = ['Cascadia Code', 'Cascadia Mono', 'Consolas', 'JetBrains Mono', 'Fira Code', 'Courier New', 'Lucida Console'];
  // האם גופן מותקן במחשב: מודדים טקסט בעברית ובאנגלית מול גופן ברירת מחדל
  const fontInstalled = (() => { let ctx; return name => { try { ctx = ctx || document.createElement('canvas').getContext('2d'); const t = 'אבגדה שלום ABCxyz 0123'; return ['monospace', 'serif'].some(fb => { ctx.font = `40px ${fb}`; const w0 = ctx.measureText(t).width; ctx.font = `40px "${name}", ${fb}`; return Math.abs(ctx.measureText(t).width - w0) > 0.5; }); } catch { return true; } }; })();
  function pChat(box) {
    const D = App.chatUiDefaults; let u = App.chatUi();
    const set = async (patch, msg) => {
      u = { ...u, ...patch };
      if ('showThinking' in patch) { const { showThinking, ...rest } = patch; await save({ showThinking }, msg); if (!Object.keys(rest).length) { paintPreview(); return; } }
      const out = {}; for (const k of Object.keys(D)) out[k] = u[k];
      await save({ chatUi: out }, msg); paintPreview();
    };
    // ----- תצוגה מקדימה חיה (אותם רכיבים בדיוק כמו בשיחה) -----
    const pv = section('👁 תצוגה מקדימה'); const prev = el('div', 'cu-preview'); pv.appendChild(prev); box.appendChild(pv);
    function paintPreview() {
      const now = Date.now(), t0 = now - 47000, t1 = now - 31000;
      const sample = 'בדקתי את הקובץ ותיקנתי את הבאג.\n\n**מה שונה:** הפונקציה `average` מחזירה עכשיו `null` למערך ריק.';
      const qa = ':::qa\n### מה גרם לבאג?\nחלוקה באפס כשהמערך ריק.\n### איך בודקים שזה תוקן?\nמריצים `npm test` — כל הבדיקות עוברות.\n:::';
      prev.innerHTML = `<div class="msg user"><div class="user-wrap"><div class="body">תבדוק בבקשה למה הממוצע נשבר, ותענה לי על שתי שאלות</div><div class="msg-time">🕒 ${esc(fmt.time(t0))}</div></div></div>
        <div class="msg assistant had-tools"><div class="avatar">✳</div><div class="body">
          <details class="thinking cu-think"><summary><span class="t-title">🧠 חשב</span><span class="t-clock">4 שנ'</span></summary><div class="content">צריך לקרוא את הקובץ ולבדוק מקרה של מערך ריק…</div></details>
          <details class="tool ok has-path"><summary><span class="t-icon">📖</span><span class="t-label">קורא קובץ <code class="path-link" data-path="C:\\project\\src\\math.js"><bdi dir="ltr">C:\\project\\src\\math.js</bdi></code></span><span class="t-time">${esc(fmt.time(t0 + 3000))} · 0 שנ'</span><span class="t-status">✅ בוצע</span></summary><div class="t-detail"></div></details>
          <div class="md">${renderMarkdown('קראתי את הקובץ — הבעיה בשורה 12.')}</div>
          <div class="md final">${renderMarkdown(sample + '\n\n' + qa)}</div>
          <div class="msg-time">🕒 <bdi dir="ltr" class="tm-range">${esc(fmt.time(t0 + 2000))} → ${esc(fmt.time(t1))}</bdi> · 16 שנ'<span class="model-tag">Opus 5.5</span></div>
        </div></div>`;
      const th = prev.querySelector('.cu-think'); if (th) th.hidden = (App.state.config || {}).showThinking === false;
      prev.querySelectorAll('.qa-item').forEach(d => (d.open = true));
    }
    // ----- פקדים -----
    const grid = el('div', 'cu-grid');
    const row = (label, hint, control) => { const l = el('div', 'cu-lbl'); l.textContent = label; if (hint) l.appendChild(el('small', '', esc(hint))); grid.append(l, control); };
    // כפתור בחירה: [ערך, תווית, דוגמה?] — הדוגמה (שעה / מקש) מוצגת משמאל לימין גם בממשק בעברית
    const seg = (key, opts, msgOf, getV) => { const s = el('div', 'cu-seg'); s.dataset.key = key; const cur = getV ? getV() : u[key]; for (const [v, t, ex] of opts) { const b = el('button', String(cur) === String(v) ? 'on' : ''); b.type = 'button'; b.dataset.v = String(v); b.textContent = t; if (ex) { const x = document.createElement('bdi'); x.dir = 'ltr'; x.className = 'cu-ex'; x.textContent = typeof ex === 'function' ? ex() : ex; b.append(' ', x); } b.onclick = () => { s.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); set({ [key]: v }, msgOf ? msgOf(v, t) : t).then(() => { if (key === 'clock' || key === 'seconds') paintExamples(); }); }; s.appendChild(b); } return s; };
    const exT = (h, m, s, clock, secs) => clock === '12' ? `${h % 12 || 12}:${m}${secs ? ':' + s : ''} ${h < 12 ? 'AM' : 'PM'}` : `${h}:${m}${secs ? ':' + s : ''}`;
    const paintExamples = () => box.querySelectorAll('.cu-seg[data-key="seconds"] button').forEach(b => { const x = b.querySelector('.cu-ex'); if (x) x.textContent = exT(14, '05', '09', u.clock, b.dataset.v === 'true'); });
    const sec1 = section('⏰ שעה'), g1 = el('div', 'cu-grid'); sec1.appendChild(g1); box.appendChild(sec1);
    const sec2 = section('🔤 טקסט וגופנים'); sec2.appendChild(grid); box.appendChild(sec2);
    const sec3 = section('🧩 מה רואים בשיחה'), g3 = el('div', 'cu-grid'); sec3.appendChild(g3); box.appendChild(sec3);
    const rowIn = (g, label, hint, control) => { const l = el('div', 'cu-lbl'); l.textContent = label; if (hint) l.appendChild(el('small', '', esc(hint))); g.append(l, control); };
    // שעה
    rowIn(g1, 'תצוגת שעה', 'בכל המערכת: צ\'אט, כרטיסי כלים, רשימת השיחות, מעקבים, קבצים', seg('clock', [['24', '24 שעות', '14:05'], ['12', '12 שעות', '2:05 PM']], v => v === '12' ? 'שעה: AM / PM' : 'שעה: 24 שעות'));
    rowIn(g1, 'שניות', null, seg('seconds', [[true, 'עם שניות', () => exT(14, '05', '09', u.clock, true)], [false, 'בלי שניות', () => exT(14, '05', '09', u.clock, false)]], v => v ? 'השעה מוצגת עם שניות' : 'השעה בלי שניות'));
    // טקסט וגופנים
    const fs = el('select', 'cu-font'); fs.dataset.key = 'font';
    fs.appendChild(Object.assign(el('option'), { value: '', textContent: 'ברירת המחדל של המערכת' }));
    for (const f of FONTS) { const o = el('option'); o.value = f; const ok = fontInstalled(f); o.textContent = f + (ok ? '' : ' (לא מותקן במחשב)'); o.disabled = !ok; o.style.fontFamily = `"${f}"`; fs.appendChild(o); }
    fs.value = u.font || ''; fs.onchange = () => set({ font: fs.value }, 'גופן: ' + (fs.value || 'ברירת מחדל'));
    row('גופן הצ\'אט', 'ההודעות שלך, התשובות ותיבת הכתיבה', fs);
    const sz = el('div', 'cu-range'), szIn = el('input'), szB = el('b'); szIn.type = 'range'; szIn.min = 12; szIn.max = 22; szIn.step = 0.5; szIn.value = u.size; szIn.dataset.key = 'size'; szB.textContent = u.size + 'px';
    szIn.oninput = () => { szB.textContent = szIn.value + 'px'; document.documentElement.style.setProperty('--chat-size', szIn.value + 'px'); };
    szIn.onchange = () => set({ size: Number(szIn.value) }, 'גודל טקסט: ' + szIn.value + 'px'); sz.append(szIn, szB);
    row('גודל הטקסט', null, sz);
    row('ריווח שורות', null, seg('lineHeight', [['tight', 'צפוף'], ['normal', 'רגיל'], ['airy', 'מרווח']], (v, t) => 'ריווח שורות: ' + t));
    row('רוחב השיחה', 'כמה רחבות ההודעות על המסך', seg('width', [['narrow', 'צר'], ['normal', 'רגיל'], ['wide', 'רחב'], ['full', 'כל הרוחב']], (v, t) => 'רוחב: ' + t));
    const cf = el('select', 'cu-font'); cf.dataset.key = 'codeFont';
    cf.appendChild(Object.assign(el('option'), { value: '', textContent: 'ברירת המחדל (Cascadia / Consolas)' }));
    for (const f of CODE_FONTS) { const o = el('option'); o.value = f; const ok = fontInstalled(f); o.textContent = f + (ok ? '' : ' (לא מותקן)'); o.disabled = !ok; cf.appendChild(o); }
    cf.value = u.codeFont || ''; cf.onchange = () => set({ codeFont: cf.value }, 'גופן קוד: ' + (cf.value || 'ברירת מחדל'));
    row('גופן קוד ונתיבים', 'בלוקי קוד, פקודות, נתיבי קבצים', cf);
    // מה רואים
    rowIn(g3, 'כרטיסי כלים', 'קומפקטי = שורה דקה לכל פעולה של Claude', seg('tools', [['normal', 'רגיל'], ['compact', 'קומפקטי']], (v, t) => 'כרטיסי כלים: ' + t));
    rowIn(g3, 'חשיבה של Claude', null, seg('showThinking', [[true, 'הצג'], [false, 'הסתר']], v => v ? 'החשיבה מוצגת' : 'החשיבה מוסתרת', () => (App.state.config || {}).showThinking !== false));
    rowIn(g3, 'שורת זמן מתחת לתשובה', 'שעה, משך, מודל וטוקנים', seg('footer', [[true, 'הצג'], [false, 'הסתר']], v => v ? 'שורת הזמן מוצגת' : 'שורת הזמן מוסתרת'));
    rowIn(g3, 'הסיכום של Claude', 'הטקסט האחרון בכל תשובה — אחרי כל הכלים', seg('summary', [['none', 'רגיל'], ['bubble', 'בבועה'], ['highlight', 'רקע מודגש']], (v, t) => 'סיכום: ' + t));
    rowIn(g3, 'חלון שאלות ותשובות', 'כש-Claude עונה על כמה שאלות — כל שאלה ותשובה בכרטיס נוח לקריאה', seg('qaBox', [[true, 'פועל'], [false, 'כבוי']], v => v ? 'שאלות ותשובות: בחלון ייעודי' : 'שאלות ותשובות: טקסט רגיל'));
    rowIn(g3, 'שליחת הודעה', 'הצירוף השני יורד שורה (Shift+Enter / Enter)', seg('enter', [['enter', 'שליחה ב-', 'Enter'], ['ctrl', 'שליחה ב-', 'Ctrl+Enter']], v => v === 'ctrl' ? 'Ctrl+Enter שולח · Enter יורד שורה' : 'Enter שולח · Shift+Enter יורד שורה'));
    const rs = el('button', 'btn-ghost cu-reset', '↺ החזר את כל הגדרות הצ\'אט לברירת המחדל');
    rs.onclick = async () => { await save({ chatUi: { ...D }, showThinking: true }, 'הגדרות הצ\'אט חזרו לברירת המחדל'); go('chat'); };
    box.appendChild(rs);
    paintPreview();
  }

  // =========================== ערכת נושא + הצבעים של ההודעות שלי ===========================
  function pTheme(box) {
    const T = App.theme, KIND = { dark: 'כהה', light: 'בהירה', hc: 'נגישות' };
    const sec = section('🎨 ערכת נושא');
    sec.appendChild(el('p', 'um-note', 'לחיצה על ערכה מחליפה מיד את המראה של כל המערכת — ונשמרת גם לפעם הבאה, בתוכנה ובדפדפן.'));
    const grid = el('div', 'th-grid');
    for (const t of T.list) {
      const b = el('button', 'th-card'); b.type = 'button'; b.dataset.themePick = t.id; b.title = t.desc;
      b.innerHTML = `<div class="th-prev" data-theme="${t.id}" aria-hidden="true"><div class="tp-top"><i></i></div><div class="tp-side"><b></b><b></b><b></b></div><div class="tp-main"><span class="tp-user">ההודעה שלי</span><span class="tp-line"></span><span class="tp-line s"></span><div class="tp-code"><span class="k">const</span> a = <span class="s">"hi"</span>; <span class="n">42</span></div><span class="tp-btn">שלח</span></div></div>`
        + `<div class="th-name"><span>${esc(t.name)}</span><span class="th-ck">✓</span></div><div class="th-kind">${KIND[t.kind] || ''} · ${esc(t.desc)}</div>`;
      b.onclick = () => { T.apply(t.id); mark(); colors.refresh(); types.refresh(); };
      grid.appendChild(b);
    }
    const mark = () => grid.querySelectorAll('.th-card').forEach(c => { const on = c.dataset.themePick === T.current(); c.classList.toggle('on', on); c.setAttribute('aria-pressed', String(on)); c.querySelector('.th-ck').hidden = !on; });
    sec.appendChild(grid); box.appendChild(sec); mark();
    const colors = userColorsSection(); box.appendChild(colors.sec);
    const types = typeColorsSection(colors); box.appendChild(types.sec);
    colors.onChange = () => types.refresh();
  }
  // הודעות שאינן שלך (Claude אחר · מנוע המחקר · תזרים · סבב מעקב): לכל סוג צבע משלו — ברירת מחדל שונה לכל סוג, ואפשר לשנות רקע וטקסט
  function typeColorsSection() {
    const T = App.theme, sec = section('🎨 צבעי הודעות שאינן שלך');
    sec.dataset.mtSection = '1';
    sec.appendChild(el('p', 'um-note', 'הודעות שנכנסות לשיחה בלי שכתבת אותן — מ-Claude בשיחה אחרת, ממנוע המחקר כשמחקר מסתיים, משלב בתזרים, או מסבב של מעקב. לכל סוג צבע משלו ותווית שאומרת ממי ולמה, כך שאי אפשר לבלבל אותן עם ההודעות שלך. אי אפשר לערוך אותן ולשלוח מחדש כאילו הן שלך. הבחירה נשמרת לכל ערכת נושא בנפרד.'));
    const cards = [];
    for (const mt of T.msgTypes) {
      const card = el('div', 'mt-card'); card.dataset.mt = mt.id;
      card.appendChild(el('div', 'mt-name', esc(mt.name)));
      const demo = el('div', 'um-demo mt-demo');
      demo.innerHTML = mt.id === 'watch'
        ? `<div class="msg user watch-msg watch-round mt-watch"><div class="user-wrap"><div class="body" style="max-width:100%"><span class="watch-pill"><span class="wp-ic">⏱</span><span class="wp-t">${esc('הודעה אוטומטית ממעקב W1 «שומר» · סבב 3 — לא ממך')}</span></span></div></div></div>`
        : `<div class="msg user mt-${mt.id}"><div class="user-wrap"><div class="body" style="max-width:100%"><div class="from-pill${mt.id === 'claude' ? ' from-claude-pill' : ''}">${esc(mt.id === 'research' ? '🔬 הודעה אוטומטית ממנוע המחקר — לא ממך · מחקר שהפעלת הסתיים, ו-Claude ממשיך איתו' : mt.id === 'flow' ? '⚙ הודעה אוטומטית מתזרים "דוגמה" — לא ממך · שלב 2/5 — בדיקה' : '🤖 הודעה מ-Claude אחר — לא ממך · שיחה A123')}</div>${esc(mt.sample)}</div></div></div>`;
      card.appendChild(demo);
      const mkRow = (label, key) => {
        const r = el('div', 'um-row'); r.appendChild(el('span', 'um-lbl', label));
        const pk = el('label', 'um-pick'), inp = el('input'), hex = el('input', 'um-hex'), def = el('span', 'um-def', 'ברירת המחדל של הסוג');
        inp.type = 'color'; inp.dataset.mtPick = mt.id + ':' + key; inp.title = mt.name + ' — ' + label;
        hex.maxLength = 7; hex.spellcheck = false; hex.dir = 'ltr'; hex.dataset.mtHex = mt.id + ':' + key; hex.setAttribute('aria-label', mt.name + ' — ' + label + ' — קוד צבע');
        pk.append(inp, hex, def); r.appendChild(pk);
        const set = (v, persist) => { const cur = T.typeColors(mt.id); cur[key] = v; T.setTypeColors(mt.id, cur, { persist }); refresh(); };
        inp.oninput = () => set(inp.value, false); inp.onchange = () => set(inp.value, true);
        hex.onchange = () => { let v = hex.value.trim(); if (/^[0-9a-f]{6}$/i.test(v)) v = '#' + v; if (/^#[0-9a-f]{6}$/i.test(v)) set(v.toLowerCase(), true); else refresh(); };
        return { r, inp, hex, def };
      };
      const rb = mkRow('🎨 רקע', 'bg'), rt = mkRow('🔤 טקסט', 'text');
      const pr = el('div', 'um-presets'), cbox = el('div', 'um-contrast'), bar = el('div', 'acct-actions');
      const reset = el('button', 'btn-ghost', '↺ איפוס לברירת המחדל'); reset.dataset.mtReset = mt.id;
      reset.onclick = () => { T.setTypeColors(mt.id, null); refresh(); App.toast('✅ ' + mt.name + ': חזר לצבע ברירת המחדל', 1400); };
      bar.appendChild(reset); card.append(rb.r, rt.r, pr, cbox, bar); sec.appendChild(card);
      function refresh() {
        const e = T.typeEffective(mt.id), cur = T.typeColors(mt.id), me = T.userEffective();
        for (const [row, key] of [[rb, 'bg'], [rt, 'text']]) { row.inp.value = e[key]; if (document.activeElement !== row.hex) row.hex.value = e[key]; row.def.hidden = !!cur[key]; }
        reset.disabled = !cur.bg && !cur.text;
        pr.innerHTML = '';
        for (const [name, bg, text, isDef] of [['ברירת המחדל', e.defBg, e.defText, true], ...T.presets().map(([n, b, t]) => [n, b, t, false])]) {
          const b = el('button', 'um-preset'); b.type = 'button'; b.textContent = name; b.style.background = bg; b.style.color = text; b.dataset.mtPreset = mt.id + ':' + (isDef ? 'default' : name);
          b.classList.toggle('on', isDef ? (!cur.bg && !cur.text) : (cur.bg === bg && cur.text === text));
          b.title = `${bg} / ${text} · ניגודיות ${T.contrast(bg, text).toFixed(1)}:1`;
          b.onclick = () => { T.setTypeColors(mt.id, isDef ? null : { bg, text }); refresh(); };
          pr.appendChild(b);
        }
        const ratio = e.ratio, good = ratio >= 4.5, dE = T.deltaE(e.bg, me.bg), same = e.bg === me.bg, near = dE < 10;
        cbox.className = 'um-contrast ' + (good && !near ? 'ok' : 'bad'); cbox.dataset.ratio = ratio.toFixed(2); cbox.dataset.same = same ? '1' : near ? 'near' : '0'; cbox.dataset.de = dE.toFixed(1);
        cbox.innerHTML = (good ? `✓ ניגודיות <b>${ratio.toFixed(1)}:1</b> — ${ratio >= 7 ? 'מצוינת (AAA)' : 'טובה (AA)'}` : `⚠️ ניגודיות נמוכה: <b>${ratio.toFixed(1)}:1</b> — מומלץ לפחות 4.5:1.`)
          + (same ? ' · ⚠️ זה בדיוק הרקע של ההודעות שלך — יהיה קשה להבדיל ביניהן' : near ? ' · ⚠️ קרוב מאוד לרקע של ההודעות שלך — קשה להבדיל ביניהן' : '');
      }
      cards.push(refresh); refresh();
    }
    return { sec, refresh: () => cards.forEach(f => f()) };
  }
  function userColorsSection() {
    const T = App.theme, sec = section('💬 הצבעים של ההודעות שלי');
    sec.appendChild(el('p', 'um-note', 'רקע וצבע טקסט להודעות שאתה שולח ל-Claude — כדי לזהות אותן מיד בשיחה. הבחירה חלה מיד על כל השיחות, ונשמרת לכל ערכת נושא בנפרד.'));
    const demo = el('div', 'um-demo');
    demo.innerHTML = `<div class="msg user"><div class="user-wrap"><div class="body" style="max-width:100%">ככה תיראה ההודעה שלי בצ'אט 👋</div></div></div><div class="msg assistant"><div class="avatar">✳</div><div class="body"><div class="md"><p>וזו תשובה של Claude, לצורך השוואה.</p></div></div></div>`;
    sec.appendChild(demo);
    const mkRow = (label, key) => {
      const r = el('div', 'um-row'); r.appendChild(el('span', 'um-lbl', label));
      const pk = el('label', 'um-pick'), inp = el('input'), hex = el('input', 'um-hex'), def = el('span', 'um-def', 'ברירת המחדל של הערכה');
      inp.type = 'color'; inp.dataset.um = key; inp.title = label;
      hex.maxLength = 7; hex.spellcheck = false; hex.dir = 'ltr'; hex.dataset.umHex = key; hex.setAttribute('aria-label', label + ' — קוד צבע');
      pk.append(inp, hex, def); r.appendChild(pk);
      const set = (v, persist) => { const cur = T.userColors(); cur[key] = v; T.setUserColors(cur, { persist }); refresh(); if (api.onChange) api.onChange(); };
      inp.oninput = () => set(inp.value, false); inp.onchange = () => set(inp.value, true);
      hex.onchange = () => { let v = hex.value.trim(); if (/^[0-9a-f]{6}$/i.test(v)) v = '#' + v; if (/^#[0-9a-f]{6}$/i.test(v)) set(v.toLowerCase(), true); else refresh(); };
      return { r, inp, hex, def };
    };
    const rb = mkRow('🎨 רקע', 'bg'), rt = mkRow('🔤 טקסט', 'text');
    const pr = el('div', 'um-presets'), cbox = el('div', 'um-contrast'), bar = el('div', 'acct-actions');
    const reset = el('button', 'btn-ghost', '↺ איפוס לברירת המחדל של הערכה'); reset.dataset.umReset = '1';
    reset.onclick = () => { T.setUserColors(null); refresh(); App.toast('✅ ההודעות שלך חזרו לצבעי הערכה', 1400); };
    bar.appendChild(reset); sec.append(rb.r, rt.r, el('div', 'st-lbl', 'צבעים מוכנים (מתאימים לערכה הנוכחית)'), pr, cbox, bar);
    function refresh() {
      const e = T.userEffective(), cur = T.userColors();
      for (const [row, key] of [[rb, 'bg'], [rt, 'text']]) { row.inp.value = e[key]; if (document.activeElement !== row.hex) row.hex.value = e[key]; row.def.hidden = !!cur[key]; }
      reset.disabled = !cur.bg && !cur.text;
      pr.innerHTML = '';
      for (const [name, bg, text, isDef] of [['ברירת המחדל', e.defBg, e.defText, true], ...T.presets().map(([n, b, t]) => [n, b, t, false])]) {
        const b = el('button', 'um-preset'); b.type = 'button'; b.textContent = name; b.style.background = bg; b.style.color = text; b.dataset.umPreset = isDef ? 'default' : name;
        b.classList.toggle('on', isDef ? (!cur.bg && !cur.text) : (cur.bg === bg && cur.text === text));
        b.title = `${bg} / ${text} · ניגודיות ${T.contrast(bg, text).toFixed(1)}:1`;
        b.onclick = () => { T.setUserColors(isDef ? null : { bg, text }); refresh(); if (api.onChange) api.onChange(); };
        pr.appendChild(b);
      }
      const ratio = e.ratio, good = ratio >= 4.5;
      cbox.className = 'um-contrast ' + (good ? 'ok' : 'bad'); cbox.dataset.ratio = ratio.toFixed(2);
      cbox.innerHTML = good ? `✓ ניגודיות <b>${ratio.toFixed(1)}:1</b> — ${ratio >= 7 ? 'מצוינת (AAA), קל מאוד לקרוא' : 'טובה (AA), קריא'}`
        : `⚠️ ניגודיות נמוכה: <b>${ratio.toFixed(1)}:1</b> — הטקסט יהיה קשה לקריאה. מומלץ לפחות 4.5:1 (ועדיף 7:1).`;
    }
    refresh();
    const api = { sec, refresh };
    return api;
  }

  // =========================== מערכת ===========================
  async function pSystem(box) {
    const s = App.state.system || await App.api('/api/system').catch(() => ({}));
    const sec = section('ℹ️ מערכת');
    sec.appendChild(el('div', 'sys-grid', `<div><small>מחשב</small><b>${esc(s.host || '')}</b></div><div><small>משתמש</small><b>${esc(s.user || '')}</b></div><div><small>מערכת הפעלה</small><b>${esc(s.os || '')}</b></div><div><small>Node</small><b>${esc(s.node || '')}</b></div><div><small>תיקיית הבית</small><b dir="ltr">${esc(s.home || '')}</b></div><div><small>שולחן עבודה</small><b dir="ltr">${esc(s.desktop || '')}</b></div><div><small>אפליקציה</small><b>${App.isDesktop() ? 'תוכנה (EXE)' : 'דפדפן'}</b></div>`));
    const rs = el('button', 'btn-ghost', '🔄 הפעל מחדש את השרת'); rs.onclick = async () => { if (!(await App.confirm('להפעיל מחדש את השרת? שיחות שרצות ייעצרו. הדף ייטען מחדש לבד.', { okText: 'הפעל מחדש' }))) return; try { await App.api('/api/restart', { method: 'POST', body: {} }); } catch { } document.body.innerHTML = '<div style="height:100vh;display:flex;align-items:center;justify-content:center;font-size:20px;color:var(--text);background:var(--bg)">מאתחל את השרת…</div>'; const t0 = Date.now(); const poll = setInterval(async () => { try { await fetch('/api/config', { cache: 'no-store' }); clearInterval(poll); location.reload(); } catch { if (Date.now() - t0 > 40000) clearInterval(poll); } }, 1000); };
    const sd = el('button', 'btn-ghost danger', '⏻ כבה'); sd.onclick = async () => { if (!(await App.confirm('לכבות את הצ\'אט? שיחות שרצות ייעצרו.', { danger: true, okText: 'כבה' }))) return; try { await App.api('/api/shutdown', { method: 'POST', body: {} }); } catch { } document.body.innerHTML = '<div style="height:100vh;display:flex;align-items:center;justify-content:center;font-size:20px;color:var(--text);background:var(--bg)">הצ\'אט כובה. אפשר לסגור את החלון.</div>'; };
    sec.appendChild(el('div', 'acct-actions')).append(rs, sd);
    // גרסה מדויקת (קטן, בתחתית)
    const ver = el('div', 'st-version'); ver.dir = 'rtl'; ver.style.cssText = 'margin-top:14px;font-size:11.5px;color:var(--text-dim,#8a877f);text-align:right;user-select:text';
    // כל ערך באנגלית/מספרים בתוך <bdi> — כדי שהסדר בשורה העברית לא יתבלבל
    App.api('/api/version').then(v => { const b = s => '<bdi dir="ltr">' + esc(s) + '</bdi>'; ver.innerHTML = 'גרסה ' + b(v.version) + (v.source === 'live' ? ' · קוד חי' : v.source === 'dev' ? ' · פיתוח' : '') + (v.shell && v.shell !== v.version ? ' · מעטפת ' + b(v.shell) : '') + (v.extension ? ' · תוסף ' + b('Chrome ' + v.extension) : ''); ver.title = 'Ctrl+Shift+R בתוכנה טוען את הבנייה האחרונה בלי לסגור'; }).catch(() => { });
    if (App.updates) sec.appendChild(App.updates.section());
    sec.appendChild(ver); box.appendChild(sec);
  }
})();
