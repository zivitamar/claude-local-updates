// ============================================================
//  explorer.js — "סייר קבצים": עץ קבצים בלוח הצד, עורך/מציג קבצים, פתיחת נתיב,
//  ו-Workspace רב-תיקיות בסגנון VS Code: העץ מציג את כל התיקיות של הפרויקט הפעיל (App.workspace) —
//  שורש לכל תיקייה (תיקיית הפרויקט + תיקיות נוספות). גרירת תיקייה מ-Windows = הוספה ל-Workspace.
//  חוזה: docs/UI-CONTRACT.md.  כל ה-DOM של הלוח נבנה כאן בתוך #explorerBody / #explorerTools.
//  window.App.explorer = { open, reveal, refresh, openFile, selected, roots, addRoot, removeRoot, getRoot, setRoot }
// ============================================================
(function () {
  'use strict';
  const App = window.App;
  if (!App || window.__fxExplorerLoaded) return;
  window.__fxExplorerLoaded = true;

  // ---------- כלים כלליים ----------
  const $ = id => document.getElementById(id);
  const el = (tag, cls, html) => App.el(tag, cls, html);
  const esc = s => App.esc(s);
  const enc = encodeURIComponent;
  const lsGet = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : v; } catch { return d; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch { } };
  const api = (p, o) => App.api(p, o);
  const post = (p, body) => App.api(p, { method: 'POST', body });
  const toast = (t, ms) => App.toast(t, ms);
  const errMsg = e => (e && (e.message || e.error)) || String(e || 'שגיאה');

  // ---------- נתיבי Windows (עברית, רווחים, UNC, כוננים) — אף פעם לא משרשרים '/' ידנית ----------
  const winLike = p => /^[a-zA-Z]:|^\\\\|\\/.test(String(p));
  const sepOf = p => (winLike(p) ? '\\' : '/');
  function joinPath(dir, name) { if (!dir) return String(name); return /[\\/]$/.test(dir) ? dir + name : dir + sepOf(dir) + name; }
  function splitPath(p) {
    p = String(p || '');
    let m;
    if ((m = /^([a-zA-Z]:)[\\/]*(.*)$/.exec(p))) return { root: m[1] + '\\', label: m[1], parts: m[2].split(/[\\/]+/).filter(Boolean) };
    if ((m = /^\\\\([^\\/]+)[\\/]+([^\\/]+)[\\/]*(.*)$/.exec(p))) return { root: '\\\\' + m[1] + '\\' + m[2] + '\\', label: '\\\\' + m[1] + '\\' + m[2], parts: m[3].split(/[\\/]+/).filter(Boolean) };
    if (p.startsWith('/')) return { root: '/', label: '/', parts: p.split('/').filter(Boolean) };
    return { root: '', label: '', parts: p.split(/[\\/]+/).filter(Boolean) };
  }
  function crumbsOf(p) {
    const s = splitPath(p), out = [];
    if (s.root) out.push({ label: s.label, path: s.root });
    let cur = s.root;
    for (const part of s.parts) { cur = joinPath(cur, part); out.push({ label: part, path: cur }); }
    return out;
  }
  function parentOf(p) { const c = crumbsOf(p); return c.length > 1 ? c[c.length - 2].path : null; }
  // מפתח להשוואה (Windows אינו רגיש לאותיות; סוף נתיב ו-/ ו-\ מנורמלים)
  const K = p => {
    p = String(p || '');
    if (winLike(p)) p = p.replace(/\//g, '\\').toLowerCase();
    return p.length > 3 && /[\\/]$/.test(p) ? p.replace(/[\\/]+$/, '') : p;
  };
  const sameP = (a, b) => !!a && !!b && K(a) === K(b);
  const isInside = (child, parent) => { const c = K(child), pp = K(parent).replace(/[\\/]+$/, ''); return c.length > pp.length && c.startsWith(pp) && /[\\/]/.test(c[pp.length]); };
  function relPath(root, p) {
    if (sameP(root, p)) return '.';
    if (!isInside(p, root)) return p;
    return String(p).slice(String(root).replace(/[\\/]+$/, '').length).replace(/^[\\/]+/, '');
  }
  const quotePath = p => (/\s/.test(p) ? '"' + p + '"' : p);
  const extOf = name => { const i = String(name).lastIndexOf('.'); return i > 0 ? String(name).slice(i + 1).toLowerCase() : ''; };
  const collator = new Intl.Collator('he', { numeric: true, sensitivity: 'base' });

  // ---------- אייקונים לפי סוג ----------
  const BADGES = {
    js: ['JS', '#e6c229'], mjs: ['JS', '#e6c229'], cjs: ['JS', '#e6c229'], jsx: ['JSX', '#61dafb'], ts: ['TS', '#4a90e2'], tsx: ['TSX', '#4a90e2'],
    json: ['{}', '#cbb26b'], html: ['<>', '#e8643c'], htm: ['<>', '#e8643c'], css: ['CSS', '#42a5f5'], scss: ['SC', '#d36ba0'], less: ['LS', '#6b8fd1'],
    md: ['MD', '#9fb0c0'], txt: ['TXT', '#a3a8ae'], py: ['PY', '#5b9bd5'], java: ['JV', '#e76f00'], c: ['C', '#6a9fd8'], h: ['H', '#a074c4'],
    cpp: ['C++', '#659ad2'], cs: ['C#', '#9b4f96'], go: ['GO', '#29beb0'], rs: ['RS', '#dea584'], php: ['PHP', '#8892bf'], rb: ['RB', '#cc342d'],
    sh: ['SH', '#7ec36d'], ps1: ['PS', '#4d8cd8'], bat: ['BAT', '#8aa5a0'], cmd: ['CMD', '#8aa5a0'], sql: ['SQL', '#e0a44a'], xml: ['XML', '#e38b4f'],
    yml: ['YML', '#d98a8a'], yaml: ['YML', '#d98a8a'], toml: ['TML', '#b08a62'], ini: ['INI', '#a3a8ae'], cfg: ['CFG', '#a3a8ae'], env: ['ENV', '#d9c04a'],
    log: ['LOG', '#8b8f94'], csv: ['CSV', '#5fa86a'], vbs: ['VBS', '#8aa5a0'], lua: ['LUA', '#5b7fd1'], kt: ['KT', '#a97bff'], swift: ['SW', '#f08b3a']
  };
  const EMOJI = {
    png: '🖼', jpg: '🖼', jpeg: '🖼', gif: '🖼', webp: '🖼', bmp: '🖼', ico: '🖼', svg: '🎨', pdf: '📕',
    zip: '📦', rar: '📦', '7z': '📦', tar: '📦', gz: '📦', exe: '⚙️', msi: '⚙️', dll: '⚙️',
    mp3: '🎵', wav: '🎵', flac: '🎵', m4a: '🎵', mp4: '🎬', mkv: '🎬', avi: '🎬', mov: '🎬',
    doc: '📘', docx: '📘', xls: '📗', xlsx: '📗', ppt: '📙', pptx: '📙', lnk: '🔗'
  };
  const SVG_FOLDER = '<svg class="fx-svg" viewBox="0 0 16 16" aria-hidden="true"><path d="M1.6 3.6a1 1 0 0 1 1-1h3.1l1.3 1.5h6.4a1 1 0 0 1 1 1v6.9a1 1 0 0 1-1 1H2.6a1 1 0 0 1-1-1z" fill="#d6a84a"/></svg>';
  const SVG_FOLDER_OPEN = '<svg class="fx-svg" viewBox="0 0 16 16" aria-hidden="true"><path d="M1.6 4a1 1 0 0 1 1-1h3.1L7 4.5h5.5a1 1 0 0 1 1 1V6H4.3a1.4 1.4 0 0 0-1.3 1L1.6 11z" fill="#b98a35"/><path d="M3.2 7h12.2a.5.5 0 0 1 .48.65l-1.55 5.1a1 1 0 0 1-.96.7H2.1z" fill="#ecc470"/></svg>';
  const SVG_CHEV = '<svg class="fx-chev-svg" viewBox="0 0 16 16" aria-hidden="true"><path d="M6 3.5 10.5 8 6 12.5" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  function iconHtml(e, open) {
    if (e.dir) return '<span class="fx-ic">' + (open ? SVG_FOLDER_OPEN : SVG_FOLDER) + '</span>';
    const x = extOf(e.name);
    if (EMOJI[x]) return '<span class="fx-ic fx-emoji">' + EMOJI[x] + '</span>';
    const b = BADGES[x];
    if (b) return '<span class="fx-ic"><i class="fx-badge" style="--c:' + b[1] + '">' + esc(b[0]) + '</i></span>';
    return '<span class="fx-ic"><i class="fx-badge fx-plain">' + esc(x ? x.slice(0, 3).toUpperCase() : '•') + '</i></span>';
  }

  const SVG_ROOT = '<svg class="fx-svg" viewBox="0 0 16 16" aria-hidden="true"><path d="M1.6 3.6a1 1 0 0 1 1-1h3.1l1.3 1.5h6.4a1 1 0 0 1 1 1v6.9a1 1 0 0 1-1 1H2.6a1 1 0 0 1-1-1z" fill="#d97757"/><path d="M8 6.1l.75 1.55 1.7.22-1.25 1.17.32 1.68L8 9.85l-1.52.87.32-1.68-1.25-1.17 1.7-.22z" fill="#1f1e1d"/></svg>';
  const SVG_WS = '<svg viewBox="0 0 16 16" width="15" height="15" aria-hidden="true"><path d="M2 5.2a1 1 0 0 1 1-1h2.6l1.1 1.2H12a1 1 0 0 1 1 1v5.4a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1z" fill="none" stroke="currentColor" stroke-width="1.2"/><path d="M4.2 3.4h2.4l1 1.1" fill="none" stroke="currentColor" stroke-width="1.1" opacity=".55" stroke-linecap="round"/><path d="M14 7.2v4.9a1 1 0 0 1-1 1H5.6" fill="none" stroke="currentColor" stroke-width="1.1" opacity=".55" stroke-linecap="round"/></svg>';
  const SVG_X = '<svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true"><path d="M4 4l8 8M12 4l-8 8" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>';

  // ---------- מצב ----------
  const PAGE = 2000;           // כמה פריטים מציירים לתיקייה לפני "הצג עוד" (תיקייה של 5000 קבצים לא מקפיאה)
  let reqSeq = 0;
  const S = {
    roots: [],                // [{path, name, primary, k}] — ה-Workspace של הפרויקט הפעיל, לפי הסדר (תיקיית הפרויקט קודם)
    sig: '', pid: null, pname: '', ready: false, home: '',
    dirs: new Map(),          // K(path) -> {path, entries, sig, err, limit, ms, at, vis}
    exp: new Map(),           // K(root) -> Set(K(dir)) — נשמר גם ב-localStorage (לכל שורש בנפרד)
    rcol: new Set(),          // K(root) של שורשים מכווצים — נשמר ב-localStorage
    showHidden: lsGet('fx.hidden', '0') === '1',
    sel: '', selRk: '', selRoot: false, selEl: null, rowEls: new Map(), edit: null,
    pending: new Map(), refreshing: false, places: null, placesAt: 0, timer: null, viewerPoll: 0, scroll: {}
  };
  try { const j = JSON.parse(lsGet('fx.exp', '{}')); for (const k of Object.keys(j)) S.exp.set(k, new Set(j[k])); } catch { }
  try { for (const k of JSON.parse(lsGet('fx.rcol', '[]'))) S.rcol.add(k); } catch { }
  let saveExpT = 0;
  function saveExp() {
    clearTimeout(saveExpT);
    saveExpT = setTimeout(() => {
      const o = {}; for (const [k, v] of [...S.exp].slice(-40)) o[k] = [...v].slice(0, 300);
      lsSet('fx.exp', JSON.stringify(o));
    }, 400);
  }
  function saveRcol() { lsSet('fx.rcol', JSON.stringify([...S.rcol].slice(-100))); }
  function expSet(rk) { let s = S.exp.get(rk); if (!s) { s = new Set(); S.exp.set(rk, s); } return s; }
  const rootByKey = rk => S.roots.find(r => r.k === rk) || null;
  // השורש שמכיל נתיב (השורש עצמו או משהו בתוכו). כששורשים מקוננים — מעדיפים את `prefer`, אחרת את הספציפי ביותר
  function rootOfPath(p, prefer) {
    const hit = S.roots.filter(r => sameP(r.path, p) || isInside(p, r.path));
    if (!hit.length) return null;
    return (prefer && hit.find(r => r.k === prefer)) || hit.slice().sort((a, b) => b.k.length - a.k.length)[0];
  }

  let tree = null, rowsHost = null; // אלמנטי ה-DOM הראשיים

  // ============================================================
  //  טעינת תיקיות
  // ============================================================
  function prepEntries(list) {
    const out = list.map(e => ({ name: e.name, path: e.path, dir: !!e.dir, size: e.size || 0, mtime: e.mtime || 0, hidden: !!e.hidden, k: K(e.path) }));
    out.sort((a, b) => (b.dir - a.dir) || collator.compare(a.name, b.name));
    return out;
  }
  async function fetchDir(path) {
    const t0 = performance.now();
    const r = await api('/api/fs/list?path=' + enc(path));
    const entries = prepEntries(r.entries || []);
    let sig = entries.length + ':' + (r.truncated ? 'T' : '');
    for (const e of entries) sig += '\n' + e.name + '|' + (e.dir ? 1 : 0) + '|' + e.size + '|' + Math.floor(e.mtime / 1000);
    return { path: r.path, parent: r.parent, entries, sig, err: '', status: 0, truncated: !!r.truncated, ms: performance.now() - t0, at: Date.now(), limit: PAGE, vis: null };
  }
  // quiet = רענון ברקע: שגיאה זמנית לא מוחקת את מה שכבר מוצג
  async function loadDir(path, { quiet = false } = {}) {
    const k = K(path), seq = ++reqSeq;
    S.pending.set(k, seq);
    try {
      const rec = await fetchDir(path);
      if (S.pending.get(k) !== seq) return { changed: false, stale: true };
      const prev = S.dirs.get(k);
      if (prev) rec.limit = prev.limit;
      S.dirs.set(k, rec);
      return { changed: !prev || prev.sig !== rec.sig || !!prev.err, rec };
    } catch (e) {
      if (S.pending.get(k) !== seq) return { changed: false, stale: true };
      const prev = S.dirs.get(k);
      if (quiet && prev && !prev.err && e.status !== 404) return { changed: false, err: e };
      S.dirs.set(k, { path, entries: [], sig: 'ERR:' + errMsg(e), err: errMsg(e), status: e.status || 0, truncated: false, ms: 0, at: Date.now(), limit: PAGE, vis: null });
      return { changed: true, err: e };
    } finally { if (S.pending.get(k) === seq) S.pending.delete(k); }
  }
  function ensureLoad(dirPath) {
    const k = K(dirPath);
    if (S.dirs.has(k) || S.pending.has(k)) return;
    loadDir(dirPath).then(r => { if (!r.stale) render(); }).catch(() => { });
  }
  function visList(rec) {
    if (!rec.vis || rec.vis.hidden !== S.showHidden) rec.vis = { hidden: S.showHidden, list: S.showHidden ? rec.entries : rec.entries.filter(e => !e.hidden) };
    return rec.vis.list;
  }
  function findEntry(path) {
    const par = parentOf(path); if (!par) return null;
    const rec = S.dirs.get(K(par)); if (!rec) return null;
    const k = K(path);
    return rec.entries.find(e => e.k === k) || null;
  }

  // ============================================================
  //  בניית שורות העץ + התאמה (reconcile) ל-DOM בלי הבהוב
  //  כל שורה נושאת data-rk = מפתח השורש שלה (נתיבים מוחלטים, ושורשים יכולים להיות מקוננים — המפתח מבחין)
  // ============================================================
  function entryRow(e, depth, open, renaming, rk) {
    const sig = ['e', e.name, e.dir ? 1 : 0, open ? 1 : 0, depth, e.size, Math.floor(e.mtime / 1000), e.hidden ? 1 : 0, renaming ? 'R' : ''].join('|');
    return {
      key: 'e:' + rk + '|' + e.k, sig,
      fill(node) {
        node.className = 'fx-row ' + (e.dir ? 'dir' : 'file') + (open ? ' open' : '') + (e.hidden ? ' hid' : '') + (renaming ? ' fx-editrow' : '');
        node.dataset.path = e.path; node.dataset.kind = e.dir ? 'dir' : 'file'; node.dataset.depth = depth; node.dataset.rk = rk;
        node.removeAttribute('data-act'); node.removeAttribute('title');
        node.style.setProperty('--d', depth);
        node.setAttribute('role', 'treeitem');
        if (e.dir) node.setAttribute('aria-expanded', open ? 'true' : 'false'); else node.removeAttribute('aria-expanded');
        node.draggable = !renaming;
        node.innerHTML = '<span class="fx-chev">' + (e.dir ? SVG_CHEV : '') + '</span>' + iconHtml(e, open) + (renaming ? '' : '<span class="fx-nm">' + esc(e.name) + '</span>');
        if (renaming) mountEditInput(node);
      }
    };
  }
  // שורת שורש: שם מודגש + נתיב מלא קטן ועמום מתחתיו; שורש הפרויקט מסומן, לשורשים נוספים יש ✕
  function rootRow(r, collapsed, err) {
    const sig = ['r', r.path, r.name, r.primary ? 1 : 0, collapsed ? 1 : 0, err ? 1 : 0].join('|');
    return {
      key: 'r:' + r.k, sig,
      fill(node) {
        node.className = 'fx-row root ' + (r.primary ? 'primary' : 'extra') + (collapsed ? '' : ' open') + (err ? ' bad' : '');
        node.dataset.path = r.path; node.dataset.kind = 'root'; node.dataset.depth = 0; node.dataset.rk = r.k; node.dataset.primary = r.primary ? '1' : '0';
        node.removeAttribute('data-act');
        node.style.setProperty('--d', 0);
        node.setAttribute('role', 'treeitem'); node.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
        node.draggable = true;
        node.title = r.path + (r.primary ? '\nתיקיית הפרויקט' : '');
        node.innerHTML = '<span class="fx-chev">' + SVG_CHEV + '</span><span class="fx-ic">' + (r.primary ? SVG_ROOT : SVG_FOLDER) + '</span>' +
          '<span class="fx-rbox"><span class="fx-rtop"><span class="fx-rname"></span>' + (r.primary ? '<span class="fx-rbadge">פרויקט</span>' : '') + '</span><span class="fx-rpath"><bdi dir="ltr"></bdi></span></span>' +
          (r.primary ? '' : '<button class="fx-rx" type="button" title="הסר מה-Workspace" aria-label="הסר מה-Workspace">' + SVG_X + '</button>');
        node.querySelector('.fx-rname').textContent = r.name;
        node.querySelector('.fx-rpath bdi').textContent = isoPath(r.path);
      }
    };
  }
  function infoRow(kind, depth, dir, text, rk) {
    return {
      key: 'i:' + kind + ':' + rk + '|' + K(dir), sig: 'i|' + kind + '|' + depth + '|' + text,
      fill(node) {
        node.className = 'fx-row fx-info ' + kind; node.removeAttribute('data-path'); node.removeAttribute('data-kind'); node.removeAttribute('title');
        node.draggable = false; node.removeAttribute('role');
        node.style.setProperty('--d', depth);
        node.dataset.dir = dir; node.dataset.rk = rk;
        node.dataset.act = kind === 'more' ? 'more' : kind === 'error' ? 'retry' : '';
        if (!node.dataset.act) node.removeAttribute('data-act');
        node.innerHTML = '<span class="fx-chev"></span><span class="fx-info-t"></span>';
        node.querySelector('.fx-info-t').textContent = text;
      }
    };
  }
  function editRow(depth) {
    return {
      key: 'edit', sig: 'edit|' + S.edit.kind + '|' + depth,
      fill(node) {
        node.className = 'fx-row fx-editrow fx-newrow'; node.removeAttribute('data-path'); node.removeAttribute('data-kind'); node.removeAttribute('data-act'); node.removeAttribute('title');
        node.draggable = false; node.style.setProperty('--d', depth);
        node.innerHTML = '<span class="fx-chev"></span>' + (S.edit.kind === 'new-dir' ? '<span class="fx-ic">' + SVG_FOLDER + '</span>' : '<span class="fx-ic"><i class="fx-badge fx-plain">•</i></span>');
        mountEditInput(node);
      }
    };
  }
  function buildRows() {
    const rows = [];
    for (const r of S.roots) {
      const rk = r.k, col = S.rcol.has(rk), exp = expSet(rk);
      const rrec = S.dirs.get(rk);
      rows.push(rootRow(r, col, !!(rrec && rrec.err)));
      if (col) continue;
      const editHere = dirPath => !!S.edit && S.edit.kind !== 'rename' && S.edit.rk === rk && sameP(S.edit.dir, dirPath);
      const walk = (dirPath, depth) => {
        const rec = S.dirs.get(K(dirPath));
        if (editHere(dirPath)) rows.push(editRow(depth));
        if (!rec) { rows.push(infoRow('loading', depth, dirPath, 'טוען…', rk)); ensureLoad(dirPath); return; }
        if (rec.err) { rows.push(infoRow('error', depth, dirPath, (rec.status === 403 ? '🔒 ' : '⚠️ ') + rec.err, rk)); return; }
        const list = visList(rec);
        if (!list.length && !editHere(dirPath)) {
          const hid = rec.entries.length - list.length;
          rows.push(infoRow('empty', depth, dirPath, hid > 0 ? 'אין פריטים גלויים' : 'ריקה', rk));
        }
        const n = Math.min(list.length, rec.limit);
        for (let i = 0; i < n; i++) {
          const e = list[i], open = e.dir && exp.has(e.k);
          rows.push(entryRow(e, depth, open, S.edit && S.edit.kind === 'rename' && S.edit.rk === rk && K(S.edit.path) === e.k, rk));
          if (open) walk(e.path, depth + 1);
        }
        if (list.length > n) { const rem = list.length - n; rows.push(infoRow('more', depth, dirPath, 'הצג עוד ' + Math.min(PAGE, rem), rk)); }
        if (rec.truncated) rows.push(infoRow('trunc', depth, dirPath, 'מוצגים 5000 ראשונים', rk));
      };
      walk(r.path, 1);
    }
    return rows;
  }
  function reconcile(rows) {
    if (S.edit) S.edit.busy = true;
    const old = S.rowEls, next = new Map();
    let cursor = rowsHost.firstChild;
    for (const d of rows) {
      let node = old.get(d.key);
      if (node) old.delete(d.key); else { node = document.createElement('div'); node._sig = null; }
      if (node._sig !== d.sig) { d.fill(node); node._sig = d.sig; }
      next.set(d.key, node);
      if (cursor === node) cursor = cursor.nextSibling; else rowsHost.insertBefore(node, cursor);
    }
    for (const n of old.values()) n.remove();
    S.rowEls = next;
    if (S.edit) S.edit.busy = false;
  }
  function render() {
    if (!tree) return;
    const none = !S.roots.length;
    const empty = $('fxEmpty'); if (empty) empty.hidden = !(none && S.ready);
    if (none) { reconcile([]); S.selEl = null; return; }
    rowsHost.hidden = false;
    reconcile(buildRows());
    updateSel();
    focusEditIfNeeded();
  }
  const selKey = () => (S.selRoot ? 'r:' + S.selRk : 'e:' + S.selRk + '|' + K(S.sel));
  function updateSel() {
    if (S.selEl) { S.selEl.classList.remove('sel'); S.selEl.removeAttribute('aria-selected'); }
    S.selEl = null;
    if (!S.sel) return;
    const n = S.rowEls.get(selKey());
    if (n) { n.classList.add('sel'); n.setAttribute('aria-selected', 'true'); S.selEl = n; }
  }
  // select(path, {rk, root:true} כשזו שורת שורש)
  function select(path, { scroll = true, rk = '', root = false } = {}) {
    S.sel = path || ''; S.selRoot = !!root && !!path;
    S.selRk = !S.sel ? '' : (rk || (rootOfPath(path, S.selRk) || {}).k || '');
    updateSel();
    if (scroll && S.selEl) S.selEl.scrollIntoView({ block: 'nearest' });
  }
  const selectRow = (row, o = {}) => select(row.dataset.path, { ...o, rk: row.dataset.rk, root: row.dataset.kind === 'root' });

  // ============================================================
  //  ה-Workspace: שורשי העץ = תיקיית הפרויקט הפעיל + התיקיות הנוספות שלו (App.workspace)
  // ============================================================
  function readWorkspace() {
    let list = [], pid = null, name = '';
    try {
      if (App.workspace) { list = App.workspace.roots() || []; pid = App.workspace.projectId(); }
      else { const w = App.state && App.state.config && App.state.config.workingDir; if (w) list = [{ path: w, name: App.baseName(w), primary: true }]; }
      const pr = App.projects && App.projects.active && App.projects.active(); name = (pr && pr.name) || '';
    } catch { }
    return { list, pid, name };
  }
  // קורא את ה-Workspace הנוכחי; אם השתנה (פרויקט אחר / תיקיות נוספו או הוסרו / שם) — מחליף את כל העץ בלי הבהוב
  function syncRoots(force) {
    const w = readWorkspace();
    const seen = new Set(), roots = [];
    for (const r of w.list) {
      if (!r || !r.path) continue;
      const k = K(r.path); if (seen.has(k)) continue; seen.add(k);
      roots.push({ path: r.path, name: r.name || App.baseName(r.path) || r.path, primary: !!r.primary, k });
    }
    const sig = [w.pid, w.name, ...roots.map(r => (r.primary ? '*' : '') + r.k + '|' + r.name)].join('\n');
    if (!force && sig === S.sig) return false;
    const pidChanged = S.pid !== w.pid;
    if (tree && pidChanged && S.pid) S.scroll[S.pid] = tree.scrollTop;
    S.sig = sig; S.pid = w.pid; S.pname = w.name; S.roots = roots;
    if (S.edit && !rootByKey(S.edit.rk)) dropEdit();
    if (S.sel && !rootByKey(S.selRk)) { S.sel = ''; S.selEl = null; S.selRk = ''; S.selRoot = false; }
    if (S.dirs.size > 400) for (const k of [...S.dirs.keys()]) if (!roots.some(r => r.k === k || isInside(k, r.path))) S.dirs.delete(k); // לא מצטברים מטמונים של פרויקטים ישנים
    render(); renderHeader();
    if (tree && pidChanged) tree.scrollTop = S.scroll[S.pid] || 0;
    return true;
  }
  function renderHeader() {
    const lbl = $('fxRootLabel'); if (!lbl) return;
    const first = S.roots[0];
    lbl.dataset.root = first ? first.path : ''; lbl.dataset.project = S.pid || ''; lbl.dataset.roots = JSON.stringify(S.roots.map(r => r.path));
    lbl.title = S.roots.map(r => r.path).join('\n'); // אלמנט נסתר: קרס לבדיקות ולמודולים אחרים
    const nm = $('fxWsName'); if (nm) { nm.textContent = S.pname || 'Workspace'; $('fxWs').title = (S.pname || 'Workspace') + (S.roots.length ? '\n' + S.roots.map(r => r.path).join('\n') : ''); }
    const cnt = $('fxWsCount'); if (cnt) cnt.textContent = S.roots.length > 1 ? S.roots.length + ' תיקיות' : '';
    for (const id of ['fxNewFile', 'fxNewFolder', 'fxCollapse']) { const b = $(id); if (b) b.disabled = !S.roots.length; }
  }

  // ============================================================
  //  פעולות על העץ
  // ============================================================
  async function toggle(path, force, rk) {
    rk = rk || (rootOfPath(path, S.selRk) || {}).k; if (!rk) return;
    const exp = expSet(rk), k = K(path);
    const open = force != null ? force : !exp.has(k);
    if (open) { exp.add(k); saveExp(); render(); const rec = S.dirs.get(k); if (rec && rec.err) loadDir(path).then(() => render()); else if (rec) loadDir(path, { quiet: true }).then(r => { if (r.changed) render(); }); }
    else { exp.delete(k); saveExp(); render(); }
  }
  // כיווץ/פתיחה של שורש שלם (המצב נשמר לכל שורש בנפרד)
  async function toggleRoot(rk, force) {
    const r = rootByKey(rk); if (!r) return;
    const open = force != null ? force : S.rcol.has(rk);
    if (open) S.rcol.delete(rk); else { S.rcol.add(rk); if (S.sel && !S.selRoot && S.selRk === rk) select(r.path, { scroll: false, rk, root: true }); }
    saveRcol(); render();
    if (open) { const rec = S.dirs.get(rk); if (rec && rec.err) loadDir(r.path).then(() => render()); else if (rec) loadDir(r.path, { quiet: true }).then(x => { if (x.changed) render(); }); }
  }
  function collapseAll() { for (const r of S.roots) expSet(r.k).clear(); saveExp(); render(); if (tree) tree.scrollTop = 0; }
  function toggleHidden(v) {
    S.showHidden = v != null ? !!v : !S.showHidden; lsSet('fx.hidden', S.showHidden ? '1' : '0');
    const b = $('fxHidden'); if (b) { b.classList.toggle('on', S.showHidden); b.title = S.showHidden ? 'הסתר קבצים נסתרים' : 'הצג קבצים נסתרים'; }
    render();
  }
  async function refresh() { await refreshVisible({ force: true }); }
  function openDirList(force) { // התיקיות הפתוחות שגלויות כרגע, בכל השורשים (שורש מכווץ לא נסרק ברענון הרקע; ברענון ידני — רק תיקיית השורש שלו, כדי שמצב שגיאה יתעדכן)
    const out = [], seen = new Set();
    const add = p => { const k = K(p); if (!seen.has(k)) { seen.add(k); out.push(p); return true; } return false; };
    for (const r of S.roots) {
      if (S.rcol.has(r.k)) { if (force) add(r.path); continue; }
      add(r.path); const exp = expSet(r.k);
      const walk = p => { const rec = S.dirs.get(K(p)); if (!rec || rec.err) return; for (const e of visList(rec)) if (e.dir && exp.has(e.k)) { add(e.path); walk(e.path); } };
      walk(r.path);
    }
    return out;
  }
  async function refreshVisible({ force = false } = {}) {
    if (S.refreshing || !S.roots.length) return;
    S.refreshing = true;
    try {
      let changed = false;
      for (const d of openDirList(force)) {
        const rec = S.dirs.get(K(d));
        if (!force && rec && rec.ms > 700 && Date.now() - rec.at < Math.max(4000, rec.ms * 8)) continue; // תיקייה כבדה: מרווחים את הרענון
        const r = await loadDir(d, { quiet: true });
        if (r.changed) changed = true;
      }
      if (changed) render();
    } finally { S.refreshing = false; }
  }
  async function stat(p) { return api('/api/fs/stat?path=' + enc(p)); }

  // חושף נתיב: מרחיב את העץ בשורש שמכיל אותו עד אליו ובוחר אותו. נתיב מחוץ ל-Workspace → false
  async function reveal(path) {
    const st = await stat(path);
    if (!st.exists) throw new Error('הנתיב לא קיים: ' + st.path);
    const target = st.path;
    const root = rootOfPath(target, S.selRk);
    if (!root) { toast('הנתיב מחוץ ל-Workspace', 3000); return false; }
    if (S.rcol.has(root.k)) { S.rcol.delete(root.k); saveRcol(); }
    if (sameP(target, root.path)) { render(); select(target, { rk: root.k, root: true }); return true; }
    const chain = []; let cur = parentOf(target);
    while (cur && !sameP(cur, root.path)) { chain.unshift(cur); cur = parentOf(cur); }
    const exp = expSet(root.k);
    for (const d of chain) { exp.add(K(d)); if (!S.dirs.has(K(d)) || S.dirs.get(K(d)).err) await loadDir(d); }
    saveExp();
    const pk = K(parentOf(target)); if (!S.dirs.has(pk)) await loadDir(parentOf(target));
    const par = S.dirs.get(pk);
    if (par && !par.err) {
      const e = par.entries.find(x => x.k === K(target));
      if (e && e.hidden && !S.showHidden) toggleHidden(true);
      const idx = visList(par).findIndex(x => x.k === K(target));
      if (idx >= par.limit) par.limit = idx + 200;
    }
    render(); select(target, { rk: root.k });
    return true;
  }
  // שורת הנתיב: תיקייה/קובץ בתוך ה-Workspace → נחשף ונבחר (קובץ גם נפתח); תיקייה מחוץ ל-Workspace → נוספת כשורש; קובץ מחוץ ל-Workspace → נפתח במציג
  async function openPath(raw) {
    setPathError('');
    let p = String(raw == null ? '' : raw).trim().replace(/^["']+|["']+$/g, '');
    if (!p) return false;
    p = expandEnv(p);
    let st;
    try { st = await stat(p); } catch (e) { setPathError(errMsg(e)); return false; }
    if (!st.exists) { setPathError('הנתיב לא קיים', st.path); return false; }
    const inp = $('fxPathInput'); if (inp) { delete inp.dataset.dirty; inp.value = ''; }
    const inside = !!rootOfPath(st.path, S.selRk);
    if (st.dir) {
      if (inside) return reveal(st.path);
      if (!(await addRoot(st.path))) return false;
      return true;
    }
    if (inside) { try { await reveal(st.path); } catch { } }
    await openFile(st.path);
    return true;
  }
  function expandEnv(p) {
    const h = S.home; if (!h) return p;
    const map = { USERPROFILE: h, HOMEPATH: h, HOME: h, APPDATA: h + '\\AppData\\Roaming', LOCALAPPDATA: h + '\\AppData\\Local', TEMP: h + '\\AppData\\Local\\Temp', TMP: h + '\\AppData\\Local\\Temp', DESKTOP: h + '\\Desktop' };
    return p.replace(/%([A-Za-z_]+)%/g, (m, n) => map[n.toUpperCase()] || m);
  }
  // נתיב בתוך טקסט עברי: עוטפים ב-isolate של LTR (U+2066..U+2069) כדי שלא יתבלגן (טוסטים הם טקסט רגיל, בלי HTML)
  // נתיב עם תיקיות בעברית: כל קטע עברי מבודד (FSI..PDI) כדי שסדר הקטעים לא יתהפך; ו-ltr() עוטף את הכל כיחידת LTR
  const RTL_RE = /[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]/;
  const isoPath = p => String(p).split(/([\\/])/).map(x => (RTL_RE.test(x) ? '\u2068' + x + '\u2069' : x)).join('');
  const ltr = s => '\u2066' + isoPath(s) + '\u2069';
  function setPathError(msg, pth) {
    const e = $('fxPathError'), i = $('fxPathInput');
    if (!e) return;
    e.hidden = !msg; e.textContent = msg || '';
    if (msg && pth) { const c = el('div', 'fx-patherr-path'); c.dir = 'ltr'; c.textContent = isoPath(pth); e.appendChild(c); }
    if (i) i.classList.toggle('bad', !!msg);
  }

  // ---------- פעולות מערכת הפעלה ----------
  async function osOpen(p) { try { await post('/api/fs/open', { path: p }); toast('נפתח'); } catch (e) { toast('הפתיחה נכשלה: ' + errMsg(e), 4000); } }
  async function osReveal(p) { try { await post('/api/fs/reveal', { path: p }); } catch (e) { toast('לא הצלחתי להציג ב-Explorer: ' + errMsg(e), 4000); } }
  function insertPath(p) {
    try { if (App.chats && App.chats.insertIntoInput) { App.chats.insertIntoInput(quotePath(p)); toast('הנתיב הוכנס להודעה'); } else toast('אין שיחה פעילה'); }
    catch (e) { toast('לא הצלחתי להכניס נתיב: ' + errMsg(e), 3500); }
  }
  async function makeProject(dir) {
    const name = await App.prompt('שם הפרויקט', App.baseName(dir), { title: 'צור פרויקט מתיקייה זו', okText: 'צור פרויקט', placeholder: 'שם הפרויקט' });
    if (name == null || !String(name).trim()) return;
    try { await App.projects.create({ dir, name: String(name).trim() }); toast('נוצר פרויקט "' + String(name).trim() + '" על התיקייה ' + ltr(dir), 4000); }
    catch (e) { toast('יצירת הפרויקט נכשלה: ' + errMsg(e), 4500); }
  }
  // ---------- הוספה / הסרה של שורשים ----------
  async function pickFolderNative(initial) {
    const title = 'הוסף תיקייה ל-Workspace';
    if (window.desktop && typeof window.desktop.pickFolder === 'function') {
      const r = await window.desktop.pickFolder({ title, defaultPath: initial || undefined });
      return typeof r === 'string' ? r : (r && r.path) || null;
    }
    const r = await post('/api/fs/pick-folder', { initial: initial || '', title });
    return (r && r.path) || null;
  }
  async function addRoot(dir) {
    dir = String(dir == null ? '' : dir).trim().replace(/^["']+|["']+$/g, '');
    if (!dir) return false;
    let ok = false;
    try { ok = !!(App.workspace && await App.workspace.add(dir)); }
    catch (e) { toast('לא הצלחתי להוסיף: ' + errMsg(e), 4500); return false; }
    syncRoots();
    if (ok) { const r = S.roots.find(x => sameP(x.path, dir)); if (r) { if (S.rcol.has(r.k)) { S.rcol.delete(r.k); saveRcol(); render(); } select(r.path, { rk: r.k, root: true }); } }
    return ok;
  }
  async function removeRoot(path) {
    const r = S.roots.find(x => sameP(x.path, path)); if (!r) return false;
    if (r.primary) { toast('זו תיקיית הפרויקט. אפשר לשנות אותה בקליק ימני על הטאב של הפרויקט', 4500); return false; }
    let ok = false;
    try { ok = !!(App.workspace && await App.workspace.remove(r.path)); } catch (e) { toast('ההסרה נכשלה: ' + errMsg(e), 4500); return false; }
    syncRoots();
    return ok;
  }
  // הכפתור "הוסף תיקייה": חלון הבחירה של המערכת; אם אין כזה (שרת בלי שולחן עבודה / שגיאה) — חלון קטן עם שורת נתיב
  async function addRootFlow(initial) {
    const b = $('fxAddRoot'); if (b) { b.disabled = true; b.classList.add('busy'); }
    try {
      let p;
      try { p = await pickFolderNative(initial || (S.roots[0] && S.roots[0].path)); }
      catch { p = await askPathModal(''); }
      if (p) return await addRoot(p);
      return false;
    } catch (e) { toast('הוספת התיקייה נכשלה: ' + errMsg(e), 4500); return false; }
    finally { if (b) { b.disabled = false; b.classList.remove('busy'); } }
  }
  async function getPlaces() {
    if (S.places && Date.now() - S.placesAt < 30000) return S.places;
    const r = await api('/api/fs/places'); S.places = r; S.placesAt = Date.now(); if (r.home) S.home = r.home; return r;
  }
  // מיקומים מהירים: לחיצה מוסיפה את המיקום ל-Workspace (מה שכבר שם — מסומן ולא לחיץ)
  async function showPlaces(btn) {
    let pl; try { pl = await getPlaces(); } catch (e) { toast('לא הצלחתי לטעון מיקומים: ' + errMsg(e)); return; }
    const icons = { desktop: '🖥', docs: '📄', download: '⬇️', home: '🏠', drive: '💽' };
    const inWs = p => S.roots.some(r => sameP(r.path, p));
    const item = (icon, label, p, hint) => ({ icon, label, hint: inWs(p) ? '✓' : (hint || ''), disabled: inWs(p), onClick: () => addRoot(p) });
    const items = [{ icon: '📂', label: 'בחר תיקייה…', onClick: () => addRootFlow() }, { sep: true }];
    for (const p of pl.places || []) items.push(item(icons[p.icon] || '📁', p.name, p.path));
    let projs = []; try { projs = (App.projects && App.projects.list && App.projects.list()) || []; } catch { }
    if (projs.length) { items.push({ sep: true }); for (const p of projs.slice(0, 12)) items.push(item('🧩', p.name, p.dir, 'פרויקט')); }
    if ((pl.drives || []).length) { items.push({ sep: true }); for (const d of pl.drives) items.push(item('💽', 'כונן ' + d.name, d.path)); }
    const r = btn.getBoundingClientRect();
    App.menu(r.left, r.bottom + 4, items);
  }

  // ============================================================
  //  יצירה / שינוי שם / מחיקה (שורה אינליין בעץ)
  // ============================================================
  function validateName(raw) {
    const n = String(raw);
    if (!n.trim()) return 'השם ריק';
    if (/[<>:"/\\|?*\u0000-\u001f]/.test(n)) return 'אסור להשתמש בתווים האלה בשם: ' + ltr('< > : " / \\ | ? *');
    if (n === '.' || n === '..') return 'שם לא תקין';
    if (/[. ]$/.test(n)) return 'שם לא יכול להסתיים ברווח או בנקודה';
    if (/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i.test(n.trim())) return 'זה שם שמור של Windows';
    if (n.length > 255) return 'השם ארוך מדי';
    return '';
  }
  function dropEdit() { if (S.edit) { S.edit.done = true; S.edit = null; } }
  function cancelEdit() {
    if (!S.edit) return;
    const e = S.edit; S.edit = null; e.done = true;
    if (tree) render();
  }
  function mountEditInput(node) {
    const ed = S.edit; if (!ed) return;
    if (!ed.input) {
      const inp = el('input', 'fx-edit'); inp.type = 'text'; inp.spellcheck = false; inp.autocomplete = 'off'; inp.dir = 'auto';
      inp.id = 'fxEditInput';
      inp.value = ed.kind === 'rename' ? ed.name : '';
      inp.placeholder = ed.kind === 'new-dir' ? 'שם התיקייה החדשה' : ed.kind === 'new-file' ? 'שם הקובץ החדש (למשל notes.md)' : '';
      const err = el('div', 'fx-edit-err'); err.hidden = true;
      ed.input = inp; ed.err = err;
      inp.addEventListener('input', () => { const m = validateName(inp.value); if (!inp.value.trim()) { err.hidden = true; inp.classList.remove('bad'); } else { err.hidden = !m; err.textContent = m; inp.classList.toggle('bad', !!m); } });
      inp.addEventListener('keydown', ev => {
        ev.stopPropagation();
        if (ev.key === 'Enter') { ev.preventDefault(); if (!ev.isComposing) commitEdit(); }
        else if (ev.key === 'Escape') { ev.preventDefault(); cancelEdit(); tree.focus(); }
      });
      inp.addEventListener('blur', () => {
        if (ed.done || ed.busy || ed.committing) return;
        if (!document.hasFocus()) return; // החלון איבד פוקוס (alt-tab): ממשיכים לערוך
        setTimeout(() => { if (ed.done || ed.committing || S.edit !== ed) return; if (document.activeElement === inp) return; const v = inp.value.trim(); if (v && !validateName(v) && !(ed.kind === 'rename' && v === ed.name)) commitEdit(); else cancelEdit(); }, 120);
      });
    }
    const had = document.activeElement === ed.input;
    node.appendChild(ed.input); node.appendChild(ed.err);
    if (had) ed.input.focus({ preventScroll: true });
  }
  function focusEditIfNeeded() {
    const ed = S.edit; if (!ed || !ed.input || ed.focused || !ed.input.isConnected) return;
    ed.focused = true;
    ed.input.focus();
    if (ed.kind === 'rename') { const dot = ed.name.lastIndexOf('.'); ed.input.setSelectionRange(0, !ed.isDir && dot > 0 ? dot : ed.name.length); }
    ed.input.scrollIntoView({ block: 'nearest' });
  }
  // היעד של "קובץ/תיקייה חדשה" מהכלים: הפריט הנבחר (תיקייה → בתוכה; קובץ → בתיקייה שלו; שורש → בשורש), ובלי בחירה — השורש הראשון
  function targetForNew() {
    const first = S.roots[0];
    if (!first) return null;
    if (!S.sel) return { dir: first.path, rk: first.k };
    if (S.selRoot) return { dir: S.sel, rk: S.selRk };
    const e = findEntry(S.sel);
    if (e && e.dir) return { dir: e.path, rk: S.selRk };
    if (e) return { dir: parentOf(e.path) || first.path, rk: S.selRk };
    return { dir: first.path, rk: first.k };
  }
  async function startNew(kind, dir, rk) {
    cancelEdit();
    if (!S.roots.length) { toast('אין תיקייה פתוחה'); return; }
    if (!dir) { const t = targetForNew(); dir = t.dir; rk = t.rk; }
    const root = rootByKey(rk) || rootOfPath(dir, S.selRk);
    if (!root) { toast('התיקייה מחוץ ל-Workspace'); return; }
    rk = root.k;
    if (S.rcol.has(rk)) { S.rcol.delete(rk); saveRcol(); }
    if (!sameP(dir, root.path)) { expSet(rk).add(K(dir)); saveExp(); }
    const rec = S.dirs.get(K(dir)); if (!rec || rec.err) await loadDir(dir);
    S.edit = { kind, dir, rk, focused: false, busy: false };
    render();
  }
  function startRename(ent) {
    if (!ent || ent.root) return;
    cancelEdit();
    S.edit = { kind: 'rename', path: ent.path, name: ent.name, isDir: ent.dir, dir: parentOf(ent.path), rk: ent.rk, focused: false, busy: false };
    select(ent.path, { scroll: false, rk: ent.rk });
    render();
  }
  async function commitEdit() {
    const ed = S.edit; if (!ed || ed.committing || ed.done) return;
    const name = ed.input.value.trim();
    const bad = name ? validateName(name) : '';
    if (!name) { ed.err.hidden = false; ed.err.textContent = 'השם ריק'; ed.input.classList.add('bad'); return; }
    if (bad) { ed.err.hidden = false; ed.err.textContent = bad; ed.input.classList.add('bad'); return; }
    if (ed.kind === 'rename' && name === ed.name) { cancelEdit(); tree.focus(); return; }
    const parent = ed.dir;
    const rec = S.dirs.get(K(parent));
    if (rec && rec.entries.some(x => x.name.toLowerCase() === name.toLowerCase() && !(ed.kind === 'rename' && x.k === K(ed.path)))) { ed.err.hidden = false; ed.err.textContent = 'כבר קיים כאן פריט בשם "' + name + '"'; ed.input.classList.add('bad'); return; }
    ed.committing = true;
    try {
      if (ed.kind === 'rename') {
        const r = await post('/api/fs/rename', { from: ed.path, to: name });
        remapPaths(ed.path, r.path);
        S.edit = null; ed.done = true;
        await loadDir(parent); select(r.path, { scroll: false, rk: ed.rk }); render(); S.selEl && S.selEl.scrollIntoView({ block: 'nearest' });
        toast('השם שונה ל-' + name);
      } else {
        const full = joinPath(parent, name);
        const r = await post(ed.kind === 'new-dir' ? '/api/fs/mkdir' : '/api/fs/newfile', { path: full });
        S.edit = null; ed.done = true;
        await loadDir(parent); select(r.path || full, { scroll: false, rk: ed.rk }); render(); S.selEl && S.selEl.scrollIntoView({ block: 'nearest' });
        toast(ed.kind === 'new-dir' ? 'נוצרה תיקייה: ' + name : 'נוצר קובץ: ' + name);
        if (ed.kind === 'new-file') openFile(r.path || full);
      }
      if (tree) tree.focus({ preventScroll: true });
    } catch (e) {
      ed.committing = false;
      ed.err.hidden = false; ed.err.textContent = errMsg(e); ed.input.classList.add('bad'); ed.input.focus();
    }
  }
  // שינוי שם של תיקייה: מעדכן מצב פתוח/נבחר/מטמון של כל מה שמתחתיה (בכל השורשים)
  function remapPaths(from, to) {
    const fk = K(from), prefix = fk.replace(/[\\/]+$/, '');
    const re = p => (p === fk ? K(to) : p.startsWith(prefix) && /[\\/]/.test(p[prefix.length] || '') ? K(to) + p.slice(prefix.length) : p);
    for (const [rk, set] of S.exp) { const n = new Set([...set].map(re)); S.exp.set(rk, n); }
    for (const k of [...S.dirs.keys()]) if (k === fk || (k.startsWith(prefix) && /[\\/]/.test(k[prefix.length] || ''))) S.dirs.delete(k);
    if (S.sel && !S.selRoot && (K(S.sel) === fk || K(S.sel).startsWith(prefix + '\\'))) S.sel = to;
    saveExp();
  }
  function dropPaths(p) { // אחרי מחיקה: שוכחים מצב פתוח/מטמון של מה שהיה מתחת
    const fk = K(p), prefix = fk.replace(/[\\/]+$/, ''), under = k => k === fk || (k.startsWith(prefix) && /[\\/]/.test(k[prefix.length] || ''));
    for (const set of S.exp.values()) for (const k of [...set]) if (under(k)) set.delete(k);
    for (const k of [...S.dirs.keys()]) if (under(k)) S.dirs.delete(k);
    if (S.sel && !S.selRoot && under(K(S.sel))) S.sel = '';
    saveExp();
  }
  async function deleteEntry(ent) {
    if (!ent || ent.root) return;
    const msg = 'למחוק את "' + ent.name + '"' + (ent.dir ? ' וכל תוכנה' : '') + '?\nיועבר לסל המחזור של Windows.';
    const ok = await App.confirm(msg, { okText: 'העבר לסל המחזור', cancelText: 'ביטול', danger: true, title: 'מחיקה' });
    if (!ok) return;
    const parent = parentOf(ent.path);
    const rec = parent && S.dirs.get(K(parent));
    let next = '';
    if (rec) { const l = visList(rec); const i = l.findIndex(x => x.k === ent.k || x.k === K(ent.path)); if (i >= 0) next = (l[i + 1] || l[i - 1] || {}).path || ''; }
    try {
      await post('/api/fs/delete', { path: ent.path });
      dropPaths(ent.path);
      if (parent) await loadDir(parent);
      select(next || '', { scroll: false, rk: ent.rk }); render();
      toast('"' + ent.name + '" הועבר לסל המחזור');
    } catch (e) { toast('המחיקה נכשלה: ' + errMsg(e), 4500); }
  }

  // ============================================================
  //  תפריט הקשר + מקלדת
  // ============================================================
  // "הדבק נתיב ופתח": קורא את הלוח (אם הדפדפן מרשה) ופותח תיקייה/קובץ; אחרת שואל בחלון קטן
  async function pasteAndOpen() {
    let t = '';
    try { t = await navigator.clipboard.readText(); } catch { }
    t = String(t || '').split(/\r?\n/)[0].trim();
    if (!t) { const v = await App.prompt('נתיב', '', { title: 'הדבק נתיב', okText: 'פתח', placeholder: 'C:\\…' }); if (v == null) return; t = String(v).trim(); }
    if (t) await openPath(t);
  }
  const PRIMARY_HINT = 'תיקיית הפרויקט — לשנות בקליק ימני על הטאב';
  // ent: שורת שורש {root:true,...} / תיקייה / קובץ ; null = רקע ריק או שורת הנתיב
  function menuFor(ent) {
    const it = [];
    const mkNew = (dir, rk) => [
      { icon: '📁', label: 'תיקייה חדשה', onClick: () => startNew('new-dir', dir, rk) },
      { icon: '📄', label: 'קובץ חדש', onClick: () => startNew('new-file', dir, rk) }
    ];
    const addItem = { icon: '📂', label: 'הוסף תיקייה ל-Workspace…', onClick: () => addRootFlow() };
    if (!ent) { // רקע ריק / שורת הנתיב: הפעולות פועלות על השורש הראשון
      const first = S.roots[0];
      if (!first) { it.push({ icon: '📥', label: 'הדבק נתיב ופתח', onClick: () => pasteAndOpen() }, { sep: true }, addItem); return it; }
      it.push(...mkNew(first.path, first.k),
        { icon: '📋', label: 'העתק נתיב', onClick: () => App.copyText(first.path, 'הנתיב הועתק') },
        { icon: '📥', label: 'הדבק נתיב ופתח', onClick: () => pasteAndOpen() },
        { icon: '🗂', label: 'הצג בסייר של Windows', onClick: () => osReveal(first.path) },
        { icon: '⟳', label: 'רענן', onClick: () => refresh() },
        { sep: true },
        { icon: '💬', label: 'הכנס נתיב לצ\'אט', onClick: () => insertPath(first.path) },
        addItem);
      return it;
    }
    const p = ent.path;
    if (ent.root) {
      it.push(
        { icon: '✕', label: 'הסר מה-Workspace', hint: ent.primary ? PRIMARY_HINT : '', disabled: !!ent.primary, onClick: () => removeRoot(p) },
        { sep: true }, ...mkNew(p, ent.rk),
        { sep: true },
        { icon: '📋', label: 'העתק נתיב', hint: 'Ctrl+C', onClick: () => App.copyText(p, 'הנתיב הועתק') },
        { icon: '🗂', label: 'הצג בסייר של Windows', onClick: () => osReveal(p) },
        { icon: '⟳', label: 'רענן', onClick: () => refresh() },
        { icon: '💬', label: 'הכנס נתיב לצ\'אט', onClick: () => insertPath(p) },
        { sep: true }, addItem,
        { icon: '🧩', label: 'צור פרויקט מתיקייה זו', onClick: () => makeProject(p) });
      return it;
    }
    const kind = ent.dir ? 'dir' : 'file';
    const newDir = ent.dir ? ent.path : parentOf(ent.path) || (rootByKey(ent.rk) || {}).path;
    if (kind === 'file') it.push({ icon: '📝', label: 'פתח בעורך', hint: 'Enter', onClick: () => openFile(p) }, { icon: '🚀', label: 'פתח באפליקציה', onClick: () => osOpen(p) });
    const rel = (rootByKey(ent.rk) || S.roots[0] || {}).path || '';
    it.push({ icon: '🗂', label: 'הצג בסייר של Windows', onClick: () => osReveal(p) }, { sep: true }, ...mkNew(newDir, ent.rk),
      { icon: '✏️', label: 'שנה שם', hint: 'F2', onClick: () => startRename(ent) },
      { icon: '🗑', label: 'מחק', hint: 'Delete', danger: true, onClick: () => deleteEntry(ent) },
      { sep: true },
      { icon: '📋', label: 'העתק נתיב', hint: 'Ctrl+C', onClick: () => App.copyText(p, 'הנתיב הועתק') },
      { icon: '📋', label: 'העתק נתיב יחסי', onClick: () => App.copyText(relPath(rel, p), 'הנתיב היחסי הועתק') },
      { icon: '💬', label: 'הכנס נתיב לצ\'אט', onClick: () => insertPath(p) });
    if (kind === 'dir') {
      const isRoot = S.roots.some(r => sameP(r.path, p));
      it.push({ sep: true }, { icon: '➕', label: 'הוסף ל-Workspace כתיקייה נפרדת', disabled: isRoot, onClick: () => addRoot(p) }, { icon: '🧩', label: 'צור פרויקט', onClick: () => makeProject(p) });
    }
    return it;
  }
  function showMenu(x, y, ent) {
    const m = App.menu(x, y, menuFor(ent));
    if (m && ent && ent.root && ent.primary) { const b = m.querySelector('.ctx-item:disabled'); if (b && b.querySelector('.ctx-hint')) b.classList.add('fx-hint2'); } // ההסבר מתחת לתווית ולא לצידה (קצר יותר, קריא יותר)
    return m;
  }
  function rowEntry(row) {
    if (!row || !row.dataset.path) return null;
    const rk = row.dataset.rk;
    if (row.dataset.kind === 'root') { const r = rootByKey(rk); return { root: true, rk, path: row.dataset.path, name: r ? r.name : App.baseName(row.dataset.path), dir: true, k: rk, primary: !!(r && r.primary) }; }
    const e = findEntry(row.dataset.path) || { path: row.dataset.path, name: App.baseName(row.dataset.path), dir: row.dataset.kind === 'dir', k: K(row.dataset.path) };
    return { ...e, rk };
  }
  function visibleRows() { return [...rowsHost.children].filter(r => r.dataset.path); }
  function moveSel(delta) {
    const rows = visibleRows(); if (!rows.length) return;
    let i = rows.findIndex(r => r.classList.contains('sel'));
    i = i < 0 ? (delta > 0 ? 0 : rows.length - 1) : Math.max(0, Math.min(rows.length - 1, i + delta));
    selectRow(rows[i]);
  }
  function onTreeKey(e) {
    if (e.target.closest && e.target.closest('input,textarea')) return;
    if (e.ctrlKey && !e.shiftKey && e.key.toLowerCase() === 'c') { if (S.sel) { e.preventDefault(); App.copyText(S.sel, 'הנתיב הועתק'); } return; }
    if (e.ctrlKey || e.altKey || e.metaKey) return;
    const sel = S.selEl ? rowEntry(S.selEl) : null;
    switch (e.key) {
      case 'ArrowDown': e.preventDefault(); moveSel(1); break;
      case 'ArrowUp': e.preventDefault(); moveSel(-1); break;
      case 'Home': e.preventDefault(); { const r = visibleRows(); if (r[0]) selectRow(r[0]); } break;
      case 'End': e.preventDefault(); { const r = visibleRows(); if (r.length) selectRow(r[r.length - 1]); } break;
      case 'ArrowRight': // לפי החוזה: → פותח תיקייה/שורש (ואם כבר פתוח — יורד לילד הראשון)
        if (sel && sel.root) { e.preventDefault(); if (S.rcol.has(sel.rk)) toggleRoot(sel.rk, true); else moveSel(1); }
        else if (sel && sel.dir) { e.preventDefault(); if (!expSet(sel.rk).has(K(sel.path))) toggle(sel.path, true, sel.rk); else moveSel(1); } break;
      case 'ArrowLeft': // ← סוגר תיקייה/שורש פתוחים, אחרת עובר להורה
        if (sel && sel.root) { e.preventDefault(); if (!S.rcol.has(sel.rk)) toggleRoot(sel.rk, false); }
        else if (sel) { e.preventDefault(); if (sel.dir && expSet(sel.rk).has(K(sel.path))) toggle(sel.path, false, sel.rk); else { const par = parentOf(sel.path), r = rootByKey(sel.rk); if (par && r) { if (sameP(par, r.path)) select(r.path, { rk: r.k, root: true }); else select(par, { rk: r.k }); } } } break;
      case 'Enter': if (sel) { e.preventDefault(); if (sel.root) toggleRoot(sel.rk); else if (sel.dir) toggle(sel.path, undefined, sel.rk); else openFile(sel.path); } break;
      case 'F2': if (sel && !sel.root) { e.preventDefault(); startRename(sel); } break;
      case 'Delete': if (sel && !sel.root) { e.preventDefault(); deleteEntry(sel); } break;
      case 'ContextMenu': { e.preventDefault(); const r = S.selEl ? S.selEl.getBoundingClientRect() : tree.getBoundingClientRect(); showMenu(r.left + 30, r.bottom, sel); break; }
      default: break;
    }
  }

  // ============================================================
  //  הדפסת ה-UI: כותרת (שם הפרויקט), כלים, עץ
  // ============================================================
  function buildUI() {
    const body = $('explorerBody'), tools = $('explorerTools');
    if (!body || !tools) throw new Error('explorer containers missing');
    body.innerHTML =
      '<div class="fx-wrap">' +
      '<div class="fx-head" id="fxHead">' +
      '<div class="fx-ws" id="fxWs"><span class="fx-ws-ic">' + SVG_WS + '</span><span class="fx-ws-name" id="fxWsName"></span><span class="fx-ws-cnt" id="fxWsCount"></span></div>' +
      '<span id="fxRootLabel" hidden></span>' +
      '<div class="fx-pathrow"><input id="fxPathInput" class="fx-pathinput" dir="ltr" spellcheck="false" autocomplete="off" placeholder="נתיב…" title="הדבק נתיב ו-Enter"><button class="icon-btn fx-go" id="fxGo" title="פתח (Enter)">↵</button></div>' +
      '<div class="fx-patherr" id="fxPathError" hidden role="alert"></div>' +
      '</div>' +
      '<div class="fx-tree" id="fxTree" tabindex="0" role="tree" aria-label="עץ קבצים"><div class="fx-rows" id="fxRows"></div>' +
      '<div class="fx-empty" id="fxEmpty" hidden><div class="fx-empty-ic">📂</div><div class="fx-empty-t">אין תיקיות</div><button class="btn-ghost fx-small" id="fxEmptyAdd" type="button">＋ הוסף תיקייה</button></div>' +
      '<div class="fx-fill" aria-hidden="true"></div></div>' +
      '</div>';
    tools.innerHTML = '';
    const mk = (id, label, title, fn) => { const b = el('button', 'icon-btn fx-tool'); b.id = id; b.innerHTML = label; b.title = title; b.type = 'button'; b.onclick = fn; tools.appendChild(b); return b; };
    mk('fxHome', '🏠', 'הוסף ממיקומים מהירים: שולחן עבודה, מסמכים, כוננים, פרויקטים', e => showPlaces(e.currentTarget));
    mk('fxAddRoot', '📂<sup>＋</sup>', 'הוסף תיקייה ל-Workspace (חלון בחירה של Windows)', () => addRootFlow());
    mk('fxNewFile', '📄<sup>＋</sup>', 'קובץ חדש (בתיקייה הנבחרת)', () => startNew('new-file'));
    mk('fxNewFolder', '📁<sup>＋</sup>', 'תיקייה חדשה (בתיקייה הנבחרת)', () => startNew('new-dir'));
    mk('fxRefresh', '⟳', 'רענן', () => refresh());
    mk('fxHidden', '👁', 'הצג קבצים נסתרים', () => toggleHidden());
    mk('fxCollapse', '⤢', 'כווץ את כל התיקיות', collapseAll);
    $('fxHidden').classList.toggle('on', S.showHidden);

    tree = $('fxTree'); rowsHost = $('fxRows');
    $('fxEmptyAdd').onclick = () => addRootFlow();
    const inp = $('fxPathInput');
    inp.addEventListener('keydown', e => {
      e.stopPropagation();
      if (e.key === 'Enter') { e.preventDefault(); openPath(inp.value); }
      else if (e.key === 'Escape') { setPathError(''); delete inp.dataset.dirty; inp.value = ''; inp.blur(); }
    });
    inp.addEventListener('input', () => { inp.dataset.dirty = '1'; if (!$('fxPathError').hidden) setPathError(''); });
    inp.addEventListener('focus', () => inp.select());
    inp.addEventListener('blur', () => { setTimeout(() => { if (document.activeElement !== inp && $('fxPathError').hidden) { delete inp.dataset.dirty; inp.value = ''; } }, 150); });
    $('fxGo').onclick = () => openPath(inp.value);

    // --- אירועים על העץ (delegation) ---
    tree.addEventListener('click', e => {
      const row = e.target.closest('.fx-row'); if (!row || e.target.closest('.fx-edit')) return;
      const act = row.dataset.act;
      if (act === 'more') { const rec = S.dirs.get(K(row.dataset.dir)); if (rec) { rec.limit += PAGE; render(); } return; }
      if (act === 'retry') { loadDir(row.dataset.dir).then(() => render()); return; }
      if (!row.dataset.path) return;
      if (e.target.closest('.fx-rx')) { e.stopPropagation(); removeRoot(row.dataset.path); return; }
      selectRow(row, { scroll: false });
      tree.focus({ preventScroll: true }); // שורות draggable לא תמיד מעבירות פוקוס לעץ — בלי זה החצים/F2/Delete לא עובדים אחרי קליק
      if (row.dataset.kind === 'root') { if (e.detail < 2) toggleRoot(row.dataset.rk); return; }
      if (row.dataset.kind === 'dir' && e.detail < 2) toggle(row.dataset.path, undefined, row.dataset.rk);
    });
    tree.addEventListener('dblclick', e => { const row = e.target.closest('.fx-row[data-kind="file"]'); if (row && !e.target.closest('.fx-edit')) openFile(row.dataset.path); });
    tree.addEventListener('contextmenu', e => {
      e.preventDefault();
      const row = e.target.closest('.fx-row[data-path]');
      if (row) selectRow(row, { scroll: false });
      tree.focus({ preventScroll: true });
      showMenu(e.clientX, e.clientY, row ? rowEntry(row) : null);
    });
    $('fxHead').addEventListener('contextmenu', e => { e.preventDefault(); showMenu(e.clientX, e.clientY, null); }); // גם קליק ימני על שורת הנתיב
    tree.addEventListener('keydown', onTreeKey);
    tree.addEventListener('dragstart', e => {
      const row = e.target.closest && e.target.closest('.fx-row[data-path]');
      if (!row || !e.dataTransfer) return;
      const p = row.dataset.path;
      e.dataTransfer.setData('application/x-claude-path', p);
      e.dataTransfer.setData('text/plain', quotePath(p));
      e.dataTransfer.effectAllowed = 'copy';
    });
    tree.addEventListener('mouseover', e => { // טיפ עם גודל/זמן נבנה בעצלתיים (לא ל-2000 שורות מראש)
      const row = e.target.closest && e.target.closest('.fx-row[data-path]');
      if (!row || row.title || row.dataset.kind === 'root') return;
      const ent = findEntry(row.dataset.path); if (!ent) return;
      const d = ent.mtime ? App.fmt.fullDateTime(ent.mtime) : '';
      row.title = ent.name + '\n' + (ent.dir ? 'תיקייה' : App.fmt.size(ent.size)) + (d ? '\nעודכן: ' + d : '') + '\n' + ent.path;
    });
    tree.addEventListener('focus', () => tree.classList.add('focus'));
    tree.addEventListener('blur', () => tree.classList.remove('focus'));
    // רמז גרירה: מסגרת סביב הלוח כשגוררים אליו תיקייה/קובץ (ההוספה ל-Workspace עצמה ב-handleDrop)
    let dd = 0;
    const isDrag = e => { const t = [...((e.dataTransfer && e.dataTransfer.types) || [])]; return t.includes('Files') || t.includes('application/x-claude-path'); };
    const dropOff = () => { dd = 0; body.classList.remove('fx-dropping'); };
    body.addEventListener('dragenter', e => { if (isDrag(e)) { dd++; body.classList.add('fx-dropping'); } });
    body.addEventListener('dragleave', () => { if (--dd <= 0) dropOff(); });
    window.addEventListener('drop', dropOff, true); window.addEventListener('dragend', dropOff, true);
  }

  // ============================================================
  //  גרירה ושחרור
  //  ----------------------------------------------------------------------------
  //  החלטה (תועדה כאן בכוונה): הטיפול בגרירה רשום ב-priority 10, לפני chat.js.
  //   * אם אין בגרירה תיקייה — מחזירים false והצ'אט מצרף את הקבצים כרגיל.
  //   * אם יש תיקייה (מ-Windows): הראשונה נוספת ל-Workspace של הפרויקט הפעיל כשורש נפרד (App.workspace.add), הלוח עובר ל"קבצים".
  //   * קבצים רופפים שנגררו יחד עם התיקייה: אם יש להם נתיב אמיתי (Electron) — מצרפים אותם כאן
  //     ב-App.chats.attachPath ומחזירים true. אם אין נתיב (דפדפן) — לא בולעים אותם: מסירים את התיקיות
  //     מה-snap (כדי ש-chat.js לא ינסה לצרף תיקייה כקובץ) ומחזירים false, והצ'אט מצרף את הקבצים.
  //   * גרירת שורה פנימית מהעץ (application/x-claude-path): תיקייה שנשחררה על הסייר עצמו נוספת כשורש;
  //     כל שאר המקרים (קובץ, או שחרור על הצ'אט) — לא שלנו, chat.js מכניס את הנתיב להודעה.
  // ============================================================
  async function resolveDropped(snap) {
    const cands = [];
    const items = (snap.items || []).filter(i => i.kind === 'file');
    if (items.length) for (const it of items) cands.push({ file: it.file, entry: it.entry, name: (it.entry && it.entry.name) || (it.file && it.file.name) || '' });
    else for (const f of snap.files || []) cands.push({ file: f, entry: null, name: f.name });
    for (const c of cands) {
      c.path = c.file ? App.pathForFile(c.file) : '';
      c.isDir = null;
      if (c.path) { try { const st = await stat(c.path); if (st.exists) { c.isDir = !!st.dir; c.path = st.path; } else c.path = ''; } catch { c.path = ''; } }
      if (c.isDir == null) c.isDir = !!(c.entry && c.entry.isDirectory);
    }
    return cands;
  }
  const inExplorerPanel = t => !!(t && t.closest && t.closest('#view-explorer, #sidepanel'));
  async function handleDrop(snap, ctx) {
    if (!snap) return false;
    if (snap.pathData) { // גרירה פנימית: תיקייה שנשחררה על הסייר → שורש נפרד
      if (!inExplorerPanel(ctx && ctx.target)) return false;
      let st; try { st = await stat(String(snap.pathData).trim()); } catch { return false; }
      if (!st || !st.exists || !st.dir) return false;
      await addRoot(st.path);
      return true;
    }
    const cands = await resolveDropped(snap);
    const dirs = cands.filter(c => c.isDir);
    if (!dirs.length) return false;
    const first = dirs[0];
    let dir = first.path;
    if (!dir) dir = await resolveByName(first.name);
    if (!dir) { pruneSnap(snap, dirs); return true; } // המשתמש ביטל — התיקייה "נצרכה", לא מצרפים אותה כקובץ
    const loose = cands.filter(c => !c.isDir);
    try {
      if (App.view && App.view.show) App.view.show('explorer');
      await addRoot(dir);
    } catch (e) { toast('לא הצלחתי להוסיף את התיקייה: ' + errMsg(e), 5000); return true; }
    let unhandled = 0;
    for (const f of loose) {
      if (f.path && App.chats.attachPath) { try { await App.chats.attachPath(f.path); } catch { unhandled++; } } else unhandled++;
    }
    if (unhandled) { pruneSnap(snap, dirs); return false; } // קבצים בלי נתיב אמיתי: משאירים ל-chat.js
    return true;
  }
  function pruneSnap(snap, dirs) {
    const files = new Set(dirs.map(d => d.file));
    try { snap.items = (snap.items || []).filter(i => !(i.file && files.has(i.file))); snap.files = (snap.files || []).filter(f => !files.has(f)); } catch { }
  }
  async function resolveByName(name) {
    toast('מחפש את התיקייה ' + ltr(name) + ' במחשב…', 8000);
    let r;
    try { r = await api('/api/fs/locate?name=' + enc(name)); } catch (e) { toast('החיפוש נכשל: ' + errMsg(e), 4000); r = { matches: [] }; }
    const m = (r && r.matches) || [];
    if (m.length === 1) return m[0];
    if (m.length > 1) return chooseFolderModal(name, m);
    return askPathModal(name);
  }
  function chooseFolderModal(name, matches) {
    return new Promise(res => {
      let done = false;
      const body = el('div', 'fx-pick-body');
      body.appendChild(el('p', 'fx-pick-msg', 'כמה תיקיות בשם <b>' + esc(name) + '</b> — בחר:'));
      const list = el('div', 'fx-pick-list');
      const m = App.modal({ title: 'איזו תיקייה גררת?', body, cls: 'small fx-pickmodal', onClose: () => { if (!done) { done = true; res(null); } } });
      for (const p of matches) { const b = el('button', 'fx-pick-item'); b.textContent = isoPath(p); b.dir = 'ltr'; b.onclick = () => { done = true; m.close(); res(p); }; list.appendChild(b); }
      body.appendChild(list);
      const other = el('button', 'btn-ghost'); other.textContent = 'אחרת…';
      other.onclick = async () => { done = true; m.close(); res(await askPathModal(name)); };
      body.appendChild(other);
    });
  }
  // name ריק = הוספת תיקייה ל-Workspace ידנית (אין חלון בחירה של המערכת); אחרת: תיקייה שנגררה ולא נמצאה
  function askPathModal(name) {
    return new Promise(res => {
      let done = false;
      const body = el('div', 'fx-pick-body');
      if (name) body.appendChild(el('p', 'fx-pick-msg', 'לא נמצאה <b>' + esc(name) + '</b>. הדבק נתיב או בחר:'));
      const inp = el('input', 'text-input'); inp.dir = 'ltr'; inp.id = 'fxManualPath'; inp.placeholder = 'C:\\Users\\…\\' + (name || 'תיקייה'); inp.spellcheck = false;
      const err = el('div', 'fx-patherr'); err.hidden = true;
      const bar = el('div', 'confirm-bar');
      const pick = el('button', 'btn-ghost'); pick.id = 'fxManualPick'; pick.textContent = '📂 בחר תיקייה…';
      const ok = el('button', 'btn-primary'); ok.id = 'fxManualOk'; ok.textContent = 'הוסף ל-Workspace';
      bar.append(pick, ok); body.append(inp, err, bar);
      const m = App.modal({ title: name ? 'איפה התיקייה?' : 'הוסף תיקייה ל-Workspace', body, cls: 'small fx-pickmodal', onClose: () => { if (!done) { done = true; res(null); } } });
      const finish = p => { done = true; m.close(); res(p); };
      const submit = async () => {
        err.hidden = true;
        const p = inp.value.trim().replace(/^["']+|["']+$/g, ''); if (!p) { err.hidden = false; err.textContent = 'הדבק נתיב'; return; }
        try { const st = await stat(p); if (!st.exists || !st.dir) { err.hidden = false; err.textContent = st.exists ? 'זה לא נתיב של תיקייה' : 'הנתיב לא קיים: ' + st.path; return; } finish(st.path); }
        catch (e) { err.hidden = false; err.textContent = errMsg(e); }
      };
      ok.onclick = submit; inp.onkeydown = e => { if (e.key === 'Enter') submit(); };
      pick.onclick = async () => { try { const p = await pickFolderNative(S.roots[0] && S.roots[0].path); if (p) finish(p); } catch (e) { err.hidden = false; err.textContent = errMsg(e); } };
      setTimeout(() => inp.focus(), 30);
    });
  }
  // ============================================================
  //  מציג / עורך קבצים (חלון קופץ)
  // ============================================================
  let viewer = null;
  async function openFile(path) {
    path = String(path || ''); if (!path) return;
    // מסמכים שאינם טקסט (PDF, Word, Excel, PowerPoint, OpenDocument, ארכיונים…) — נפתחים בתצוגת הקבצים שליד הצ'אט
    if (App.paths && App.paths.show && /\.(pdf|docx?|dotx?|docm|xlsx?|xlsm|xltx?|pptx?|ppsx?|pptm|potx|odt|ods|odp|ott|rtf|zip|jar|war|apk|aab|epub|vsix|nupkg|whl|msg)$/i.test(path)) return App.paths.show(path);
    if (viewer) { if (sameP(viewer.path, path)) { viewer.focus(); return; } if (!(await viewer.requestClose())) return; }
    const v = createViewer(path);
    viewer = v;
    await v.load();
  }
  const topModalIs = m => { const all = document.querySelectorAll('.modal-backdrop'); return all.length && all[all.length - 1] === m.el; };
  function createViewer(path) {
    const name = App.baseName(path), ext = extOf(name);
    const root = el('div', 'fx-v');
    root.innerHTML = '<div class="fx-vbar"><span class="fx-vpath" dir="ltr"></span><div class="fx-vtools"></div></div><div class="fx-vnotice" hidden></div><div class="fx-vmain"><div class="fx-vloading">טוען…</div></div><div class="fx-vstatus"></div>';
    const m = App.modal({ title: name, body: root, cls: 'xwide fx-vmodal', sticky: true, onClose: () => cleanup() });
    m.body.classList.add('fx-vbody');
    const vpath = root.querySelector('.fx-vpath'), vtools = root.querySelector('.fx-vtools'), notice = root.querySelector('.fx-vnotice'), main = root.querySelector('.fx-vmain'), status = root.querySelector('.fx-vstatus');
    vpath.textContent = isoPath(path); vpath.title = path;
    m.titleEl.classList.add('fx-vtitle'); m.titleEl.dir = 'ltr';
    const v = {
      path, name, ext, mode: 'loading', mtime: 0, size: 0, eol: '\n', mixed: false, S0: '', ta: null, readOnly: false, closing: false, blobUrl: '', modal: m,
      isDirty() { return !!(v.ta && !v.readOnly && v.ta.value !== v.S0); },
      focus() { if (v.ta) v.ta.focus(); }
    };
    let cleaned = false, gutT = 0;
    const winKey = e => {
      if (!topModalIs(m)) return;
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); v.requestClose(); }
      else if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey && e.key.toLowerCase() === 's') { e.preventDefault(); e.stopPropagation(); v.save(); }
    };
    window.addEventListener('keydown', winKey, true);
    const beforeUnload = e => { if (v.isDirty()) { e.preventDefault(); e.returnValue = ''; } };
    window.addEventListener('beforeunload', beforeUnload);
    function cleanup() {
      if (cleaned) return; cleaned = true;
      window.removeEventListener('keydown', winKey, true); window.removeEventListener('beforeunload', beforeUnload);
      if (v.blobUrl) { try { URL.revokeObjectURL(v.blobUrl); } catch { } }
      clearTimeout(gutT); clearTimeout(v._st); if (viewer === v) viewer = null;
    }
    // כפתור ה-✕ ו-Esc: בודקים שינויים שלא נשמרו
    const x = m.head.querySelector('button'); if (x) x.onclick = () => v.requestClose();
    v.requestClose = async () => {
      if (v.closing) return false;
      if (v.isDirty()) {
        v.closing = true;
        const ok = await App.confirm('יש שינויים שלא נשמרו ב-"' + name + '".\nלסגור ולאבד אותם?', { okText: 'סגור בלי לשמור', cancelText: 'המשך לערוך', danger: true, title: 'שינויים שלא נשמרו' });
        v.closing = false;
        if (!ok) { v.focus(); return false; }
      }
      m.close(); return true;
    };
    const mkBtn = (label, title, fn, id, cls) => { const b = el('button', cls || 'btn-ghost fx-vbtn'); b.type = 'button'; b.innerHTML = label; b.title = title; if (id) b.id = id; b.onclick = fn; vtools.appendChild(b); return b; };
    const note = (html, kind) => { notice.hidden = !html; notice.className = 'fx-vnotice' + (kind ? ' ' + kind : ''); notice.innerHTML = html || ''; return notice; };
    const bd = t => '<bdi dir="ltr">' + esc(t) + '</bdi>';
    const stat2 = parts => { status.innerHTML = parts.filter(Boolean).map(p => '<span>' + p + '</span>').join(''); };
    const setTitle = () => { m.titleEl.textContent = ''; const t = el('span', 'fx-vname'); t.textContent = name; m.titleEl.appendChild(t); if (v.isDirty()) m.titleEl.appendChild(el('span', 'fx-dirty', ' ●')); };
    const commonBtns = () => {
      mkBtn('📋', 'העתק נתיב מלא', () => App.copyText(path, 'הנתיב הועתק'), 'fxVCopy');
      mkBtn('💬', 'הכנס את הנתיב לתיבת ההודעה בצ\'אט', () => insertPath(path), 'fxVInsert');
      mkBtn('🚀 פתח באפליקציה', 'פתח באפליקציית ברירת המחדל של Windows', () => osOpen(path), 'fxVOpenExt');
    };

    // ---------- מצבים ----------
    function showInfo(icon, msg, extra) {
      v.mode = 'info'; main.innerHTML = '';
      const box = el('div', 'fx-vinfo'); box.innerHTML = '<div class="fx-vinfo-ic">' + icon + '</div><div class="fx-vinfo-t"></div>';
      box.querySelector('.fx-vinfo-t').textContent = msg; main.appendChild(box);
      vtools.innerHTML = ''; commonBtns();
      if (extra) extra(box);
      stat2([v.size ? bd(App.fmt.size(v.size)) : '']); setTitle();
    }
    function showImage(r) {
      v.mode = 'image'; main.innerHTML = ''; vtools.innerHTML = '';
      const w = el('div', 'fx-imgwrap'); const img = el('img', 'zoomable'); img.alt = name; img.src = '/api/fs/raw?path=' + enc(path) + '&_=' + Math.floor(v.mtime || 0);
      img.title = 'לחיצה: הגדלה'; w.appendChild(img); main.appendChild(w);
      img.onload = () => stat2([bd(img.naturalWidth + ' × ' + img.naturalHeight + ' px'), bd(App.fmt.size(v.size)), bd(r.mime || '')]);
      img.onerror = () => showInfo('⚠️', 'שגיאה בתמונה');
      commonBtns();
      if (ext === 'svg') mkBtn('✏️ ערוך כקוד', 'פתח את ה-SVG כטקסט לעריכה', async () => { try { const t = await (await fetch('/api/fs/raw?path=' + enc(path))).text(); vtools.innerHTML = ''; showText({ text: t, mtime: v.mtime, size: v.size }); } catch (e) { toast('הקריאה נכשלה: ' + errMsg(e)); } }, 'fxVEditSvg');
      stat2([bd(App.fmt.size(v.size))]); setTitle();
    }
    async function showPdf() {
      v.mode = 'pdf'; main.innerHTML = '<div class="fx-vloading">טוען PDF…</div>'; vtools.innerHTML = ''; commonBtns();
      try {
        const res = await fetch('/api/fs/raw?path=' + enc(path)); if (!res.ok) throw new Error('HTTP ' + res.status);
        const blob = await res.blob(); v.size = blob.size;
        v.blobUrl = URL.createObjectURL(new Blob([blob], { type: 'application/pdf' }));
        main.innerHTML = ''; const fr = el('iframe', 'fx-pdf'); fr.src = v.blobUrl; fr.title = name; main.appendChild(fr);
        stat2([bd('PDF'), bd(App.fmt.size(v.size))]);
      } catch (e) { showInfo('📕', 'שגיאה ב-PDF: ' + errMsg(e)); }
      setTitle();
    }
    async function showHead() { // קובץ גדול מדי לעריכה: מציגים רק את ההתחלה (קריאה בלבד)
      try {
        const ctl = new AbortController(); const res = await fetch('/api/fs/raw?path=' + enc(path), { signal: ctl.signal });
        const rd = res.body.getReader(); const chunks = []; let got = 0;
        while (got < 262144) { const { done, value } = await rd.read(); if (done) break; chunks.push(value); got += value.length; }
        ctl.abort();
        const buf = new Uint8Array(got); let o = 0; for (const c of chunks) { buf.set(c, o); o += c.length; }
        if (buf.subarray(0, 8000).includes(0)) return;
        const t = new TextDecoder('utf-8').decode(buf.subarray(0, 262144));
        showText({ text: t, mtime: v.mtime, size: v.size }, { readOnly: true, head: true });
      } catch { }
    }
    function showText(r, o = {}) {
      v.mode = 'text'; vtools.innerHTML = ''; main.innerHTML = '';
      const raw = String(r.text == null ? '' : r.text);
      const crlf = (raw.match(/\r\n/g) || []).length, lf = (raw.match(/(?<!\r)\n/g) || []).length;
      v.eol = crlf > lf ? '\r\n' : '\n'; v.mixed = crlf > 0 && lf > 0;
      v.readOnly = !!(o.readOnly || r.truncated); v.mtime = r.mtime || v.mtime; v.size = r.size || v.size;
      v.S0 = raw.replace(/\r\n?/g, '\n');
      v.encBad = raw.includes('\uFFFD');
      // קוד (js/py/css...) תמיד LTR; טקסט/מארקדאון/ללא סיומת: כל פסקה לפי השפה שלה (עברית מיושרת לימין)
      const isCode = !!BADGES[ext] && !['txt', 'md', 'log', 'csv'].includes(ext);
      const wrap = el('div', 'fx-ed' + (isCode ? '' : ' fx-auto')); const gut = el('div', 'fx-gut'); const gin = el('div', 'fx-gin'); gut.appendChild(gin);
      const ta = el('textarea'); ta.id = 'fxEditor'; ta.spellcheck = false; ta.setAttribute('autocomplete', 'off'); ta.setAttribute('autocapitalize', 'off'); ta.readOnly = v.readOnly; ta.value = v.S0;
      wrap.append(gut, ta); main.appendChild(wrap); v.ta = ta;
      let wrapOn = lsGet('fx.wrap', '0') === '1';
      const applyWrap = () => { ta.setAttribute('wrap', wrapOn ? 'soft' : 'off'); wrap.classList.toggle('wrapped', wrapOn); layoutGutter(true); };
      // ----- פס כלים -----
      commonBtns();
      const wb = mkBtn('↩ גלישה', 'גלישת שורות (Wrap)', () => { wrapOn = !wrapOn; lsSet('fx.wrap', wrapOn ? '1' : '0'); wb.classList.toggle('on', wrapOn); applyWrap(); }, 'fxVWrap'); wb.classList.toggle('on', wrapOn);
      let saveBtn = null;
      if (!v.readOnly) saveBtn = mkBtn('💾 שמור <kbd>Ctrl+S</kbd>', 'שמור את הקובץ (Ctrl+S)', () => v.save(), 'fxSave', 'btn-primary fx-vbtn fx-save');
      if (v.readOnly) note(o.head ? '🔒 קובץ גדול (' + App.fmt.size(v.size) + ') — קריאה בלבד' : '🔒 נחתך — קריאה בלבד', 'warn');
      else if (v.encBad) note('⚠️ קידוד חשוד — שמירה עלולה להשחית', 'warn');
      else if (v.mixed) note('ℹ️ סוף-שורה מעורב — יאוחד ל-' + (v.eol === '\r\n' ? 'CRLF' : 'LF'), 'info');
      // ----- מספרי שורות -----
      let lastN = -1;
      const mirror = el('div', 'fx-mirror'); wrap.appendChild(mirror);
      function layoutGutter(force) {
        const val = ta.value; let n = 1; for (let i = val.indexOf('\n'); i >= 0; i = val.indexOf('\n', i + 1)) n++;
        v.lines = n;
        if (!wrapOn || n > 4000) {
          if (force || n !== lastN || gin.dataset.mode !== 'plain') { let s = ''; for (let i = 1; i <= n; i++) s += i + '\n'; gin.textContent = s; gin.dataset.mode = 'plain'; gin.style.removeProperty('height'); }
        } else { // גלישה: מדדים כמה גובה תופסת כל שורה כדי שהמספרים יישארו מיושרים
          const cs = getComputedStyle(ta); mirror.style.width = (ta.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight)) + 'px';
          mirror.textContent = ''; const frag = document.createDocumentFragment();
          for (const l of val.split('\n')) { const d = document.createElement('div'); d.textContent = l || ' '; frag.appendChild(d); }
          mirror.appendChild(frag);
          const hs = [...mirror.children].map(c => c.offsetHeight);
          gin.textContent = ''; const f2 = document.createDocumentFragment();
          hs.forEach((h, i) => { const d = document.createElement('div'); d.textContent = i + 1; d.style.height = h + 'px'; f2.appendChild(d); }); gin.appendChild(f2); gin.dataset.mode = 'wrap';
        }
        lastN = n; gin.style.transform = 'translateY(' + (-ta.scrollTop) + 'px)'; updateStatus();
      }
      const schedGutter = () => { clearTimeout(gutT); gutT = setTimeout(() => layoutGutter(false), wrapOn ? 120 : 30); };
      ta.addEventListener('scroll', () => { gin.style.transform = 'translateY(' + (-ta.scrollTop) + 'px)'; });
      // ----- שורת מצב -----
      let savedT = 0, savedFlash = false;
      function updateStatus() {
        const pos = ta.selectionStart, val = ta.value; let line = 1, last = -1;
        for (let i = val.indexOf('\n'); i >= 0 && i < pos; i = val.indexOf('\n', i + 1)) { line++; last = i; }
        const bytes = new Blob([v.eol === '\r\n' ? val.replace(/\n/g, '\r\n') : val]).size;
        stat2([
          'שורה ' + line + ', עמודה ' + (pos - last),
          (v.lines || 1) + ' שורות',
          '<bdi dir="ltr">' + App.fmt.size(bytes) + '</bdi>',
          '<bdi dir="ltr">UTF-8</bdi>', '<bdi dir="ltr">' + (v.eol === '\r\n' ? 'CRLF' : 'LF') + '</bdi>',
          v.readOnly ? '🔒 קריאה בלבד' : '',
          savedFlash ? '<b class="fx-saved" id="fxSaved">נשמר ✓</b>' : ''
        ]);
        const sv = $('fxSave'); if (sv) sv.classList.toggle('dirty', v.isDirty());
        setTitle();
      }
      v.flashSaved = () => { savedFlash = true; updateStatus(); clearTimeout(savedT); savedT = setTimeout(() => { savedFlash = false; updateStatus(); }, 2500); };
      v.updateStatus = updateStatus;
      ta.addEventListener('input', () => { schedGutter(); updateStatus(); });
      for (const ev of ['keyup', 'click', 'select', 'focus']) ta.addEventListener(ev, () => { clearTimeout(v._st); v._st = setTimeout(updateStatus, 40); });
      // ----- מקלדת: Tab = רווחים, Enter שומר הזחה -----
      const TAB = /\n\t/.test('\n' + v.S0) && !/\n {2,}\S/.test('\n' + v.S0) ? '\t' : '  ';
      const insert = txt => { if (!document.execCommand('insertText', false, txt)) ta.setRangeText(txt, ta.selectionStart, ta.selectionEnd, 'end'); };
      ta.addEventListener('keydown', e => {
        if (e.isComposing || v.readOnly) return;
        if (e.key === 'Tab' && !e.ctrlKey && !e.altKey && !e.metaKey) {
          e.preventDefault();
          const s = ta.selectionStart, en = ta.selectionEnd, val = ta.value;
          if (!e.shiftKey && s === en) { insert(TAB); return; }
          const ls = val.lastIndexOf('\n', s - 1) + 1; let le = val.indexOf('\n', en > s && val[en - 1] === '\n' ? en - 1 : en); if (le < 0) le = val.length;
          const lines = val.slice(ls, le).split('\n'); let firstDelta = 0, total = 0;
          const out = lines.map((l, i) => { let nl; if (e.shiftKey) { nl = l.startsWith('\t') ? l.slice(1) : l.replace(/^ {1,2}/, ''); } else nl = TAB + l; if (i === 0) firstDelta = nl.length - l.length; total += nl.length - l.length; return nl; });
          ta.setSelectionRange(ls, le); insert(out.join('\n'));
          ta.setSelectionRange(Math.max(ls, s + firstDelta), en + total);
          schedGutter(); updateStatus();
        } else if (e.key === 'Enter' && !e.ctrlKey && !e.altKey && !e.metaKey && !e.shiftKey) {
          const s = ta.selectionStart, val = ta.value; const ls = val.lastIndexOf('\n', s - 1) + 1; const ind = (/^[ \t]*/.exec(val.slice(ls, s)) || [''])[0];
          if (ind) { e.preventDefault(); insert('\n' + ind); }
        }
      });
      applyWrap();
      ta.focus(); ta.setSelectionRange(0, 0);
      if (v.eol === '\r\n' || v.mixed) { /* מוצג בשורת המצב */ }
    }

    // ---------- שמירה ----------
    v.save = async () => {
      if (v.mode !== 'text' || v.readOnly) return false;
      if (!v.isDirty()) { toast('אין שינויים לשמור'); return true; }
      if (v.saving) return false; v.saving = true;
      try {
        if (v.encBad && !v.encOk) { const ok = await App.confirm('בקובץ יש תווים שלא נראים כ-UTF-8 תקין. שמירה עלולה להשחית אותו. לשמור בכל זאת?', { okText: 'שמור בכל זאת', danger: true, title: 'קידוד חשוד' }); if (!ok) return false; v.encOk = true; }
        const st = await stat(path).catch(() => null);
        if (st && st.exists && v.mtime && Math.abs(st.mtime - v.mtime) > 2) {
          const ok = await App.confirm('הקובץ השתנה בדיסק אחרי שפתחת אותו (אולי Claude עדכן אותו).\nלדרוס את הגרסה שבדיסק בשינויים שלך?', { okText: 'דרוס', cancelText: 'ביטול', danger: true, title: 'הקובץ השתנה בדיסק' });
          if (!ok) return false;
        }
        const val = v.ta.value, out = v.eol === '\r\n' ? val.replace(/\n/g, '\r\n') : val;
        const r = await post('/api/fs/write', { path, text: out });
        v.mtime = r.mtime; v.size = r.size; v.S0 = val; v.extNote = false; note('');
        v.flashSaved(); setTitle();
        const par = parentOf(path); if (par) { const rec = S.dirs.get(K(par)); if (rec) loadDir(par, { quiet: true }).then(x => { if (x.changed) render(); }); }
        return true;
      } catch (e) { toast('השמירה נכשלה: ' + errMsg(e), 5000); note('❌ השמירה נכשלה: ' + esc(errMsg(e)), 'err'); return false; }
      finally { v.saving = false; }
    };

    // ---------- טעינה ----------
    v.load = async () => {
      setTitle();
      if (ext === 'pdf') return showPdf();
      let r;
      try { r = await api('/api/fs/read?path=' + enc(path)); }
      catch (e) { return showInfo('⚠️', errMsg(e)); }
      v.mtime = r.mtime || 0; v.size = r.size || 0;
      if (r.image) return showImage(r);
      if (r.binary) return showInfo('🧱', 'קובץ בינארי');
      if (r.tooLarge) { showInfo('🐘', 'קובץ גדול מדי (' + App.fmt.size(r.size) + ')'); return showHead(); }
      showText(r);
    };
    // בדיקה מחזורית: Claude (או תוכנה אחרת) שינה את הקובץ בדיסק בזמן שהוא פתוח
    v.poll = async () => {
      if (v.mode !== 'text' || v.saving || v.reloading) return;
      let st; try { st = await stat(path); } catch { return; }
      if (!st.exists || !v.mtime || Math.abs(st.mtime - v.mtime) <= 2 || st.mtime === v.extSeen) return;
      if (!v.isDirty()) { await v.reload(true); return; }
      v.extSeen = st.mtime;
      const n = note('⚠️ הקובץ השתנה בדיסק <button class="btn-ghost fx-small" id="fxReload">טען מחדש</button>', 'warn');
      const b = n.querySelector('#fxReload'); if (b) b.onclick = () => v.reload(false);
    };
    v.reload = async silent => {
      if (v.reloading) return; v.reloading = true;
      try {
        const r = await api('/api/fs/read?path=' + enc(path)); if (!r || r.text == null) return;
        const ta = v.ta, st = ta.scrollTop, sel = ta.selectionStart;
        v.mtime = r.mtime; v.size = r.size; v.S0 = String(r.text).replace(/\r\n?/g, '\n'); ta.value = v.S0;
        const crlf = (r.text.match(/\r\n/g) || []).length, lf = (r.text.match(/(?<!\r)\n/g) || []).length; v.eol = crlf > lf ? '\r\n' : '\n';
        ta.scrollTop = st; ta.setSelectionRange(Math.min(sel, ta.value.length), Math.min(sel, ta.value.length)); note('');
        ta.dispatchEvent(new Event('input')); toast(silent ? 'הקובץ עודכן מהדיסק' : 'הקובץ נטען מחדש');
      } catch (e) { toast('הטעינה מחדש נכשלה: ' + errMsg(e)); } finally { v.reloading = false; }
    };
    return v;
  }

  // ============================================================
  //  רענון מחזורי (Claude יוצר קבצים בזמן שאתה מסתכל) + אירועים
  // ============================================================
  function isShown() { const v = $('view-explorer'), sp = $('sidepanel'); return !!v && !v.hidden && !(sp && sp.classList.contains('collapsed')); }
  function windowActive() { return document.visibilityState === 'visible' && (document.hasFocus()); }
  function tick() {
    try { syncRoots(); } catch { } // רשת ביטחון למקרה שאירוע workspace אבד (בלי רשת, זול)
    if (!windowActive()) return;
    if (isShown()) refreshVisible().catch(() => { });
    if (viewer) viewer.poll().catch(() => { });
  }
  function startTimer() {
    if (S.timer) return;
    let n = 0;
    S.timer = setInterval(() => { // 4 שניות; כשצ'אט רץ — כל 2 שניות (קבצים שהוא יוצר)
      n++; let running = false; try { const a = App.chats && App.chats.active && App.chats.active(); running = !!(a && a.running); } catch { }
      if (running || n % 2 === 0) tick();
    }, 2000);
  }

  // ============================================================
  //  אתחול
  // ============================================================
  function init() {
    try { buildUI(); } catch (e) { console.error('[explorer] init failed', e); return; }
    try { startTimer(); } catch (e) { console.error('[explorer] timer', e); }
    try {
      App.registerDrop({ name: 'explorer', priority: 10, handle: (snap, ctx) => handleDrop(snap, ctx) });
    } catch (e) { console.error('[explorer] drop', e); }
    const safe = fn => (...a) => { try { const r = fn(...a); if (r && r.catch) r.catch(e => console.error('[explorer]', e)); } catch (e) { console.error('[explorer]', e); } };
    // ה-Workspace של הפרויקט הפעיל הוא מקור האמת לשורשים: כל אחד מהאירועים האלה מסנכרן (סינכרון זהה = לא עושה כלום)
    for (const ev of ['workspace:changed', 'project:activated', 'projects:changed']) App.on(ev, safe(() => syncRoots()));
    App.on('projects:ready', safe(() => { S.ready = true; syncRoots(); render(); }));
    App.on('chat:running', safe(d => { if (d && d.running === false) setTimeout(() => { if (isShown()) refreshVisible({ force: true }).catch(() => { }); }, 400); }));
    App.on('view:shown', safe(name => { if (name === 'explorer') { syncRoots(); refreshVisible({ force: true }); } }));
    window.addEventListener('focus', safe(() => { if (isShown()) refreshVisible(); }));
    document.addEventListener('visibilitychange', safe(() => { if (document.visibilityState === 'visible' && isShown()) refreshVisible(); }));
    setTimeout(() => { S.ready = true; render(); }, 3000); // עד שהפרויקטים נטענו לא מציגים "אין תיקיות"

    App.explorer = {
      open: p => openPath(p),
      reveal: p => reveal(p),
      refresh: () => refresh(),
      openFile: p => openFile(p),
      selected: () => S.sel,
      roots: () => S.roots.map(r => ({ path: r.path, name: r.name, primary: r.primary })),
      addRoot: p => addRoot(p),
      removeRoot: p => removeRoot(p),
      getRoot: () => (S.roots[0] ? S.roots[0].path : ''), // תיקיית הפרויקט (השורש הראשון)
      setRoot: p => addRoot(p),                          // תאימות לאחור: אין עוד "שורש יחיד" — מוסיף ל-Workspace
      // עזרים לבדיקות
      _state: () => ({ roots: S.roots.map(r => r.path), project: S.pid, sel: S.sel, showHidden: S.showHidden, expanded: [].concat(...S.roots.map(r => [...expSet(r.k)])), collapsedRoots: S.roots.filter(r => S.rcol.has(r.k)).map(r => r.path), viewer: viewer ? { path: viewer.path, mode: viewer.mode, dirty: viewer.isDirty() } : null })
    };

    (async () => {
      try { const pl = await getPlaces(); S.home = pl.home || ''; } catch { }
      syncRoots(true);
    })().catch(e => console.error('[explorer] boot', e));
  }
  App.ready(() => { try { init(); } catch (e) { console.error('[explorer]', e); } });
})();
