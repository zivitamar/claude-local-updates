'use strict';
// ============================================================
//  הכתבה קולית חיה בתיבת הכתיבה (עברית + English).
//  מיקרופון -> AudioWorklet (PCM 16kHz) -> WebSocket /api/stt/ws -> השרת -> מנוע whisper מקומי.
//  מילים מופיעות תוך כדי דיבור (טקסט ביניים מסומן), ומתקבעות כשיש הפסקה קצרה בדיבור. לחיצה שנייה = עצירה.
//  עובד גם בדפדפן וגם ב-EXE (הרשאת media ל-origin המקומי ב-electron/main.js).
// ============================================================
(function () {
  // עותק מדויק של stt-worklet.js (גיבוי — נטען רק אם הקובץ עצמו לא נגיש). בדיקת build מוודאת שהם זהים
  const WORKLET_SRC = "'use strict';\n// הכתבה קולית: לוכד את המיקרופון בתוך AudioWorklet וממיר ל-PCM 16 ביט, 16kHz מונו, במנות של 100ms.\n// אם ה-AudioContext לא רץ על 16kHz (דפדפן שמסרב) — דגימה מחדש כאן (ממוצע על כל חלון של יחס הדגימה).\nclass SttCapture extends AudioWorkletProcessor {\n  constructor() {\n    super();\n    this.ratio = sampleRate / 16000;\n    this.out = new Int16Array(1600); this.n = 0;\n    this.acc = 0; this.accN = 0; this.pos = 0; this.peak = 0;\n  }\n  push(v) {\n    v = Math.max(-1, Math.min(1, v));\n    const a = Math.abs(v); if (a > this.peak) this.peak = a;\n    this.out[this.n++] = v < 0 ? v * 32768 : v * 32767;\n    if (this.n === this.out.length) {\n      const buf = this.out.buffer;\n      this.port.postMessage({ pcm: buf, level: this.peak }, [buf]);\n      this.out = new Int16Array(1600); this.n = 0; this.peak = 0;\n    }\n  }\n  process(inputs) {\n    const ch = inputs[0] && inputs[0][0];\n    if (!ch) return true;\n    if (this.ratio === 1) { for (let i = 0; i < ch.length; i++) this.push(ch[i]); return true; }\n    for (let i = 0; i < ch.length; i++) {\n      this.acc += ch[i]; this.accN++; this.pos += 1;\n      if (this.pos >= this.ratio) { this.push(this.acc / this.accN); this.acc = 0; this.accN = 0; this.pos -= this.ratio; }\n    }\n    return true;\n  }\n}\nregisterProcessor('stt-capture', SttCapture);\n";
  const toast = (t, ms) => { try { window.App && App.toast ? App.toast(t, ms || 5000) : console.warn(t); } catch { } };
  let current = null;          // הכתבה פעילה אחת בכל רגע
  let warmed = false;

  const MIRROR_PROPS = ['fontFamily', 'fontSize', 'fontWeight', 'fontStyle', 'fontVariant', 'lineHeight', 'letterSpacing', 'wordSpacing', 'textIndent', 'textTransform', 'direction', 'unicodeBidi', 'textAlign',
    'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft', 'borderTopWidth', 'borderRightWidth', 'borderBottomWidth', 'borderLeftWidth', 'boxSizing', 'tabSize', 'whiteSpace', 'overflowWrap', 'wordBreak'];

  function micError(e) {
    const n = e && e.name;
    if (n === 'NotAllowedError' || n === 'SecurityError' || n === 'PermissionDeniedError') return 'הגישה למיקרופון חסומה. אשר גישה למיקרופון (בדפדפן: סמל המנעול ליד הכתובת; ב-Windows: הגדרות › פרטיות › מיקרופון) ונסה שוב.';
    if (n === 'NotFoundError' || n === 'OverconstrainedError' || n === 'DevicesNotFoundError') return 'לא נמצא מיקרופון במחשב. חבר מיקרופון ונסה שוב.';
    if (n === 'NotReadableError' || n === 'TrackStartError') return 'המיקרופון תפוס על ידי תוכנה אחרת. סגור אותה ונסה שוב.';
    return 'לא ניתן להפעיל את המיקרופון: ' + ((e && e.message) || e);
  }

  class Dictation {
    constructor(chat) {
      this.chat = chat; this.ta = chat.$input; this.btn = chat.pane.querySelector('.cb-mic');
      this.parts = []; this.interim = ''; this.skipUtt = false; this.state = 'idle'; this.queue = [];
      this.onInput = () => this.rebase(true);
    }

    setState(st) {
      this.state = st;
      if (!this.btn) return;
      this.btn.classList.toggle('rec', st === 'rec' || st === 'loading');
      this.btn.classList.toggle('wait', st === 'loading' || st === 'finishing');
      this.btn.title = st === 'idle' ? 'הכתבה קולית (עברית / English) — לחיצה: התחל לדבר'
        : st === 'finishing' ? 'מסיים לזהות…' : st === 'loading' ? 'טוען את מנוע זיהוי הדיבור… (אפשר כבר לדבר)' : 'מקליט — לחיצה: עצור';
      this.btn.setAttribute('aria-pressed', st === 'idle' ? 'false' : 'true');
      if (st === 'idle') this.btn.style.removeProperty('--lvl');
    }

    // ----- הטקסט בתיבה: [לפני] + [מה שנאמר: סופי + ביניים] + [אחרי] -----
    rebase(skipCurrent) {
      const ta = this.ta;
      this.pre = ta.value.slice(0, ta.selectionStart); this.post = ta.value.slice(ta.selectionEnd);
      this.parts = [];
      if (skipCurrent && this.interim) this.skipUtt = true; // הטקסט של המשפט הנוכחי כבר בתיבה — לא להכניס אותו שוב
      this.interim = ''; this.lastValue = ta.value; this.mirror(0, 0);
    }
    write() {
      const ta = this.ta;
      if (ta.value !== this.lastValue) this.rebase(true);  // התיבה השתנתה מבחוץ (שליחה / עריכה)
      const fin = this.parts.join(' ');
      const said = [fin, this.interim].filter(Boolean).join(' ');
      const s1 = this.pre && said && !/\s$/.test(this.pre) ? ' ' : '';
      const s2 = this.post && said && !/^\s/.test(this.post) ? ' ' : '';
      const v = this.pre + s1 + said + s2 + this.post;
      const iStart = this.pre.length + s1.length + (this.interim ? said.length - this.interim.length : said.length);
      const caret = this.pre.length + s1.length + said.length;
      ta.value = v; this.lastValue = v;
      try { ta.setSelectionRange(caret, caret); } catch { }
      if (this.chat.autoGrow) this.chat.autoGrow();
      this.mirror(iStart, iStart + this.interim.length);
    }
    // סימון טקסט הביניים: שכבה מתחת ל-textarea עם אותו פריסה בדיוק, ורקע רק למילים שעוד לא סופיות
    mirror(s, e) {
      const ta = this.ta;
      if (s >= e) { if (this.$m) { this.$m.remove(); this.$m = null; } return; }
      let m = this.$m;
      if (!m) { m = this.$m = document.createElement('div'); m.className = 'stt-mirror'; m.setAttribute('aria-hidden', 'true'); ta.parentNode.insertBefore(m, ta); }
      const cs = getComputedStyle(ta);
      for (const p of MIRROR_PROPS) m.style[p] = cs[p];
      m.style.width = ta.offsetWidth + 'px'; m.style.height = ta.offsetHeight + 'px'; m.style.top = ta.offsetTop + 'px'; m.style.left = ta.offsetLeft + 'px';
      const v = ta.value, mark = document.createElement('mark');
      mark.className = 'stt-interim'; mark.textContent = v.slice(s, e);
      m.replaceChildren(document.createTextNode(v.slice(0, s)), mark, document.createTextNode(v.slice(e) + '​'));
      m.scrollTop = ta.scrollTop;
    }

    async start() {
      const ta = this.ta;
      this.setState('loading');
      ta.focus(); this.rebase(false); this.skipUtt = false;
      this.placeholder = ta.placeholder; ta.placeholder = '🎤 מקשיב… דבר בעברית או באנגלית';
      this.chat.$composer && this.chat.$composer.classList.add('stt-on');
      ta.addEventListener('input', this.onInput);
      // בתוך אפליקציית הטלפון: המיקרופון של הטלפון עצמו (Kotlin, ערוץ 'stt' המוצפן ל-Whisper של המחשב).
      // ה-WebView לא יכול לפתוח WebSocket דרך השער — לכן "ws" כאן הוא גשר: אותן הודעות, אותו onMsg
      const phone = window.ClaudePhone;
      if (phone && typeof phone.sttStart === 'function') {
        const self = this;
        window.__claudePhoneStt = data => { if (current === self) self.onMsg(data); };
        this.ws = { readyState: 1, send(s) { try { if (JSON.parse(s).op === 'stop') phone.sttStop(); } catch { } }, close() { try { phone.sttCancel(); } catch { } } };
        try { const r = phone.sttStart(); if (r && r !== 'ok') { toast('🎤 ' + r, 7000); return this.finish(); } }
        catch (e) { toast('🎤 ' + e.message, 7000); return this.finish(); }
        return;
      }
      // 1) מיקרופון
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw Object.assign(new Error('אין גישה למיקרופון בממשק הזה'), { name: 'NotSupported' });
        this.stream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
      } catch (e) { toast('🎤 ' + micError(e), 7000); return this.finish(); }
      if (this.state === 'idle') { this.stopTracks(); return; }
      // 2) חיבור לשרת
      try {
        this.ws = new WebSocket((location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/api/stt/ws');
        this.ws.binaryType = 'arraybuffer';
      } catch (e) { toast('🎤 אין חיבור לשרת ההכתבה: ' + e.message, 7000); return this.finish(); }
      this.ws.onopen = () => { this.ws.send(JSON.stringify({ op: 'start', lang: 'auto' })); for (const b of this.queue) this.ws.send(b); this.queue = []; };
      this.ws.onmessage = ev => this.onMsg(ev.data);
      this.ws.onerror = () => { if (this.state !== 'idle' && !this.gotMsg) toast('🎤 אין חיבור לשרת ההכתבה (WebSocket).', 6000); };
      this.ws.onclose = () => { if (this.state !== 'idle') this.finish(); };
      // 3) לכידת אודיו 16kHz
      try {
        try { this.ctx = new AudioContext({ sampleRate: 16000 }); } catch { this.ctx = new AudioContext(); }
        // הלוכד נטען מהקובץ; אם הקובץ לא נגיש (שרת שהתחלף, 404, מחשב מרוחק…) — מאותו קוד בדיוק שמוטמע כאן. ההקלטה עובדת תמיד, באותה איכות
        try { await this.ctx.audioWorklet.addModule('stt-worklet.js'); }
        catch (e1) { console.warn('[stt] worklet file failed, using the built-in copy:', e1.message); const u = URL.createObjectURL(new Blob([WORKLET_SRC], { type: 'application/javascript' })); try { await this.ctx.audioWorklet.addModule(u); } finally { URL.revokeObjectURL(u); } }
        const src = this.ctx.createMediaStreamSource(this.stream);
        this.node = new AudioWorkletNode(this.ctx, 'stt-capture', { numberOfInputs: 1, numberOfOutputs: 1, channelCount: 1, channelCountMode: 'explicit' });
        const mute = this.ctx.createGain(); mute.gain.value = 0;
        src.connect(this.node); this.node.connect(mute); mute.connect(this.ctx.destination);
        this.node.port.onmessage = ev => {
          const { pcm, level } = ev.data;
          if (this.btn) this.btn.style.setProperty('--lvl', Math.min(1, level * 3).toFixed(2));
          if (this.state === 'finishing' || this.state === 'idle') return;
          if (this.ws && this.ws.readyState === 1) this.ws.send(pcm); else if (this.queue.length < 600) this.queue.push(pcm);
        };
        if (this.ctx.state === 'suspended') await this.ctx.resume();
      } catch (e) { toast('🎤 לכידת האודיו נכשלה: ' + e.message, 7000); return this.finish(); }
    }

    onMsg(data) {
      let m; try { m = JSON.parse(data); } catch { return; }
      this.gotMsg = true;
      if (m.type === 'status') {
        if (m.state === 'loading') { if (this.state === 'loading') toast('🎤 טוען את מנוע זיהוי הדיבור (בפעם הראשונה כמה שניות)… אפשר כבר לדבר.', 4000); }
        else if (m.state === 'ready' && this.state === 'loading') this.setState('rec');
        return;
      }
      if (m.type === 'partial') { if (this.state === 'loading') this.setState('rec'); if (this.skipUtt) return; this.interim = m.text || ''; this.write(); return; }
      if (m.type === 'final') {
        if (this.skipUtt) { this.skipUtt = false; return; }
        if (m.text) this.parts.push(m.text);
        this.interim = ''; this.write(); return;
      }
      if (m.type === 'done') return this.finish();
      if (m.type === 'error') { toast('🎤 ' + (m.message || 'שגיאה בזיהוי הדיבור'), 8000); return this.finish(); }
    }

    stopTracks() {
      try { this.stream && this.stream.getTracks().forEach(t => t.stop()); } catch { }
      try { this.node && (this.node.port.onmessage = null); this.ctx && this.ctx.close(); } catch { }
      this.stream = null; this.ctx = null; this.node = null;
    }

    // לחיצה שנייה: המיקרופון נסגר מיד, והשרת מסיים לזהות את מה שכבר נאמר
    stop() {
      if (this.state === 'idle' || this.state === 'finishing') return;
      this.stopTracks();
      if (this.ws && this.ws.readyState === 1) {
        this.setState('finishing');
        if (this.btn) this.btn.style.removeProperty('--lvl');
        try { this.ws.send(JSON.stringify({ op: 'stop' })); } catch { }
        this.finTimer = setTimeout(() => this.finish(), 20000);
      } else this.finish();
    }

    finish() {
      if (this.state === 'idle' && !this.ws && !this.stream) return;
      clearTimeout(this.finTimer);
      this.stopTracks();
      const ws = this.ws; this.ws = null;
      if (ws) { ws.onclose = null; try { ws.close(); } catch { } }
      this.ta.removeEventListener('input', this.onInput);
      if (this.placeholder !== undefined) this.ta.placeholder = this.placeholder;
      // טקסט ביניים שנשאר (למשל ניתוק) נשאר בתיבה כטקסט רגיל
      this.interim = ''; this.mirror(0, 0);
      this.chat.$composer && this.chat.$composer.classList.remove('stt-on');
      this.setState('idle');
      if (current === this) current = null;
    }
  }

  window.Dictation = {
    toggle(chat) {
      if (current && current.chat === chat) { current.state === 'finishing' ? current.finish() : current.stop(); return; }
      if (current) current.stop();
      current = new Dictation(chat);
      current.start();
    },
    // מעלה את המנוע ברקע (ריחוף על הכפתור) כדי שהלחיצה הראשונה לא תחכה לטעינת המודל
    warm() { if (warmed) return; warmed = true; fetch('/api/stt/warm', { method: 'POST' }).catch(() => { warmed = false; }); },
    // נשלחה הודעה מהצ'אט הזה בזמן הקלטה: כיבוי מיידי (בלי לחכות לזיהוי האחרון — מה שהיה בתיבה כבר נשלח)
    stopForSend(chat) { if (current && current.chat === chat && current.state !== 'idle') { current.finish(); return true; } return false; },
    active: () => current
  };
})();
