'use strict';
// הכתבה קולית: לוכד את המיקרופון בתוך AudioWorklet וממיר ל-PCM 16 ביט, 16kHz מונו, במנות של 100ms.
// אם ה-AudioContext לא רץ על 16kHz (דפדפן שמסרב) — דגימה מחדש כאן (ממוצע על כל חלון של יחס הדגימה).
class SttCapture extends AudioWorkletProcessor {
  constructor() {
    super();
    this.ratio = sampleRate / 16000;
    this.out = new Int16Array(1600); this.n = 0;
    this.acc = 0; this.accN = 0; this.pos = 0; this.peak = 0;
  }
  push(v) {
    v = Math.max(-1, Math.min(1, v));
    const a = Math.abs(v); if (a > this.peak) this.peak = a;
    this.out[this.n++] = v < 0 ? v * 32768 : v * 32767;
    if (this.n === this.out.length) {
      const buf = this.out.buffer;
      this.port.postMessage({ pcm: buf, level: this.peak }, [buf]);
      this.out = new Int16Array(1600); this.n = 0; this.peak = 0;
    }
  }
  process(inputs) {
    const ch = inputs[0] && inputs[0][0];
    if (!ch) return true;
    if (this.ratio === 1) { for (let i = 0; i < ch.length; i++) this.push(ch[i]); return true; }
    for (let i = 0; i < ch.length; i++) {
      this.acc += ch[i]; this.accN++; this.pos += 1;
      if (this.pos >= this.ratio) { this.push(this.acc / this.accN); this.acc = 0; this.accN = 0; this.pos -= this.ratio; }
    }
    return true;
  }
}
registerProcessor('stt-capture', SttCapture);
