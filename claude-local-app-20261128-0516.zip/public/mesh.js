// ============================================================
//  mesh.js (ממשק) — "מחשבים": פס המחשבים בראש סרגל הפעילות. כל מחשב = עיגול עם ראשי תיבות וצבע קבוע,
//  נקודה ירוקה/כתומה + מספר: כמה צ'אטים עובדים / סיימו בו עכשיו. קליק = כל המסך עובר למחשב ההוא (הפרויקטים, הצ'אטים,
//  הקבצים וה-Claude שלו) תוך שנייה; קליק על "המחשב הזה" חוזר. ריחוף = כרטיס זהות מלא. קליק ימני = שם / רענון / הסרה.
//  צלילים ממחשבים אחרים מגיעים בזרם המקומי של הרשת ומושמעים לפי הגדרות הצלילים שלך לכל מחשב.
// ============================================================
(function () {
  'use strict';
  const App = window.App, el = App.el, esc = App.esc;
  const S = { machines: [], selfId: null, beacon: null, es: null, cardId: null };
  const current = () => (window.MESH && MESH.remote) || S.selfId;
  const byId = id => S.machines.find(m => m.id === id) || null;
  const hue = id => { let h = 0; for (const c of String(id)) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
  // צבע של מחשב: מה שבחרת (קליק ימני → שינוי צבע), אחרת צבע קבוע לפי המזהה. נשמר במחשב שלך (localStorage "mesh.colors")
  const COLORS_KEY = 'mesh.colors';
  const customColors = () => { try { return JSON.parse(localStorage.getItem(COLORS_KEY) || '{}') || {}; } catch { return {}; } };
  const setColor = (id, c) => { const all = customColors(); if (c) all[id] = c; else delete all[id]; try { localStorage.setItem(COLORS_KEY, JSON.stringify(all)); } catch { } };
  const colorOf = id => { const c = customColors()[id]; return /^#[0-9a-f]{6}$/i.test(c || '') ? c : `hsl(${hue(id)} 62% 52%)`; };
  // צבע האותיות על העיגול: לבן או שחור — מה שנותן ניגודיות גבוהה יותר (צהוב/ירוק → שחור, כחול/אדום → לבן), תמיד ≥ 4.5:1
  let cnv = null;
  const fgOf = id => {
    try {
      cnv = cnv || document.createElement('canvas').getContext('2d'); cnv.fillStyle = '#000'; cnv.fillStyle = colorOf(id); // הדפדפן מנרמל כל צבע ל-#rrggbb
      const hx = String(cnv.fillStyle); const lin = i => { const v = parseInt(hx.slice(i, i + 2), 16) / 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
      const L = 0.2126 * lin(1) + 0.7152 * lin(3) + 0.0722 * lin(5);
      return 1.05 / (L + 0.05) >= (L + 0.05) / 0.05 ? '#fff' : '#000';
    } catch { return '#fff'; }
  };
  const PALETTE = ['#e5484d', '#f76b15', '#ffc53d', '#46a758', '#12a594', '#0090ff', '#3e63dd', '#8e4ec6', '#d6409f', '#ad7f58', '#8b8d98', '#202020'];
  const initials = name => { const w = String(name || '?').replace(/[^\p{L}\p{N}\s-]/gu, ' ').trim().split(/[\s-]+/).filter(Boolean); return ((w[0] || '?')[0] + (w[1] ? w[1][0] : (w[0] || '').slice(1, 2))).toUpperCase(); };
  const ago = ts => { if (!ts) return '—'; const s = Math.round((Date.now() - ts) / 1000); return s < 60 ? 'עכשיו' : s < 3600 ? `לפני ${Math.round(s / 60)} דק'` : s < 86400 ? `לפני ${Math.round(s / 3600)} שע'` : `לפני ${Math.round(s / 86400)} ימים`; };
  const nameOf = id => { const m = byId(id); return m ? m.displayName : id; };
  // סוג המכשיר: טלפון (האפליקציה לאנדרואיד מצטרפת עם kind:'phone') או מחשב — העיגול מציג אייקון במקום ראשי תיבות
  const kindOf = m => { const i = (m && m.info) || {}; return i.kind === 'phone' || i.platform === 'android' ? 'phone' : 'computer'; };
  const ICONS = {
    computer: '<svg class="mach-ic" viewBox="0 0 24 24" aria-hidden="true"><rect x="2.5" y="4" width="19" height="12.5" rx="2" fill="none" stroke="currentColor" stroke-width="2"/><path d="M8 20.5h8M12 16.5v4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    phone: '<svg class="mach-ic" viewBox="0 0 24 24" aria-hidden="true"><rect x="6.5" y="2" width="11" height="20" rx="2.6" fill="none" stroke="currentColor" stroke-width="2"/><path d="M10.5 18.3h3" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>'
  };
  const iconOf = m => ICONS[kindOf(m)];
  const kindWord = m => (kindOf(m) === 'phone' ? 'טלפון' : 'מחשב');

  // ---------- פס המחשבים ----------
  function ensureRail() {
    let rail = document.getElementById('machineRail'); if (rail) return rail;
    const bar = document.getElementById('activitybar'); if (!bar) return null;
    rail = el('div', 'mach-rail'); rail.id = 'machineRail'; rail.setAttribute('aria-label', 'מחשבים');
    bar.insertBefore(rail, bar.firstChild);
    bar.insertBefore(el('div', 'mach-sep'), rail.nextSibling);
    return rail;
  }
  function render() {
    const rail = ensureRail(); if (!rail) return;
    rail.innerHTML = '';
    const cur = current();
    for (const m of S.machines) {
      const sum = m.self ? m.summary : m.summary || {}; const run = (sum && sum.run) || 0, done = (sum && sum.done) || 0;
      const b = el('button', 'mach' + (m.id === cur ? ' active' : '') + (m.online ? ' online' : ' offline') + (m.self ? ' self' : ''));
      b.dataset.id = m.id; b.style.setProperty('--mc', colorOf(m.id)); b.style.setProperty('--mc-fg', fgOf(m.id));
      const phone = kindOf(m) === 'phone';
      b.classList.add('k-' + kindOf(m));
      b.innerHTML = `<span class="mach-av">${iconOf(m)}</span><span class="mach-st"></span>`
        + (run ? `<span class="mach-n run" title="צ'אטים שעובדים">${run}</span>` : '') + (done ? `<span class="mach-n done" title="צ'אטים שסיימו">${done}</span>` : '')
        + `<small class="mach-lb">${esc(m.self ? 'המחשב הזה' : String(m.displayName).slice(0, 10))}</small>`;
      b.setAttribute('aria-label', (m.self ? 'המחשב הזה: ' : kindWord(m) + ': ') + m.displayName);
      b.title = phone ? 'טלפון — לחיצה: פרטי הטלפון · קליק ימני: שם, צבע ועוד' : m.id === cur ? 'לחיצה: פרטי המחשב · קליק ימני: שם, צבע ועוד' : 'לחיצה: עבור למחשב הזה · קליק ימני: פרטים, שם, צבע ועוד';
      // קליק שמאלי: על המחשב שאתה עליו — כרטיס הפרטים (פתיחה/סגירה); על מחשב אחר — מעבר אליו; על טלפון — הכרטיס שלו
      // (טלפון שולט במחשבים, אין בו סביבת עבודה לעבור אליה). קליק ימני: רק התפריט
      b.onclick = () => { if (m.id === cur || phone) { if (S.cardId === m.id) hideCard(); else card(b, m); } else { hideCard(); switchTo(m.id); } };
      b.oncontextmenu = e => { e.preventDefault(); e.stopPropagation(); hideCard(); menu(e.clientX, e.clientY, m, b); };
      rail.appendChild(b);
      if (S.cardId === m.id && cardEl) card(b, m); // הרשימה התעדכנה (מונים חיים) — הכרטיס הפתוח מתעדכן במקום
    }
    const add = el('button', 'mach mach-add'); add.innerHTML = '<span class="mach-av">＋</span><small class="mach-lb">הוסף</small>'; add.title = 'הוספת מחשב'; add.onclick = addDialog;
    rail.appendChild(add);
    // 🧹 one tap clears stale duplicates (offline copies of the same name, old emulators) — owner-only on the server
    { const names = {}; let junk = 0; const selfN = String((S.machines.find(x => x.self) || {}).displayName || '').toLowerCase();
      for (const m of S.machines.filter(x => !x.self).sort((x, y) => (y.online - x.online) || ((y.lastSeen || 0) - (x.lastSeen || 0)))) { const k = String(m.displayName || '').toLowerCase(); if (!m.online && (k === selfN || names[k] || /^sdk_gphone/.test(k))) junk++; names[k] = 1; }
      if (junk) { const c = el('button', 'mach mach-add mach-clean'); c.innerHTML = `<span class="mach-av">🧹</span><small class="mach-lb">נקה ${junk}</small>`; c.title = 'הסר מכשירים כפולים / ישנים שלא מחוברים'; c.onclick = async () => { c.disabled = true; try { const r = await App.api('/api/mesh/clean', { method: 'POST', body: {} }); S.machines = r.machines || S.machines; render(); App.toast && App.toast('🧹 הוסרו ' + r.removed + ' מכשירים', 3000); } catch (e) { c.disabled = false; App.toast && App.toast('❌ ' + e.message, 4000); } }; rail.appendChild(c); } }
    paintTopbar();
  }
  // סימון ברור למעלה: על איזה מחשב עובדים עכשיו (לא מתבלבלים)
  function paintTopbar() {
    const brand = document.querySelector('#topbar .brand'); if (!brand) return;
    let tag = brand.querySelector('.mach-tag'); const cur = current(), m = byId(cur);
    if (!window.MESH || !MESH.remote) { if (tag) tag.remove(); document.documentElement.style.removeProperty('--mach-color'); document.body.classList.remove('on-remote'); return; }
    if (!tag) { tag = el('span', 'mach-tag'); brand.appendChild(tag); }
    tag.textContent = (m && kindOf(m) === 'phone' ? '📱 ' : '🖥 ') + (m ? m.displayName : cur) + (m && !m.online ? ' (לא מחובר)' : '');
    tag.title = 'עובד עכשיו על המחשב הזה — לחיצה חוזרת למחשב שלך'; tag.onclick = () => switchTo(S.selfId);
    document.documentElement.style.setProperty('--mach-color', colorOf(cur)); document.documentElement.style.setProperty('--mach-fg', fgOf(cur)); document.body.classList.add('on-remote');
    paintLoginBtn();
  }
  // המחשב שעובדים עליו עוד לא מחובר לחשבון Claude: כפתור התחברות — נפתח הדפדפן שלך, ואחרי שאתה מאשר החזרה עוברת ברשת למחשב ההוא
  function paintLoginBtn() {
    const brand = document.querySelector('#topbar .brand'); if (!brand || !window.MESH || !MESH.remote) return;
    const cfg = (App.state && App.state.config) || {}; let b = brand.querySelector('.mach-login');
    const need = cfg.accountMode === 'subscription' && cfg.cliLoggedIn === false;
    if (!need) { if (b) b.remove(); return; }
    if (!b) { b = el('button', 'mach-login', '🔑 התחבר לחשבון Claude במחשב הזה'); brand.appendChild(b); b.onclick = remoteLogin; }
  }
  async function remoteLogin() {
    const id = MESH.remote; let r;
    try { r = await App.api('/api/mesh/remote-login', { body: { id } }); } catch (e) { App.toast('❌ ' + e.message, 5000); return; }
    if (r.already) { App.toast('המחשב כבר מחובר לחשבון'); App.loadConfig(); return; }
    App.toast('🌐 נפתח הדפדפן — אשר שם, וההתחברות תגיע למחשב ' + nameOf(id), 8000);
    const t0 = Date.now();
    const iv = setInterval(async () => {
      if (Date.now() - t0 > 15 * 60 * 1000) { clearInterval(iv); return; }
      const s = await App.api('/api/mesh/remote-login-status?machine=' + id + '&id=' + encodeURIComponent(r.loginId)).catch(() => null);
      if (s && s.status === 'success') { clearInterval(iv); App.toast('✅ המחשב ' + nameOf(id) + ' מחובר לחשבון Claude', 5000); App.loadConfig().then(paintLoginBtn); }
      else if (s && s.status && s.status !== 'pending') { clearInterval(iv); App.toast('❌ ההתחברות נכשלה: ' + (s.error || s.status), 6000); }
    }, 2000);
  }
  App.on('config:changed', () => paintLoginBtn());
  // ---------- מעבר מחשב ----------
  function switchTo(id) {
    if (!id || id === current()) return;
    const m = byId(id);
    if (m && !m.self && kindOf(m) === 'phone') return; // טלפון לא מגיש סביבת עבודה — אין לאן לעבור
    if (m && !m.self && !m.online) { App.toast(`🖥 ${m.displayName} לא מחובר כרגע (נראה ${ago(m.lastSeen)})`, 3500); return; }
    try { sessionStorage.setItem('mesh.switchAt', String(performance.timeOrigin + performance.now())); } catch { }
    try { if (id === S.selfId) sessionStorage.removeItem('mesh.active'); else sessionStorage.setItem('mesh.active', id); } catch { }
    location.href = id === S.selfId ? '/?local=1' : '/?m=' + id;
  }
  // ---------- כרטיס זהות ----------
  let cardEl = null;
  function card(anchor, m) {
    hideCard(); const i = m.info || {}; const sum = m.summary || {};
    cardEl = el('div', 'mach-card'); cardEl.style.setProperty('--mc', colorOf(m.id)); cardEl.style.setProperty('--mc-fg', fgOf(m.id));
    const rows = [
      ['מזהה', m.id], [kindOf(m) === 'phone' ? 'מכשיר' : 'מחשב', (kindOf(m) === 'phone' ? [i.model, i.host].filter(Boolean)[0] : i.host) || '—'], ['משתמש', i.user || '—'], ['מערכת', [i.os, i.arch].filter(Boolean).join(' · ') || '—'],
      ['כתובות', (i.ips || []).join(', ') || '—'], ['גרסה', i.version || '—'],
      ['חיבור', m.self ? 'המחשב הזה' : m.online ? `${m.path === 'local' ? 'מקומי' : 'ישיר'}${m.addr ? ' · ' + m.addr : ''}${m.rtt != null ? ' · ' + m.rtt + 'ms' : ''}` : 'לא מחובר · ' + ago(m.lastSeen)],
      ['צ\'אטים', `${sum.run || 0} עובדים · ${sum.done || 0} סיימו`]
    ];
    cardEl.innerHTML = `<div class="mc-head"><span class="mach-av">${iconOf(m)}</span><div><b></b><small>${m.self ? 'המחשב הזה' : (kindOf(m) === 'phone' ? '📱 טלפון · ' : '') + (m.online ? '🟢 מחובר' : '⚪ לא מחובר')}${m.via && !m.self ? ' · הצטרף ' + (m.via === 'account' ? 'דרך חשבון Claude' : m.via === 'manual' ? 'ידנית' : /^phone/.test(m.via) ? 'מהטלפון' : 'דרך מחשב אחר') : ''}</small></div></div>`
      + `<table>${rows.map(([k, v]) => `<tr><th>${esc(k)}</th><td dir="auto">${esc(v)}</td></tr>`).join('')}</table>`
      + ((sum.runningTitles || []).length ? `<div class="mc-run">${sum.runningTitles.map(t => `<div>🟢 ${esc(t)}</div>`).join('')}</div>` : '');
    cardEl.querySelector('.mc-head b').textContent = m.displayName;
    const x = el('button', 'mc-close', '✕'); x.title = 'סגור (Esc)'; x.onclick = hideCard; cardEl.appendChild(x);
    document.body.appendChild(cardEl); S.cardId = m.id;
    const r = anchor.getBoundingClientRect(); cardEl.style.top = Math.max(8, Math.min(innerHeight - cardEl.offsetHeight - 8, r.top - 6)) + 'px';
    cardEl.style.left = (r.right + 8) + 'px';
  }
  function hideCard() { if (cardEl) { cardEl.remove(); cardEl = null; } S.cardId = null; }
  // הכרטיס נסגר בלחיצה בכל מקום אחר, ב-Esc ובמעבר לחלון אחר — לא נשאר תקוע
  document.addEventListener('mousedown', e => { if (cardEl && !cardEl.contains(e.target) && !(e.target.closest && e.target.closest('.mach.active'))) hideCard(); }, true);
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && cardEl) hideCard(); });
  window.addEventListener('blur', () => hideCard());
  // ---------- תפריט (קליק ימני) ----------
  function menu(x, y, m, anchor) {
    App.menu(x, y, [
      { icon: 'ℹ️', label: kindOf(m) === 'phone' ? 'פרטי הטלפון' : 'פרטי המחשב', onClick: () => { const b = document.querySelector(`.mach[data-id="${m.id}"]`) || anchor; if (b) card(b, m); } },
      { icon: '✏️', label: 'שינוי שם', onClick: async () => { const n = await App.prompt('שם למחשב (יופיע בכל המחשבים):', m.name || m.displayName, { title: 'שם מחשב', okText: 'שמור' }); if (n == null) return; await App.api('/api/mesh/rename', { body: { id: m.id, name: n } }); load(); } },
      { icon: '🎨', label: 'שינוי צבע', onClick: () => colorMenu(x, y, m) },
      { icon: '📋', label: 'העתק מזהה', onClick: () => App.copyText(m.id) },
      { sep: true },
      { icon: '🔄', label: 'חפש עכשיו מחשבים חדשים בחשבון', hint: 'בלי לחכות', onClick: async () => { await App.api('/api/mesh/discover', { method: 'POST' }).catch(() => { }); App.toast('🔄 מחפש מחשבים שמחוברים לאותו חשבון Claude… מחשב חדש יופיע כאן תוך כחצי דקה', 5000); } },
      !m.self && { icon: '🚫', label: 'הסר מהרשת', danger: true, onClick: async () => { if (!(await App.confirm(`להסיר את "${m.displayName}" מכל המחשבים? הוא יחזור רק אם יתחבר שוב לחשבון.`, { danger: true, okText: 'הסר' }))) return; await App.api('/api/mesh/revoke', { body: { id: m.id } }); load(); } }
    ]);
  }
  // בחירת צבע: 12 צבעים + צבע חופשי + חזרה לצבע האוטומטי
  function colorMenu(x, y, m) {
    const cur = (customColors()[m.id] || '').toLowerCase();
    const box = el('div', 'mach-palette');
    const apply = c => { setColor(m.id, c); App.menuClose(); render(); App.emit('mesh:changed', S.machines); };
    for (const c of PALETTE) { const s = el('button', 'mpal-sw' + (cur === c ? ' on' : '')); s.style.background = c; s.title = c; s.onclick = e => { e.stopPropagation(); apply(c); }; box.appendChild(s); }
    const pick = el('label', 'mpal-custom'); pick.title = 'צבע אחר…'; pick.innerHTML = '<span>🎨</span>';
    const inp = el('input'); inp.type = 'color'; inp.value = /^#[0-9a-f]{6}$/i.test(cur) ? cur : '#0090ff'; inp.onchange = () => apply(inp.value); pick.appendChild(inp); box.appendChild(pick);
    App.menu(x, y, [
      { el: box },
      { sep: true },
      { icon: '↺', label: 'צבע אוטומטי', disabled: !cur, onClick: () => apply(null) }
    ]);
  }
  function addDialog() {
    const b = S.beacon || {};
    const body = el('div', 'mach-add-dlg');
    body.innerHTML = `<p><b>מחשב חדש מצטרף לבד:</b></p>
      <ol><li>מתקינים עליו את האפליקציה (Windows / Linux).</li><li>מתחברים בה לאותו חשבון Claude.</li><li>הוא מופיע כאן תוך דקה — בלי קוד ובלי אישור.</li></ol>
      <p>או בצ'אט: <code>תתקין את האפליקציה על השרת … דרך SSH</code> — Claude יתקין ויחזיר לך את קישור ההתחברות.</p>
      <p class="mach-beacon">מצב החיבור לחשבון: <b></b></p>`;
    body.querySelector('.mach-beacon b').textContent = b.state === 'connected' ? '🟢 מחובר (' + (b.name || '') + ')' : b.state ? b.state + (b.error ? ' — ' + b.error : '') : 'כבוי';
    const closers = []; const m = App.modal({ title: '🖥 הוספת מחשב', body, onClose: () => closers.forEach(f => { try { f(); } catch { } }) }); m.closers = closers;
    const r = el('button', 'btn-primary', '🔄 חפש עכשיו'); r.onclick = async () => { await App.api('/api/mesh/discover', { method: 'POST' }).catch(() => { }); App.toast('מחפש…'); m.close(); };
    body.appendChild(r);
    // ----- טלפון: צימוד עם QR / קוד, ואימות שהוא שלך דרך חשבון Claude -----
    const ph = el('div', 'mach-phone');
    ph.innerHTML = `<p><b>📱 טלפון (האפליקציה לאנדרואיד):</b> סרוק את הקוד באפליקציה או הקלד אותו. אחר כך מאשרים פעם אחת בחשבון Claude — והטלפון שולט בכל המחשבים.</p>`;
    const pb = el('button', 'btn-primary', '📱 חבר טלפון'); pb.onclick = () => phonePair(ph, m); ph.appendChild(pb);
    body.appendChild(ph);
  }
  function loadQrLib() { return window.qrcode ? Promise.resolve() : new Promise((ok, no) => { const s = document.createElement('script'); s.src = 'vendor/qrcode.js'; s.onload = ok; s.onerror = no; document.head.appendChild(s); }); }
  async function phonePair(box, modal) {
    let w; try { w = await App.api('/api/mesh/enroll', { method: 'POST', body: {} }); } catch (e) { App.toast('❌ ' + e.message, 5000); return; }
    box.innerHTML = `<div class="mp-qr" aria-label="קוד QR לצימוד"></div><div class="mp-code" dir="ltr"></div><div class="mp-meta"><span class="mp-left"></span> · <span class="mp-state">ממתין לטלפון…</span></div><div class="mp-acts"></div>`;
    box.querySelector('.mp-code').textContent = w.code;
    try { await loadQrLib(); const q = window.qrcode(0, 'M'); q.addData(w.qr); q.make(); box.querySelector('.mp-qr').innerHTML = q.createSvgTag({ cellSize: 4, margin: 3, scalable: true }); } catch { box.querySelector('.mp-qr').textContent = 'QR לא זמין — הקלד את הקוד'; }
    const acts = box.querySelector('.mp-acts'), stEl = box.querySelector('.mp-state'), leftEl = box.querySelector('.mp-left');
    const approve = el('button', 'btn-primary', '✓ אשר את הטלפון מכאן'); approve.hidden = true;
    approve.onclick = async () => { const r = await App.api('/api/mesh/enroll/' + w.nonce + '/approve-here', { method: 'POST', body: {} }).catch(e => ({ error: e.message })); if (!r.ok) App.toast('❌ ' + (r.error || 'נכשל'), 4000); };
    const cancel = el('button', 'btn-ghost', 'בטל'); cancel.onclick = () => { App.api('/api/mesh/enroll/' + w.nonce + '/cancel', { method: 'POST', body: {} }).catch(() => { }); stop(); modal.close(); };
    acts.append(approve, cancel);
    const paintLeft = () => { const s = Math.max(0, Math.round((w.expiresAt - Date.now()) / 1000)); leftEl.textContent = Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }; paintLeft(); const tick = setInterval(paintLeft, 500);
    const es = new EventSource('/api/mesh/enroll/' + w.nonce);
    const stop = () => { clearInterval(tick); es.close(); };
    es.addEventListener('enroll', e => {
      let d; try { d = JSON.parse(e.data); } catch { return; }
      const last = (d.log || [])[d.log.length - 1]; stEl.textContent = last ? last.text : d.state;
      approve.hidden = d.state !== 'needs-pc-approval';
      box.dataset.state = d.state;
      if (d.state === 'done') { stop(); App.toast('📱 ' + ((d.phone && (d.phone.model || d.phone.name)) || 'הטלפון') + ' נוסף לרשת', 5000); setTimeout(() => { try { modal.close(); } catch { } load(); }, 1800); }
      if (['expired', 'cancelled', 'rejected', 'gone'].includes(d.state)) stop();
    });
    (modal.closers || []).push(() => { stop(); if (!['done', 'rejected', 'expired', 'cancelled'].includes(box.dataset.state)) App.api('/api/mesh/enroll/' + w.nonce + '/cancel', { method: 'POST', body: {} }).catch(() => { }); });
  }
  // ---------- נתונים חיים ----------
  async function load() {
    try { const r = await App.api('/api/mesh/info'); if (!r.enabled) return; S.selfId = r.self.id; S.machines = r.machines || []; S.beacon = r.beacon; render(); App.emit('mesh:changed', S.machines); } catch { }
  }
  function connect() {
    if (S.es) return;
    const es = S.es = new EventSource('/api/mesh/events');
    es.addEventListener('machines', e => { try { const d = JSON.parse(e.data); S.machines = d.machines || S.machines; if (d.self) S.selfId = d.self; if (d.beacon !== undefined) S.beacon = d.beacon; render(); App.emit('mesh:changed', S.machines); } catch { } });
    // צלילים ממחשבים אחרים (וגם מהמחשב שלך כשאתה עובד על מחשב אחר). צלילי המחשב שמוצג עכשיו מגיעים כבר בזרם הרגיל שלו
    es.addEventListener('sound', e => { try { const d = JSON.parse(e.data); if (!d || !d.machine || d.machine === current()) return; App.emit('sound:event', { ...d, machineName: nameOf(d.machine) }); } catch { } });
    es.onerror = () => { };
  }
  App.mesh = { machines: () => S.machines, current, selfId: () => S.selfId, nameOf, colorOf, fgOf, initials, kindOf, iconOf, switchTo, reload: load };
  App.ready(() => { load().then(connect); });
  // מדידה: כמה זמן לקח המעבר (מהקליק עד שהממשק של המחשב החדש מוכן)
  App.ready(() => { try { const t = +sessionStorage.getItem('mesh.switchAt'); if (t) { sessionStorage.removeItem('mesh.switchAt'); window.__meshSwitchMs = Math.round(performance.timeOrigin + performance.now() - t); } } catch { } });
})();
