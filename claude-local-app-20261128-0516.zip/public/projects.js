// ============================================================
//  projects.js — מודל הפרויקטים:
//   • הטאבים למעלה = פרויקטים (שם + נתיב מתחת). ＋ = פרויקט חדש. קליק ימני = שינוי שם / תיקייה / מחיקה...
//   • בצד ימין: רק השיחות של הפרויקט הפעיל, מסודרות בתיקיות שיחות (אייקון תיקייה+Claude). שיחה חדשה נוצרת רק שם.
//   • נקודות: ירוקה לכל צ'אט שעובד, כתומה כשסיים (נעלמת כשנכנסים אליו) — בטאב הפרויקט וליד כל צ'אט. צליל בכל סיום.
//   • Workspace רב-תיקיות: תיקיית הפרויקט + תיקיות נוספות (App.workspace)
//  המידע החי מגיע מהשרת ב-SSE (/api/events), כך שהכל מתעדכן מיד, גם כשהשיחה רצה מתזרים או משיחה אחרת.
// ============================================================
(function () {
  const App = window.App, $ = App.$, el = App.el, esc = App.esc, fmt = App.fmt;
  const ls = { get: k => { try { return localStorage.getItem(k); } catch { return null; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch { } } };
  const jget = (k, d) => { try { const v = JSON.parse(ls.get(k)); return v == null ? d : v; } catch { return d; } };
  const S = { projects: [], convs: new Map(), open: jget('proj.open', []), active: ls.get('proj.active') || null, last: jget('proj.last', {}), ready: false, es: null, esWasOpen: false };
  const byId = id => S.projects.find(p => p.id === id) || null;
  const activeProject = () => byId(S.active);
  const persist = () => { ls.set('proj.open', JSON.stringify(S.open)); ls.set('proj.active', S.active || ''); ls.set('proj.last', JSON.stringify(S.last)); };
  const chatsOf = pid => [...S.convs.values()].filter(c => c.projectId === pid && !c.research) // שיחות מחקר (c.research) הן לא צ'אטים: מופיעות רק באזור המחקרים
    .sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
  const dirShort = d => { d = String(d || ''); const parts = d.split(/[\\/]+/).filter(Boolean); return parts.length <= 3 ? d : parts[0] + '\\…\\' + parts.slice(-2).join('\\'); };
  const FOLDER_SVG = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M3 6.5A1.5 1.5 0 0 1 4.5 5h4.2l1.8 2H19.5A1.5 1.5 0 0 1 21 8.5v9a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 17.5z" fill="currentColor" opacity=".16" stroke="currentColor" stroke-width="1.4"/><path d="M12 9.6l.8 2.2 2.3-.9-1.1 2.1 2.1 1.1-2.4.4.2 2.4-1.9-1.5-1.9 1.5.2-2.4-2.4-.4 2.1-1.1-1.1-2.1 2.3.9z" fill="#d97757"/></svg>';

  // ---------------------------------------------------------------- טעינה
  let reloadT = null, reloading = null; const lastEv = new Map(); // id -> זמן האירוע החי האחרון (כדי שרענון ישן לא ידרוס מצב חדש יותר)
  async function reload() {
    if (reloading) return reloading;
    reloading = (async () => {
      const t0 = Date.now();
      try {
        const [pr, cv] = await Promise.all([App.api('/api/projects'), App.api('/api/conversations')]);
        S.projects = pr.projects || [];
        const prev = S.convs; S.convs = new Map();
        for (const c of cv.conversations || []) {
          const p0 = prev.get(c.id);
          if (p0 && (lastEv.get(c.id) || 0) >= t0 - 50) S.convs.set(c.id, { ...c, running: p0.running, unseen: p0.unseen, title: p0.title || c.title }); // האירוע החי חדש יותר מהתשובה
          else S.convs.set(c.id, { ...c });
        }
        // שיחות שרצות אצלנו לוקאלית ועוד לא הגיעו מהשרת — נשארות
        for (const [id, c] of prev) if (!S.convs.has(id) && c._local) S.convs.set(id, c);
        const ids = new Set(S.projects.map(p => p.id));
        S.open = S.open.filter(id => ids.has(id));
        if (!S.projects.length) return;
        const g = S.projects.find(p => p.general) || S.projects[0];
        if (!S.open.length) S.open.push(g.id);
        if (!S.active || !ids.has(S.active)) S.active = S.open[0];
        if (!S.open.includes(S.active)) S.open.push(S.active);
        persist();
      } catch (e) { console.warn('[projects] reload', e.message); }
      finally { reloading = null; renderAll(); App.emit('projects:changed', {}); }
    })();
    return reloading;
  }
  const reloadSoon = () => { clearTimeout(reloadT); reloadT = setTimeout(reload, 250); };

  // ---------------------------------------------------------------- נקודות + צליל
  function dotsFor(list) { const run = list.filter(c => c.running).length, done = list.filter(c => !c.running && c.unseen).length; return { run, done }; }
  function dotsHtml({ run, done }, max = 5) {
    let h = '', n = 0;
    for (let i = 0; i < run && n < max; i++, n++) h += '<i class="pd run" title="צ\'אט עובד"></i>';
    for (let i = 0; i < done && n < max; i++, n++) h += '<i class="pd done" title="צ\'אט סיים"></i>';
    const more = run + done - n; if (more > 0) h += `<b class="pd-more">+${more}</b>`;
    return h;
  }
  const recentStop = new Map();
  App.on('chat:userstop', d => { if (d && d.id) recentStop.set(d.id, Date.now()); });
  function onFinished(c) {
    if (recentStop.has(c.id) && Date.now() - recentStop.get(c.id) < 20000) return; // המשתמש עצר בעצמו
    // הצליל של "Claude סיים" מגיע עכשיו מהשרת (אירוע 'sound' → sound.js, לפי הגדרות הצלילים והפרויקט) — לא מכאן
    (App.chimeLog = App.chimeLog || []).push({ id: c.id, code: c.code, at: Date.now() });
    App.emit('chat:finished', { id: c.id, code: c.code, title: c.title, projectId: c.projectId });
  }
  const isViewing = id => { const a = App.chats && App.chats.active(); return !!(a && a.id === id && !document.hidden); };
  function markSeen(id) {
    const s = S.convs.get(id); if (!s || !s.unseen) return;
    s.unseen = false; renderAll();
    App.api('/api/conversations/' + id + '/seen', { method: 'POST', body: {} }).catch(() => { });
  }
  function onState(d) {
    const prev = S.convs.get(d.id); lastEv.set(d.id, Date.now());
    S.convs.set(d.id, { ...(prev || {}), ...d, updatedAt: Date.now() });
    if (!prev) reloadSoon();
    if (prev && prev.running && !d.running) onFinished(S.convs.get(d.id));
    if (d.running) { const pane = App.chats.byConvId(d.id); if (pane && pane.loaded && !pane.running && !pane._attaching) pane.attachLoop(); }
    if (d.unseen && !d.running && isViewing(d.id)) markSeen(d.id);
    const pane = App.chats.byConvId(d.id);
    if (pane) { let ch = false; if (d.title && d.title !== pane.title) { pane.title = d.title; ch = true; } if (d.code && d.code !== pane.code) { pane.code = d.code; ch = true; } if (ch) pane.updateHead(); }
    renderAll();
  }
  function connectEvents() {
    if (S.es) return;
    const es = S.es = new EventSource('/api/events');
    es.onopen = () => { if (S.esWasOpen) reload(); S.esWasOpen = true; };
    es.addEventListener('chat_state', e => { try { onState(JSON.parse(e.data)); } catch { } });
    es.addEventListener('chat_removed', e => { try { const d = JSON.parse(e.data); S.convs.delete(d.id); const pane = App.chats.byConvId(d.id); if (pane) App.chats.closeTab(pane); renderAll(); } catch { } });
    es.addEventListener('sound', e => { try { const d = JSON.parse(e.data); if (window.MESH && MESH.remote) { d.machine = MESH.remote; d.machineName = App.mesh ? App.mesh.nameOf(MESH.remote) : ''; } App.emit('sound:event', d); } catch { } }); // צלילים: מה Claude עושה עכשיו (במחשב שמוצג)
    // כתבת הודעה מהטלפון → השיחה נפתחת כאן על המסך מיד (גם אם לא הייתה פתוחה) והתשובה זורמת חי. כיבוי: config.followPhone=false
    // חשבון Claude התחלף (גם מחוץ לאפליקציה): החשבון, השימוש והמודלים נטענים מחדש מיד
    es.addEventListener('update_status', e => { try { App.emit('update:status', JSON.parse(e.data)); } catch { } });
    es.addEventListener('account_changed', e => { try { App.emit('account:changed', JSON.parse(e.data)); } catch { } });
    es.addEventListener('phone_activity', e => { try {
      const d = JSON.parse(e.data); App.emit('phone:activity', d);
      if (((App.state && App.state.config) || {}).followPhone === false) return;
      (async () => {
        if (!S.convs.has(d.id)) await reload();
        if (d.projectId && byId(d.projectId)) await activateProject(d.projectId, { chatId: d.id }); else await App.chats.openConversation(d.id);
        const pane = App.chats.byConvId(d.id); if (pane && pane.loaded && !pane.running && !pane._attaching) pane.attachLoop();
        App.toast('📱 ' + (d.phone || 'טלפון') + ': הודעה חדשה מהטלפון', 2500);
      })().catch(() => { });
    } catch { } });
    es.addEventListener('chat_updated', e => { try { App.emit('chat:updated', JSON.parse(e.data)); } catch { } }); // שיחה השתנתה בלי ריצה (למשל תשובה לצ'אט מ-VS Code)
    es.addEventListener('instructions_rules', e => { try { App.emit('instructions:rules', JSON.parse(e.data)); } catch { } }); // ההוק קרא מחדש הוראה שנערכה
    es.addEventListener('research_update', e => { try { App.emit('research:update', JSON.parse(e.data)); } catch { } }); // כרטיסי המחקר החיים בצ'אט + רשימת המחקרים
    for (const t of ['c2c_pending', 'c2c_resolved']) es.addEventListener(t, e => { try { App.emit('c2c:event', { type: t, data: JSON.parse(e.data) }); } catch { } }); // 🤝 הודעות בין Claude-ים שממתינות לאישורך
    es.addEventListener('manager', e => { try { App.emit('manager', JSON.parse(e.data)); } catch { } });
    es.addEventListener('chrome_gate', e => { try { App.emit('chrome:gate', JSON.parse(e.data)); } catch { } }); // 🌐 Chrome בלי ההגדרה שמונעת את הפס — כרטיס "לפתוח מחדש פעם אחת"
    for (const t of ['watch_update', 'watch_removed', 'watch_activity']) es.addEventListener(t, e => { try { App.emit('watch:event', { type: t, data: JSON.parse(e.data) }); } catch { } }); // מעקבים
    for (const t of ['flow_run', 'flow_run_end', 'flow_saved']) es.addEventListener(t, e => { try { const d = JSON.parse(e.data); App.emit('flow:event', { type: t, data: d }); flowBadge(t, d); } catch { } });
  }

  // תג "תזרים רץ" בכותרת הצ'אט שהתזרים מפעיל
  function flowBadge(type, d) {
    if (!d || !d.convId) return;
    const pane = App.chats.byConvId(d.convId); if (!pane) return;
    if (type === 'flow_run' && d.status === 'running') pane.setFlowBadge({ flowName: d.flowName, no: d.stepNo, total: d.total, stepName: '' });
    else pane.setFlowBadge(null);
  }

  // ---------------------------------------------------------------- טאבי פרויקטים (למעלה)
  function renderTabs() {
    const box = $('tabs'); if (!box) return; box.innerHTML = '';
    for (const pid of S.open) {
      const p = byId(pid); if (!p) continue;
      const dots = dotsFor(chatsOf(pid));
      const col = tabColor(p); // הצבע שבחרת ללשונית (קליק ימני → 🎨). פרויקט ש-Claude עובד בו — רק הנקודה הירוקה, בלי רקע
      const t = el('div', 'tab ptab' + (pid === S.active ? ' active' : '') + (dots.run ? ' running' : '') + (col ? ' has-color' : '')); t.dataset.project = pid;
      if (col) { t.style.setProperty('--ptab-bg', col); t.style.setProperty('--ptab-fg', App.textOn(col)); t.dataset.color = col; }
      t.innerHTML = `<span class="t-main"><span class="t-title"></span><span class="t-dir" dir="ltr"></span></span><span class="t-dots">${dotsHtml(dots)}</span><button class="t-close" title="סגור את הטאב (הפרויקט והשיחות נשמרים)">✕</button>`;
      t.querySelector('.t-title').textContent = p.name;
      t.querySelector('.t-dir').textContent = dirShort(p.dir);
      t.title = p.name + '\n' + p.dir + (dots.run || dots.done ? `\n${dots.run} עובדות · ${dots.done} סיימו` : '');
      t.onclick = e => { if (e.target.closest('.t-close')) return; activateProject(pid); };
      t.onauxclick = e => { if (e.button === 1) closeTab(pid); };
      t.querySelector('.t-close').onclick = e => { e.stopPropagation(); closeTab(pid); };
      t.oncontextmenu = e => { e.preventDefault(); projectMenu(e.clientX, e.clientY, p); };
      box.appendChild(t);
    }
    const act = box.querySelector('.tab.active'); if (act && act.scrollIntoView) act.scrollIntoView({ inline: 'nearest' });
    const empty = $('emptyState'); if (empty) empty.hidden = !!(App.chats && App.chats.active && App.chats.active());
  }
  function projectMenu(x, y, p) {
    App.menu(x, y, [
      { icon: '✏️', label: 'שנה שם פרויקט', onClick: () => renameProject(p) },
      { icon: '📂', label: 'שנה תיקייה…', onClick: () => changeDir(p) },
      { icon: '➕', label: 'הוסף תיקייה ל-Workspace…', onClick: () => addWorkspaceDir(p) },
      { icon: '🎨', label: 'צבע הלשונית…', hint: tabColor(p) ? 'נבחר' : '', onClick: () => colorMenu(x, y, p) },
      { icon: '📋', label: 'העתק נתיב', onClick: () => App.copyText(p.dir, 'הנתיב הועתק') },
      { sep: true },
      { icon: '✕', label: 'סגור טאב', onClick: () => closeTab(p.id) },
      { icon: '✕', label: 'סגור את האחרים', disabled: S.open.length < 2, onClick: () => { for (const id of S.open.filter(i => i !== p.id)) closeTab(id, { quiet: true }); } },
      { sep: true },
      { icon: '🗑️', label: 'מחק פרויקט…', danger: true, disabled: !!p.general, onClick: () => deleteProject(p) }
    ]);
  }
  // ----- צבע הלשונית של פרויקט: 12 צבעים + צבע חופשי + "בלי צבע" (נשמר בפרויקט, projects.json → color) -----
  const TAB_PALETTE = ['#e5484d', '#f76b15', '#ffc53d', '#46a758', '#12a594', '#0090ff', '#3e63dd', '#8e4ec6', '#d6409f', '#ad7f58', '#8b8d98', '#202020'];
  const tabColor = p => (p && /^#[0-9a-f]{6}$/i.test(p.color || '') ? p.color.toLowerCase() : null);
  function colorMenu(x, y, p) {
    const cur = tabColor(p) || '';
    const box = el('div', 'ptab-palette');
    const apply = async c => { App.menuClose(); try { await update(p.id, { color: c || '' }); App.toast(c ? '🎨 צבע הלשונית של "' + p.name + '" נשמר' : 'הלשונית של "' + p.name + '" חזרה לרגיל', 1800); } catch (e) { App.toast('שגיאה: ' + e.message, 4000); } };
    for (const c of TAB_PALETTE) { const s = el('button', 'mpal-sw' + (cur === c ? ' on' : '')); s.style.background = c; s.title = c; s.dataset.color = c; s.onclick = e => { e.stopPropagation(); apply(c); }; box.appendChild(s); }
    const pick = el('label', 'mpal-custom'); pick.title = 'צבע אחר…'; pick.innerHTML = '<span>🎨</span>';
    const inp = el('input'); inp.type = 'color'; inp.value = cur || '#0090ff'; inp.onchange = () => apply(inp.value.toLowerCase()); pick.appendChild(inp); box.appendChild(pick);
    box.classList.add('mach-palette'); // אותו עיצוב כמו בחירת צבע למחשב
    App.menu(x, y, [{ el: box }, { sep: true }, { icon: '↺', label: 'בלי צבע (רגיל)', disabled: !cur, onClick: () => apply(null) }]);
  }
  function closeTab(pid) {
    const i = S.open.indexOf(pid); if (i < 0) return;
    S.open.splice(i, 1);
    if (!S.open.length) { const g = S.projects.find(p => p.general) || S.projects[0]; if (g && g.id !== pid) S.open.push(g.id); else if (g) S.open.push(g.id); }
    if (S.active === pid) activateProject(S.open[Math.min(i, S.open.length - 1)]); else { persist(); renderAll(); }
  }
  async function activateProject(pid, o = {}) {
    const p = byId(pid); if (!p) return;
    if (!S.open.includes(pid)) S.open.push(pid);
    const changed = S.active !== pid; S.active = pid; persist();
    let cid = o.chatId || S.last[pid]; if (cid && (!S.convs.has(cid) || (!o.chatId && S.convs.get(cid).projectId !== pid))) { if (!o.chatId) delete S.last[pid]; cid = null; } // צ'אט שהועבר לפרויקט אחר לא ימשוך את הלשונית אליו
    if (!cid && !o.fresh) { const mine = chatsOf(pid); if (mine.length) cid = mine[0].id; }
    if (cid && !o.fresh) await App.chats.openConversation(cid);
    else {
      const draft = App.chats.list().find(c => !c.id && c.projectId === pid);
      if (draft && !o.fresh) App.chats.activate(draft); else App.chats.newChat({ projectId: pid, focus: true });
    }
    renderAll();
    if (changed) { App.emit('project:activated', { id: pid, project: p }); App.emit('workspace:changed', workspaceInfo()); }
  }
  App.on('chat:activated', d => {
    const chat = d && d.chat; if (!chat) return;
    // the server list is the truth: a chat moved from another window / the phone / the API keeps a stale projectId on its open pane
    const srv = chat.id && S.convs.get(chat.id); if (srv && srv.projectId && byId(srv.projectId) && srv.projectId !== chat.projectId) chat.projectId = srv.projectId;
    const pid = chat.projectId;
    if (pid && byId(pid) && S.active !== pid) { if (!S.open.includes(pid)) S.open.push(pid); S.active = pid; App.emit('project:activated', { id: pid, project: byId(pid) }); App.emit('workspace:changed', workspaceInfo()); }
    if (chat.id && S.active) { S.last[S.active] = chat.id; markSeen(chat.id); }
    persist(); renderAll();
  });
  App.on('tabs:render', () => renderAll());
  // חלון שהוקטן: הלשונית שאתה עליה נשארת גלויה בסרגל (לא נגללת החוצה)
  let rzT = null; window.addEventListener('resize', () => { clearTimeout(rzT); rzT = setTimeout(() => { const a = document.querySelector('#tabs .ptab.active'), box = $('tabs'); if (!a || !box) return; const r = a.getBoundingClientRect(), b = box.getBoundingClientRect(); if (r.left < b.left || r.right > b.right) a.scrollIntoView({ inline: 'nearest', block: 'nearest' }); }, 120); });
  App.on('list:render', () => renderAll());
  App.on('convs:reload', () => reloadSoon());

  // ---------------------------------------------------------------- רשימת השיחות (ימין)
  let dragId = null;
  function dotCell(c) { const d = el('span', 'ci-dot' + (c.running ? ' run' : c.unseen ? ' done' : '')); d.title = c.running ? 'Claude עובד בצ\'אט הזה' : c.unseen ? 'הצ\'אט סיים — לחץ כדי לראות' : ''; return d; }
  function chatItem(c, p) {
    const a = App.chats.active();
    const item = el('div', 'conv-item ci2' + (a && a.id === c.id ? ' active' : '') + (c.running ? ' is-run' : '') + (c.unseen && !c.running ? ' is-done' : ''));
    item.dataset.id = c.id; item.dataset.code = c.code || ''; item.draggable = true;
    const main = el('span', 'c-main'), t = el('span', 'title'); t.textContent = c.title || 'שיחה'; t.title = c.title || ''; main.appendChild(t); if (App.managerBadge) { const bd = App.managerBadge(c); if (bd) t.insertAdjacentHTML('afterbegin', bd + ' '); }
    const sub = el('span', 'c-sub'); const code = el('span', 'c-code', esc(c.code || '')); code.title = 'קוד השיחה — לחיצה: העתקה. אפשר לומר ל-Claude "שיחה ' + (c.code || '') + '"';
    code.onclick = e => { e.stopPropagation(); App.copyText(c.code || '', 'הקוד ' + c.code + ' הועתק'); };
    sub.appendChild(code); const tm = el('span', 'c-time'); tm.textContent = ' · ' + fmt.dateTime(c.updatedAt); sub.appendChild(tm); main.appendChild(sub);
    const acts = el('span', 'acts'), bell = el('button', 'ci-bell'), ren = el('button', '', '✏️'), del = el('button', '', '🗑️'); ren.title = 'שנה שם'; del.title = 'מחק';
    paintBell(bell, c.id);
    bell.onclick = e => { e.stopPropagation(); const m = !sndChat(c.id).mute; setSndChat(c.id, { mute: m }); App.toast(m ? '🔕 הצלילים של "' + (c.title || 'השיחה') + '" מושתקים' : '🔔 הצלילים של "' + (c.title || 'השיחה') + '" פועלים', 1600); };
    ren.onclick = e => { e.stopPropagation(); renameChat(c); };
    del.onclick = e => { e.stopPropagation(); deleteChat(c); };
    acts.append(bell, ren, del); item.append(dotCell(c), main, acts);
    if (sndChat(c.id).mute) item.classList.add('snd-muted');
    item.onclick = () => App.chats.openConversation(c.id);
    item.oncontextmenu = e => { e.preventDefault(); e.stopPropagation(); chatMenu(e.clientX, e.clientY, c); };
    item.ondragstart = e => { dragId = c.id; e.dataTransfer.setData('application/x-claude-chat', c.id); e.dataTransfer.effectAllowed = 'move'; item.classList.add('dragging'); };
    item.ondragend = () => { dragId = null; item.classList.remove('dragging'); document.querySelectorAll('.drop-hot').forEach(x => x.classList.remove('drop-hot')); };
    return item;
  }
  // ---------- צלילים לכל שיחה: השתקה (פעמון) · עוצמה · רמה (קריטיים / מפורט / הכל) ----------
  const sndAll = () => { const cfg = App.state.config || {}; const s = cfg.sounds && typeof cfg.sounds === 'object' ? cfg.sounds : (App.sound ? App.sound.settings() : {}); if (!s.chats || typeof s.chats !== 'object') s.chats = {}; return s; };
  const sndChat = id => sndAll().chats[id] || {};
  let sndSaveT = null;
  function setSndChat(id, patch) {
    const s = sndAll(), cur = { ...(s.chats[id] || {}), ...patch };
    for (const k of Object.keys(cur)) if (cur[k] == null || (k === 'mute' && !cur[k]) || (k === 'vol' && cur[k] >= 1)) delete cur[k];
    if (Object.keys(cur).length) s.chats[id] = cur; else delete s.chats[id];
    App.state.config.sounds = s;
    document.querySelectorAll(`.conv-item[data-id="${id}"]`).forEach(it => { it.classList.toggle('snd-muted', !!cur.mute); const b = it.querySelector('.ci-bell'); if (b) paintBell(b, id); });
    clearTimeout(sndSaveT); sndSaveT = setTimeout(() => App.saveConfig({ sounds: s }).catch(e => App.toast('❌ ' + e.message, 3000)), 300);
  }
  function paintBell(b, id) {
    const c = sndChat(id), lv = c.level ? ' · ' + ((window.SOUND_CATALOG && SOUND_CATALOG.LEVELS) || {})[c.level] : '', vol = c.vol != null ? ' · עוצמה ' + Math.round(c.vol * 100) + '%' : '';
    b.textContent = c.mute ? '🔕' : '🔔'; b.classList.toggle('off', !!c.mute);
    b.title = (c.mute ? 'הצלילים של השיחה מושתקים — לחיצה: הפעלה' : 'צלילים פועלים בשיחה — לחיצה: השתקה') + vol + lv + ' · קליק ימני: עוצמה ורמה';
  }
  function volumeRow(id) {
    const row = el('div', 'ctx-vol'); const c = sndChat(id), v = c.vol != null ? c.vol : 1;
    row.innerHTML = `<span class="ctx-ic">🔊</span><input type="range" min="0" max="100" step="5" class="ctx-vol-r"><b class="ctx-vol-p"></b>`;
    const r = row.querySelector('input'), p = row.querySelector('b'); r.value = Math.round(v * 100); p.textContent = r.value + '%';
    const paint = () => { p.textContent = r.value + '%'; r.style.setProperty('--p', r.value + '%'); }; paint();
    r.oninput = () => { paint(); setSndChat(id, { vol: +r.value / 100 }); };
    row.onclick = e => e.stopPropagation(); row.onmousedown = e => e.stopPropagation();
    return row;
  }
  function soundItems(c) {
    const cur = sndChat(c.id), L = (window.SOUND_CATALOG && SOUND_CATALOG.LEVELS) || { 1: 'קריטיים בלבד', 2: 'מפורט', 3: 'כל הצלילים' };
    const glob = ((App.state.config || {}).sounds || {}).level || 1;
    return [
      { icon: cur.mute ? '🔔' : '🔕', label: cur.mute ? 'הפעל צלילים בשיחה' : 'השתק צלילים בשיחה', onClick: () => setSndChat(c.id, { mute: !cur.mute }) },
      { el: volumeRow(c.id) },
      ...[1, 2, 3].map(n => ({ icon: cur.level === n ? '✓' : '', label: 'צלילים: ' + L[n], onClick: () => setSndChat(c.id, { level: n }) })),
      { icon: !cur.level ? '✓' : '', label: 'צלילים: כמו בהגדרות (' + L[glob] + ')', onClick: () => setSndChat(c.id, { level: null }) }
    ];
  }
  App.chatSound = { get: sndChat, set: setSndChat };
  function chatMenu(x, y, c) {
    const p = byId(c.projectId); const folders = (p && p.chatFolders) || [];
    App.menu(x, y, [
      ...soundItems(c),
      { sep: true },
      { icon: '💬', label: 'פתח', onClick: () => App.chats.openConversation(c.id) },
      { icon: '✏️', label: 'שנה שם', onClick: () => renameChat(c) },
      ...(c.role === 'manager' ? [] : [{ icon: '🧭', label: 'הפוך למנהל עבודה…', onClick: () => App.managers && App.managers.dialog({ convId: c.id }) }]),
      { icon: '🏷️', label: 'העתק קוד (' + (c.code || '—') + ')', onClick: () => App.copyText(c.code || '', 'הקוד הועתק') },
      c.running ? { icon: '■', label: 'עצור', onClick: () => { App.emit('chat:userstop', { id: c.id }); App.api('/api/stop', { method: 'POST', body: { conversationId: c.id } }).catch(() => { }); } } : null,
      { sep: true },
      { icon: '📁', label: 'העבר לתיקייה', empty: 'אין תיקיות בפרויקט הזה', children: () => [
        ...folders.filter(f => f.id !== c.folderId).map(f => ({ icon: '📁', label: f.name, onClick: () => moveChat(c.id, { folderId: f.id }) })),
        c.folderId ? { icon: '↥', label: 'הוצא מהתיקייה', onClick: () => moveChat(c.id, { folderId: null }) } : null
      ].filter(Boolean) },
      { icon: '📂', label: 'העבר לפרויקט', empty: 'אין פרויקטים אחרים', children: () => S.projects.filter(x2 => x2.id !== c.projectId).map(x2 => ({ icon: '📂', label: x2.name, sub: x2.dir, onClick: () => moveChat(c.id, { projectId: x2.id }) })) },
      { icon: '🖥', label: 'העבר למחשב', empty: 'אין מחשבים אחרים מחוברים', children: () => machineTargets(c) },
      { sep: true },
      { icon: '🗑️', label: 'מחק שיחה', danger: true, onClick: () => deleteChat(c) }
    ]);
  }
  function folderHead(f, items, p) {
    const key = 'fcol:' + f.id; let collapsed = ls.get(key) === '1';
    const h = el('div', 'folder-head'); h.dataset.folder = f.id;
    const d = dotsFor(items);
    h.innerHTML = `<span class="f-caret">${collapsed ? '◂' : '▾'}</span><span class="f-ic">${FOLDER_SVG}</span><span class="f-name"></span><span class="f-dots">${dotsHtml(d, 3)}</span><span class="f-cnt">${items.length}</span>`;
    h.querySelector('.f-name').textContent = f.name;
    const body = el('div', 'folder-body'); body.hidden = collapsed;
    h.onclick = () => { collapsed = !collapsed; ls.set(key, collapsed ? '1' : '0'); body.hidden = collapsed; h.querySelector('.f-caret').textContent = collapsed ? '◂' : '▾'; };
    h.oncontextmenu = e => { e.preventDefault(); e.stopPropagation(); folderMenu(e.clientX, e.clientY, f); };
    const hot = e => { if (!(e.dataTransfer.types || []).includes('application/x-claude-chat')) return; e.preventDefault(); h.classList.add('drop-hot'); };
    h.ondragover = hot; h.ondragenter = hot; h.ondragleave = () => h.classList.remove('drop-hot');
    h.ondrop = e => { e.preventDefault(); e.stopPropagation(); h.classList.remove('drop-hot'); const id = e.dataTransfer.getData('application/x-claude-chat') || dragId; if (id) moveChat(id, { folderId: f.id }); };
    return [h, body];
  }
  function folderMenu(x, y, f) {
    App.menu(x, y, [
      { icon: '➕', label: 'שיחה חדשה בתיקייה', onClick: () => newChat({ folderId: f.id }) },
      { icon: '🧭', label: 'הרכב מנהל עבודה על התיקייה', onClick: () => App.managers && App.managers.dialog({ projectId: S.active, folderId: f.id }) },
      { icon: '✏️', label: 'שנה שם תיקייה', onClick: () => renameFolder(f) },
      { sep: true },
      { icon: '📂', label: 'העבר את התיקייה לפרויקט', empty: 'אין פרויקטים אחרים', children: () => { const p = activeProject(); return S.projects.filter(x2 => !p || x2.id !== p.id).map(x2 => ({ icon: '📂', label: x2.name, sub: x2.dir, onClick: () => moveFolderToProject(f, x2) })); } },
      { icon: '🖥', label: 'העבר את התיקייה למחשב', empty: 'אין מחשבים אחרים מחוברים', children: () => machineTargets(null).map(t => ({ ...t, onClick: () => sendFolderToMachine(f, t._m) })) },
      { sep: true },
      { icon: '🗑️', label: 'מחק תיקייה (השיחות נשארות בפרויקט)', danger: true, onClick: () => deleteFolder(f) }
    ]);
  }
  function renderList() {
    const list = $('convList'); if (!list) return;
    const p = activeProject();
    const title = $('chatsTitle'); if (title) { title.textContent = p ? p.name : 'שיחות'; title.title = p ? p.dir : ''; }
    const q = (($('searchConv') || {}).value || '').trim().toLowerCase();
    const scroll = list.scrollTop; list.innerHTML = '';
    if (!p) return;
    const all = chatsOf(p.id).filter(c => !q || (c.title || '').toLowerCase().includes(q) || (c.code || '').toLowerCase().includes(q));
    const folders = p.chatFolders || []; const fids = new Set(folders.map(f => f.id));
    for (const f of folders) {
      const items = all.filter(c => c.folderId === f.id);
      if (q && !items.length) continue;
      const [h, body] = folderHead(f, items, p);
      for (const c of items) body.appendChild(chatItem(c, p));
      if (!items.length) body.appendChild(el('div', 'folder-empty', 'ריקה — גרור לכאן שיחות'));
      list.append(h, body);
    }
    const root = all.filter(c => !c.folderId || !fids.has(c.folderId));
    for (const c of root) list.appendChild(chatItem(c, p));
    if (!all.length) list.appendChild(el('div', 'conv-group', q ? 'לא נמצאו שיחות' : 'אין עדיין שיחות בפרויקט. לחץ ＋ כדי להתחיל'));
    list.scrollTop = scroll;
  }
  function bindListArea() {
    const list = $('convList'); if (!list) return;
    list.oncontextmenu = e => { if (e.target.closest('.conv-item, .folder-head')) return; e.preventDefault(); App.menu(e.clientX, e.clientY, [{ icon: '＋', label: 'שיחה חדשה', onClick: () => newChat() }, { icon: '📁', label: 'תיקיית שיחות חדשה', onClick: () => createFolder() }]); };
    list.ondragover = e => { if (!(e.dataTransfer.types || []).includes('application/x-claude-chat')) return; e.preventDefault(); };
    list.ondrop = e => { const id = e.dataTransfer.getData('application/x-claude-chat') || dragId; if (id && !e.target.closest('.folder-head')) { e.preventDefault(); moveChat(id, { folderId: null }); } };
  }
  function renderAll() {
    const a = App.chats && App.chats.active && App.chats.active();
    if (a && a.id && a.projectId && a.projectId === S.active && S.last[S.active] !== a.id) { S.last[S.active] = a.id; persist(); } // הצ'אט הפעיל בפרויקט = האחרון שנפתח
    renderTabs(); renderList();
  }

  // ---------------------------------------------------------------- פעולות
  function newChat(o = {}) { const p = activeProject(); if (!p) return null; return App.chats.newChat({ projectId: p.id, folderId: o.folderId || null, focus: true }); }
  async function renameChat(c) {
    const t = await App.prompt('שם חדש לשיחה:', c.title, { title: 'שנה שם' }); if (!t || !t.trim()) return;
    await App.api('/api/conversations/' + c.id, { method: 'PATCH', body: { title: t.trim() } });
    const pane = App.chats.byConvId(c.id); if (pane) { pane.title = t.trim(); pane.updateHead(); }
    const s = S.convs.get(c.id); if (s) s.title = t.trim(); renderAll();
  }
  async function deleteChat(c) {
    if (!(await App.confirm('למחוק את השיחה "' + c.title + '"?', { danger: true, okText: 'מחק' }))) return;
    await App.api('/api/conversations/' + c.id, { method: 'DELETE' });
    const pane = App.chats.byConvId(c.id); if (pane) App.chats.closeTab(pane);
    S.convs.delete(c.id); if (S.last[c.projectId] === c.id) delete S.last[c.projectId];
    const a = App.chats.active(); if (!a) await activateProject(S.active, { fresh: !chatsOf(S.active).length });
    renderAll();
  }
  // ----- העברת צ'אט למחשב אחר ברשת: כל ההיסטוריה עוברת לפרויקט "כללי" שם; כאן הוא נמחק רק אחרי שהיעד אישר שקיבל הכל -----
  function machineTargets(c) {
    const M = App.mesh; if (!M) return [];
    const here = M.current();
    return M.machines().filter(m => m.id !== here && M.kindOf(m) !== 'phone' && !m.revoked).map(m => ({
      icon: m.online ? '🟢' : '⚪', label: m.displayName || m.id, sub: m.self ? 'המחשב הזה' : (m.online ? 'מחובר' : 'לא מחובר'),
      disabled: !m.online, _m: m, onClick: () => sendChatToMachine(c, m)
    }));
  }
  // מעביר צ'אט אחד; זורק שגיאה אם משהו לא הושלם (ואז הצ'אט נשאר כאן)
  async function transferOne(c, m, folderName) {
    const data = await App.api('/api/conversations/' + c.id + '/export');
    if (folderName) data.folderName = folderName;
    const total = data.messages.length;
    const res = await fetch('/m/' + m.id + '/api/conversations/import', { method: 'POST', headers: { 'content-type': 'application/json', 'x-mesh-local': '1' }, body: JSON.stringify(data), cache: 'no-store' });
    const r = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(r.error || 'HTTP ' + res.status);
    if (r.total !== total) throw new Error(`היעד קיבל ${r.total} הודעות מתוך ${total}`);
    await App.api('/api/conversations/' + c.id, { method: 'DELETE' });
    return { ...r, total };
  }
  async function sendChatToMachine(c, m) {
    if (c.running) { App.toast('Claude עובד בצ\'אט הזה עכשיו. עצור אותו או חכה שיסיים, ואז העבר.', 4000); return; }
    const name = m.displayName || m.id;
    if (!(await App.confirm(`להעביר את "${c.title || 'השיחה'}" (${c.code || ''}) עם כל ההיסטוריה למחשב "${name}"?\nהצ'אט יופיע שם בפרויקט "כללי", ויימחק מכאן רק אחרי שההעברה תאושר.`, { okText: 'העבר' }))) return;
    App.toast('⏳ מעביר את הצ\'אט ל-' + name + '…', 3000);
    try { const r = await transferOne(c, m); await reload(); App.toast(`✅ הועבר ל-${name}: ${r.code} · ${r.total} הודעות (פרויקט "כללי")`, 5000); }
    catch (e) { await reload().catch(() => { }); App.toast('ההעברה נכשלה, הצ\'אט נשאר כאן: ' + e.message, 6000); }
  }
  async function sendFolderToMachine(f, m) {
    const p = activeProject(); if (!p || !m) return;
    const items = chatsOf(p.id).filter(c => c.folderId === f.id), name = m.displayName || m.id;
    if (items.some(c => c.running)) { App.toast('יש בתיקייה צ\'אט ש-Claude עובד בו עכשיו. חכה שיסיים, ואז העבר.', 4500); return; }
    if (!(await App.confirm(`להעביר את התיקייה "${f.name}" (${items.length} צ'אטים, עם כל ההיסטוריה) למחשב "${name}"?\nהיא תופיע שם בפרויקט "כללי".`, { okText: 'העבר' }))) return;
    let ok = 0; const fail = [];
    for (const c of items) { App.toast(`⏳ מעביר ${ok + fail.length + 1}/${items.length}…`, 2500); try { await transferOne(c, m, f.name); ok++; } catch (e) { fail.push((c.code || c.title) + ': ' + e.message); } }
    if (!fail.length) await update(p.id, { chatFolders: (p.chatFolders || []).filter(x => x.id !== f.id) });
    await reload();
    App.toast(fail.length ? `הועברו ${ok}/${items.length}. נשארו כאן: ${fail.join(' · ')}` : `✅ התיקייה "${f.name}" הועברה ל-${name} (${ok} צ'אטים)`, 7000);
  }
  async function moveFolderToProject(f, target) {
    const p = activeProject(); if (!p || !target) return;
    const items = chatsOf(p.id).filter(c => c.folderId === f.id);
    const tgt = byId(target.id) || target; let tf = (tgt.chatFolders || []).find(x => x.name === f.name);
    if (!tf) { tf = { id: 'f' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), name: f.name }; await update(tgt.id, { chatFolders: [...(tgt.chatFolders || []), tf] }); }
    for (const c of items) { await App.api('/api/conversations/' + c.id, { method: 'PATCH', body: { projectId: tgt.id, folderId: tf.id } }); const s = S.convs.get(c.id); if (s) Object.assign(s, { projectId: tgt.id, folderId: tf.id }); }
    await update(p.id, { chatFolders: (p.chatFolders || []).filter(x => x.id !== f.id) });
    await reload();
    App.toast(`✅ התיקייה "${f.name}" (${items.length} צ'אטים) הועברה לפרויקט "${tgt.name}"`, 4500);
  }
  async function moveChat(id, patch) {
    try {
      await App.api('/api/conversations/' + id, { method: 'PATCH', body: patch });
      const s = S.convs.get(id); if (s) Object.assign(s, patch);
      const pane = App.chats.byConvId(id);
      if (patch.projectId) { if (pane) { pane.projectId = patch.projectId; } await reload(); if (App.chats.active() && App.chats.active().id === id) await activateProject(patch.projectId, { chatId: id }); else if (pane && App.chats.active() === pane) { } }
      else renderAll();
    } catch (e) { App.toast('לא הצלחתי להעביר: ' + e.message, 4000); }
  }
  async function createFolder() {
    const p = activeProject(); if (!p) return;
    const name = await App.prompt('שם תיקיית השיחות:', '', { title: 'תיקיית שיחות חדשה', placeholder: 'למשל: באגים, רעיונות, מחקר' }); if (!name || !name.trim()) return;
    await update(p.id, { chatFolders: [...(p.chatFolders || []), { id: 'f' + Math.random().toString(36).slice(2, 9), name: name.trim() }] });
  }
  async function renameFolder(f) {
    const p = activeProject(); if (!p) return;
    const name = await App.prompt('שם חדש לתיקייה:', f.name, { title: 'שנה שם תיקייה' }); if (!name || !name.trim()) return;
    await update(p.id, { chatFolders: (p.chatFolders || []).map(x => (x.id === f.id ? { ...x, name: name.trim() } : x)) });
  }
  async function deleteFolder(f) {
    const p = activeProject(); if (!p) return;
    const n = chatsOf(p.id).filter(c => c.folderId === f.id);
    if (!(await App.confirm(`למחוק את התיקייה "${f.name}"?${n.length ? '\n' + n.length + ' שיחות יישארו בפרויקט (בלי תיקייה).' : ''}`, { danger: true, okText: 'מחק תיקייה' }))) return;
    for (const c of n) { await App.api('/api/conversations/' + c.id, { method: 'PATCH', body: { folderId: null } }); const s = S.convs.get(c.id); if (s) s.folderId = null; }
    await update(p.id, { chatFolders: (p.chatFolders || []).filter(x => x.id !== f.id) });
  }

  // ---------------------------------------------------------------- פרויקטים: יצירה / עדכון / מחיקה
  async function update(id, patch) {
    const r = await App.api('/api/projects', { method: 'POST', body: { id, ...patch } });
    S.projects = r.projects || S.projects;
    renderAll(); App.emit('projects:changed', {});
    if (id === S.active) App.emit('workspace:changed', workspaceInfo());
    return r.project;
  }
  async function create(o) {
    const r = await App.api('/api/projects', { method: 'POST', body: o });
    S.projects = r.projects; if (!S.open.includes(r.project.id)) S.open.push(r.project.id);
    await activateProject(r.project.id, { fresh: true });
    return r.project;
  }
  async function renameProject(p) {
    const name = await App.prompt('שם חדש לפרויקט:', p.name, { title: 'שנה שם פרויקט' }); if (!name || !name.trim()) return;
    await update(p.id, { name: name.trim() });
  }
  // חלון: בחירת תיקייה (שורה אחת + "בחר…") — משמש גם לפרויקט חדש וגם לשינוי תיקייה
  function pathDialog({ title, nameValue, dirValue, showName, okText }) {
    return new Promise(res => {
      const body = el('div', 'proj-dlg'); let done = false;
      let nameIn = null;
      if (showName) { body.appendChild(el('label', 'pd-lbl', 'שם הפרויקט')); nameIn = el('input', 'text-input'); nameIn.value = nameValue || ''; nameIn.placeholder = 'למשל: האתר שלי'; body.appendChild(nameIn); }
      body.appendChild(el('label', 'pd-lbl', 'תיקייה (נתיב במחשב, או נתיב רשת של מחשב אחר: \\\\מחשב\\תיקייה)'));
      const row = el('div', 'pd-row'); const dirIn = el('input', 'text-input'); dirIn.dir = 'ltr'; dirIn.value = dirValue || ''; dirIn.placeholder = 'C:\\Users\\...\\הפרויקט';
      const pick = el('button', 'btn-ghost', '📂 בחר…'); pick.type = 'button';
      pick.onclick = async () => { try { const r = await App.api('/api/fs/pick-folder', { method: 'POST', body: { initial: dirIn.value || '', title } }); if (r && r.path) { dirIn.value = r.path; if (nameIn && !nameIn.value.trim()) nameIn.value = App.baseName(r.path); } } catch (e) { App.toast('לא הצלחתי לפתוח בחירת תיקייה: ' + e.message, 4000); } };
      row.append(dirIn, pick); body.appendChild(row);
      const err = el('div', 'pd-err'); err.hidden = true; body.appendChild(err);
      const bar = el('div', 'confirm-bar'); const ok = el('button', 'btn-primary', okText || 'אישור'), no = el('button', 'btn-ghost', 'ביטול'); bar.append(no, ok); body.appendChild(bar);
      const m = App.modal({ title, body, cls: 'small pdlg', onClose: () => { if (!done) { done = true; res(null); } } });
      const submit = () => { const dir = dirIn.value.trim(); if (!dir) { err.hidden = false; err.textContent = 'צריך לבחור תיקייה'; return; } done = true; m.close(); res({ dir, name: nameIn ? nameIn.value.trim() : '' }); };
      ok.onclick = submit; no.onclick = () => m.close();
      body.addEventListener('keydown', e => { if (e.key === 'Enter') submit(); });
      setTimeout(() => (showName ? nameIn : dirIn).focus(), 40);
    });
  }
  async function newProjectDialog() {
    const closed = S.projects.filter(p => !S.open.includes(p.id));
    const r = await pathDialog({ title: 'פרויקט חדש', showName: true, okText: 'צור פרויקט', dirValue: '' });
    if (r) { try { await create({ name: r.name || App.baseName(r.dir), dir: r.dir }); App.toast('הפרויקט נוצר'); } catch (e) { App.toast('שגיאה: ' + e.message, 4500); } return; }
    void closed;
  }
  function plusMenu() {
    const closed = S.projects.filter(p => !S.open.includes(p.id));
    const rc = $('newTabBtn').getBoundingClientRect();
    if (!closed.length) return newProjectDialog();
    // היסטוריה: הפרויקטים שסגרת — האחרון שעבדת עליו ראשון; השם בצבע הלשונית שבחרת לו, והנתיב מתחת
    const lastUse = p => Math.max(p.updatedAt || 0, p.createdAt || 0, ...chatsOf(p.id).map(c => c.updatedAt || 0));
    closed.sort((a, b) => lastUse(b) - lastUse(a));
    App.menu(rc.left, rc.bottom + 4, [{ icon: '＋', label: 'פרויקט חדש…', onClick: newProjectDialog }, { icon: '🧭', label: 'מנהל עבודה חדש…', sub: 'מנהל שבונה תיקייה משלו ומביא את הפרויקט עד הוכחה', onClick: () => App.managers && App.managers.dialog({ projectId: S.active }) }, { sep: true }, ...closed.map(p => ({ icon: '📂', label: 'פתח: ', name: p.name, color: tabColor(p), sub: p.dir, onClick: () => activateProject(p.id) }))]);
  }
  async function changeDir(p) {
    const r = await pathDialog({ title: 'שנה תיקייה לפרויקט "' + p.name + '"', showName: false, dirValue: p.dir, okText: 'שמור' }); if (!r) return;
    try { await update(p.id, { dir: r.dir }); App.toast('תיקיית הפרויקט עודכנה'); } catch (e) { App.toast('שגיאה: ' + e.message, 4500); }
  }
  async function addWorkspaceDir(p) {
    const r = await pathDialog({ title: 'הוסף תיקייה ל-Workspace של "' + p.name + '"', showName: false, dirValue: '', okText: 'הוסף' }); if (!r) return;
    try { await workspaceAdd(r.dir, p); } catch (e) { App.toast('שגיאה: ' + e.message, 4500); }
  }
  function deleteProject(p) {
    const n = chatsOf(p.id).length; let m;
    const body = el('div', 'confirm-body'); body.appendChild(el('p', '', esc('למחוק את הפרויקט "' + p.name + '"? (התיקייה עצמה בדיסק לא נמחקת)' + (n ? '\nיש בו ' + n + ' שיחות.' : ''))));
    const bar = el('div', 'del-bar');
    const keep = el('button', 'btn-primary', n ? 'מחק פרויקט — השיחות עוברות ל"כללי"' : 'מחק פרויקט'), kill = el('button', 'btn-danger', 'מחק פרויקט וגם את כל השיחות שלו'), no = el('button', 'btn-ghost', 'ביטול');
    bar.append(keep); if (n) bar.append(kill); bar.append(no); body.appendChild(bar);
    m = App.modal({ title: 'מחיקת פרויקט', body, cls: 'small' });
    const go = async mode => { m.close(); try { const r = await App.api('/api/projects/' + p.id + '?chats=' + mode, { method: 'DELETE' }); S.projects = r.projects; S.open = S.open.filter(i => i !== p.id); if (mode === 'delete') for (const c of chatsOf(p.id)) { const pane = App.chats.byConvId(c.id); if (pane) App.chats.closeTab(pane); } if (S.active === p.id) S.active = null; await reload(); if (!S.active || !byId(S.active)) S.active = S.open[0]; await activateProject(S.active); App.toast('הפרויקט נמחק'); } catch (e) { App.toast('שגיאה: ' + e.message, 4500); } };
    keep.onclick = () => go('keep'); kill.onclick = () => go('delete'); no.onclick = () => m.close();
  }

  // ---------------------------------------------------------------- Workspace רב-תיקיות
  const norm = d => String(d || '').replace(/[\\/]+$/, '').toLowerCase().replace(/\//g, '\\');
  function workspaceInfo() { return { projectId: S.active, roots: App.workspace.roots() }; }
  async function workspaceAdd(dir, p = activeProject()) {
    if (!p) return false; dir = String(dir || '').trim(); if (!dir) return false;
    if (norm(dir) === norm(p.dir) || (p.extraDirs || []).some(d => norm(d) === norm(dir))) { App.toast('התיקייה כבר ב-Workspace', 2500); return false; }
    const before = (p.extraDirs || []).length;
    const np = await update(p.id, { extraDirs: [...(p.extraDirs || []), dir] });
    if ((np.extraDirs || []).length === before) { App.toast('התיקייה לא נמצאה: ' + dir, 4000); return false; }
    App.toast('📂 נוספה ל-Workspace: ' + App.baseName(dir), 2500); return true;
  }
  async function workspaceRemove(dir, p = activeProject()) {
    if (!p) return false;
    if (norm(dir) === norm(p.dir)) { App.toast('זו תיקיית הפרויקט עצמה. אפשר לשנות אותה בקליק ימני על הטאב של הפרויקט', 4500); return false; }
    await update(p.id, { extraDirs: (p.extraDirs || []).filter(d => norm(d) !== norm(dir)) }); return true;
  }
  App.workspace = {
    projectId: () => S.active,
    roots() { const p = activeProject(); if (!p) return []; return [{ path: p.dir, name: App.baseName(p.dir) || p.dir, primary: true }, ...(p.extraDirs || []).map(d => ({ path: d, name: App.baseName(d) || d, primary: false }))]; },
    add: workspaceAdd, remove: workspaceRemove
  };

  // ---------------------------------------------------------------- ה-API הציבורי
  App.on('chatui:changed', () => { try { renderList(); } catch { } }); // פורמט שעה חדש ברשימת השיחות
  App.projects = {
    list: () => S.projects.slice(), get: byId, activeId: () => S.active, active: activeProject,
    chatsOf: pid => chatsOf(pid), state: id => S.convs.get(id) || null, open: () => S.open.slice(),
    convByCode: code => { code = String(code || "").toUpperCase(); for (const c of S.convs.values()) if (String(c.code || "").toUpperCase() === code) return c; return null; },
    openConversation: id => App.chats.openConversation(id),
    reload, refresh: reload, create, update, activate: activateProject, closeTab, newChat, createFolder,
    async remove(id, mode = 'keep') { const r = await App.api('/api/projects/' + id + '?chats=' + mode, { method: 'DELETE' }); S.projects = r.projects; await reload(); },
    markSeen,
    cycleChat(d) { const list = chatsOf(S.active); if (list.length < 2) return; const a = App.chats.active(); const i = list.findIndex(c => a && c.id === a.id); App.chats.openConversation(list[(i + d + list.length) % list.length].id); }
  };

  // ---------------------------------------------------------------- אתחול
  App.ready(async () => {
    $('newTabBtn').onclick = plusMenu;
    const eb = $('emptyNewBtn'); if (eb) eb.onclick = () => newChat();
    $('newChatBtn').onclick = () => newChat();
    $('newFolderBtn').onclick = createFolder;
    $('searchConv').oninput = renderList;
    bindListArea();
    await App.chatsReady;
    await reload();
    const hash = location.hash.slice(1);
    let want = null; if (hash && /^[a-zA-Z0-9-]+$/.test(hash) && S.convs.has(hash)) want = hash;
    if (want) { const pid = S.convs.get(want).projectId; S.active = pid; if (!S.open.includes(pid)) S.open.push(pid); }
    connectEvents();
    await activateProject(S.active, { chatId: want || undefined });
    S.ready = true; App.emit('projects:ready', {});
    window.addEventListener('focus', () => { const a = App.chats.active(); if (a && a.id) markSeen(a.id); });
    document.addEventListener('visibilitychange', () => { if (!document.hidden) { const a = App.chats.active(); if (a && a.id) markSeen(a.id); } });
    setInterval(reload, 30000); // רשת ביטחון למקרה שאירוע אחד אבד
  });
})();
