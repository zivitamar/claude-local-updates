// ============================================================
//  flows.js (ממשק) — חלונית "תזרים": רשימה, עורך שלבים, בנייה עם Claude, תצוגת הרצה חיה
//  השרת מריץ ואוכף את התזרים (flows.js בשורש). כאן רק ממשק מעל /api/flows.
//  מתחבר ל-#flowsBody / #flowsTools / #actFlowsBadge (index.html). כל הסלקטורים עם קידומת fl-
//  חושף: App.flows = { refresh(), openEditor(id), openRun(rid), start(id), generate(goal), ... }
// ============================================================
(function () {
  const App = window.App; if (!App) return;
  const $ = id => document.getElementById(id);
  const el = App.el, esc = App.esc;

  const TYPES = {
    task: { ic: '🧠', label: 'משימה' },
    research: { ic: '🔎', label: 'מחקר' },
    command: { ic: '⌨', label: 'פקודה' },
    watch: { ic: '👁', label: 'בדיקה חוזרת' },
    wait: { ic: '⏱', label: 'המתנה' }
  };
  const DEF_TIMEOUT = { task: 30, research: 25, command: 10, watch: 30, wait: 0 };
  const ST = {
    running: { ic: '⟳', txt: 'רץ' }, done: { ic: '✔', txt: 'הצליח' }, failed: { ic: '✖', txt: 'נכשל' },
    stopped: { ic: '■', txt: 'נעצר' }, timeout: { ic: '⏱', txt: 'תם הזמן' }
  };
  const OUT = { ok: { ic: '✔', cls: 'ok' }, fail: { ic: '✖', cls: 'fail' }, timeout: { ic: '⏱', cls: 'timeout' } };
  const KIC = { ok: '✔', fail: '✖', timeout: '⏱' };
  const DEFAULT_ROUTE = { ok: 'next', fail: 'stop', timeout: 'stop' };
  const pad = n => String(n).padStart(2, '0');
  const svg = (p, w = 12) => `<svg viewBox="0 0 16 16" width="${w}" height="${w}" aria-hidden="true" focusable="false">${p}</svg>`;
  const STK = 'fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"';
  const IC = {
    play: svg('<path d="M4.5 2.8v10.4l8.4-5.2z" fill="currentColor"/>', 10),
    edit: svg(`<path d="M10.8 2.6l2.6 2.6-7.6 7.6-3.4.8.8-3.4z" ${STK} stroke-width="1.3"/>`, 12),
    more: svg('<circle cx="2.6" cy="8" r="1.5" fill="currentColor"/><circle cx="8" cy="8" r="1.5" fill="currentColor"/><circle cx="13.4" cy="8" r="1.5" fill="currentColor"/>', 14),
    up: svg(`<path d="M3.5 10.5L8 5.5l4.5 5" ${STK} stroke-width="1.7"/>`, 13),
    down: svg(`<path d="M3.5 5.5L8 10.5l4.5-5" ${STK} stroke-width="1.7"/>`, 13),
    trash: svg(`<path d="M2.8 4.4h10.4M6.4 4.4V2.9h3.2v1.5M4.3 4.4l.6 8.6h6.2l.6-8.6M6.7 7v3.8M9.3 7v3.8" ${STK} stroke-width="1.25"/>`, 13),
    open: svg(`<path d="M4 6l4 4 4-4" ${STK} stroke-width="1.7"/>`, 13),
    closed: svg(`<path d="M10 3.8L5.8 8 10 12.2" ${STK} stroke-width="1.7"/>`, 13)
  };
  const clone = o => JSON.parse(JSON.stringify(o));
  const ls = { get: k => { try { return localStorage.getItem(k); } catch { return null; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch { } } };

  // ---------- תצוגת טקסט קריאה (הבעלים 26/11: פלט השלבים היה "לא קריא") ----------
  // Markdown אמיתי (window.renderMarkdown), כיוון לכל בלוק לפי התוכן: יש עברית → מימין לשמאל, רק אנגלית → משמאל לימין.
  // קוד, נתיבים וקישורים תמיד משמאל לימין ומבודדים (לא "מערבבים" את השורה)
  const HEB = /[֐-׿؀-ۿ]/, LAT = /[A-Za-z]/;
  const blockDir = el0 => { const c = el0.cloneNode(true); c.querySelectorAll('code,pre,.path-link,a,.code-block').forEach(x => x.remove()); const t = c.textContent || ''; return HEB.test(t) ? 'rtl' : LAT.test(t) ? 'ltr' : 'rtl'; };
  function mdHtml(text) {
    const raw = String(text == null ? '' : text);
    let html; try { html = window.renderMarkdown ? window.renderMarkdown(raw) : `<p>${esc(raw)}</p>`; } catch { html = `<p>${esc(raw)}</p>`; }
    const t = document.createElement('template'); t.innerHTML = html;
    t.content.querySelectorAll('p,li,h1,h2,h3,h4,h5,h6,blockquote,ul,ol,dd,dt').forEach(e => e.setAttribute('dir', blockDir(e)));
    t.content.querySelectorAll('.code-block,pre').forEach(e => e.setAttribute('dir', 'ltr'));
    return t.innerHTML;
  }
  const textDir = s => (HEB.test(String(s || '')) ? 'rtl' : LAT.test(String(s || '')) ? 'ltr' : 'rtl');
  // ערכי מגבלות: ריק / null / 0 = ללא הגבלה
  const limOf = v => (v == null || v === '' || !(Number(v) > 0) ? null : Number(v));
  function limitsText(f) {
    const l = []; if (limOf(f.maxMinutes)) l.push(`עד ${f.maxMinutes} דק׳ בסך הכול`); if (limOf(f.maxVisits)) l.push(`עד ${f.maxVisits} חזרות לשלב`); if (limOf(f.maxSteps)) l.push(`עד ${f.maxSteps} ביצועי שלבים`);
    return l.length ? l.join(' · ') : '';
  }

  const S = {
    view: 'list', flows: [], runs: [], active: [], loaded: false, err: '', sig: '', loading: false, again: false,
    showAll: ls.get('fl.showAll') === '1',
    convProj: new Map(), convTitle: new Map(), convAt: 0,
    pollT: null, runT: null,
    E: null,                                  // מצב העורך
    runId: null, run: null, runErr: '', runOpen: new Set(), runSig: '', runBusyStop: false,
    gen: { busy: false, t0: 0, goal: '', err: '' }, pending: null, uid: 0
  };

  // ---------- עזרים ----------
  const body = () => $('flowsBody');
  // רכיב בתוך העורך הפעיל — העורך יכול להיות בחלונית או בחלון התזרים הגדול (S.E.root)
  const eq = id => { const r = S.E && S.E.root; return r && r.isConnected ? r.querySelector('#' + id) : $(id); };
  const visible = () => { const b = body(); return !!b && b.getClientRects().length > 0 && !document.hidden; };
  const clk = ms => { const s = Math.max(0, Math.floor(ms / 1000)); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60); return (h ? h + ':' : '') + pad(m) + ':' + pad(s % 60); };
  const ago = ts => {
    const s = Math.max(0, Math.round((Date.now() - ts) / 1000)); if (s < 45) return 'הרגע';
    const m = Math.round(s / 60); if (m < 60) return `לפני ${m} דק'`;
    const h = Math.round(m / 60); if (h < 48) return `לפני ${h} שע'`;
    return `לפני ${Math.round(h / 24)} ימים`;
  };
  const clip = (s, n) => { s = String(s == null ? '' : s); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
  const numOrU = v => (v === '' || v == null || !Number.isFinite(Number(v)) ? undefined : Number(v));
  const toLocalInput = ms => { if (!ms) return ''; const d = new Date(ms); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`; };
  const flowById = id => S.flows.find(f => f.id === id) || null;

  function curChat() { try { return (App.chats && App.chats.active && App.chats.active()) || null; } catch { return null; } }
  function curProject() {
    try { const a = App.projects && App.projects.activeId && App.projects.activeId(); if (a) return a; } catch { }
    const c = curChat(); return (c && c.projectId) || null;
  }
  function curConvId() { const c = curChat(); return (c && c.id) || null; }
  const projList = () => { try { return (App.projects && App.projects.list && App.projects.list()) || []; } catch { return []; } };
  const projName = id => { const p = projList().find(x => x.id === id); return p ? p.name : ''; };
  async function ensureProjects() {
    let l = projList();
    if (!l.length) { try { l = (await App.api('/api/projects')).projects || []; if (App.projects && App.projects.refresh) App.projects.refresh().catch(() => { }); } catch { l = []; } }
    return l;
  }
  async function ensureProjectId() {
    const c = curProject(); if (c) return c;
    const l = await ensureProjects(); return (l.find(p => p.general) || l[0] || {}).id || null;
  }
  // שיחות: מיפוי שיחה→פרויקט (לסינון תזרימים ברמת שיחה) וכותרות
  async function ensureConvs(force) {
    if (!force && Date.now() - S.convAt < 30000) return;
    S.convAt = Date.now();
    try {
      const l = (await App.api('/api/conversations')).conversations || [];
      let ch = false;
      for (const c of l) { if (S.convProj.get(c.id) !== (c.projectId || null)) { S.convProj.set(c.id, c.projectId || null); ch = true; } S.convTitle.set(c.id, c.title || ''); }
      if (ch && S.view === 'list') { S.sig = ''; renderList(); }
    } catch { }
  }
  function inScope(f) {
    const pid = curProject(); if (!pid) return true;
    if (f.scope.type === 'project') return f.scope.id === pid;
    if (S.convProj.has(f.scope.id)) return S.convProj.get(f.scope.id) === pid;
    try { const c = App.chats.byConvId(f.scope.id); return !!(c && c.projectId === pid); } catch { return false; }
  }

  function schedText(f) {
    const s = f.schedule || { mode: 'none' };
    if (s.mode === 'at') return `⏰ ${App.fmt.dateTime(s.at)}${s.done ? ' (בוצע)' : ''}`;
    if (s.mode === 'every') { const m = s.everyMin; return `⏰ כל ${m >= 60 && m % 60 === 0 ? (m / 60) + " שע'" : m + " דק'"}`; }
    if (s.mode === 'daily') return `⏰ כל יום ב-${s.time}`;
    return '';
  }
  const lastRunOf = fid => S.runs.find(r => r.flowId === fid && r.status !== 'running') || null;
  const activeRunOf = fid => S.active.find(r => r.flowId === fid) || null;

  function updateBadge() {
    const b = $('actFlowsBadge'); if (!b) return;
    const n = S.active.length; b.textContent = String(n); b.hidden = n === 0;
  }

  // ---------- טעינה + סקר ----------
  async function load() {
    if (S.loading) { S.again = true; return; }
    S.loading = true;
    try {
      const d = await App.api('/api/flows');
      S.flows = d.flows || []; S.runs = d.runs || []; S.active = d.active || []; S.loaded = true; S.err = '';
    } catch (e) { S.err = (e && e.message) || 'שגיאה'; }
    S.loading = false;
    updateBadge();
    const sig = JSON.stringify([S.flows.map(f => [f.id, f.updatedAt, f.enabled, f.locked]), S.runs.map(r => [r.id, r.status, r.endedAt]), S.active.map(r => [r.id, r.stepId, r.stepNo]), S.showAll, curProject(), S.convProj.size, !!S.err, !!S.pending]);
    if (sig !== S.sig) { S.sig = sig; if (S.view === 'list') renderList(); else if (S.view === 'run') renderRun(); }
    if (S.again) { S.again = false; load(); }
  }
  function schedulePoll() {
    clearTimeout(S.pollT);
    S.pollT = setTimeout(async () => { try { await load(); } catch { } schedulePoll(); }, visible() ? 2000 : 6000);
  }
  // שעון חי: מעדכן רק טקסט של אלמנטים עם data-fl-since (לא בונה מחדש את התצוגה)
  function tickClocks() {
    const now = Date.now();
    const roots = [...document.querySelectorAll('.fl-w')]; const b = body(); if (b && b.getClientRects().length) roots.push(b);
    for (const r of roots) {
      r.querySelectorAll('[data-fl-since]').forEach(n => { n.textContent = clk(now - Number(n.dataset.flSince)); });
      r.querySelectorAll('[data-fl-until]').forEach(n => { n.textContent = clk(Math.max(0, Number(n.dataset.flUntil) - now)); });
    }
    const g = b && b.querySelector('[data-fl-gen]'); if (g && S.gen.busy) g.textContent = clk(now - S.gen.t0);
  }

  // ---------- מעבר בין תצוגות ----------
  function showPanel() { try { if (App.view && App.view.show) App.view.show('flows'); } catch { } }
  function setTools() {
    const t = $('flowsTools'); if (!t) return;
    t.innerHTML = '';
    if (S.view !== 'list') return;
    const mk = (id, txt, title, fn) => { const b = el('button', 'icon-btn'); b.id = id; b.type = 'button'; b.textContent = txt; b.title = title; b.onclick = fn; t.appendChild(b); };
    mk('flNewBtn', '＋', 'תזרים חדש', () => openEditor(null));
    mk('flGenBtn', '✨', 'בנה תזרים עם Claude', () => openGen());
    mk('flRefreshBtn', '↻', 'רענן', () => { load(); App.toast('מרענן…', 700); });
  }
  function setView(v) {
    S.view = v;
    if (v !== 'run') { clearTimeout(S.runT); S.runT = null; }
    setTools();
    const b = body(); if (b) b.scrollTop = 0;
    if (v === 'list') { S.sig = ''; renderList(); load(); }
    else if (v === 'editor') renderEditor();
    else if (v === 'gen') renderGen();
    else if (v === 'run') renderRun();
  }
  async function leaveEditor() {
    if (S.view === 'editor' && S.E && S.E.dirty) { const ok = await App.confirm('יש שינויים שלא נשמרו. לצאת בלי לשמור?', { okText: 'צא בלי לשמור', cancelText: 'המשך לערוך', danger: true }); if (!ok) return false; }
    return true;
  }
  async function goBack() { if (await leaveEditor()) { S.E = null; setView('list'); } }

  // ============================================================
  //  1) רשימה
  // ============================================================
  const chipHtml = (cls, txt, title) => `<span class="fl-chip ${cls || ''}"${title ? ` title="${esc(title)}"` : ''}>${txt}</span>`;

  function cardHtml(f) {
    const act = activeRunOf(f.id), last = act ? null : lastRunOf(f.id);
    const st = act ? 'running' : last ? last.status : 'idle';
    // כל כפתור עושה דבר אחר (הבעלים 26/11): "N שלבים" = הגדרת השלבים · "שיחה" = פתיחת השיחה שהתזרים רץ בה · "צפה בהרצה" = ההרצה שלב אחרי שלב · לחיצה על הכרטיס = חלון התזרים המלא
    const chips = [`<button type="button" class="fl-chip fl-chipbtn" data-act="steps" title="הצג את ${f.steps.length} השלבים שהתזרים מריץ">🧩 ${f.steps.length} שלבים</button>`];
    chips.push(`<button type="button" class="fl-chip fl-chipbtn scope" data-act="chat" title="${f.scope.type === 'chat' ? 'פתח את השיחה שהתזרים רץ בה' : 'פתח את השיחה של ההרצה האחרונה (כל הרצה פותחת שיחה חדשה בפרויקט)'}">${f.scope.type === 'chat' ? '💬 שיחה' : '📁 פרויקט · 💬 שיחה'}</button>`);
    if (f.locked) chips.unshift(chipHtml('lock', '🔒 נעול', 'נעול ע"י הבעלים: Claude לא יכול לערוך, לעצור או למחוק אותו'));
    const lt = limitsText(f); chips.push(chipHtml('lim' + (lt ? '' : ' inf'), lt ? '⛔ ' + lt : '∞ ללא הגבלה', lt ? 'מגבלות שהגדרת להרצה' : 'בלי מגבלה: תזרים בלולאה זורם עד שתעצור אותו'));
    const sc = schedText(f); if (sc) chips.push(chipHtml('sched' + (f.enabled ? '' : ' off'), sc + (f.enabled ? '' : ' · כבוי'), f.enabled ? 'תזמון פעיל' : 'התזמון כבוי'));
    if (last) chips.push(chipHtml('st-' + last.status, `${ST[last.status].ic} ${ST[last.status].txt} · ${ago(last.endedAt || last.startedAt)}`, last.reason || ''));
    let live = '';
    if (act) {
      const idx = f.steps.findIndex(s => s.id === act.stepId);
      const nm = idx >= 0 ? f.steps[idx].name : '';
      live = `<div class="fl-live"><span class="fl-spin"></span><span class="fl-live-t">${idx >= 0 ? `שלב ${idx + 1}/${f.steps.length} — ${esc(clip(nm, 40))}` : 'מתחיל…'}${act.stepNo > f.steps.length ? ` <small>· ביצוע ${act.stepNo}</small>` : ''}</span><span class="fl-clock" data-fl-since="${act.startedAt}">${clk(Date.now() - act.startedAt)}</span></div>`;
    } else if (last && last.status !== 'done' && last.reason) live = `<div class="fl-reason ${last.status}">${esc(clip(last.reason, 120))}</div>`;
    return `<div class="fl-card" data-id="${esc(f.id)}" data-status="${st}" tabindex="0">
      <div class="fl-c1"><span class="fl-name" title="${esc(f.name)}">${esc(f.name)}</span></div>
      ${f.description ? `<div class="fl-desc">${esc(f.description)}</div>` : ''}
      <div class="fl-chips">${chips.join('')}</div>
      ${live}
      <div class="fl-acts">
        ${act ? `<button type="button" class="fl-btn danger" data-act="stop-card" title="עצור את ההרצה"><i class="fl-sq"></i> עצור</button><button type="button" class="fl-btn" data-act="open-run" title="ההרצה שלב אחרי שלב">👁 צפה בהרצה</button>`
          : `<button type="button" class="fl-btn pri" data-act="run" title="הפעל עכשיו">${IC.play} הפעל</button><button type="button" class="fl-btn" data-act="edit">${IC.edit} ערוך</button>${last ? '<button type="button" class="fl-btn" data-act="open-run" title="ההרצה האחרונה שלב אחרי שלב">👁 צפה בהרצה</button>' : ''}`}
        <button type="button" class="fl-btn icon" data-act="more" title="עוד פעולות">${IC.more}</button>
      </div>
    </div>`;
  }

  function emptyHtml(hasAny) {
    return `<div class="fl-empty">
      <div class="fl-empty-ic">⚙</div>
      <h3>${hasAny ? 'אין תזרימים בפרויקט הזה' : 'עוד אין תזרימים'}</h3>
      <p>תזרים הוא רצף שלבים שהשרת מריץ ומחייב — Claude לא יכול לדלג על שלב. בדיקה חוזרת, ניסיון ← מחקר ← ניסיון נוסף, ופעולות מתוזמנות.</p>
      <button type="button" class="fl-btn pri big" id="flEmptyNew" data-act="new">＋ תזרים חדש</button>
      <button type="button" class="fl-btn big" id="flEmptyGen" data-act="gen">✨ בנה עם Claude</button>
      <div class="fl-empty-sub">או התחל מתבנית</div>
      <div class="fl-tpl-row">${['loop', 'poll', 'cmd'].map(k => `<button type="button" class="fl-tpl-mini" data-act="tpl" data-tpl="${k}">${TPLS[k].title}</button>`).join('')}</div>
    </div>`;
  }

  function renderList() {
    const b = body(); if (!b) return;
    const pid = curProject();
    if (S.flows.some(f => f.scope && f.scope.type === 'chat')) ensureConvs();
    const shown = (S.showAll || !pid ? S.flows.slice() : S.flows.filter(inScope));
    shown.sort((a, c) => ((activeRunOf(c.id) ? 1 : 0) - (activeRunOf(a.id) ? 1 : 0)) || (c.updatedAt || 0) - (a.updatedAt || 0));
    const pn = pid ? projName(pid) : '';
    let h = '<div class="fl-root fl-list">';
    if (S.pending) h += `<div class="fl-pending"><span>✨ התזרים שבנה Claude מוכן</span><button type="button" class="fl-btn pri" data-act="pend-open">פתח</button></div>`;
    if (S.flows.length) {
      h += `<div class="fl-bar"><span class="fl-bar-t">${S.showAll || !pn ? 'כל התזרימים' : `תזרימים של «${esc(clip(pn, 22))}»`} <span class="fl-gc">${shown.length}</span></span>
        <label class="fl-switch" title="הצג תזרימים של כל הפרויקטים"><input type="checkbox" id="flShowAll" data-f="showAll" ${S.showAll ? 'checked' : ''}><i></i><span>הצג את כולם</span></label></div>`;
    }
    if (S.err && !S.loaded) h += `<div class="fl-note">לא הצלחתי לטעון את התזרימים (${esc(S.err)}). <button type="button" class="fl-link" data-act="reload">נסה שוב</button></div>`;
    h += shown.length ? `<div class="fl-cards">${shown.map(cardHtml).join('')}</div>` : (S.loaded ? emptyHtml(S.flows.length > 0) : '<div class="fl-note">טוען…</div>');
    h += '</div>';
    b.innerHTML = h;
  }

  // ---------- פעולות על תזרים ----------
  async function startFlow(f, convId, andOpen) {
    try {
      const d = await App.api(`/api/flows/${f.id}/start`, { method: 'POST', body: convId ? { convId } : {} });
      App.toast('התזרים התחיל', 1500);
      await load();
      if (andOpen) openRun(d.run.id);
      return d.run;
    } catch (e) { App.toast(e.message, 3500); return null; }
  }
  async function stopRun(rid) {
    try { await App.api(`/api/flows/runs/${rid}/stop`, { method: 'POST', body: {} }); App.toast('עוצר…', 1200); } catch (e) { App.toast(e.message, 3000); }
    await load();
  }
  async function duplicateFlow(f) {
    const c = clone(f); delete c.id; delete c.createdAt; delete c.updatedAt; c.name = f.name + ' (עותק)'; c.schedule = { mode: 'none' };
    try { await App.api('/api/flows', { method: 'POST', body: c }); App.toast('שוכפל', 1500); await load(); } catch (e) { App.toast(e.message, 3500); }
  }
  async function removeFlow(f) {
    const ok = await App.confirm(`למחוק את התזרים «${f.name}»?\nהרצה פעילה שלו תיעצר.`, { okText: 'מחק', danger: true, title: 'מחיקת תזרים' });
    if (!ok) return;
    try { await App.api('/api/flows/' + f.id, { method: 'DELETE' }); App.toast('נמחק', 1500); await load(); } catch (e) { App.toast(e.message, 3500); }
  }
  async function toggleEnabled(f) {
    try { await App.api('/api/flows/' + f.id, { method: 'PUT', body: { ...f, enabled: !f.enabled } }); App.toast(f.enabled ? 'התזמון כובה' : 'התזמון הופעל', 1500); await load(); } catch (e) { App.toast(e.message, 3500); }
  }
  function moreMenu(f, btn) {
    const r = btn.getBoundingClientRect();
    const hasSched = f.schedule && f.schedule.mode !== 'none';
    App.menu(Math.round(r.left), Math.round(r.bottom + 4), [
      { icon: '🗗', label: 'פתח את חלון התזרים', onClick: () => openFlowWindow(f.id) },
      { icon: '💬', label: 'הפעל בשיחה הנוכחית', disabled: !curConvId() || !!activeRunOf(f.id), onClick: () => startFlow(f, curConvId()) },
      { icon: '⧉', label: 'שכפל', onClick: () => duplicateFlow(f) },
      hasSched && { icon: f.enabled ? '⏸' : '▶', label: f.enabled ? 'כבה תזמון' : 'הפעל תזמון', disabled: !!f.locked, onClick: () => toggleEnabled(f) },
      { icon: f.locked ? '🔓' : '🔒', label: f.locked ? 'בטל נעילה' : 'נעל (Claude לא יוכל לשנות)', onClick: () => setLock(f.id, !f.locked) },
      { sep: true },
      { icon: '🗑', label: 'מחק', danger: true, disabled: !!f.locked, onClick: () => removeFlow(f) }
    ]);
  }
  async function setLock(fid, on) {
    try { await App.api(`/api/flows/${fid}/${on ? 'lock' : 'unlock'}`, { method: 'POST', body: {} }); App.toast(on ? '🔒 התזרים נעול — Claude לא יכול לערוך, לעצור או למחוק אותו' : '🔓 הנעילה בוטלה', 2200); }
    catch (e) { App.toast(e.message, 3500); }
    await load(); for (const W of S.wins.values()) if (W.fid === fid) wRefresh(W, true);
  }

  // ---------- כפתורי הכרטיס: כל אחד פעולה אחרת ----------
  // "N שלבים" — בדיוק השלבים שירוצו, לפי הסדר (ההגדרה, לא הרצה)
  function stepTypeLine(s) {
    const bits = [];
    if (s.type !== 'wait' && s.timeoutMin) bits.push(`⏱ עד ${s.timeoutMin} דק׳`);
    if (s.type === 'wait') bits.push(`⏱ ממתין ${s.waitSec} שנ׳`);
    if (s.type === 'watch') bits.push(`🔁 כל ${s.everySec} שנ׳`);
    if (s.retries) bits.push(`↻ ${s.retries} ניסיונות חוזרים`);
    if (s.idleMin && (s.type === 'task' || s.type === 'research')) bits.push(`💤 תקוע אחרי ${s.idleMin} דק׳ בלי תזוזה → רץ שוב`);
    return bits;
  }
  function routeText(steps, i, v, k) {
    if (v === 'next') return i === steps.length - 1 ? 'סיום' : `השלב הבא (${i + 2})`;
    if (v === 'end') return 'סיום (הצלחה)';
    if (v === 'stop') return 'עצירה';
    const j = steps.findIndex(s => s.id === v); return j >= 0 ? `${j <= i ? '↩' : '→'} שלב ${j + 1}: ${steps[j].name}` : String(v);
  }
  const CHK_HE = { contains: 'התשובה / הפלט מכילים', not_contains: 'התשובה / הפלט לא מכילים', command: 'פקודת בדיקה (קוד 0 = עבר)', judge: 'שופט (Claude בודק לפי קריטריון)' };
  const ALLOW_HE = { read: '📖 קריאה', write: '✏️ כתיבה', shell: '⌨️ פקודות', web: '🌐 רשת', browser: '🧭 דפדפן', agents: '🤖 סוכנים', chats: '💬 צ\'אטים', mcp: '🔌 MCP', all: '⭐ הכול' };
  // כרטיס קריאה של שלב (חלון "N שלבים" + לשונית השלבים בחלון התזרים)
  function stepViewHtml(s, i, steps, o = {}) {
    const T = TYPES[s.type] || TYPES.task;
    const content = (s.type === 'task' || s.type === 'research') ? `<div class="fl-sv-k">${s.type === 'research' ? 'מה לחקור' : 'הוראה ל-Claude'}</div><div class="fl-sv-prompt fl-md md">${mdHtml(s.prompt || '')}</div>`
      : (s.type === 'command' || s.type === 'watch') ? `<div class="fl-sv-k">פקודה</div><pre class="fl-out" dir="ltr">${esc(s.command || '')}</pre>` : '';
    const chk = s.check && s.check.type && s.check.type !== 'none' ? `<div class="fl-sv-row"><span class="fl-sv-k">בדיקת התוצאה</span><span dir="${textDir(s.check.value)}">${esc(CHK_HE[s.check.type] || s.check.type)}: <b>${esc(s.check.value)}</b></span></div>` : '';
    const allow = (s.allow || []).length ? `<div class="fl-sv-row"><span class="fl-sv-k">🔒 כלים מותרים</span><span class="fl-sv-chips">${s.allow.map(a => `<span class="fl-chip">${esc(ALLOW_HE[a] || a)}</span>`).join('')}</span></div>` : '';
    const ks = s.type === 'wait' ? [['ok', '✔ אחרי ההמתנה']] : [['ok', '✔ אם הצליח'], ['fail', '✖ אם נכשל'], ['timeout', '⏱ אם עבר הזמן']];
    const routes = `<div class="fl-sv-routes">${ks.map(([k, l]) => `<span class="fl-sv-route r-${s.on && s.on[k] === 'stop' ? 'stop' : s.on && s.on[k] === 'end' ? 'end' : 'go'}"><i>${l}</i> ${esc(routeText(steps, i, (s.on || {})[k] || (k === 'ok' ? 'next' : 'stop'), k))}</span>`).join('')}</div>`;
    const meta = stepTypeLine(s);
    return `<article class="fl-sv${o.cur ? ' cur' : ''}" data-sid="${esc(s.id)}" id="${o.idp || 'flsv'}-${esc(s.id)}">
      <header class="fl-sv-h"><span class="fl-num t-${s.type}">${i + 1}</span><span class="fl-sv-type t-${s.type}">${T.ic} ${T.label}</span><b class="fl-sv-name" dir="${textDir(s.name)}">${esc(s.name)}</b>${o.cur ? '<span class="fl-chip st-running"><span class="fl-spin"></span> רץ עכשיו</span>' : ''}</header>
      ${meta.length ? `<div class="fl-sv-meta">${meta.map(m => `<span>${esc(m)}</span>`).join('')}</div>` : ''}
      ${content}${chk}${allow}${routes}
    </article>`;
  }
  function showStepsPopup(f) {
    const act = activeRunOf(f.id);
    const box = el('div', 'fl-w fl-stepspop');
    box.innerHTML = `<div class="fl-pop-intro">אלה ${f.steps.length} השלבים שהתזרים <b>«${esc(f.name)}»</b> מריץ, לפי הסדר. השרת מריץ שלב אחד בכל פעם ובוחר את הבא לפי התוצאה.${limitsText(f) ? ` מגבלות: ${esc(limitsText(f))}.` : ' ללא הגבלה: לולאה ממשיכה עד שתעצור.'}</div>
      <div class="fl-chain fl-pop-chain" dir="ltr">${f.steps.map((s, i) => `<span class="fl-sn t-${s.type}${act && act.stepId === s.id ? ' cur' : ''}" title="${esc(s.name)}">${i + 1}</span>`).join('<span class="fl-sa">→</span>')}<span class="fl-sa">→</span><span class="fl-sn fin">⏹</span></div>
      <div class="fl-svlist">${f.steps.map((s, i) => stepViewHtml(s, i, f.steps, { cur: act && act.stepId === s.id, idp: 'flpop' })).join('')}</div>
      <div class="fl-pop-foot"><button type="button" class="fl-btn" data-pop="win">🗗 פתח את חלון התזרים (עריכה)</button></div>`;
    const m = App.modal({ title: `🧩 ${f.steps.length} השלבים של «${f.name}»`, body: box, wide: true, cls: 'fl-steps-modal' });
    box.addEventListener('click', e => { if (e.target.closest('[data-pop="win"]')) { m.close(); openFlowWindow(f.id, { tab: 'steps' }); } });
    return m;
  }
  // "שיחה" — השיחה שבה התזרים / הלולאה שלו רצה: ההרצה הפעילה, אחרת האחרונה, אחרת שיחת היעד של התזרים
  function flowChatId(f) {
    const r = activeRunOf(f.id) || S.runs.find(x => x.flowId === f.id && x.convId);
    return (r && r.convId) || (f.scope && f.scope.type === 'chat' ? f.scope.id : null);
  }
  function openFlowChat(f) {
    const cid = flowChatId(f);
    if (!cid) { App.toast('לתזרים הזה עוד אין שיחה — כל הרצה פותחת שיחה חדשה בפרויקט. הפעל אותו פעם אחת.', 3500); return false; }
    try { App.chats.openConversation(cid); } catch (e) { App.toast(e.message || 'לא הצלחתי לפתוח את השיחה', 3000); return false; }
    try { if (App.view && App.view.show && window.innerWidth < 900) App.view.show('chats'); } catch { }
    return true;
  }
  // "צפה בהרצה" — ההרצה הפעילה, או האחרונה
  function openLatestRun(f) {
    const r = activeRunOf(f.id) || S.runs.find(x => x.flowId === f.id);
    if (!r) { App.toast('התזרים עוד לא רץ', 2200); return; }
    openRun(r.id);
  }

  // ============================================================
  //  חלון התזרים הגדול (כמו חלון המחקר): הכול על התזרים + עריכה מלאה
  // ============================================================
  S.wins = new Map(); // fid -> W
  function withE(W, fn) { const prev = S.E; S.E = W.E; try { return fn(); } finally { W.E = S.E; S.E = prev; } }
  async function openFlowWindow(fid, o = {}) {
    const ex = S.wins.get(fid);
    if (ex && ex.m.el.isConnected) { ex.m.el.parentNode.appendChild(ex.m.el); if (o.tab) wTab(ex, o.tab); if (o.edit) wEdit(ex); return ex; }
    let flow; try { flow = (await App.api('/api/flows/' + fid)).flow; } catch (e) { App.toast(e.message || 'התזרים לא נמצא', 3000); return null; }
    await ensureProjects(); if (flow.scope && flow.scope.type === 'chat') ensureConvs(true);
    const root = el('div', 'fl-w fl-win');
    root.dataset.fid = fid;
    root.innerHTML = `<div class="fl-w-top" data-r="top"></div>
      <div class="fl-w-body"><nav class="fl-w-nav" data-r="nav" aria-label="ניווט בתזרים"></nav><main class="fl-w-main" data-r="main"></main></div>`;
    const W = { fid, root, flow, runs: [], run: null, selRun: null, tab: o.tab || 'overview', edit: false, E: null, openSet: new Set(), pollT: 0, sig: '', busyStop: false, draft: null };
    W.top = root.querySelector('[data-r="top"]'); W.nav = root.querySelector('[data-r="nav"]'); W.main = root.querySelector('[data-r="main"]');
    W.m = App.modal({
      title: '⚙ ' + flow.name, cls: 'xwide fl-win-box', sticky: true, body: root,
      onClose: () => { clearInterval(W.pollT); if (W.edit && W.E && W.E.dirty) { S.drafts.set(fid, W.E); App.toast('השינויים שלא נשמרו נשמרו כטיוטה — פתח שוב את חלון התזרים כדי להמשיך', 3500); } S.wins.delete(fid); }
    });
    S.wins.set(fid, W);
    root.addEventListener('click', e => wOnClick(W, e));
    root.addEventListener('input', e => wOnInput(W, e));
    root.addEventListener('change', e => wOnInput(W, e));
    root.addEventListener('keydown', e => { if (W.edit && e.key === 'Enter' && e.target.matches && e.target.matches('input.fl-in')) e.preventDefault(); });
    await wRefresh(W, true);
    if (o.edit || S.drafts.has(fid)) wEdit(W);
    W.pollT = setInterval(() => { if (!root.isConnected) { clearInterval(W.pollT); return; } wRefresh(W, false); }, 1500);
    return W;
  }
  S.drafts = new Map();
  async function wRefresh(W, force) {
    try {
      const [fd, rd] = await Promise.all([App.api('/api/flows/' + W.fid), App.api('/api/flows/' + W.fid + '/runs?summary=1')]);
      W.flow = fd.flow; W.runs = rd.runs || [];
    } catch (e) { if (e && e.status === 404) { W.top.innerHTML = '<div class="fl-note">התזרים נמחק.</div>'; W.main.innerHTML = ''; W.nav.innerHTML = ''; clearInterval(W.pollT); return; } }
    const cur = W.runs.find(r => r.status === 'running') || null;
    const rid = W.selRun || (cur && cur.id) || (W.runs[0] && W.runs[0].id) || null;
    if (rid && (W.tab === 'run' || W.tab === 'overview' || force)) {
      const need = force || !W.run || W.run.id !== rid || W.run.status === 'running';
      if (need) { try { W.run = (await App.api('/api/flows/runs/' + rid)).run; } catch { } }
    } else if (!rid) W.run = null;
    const r = W.run;
    const sig = JSON.stringify([W.flow && [W.flow.updatedAt, W.flow.locked, W.flow.enabled, (W.flow.lock || {}).blockedTotal], W.runs.map(x => [x.id, x.status, x.stepNo]), r && [r.id, r.status, (r.log || []).length, r.stepId, r.retryAt], W.tab, W.edit, W.busyStop, [...W.openSet].join()]);
    if (!force && sig === W.sig) return;
    W.sig = sig;
    wRender(W);
  }
  function wTab(W, tab) { W.tab = tab; W.sig = ''; if (tab === 'run' && !W.run) wRefresh(W, true); else wRender(W); }
  function wRender(W) {
    const f = W.flow; if (!f) return;
    W.m.setTitle('⚙ ' + f.name);
    const act = W.runs.find(r => r.status === 'running') || null, last = W.runs[0] || null;
    const stNow = act ? 'running' : last ? last.status : null;
    const lt = limitsText(f);
    W.top.innerHTML = `<div class="fl-w-t1">
        <span class="fl-w-name" dir="${textDir(f.name)}">${esc(f.name)}</span>
        ${f.locked ? '<span class="fl-chip lock" data-r="lockchip" title="נעול ע״י הבעלים">🔒 נעול</span>' : ''}
        ${stNow ? `<span class="fl-chip big st-${stNow}" data-r="wstatus">${stNow === 'running' ? '<span class="fl-spin"></span>' : ST[stNow].ic} ${ST[stNow].txt}${act ? ` · שלב ${Math.max(1, (f.steps.findIndex(s => s.id === act.stepId) + 1) || 1)}/${f.steps.length}` : ''}</span>` : '<span class="fl-chip">עוד לא רץ</span>'}
        <span class="fl-chip ${lt ? 'lim' : 'lim inf'}">${lt ? '⛔ ' + esc(lt) : '∞ ללא הגבלה'}</span>
      </div>
      ${f.description ? `<div class="fl-w-desc" dir="${textDir(f.description)}">${esc(f.description)}</div>` : ''}
      <div class="fl-w-acts">
        ${act ? `<button type="button" class="fl-btn danger" data-act="w-stop" ${W.busyStop ? 'disabled' : ''}><i class="fl-sq"></i> ${W.busyStop ? 'עוצר…' : 'עצור'}</button>` : `<button type="button" class="fl-btn pri" data-act="w-run" ${W.edit ? 'disabled' : ''}>${IC.play} הפעל</button>`}
        <button type="button" class="fl-btn" data-act="w-tab" data-tab="run" ${last ? '' : 'disabled'}>👁 צפה בהרצה</button>
        <button type="button" class="fl-btn" data-act="w-chat">💬 שיחה</button>
        ${W.edit ? '' : `<button type="button" class="fl-btn" data-act="w-edit" ${f.locked ? 'disabled title="התזרים נעול — בטל קודם את הנעילה"' : ''}>${IC.edit} עריכה</button>`}
        <button type="button" class="fl-btn ${f.locked ? 'lockon' : ''}" data-act="w-lock" title="${f.locked ? 'בטל את הנעילה (רק מחלון האפליקציה)' : 'נעל: Claude לא יוכל לערוך, לעצור או למחוק את התזרים'}">${f.locked ? '🔓 בטל נעילה' : '🔒 נעל'}</button>
      </div>`;
    // ניווט: סקירה · שלבים (כל שלב בנפרד) · הרצה · היסטוריה
    const steps = W.edit && W.E ? W.E.flow.steps : f.steps;
    const nav = [['overview', '📋 סקירה כללית'], ['steps', `🧩 שלבים <span class="fl-gc">${steps.length}</span>`], ['run', `▶ הרצה ${act ? '<i class="fl-dot"></i>' : ''}`], ['history', `🕓 היסטוריית הרצות <span class="fl-gc">${W.runs.length}</span>`]];
    W.nav.innerHTML = nav.map(([k, l]) => `<button type="button" class="fl-w-tab${W.tab === k ? ' on' : ''}" data-act="w-tab" data-tab="${k}">${l}</button>${k === 'steps' ? `<div class="fl-w-snav">${steps.map((s, i) => `<button type="button" class="fl-w-sitem${act && act.stepId === s.id && !W.edit ? ' cur' : ''}" data-act="w-goto" data-sid="${esc(s.id)}" title="${esc(s.name)}"><span class="fl-num t-${s.type}">${i + 1}</span><span class="fl-w-sname" dir="${textDir(s.name)}">${esc(s.name || '(ללא שם)')}</span></button>`).join('')}${W.edit ? '<button type="button" class="fl-w-sitem add" data-act="w-add">＋ הוסף שלב בסוף</button>' : ''}</div>` : ''}`).join('');
    if (W.edit) { if (!W.main.querySelector('.fl-ed')) wRenderEditor(W); return; }
    const st0 = W.main.scrollTop;
    if (W.tab === 'overview') W.main.innerHTML = wOverviewHtml(W, act, last);
    else if (W.tab === 'steps') W.main.innerHTML = `<div class="fl-w-pane" data-pane="steps"><div class="fl-w-ph"><h3>שלבי התזרים</h3><span class="fl-dim">${f.steps.length} שלבים · השרת מריץ אותם לפי הסדר ולפי המעברים</span><button type="button" class="fl-btn" data-act="w-edit" ${f.locked ? 'disabled' : ''}>${IC.edit} ערוך שלבים</button></div><div class="fl-chain" dir="ltr">${f.steps.map((s, i) => `<span class="fl-sn t-${s.type}${act && act.stepId === s.id ? ' cur' : ''}">${i + 1}</span>`).join('<span class="fl-sa">→</span>')}<span class="fl-sa">→</span><span class="fl-sn fin">⏹</span></div><div class="fl-svlist">${f.steps.map((s, i) => stepViewHtml(s, i, f.steps, { cur: act && act.stepId === s.id, idp: 'flw' })).join('')}</div></div>`;
    else if (W.tab === 'run') W.main.innerHTML = `<div class="fl-w-pane" data-pane="run">${W.run ? `<div class="fl-w-ph"><h3>${W.run.status === 'running' ? 'ההרצה הנוכחית' : 'הרצה'} — ${esc(App.fmt.dateTime(W.run.startedAt))}</h3>${W.runs.length > 1 ? `<button type="button" class="fl-btn" data-act="w-tab" data-tab="history">🕓 הרצות קודמות</button>` : ''}</div>${runInnerHtml(W.run, { win: true, openSet: W.openSet, busyStop: W.busyStop })}` : '<div class="fl-note">התזרים עוד לא רץ.</div>'}</div>`;
    else if (W.tab === 'history') W.main.innerHTML = `<div class="fl-w-pane" data-pane="history"><div class="fl-w-ph"><h3>היסטוריית הרצות</h3></div>${W.runs.length ? `<div class="fl-hist">${W.runs.map(x => histRowHtml(x, W.run && x.id === W.run.id, 'w-hist')).join('')}</div>` : '<div class="fl-note">אין עדיין הרצות.</div>'}</div>`;
    W.main.scrollTop = st0;
  }
  function scopeLabel(f) {
    if (f.scope.type === 'project') return `📁 פרויקט «${esc(projName(f.scope.id) || f.scope.id)}» — כל הרצה פותחת שיחה חדשה בפרויקט`;
    const t = S.convTitle.get(f.scope.id) || (() => { try { const c = App.chats.byConvId(f.scope.id); return c && c.title; } catch { return ''; } })();
    return `💬 השיחה «${esc(t || f.scope.id.slice(0, 8))}»`;
  }
  function wOverviewHtml(W, act, last) {
    const f = W.flow, sc = schedText(f) || 'ידני — מפעילים בכפתור', lt = limitsText(f), li = f.lock || null;
    const card = (k, v, extra = '') => `<div class="fl-w-card${extra}"><div class="fl-w-ck">${k}</div><div class="fl-w-cv">${v}</div></div>`;
    const G = { steps: 'נאכף בשלבים שהוגדרו להם כלים מותרים', strict: 'קשיח — שלב בלי הגדרה = קריאה בלבד', off: 'בלי אכיפה' };
    const r = W.run;
    let h = `<div class="fl-w-pane" data-pane="overview"><div class="fl-w-grid">
      ${card('מצב עכשיו', act ? `<span class="fl-spin"></span> רץ — ${esc((f.steps.find(s => s.id === act.stepId) || {}).name || 'מתחיל')} · ${act.stepNo || 0} ביצועים` : last ? `${ST[last.status].ic} ${ST[last.status].txt} · ${esc(ago(last.endedAt || last.startedAt))}${last.reason ? `<div class="fl-dim" dir="${textDir(last.reason)}">${esc(clip(last.reason, 160))}</div>` : ''}` : 'עוד לא רץ')}
      ${card('על מה רץ', scopeLabel(f) + `<div><button type="button" class="fl-link" data-act="w-chat">💬 פתח את השיחה</button></div>`)}
      ${card('תזמון', esc(sc) + (f.schedule && f.schedule.mode !== 'none' ? (f.enabled ? ' · פעיל' : ' · <b>כבוי</b>') : ''))}
      ${card('מגבלות', lt ? '⛔ ' + esc(lt) : '∞ <b>ללא הגבלה</b> — לולאה זורמת עד שתעצור אותה. תקלה זמנית לא עוצרת: השלב רץ שוב', lt ? '' : ' ok')}
      ${card('אכיפה בהוק', esc(G[f.guard || 'steps'] || f.guard))}
      ${card('נעילה', f.locked ? `🔒 נעול${f.lockedAt ? ' מ-' + esc(App.fmt.dateTime(f.lockedAt)) : ''} — Claude לא יכול לערוך, לעצור או למחוק${li && li.blockedTotal ? `<div class="fl-dim">${li.blockedTotal} ניסיונות נחסמו${(li.blocked || []).length ? ':' : ''}</div>${(li.blocked || []).map(b => `<div class="fl-dim small" dir="rtl">• ${esc(App.fmt.time(b.at))} — ${esc(b.what)}</div>`).join('')}` : ''}` : '🔓 לא נעול — Claude יכול לערוך את התזרים כשתבקש', f.locked ? ' lock' : '')}
      ${card('נוצר / עודכן', `${esc(App.fmt.dateTime(f.createdAt))} · ${esc(App.fmt.dateTime(f.updatedAt))}`)}
      ${card('הרצות', `${W.runs.length} הרצות${W.runs.length ? ` · <button type="button" class="fl-link" data-act="w-tab" data-tab="history">היסטוריה</button>` : ''}`)}
    </div>
    ${f.description ? `<section class="fl-w-sec"><h4>תיאור</h4><div class="fl-md md">${mdHtml(f.description)}</div></section>` : ''}
    <section class="fl-w-sec"><h4>השלבים בקצרה <button type="button" class="fl-link" data-act="w-tab" data-tab="steps">כל הפרטים</button></h4>
      <ol class="fl-w-olist">${f.steps.map((s, i) => `<li class="${act && act.stepId === s.id ? 'cur' : ''}"><span class="fl-num t-${s.type}">${i + 1}</span><span class="fl-w-oname" dir="${textDir(s.name)}">${TYPES[s.type].ic} ${esc(s.name)}</span><span class="fl-dim">${esc(routeText(f.steps, i, s.on.ok, 'ok'))}</span></li>`).join('')}</ol></section>`;
    if (r) h += `<section class="fl-w-sec"><h4>${r.status === 'running' ? 'ההרצה הנוכחית' : 'ההרצה האחרונה'} <button type="button" class="fl-link" data-act="w-tab" data-tab="run">פתח את ההרצה המלאה</button></h4>${(() => { const rows = buildRows(r).slice(-3); return rows.length ? `<div class="fl-tl mini">${rows.map((row, k) => rowHtml(row, 'o' + k, r, k === rows.length - 1, W.openSet)).join('')}</div>` : '<div class="fl-note">עוד לא התחיל שלב…</div>'; })()}</section>`;
    return h + '</div>';
  }
  // עריכה בתוך החלון: אותו עורך כמו בחלונית (כל השדות + השלבים), עם שמירה
  function wEdit(W) {
    const f = W.flow; if (!f) return;
    if (f.locked) { App.toast('🔒 התזרים נעול — בטל קודם את הנעילה', 3000); return; }
    const draft = S.drafts.get(W.fid); S.drafts.delete(W.fid);
    const ff = draft ? draft.flow : fullFlow(f);
    S.uid = Math.max(S.uid, ff.steps.length + 50);
    W.E = draft ? { ...draft, root: null } : { isNew: false, flow: ff, errors: [], dirty: false, collapsed: new Set(), bad: new Set(), ai: false, root: null, win: true };
    W.edit = true; W.tab = 'steps'; W.sig = '';
    W.main.innerHTML = '';
    wRender(W);
  }
  function wRenderEditor(W) {
    W.main.innerHTML = `<div class="fl-root fl-ed fl-wed"><div class="fl-w-ph"><h3>✏ עריכת התזרים</h3><span class="fl-dim">אפשר להוסיף שלב בכל מקום (＋ בין שלבים), למחוק, לשנות שם ותוכן, ולהזיז ▲▼</span></div>
      ${withE(W, () => { W.E.root = W.main; return editorFormHtml(); })}
      <div class="fl-foot"><button type="button" class="fl-btn pri" id="flSave" data-act="w-save">שמור</button><button type="button" class="fl-btn" data-act="w-cancel">ביטול</button></div></div>`;
    withE(W, () => { W.E.root = W.main; renderScopeExtra(); renderSteps(); });
  }
  function wNavRefresh(W) { // אחרי שינוי בשלבים בעורך: הרשימה בניווט מתעדכנת
    const box = W.nav.querySelector('.fl-w-snav'); if (!box || !W.E) return;
    box.innerHTML = W.E.flow.steps.map((s, i) => `<button type="button" class="fl-w-sitem" data-act="w-goto" data-sid="${esc(s.id)}"><span class="fl-num t-${s.type}">${i + 1}</span><span class="fl-w-sname" dir="${textDir(s.name)}">${esc(s.name || '(ללא שם)')}</span></button>`).join('') + '<button type="button" class="fl-w-sitem add" data-act="w-add">＋ הוסף שלב בסוף</button>';
    const n = W.nav.querySelector('[data-tab="steps"] .fl-gc'); if (n) n.textContent = W.E.flow.steps.length;
  }
  async function wSave(W) {
    const E = W.E; if (!E || E.saving) return null;
    E.errors = [];
    if (E.flow.scope.type === 'chat' && !E.flow.scope.id) E.errors.push('אין שיחה לקשור אליה את התזרים — בחר "פרויקט".');
    if (E.errors.length) { withE(W, () => { markBad(); renderErrors(); renderSteps(); }); return null; }
    E.saving = true;
    try {
      const d = await App.api('/api/flows/' + W.fid, { method: 'PUT', body: flowPayload(E) });
      E.saving = false; E.dirty = false;
      W.flow = d.flow; W.edit = false; W.E = null; W.tab = 'steps'; W.sig = '';
      App.toast('התזרים נשמר', 1500);
      await load(); await wRefresh(W, true);
      return d.flow;
    } catch (e) {
      E.saving = false;
      E.errors = (e.data && Array.isArray(e.data.errors) && e.data.errors.length) ? e.data.errors : String(e.message || 'שגיאה בשמירה').split(' · ');
      withE(W, () => { markBad(); renderErrors(); renderSteps(); const b = eq('flErrors'); if (b) b.scrollIntoView({ block: 'start' }); });
      return null;
    }
  }
  async function wCancel(W) {
    if (W.E && W.E.dirty) { const ok = await App.confirm('יש שינויים שלא נשמרו. לבטל אותם?', { okText: 'בטל שינויים', cancelText: 'המשך לערוך', danger: true }); if (!ok) return; }
    W.edit = false; W.E = null; W.sig = ''; wRender(W);
  }
  async function wOnClick(W, e) {
    const a = e.target.closest('[data-act]'); if (!a || !W.root.contains(a)) return;
    const act = a.dataset.act, f = W.flow;
    if (act === 'row-toggle' || act === 'row-toggle-btn') {
      if (e.target.closest('a,.path-link,.copy-code')) return;
      if (window.getSelection && String(window.getSelection()).length) return;
      const row = a.closest('.fl-row'); if (!row || !W.run) return; const k = W.run.id + ':' + row.dataset.k;
      if (W.openSet.has(k)) W.openSet.delete(k); else W.openSet.add(k); W.sig = ''; wRender(W); return;
    }
    switch (act) {
      case 'w-tab': if (W.edit && a.dataset.tab !== 'steps') { App.toast('סיים קודם את העריכה (שמור / ביטול)', 2200); break; } W.selRun = a.dataset.tab === 'run' ? W.selRun : W.selRun; wTab(W, a.dataset.tab); break;
      case 'w-goto': {
        if (!W.edit && W.tab !== 'steps') wTab(W, 'steps');
        const sid = a.dataset.sid;
        if (W.edit) withE(W, () => { S.E.collapsed.delete(sid); renderSteps(); });
        const t = W.main.querySelector(W.edit ? `.fl-step[data-sid="${CSS.escape(sid)}"]` : `.fl-sv[data-sid="${CSS.escape(sid)}"]`);
        if (t) { t.scrollIntoView({ block: 'start', behavior: 'smooth' }); t.classList.add('flash'); setTimeout(() => t.classList.remove('flash'), 1200); }
        break;
      }
      case 'w-run': { const run = await startFlow(f, null, false); if (run) { W.selRun = null; W.tab = 'run'; W.run = null; await wRefresh(W, true); } break; }
      case 'w-stop': { const r = W.runs.find(x => x.status === 'running'); if (r) { W.busyStop = true; wRender(W); await stopRun(r.id); setTimeout(async () => { W.busyStop = false; W.sig = ''; await wRefresh(W, true); }, 900); } break; }
      case 'w-chat': if (openFlowChat(f)) W.m.close(); break;
      case 'w-chat-run': if (W.run && W.run.convId) { try { App.chats.openConversation(W.run.convId); W.m.close(); } catch (er) { App.toast(er.message); } } break;
      case 'w-edit': wEdit(W); break;
      case 'w-lock': await setLock(W.fid, !f.locked); break;
      case 'w-hist': W.selRun = a.dataset.rid; W.run = null; W.tab = 'run'; await wRefresh(W, true); break;
      case 'w-save': await wSave(W); break;
      case 'w-cancel': await wCancel(W); break;
      case 'w-add': withE(W, () => addStep()); wNavRefresh(W); break;
      default:
        if (W.edit && withE(W, () => editorAction(act, a))) wNavRefresh(W);
    }
  }
  function wOnInput(W, e) {
    if (!W.edit || !W.E) return;
    const t = e.target; if (!t.dataset || !t.dataset.f) return;
    withE(W, () => onEditorInput(e));
    if (t.dataset.f === 'name' || t.dataset.f === 'type') wNavRefresh(W);
  }

  // ============================================================
  //  2) תבניות + בנייה עם Claude
  // ============================================================
  const TPLS = {
    loop: {
      title: 'לולאת עבודה', desc: 'ניסיון ← בדיקה ← אם נכשל: מחקר ברשת ← ניסיון חוזר לפי המסקנות',
      make: () => ({
        name: 'לולאת עבודה', description: 'ניסיון, ואם נכשל — מחקר ברשת וניסיון חוזר לפי המסקנות',
        steps: [
          { id: 's1', name: 'ניסיון', type: 'task', prompt: 'בצע את המשימה (ערוך כאן: מה בדיוק לעשות). בסוף דווח מה עשית ומה התוצאה.', timeoutMin: 30, check: { type: 'judge', value: 'המשימה בוצעה בפועל והתוצאה נבדקה ועובדת' }, on: { ok: 'end', fail: 's2', timeout: 's2' } },
          { id: 's2', name: 'מחקר ברשת', type: 'research', prompt: 'חפש ברשת למה הניסיון הקודם נכשל ומה הפתרונות המקובלים. כתוב מסקנות ממוספרות ומה לנסות עכשיו.', timeoutMin: 25, on: { ok: 'next', fail: 'stop', timeout: 'next' } },
          { id: 's3', name: 'ניסיון חוזר לפי המסקנות', type: 'task', prompt: 'נסה שוב לפי המסקנות מהמחקר. בדוק שהפעם זה עובד בפועל, ודווח.', timeoutMin: 30, check: { type: 'judge', value: 'המשימה בוצעה בפועל והתוצאה נבדקה ועובדת' }, on: { ok: 'end', fail: 's2', timeout: 's2' } }
        ]
      })
    },
    poll: {
      title: 'בדיקה חוזרת', desc: 'בודק פקודה כל 10 שניות עד 30 דקות; אם לא ענה — מחקר',
      make: () => ({
        name: 'בדיקה חוזרת', description: 'בודק כל 10 שניות עד שמצליח; אם עבר הזמן — מחקר ברשת',
        steps: [
          { id: 's1', name: 'בדיקה חוזרת', type: 'watch', command: 'curl -sf https://example.com', everySec: 10, timeoutMin: 30, on: { ok: 'next', fail: 'stop', timeout: 's3' } },
          { id: 's2', name: 'סיכום', type: 'task', prompt: 'הבדיקה עברה. סכם בקצרה מה נבדק ומה התוצאה.', timeoutMin: 10, on: { ok: 'end', fail: 'stop', timeout: 'stop' } },
          { id: 's3', name: 'מחקר: למה זה לא עונה', type: 'research', prompt: 'הבדיקה לא הצליחה במשך 30 דקות. חפש ברשת סיבות אפשריות ופתרונות. כתוב מסקנות ממוספרות.', timeoutMin: 25, on: { ok: 'end', fail: 'stop', timeout: 'stop' } }
        ]
      })
    },
    cmd: {
      title: 'פקודה + אימות', desc: 'מריץ פקודה, בודק את הפלט, ואז Claude מאמת את התוצאה',
      make: () => ({
        name: 'פקודה + אימות', description: 'מריץ פקודה, בודק את הפלט ומבקש מ-Claude לאמת',
        steps: [
          { id: 's1', name: 'הרץ פקודה', type: 'command', command: 'echo done', timeoutMin: 10, retries: 1, check: { type: 'contains', value: 'done' }, on: { ok: 'next', fail: 'stop', timeout: 'stop' } },
          { id: 's2', name: 'אימות', type: 'task', prompt: 'בדוק שהתוצאה של הפקודה האחרונה תקינה והסבר בקצרה.', timeoutMin: 10, on: { ok: 'end', fail: 'stop', timeout: 'stop' } }
        ]
      })
    }
  };
  async function openTemplate(key) {
    const t = TPLS[key]; if (!t) return;
    const pid = await ensureProjectId();
    const d = t.make(); d.scope = { type: 'project', id: pid };
    return openEditor(null, { draft: d, dirty: true });
  }

  function openGen() { S.gen.err = ''; showPanel(); setView('gen'); }
  async function generate(goal) {
    goal = String(goal || '').trim();
    if (!goal) { S.gen.err = 'כתוב מה התזרים צריך לעשות'; if (S.view === 'gen') renderGen(); return null; }
    if (S.gen.busy) return null;
    S.gen = { busy: true, t0: Date.now(), goal, err: '' };
    if (S.view === 'gen') renderGen();
    try {
      const pid = await ensureProjectId();
      const d = await App.api('/api/flows/generate', { method: 'POST', body: { goal, scope: { type: 'project', id: pid } } });
      S.gen.busy = false;
      const info = { draft: d.flow, errors: d.errors || [], ai: true, dirty: true };
      if (S.view === 'gen' || S.view === 'list') { await openEditor(null, info); if (info.errors.length) App.toast('התזרים נבנה — יש כמה דברים לתקן', 3000); }
      else { S.pending = info; App.toast('התזרים שבנה Claude מוכן', 3000); }
      return d.flow;
    } catch (e) {
      S.gen.busy = false; S.gen.err = e.message || 'שגיאה';
      if (S.view === 'gen') renderGen();
      return null;
    }
  }
  function renderGen() {
    const b = body(); if (!b) return;
    const g = S.gen;
    b.innerHTML = `<div class="fl-root fl-gen">
      <div class="fl-head"><button type="button" class="fl-back" data-act="back" title="חזרה">→</button><div class="fl-title">בנה עם Claude</div></div>
      <section class="fl-sec">
        <label class="fl-f"><span>מה התזרים צריך לעשות?</span>
          <textarea class="fl-in" id="flGoal" data-f="goal" rows="5" placeholder="למשל: בדוק כל דקה אם האתר שלי עונה. אם הוא לא עונה 10 דקות — חפש ברשת מה הסיבה, נסה לתקן ובדוק שוב." ${g.busy ? 'disabled' : ''}>${esc(g.goal)}</textarea></label>
        <button type="button" class="fl-btn pri big" id="flGenGo" data-act="gen-go" ${g.busy ? 'disabled' : ''}>${g.busy ? 'בונה…' : '✨ בנה תזרים'}</button>
        ${g.busy ? `<div class="fl-genbusy" id="flGenBusy"><span class="fl-spin"></span><div><b>Claude בונה את התזרים…</b><small>זה לוקח בין 15 שניות לדקה · <span class="fl-clock" data-fl-gen>${clk(Date.now() - g.t0)}</span></small></div></div>` : ''}
        ${g.err ? `<div class="fl-errors" id="flGenErr"><div class="fl-err-h">לא הצלחתי לבנות</div><div class="fl-err-i">${esc(g.err)}</div></div>` : ''}
      </section>
      <section class="fl-sec">
        <h4 class="fl-sec-h">או התחל מתבנית</h4>
        <div class="fl-tpls">${['loop', 'poll', 'cmd'].map(k => `<button type="button" class="fl-tpl" data-act="tpl" data-tpl="${k}"><b>${TPLS[k].title}</b><span>${TPLS[k].desc}</span></button>`).join('')}</div>
      </section>
    </div>`;
    const ta = $('flGoal'); if (ta && !g.busy) setTimeout(() => ta.focus(), 30);
  }

  // ============================================================
  //  3) עורך
  // ============================================================
  function newStepId() { const used = new Set(S.E ? S.E.flow.steps.map(s => s.id) : []); let id; do { id = 's' + (++S.uid); } while (used.has(id)); return id; }
  function fullStep(s) {
    const type = TYPES[s.type] ? s.type : 'task';
    const o = {
      id: s.id || newStepId(), name: s.name || '', type, prompt: '', command: '', everySec: 10, waitSec: 60,
      timeoutMin: DEF_TIMEOUT[type], retries: 0, check: { type: 'none', value: '' }, on: { ok: 'next', fail: 'stop', timeout: 'stop' }
    };
    for (const k of ['prompt', 'command', 'everySec', 'waitSec', 'timeoutMin', 'retries', 'idleMin', 'chat']) if (s[k] != null) o[k] = s[k];
    o.allow = Array.isArray(s.allow) ? s.allow.slice() : [];
    if (s.check) o.check = { type: s.check.type || 'none', value: s.check.value || '' };
    if (s.on) o.on = { ...o.on, ...s.on };
    return o;
  }
  function fullFlow(f) {
    return {
      id: f.id, name: f.name || '', description: f.description || '', scope: f.scope ? { ...f.scope } : { type: 'project', id: '' },
      enabled: f.enabled !== false, guard: f.guard || 'steps', researchQuota: Number(f.researchQuota) || 1, locked: !!f.locked,
      maxMinutes: limOf(f.maxMinutes) == null ? '' : f.maxMinutes, maxVisits: limOf(f.maxVisits) == null ? '' : f.maxVisits, maxSteps: limOf(f.maxSteps) == null ? '' : f.maxSteps, researchQuota: [1, 2, 3].includes(Number(f.researchQuota)) ? Number(f.researchQuota) : 1, // ריק = ללא הגבלה
      schedule: clone(f.schedule || { mode: 'none' }), steps: (f.steps || []).map(fullStep)
    };
  }
  async function openEditor(id, o = {}) {
    if (S.view === 'editor' && S.E && S.E.dirty && !(await leaveEditor())) return null;
    let flow;
    if (o.draft) flow = clone(o.draft);
    else if (id) {
      try { flow = (await App.api('/api/flows/' + id)).flow; } catch (e) { App.toast(e.message, 3500); return null; }
      if (flow.locked) { App.toast('🔒 התזרים נעול — כדי לערוך, בטל את הנעילה בחלון התזרים', 3500); openFlowWindow(id); return null; }
    } else {
      const pid = await ensureProjectId();
      flow = { name: '', description: '', scope: { type: 'project', id: pid }, steps: [{ name: 'שלב 1', type: 'task', prompt: '' }] };
    }
    await ensureProjects();
    const ff = fullFlow(flow);
    S.uid = Math.max(S.uid, ff.steps.length);
    S.E = { isNew: !id, flow: ff, errors: o.errors || [], dirty: !!o.dirty, collapsed: new Set(), bad: new Set(), ai: !!o.ai, root: body() };
    if (ff.steps.length > 4) ff.steps.slice(1).forEach(s => S.E.collapsed.add(s.id));
    markBad();
    S.pending = null;
    showPanel(); setView('editor');
    if (ff.scope.type === 'chat') ensureConvs(true).then(() => { if (S.view === 'editor') renderScopeExtra(); });
    if (S.E.isNew && !ff.name) setTimeout(() => { const n = eq('flName'); if (n && S.view === 'editor') n.focus(); }, 40);
    return S.E;
  }
  function markBad() {
    const E = S.E; E.bad = new Set();
    for (const e of E.errors) { const m = /שלב (\d+)/.exec(e); if (m) E.bad.add(Number(m[1]) - 1); }
  }

  // --- אפשרויות מעבר ---
  function routeOptions(i) {
    const steps = S.E.flow.steps;
    const o = [['next', i === steps.length - 1 ? 'השלב הבא (סיום)' : 'השלב הבא'], ['end', 'סיום (הצלחה)'], ['stop', 'עצירה (כשל)']];
    steps.forEach((s, j) => o.push([s.id, `→ שלב ${j + 1}: ${clip(s.name || '(ללא שם)', 26)}${j === i ? ' (זה)' : ''}`]));
    return o;
  }
  const routeOptsHtml = (i, val) => routeOptions(i).map(([v, l]) => `<option value="${esc(v)}"${v === val ? ' selected' : ''}>${esc(l)}</option>`).join('');
  function refreshRouteLabels() {
    const root = eq('flSteps'); if (!root) return;
    root.querySelectorAll('.fl-step').forEach(card => {
      const i = Number(card.dataset.i), s = S.E.flow.steps[i]; if (!s) return;
      card.querySelectorAll('select[data-f^="r-"]').forEach(sel => { const k = sel.dataset.f.slice(2); sel.innerHTML = routeOptsHtml(i, s.on[k]); sel.value = s.on[k]; });
    });
  }
  function renderStrip() {
    const box = eq('flStrip'); if (!box) return;
    const steps = S.E.flow.steps; const idx = new Map(steps.map((s, i) => [s.id, i]));
    const chips = steps.map((s, i) => `<span class="fl-sn t-${s.type}" title="${esc(`${i + 1}. ${TYPES[s.type].label}: ${s.name}`)}">${i + 1}</span>`).join('<span class="fl-sa">→</span>');
    const pills = [];
    steps.forEach((s, i) => {
      const ks = s.type === 'wait' ? ['ok'] : ['ok', 'fail', 'timeout'];
      for (const k of ks) {
        const v = s.on[k]; if (v === DEFAULT_ROUTE[k]) continue;
        if (v === 'end') pills.push(`<span class="fl-pill end" dir="ltr" title="סיום מוצלח">${i + 1} ${KIC[k]} ⏹ סיום</span>`);
        else if (v === 'stop') pills.push(`<span class="fl-pill stop" dir="ltr" title="עצירה">${i + 1} ${KIC[k]} ⏹ עצירה</span>`);
        else if (v === 'next') pills.push(`<span class="fl-pill" dir="ltr" title="ממשיך לשלב הבא">${i + 1} ${KIC[k]} → ${i + 2 <= steps.length ? i + 2 : 'סיום'}</span>`);
        else if (idx.has(v)) { const j = idx.get(v); pills.push(`<span class="fl-pill ${j <= i ? 'loop' : 'fwd'}" dir="ltr" title="${j <= i ? 'לולאה אחורה' : 'קפיצה קדימה'}">${i + 1} ${KIC[k]} ${j <= i ? '↩' : '→'} ${j + 1}</span>`); }
      }
    });
    box.innerHTML = steps.length ? `<div class="fl-chain" dir="ltr">${chips}<span class="fl-sa">→</span><span class="fl-sn fin" title="סיום">⏹</span></div>${pills.length ? `<div class="fl-pills">${pills.join('')}</div>` : ''}` : '';
  }

  function checkLabels(type) {
    const out = type === 'command' || type === 'watch';
    return [['none', 'ללא בדיקה'], ['contains', out ? 'הפלט מכיל…' : 'התשובה מכילה…'], ['not_contains', out ? 'הפלט לא מכיל…' : 'התשובה לא מכילה…'], ['command', 'פקודת בדיקה (קוד 0 = עבר)'], ['judge', 'שופט — Claude בודק לפי קריטריון']];
  }
  const CHK_PH = { contains: 'הטקסט שחייב להופיע', not_contains: 'הטקסט שאסור שיופיע', command: 'פקודה שמחזירה קוד 0 כשהכול תקין', judge: 'מה נחשב הצלחה? (נבדק לפי הדיווח של Claude)' };

  function stepHtml(s, i) {
    const E = S.E, T = TYPES[s.type], col = E.collapsed.has(s.id) && !E.bad.has(i), n = E.flow.steps.length;
    const typeSel = `<select class="fl-in fl-typesel" data-f="type" title="סוג השלב">${Object.entries(TYPES).map(([k, t]) => `<option value="${k}"${k === s.type ? ' selected' : ''}>${t.ic} ${t.label}</option>`).join('')}</select>`;
    const head = `<div class="fl-sh">
        <span class="fl-num t-${s.type}">${i + 1}</span>
        ${col ? `<button type="button" class="fl-sh-title" data-act="toggle" title="פתח">${T.ic} ${esc(s.name || '(ללא שם)')}</button>` : typeSel}
        <span class="fl-sbtns">
          <button type="button" class="fl-ib" data-act="up" title="הזז למעלה" ${i === 0 ? 'disabled' : ''}>${IC.up}</button>
          <button type="button" class="fl-ib" data-act="down" title="הזז למטה" ${i === n - 1 ? 'disabled' : ''}>${IC.down}</button>
          <button type="button" class="fl-ib del" data-act="del" title="מחק שלב">${IC.trash}</button>
          <button type="button" class="fl-ib" data-act="toggle" title="${col ? 'הרחב' : 'כווץ'}">${col ? IC.closed : IC.open}</button>
        </span></div>`;
    if (col) return `<div class="fl-step collapsed${E.bad.has(i) ? ' fl-bad' : ''}" data-i="${i}" data-sid="${esc(s.id)}">${head}</div>`;
    let f = `<label class="fl-f"><span>שם השלב</span><input class="fl-in" data-f="name" value="${esc(s.name)}" placeholder="שם קצר לשלב"></label>`;
    if (s.type === 'task' || s.type === 'research') f += `<label class="fl-f"><span>${s.type === 'research' ? 'מה לחקור (Claude יחפש ברשת ויכתוב מסקנות)' : 'הוראה ל-Claude'}</span><textarea class="fl-in" data-f="prompt" rows="3" placeholder="${s.type === 'research' ? 'למשל: חפש למה השגיאה הזו קורית ומה הפתרונות' : 'מה Claude צריך לעשות בשלב הזה'}">${esc(s.prompt)}</textarea></label>`;
    if (s.type === 'command' || s.type === 'watch') f += `<label class="fl-f"><span>פקודה (מתבצעת במחשב, קוד 0 = הצלחה)</span><input class="fl-in fl-cmd" data-f="command" value="${esc(s.command)}" placeholder="npm test" spellcheck="false"></label>`;
    if (s.type === 'watch') f += `<label class="fl-f"><span>בדוק כל (שניות)</span><input class="fl-in fl-num-in" type="number" step="any" min="0.2" data-f="everySec" value="${esc(s.everySec)}"></label>`;
    if (s.type === 'wait') f += `<label class="fl-f"><span>זמן המתנה (שניות)</span><input class="fl-in fl-num-in" type="number" step="any" min="0.1" data-f="waitSec" value="${esc(s.waitSec)}"></label>`;
    if (s.type !== 'wait') {
      const hasRetry = s.type !== 'watch';
      f += `<div class="${hasRetry ? 'fl-grid2' : ''}"><label class="fl-f"><span>זמן מקסימום (דקות)</span><input class="fl-in fl-num-in" type="number" step="any" min="0.02" data-f="timeoutMin" value="${esc(s.timeoutMin)}"></label>
        ${hasRetry ? `<label class="fl-f"><span>ניסיונות חוזרים</span><input class="fl-in fl-num-in" type="number" step="1" min="0" max="5" data-f="retries" value="${esc(s.retries || 0)}"></label>` : ''}</div>`;
      f += `<div class="fl-f"><span>בדיקת התוצאה</span><select class="fl-in" data-f="chk-type">${checkLabels(s.type).map(([v, l]) => `<option value="${v}"${v === s.check.type ? ' selected' : ''}>${l}</option>`).join('')}</select>
        ${s.check.type === 'none' ? '' : (s.check.type === 'judge' ? `<textarea class="fl-in" data-f="chk-val" rows="2" placeholder="${esc(CHK_PH.judge)}">${esc(s.check.value)}</textarea>` : `<input class="fl-in${s.check.type === 'command' ? ' fl-cmd' : ''}" data-f="chk-val" value="${esc(s.check.value)}" placeholder="${esc(CHK_PH[s.check.type])}">`)}</div>`;
    }
    if (s.type === 'task' || s.type === 'research') {
      const CATS = [['read', '📖 קריאה'], ['write', '✏️ כתיבה'], ['shell', '⌨️ פקודות'], ['web', '🌐 רשת'], ['browser', '🧭 דפדפן'], ['agents', '🤖 סוכנים'], ['chats', '💬 צ\'אטים'], ['mcp', '🔌 MCP'], ['all', '⭐ הכול']];
      const al = Array.isArray(s.allow) ? s.allow : [];
      f += `<div class="fl-f"><span>🔒 כלים מותרים בשלב הזה (ההוק חוסם את השאר)</span><div class="fl-allow">${CATS.map(([v, l]) => `<button type="button" class="fl-chip${al.includes(v) ? ' on' : ''}" data-act="allow" data-allow="${v}">${l}</button>`).join('')}</div><div class="fl-hint">${al.length ? 'רק הקבוצות המסומנות מותרות.' : ((S.E && S.E.flow.guard === 'strict') ? 'לא סומן כלום: במצב קשיח — קריאה וחיפוש בקבצים בלבד.' : 'לא סומן כלום: אין הגבלה בשלב הזה.')}</div></div>`;
    }
    const rk = s.type === 'wait' ? [['ok', 'אחרי ההמתנה']] : [['ok', 'אם הצליח'], ['fail', 'אם נכשל'], ['timeout', 'אם עבר הזמן']];
    f += `<div class="fl-route"><div class="fl-route-h">מה קורה אחר כך</div>${rk.map(([k, l]) => `<label class="fl-rr"><span class="fl-rl">${KIC[k]} ${l}</span><select class="fl-in fl-rsel" data-f="r-${k}">${routeOptsHtml(i, s.on[k])}</select></label>`).join('')}</div>`;
    return `<div class="fl-step${E.bad.has(i) ? ' fl-bad' : ''}" data-i="${i}" data-sid="${esc(s.id)}">${head}<div class="fl-sb">${f}</div></div>`;
  }
  function stepsHtml() {
    const steps = S.E.flow.steps;
    return steps.map((s, i) => (i ? `<button type="button" class="fl-ins" data-act="ins" data-at="${i}" title="הוסף שלב כאן"><span>＋</span></button>` : '') + stepHtml(s, i)).join('') + `<button type="button" class="fl-add" id="flAddStep" data-act="add">＋ הוסף שלב</button>`;
  }
  function renderSteps() { const r = eq('flSteps'); if (r) r.innerHTML = stepsHtml(); renderStrip(); const c = eq('flStepsN'); if (c && S.E) c.textContent = S.E.flow.steps.length; }

  function errorsHtml() {
    const E = S.E; if (!E.errors.length) return '';
    return `<div class="fl-err-h">צריך לתקן ${E.errors.length === 1 ? 'דבר אחד' : E.errors.length + ' דברים'} לפני שמירה</div>` + E.errors.map(e => { const m = /שלב (\d+)/.exec(e); return `<div class="fl-err-i${m ? ' link' : ''}" ${m ? `data-act="goto-step" data-i="${Number(m[1]) - 1}"` : ''}>• ${esc(e)}</div>`; }).join('');
  }
  function renderErrors() { const b = eq('flErrors'); if (!b) return; b.innerHTML = errorsHtml(); b.hidden = !S.E.errors.length; }
  function renderScopeExtra() {
    const box = eq('flScopeExtra'); if (!box || !S.E) return; const f = S.E.flow;
    if (f.scope.type === 'project') {
      const l = projList();
      box.innerHTML = `<label class="fl-f"><span>פרויקט</span><select class="fl-in" data-f="projectId">${l.map(p => `<option value="${esc(p.id)}"${p.id === f.scope.id ? ' selected' : ''}>${esc(p.name)}</option>`).join('')}${l.some(p => p.id === f.scope.id) ? '' : `<option value="${esc(f.scope.id)}" selected>${esc(f.scope.id || '—')}</option>`}</select></label>`;
    } else {
      const t = S.convTitle.get(f.scope.id) || (() => { try { const c = App.chats.byConvId(f.scope.id); return c && c.title; } catch { return ''; } })();
      box.innerHTML = f.scope.id ? `<div class="fl-hint">שיחה: <b>${esc(t || f.scope.id.slice(0, 8))}</b></div>` : `<div class="fl-hint warn">השיחה הנוכחית עדיין ריקה — שלח בה הודעה אחת כדי שאפשר יהיה לקשור אליה תזרים.</div>`;
    }
  }
  function schedExtraHtml(sc) {
    if (sc.mode === 'at') return `<label class="fl-f"><span>תאריך ושעה</span><input class="fl-in" type="datetime-local" data-f="sch-at" value="${toLocalInput(sc.at)}"></label>${sc.at && sc.at <= Date.now() ? '<div class="fl-hint warn">השעה כבר עברה — התזרים ירוץ מיד אחרי השמירה.</div>' : ''}`;
    if (sc.mode === 'every') return `<label class="fl-f"><span>כל כמה דקות</span><input class="fl-in fl-num-in" type="number" min="1" step="1" data-f="sch-every" value="${esc(sc.everyMin || 60)}"></label>`;
    if (sc.mode === 'daily') return `<label class="fl-f"><span>שעה ביום</span><input class="fl-in" type="time" data-f="sch-time" value="${esc(sc.time || '09:00')}"></label>`;
    return '';
  }
  function renderSchedExtra() { const b = eq('flSchedExtra'); if (b) b.innerHTML = schedExtraHtml(S.E.flow.schedule); }

  // טופס העורך (בלי כותרת ובלי שורת כפתורים) — משותף לחלונית ולחלון התזרים הגדול
  function editorFormHtml() {
    const E = S.E, f = E.flow, sc = f.schedule;
    return `<div class="fl-errors" id="flErrors" ${E.errors.length ? '' : 'hidden'}>${errorsHtml()}</div>
      <section class="fl-sec" data-sec="general">
        <label class="fl-f"><span>שם התזרים</span><input class="fl-in" data-f="fname" id="flName" value="${esc(f.name)}" placeholder="למשל: בדיקת האתר"></label>
        <label class="fl-f"><span>תיאור (לא חובה)</span><textarea class="fl-in" data-f="fdesc" rows="2" placeholder="במה התזרים עוזר">${esc(f.description)}</textarea></label>
        <label class="fl-f"><span>על מה התזרים רץ</span><select class="fl-in" data-f="target"><option value="chat"${f.scope.type === 'chat' ? ' selected' : ''}>השיחה הנוכחית</option><option value="project"${f.scope.type === 'project' ? ' selected' : ''}>פרויקט — שיחה חדשה לכל הרצה</option></select></label>
        <div id="flScopeExtra"></div>
        <div class="fl-grid2">
          <label class="fl-f"><span>זמן כולל מקסימלי (דקות)</span><input class="fl-in fl-num-in" type="number" step="any" min="0" data-f="maxMinutes" value="${esc(f.maxMinutes)}" placeholder="ללא הגבלה"></label>
          <label class="fl-f"><span>🔬 מחקר עמוק (נאכף)</span><select class="fl-in" data-f="researchQuota">${[1, 2, 3].map(n => `<option value="${n}"${Number(f.researchQuota || 1) === n ? ' selected' : ''}>${n} איטרציות עם מחקר · ${2 * n} בלי</option>`).join('')}</select></label>
          <label class="fl-f"><span>מקסימום חזרות לשלב</span><input class="fl-in fl-num-in" type="number" step="1" min="0" data-f="maxVisits" value="${esc(f.maxVisits)}" placeholder="ללא הגבלה"></label>
        </div>
        <label class="fl-f"><span>מקסימום ביצועי שלבים בהרצה</span><input class="fl-in fl-num-in" type="number" step="1" min="0" data-f="maxSteps" value="${esc(f.maxSteps)}" placeholder="ללא הגבלה"></label>
        <div class="fl-hint">שדה ריק = <b>ללא הגבלה</b>: תזרים בלולאה זורם כל הזמן, עד שתעצור אותו. תקלה זמנית (Claude נתקע / שגיאת API / קריסה) לא עוצרת אותו — השלב פשוט רץ שוב. מגבלה שתכתוב כאן — תיאכף.</div>
        <label class="fl-f"><span>🔒 אכיפה בהוק — אילו כלים Claude רשאי להפעיל בכל שלב</span><select class="fl-in" data-f="guard">
          <option value="steps"${(f.guard || 'steps') === 'steps' ? ' selected' : ''}>נאכף בשלבים שהוגדרו להם כלים מותרים (מומלץ)</option>
          <option value="strict"${f.guard === 'strict' ? ' selected' : ''}>קשיח: כל שלב מוגבל — שלב בלי הגדרה = קריאה וחיפוש בקבצים בלבד</option>
          <option value="off"${f.guard === 'off' ? ' selected' : ''}>בלי אכיפה</option></select></label>
        <div class="fl-hint">ההוק בודק כל כלי ש-Claude מפעיל, <b>לפני</b> שהוא רץ. כלי שהשלב לא מתיר — נחסם, נרשם ביומן התזרים, ו-Claude מקבל הודעה מדוע. כשלא מוגדר שלב פעיל של Claude (בין שלבים / שלב פקודה) — Claude לא יכול לפעול בכלל.</div>
      </section>
      <section class="fl-sec" data-sec="schedule">
        <h4 class="fl-sec-h">תזמון</h4>
        <label class="fl-f"><select class="fl-in" data-f="sch-mode"><option value="none"${sc.mode === 'none' ? ' selected' : ''}>ללא — הפעלה ידנית בלבד</option><option value="at"${sc.mode === 'at' ? ' selected' : ''}>פעם אחת, בשעה מסוימת</option><option value="every"${sc.mode === 'every' ? ' selected' : ''}>כל X דקות</option><option value="daily"${sc.mode === 'daily' ? ' selected' : ''}>כל יום בשעה קבועה</option></select></label>
        <div id="flSchedExtra">${schedExtraHtml(sc)}</div>
        <label class="fl-chk"><input type="checkbox" data-f="enabled" ${f.enabled ? 'checked' : ''}><span>תזמון פעיל</span></label>
      </section>
      <section class="fl-sec" data-sec="steps">
        <h4 class="fl-sec-h">שלבים <span class="fl-gc" id="flStepsN">${f.steps.length}</span></h4>
        <div id="flStrip"></div>
        <div id="flSteps" class="fl-steps"></div>
      </section>`;
  }
  function renderEditor() {
    const b = body(); if (!b || !S.E) return; const E = S.E;
    E.root = b;
    b.innerHTML = `<div class="fl-root fl-ed">
      <div class="fl-head"><button type="button" class="fl-back" data-act="back" title="חזרה לרשימה">→</button><div class="fl-title">${E.isNew ? 'תזרים חדש' : 'עריכת תזרים'}</div>${E.ai ? '<span class="fl-chip ai">✨ נבנה ע״י Claude</span>' : ''}</div>
      ${editorFormHtml()}
      <div class="fl-foot">
        <button type="button" class="fl-btn pri" id="flSave" data-act="save">שמור</button>
        <button type="button" class="fl-btn pri alt" id="flSaveRun" data-act="save-run">${IC.play} שמור והפעל</button>
        <button type="button" class="fl-btn" id="flCancel" data-act="back">ביטול</button>
      </div>
    </div>`;
    renderScopeExtra(); renderSteps();
  }

  // --- שמירה ---
  function stepPayload(s) {
    const o = { id: s.id, name: s.name, type: s.type, on: { ...s.on } };
    if (s.type === 'task' || s.type === 'research') { o.prompt = s.prompt; if (s.idleMin != null) o.idleMin = s.idleMin; }
    if (s.type === 'command' || s.type === 'watch') o.command = s.command;
    if (s.type === 'watch') o.everySec = numOrU(s.everySec);
    if (s.type === 'wait') o.waitSec = numOrU(s.waitSec);
    else { o.timeoutMin = numOrU(s.timeoutMin); o.check = { type: s.check.type, value: s.check.value }; }
    if (s.type === 'task' || s.type === 'research' || s.type === 'command') o.retries = numOrU(s.retries) || 0;
    if (s.chat) o.chat = s.chat;
    if ((s.type === 'task' || s.type === 'research') && Array.isArray(s.allow) && s.allow.length) o.allow = s.allow.slice();
    return o;
  }
  const numOrNull = v => (v === '' || v == null || !Number.isFinite(Number(v)) || !(Number(v) > 0) ? null : Number(v)); // ריק / 0 = ללא הגבלה (נשלח כ-null — לא נשמט)
  function flowPayload(E = S.E) {
    const f = E.flow, sc = f.schedule; let schedule = { mode: 'none' };
    if (sc.mode === 'at') schedule = { mode: 'at', at: Number(sc.at) || 0, done: !!sc.done };
    else if (sc.mode === 'every') schedule = { mode: 'every', everyMin: numOrU(sc.everyMin), nextAt: sc.nextAt };
    else if (sc.mode === 'daily') schedule = { mode: 'daily', time: sc.time || '', lastDay: sc.lastDay || '' };
    return { id: f.id, name: f.name.trim(), description: f.description.trim(), scope: { type: f.scope.type, id: f.scope.id }, enabled: f.enabled, guard: f.guard || 'steps', maxMinutes: numOrNull(f.maxMinutes), maxVisits: numOrNull(f.maxVisits), maxSteps: numOrNull(f.maxSteps), schedule, steps: f.steps.map(stepPayload) };
  }
  async function saveEditor(andRun) {
    const E = S.E; if (!E || E.saving) return null;
    E.errors = [];
    if (E.flow.scope.type === 'chat' && !E.flow.scope.id) E.errors.push('אין שיחה לקשור אליה את התזרים — שלח הודעה בשיחה, או בחר "פרויקט".');
    if (E.flow.scope.type === 'project' && !E.flow.scope.id) E.errors.push('בחר פרויקט');
    if (E.errors.length) { markBad(); renderErrors(); renderSteps(); scrollErrors(); return null; }
    E.saving = true; const bs = [eq('flSave'), eq('flSaveRun')]; bs.forEach(x => x && (x.disabled = true));
    try {
      const payload = flowPayload();
      const d = E.isNew ? await App.api('/api/flows', { method: 'POST', body: payload }) : await App.api('/api/flows/' + E.flow.id, { method: 'PUT', body: payload });
      E.dirty = false; E.saving = false;
      const saved = d.flow;
      await load();
      if (andRun) { S.E = null; const run = await startFlow(saved, null, false); if (run) openRun(run.id); else setView('list'); return saved; }
      App.toast('התזרים נשמר', 1500);
      S.E = null; setView('list');
      return saved;
    } catch (e) {
      E.saving = false; bs.forEach(x => x && (x.disabled = false));
      E.errors = (e.data && Array.isArray(e.data.errors) && e.data.errors.length) ? e.data.errors : String(e.message || 'שגיאה בשמירה').split(' · ');
      markBad();
      if (S.view === 'editor') { renderErrors(); renderSteps(); scrollErrors(); }
      return null;
    }
  }
  function scrollErrors() { const b = eq('flErrors'); if (b) b.scrollIntoView({ block: 'start' }); }

  // --- פעולות על שלבים ---
  const editorTouch = () => { if (S.E) S.E.dirty = true; };
  function addStep(at) {
    const E = S.E, steps = E.flow.steps; at = at == null ? steps.length : at;
    const s = fullStep({ id: newStepId(), name: `שלב ${steps.length + 1}`, type: 'task' });
    steps.splice(at, 0, s); E.collapsed.delete(s.id); E.bad = new Set(); editorTouch();
    renderSteps();
    const card = eq('flSteps').querySelector(`.fl-step[data-sid="${s.id}"]`);
    if (card) { card.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); const inp = card.querySelector('[data-f="name"]'); if (inp) { inp.focus(); inp.select(); } }
  }
  function moveStep(i, d) {
    const steps = S.E.flow.steps, j = i + d; if (j < 0 || j >= steps.length) return;
    [steps[i], steps[j]] = [steps[j], steps[i]]; S.E.bad = new Set(); editorTouch(); renderSteps();
  }
  function deleteStep(i) {
    const E = S.E, steps = E.flow.steps; if (steps.length <= 1) { App.toast('חייב להישאר לפחות שלב אחד', 2200); return; }
    const gone = steps[i].id; steps.splice(i, 1);
    for (const s of steps) for (const k of ['ok', 'fail', 'timeout']) if (s.on[k] === gone) s.on[k] = DEFAULT_ROUTE[k];   // מעבר שהצביע על שלב שנמחק חוזר לברירת מחדל
    E.bad = new Set(); editorTouch(); renderSteps();
  }
  function changeType(i, type) {
    const s = S.E.flow.steps[i], old = s.type; if (old === type) return;
    if (Number(s.timeoutMin) === DEF_TIMEOUT[old] || s.timeoutMin === '' || s.timeoutMin == null) s.timeoutMin = DEF_TIMEOUT[type];
    s.type = type;
    if (type === 'wait') { s.on = { ok: s.on.ok, fail: 'stop', timeout: 'stop' }; s.check = { type: 'none', value: '' }; }
    if ((type === 'command' || type === 'watch') && s.check.type === 'judge') s.check = { type: 'none', value: '' };
    editorTouch(); renderSteps();
  }

  function onEditorInput(e) {
    const t = e.target, k = t.dataset.f; if (!k || !S.E) return;
    const E = S.E, f = E.flow;
    const card = t.closest('.fl-step'); const s = card ? f.steps[Number(card.dataset.i)] : null;
    const isChange = e.type === 'change';
    if (s) {
      if (k === 'name') { s.name = t.value; refreshRouteLabels(); renderStrip(); }
      else if (k === 'prompt' || k === 'command') s[k] = t.value;
      else if (k === 'everySec' || k === 'waitSec' || k === 'timeoutMin' || k === 'retries') s[k] = t.value === '' ? '' : Number(t.value);
      else if (k === 'chk-val') s.check.value = t.value;
      else if (k === 'type' && isChange) { changeType(Number(card.dataset.i), t.value); return; }
      else if (k === 'chk-type' && isChange) { s.check.type = t.value; if (t.value === 'none') s.check.value = ''; editorTouch(); renderSteps(); return; }
      else if (k.startsWith('r-') && isChange) { s.on[k.slice(2)] = t.value; renderStrip(); }
      else return;
      editorTouch(); return;
    }
    if (k === 'fname') f.name = t.value;
    else if (k === 'fdesc') f.description = t.value;
    else if (k === 'maxMinutes' || k === 'maxVisits' || k === 'maxSteps') f[k] = t.value === '' ? '' : Number(t.value);
    else if (k === 'researchQuota') f[k] = Number(t.value) || 1;
    else if (k === 'guard' && isChange) f.guard = t.value;
    else if (k === 'enabled' && isChange) f.enabled = t.checked;
    else if (k === 'target' && isChange) {
      if (t.value === 'chat') { const cid = f._chatId || (curChat() && curChat().id) || ''; f._chatId = cid; f.scope = { type: 'chat', id: cid }; }
      else { if (f.scope.type === 'chat') f._chatId = f.scope.id; f.scope = { type: 'project', id: f._projId || curProject() || (projList()[0] || {}).id || '' }; }
      renderScopeExtra();
    }
    else if (k === 'projectId' && isChange) { f.scope = { type: 'project', id: t.value }; f._projId = t.value; }
    else if (k === 'sch-mode' && isChange) {
      const m = t.value;
      if (m === 'none') f.schedule = { mode: 'none' };
      else if (m === 'at') { const at = Date.now() + 3600e3; f.schedule = { mode: 'at', at: at - (at % 60000), done: false }; }
      else if (m === 'every') f.schedule = { mode: 'every', everyMin: 60 };
      else f.schedule = { mode: 'daily', time: '09:00', lastDay: '' };
      renderSchedExtra();
    }
    else if (k === 'sch-at') { f.schedule.at = t.value ? new Date(t.value).getTime() : 0; f.schedule.done = false; }
    else if (k === 'sch-every') { f.schedule.everyMin = t.value === '' ? '' : Number(t.value); delete f.schedule.nextAt; }
    else if (k === 'sch-time') { f.schedule.time = t.value; f.schedule.lastDay = ''; }
    else return;
    editorTouch();
  }

  // ============================================================
  //  4) תצוגת הרצה
  // ============================================================
  async function openRun(rid) {
    S.runId = rid; S.run = null; S.runErr = ''; S.runSig = ''; S.runBusyStop = false;
    showPanel(); setView('run');
    await fetchRun(true);
  }
  async function fetchRun(first) {
    const rid = S.runId; if (!rid) return;
    try {
      const d = await App.api('/api/flows/runs/' + rid);
      if (rid !== S.runId) return;
      S.run = d.run; S.runErr = '';
    } catch (e) { if (rid !== S.runId) return; S.runErr = e.status === 404 ? 'ההרצה לא נמצאה' : (e.message || 'שגיאה'); }
    if (S.view !== 'run' || rid !== S.runId) return;
    const r = S.run, sig = r ? [r.status, r.log.length, r.stepId, S.runErr].join('|') : S.runErr;
    if (first || sig !== S.runSig) { S.runSig = sig; renderRun(); }
    if (r && r.status === 'running') scheduleRunPoll();
    else if (r) { S.runBusyStop = false; load(); }
    else if (!S.runErr) scheduleRunPoll();
  }
  function scheduleRunPoll() {
    clearTimeout(S.runT);
    S.runT = setTimeout(async () => {
      if (S.view !== 'run') return;
      if (visible()) await fetchRun(false); else scheduleRunPoll();
    }, 1500);
  }

  // שורות ההרצה: שורה לכל ביצוע של שלב (כולל ניסיונות חוזרים ותקלות זמניות), עם התוצאה, שורת הבדיקה וההודעות
  function buildRows(run) {
    const rows = []; const general = [];
    const lastOf = sid => { for (let i = rows.length - 1; i >= 0; i--) if (rows[i].stepId === sid) return rows[i]; return null; };
    for (const l of run.log || []) {
      if (l.kind === 'step') rows.push({ stepId: l.stepId, name: l.name, no: l.no, attempt: l.attempt || 1, visit: l.visit || 1, ts: l.ts, outcome: null, text: '', why: null, body: null, transient: false, infos: [], endTs: null });
      else if (l.kind === 'result') { for (let i = rows.length - 1; i >= 0; i--) if (rows[i].stepId === l.stepId && !rows[i].outcome) { const r = rows[i]; r.outcome = l.outcome; r.text = l.text || ''; r.why = l.why != null ? l.why : null; r.body = l.body != null ? l.body : null; r.transient = !!l.transient; r.endTs = l.ts; break; } }
      else if (l.kind === 'info' || l.kind === 'retry' || l.kind === 'resume') { const r = l.stepId ? lastOf(l.stepId) : rows[rows.length - 1]; const it = { ts: l.ts, text: l.text || '', kind: l.kind, waitMs: l.waitMs }; if (r) r.infos.push(it); else general.push(it); }
    }
    rows.general = general;
    return rows;
  }
  function rowStatus(row, run, isLast) {
    if (row.outcome) return row.outcome;
    if (run.status === 'running') return isLast ? 'running' : 'skipped';
    return run.status;   // ההרצה הסתיימה באמצע השלב: נעצר / נגמר הזמן
  }
  const OUT_HE = { ok: 'הצלחה', fail: 'כשל', timeout: 'חריגת זמן', error: 'תקלה זמנית' };
  const routeInfo = text => { const m = /^(ok|fail|timeout) ← קופץ לשלב "(.*)"$/.exec(text); return m ? `קופץ לשלב «${m[2]}» (אחרי ${OUT_HE[m[1]]})` : text; };
  // תוצאה של שלב: [why, body] — גם להרצות ישנות (רק text): בפקודה השורה הראשונה היא שורת הבדיקה
  function splitResult(row, type) {
    if (row.why != null || row.body != null) return [row.why || '', row.body || ''];
    const t = String(row.text || ''); if (!t) return ['', ''];
    if (type === 'command' || type === 'watch') { const i = t.indexOf('\n'); return i < 0 ? [t, ''] : [t.slice(0, i), t.slice(i + 1)]; }
    const m = /^(נמצא "|לא נמצא "|בדיקת פקודה|שופט:|השופט נכשל)[^\n]*\n/.exec(t); return m ? [m[0].trim(), t.slice(m[0].length)] : ['', t];
  }
  const isCmdType = t => t === 'command' || t === 'watch' || t === 'wait';
  function rowHtml(row, k, run, isLast, openSet) {
    const st = rowStatus(row, run, isLast), live = st === 'running';
    const OUTX = { ...OUT, error: { ic: '⚠', cls: 'error' } };
    const ic = live ? '<span class="fl-spin"></span>' : (OUTX[st] ? OUTX[st].ic : (ST[st] ? ST[st].ic : '•'));
    const cls = OUTX[st] ? OUTX[st].cls : st;
    const endMs = row.endTs || (run.endedAt || row.ts);
    const dur = live ? `<span class="fl-rt fl-clock" data-fl-since="${row.ts}">${clk(Date.now() - row.ts)}</span>` : `<span class="fl-rt">${esc(App.fmt.dur(Math.max(0, endMs - row.ts)))}</span>`;
    const step = (run.steps || []).find(s => s.id === row.stepId); const type = step ? step.type : 'task'; const T = TYPES[type] || TYPES.task;
    const idx = (run.steps || []).findIndex(s => s.id === row.stepId);
    const badges = `<span class="fl-rb ty t-${type}" title="${esc(T.label)}">${T.ic} ${idx >= 0 ? 'שלב ' + (idx + 1) : ''}</span>` + (row.visit > 1 ? `<span class="fl-rb loop" title="הפעם ה-${row.visit} שהשלב רץ בהרצה הזו">סבב ${row.visit}</span>` : '') + (row.attempt > 1 ? `<span class="fl-rb" title="ניסיון חוזר">ניסיון ${row.attempt}</span>` : '') + (row.transient ? '<span class="fl-rb warn" title="תקלה זמנית — השלב רץ שוב אוטומטית">תקלה זמנית</span>' : '');
    const open = openSet.has(run.id + ':' + k);
    const [why, bodyTxt] = splitResult(row, type);
    const plain = row.infos.filter(i => !/קופץ לשלב/.test(i.text) && i.kind === 'info'), retries = row.infos.filter(i => i.kind === 'retry' || i.kind === 'resume');
    const lastInfo = plain.length ? plain[plain.length - 1] : null;
    const route = row.infos.filter(i => /קופץ לשלב/.test(i.text)).map(i => `<div class="fl-rroute" dir="rtl">↪ ${esc(routeInfo(i.text))}</div>`).join('');
    const lines = bodyTxt.split('\n').filter(x => x.trim()).length;
    const hasMore = bodyTxt.length > 260 || lines > 4 || plain.length > 1;
    const bodyHtml = !bodyTxt.trim() ? '' : isCmdType(type) ? `<pre class="fl-out" dir="ltr">${esc(bodyTxt)}</pre>` : `<div class="fl-md md">${mdHtml(bodyTxt)}</div>`;
    let content = '';
    if (why) content += `<div class="fl-rwhy ${cls}" dir="${textDir(why)}">${esc(why)}</div>`;
    if (bodyHtml) content += `<div class="fl-rtext${open || !hasMore ? '' : ' clamp'}">${bodyHtml}</div>`;
    else if (!why && lastInfo) content += `<div class="fl-rtext dim" dir="${textDir(lastInfo.text)}">${esc(lastInfo.text)}</div>`;
    else if (!why && live) content += '<div class="fl-rtext dim">רץ עכשיו…</div>';
    return `<div class="fl-row st-${cls}${live ? ' cur' : ''}${open ? ' open' : ''}" data-k="${k}" data-act="row-toggle">
      <span class="fl-ric">${ic}</span>
      <div class="fl-rbody">
        <div class="fl-r1"><b class="fl-rname" dir="${textDir(row.name)}">${esc(row.name)}</b>${badges}${dur}</div>
        ${content}
        ${open && plain.length ? `<div class="fl-rinfos">${plain.map(i => `<div dir="${textDir(i.text)}">${esc(i.text)}</div>`).join('')}</div>` : ''}
        ${retries.map(i => `<div class="fl-rretry" dir="rtl">${i.kind === 'resume' ? '⟲' : '↻'} ${esc(i.text)}</div>`).join('')}
        ${route}
        ${hasMore ? `<button type="button" class="fl-rmore" data-act="row-toggle-btn">${open ? '▴ כווץ' : '▾ הצג הכול'}</button>` : ''}
      </div></div>`;
  }
  // חלק עליון של הרצה + ציר הזמן + סיכום — משותף לחלונית ולחלון התזרים
  function runInnerHtml(r, o = {}) {
    const openSet = o.openSet || S.runOpen;
    const live = r.status === 'running';
    const rows = buildRows(r), lastIdx = rows.length - 1;
    const dur = (r.endedAt || Date.now()) - r.startedAt;
    const retryWait = live && r.retryAt && r.retryAt > Date.now();
    let h = `<div class="fl-runtop" data-status="${r.status}">
      <div class="fl-runtop-r1"><span class="fl-chip big st-${r.status}" ${o.win ? '' : 'id="flRunStatus"'} data-r="status">${live ? '<span class="fl-spin"></span>' : ST[r.status].ic} ${ST[r.status].txt}</span>
        <span class="fl-clock" ${live ? `data-fl-since="${r.startedAt}"` : ''}>${live ? clk(dur) : esc(App.fmt.dur(dur))}</span>
        ${live ? `<button type="button" class="fl-btn danger" ${o.win ? 'data-act="w-stop"' : 'id="flRunStop" data-act="stop-run"'} ${o.busyStop ? 'disabled' : ''}><i class="fl-sq"></i> ${o.busyStop ? 'עוצר…' : 'עצור'}</button>` : ''}</div>
      <div class="fl-runmeta">התחיל ${esc(App.fmt.dateTime(r.startedAt))} · ${esc(r.trigger === 'schedule' ? 'תזמון' : r.trigger === 'chat' ? 'מהשיחה' : 'ידני')} · ${r.stepNo || 0} ביצועים${r.transient ? ` · ${r.transient} תקלות זמניות שטופלו` : ''}${r.resumed ? ` · המשיך ${r.resumed} פעמים אחרי הפעלה מחדש של השרת` : ''}</div>
      ${retryWait ? `<div class="fl-retrybar">↻ תקלה זמנית — השלב ירוץ שוב בעוד <span class="fl-clock" data-fl-until="${r.retryAt}">${clk(r.retryAt - Date.now())}</span></div>` : ''}
      <div class="fl-runstrip" dir="ltr">${(r.steps || []).map((s, i) => { const state = (live && r.stepId === s.id) ? 'cur' : (rows.some(x => x.stepId === s.id && x.outcome === 'ok') ? 'ok' : rows.some(x => x.stepId === s.id && (x.outcome === 'fail' || x.outcome === 'timeout')) ? 'bad' : ''); return `<span class="fl-sn t-${s.type} ${state}" title="${esc(`${i + 1}. ${s.name}`)}">${i + 1}</span>`; }).join('<span class="fl-sa">→</span>')}</div>
      ${r.convId ? `<button type="button" class="fl-btn" data-act="${o.win ? 'w-chat-run' : 'open-chat'}" ${o.win ? '' : 'id="flOpenChat"'}>💬 פתח את השיחה</button>` : ''}
    </div>`;
    if (r.logTrimmed) h += '<div class="fl-note small">ההרצה ארוכה — מוצגים הביצועים האחרונים.</div>';
    h += `<div class="fl-tl" ${o.win ? 'data-r="timeline"' : 'id="flTimeline"'}>${rows.length ? rows.map((row, k) => rowHtml(row, k, r, k === lastIdx, openSet)).join('') : '<div class="fl-note">עוד לא התחיל שלב…</div>'}</div>`;
    if (!live) h += `<div class="fl-final st-${r.status}" ${o.win ? 'data-r="final"' : 'id="flFinal"'}><b>${ST[r.status].ic} ${ST[r.status].txt}</b><span dir="${textDir(r.reason)}">${esc(r.reason || '')}</span></div>`;
    return h;
  }

  function renderRun() {
    const b = body(); if (!b || S.view !== 'run') return;
    const r = S.run;
    let h = `<div class="fl-root fl-run"><div class="fl-head"><button type="button" class="fl-back" data-act="back" title="חזרה לרשימה">→</button><div class="fl-title">${r ? esc(r.flowName) : 'הרצה'}</div>${r ? `<button type="button" class="fl-btn icon" data-act="run-win" title="פתח את חלון התזרים המלא">🗗</button>` : ''}</div>`;
    if (!r) { h += S.runErr ? `<div class="fl-note">${esc(S.runErr)}</div>` : '<div class="fl-note">טוען…</div>'; b.innerHTML = h + '</div>'; return; }
    h += runInnerHtml(r, { busyStop: S.runBusyStop });
    const hist = S.runs.filter(x => x.flowId === r.flowId);
    if (hist.length > 1) {
      h += `<section class="fl-sec"><h4 class="fl-sec-h">הרצות אחרונות <span class="fl-gc">${hist.length}</span></h4><div class="fl-hist" id="flHist">${hist.slice(0, 12).map(x => histRowHtml(x, x.id === r.id, 'hist')).join('')}</div></section>`;
    }
    h += '</div>';
    const st0 = b.scrollTop;
    b.innerHTML = h;
    b.scrollTop = st0;
  }
  const histRowHtml = (x, on, act) => `<button type="button" class="fl-hrow${on ? ' on' : ''}" data-act="${act}" data-rid="${esc(x.id)}"><span class="fl-hic st-${x.status}">${ST[x.status] ? ST[x.status].ic : '•'}</span><span class="fl-ht">${esc(ago(x.startedAt))}</span><span class="fl-hd">${esc(x.status === 'running' ? 'רץ' : App.fmt.dur((x.endedAt || Date.now()) - x.startedAt))}</span><span class="fl-hr" dir="${textDir(x.reason)}">${esc(clip(x.reason || (ST[x.status] || {}).txt || '', 70))}</span></button>`;

  // ============================================================
  //  5) אירועי לחיצה / הקלדה (האצלה אחת על #flowsBody)
  // ============================================================
  // פעולות העורך (משותפות לחלונית ולחלון התזרים — S.E הוא העורך הפעיל). מחזיר true אם טופל
  function editorAction(act, a) {
    if (!S.E) return false;
    switch (act) {
      case 'add': addStep(); return true;
      case 'ins': addStep(Number(a.dataset.at)); return true;
      case 'allow': { // כלים מותרים בשלב (אכיפה בהוק)
        const sc = a.closest('.fl-step'); if (!sc) return true; const st = S.E.flow.steps[Number(sc.dataset.i)]; if (!st) return true;
        const v = a.dataset.allow; st.allow = Array.isArray(st.allow) ? st.allow : []; st.allow = st.allow.includes(v) ? st.allow.filter(x => x !== v) : [...st.allow, v];
        editorTouch(); renderSteps(); return true;
      }
      case 'up': case 'down': case 'del': case 'toggle': {
        const sc = a.closest('.fl-step'); if (!sc) return true; const i = Number(sc.dataset.i);
        if (act === 'up') moveStep(i, -1); else if (act === 'down') moveStep(i, 1); else if (act === 'del') deleteStep(i);
        else { const id = S.E.flow.steps[i].id; if (S.E.collapsed.has(id)) S.E.collapsed.delete(id); else S.E.collapsed.add(id); S.E.bad.delete(i); renderSteps(); }
        return true;
      }
      case 'goto-step': { const i = Number(a.dataset.i), st = S.E.flow.steps[i]; if (!st) return true; S.E.collapsed.delete(st.id); renderSteps(); const c = eq('flSteps').querySelector(`.fl-step[data-i="${i}"]`); if (c) c.scrollIntoView({ block: 'center', behavior: 'smooth' }); return true; }
    }
    return false;
  }
  function onClick(e) {
    const body0 = body(); if (!body0) return;
    const a = e.target.closest('[data-act]');
    if (!a || !body0.contains(a)) {
      // לחיצה על הכרטיס עצמו (לא על כפתור) = חלון התזרים הגדול עם כל המידע והעריכה
      const card = e.target.closest('.fl-card');
      if (card && !e.target.closest('button,input,label,select')) cardOpen(card.dataset.id);
      return;
    }
    const act = a.dataset.act, card = a.closest('.fl-card'), f = card ? flowById(card.dataset.id) : null;
    if (S.view === 'editor' && editorAction(act, a)) return;
    switch (act) {
      case 'new': openEditor(null); break;
      case 'gen': openGen(); break;
      case 'tpl': openTemplate(a.dataset.tpl); break;
      case 'reload': load(); break;
      case 'pend-open': if (S.pending) { const p = S.pending; S.pending = null; openEditor(null, p); } break;
      case 'run': if (f) startFlow(f); break;
      case 'edit': if (f) openEditor(f.id); break;
      case 'more': if (f) moreMenu(f, a); break;
      case 'stop-card': if (f) { const r = activeRunOf(f.id); if (r) stopRun(r.id); } break;
      case 'open-run': if (f) openLatestRun(f); break;          // 👁 צפה בהרצה — ההרצה שלב אחרי שלב
      case 'steps': if (f) showStepsPopup(f); break;            // 🧩 N שלבים — הגדרת השלבים שירוצו
      case 'chat': if (f) openFlowChat(f); break;               // 💬 שיחה — השיחה שהתזרים רץ בה
      case 'back': goBack(); break;
      case 'gen-go': { const ta = $('flGoal'); generate(ta ? ta.value : S.gen.goal); break; }
      case 'save': saveEditor(false); break;
      case 'save-run': saveEditor(true); break;
      case 'stop-run': if (S.run && S.run.status === 'running') { S.runBusyStop = true; renderRun(); stopRun(S.run.id).then(() => fetchRun(true)); } break;
      case 'open-chat': if (S.run && S.run.convId) { try { App.chats.openConversation(S.run.convId); } catch (er) { App.toast(er.message); } } break;
      case 'run-win': if (S.run) openFlowWindow(S.run.flowId, { tab: 'run' }); break;
      case 'hist': openRun(a.dataset.rid); break;
      case 'row-toggle': case 'row-toggle-btn': {
        if (e.target.closest('a,.path-link,.copy-code')) break;
        if (window.getSelection && String(window.getSelection()).length) break;
        const row = a.closest('.fl-row'); if (!row || !S.run) break;
        const k = S.run.id + ':' + row.dataset.k; if (S.runOpen.has(k)) S.runOpen.delete(k); else S.runOpen.add(k); renderRun(); break;
      }
    }
  }
  function cardOpen(fid) { return openFlowWindow(fid); }
  function onInputEv(e) {
    const t = e.target;
    if (!t.dataset || !t.dataset.f) return;
    if (t.dataset.f === 'showAll') { if (e.type !== 'change') return; S.showAll = t.checked; ls.set('fl.showAll', t.checked ? '1' : '0'); S.sig = ''; renderList(); return; }
    if (t.dataset.f === 'goal') { S.gen.goal = t.value; return; }
    if (S.view === 'editor') onEditorInput(e);
  }
  function onKey(e) {
    if (S.view === 'gen' && e.target.id === 'flGoal' && e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); generate(e.target.value); }
    if (S.view === 'editor' && e.key === 'Enter' && e.target.matches && e.target.matches('input.fl-in')) e.preventDefault();
  }

  // ============================================================
  //  6) חשיפה + אתחול
  // ============================================================
  App.flows = {
    refresh: () => load(),
    openEditor: (id, o) => openEditor(id, o),
    openRun, openGen, generate, openTemplate, openWindow: (id, o) => openFlowWindow(id, o), showSteps: id => { const f = flowById(id); return f ? showStepsPopup(f) : null; }, openChat: id => { const f = flowById(id); return f ? openFlowChat(f) : false; }, setLock: (id, on) => setLock(id, on), mdHtml,
    start: async (id, convId) => { const f = flowById(id) || (await App.api('/api/flows/' + id)).flow; return startFlow(f, convId, true); },
    stop: rid => stopRun(rid),
    list: () => S.flows.slice(), activeRuns: () => S.active.slice(),
    _debug: { S, TPLS, wins: () => S.wins }
  };

  App.on('chat:activated', () => { if (S.view === 'list') { S.sig = ''; renderList(); } });
  App.on('project:activated', () => { if (S.view === 'list') { S.sig = ''; renderList(); } });
  App.on('view:shown', name => { if (name === 'flows') { load(); if (S.view === 'run') fetchRun(false); tickClocks(); } });

  App.ready(() => {
    const b = body(); if (!b) return;
    b.addEventListener('click', onClick);
    b.addEventListener('input', onInputEv);
    b.addEventListener('change', onInputEv);
    b.addEventListener('keydown', onKey);
    setTools();
    renderList();
    load();
    schedulePoll();
    setInterval(tickClocks, 1000);
  });
})();
