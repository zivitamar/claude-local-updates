// ============================================================
//  managers-ui.js — 🧭 מנהל עבודה בממשק:
//   • דיאלוג "הרכב מנהל" (על תיקייה קיימת, או שהמנהל בונה תיקייה משלו): מטרה, דדליין (לא חובה), כמה עובדים
//   • פס מצב בראש הצ'אט של המנהל: סטטוס, X/Y פריטים מוכחים, עובדים, קירות, ⏸ / ▶ / דדליין
//   • תגים ברשימת השיחות: 🧭 מנהל · 👷 עובד (של מנהל)
// ============================================================
(function () {
  const App = window.App, el = App.el, esc = App.esc;
  const ST = { running: ['▶', 'עובד'], paused: ['⏸', 'מושהה'], stopped: ['⏹', 'נעצר'], done: ['🏁', 'הוכח והסתיים'], deadline: ['⏰', 'הגיע הדדליין'] };

  async function dialog({ projectId, folderId, folderName, convId } = {}) {
    const box = el('div', 'mg-form');
    box.innerHTML = `<label class="mg-f"><span>מה המנהל צריך להביא לסיום? (המטרה)</span><textarea class="text-input mg-goal" rows="5" placeholder="לדוגמה: לבנות אתר הזמנות עם תשלום, בדיקות ודף ניהול — מוכח שעובד"></textarea></label>
      <div class="mg-row"><label class="mg-f"><span>כמה עובדים (צ'אטים) לכל היותר</span><select class="text-input mg-w"><option value="1">1</option><option value="2">2</option><option value="3" selected>3</option></select></label>
      <label class="mg-f"><span>דדליין בשעות (ריק = עד שהכל מוכח)</span><input class="text-input mg-dl" type="number" min="0" step="0.5" dir="ltr" placeholder="ללא"></label></div>
      <div class="mg-note">🧭 המנהל עובד לבד בלולאה עד שהכל <b>מוכח</b> (פקודות שהשרת מריץ). הוא פותח מעט עובדים, יוצא למחקר כשיש קיר, ולא שואל אותך שאלות.</div>`;
    const go = el('button', 'btn-primary', '🧭 הפעל מנהל');
    const m = App.modal({ title: convId ? '🧭 הפוך את השיחה למנהל עבודה' : folderId ? '🧭 הרכב מנהל על התיקייה' : '🧭 מנהל עבודה חדש', body: box, cls: 'mg-modal' });
    m.body.appendChild(go);
    go.onclick = async () => {
      const goal = box.querySelector('.mg-goal').value.trim(); if (!goal) { App.toast('כתוב מטרה'); return; }
      go.disabled = true; go.textContent = 'מפעיל…';
      try {
        const r = await App.api('/api/managers', { method: 'POST', body: { convId: convId || null, projectId: projectId || (App.projects && App.projects.activeId()), folderId: folderId || null, folderName, goal, maxWorkers: Number(box.querySelector('.mg-w').value), deadlineHours: Number(box.querySelector('.mg-dl').value) || 0 } });
        m.close(); App.toast('🧭 המנהל ' + r.code + ' התחיל לעבוד', 3500);
        if (App.projects) { await App.projects.reload(); App.chats.openConversation(r.id); }
      } catch (e) { App.toast('❌ ' + e.message, 5000); go.disabled = false; go.textContent = '🧭 הפעל מנהל'; }
    };
    setTimeout(() => box.querySelector('.mg-goal').focus(), 50);
  }

  // ----- status bar at the top of the manager's chat -----
  const docks = new Map(); // convId → element
  function paintDock(d, s) {
    const [ic, lbl] = ST[s.status] || ['•', s.status];
    const workers = (s.workers || []).map(w => `<span class="mg-wk${w.running ? ' run' : ''}" data-id="${esc(w.id)}" title="${esc(w.title)}">👷 ${esc(w.code)}</span>`).join('') || '<span class="mg-dim">אין עובדים עדיין</span>';
    const pct = s.total ? Math.round(s.proven / s.total * 100) : 0;
    d.innerHTML = `<div class="mg-top"><b class="mg-st st-${esc(s.status)}">${ic} ${esc(lbl)}</b><span class="mg-prog"><i style="width:${pct}%"></i></span><span class="mg-n">${s.proven}/${s.total} מוכחים</span>
      <span class="mg-sp"></span>${s.deadline ? `<span class="mg-dim">⏰ ${new Date(s.deadline).toLocaleString('he-IL', { hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'numeric' })}</span>` : ''}
      <button class="btn-ghost mg-tg" type="button">${s.status === 'running' ? '⏸ השהה' : '▶ המשך'}</button><button class="btn-ghost mg-more" type="button" title="תוכנית, קירות ויומן">▾</button></div>
      <div class="mg-wks">${workers}${(s.walls || []).length ? `<span class="mg-wall">🧱 ${s.walls.length} קירות → מחקר</span>` : ''}</div>
      <div class="mg-det" hidden><div class="mg-goal-t">🎯 ${esc(s.goal)}</div>${(s.plan || []).map(p => `<div class="mg-it ${esc(p.status)}">${p.status === 'proven' ? '✅' : p.status === 'failing' ? '❌' : '⬜'} <b>${esc(p.id)}</b> ${esc(p.text)}</div>`).join('') || '<div class="mg-dim">עוד אין תוכנית</div>'}
      ${(s.walls || []).map(w => `<div class="mg-it wall">🧱 ${esc(w.what)} ×${w.count}</div>`).join('')}
      <div class="mg-log">${(s.log || []).slice(-8).reverse().map(l => `<div><span class="mg-dim">${new Date(l.at).toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' })}</span> ${esc(l.text)}</div>`).join('')}</div></div>`;
    d.querySelector('.mg-tg').onclick = async () => { try { await App.api('/api/managers/' + s.id + '/status', { method: 'POST', body: { status: s.status === 'running' ? 'paused' : 'running' } }); refresh(s.id); } catch (e) { App.toast('❌ ' + e.message); } };
    d.querySelector('.mg-more').onclick = () => { const x = d.querySelector('.mg-det'); x.hidden = !x.hidden; d._open = !x.hidden; };
    if (d._open) d.querySelector('.mg-det').hidden = false;
    d.querySelectorAll('.mg-wk').forEach(w => (w.onclick = () => App.chats.openConversation(w.dataset.id)));
  }
  async function refresh(id) { const d = docks.get(id); if (!d || !d.isConnected) { docks.delete(id); return; } try { const r = await App.api('/api/managers/' + id); paintDock(d, r.manager); } catch { } }
  function attach(chat, tries = 0) {
    if (!chat || !chat.pane) return;
    if (!chat.loaded && tries < 25) { setTimeout(() => attach(chat, tries + 1), 300); return; }
    if (chat.role !== 'manager' || !chat.id) return;
    let d = chat.pane.querySelector('.mg-dock');
    if (!d) { d = el('div', 'mg-dock'); const bar = chat.pane.querySelector('.pane-bar'); bar.parentNode.insertBefore(d, bar.nextSibling); }
    docks.set(chat.id, d); refresh(chat.id);
  }
  App.on('chat:activated', ({ chat }) => setTimeout(() => attach(chat), 50));
  App.on('chat:updated', () => { const c = App.chats && App.chats.active(); if (c) attach(c); });
  App.on('manager', s => { if (s && docks.has(s.id)) { const d = docks.get(s.id); if (d.isConnected) paintDock(d, s); } });
  App.ready(() => { try { const es = App._events; } catch { } });
  // a row badge (projects.js calls it for every chat row)
  App.managerBadge = c => c.role === 'manager' ? `<span class="mg-badge" title="מנהל עבודה">🧭${c.mgr && c.mgr.total ? ' ' + c.mgr.proven + '/' + c.mgr.total : ''}</span>` : c.managedBy && !c.released ? '<span class="mg-badge wk" title="עובד של מנהל">👷</span>' : '';
  App.managers = { dialog, refresh };
})();
