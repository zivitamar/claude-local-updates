// ============================================================
//  mobile.js — phone layout of the SAME app (docs/mobile/03-design-plan.md).
//  Active when the window is narrow (≤ 600px) or ?m=1. One screen at a time:
//   chat  — the open chat (#chatstack)            list  — a right-panel view (chats / research / flows / watches / agents)
//   files — the explorer / Claude view (#sidepanel)
//  Top bar: ☰ more · project chip (colour + name ▾) · machine chip · usage.  Bottom nav: שיחות · קבצים · מחקרים · תזרים · עוד.
//  Every change pushes a history entry, so the phone's Back goes back one screen.
// ============================================================
(function () {
  const App = window.App;
  const q = new URLSearchParams(location.search);
  const want = () => q.get('m') === '1' || (q.get('m') !== '0' && window.matchMedia('(max-width: 600px)').matches);
  const root = document.documentElement;
  if (!want()) { App.mobile = { on: false }; return; }
  root.classList.add('m');

  const $ = id => document.getElementById(id);
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const TABS = [
    { id: 'chats', ic: '💬', lbl: 'שיחות' },
    { id: 'explorer', ic: '📁', lbl: 'קבצים' },
    { id: 'research', ic: '🔬', lbl: 'מחקרים' },
    { id: 'flows', ic: '⚙', lbl: 'תזרים' },
    { id: 'more', ic: '☰', lbl: 'עוד' }
  ];
  const S = { screen: 'list', view: 'chats' };

  // ---------- screens ----------
  function apply() {
    root.dataset.mscreen = S.screen;
    root.dataset.mview = S.view;
    document.querySelectorAll('.mnav-btn').forEach(b => b.classList.toggle('on', S.screen !== 'chat' && b.dataset.t === navOf(S.view)));
    const t = $('mTitle'); if (t) t.textContent = titleOf();
  }
  const navOf = v => (['chats', 'explorer', 'research', 'flows'].includes(v) ? v : 'more');
  function titleOf() {
    if (S.screen === 'chat') { const c = App.chats && App.chats.active(); const t = c && c.pane && c.pane.querySelector('.pt-text'); return (t && t.textContent.trim()) || 'שיחה'; }
    return { chats: 'שיחות', explorer: 'קבצים', claude: 'Claude', research: 'מחקרים', flows: 'תזרים', watches: 'מעקבים', agents: 'סוכנים' }[S.view] || '';
  }
  function go(screen, view, { push = true } = {}) {
    if (screen === S.screen && (view || S.view) === S.view) { apply(); return; }
    S.screen = screen; if (view) S.view = view;
    if (screen !== 'chat') {
      if (['explorer', 'claude'].includes(S.view)) { App.view.show(S.view); }
      else { App.view.split = false; App.view.show(S.view); }
    }
    if (push) history.pushState({ m: 1, screen: S.screen, view: S.view }, '');
    apply();
  }
  window.addEventListener('popstate', e => {
    const st = e.state;
    if (closeSheet()) { history.pushState({ m: 1, screen: S.screen, view: S.view }, ''); return; } // Back closes an open sheet first
    // then an open window (settings page → settings list → closed; research / flow / any dialog → closed)
    const pops = document.querySelectorAll('.ctrl-pop:not([hidden])'); if (pops.length) { pops.forEach(p => { p.hidden = true; }); return; }
    const mpn = document.querySelector('.mediapanel:not([hidden])'); if (mpn) { const x = mpn.querySelector('.mp-close'); if (x) x.click(); return; }
    const bks = document.querySelectorAll('.modal-backdrop');
    if (bks.length) {
      const top = bks[bks.length - 1];
      const sw = top.querySelector('.settings-modal .st-wrap.m-page, .st-wrap.m-page');
      if (sw) { settingsMode(sw, 'menu'); history.pushState({ m: 1, screen: S.screen, view: S.view, modal: 1 }, ''); return; }
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }));
      if (top.isConnected) top.remove();
      return;
    }
    if (st && st.m) go(st.screen, st.view, { push: false }); else go('list', 'chats', { push: false });
  });

  // ---------- bottom sheet ----------
  let sheet = null;
  function closeSheet() { if (!sheet) return false; sheet.remove(); sheet = null; return true; }
  function openSheet(title, build) {
    closeSheet();
    sheet = el('div', 'msheet-wrap');
    const back = el('div', 'msheet-back'); back.onclick = closeSheet;
    const box = el('div', 'msheet'); box.setAttribute('role', 'dialog');
    box.appendChild(el('div', 'msheet-grip'));
    if (title) box.appendChild(el('div', 'msheet-title', esc(title)));
    const body = el('div', 'msheet-body'); box.appendChild(body); build(body);
    sheet.append(back, box); document.body.appendChild(sheet);
    // old WebViews resolve vh to 0 → size in real pixels from the window
    { const H = window.innerHeight || document.documentElement.clientHeight || 600; box.style.setProperty('max-height', Math.round(H * 0.82) + 'px', 'important'); body.style.setProperty('max-height', Math.max(120, Math.round(H * 0.82) - 64) + 'px', 'important'); }
    return body;
  }
  const row = (ic, label, sub, onClick, cls = '') => { const b = el('button', 'mrow ' + cls); b.type = 'button'; b.innerHTML = `<span class="mrow-ic">${ic}</span><span class="mrow-t"><b>${esc(label)}</b>${sub ? `<small>${esc(sub)}</small>` : ''}</span>`; b.onclick = onClick; return b; };

  // ---------- project picker ----------
  function projectSheet() {
    openSheet('פרויקטים', body => {
      const list = App.projects ? App.projects.list() : [];
      const act = App.projects && App.projects.activeId();
      for (const p of list) {
        const chats = App.projects.chatsOf(p.id) || [];
        const run = chats.filter(c => c.running).length, done = chats.filter(c => !c.running && c.unseen).length;
        const b = row('<i class="mproj-dot"></i>', p.name || 'פרויקט', chats.length + ' שיחות' + (run ? ` · ${run} עובדות` : '') + (done ? ` · ${done} חדשות` : ''), () => { closeSheet(); App.projects.activate(p.id); go('list', 'chats'); }, 'mproj' + (p.id === act ? ' on' : ''));
        if (/^#[0-9a-f]{6}$/i.test(p.color || '')) b.style.setProperty('--pc', p.color);
        if (run) b.classList.add('run'); else if (done) b.classList.add('done');
        body.appendChild(b);
      }
      body.appendChild(row('＋', 'פרויקט חדש', 'תיקייה + השיחות שעובדות עליה', () => { closeSheet(); $('newTabBtn').click(); }, 'madd'));
    });
  }
  // ---------- "what's working now": every project + its chats, green = working, orange = finished (not seen) ----------
  function activeSheet() {
    openSheet('מה עובד עכשיו', body => {
      const list = App.projects ? App.projects.list() : []; let any = 0;
      for (const p of list) {
        const chats = (App.projects.chatsOf(p.id) || []).filter(c => c.running || c.unseen);
        if (!chats.length) continue; any++;
        body.appendChild(el('div', 'mact-h', esc(p.name || 'פרויקט') + ` · ${chats.filter(c => c.running).length} עובדות`));
        for (const c of chats.sort((a, b) => (b.running ? 1 : 0) - (a.running ? 1 : 0))) {
          const r = row(`<i class="mact-dot ${c.running ? 'run' : 'done'}"></i>`, c.title || 'שיחה', c.running ? '● עובד עכשיו' : '✓ סיים — לא נקרא', () => { closeSheet(); App.projects.activate(p.id); App.chats.openConversation(c.id); go('chat'); }, 'mact ' + (c.running ? 'run' : 'done'));
          body.appendChild(r);
        }
      }
      if (!any) body.appendChild(el('div', 'mempty', 'אין כרגע צ\'אטים שעובדים או שסיימו ולא נקראו'));
    });
  }
  // ---------- machine picker ----------
  function machineSheet() {
    openSheet('מחשבים', body => {
      const M = App.mesh; const ms0 = M ? M.machines() : []; const pm = /\/m\/([0-9a-f]{16})\//.exec(location.pathname); const sid = (M && M.selfId && M.selfId()) || (window.MESH && MESH.remote) || (pm && pm[1]); const ms = sid && !ms0.some(x => x.id === sid) ? [{ id: sid, online: true, self: true, displayName: (App.state && App.state.hostname) || 'המחשב' }].concat(ms0) : ms0;
      const cur = M && M.current(); const curId = cur && typeof cur === 'object' ? cur.id : cur;
      if (!ms.length) body.appendChild(el('div', 'mempty', 'אין מחשבים ברשת'));
      for (const m of ms) {
        const r = row(M.iconOf ? M.iconOf(m) : '🖥', (m.self ? m.displayName : M.nameOf(m.id)), (m.online ? '● מחובר' : '○ לא מחובר') + (m.summary && m.summary.run ? ` · ${m.summary.run} עובדות` : ''), () => { closeSheet(); M.switchTo(m.id); }, (curId === m.id ? 'on' : '') + (m.online ? '' : ' off'));
        body.appendChild(r);
      }
    });
  }
  // ---------- "more" ----------
  function moreSheet() {
    openSheet('עוד', body => {
      body.appendChild(row('🧭', 'מנהל עבודה חדש', 'מנהל שמביא פרויקט עד הוכחה, לבד', () => { closeSheet(); App.managers && App.managers.dialog({}); }));
      body.appendChild(row('⏱', 'מעקבים', 'משימות קבועות ש-Claude מבצע לבד', () => { closeSheet(); go('list', 'watches'); }));
      body.appendChild(row('🤖', 'סוכנים', 'הסוכנים שרצים עכשיו', () => { closeSheet(); go('list', 'agents'); }));
      body.appendChild(row('🖥', 'מחשבים', 'מעבר בין המחשבים שלך', () => { closeSheet(); machineSheet(); }));
      body.appendChild(row('✳', 'Claude', 'חשבון, שימוש ומודלים', () => { closeSheet(); go('list', 'claude'); }));
      body.appendChild(row('👤', 'חשבון', 'מנוי, חשבונות ומפתחות', () => { closeSheet(); App.settings.open('account'); }));
      body.appendChild(row('⚙️', 'הגדרות', 'כל ההגדרות', () => { closeSheet(); App.settings.open('general'); }));
      body.appendChild(row('📥', 'ייבוא מ-VS Code', 'פתח כאן צ\'אט מ-VS Code', () => { closeSheet(); $('vscodeImportBtn').click(); }));
      body.appendChild(row('🎨', 'ערכת נושא', 'צבעים ותצוגה', () => { closeSheet(); App.settings.open('theme'); }));
    });
  }

  // ---------- build the chrome ----------
  // 1vh in real pixels (old WebViews resolve vh to 0)
  const setVh = () => { const H = window.innerHeight || document.documentElement.clientHeight; if (H) document.documentElement.style.setProperty('--vh1', (H / 100) + 'px'); };
  setVh(); window.addEventListener('resize', setVh);
  function build() {
    const top = el('div', 'mtop'); top.id = 'mTop';
    top.innerHTML = `<button class="mtop-back" id="mBack" aria-label="חזרה">‹</button>
      <button class="mtop-proj" id="mProj"><i class="mproj-dot"></i><span id="mProjName">כללי</span><b>▾</b></button>
      <span class="mtop-title" id="mTitle"></span>
      <button class="mtop-act" id="mAct" aria-label="מה עובד עכשיו"><i class="mact-dot"></i><span id="mActN">0</span></button>
      <button class="mtop-mach" id="mMach" aria-label="מחשב"><span id="mMachIc">🖥</span><span id="mMachName"></span></button>
      <button class="mtop-use" id="mUse" aria-label="שימוש"><span id="mUseTxt">—</span></button>`;
    document.body.insertBefore(top, $('app'));
    const nav = el('nav', 'mnav'); nav.id = 'mNav';
    for (const t of TABS) {
      const b = el('button', 'mnav-btn', `<span class="mnav-ic">${t.ic}</span><span class="mnav-l">${t.lbl}</span><i class="mnav-badge" hidden></i>`);
      b.dataset.t = t.id; b.type = 'button';
      b.onclick = () => { closeSheet(); if (t.id === 'more') moreSheet(); else go('list', t.id); };
      nav.appendChild(b);
    }
    document.body.appendChild(nav);
    $('mBack').onclick = () => history.back();
    // chat screen: the title is the chat's name; a tap renames it (like the desktop pane title)
    $('mTitle').onclick = () => { if (S.screen !== 'chat') return; const c = App.chats.active(); const b = c && c.pane && c.pane.querySelector('.pane-title'); if (b) b.click(); };
    new MutationObserver(() => { if (S.screen === 'chat') apply(); }).observe($('chatstack'), { subtree: true, characterData: true, childList: true, attributeFilter: ['class'] });
    $('mProj').onclick = projectSheet; $('mAct').onclick = activeSheet; syncActive(); setInterval(syncActive, 2000);
    $('mMach').onclick = machineSheet;
    $('mUse').onclick = () => App.settings.open('usage');
    // FAB: new chat on the chats list
    const fab = el('button', 'mfab', '＋'); fab.id = 'mFab'; fab.type = 'button'; fab.setAttribute('aria-label', 'שיחה חדשה');
    fab.onclick = () => { App.chats.newChat({ focus: true }); };
    document.body.appendChild(fab);
  }

  function syncActive() {
    const b = $('mAct'); if (!b || !App.projects) return; let run = 0, done = 0;
    for (const p of App.projects.list()) for (const c of App.projects.chatsOf(p.id) || []) { if (c.running) run++; else if (c.unseen) done++; }
    $('mActN').textContent = run || done ? String(run || done) : '0'; b.className = 'mtop-act' + (run ? ' run' : done ? ' done' : '');
  }
  function syncProject() {
    const p = App.projects && App.projects.active && App.projects.active();
    const n = $('mProjName'); if (!n) return;
    n.textContent = (p && p.name) || 'כללי';
    const b = $('mProj'); if (p && /^#[0-9a-f]{6}$/i.test(p.color || '')) b.style.setProperty('--pc', p.color); else b.style.removeProperty('--pc');
  }
  function syncMachine() {
    const M = App.mesh; const c0 = M && M.current && M.current(); const m = c0 && typeof c0 === 'object' ? c0 : (M && M.machines ? M.machines().find(x => x.id === c0) : null);
    const b = $('mMach'); if (!b) return;
    const many = M && M.machines && M.machines().length > 1;
    b.hidden = !many;
    if (m) { $('mMachIc').textContent = M.iconOf ? M.iconOf(m) : '🖥'; $('mMachName').textContent = M.nameOf(m.id); }
  }
  function syncUsage() {
    const l = $('budgetLabel'), u = $('mUseTxt'); if (!l || !u) return;
    const m = (l.textContent || '').match(/(\d+)%/); u.textContent = m ? m[1] + '%' : '—';
    const f = $('budgetFill'); if (f) $('mUse').style.setProperty('--use', f.style.width || '0%');
  }
  function syncBadges() {
    const map = { research: 'actResearchBadge', flows: 'actFlowsBadge' };
    for (const [t, id] of Object.entries(map)) { const src = $(id), b = document.querySelector(`.mnav-btn[data-t="${t}"] .mnav-badge`); if (src && b) { b.hidden = src.hidden; b.textContent = src.textContent; } }
  }

  // ---------- settings: a list of pages with names → tap → the page, with "‹ הגדרות" back ----------
  function settingsMode(wrap, mode) {
    wrap.classList.toggle('m-menu', mode === 'menu'); wrap.classList.toggle('m-page', mode === 'page');
    const modalEl = wrap.closest('.modal'); if (!modalEl) return;
    let bk = modalEl.querySelector('.m-st-back');
    if (!bk) { bk = el('button', 'm-st-back', '‹ הגדרות'); bk.type = 'button'; bk.onclick = () => settingsMode(wrap, 'menu'); const h = modalEl.querySelector('.modal-head'); if (h) h.insertBefore(bk, h.firstChild); }
    bk.hidden = mode !== 'page';
    const t = modalEl.querySelector('.modal-head h2');
    if (t) t.textContent = mode === 'page' ? ((wrap.querySelector('.st-tab.active') || {}).textContent || '').trim() : '⚙️ הגדרות';
  }
  function patchSettings() {
    const orig = App.settings && App.settings.open; if (!orig || orig._m) return;
    const open = function (tab) {
      const r = orig.apply(this, arguments);
      setTimeout(() => {
        const wrap = document.querySelector('.settings-modal .st-wrap'); if (!wrap) return;
        if (!wrap._m) { wrap._m = 1; wrap.querySelector('.st-nav').addEventListener('click', e => { if (e.target.closest('.st-tab')) setTimeout(() => settingsMode(wrap, 'page'), 0); }); }
        settingsMode(wrap, !tab || tab === 'general' ? 'menu' : 'page');
      }, 0);
      return r;
    };
    open._m = 1; App.settings.open = open;
  }

  // ---------- every desktop menu (right-click, ⋯, ＋) = a bottom sheet; sub-menus open inside it with ‹ back ----------
  function sheetMenu(items, title) {
    const body = openSheet(title || '', b => fill(b, items, null));
    function fill(b, list, back) {
      b.innerHTML = '';
      if (back) { const bk = row('‹', 'חזרה', '', () => fill(b, back.items, back.back), 'mback'); b.appendChild(bk); }
      for (const it of (list || []).filter(Boolean)) {
        if (it.sep) { b.appendChild(el('div', 'msep')); continue; }
        if (it.el) { b.appendChild(it.el); continue; }
        const label = (it.label || '') + (it.name != null ? ' ' + it.name : '');
        const r = row(it.icon || '', label, it.sub || it.hint || '', () => {
          if (it.disabled) return;
          if (it.children) { const kids = typeof it.children === 'function' ? it.children() : it.children; fill(b, kids && kids.length ? kids : [{ label: it.empty || 'אין', disabled: true }], { items: list, back }); return; }
          closeSheet(); if (it.onClick) it.onClick();
        }, (it.danger ? 'danger' : '') + (it.disabled ? ' off' : '') + (it.children ? ' mparent' : ''));
        if (it.color) { const t = r.querySelector('.mrow-t b'); if (t) t.style.color = it.color; }
        r.disabled = !!it.disabled; b.appendChild(r);
      }
    }
    return body;
  }
  // every window that opens adds a history entry, so the phone's Back closes it
  function patchModal() {
    const orig = App.modal; if (!orig || orig._m) return;
    const wrapped = function (o) { const r = orig.apply(this, arguments); try { history.pushState({ m: 1, screen: S.screen, view: S.view, modal: 1 }, ''); } catch { } return r; };
    wrapped._m = 1; App.modal = wrapped;
  }
  // files: one tap opens a file (desktop = double click); the file panel gets a history entry so Back closes it
  function tapFiles() {
    document.addEventListener('click', e => {
      const row = e.target.closest('#explorerBody .fx-row[data-kind="file"]');
      if (!row || e.target.closest('.fx-edit') || !row.dataset.path) return;
      setTimeout(() => App.explorer && App.explorer.openFile(row.dataset.path), 0);
    });
    // composer popups: a history entry while open (Back closes), and a dimmed page behind them
    const syncPop = () => { const open = !!document.querySelector('.ctrl-pop:not([hidden])'); root.classList.toggle('m-pop', open); if (open && !syncPop.h) { syncPop.h = 1; history.pushState({ m: 1, screen: S.screen, view: S.view, modal: 1 }, ''); } else if (!open) syncPop.h = 0; };
    new MutationObserver(syncPop).observe(document.body, { subtree: true, attributes: true, attributeFilter: ['hidden'] });
    const mp = () => document.querySelector('.mediapanel');
    new MutationObserver(() => { const p = mp(); if (p && !p.hidden && !p._h) { p._h = 1; history.pushState({ m: 1, screen: S.screen, view: S.view, modal: 1 }, ''); } else if (p && p.hidden) p._h = 0; })
      .observe(document.body, { subtree: true, attributes: true, attributeFilter: ['hidden'], childList: true });
  }
  function patchMenus() {
    App.menu = (x, y, items) => { sheetMenu(items); return sheet; };
    App.menuClose = () => { closeSheet(); };
  }
  // long-press (550 ms, finger still) = right-click: the element's own contextmenu handler runs → its menu opens as a sheet
  function longPress() {
    let t = null, sx = 0, sy = 0, fired = 0;
    document.addEventListener('touchstart', e => {
      if (e.touches.length !== 1) return; const p = e.touches[0]; sx = p.clientX; sy = p.clientY; const tg = e.target;
      clearTimeout(t); t = setTimeout(() => { fired = Date.now(); try { navigator.vibrate && navigator.vibrate(15); } catch { } tg.dispatchEvent(new MouseEvent('contextmenu', { bubbles: true, cancelable: true, clientX: sx, clientY: sy })); }, 550);
    }, { passive: true });
    const cancel = () => clearTimeout(t);
    document.addEventListener('touchmove', e => { const p = e.touches[0]; if (Math.abs(p.clientX - sx) > 10 || Math.abs(p.clientY - sy) > 10) cancel(); }, { passive: true });
    document.addEventListener('touchend', e => { cancel(); if (Date.now() - fired < 700) { e.preventDefault(); } }, { passive: false });
    document.addEventListener('contextmenu', e => { if (e.isTrusted && Date.now() - fired < 900) { e.preventDefault(); e.stopImmediatePropagation(); } }, true); // the native one after ours
    document.addEventListener('click', e => { if (Date.now() - fired < 700) { e.preventDefault(); e.stopPropagation(); } }, true); // no tap after a long-press
  }

  // the phone's own Back button (FullModeScreen asks the page first): one step back inside the app; false = nothing left
  function backStep() {
    if (closeSheet()) return true;
    const pops = document.querySelectorAll('.ctrl-pop:not([hidden])'); if (pops.length) { pops.forEach(p => { p.hidden = true; }); return true; }
    const mpn = document.querySelector('.mediapanel:not([hidden])'); if (mpn) { const x = mpn.querySelector('.mp-close'); if (x) { x.click(); return true; } }
    const bks = document.querySelectorAll('.modal-backdrop');
    if (bks.length) {
      const top = bks[bks.length - 1];
      const sw = top.querySelector('.st-wrap.m-page'); if (sw) { settingsMode(sw, 'menu'); return true; }
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }));
      if (top.isConnected) top.remove();
      return true;
    }
    if (S.screen === 'chat') { go('list', S.view); return true; }
    if (S.view !== 'chats') { go('list', 'chats'); return true; }
    return false;
  }
  window.__phoneBack = () => { try { return backStep(); } catch (e) { return false; } };

  App.mobile = { on: true, sheetMenu, go, state: S, openSheet, closeSheet, projectSheet, machineSheet, moreSheet, activeSheet };

  App.ready(() => {
    build(); patchModal(); patchSettings(); patchMenus(); longPress(); tapFiles();
    // opening a chat (from the list, a new chat, a link) → chat screen
    // only a chat the user opened (a tap in the last 2.5 s) switches screens — not the chat the app restores at startup
    let lastTap = 0; for (const ev of ['pointerdown', 'click', 'keydown']) document.addEventListener(ev, () => { lastTap = Date.now(); }, true);
    App.on('chat:activated', () => { if (S.screen === 'chat') apply(); else if (Date.now() - lastTap < 2500) go('chat'); });
    App.on('chat:created', () => { if (Date.now() - lastTap < 2500) go('chat'); });
    App.on('projects:changed', syncProject); App.on('tabs:render', syncProject); App.on('projects:ready', syncProject);
    App.on('mesh:changed', syncMachine);
    App.on('usage:data', syncUsage); App.on('usage:changed', syncUsage);
    App.on('chat:updated', () => { if (S.screen === 'chat') apply(); });
    new MutationObserver(syncBadges).observe($('rightpanel'), { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['hidden'] });
    new MutationObserver(syncUsage).observe($('budgetWrap'), { subtree: true, childList: true, characterData: true, attributes: true });
    // the start screen is the chats list (desktop restores the last open chat — on the phone the list comes first)
    history.replaceState({ m: 1, screen: 'list', view: 'chats' }, '');
    S.screen = ''; go('list', 'chats', { push: false });
    setTimeout(() => { syncProject(); syncMachine(); syncUsage(); syncBadges(); }, 300);
  });
})();
