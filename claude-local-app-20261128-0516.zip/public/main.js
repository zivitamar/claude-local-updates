// ============================================================
//  main.js — אתחול: טעינת הגדרות/מודלים, מעבר בין חלוניות צד, שינוי רוחב, גרירה, קיצורי מקלדת
// ============================================================
(function () {
  const App = window.App, $ = App.$;

  // ---------- שני צדדים: שמאל (קבצים/שיחות) וימין (סוכנים/מחקר). כל צד נסגר ונפתח, והבחירה נשמרת ----------
  const LEFT = ['explorer', 'claude'], RIGHT = ['chats', 'agents', 'research', 'flows', 'watches'];
  const ls = { get: k => { try { return localStorage.getItem(k); } catch { return null; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch { } } };
  App.view = {
    current: 'explorer', rightCurrent: 'chats', split: false,
    // show('explorer'|'chats') — צד שמאל;  show('agents'|'research') — צד ימין. toggle=true: לחיצה שנייה על אותה לשונית סוגרת
    show(name, { toggle = false } = {}) {
      if (!document.querySelector(`.view[data-view="${name}"]`)) return;
      if (RIGHT.includes(name)) {
        const panel = $('rightpanel');
        if (toggle && this.rightCurrent === name && !panel.classList.contains('collapsed')) { this.setRight(false); return; }
        this.rightCurrent = name; ls.set('rview', name);
        document.querySelectorAll('.rp-tab').forEach(b => b.classList.toggle('active', b.dataset.view === name));
        const at = document.querySelector('.rp-tab.active'); if (at && at.scrollIntoView) at.scrollIntoView({ inline: 'nearest', block: 'nearest' });
        this._layoutRight();
        this.setRight(true);
      } else {
        const panel = $('sidepanel');
        if (toggle && this.current === name && !panel.classList.contains('collapsed')) { this.setLeft(false); return; }
        this.current = name; ls.set('view', name);
        document.querySelectorAll('#sidepanel .view').forEach(v => (v.hidden = v.dataset.view !== name));
        this.setLeft(true);
      }
      App.emit('view:shown', name);
    },
    // מצב רגיל: לשונית אחת. מצב מפוצל: שיחות למעלה, והלשונית הנבחרת (סוכנים/מחקר) למטה, עם מפריד שגוררים
    _layoutRight() {
      const name = this.rightCurrent, split = this.split;
      const views = [...document.querySelectorAll('#rightpanel .view')];
      views.forEach(v => { const n = v.dataset.view; v.hidden = split ? !(n === 'chats' || n === (name === 'chats' ? 'agents' : name)) : n !== name; v.style.flex = ''; });
      $('hsplitter').hidden = !split;
      $('rightpanel').classList.toggle('split', split);
      $('splitRight').classList.toggle('on', split);
      if (split) { const r = Number(ls.get('hsplit')) || 0.55; $('view-chats').style.flex = `${r} 1 0`; const other = views.find(v => !v.hidden && v.dataset.view !== 'chats'); if (other) other.style.flex = `${1 - r} 1 0`; }
    },
    setSplit(on) { this.split = !!on; ls.set('split', on ? '1' : '0'); this._layoutRight(); },
    setLeft(open) { $('sidepanel').classList.toggle('collapsed', !open); ls.set('leftOpen', open ? '1' : '0'); this._sync(); if (open) App.emit('view:shown', this.current); },
    setRight(open) { $('rightpanel').classList.toggle('collapsed', !open); ls.set('rightOpen', open ? '1' : '0'); this._sync(); if (open) App.emit('view:shown', this.rightCurrent); },
    _sync() {
      const lc = $('sidepanel').classList.contains('collapsed'), rc = $('rightpanel').classList.contains('collapsed');
      document.querySelectorAll('.act-btn[data-view]').forEach(b => b.classList.toggle('active', !lc && b.dataset.view === App.view.current));
      $('splitter').hidden = lc; $('rsplitter').hidden = rc;
      $('toggleLeft').classList.toggle('on', !lc); $('toggleRight').classList.toggle('on', !rc);
    }
  };

  function bindShell() {
    document.querySelectorAll('.act-btn[data-view]').forEach(b => (b.onclick = () => App.view.show(b.dataset.view, { toggle: true })));
    document.querySelectorAll('.rp-tab').forEach(b => (b.onclick = () => App.view.show(b.dataset.view)));
    $('toggleLeft').onclick = () => App.view.setLeft($('sidepanel').classList.contains('collapsed'));
    $('toggleRight').onclick = () => App.view.setRight($('rightpanel').classList.contains('collapsed'));
    $('closeRight').onclick = () => App.view.setRight(false);
    // שורות כפתורים שנחתכות כשהחלונית צרה: גלגלת העכבר גוללת אותן הצידה
    for (const e of [$('rpTabs'), $('explorerTools')]) if (e) e.addEventListener('wheel', ev => { if (ev.deltaY && e.scrollWidth > e.clientWidth) { e.scrollLeft += ev.deltaY; ev.preventDefault(); } }, { passive: false });
    $('splitRight').onclick = () => App.view.setSplit(!App.view.split);
    $('hsplitter').addEventListener('mousedown', e => {
      e.preventDefault(); const sp = $('hsplitter'); sp.classList.add('drag'); const panel = $('rightpanel');
      const move = ev => { const r = panel.getBoundingClientRect(); const head = panel.querySelector('.rp-head').offsetHeight; const ratio = Math.max(.15, Math.min(.85, (ev.clientY - r.top - head) / (r.height - head))); ls.set('hsplit', ratio); App.view._layoutRight(); };
      const up = () => { sp.classList.remove('drag'); window.removeEventListener('mousemove', move); window.removeEventListener('mouseup', up); };
      window.addEventListener('mousemove', move); window.addEventListener('mouseup', up);
    });
    $('actSettings').onclick = () => App.settings && App.settings.open('general');
    $('actAccount').onclick = () => App.settings && App.settings.open('account');
    $('accountBadge').onclick = () => App.settings && App.settings.open('account');
    $('budgetWrap').onclick = () => App.settings && App.settings.open('usage');

    // רוחב החלוניות (נשמר)
    const resizer = (splitter, panel, key, side) => {
      const w = Number(ls.get(key)); if (w >= 190) panel.style.width = w + 'px';
      splitter.addEventListener('mousedown', e => {
        e.preventDefault(); splitter.classList.add('drag');
        const move = ev => { const r = $('workspace').getBoundingClientRect(); const nw = side === 'left' ? ev.clientX - r.left - 56 : r.right - ev.clientX; panel.style.width = Math.max(190, Math.min(window.innerWidth * 0.55, nw)) + 'px'; };
        const up = () => { splitter.classList.remove('drag'); ls.set(key, parseInt(panel.style.width, 10) || 300); window.removeEventListener('mousemove', move); window.removeEventListener('mouseup', up); };
        window.addEventListener('mousemove', move); window.addEventListener('mouseup', up);
      });
    };
    resizer($('splitter'), $('sidepanel'), 'sidepanelW', 'left');
    resizer($('rsplitter'), $('rightpanel'), 'rightpanelW', 'right');

    // גרירת קבצים/תיקיות לחלון: כל ה-handlers ב-App.dropHandlers (explorer.js קודם, chat.js אחריו)
    let depth = 0;
    const overlay = $('dropOverlay'), dropText = $('dropText');
    const hide = () => { depth = 0; overlay.hidden = true; };
    window.addEventListener('dragenter', e => {
      const types = [...(e.dataTransfer.types || [])];
      if (!types.includes('Files') && !types.includes('application/x-claude-path')) return;
      depth++; overlay.hidden = false;
      dropText.textContent = types.includes('application/x-claude-path') ? '📎 שחרר כאן' : '📂 שחרר כאן';
    });
    window.addEventListener('dragleave', () => { if (--depth <= 0) hide(); });
    window.addEventListener('dragover', e => e.preventDefault());
    window.addEventListener('drop', async e => {
      e.preventDefault(); hide();
      // ה-DataTransfer נעלם אחרי await: מצלמים את הקבצים והפריטים מיד
      const dt = e.dataTransfer;
      const snap = { files: [...(dt.files || [])], items: [...(dt.items || [])].map(it => ({ kind: it.kind, type: it.type, entry: it.webkitGetAsEntry ? it.webkitGetAsEntry() : null, file: it.kind === 'file' ? it.getAsFile() : null })), types: [...(dt.types || [])], getData: t => { try { return dt.getData(t); } catch { return ''; } }, raw: dt };
      snap.pathData = snap.getData('application/x-claude-path');
      snap.textData = snap.getData('text/plain');
      await App.dispatchDrop(snap, { target: e.target });
    });

    // קיצורי מקלדת כלליים
    document.addEventListener('keydown', e => {
      if (e.ctrlKey && !e.shiftKey && !e.altKey && e.key.toLowerCase() === 'b') { e.preventDefault(); $('toggleLeft').click(); }
      else if (e.ctrlKey && e.altKey && e.key.toLowerCase() === 'b') { e.preventDefault(); $('toggleRight').click(); }
      else if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'e') { e.preventDefault(); App.view.show('explorer'); }
      else if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'o') { e.preventDefault(); App.chats && App.chats.newChat({ focus: true }); }
      else if (e.ctrlKey && !e.shiftKey && e.key.toLowerCase() === 't') { e.preventDefault(); App.chats && App.chats.newChat({ focus: true }); }
      else if (e.ctrlKey && !e.shiftKey && e.key.toLowerCase() === 'w') { const pid = App.projects && App.projects.activeId(); if (pid) { e.preventDefault(); App.projects.closeTab(pid); } }
      else if (e.ctrlKey && e.key === 'Tab') { e.preventDefault(); App.chats && App.chats.cycle(e.shiftKey ? -1 : 1); }
      else if (e.ctrlKey && e.key === ',') { e.preventDefault(); App.settings && App.settings.open('general'); }
    });
  }

  // ---------- אתחול ----------
  async function boot() {
    if (location.protocol === 'file:') {
      document.body.innerHTML = '<div style="padding:40px;text-align:center;font-size:18px">פתחת את הקובץ ישירות. הפעל את התוכנה (Claude מקומי) או גלוש אל <b>http://localhost:3456</b></div>';
      return;
    }
    bindShell();
    try { await App.loadConfig(); }
    catch (e) { document.body.innerHTML = '<div style="padding:40px;text-align:center;font-size:18px">השרת לא עונה. הפעל את התוכנה מחדש.</div>'; return; }
    App.api('/api/system').then(s => { App.state.system = s; }).catch(() => { });
    const sv = ls.get('view'), rv = ls.get('rview');
    App.view.show(LEFT.includes(sv) ? sv : 'explorer');
    App.view.split = ls.get('split') === '1';
    App.view.show(RIGHT.includes(rv) ? rv : 'chats');
    App.view.setLeft(ls.get('leftOpen') !== '0');
    App.view.setRight(ls.get('rightOpen') !== '0'); // הימנית פתוחה כברירת מחדל (שיחות)
    App._fireReady(); // chat.js / explorer.js / agents.js / settings.js / usage.js מתחילים כאן
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
