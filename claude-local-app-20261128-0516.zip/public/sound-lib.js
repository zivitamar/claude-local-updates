// ============================================================
//  sound-lib.js — ספריית צלילים מסונתזים (WebAudio, בלי קבצים). כל צליל = מתכון של תווים ורעש.
//  SOUND_LIB.list = [{id, name, cat, tags}] · SOUND_LIB.play(ctx, out, id, when, vol) → משך בשניות
//  note: f תדר · t התחלה · d משך · w צורת גל · v עוצמה · to גלישה לתדר · h הרמוניות [[כפולה,עוצמה]] · a התקפה · vib ויברטו
//  noise: t · d · v · hp/lp/bp מסנן · sweep (תדר סיום של bp)
// ============================================================
(function () {
  const N = (f, t, d, o) => Object.assign({ f, t, d }, o || {});
  const BELL = [[1, 1], [2.01, 0.28], [3.98, 0.1]], GLASS = [[1, 1], [2.76, 0.35], [5.4, 0.12]], MARIMBA = [[1, 1], [4, 0.18], [10, 0.04]], KAL = [[1, 1], [2.7, 0.22], [6.1, 0.08]];
  const C4 = 261.63, D4 = 293.66, E4 = 329.63, F4 = 349.23, G4 = 392, A4 = 440, B4 = 493.88, C5 = 523.25, D5 = 587.33, E5 = 659.25, F5 = 698.46, G5 = 783.99, A5 = 880, B5 = 987.77, C6 = 1046.5, E6 = 1318.5, G6 = 1568;
  const up = (notes, step, d, o) => notes.map((f, i) => N(f, i * step, d, o));
  const R = [];
  const add = (id, name, cat, tags, notes, noise) => R.push({ id, name, cat, tags: tags || '', notes: notes || [], noise: noise || [] });
  // ---------- פעמונים ---------- (bell3 = הצליל המקורי של "Claude סיים")
  add('bell3', 'פעמון שלושה צלילים (המקורי)', 'פעמונים', 'סיום finish chime', [N(E5, 0, 1.1, { h: BELL, v: .22 }), N(G5, .14, 1.1, { h: BELL, v: .22 }), N(C6, .28, 1.5, { h: BELL, v: .26 })]);
  add('bell', 'פעמון יחיד', 'פעמונים', 'ding', [N(A5, 0, 1.4, { h: BELL, v: .28 })]);
  add('bell-low', 'פעמון נמוך', 'פעמונים', 'church', [N(E4, 0, 2.2, { h: [[1, 1], [2.4, .4], [3.9, .2], [5.2, .1]], v: .3 })]);
  add('chime-up', 'צלצול עולה', 'פעמונים', 'up', up([C5, E5, G5, C6], .1, 1, { h: BELL, v: .18 }));
  add('chime-down', 'צלצול יורד', 'פעמונים', 'down end', up([C6, G5, E5, C5], .1, 1, { h: BELL, v: .18 }));
  add('glass', 'זכוכית', 'פעמונים', 'crystal', [N(1760, 0, 1.3, { h: GLASS, v: .16 })]);
  add('glass2', 'שתי כוסות', 'פעמונים', 'crystal', [N(1568, 0, 1, { h: GLASS, v: .14 }), N(2093, .12, 1.2, { h: GLASS, v: .14 })]);
  add('gong', 'גונג', 'פעמונים', 'gong', [N(98, 0, 3, { h: [[1, 1], [1.48, .6], [2.3, .4], [3.1, .25], [4.4, .12]], v: .35, a: .02 })]);
  add('bowl', 'קערה טיבטית', 'פעמונים', 'meditation', [N(420, 0, 3.2, { h: [[1, 1], [2.68, .5], [4.9, .2]], v: .22, a: .015, vib: [4, 2] })]);
  add('doorbell', 'פעמון דלת', 'פעמונים', 'ding dong', [N(E5, 0, .9, { h: BELL, v: .25 }), N(C5, .38, 1.3, { h: BELL, v: .25 })]);
  add('elevator', 'מעלית', 'פעמונים', 'lift ding', [N(1046.5, 0, 1.6, { h: [[1, 1], [2, .2]], v: .2 })]);
  add('wind', 'פעמוני רוח', 'פעמונים', 'wind chimes', up([2093, 1760, 2637, 1975, 2349, 1568], .09, 1.4, { h: GLASS, v: .07 }));
  // ---------- קצרים ----------
  add('pop', 'פופ', 'קצרים', 'bubble', [N(600, 0, .09, { to: 1400, v: .3 })]);
  add('click', 'קליק', 'קצרים', 'tap', [], [{ t: 0, d: .018, v: .45, hp: 2500 }]);
  add('tick', 'טיק', 'קצרים', 'clock', [N(2000, 0, .03, { w: 'square', v: .06 })]);
  add('tock', 'טוק', 'קצרים', 'clock', [N(900, 0, .05, { w: 'triangle', v: .25 })]);
  add('blip', 'בליפ', 'קצרים', 'beep', [N(880, 0, .08, { w: 'square', v: .07 })]);
  add('blip-high', 'בליפ גבוה', 'קצרים', 'beep', [N(1760, 0, .06, { w: 'square', v: .06 })]);
  add('beep2', 'שני ביפים', 'קצרים', 'beep double', [N(1000, 0, .07, { w: 'square', v: .06 }), N(1000, .11, .07, { w: 'square', v: .06 })]);
  add('bloop', 'בלופ', 'קצרים', 'water', [N(300, 0, .14, { to: 120, v: .35 })]);
  add('drop', 'טיפה', 'קצרים', 'drip water', [N(1400, 0, .18, { to: 380, v: .3 })]);
  add('bubble', 'בועה', 'קצרים', 'water', [N(320, 0, .12, { to: 950, v: .3 })]);
  add('pluck', 'פריטה', 'קצרים', 'string', [N(G4, 0, .35, { w: 'triangle', v: .3, h: [[1, 1], [2, .3]] })]);
  add('wood', 'בלוק עץ', 'קצרים', 'woodblock', [N(820, 0, .07, { w: 'triangle', v: .4 })]);
  add('wood2', 'שני בלוקי עץ', 'קצרים', 'woodblock', [N(820, 0, .07, { w: 'triangle', v: .4 }), N(620, .1, .07, { w: 'triangle', v: .4 })]);
  add('cowbell', 'פעמון פרה', 'קצרים', 'cowbell', [N(540, 0, .3, { w: 'square', v: .05 }), N(800, 0, .3, { w: 'square', v: .05 })]);
  add('snap', 'נקישת אצבעות', 'קצרים', 'snap', [], [{ t: 0, d: .04, v: .5, bp: 2500 }]);
  add('clap', 'מחיאת כף', 'קצרים', 'clap', [], [{ t: 0, d: .03, v: .5, bp: 1200 }, { t: .015, d: .06, v: .4, bp: 1100 }]);
  add('knock', 'דפיקה בדלת', 'קצרים', 'door knock approval', [N(150, 0, .08, { v: .5 }), N(150, .16, .08, { v: .5 })], [{ t: 0, d: .03, v: .2, lp: 900 }, { t: .16, d: .03, v: .2, lp: 900 }]);
  // ---------- הצלחה וסיום ----------
  add('success', 'הצלחה', 'הצלחה', 'done arpeggio', up([C5, E5, G5], .09, .5, { w: 'triangle', v: .22 }));
  add('fanfare', 'תרועה', 'הצלחה', 'research done', [N(G4, 0, .15, { w: 'triangle', v: .22 }), N(C5, .15, .15, { w: 'triangle', v: .22 }), N(E5, .3, .15, { w: 'triangle', v: .22 }), N(G5, .45, .6, { w: 'triangle', v: .26 })]);
  add('level-up', 'עלייה ברמה', 'הצלחה', '8bit game', up([C5, E5, G5, C6, E6], .06, .12, { w: 'square', v: .05 }));
  add('coin', 'מטבע', 'הצלחה', '8bit game', [N(B5, 0, .08, { w: 'square', v: .06 }), N(E6, .08, .35, { w: 'square', v: .06 })]);
  add('power-up', 'התעצמות', 'הצלחה', 'sweep up', [N(200, 0, .5, { to: 1600, w: 'sawtooth', v: .05 })]);
  add('sparkle', 'נצנוץ', 'הצלחה', 'magic', up([2093, 2637, 3136, 2637, 3520], .04, .3, { h: GLASS, v: .06 }));
  add('spark-up', 'ניצוץ עולה', 'הצלחה', 'agents start', up([E5, A5, E6], .05, .35, { h: GLASS, v: .1 }));
  add('harp', 'נבל', 'הצלחה', 'gliss', up([C5, D5, E5, G5, A5, C6, D5 * 2, E6], .045, .7, { w: 'triangle', v: .1 }));
  add('marimba-up', 'מרימבה עולה', 'הצלחה', 'marimba', up([G4, C5, E5], .11, .5, { h: MARIMBA, v: .3 }));
  add('piano-major', 'אקורד מז\'ור', 'הצלחה', 'chord', [N(C4, 0, 1.4, { h: [[1, 1], [2, .4], [3, .2]], v: .12 }), N(E4, 0, 1.4, { h: [[1, 1], [2, .4]], v: .12 }), N(G4, 0, 1.4, { h: [[1, 1], [2, .4]], v: .12 }), N(C5, 0, 1.4, { v: .1 })]);
  add('happy', 'שמח', 'הצלחה', 'two up ok', [N(G5, 0, .2, { w: 'triangle', v: .22 }), N(C6, .12, .35, { w: 'triangle', v: .22 })]);
  add('done-soft', 'סיום רך', 'הצלחה', 'soft', [N(A4, 0, .5, { v: .2 }), N(E5, .12, .7, { v: .18 })]);
  add('jingle', 'ג\'ינגל', 'הצלחה', 'melody', [N(E5, 0, .15, { h: BELL, v: .15 }), N(E5, .16, .15, { h: BELL, v: .15 }), N(G5, .32, .15, { h: BELL, v: .15 }), N(E5, .48, .15, { h: BELL, v: .15 }), N(C6, .64, .6, { h: BELL, v: .18 })]);
  add('xylophone', 'קסילופון', 'הצלחה', 'xylo', up([C6, E6, G6], .08, .4, { h: MARIMBA, v: .18 }));
  add('kalimba', 'קלימבה', 'הצלחה', 'kalimba', up([G5, B5, D5 * 2], .1, .8, { h: KAL, v: .2 }));
  // ---------- התראות, אזהרות ושגיאות ----------
  add('alert', 'התראה', 'אזהרות', 'notice', [N(880, 0, .12, { v: .25 }), N(880, .18, .12, { v: .25 })]);
  add('alert-urgent', 'התראה דחופה', 'אזהרות', 'urgent', [N(1046, 0, .08, { w: 'square', v: .07 }), N(1046, .12, .08, { w: 'square', v: .07 }), N(1046, .24, .08, { w: 'square', v: .07 })]);
  add('warning-tone', 'טון אזהרה', 'אזהרות', 'warn', [N(660, 0, .18, { w: 'triangle', v: .25 }), N(440, .2, .3, { w: 'triangle', v: .25 })]);
  add('buzz', 'זמזום', 'אזהרות', 'error', [N(110, 0, .35, { w: 'sawtooth', v: .12 })]);
  add('buzz-soft', 'זמזום רך', 'אזהרות', 'error soft', [N(220, 0, .3, { w: 'square', v: .05, lp: 900 }), N(196, .18, .35, { w: 'square', v: .05, lp: 900 })]);
  add('down2', 'שני צלילים יורדים', 'אזהרות', 'stop down', [N(G5, 0, .18, { w: 'triangle', v: .22 }), N(C5, .16, .35, { w: 'triangle', v: .22 })]);
  add('sad', 'עצוב', 'אזהרות', 'refused minor fail', [N(E5, 0, .25, { w: 'triangle', v: .2 }), N(C5, .22, .25, { w: 'triangle', v: .2 }), N(A4, .44, .6, { w: 'triangle', v: .22 })]);
  add('blocked', 'חסום', 'אזהרות', 'denied', [N(300, 0, .12, { w: 'square', v: .06 }), N(250, .14, .2, { w: 'square', v: .06 })]);
  add('error-8bit', 'שגיאה 8 ביט', 'אזהרות', 'game error', [N(400, 0, .1, { w: 'square', v: .06 }), N(300, .1, .1, { w: 'square', v: .06 }), N(200, .2, .25, { w: 'square', v: .06 })]);
  add('siren', 'סירנה', 'אזהרות', 'siren', [N(600, 0, .4, { to: 1200, w: 'triangle', v: .15 }), N(1200, .4, .4, { to: 600, w: 'triangle', v: .15 })]);
  add('alarm', 'אזעקה', 'אזהרות', 'alarm', up([1200, 900, 1200, 900, 1200, 900], .09, .08, { w: 'square', v: .05 }));
  add('question', 'שאלה', 'אזהרות', 'ask hmm', [N(E5, 0, .16, { w: 'triangle', v: .22 }), N(A5, .16, .3, { w: 'triangle', v: .22, to: B5 })]);
  add('sonar', 'סונאר', 'אזהרות', 'ping radar', [N(1046, 0, 1.2, { v: .22, h: [[1, 1], [2, .1]] }), N(1046, .45, .9, { v: .06 })]);
  add('radar', 'מכ"ם', 'אזהרות', 'radar watch', [N(1400, 0, .06, { v: .2 }), N(1400, .5, .06, { v: .12 })]);
  // ---------- מכני וטכנולוגי ----------
  add('typewriter', 'מכונת כתיבה', 'מכני', 'type keys', [N(2600, .2, .6, { h: BELL, v: .12 })], [{ t: 0, d: .02, v: .4, hp: 1800 }, { t: .08, d: .02, v: .35, hp: 1800 }, { t: .15, d: .02, v: .38, hp: 1800 }]);
  add('keyboard', 'מקלדת', 'מכני', 'typing keys', [], [{ t: 0, d: .015, v: .3, hp: 2200 }, { t: .07, d: .015, v: .28, hp: 2200 }, { t: .13, d: .015, v: .3, hp: 2200 }, { t: .2, d: .015, v: .26, hp: 2200 }]);
  add('camera', 'צמצם מצלמה', 'מכני', 'screenshot shutter png', [N(3000, 0, .02, { w: 'square', v: .04 })], [{ t: 0, d: .05, v: .5, bp: 3000 }, { t: .09, d: .06, v: .45, bp: 2200 }]);
  add('laser', 'לייזר', 'מכני', 'zap', [N(1500, 0, .25, { to: 200, w: 'square', v: .05 })]);
  add('zap', 'זאפ', 'מכני', 'electric', [N(800, 0, .12, { to: 60, w: 'sawtooth', v: .08 })]);
  add('whoosh', 'וושש', 'מכני', 'swoosh air', [], [{ t: 0, d: .45, v: .35, bp: 600, sweep: 3000 }]);
  add('swoosh-up', 'סווש עולה', 'מכני', 'swoosh', [], [{ t: 0, d: .35, v: .3, bp: 400, sweep: 4000 }]);
  add('swoosh-down', 'סווש יורד', 'מכני', 'swoosh', [], [{ t: 0, d: .35, v: .3, bp: 4000, sweep: 400 }]);
  add('robot', 'רובוט', 'מכני', 'beeps', up([700, 1100, 600, 1300], .07, .06, { w: 'square', v: .05 }));
  add('scanner', 'סורק', 'מכני', 'scan', [N(400, 0, .3, { to: 1600, v: .15 }), N(1600, .3, .3, { to: 400, v: .15 })]);
  add('tick-tock', 'טיק-טוק', 'מכני', 'clock', [N(2000, 0, .03, { w: 'square', v: .05 }), N(1500, .25, .03, { w: 'square', v: .05 })]);
  add('drip', 'טפטוף', 'מכני', 'water', [N(1200, 0, .1, { to: 500, v: .25 }), N(1300, .22, .1, { to: 550, v: .2 })]);
  add('water', 'מים', 'מכני', 'bubbles', up([400, 520, 460, 600], .07, .09, { to: 900, v: .15 }));
  // ---------- מוזיקלי ----------
  add('marimba', 'מרימבה', 'מוזיקלי', 'note', [N(C5, 0, .6, { h: MARIMBA, v: .32 })]);
  add('flute', 'חליל', 'מוזיקלי', 'note', [N(A5, 0, .7, { v: .18, a: .025, vib: [5, 6] })]);
  add('organ', 'עוגב', 'מוזיקלי', 'chord', [N(C4, 0, 1.1, { h: [[1, 1], [2, .5], [3, .3], [4, .2]], v: .07, a: .015 }), N(G4, 0, 1.1, { h: [[1, 1], [2, .5], [3, .3]], v: .07, a: .015 })]);
  add('bass', 'בס', 'מוזיקלי', 'low', [N(65, 0, .5, { w: 'triangle', v: .45 })]);
  add('pad', 'סינתי רך', 'מוזיקלי', 'pad', [N(C4, 0, 1.4, { w: 'sawtooth', v: .03, a: .05, lp: 1200 }), N(E4, 0, 1.4, { w: 'sawtooth', v: .03, a: .05, lp: 1200 }), N(G4, 0, 1.4, { w: 'sawtooth', v: .03, a: .05, lp: 1200 })]);
  add('minor-arp', 'ארפג\'ו מינורי', 'מוזיקלי', 'minor', up([A4, C5, E5, A5], .08, .5, { w: 'triangle', v: .15 }));
  add('guitar', 'גיטרה', 'מוזיקלי', 'strum', up([E4, G4 * 1.0, B4, E5], .025, 1, { w: 'triangle', v: .12, h: [[1, 1], [2, .4], [3, .2]] }));
  add('trumpet', 'חצוצרה', 'מוזיקלי', 'brass', [N(G4, 0, .18, { w: 'sawtooth', v: .05, lp: 2000 }), N(C5, .2, .45, { w: 'sawtooth', v: .06, lp: 2200 })]);

  const byId = Object.fromEntries(R.map(r => [r.id, r]));
  let noiseBuf = null;
  function noiseBuffer(ctx) { if (noiseBuf && noiseBuf.sampleRate === ctx.sampleRate) return noiseBuf; const n = ctx.sampleRate * 1; noiseBuf = ctx.createBuffer(1, n, ctx.sampleRate); const d = noiseBuf.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1; return noiseBuf; }
  function play(ctx, out, id, when, vol) {
    const r = byId[id]; if (!r) return 0; const t0 = when || ctx.currentTime; vol = vol == null ? 1 : vol; let end = 0;
    for (const n of r.notes) {
      const g = ctx.createGain(); let dest = g;
      if (n.lp) { const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = n.lp; g.connect(f); f.connect(out); } else g.connect(out);
      const s = t0 + n.t, a = n.a || 0.008, v = Math.max(0.0002, (n.v || .2) * vol);
      g.gain.setValueAtTime(0.0001, s); g.gain.exponentialRampToValueAtTime(v, s + a); g.gain.exponentialRampToValueAtTime(0.0001, s + n.d);
      for (const [mul, hv] of (n.h || [[1, 1]])) {
        const o = ctx.createOscillator(), og = ctx.createGain(); o.type = n.w || 'sine'; o.frequency.setValueAtTime(n.f * mul, s);
        if (n.to) o.frequency.exponentialRampToValueAtTime(n.to * mul, s + n.d * 0.9);
        if (n.vib) { const lfo = ctx.createOscillator(), lg = ctx.createGain(); lfo.frequency.value = n.vib[0]; lg.gain.value = n.vib[1]; lfo.connect(lg); lg.connect(o.frequency); lfo.start(s); lfo.stop(s + n.d + .05); }
        og.gain.value = hv; o.connect(og); og.connect(dest); o.start(s); o.stop(s + n.d + .05);
      }
      end = Math.max(end, n.t + n.d);
    }
    for (const z of r.noise) {
      const src = ctx.createBufferSource(); src.buffer = noiseBuffer(ctx); const g = ctx.createGain(); const s = t0 + z.t;
      let node = src;
      for (const [k, type] of [['hp', 'highpass'], ['lp', 'lowpass'], ['bp', 'bandpass']]) if (z[k]) { const f = ctx.createBiquadFilter(); f.type = type; f.frequency.setValueAtTime(z[k], s); if (z.sweep && k === 'bp') f.frequency.exponentialRampToValueAtTime(z.sweep, s + z.d); if (k === 'bp') f.Q.value = 1.2; node.connect(f); node = f; }
      node.connect(g); g.connect(out);
      g.gain.setValueAtTime(0.0001, s); g.gain.exponentialRampToValueAtTime(Math.max(0.0002, z.v * vol), s + Math.min(.01, z.d / 3)); g.gain.exponentialRampToValueAtTime(0.0001, s + z.d);
      src.start(s); src.stop(s + z.d + .02); end = Math.max(end, z.t + z.d);
    }
    return end;
  }
  const CATS = [...new Set(R.map(r => r.cat))];
  window.SOUND_LIB = { list: R.map(({ id, name, cat, tags }) => ({ id, name, cat, tags })), byId, cats: CATS, play };
})();
