// ============================================================
//  hub-ui.js — הגדרות › 🌐 חיבור מכל מקום: כפתור אחד "חבר Cloudflare".
//  נפתח דף הכניסה של Cloudflare → מאשרים → המרכזיה מותקנת בחשבון שלך לבד, וכל המכשירים שלך מקבלים אותה דרך הרשת המוצפנת.
//  אין מפתח להעתיק. (גיבוי למי שרוצה: הדבקת מפתח API ידנית, מוסתר תחת "מתקדם")
// ============================================================
(function () {
  const App = window.App, el = App.el, esc = App.esc;
  let poll = null;
  async function render(box) {
    const st = await App.api('/api/hub').catch(() => ({}));
    const sec = el('section', 'st-sec');
    sec.innerHTML = `<h3>🌐 חיבור מכל מקום</h3><div class="st-sub">הטלפון והמחשבים שלך מתחברים זה לזה מכל רשת — סלולרית, חו״ל, סים אחר — דרך "מרכזיה" קטנה בחשבון Cloudflare <b>שלך</b> (חינם). המידע מוצפן מקצה לקצה: Cloudflare לא יכול לקרוא אותו. מחברים פעם אחת, וכל המכשירים מקבלים את זה לבד.</div>`;
    const card = el('div', 'hub-card ' + (st.up ? 'on' : st.configured ? 'warn' : 'off'));
    card.innerHTML = st.configured
      ? `<b>${st.up ? '✅ מחובר' : '⏳ מתחבר…'}</b><div class="mg-dim" dir="ltr">${esc(st.url || '')}</div>${st.account ? `<div class="mg-dim">חשבון: ${esc(st.account)}</div>` : ''}<div>מכשירים על המרכזיה עכשיו: <b>${(st.peers || []).length}</b></div>`
      : '<b>○ עוד לא מחובר</b><div class="mg-dim">כרגע הטלפון מתחבר רק כשהוא באותה רשת עם המחשב.</div>';
    sec.appendChild(card);
    const go = el('button', 'btn-primary hub-go', st.configured ? '↻ חבר מחדש את Cloudflare' : '🌐 חבר Cloudflare'); go.type = 'button';
    const out = el('div', 'hub-out');
    const note = el('div', 'mg-dim', 'נפתח דפדפן: נכנסים לחשבון Cloudflare (או נרשמים חינם) ולוחצים "Allow". זהו — השאר קורה לבד.');
    go.onclick = async () => {
      go.disabled = true; go.textContent = 'ממתין לאישור בדפדפן…'; out.textContent = '';
      try { await App.api('/api/hub/connect', { method: 'POST', body: {} }); }
      catch (e) { out.innerHTML = '❌ ' + esc(e.message); go.disabled = false; go.textContent = '🌐 חבר Cloudflare'; return; }
      clearInterval(poll);
      poll = setInterval(async () => {
        if (!box.isConnected) { clearInterval(poll); return; }
        let l; try { l = await App.api('/api/hub/login'); } catch { return; }
        if (l.state === 'installing') go.textContent = 'מתקין את המרכזיה בחשבון שלך…';
        if (l.state === 'done') { clearInterval(poll); out.innerHTML = (l.steps || []).map(s => '✅ ' + esc(s)).join('<br>'); App.toast('🌐 מחובר! כל המכשירים שלך יתחברו דרך המרכזיה', 5000); setTimeout(() => App.settings.open('hub'), 1500); }
        if (l.state === 'error') { clearInterval(poll); out.innerHTML = '❌ ' + esc(l.error || 'נכשל'); go.disabled = false; go.textContent = '🌐 נסה שוב'; }
      }, 1500);
    };
    sec.append(go, note, out);
    // advanced: paste an API token instead
    const adv = el('details', 'hub-adv'); adv.innerHTML = '<summary>מתקדם: חיבור עם מפתח API</summary>';
    const row = el('div', 'row'); const inp = el('input', 'text-input'); inp.type = 'password'; inp.dir = 'ltr'; inp.placeholder = 'מפתח API של Cloudflare (Workers Scripts: Edit)'; inp.autocomplete = 'off';
    const ib = el('button', 'btn-ghost', 'התקן עם מפתח'); ib.type = 'button';
    ib.onclick = async () => { if (!inp.value.trim()) return; ib.disabled = true; try { const r = await App.api('/api/hub/install', { method: 'POST', body: { token: inp.value.trim() } }); inp.value = ''; out.innerHTML = r.steps.map(s => '✅ ' + esc(s)).join('<br>'); setTimeout(() => App.settings.open('hub'), 1500); } catch (e) { out.innerHTML = '❌ ' + esc(e.message); } ib.disabled = false; };
    row.append(inp, ib); adv.appendChild(row); sec.appendChild(adv);
    if (st.configured) { const rc = el('button', 'btn-ghost', '⟳ התחבר מחדש עכשיו'); rc.onclick = async () => { await App.api('/api/hub/reconnect', { method: 'POST', body: {} }); setTimeout(() => App.settings.open('hub'), 1200); }; sec.appendChild(rc); }
    box.appendChild(sec);
  }
  App.hubUI = { render };
})();
