// ============================================================
//  sound-catalog.js — כל האירועים שהמערכת מזהה לבד (בלי ש-Claude ינגן משהו) ואפשר לחבר אליהם צליל.
//  משותף לשרת (מיפוי אירוע → מפתח) ולממשק (שמות, קבוצות, משפט לקול, ברירות מחדל).
//  key: 'ev:*' אירוע · 'tool:*' כלי של Claude Code · 'cmd:*' סוג פקודה בתוך Bash · 'chrome:*' פעולה בכרום · 'pc:*' שליטה במחשב
//  def: { on, src } — ברירת המחדל של כל המערכת (לבקשת הבעלים): כל אירוע וכל פעולה דלוקים, ו-Claude "אומר" אותם
//  בקול גבר ברור (אסף) — לא צפצוף. syn = צליל מומלץ חלופי מהספרייה (לבחירה בבוחר הצלילים).
// ============================================================
(function (root) {
  const G = {
    status: '✅ סיום ומצב', research: '🔬 מחקר', agents: '🤖 סוכנים', watch: '⏱ מעקבים', flow: '⚙ תזרים',
    cmd: '💻 פקודות (Bash / PowerShell / CMD)', files: '📄 קבצים וחיפוש', web: '🌐 רשת', chrome: '🧭 Chrome שלך', pc: '🖥 שליטה במחשב',
    shot: '📸 צילומי מסך', claude: '✳ כלים של Claude', app: '💬 שיחות ותזרימים', other: '🔌 כלים חיצוניים (MCP)'
  };
  const E = (key, group, label, phrase, on, syn) => ({ key, group, label, phrase, alt: syn ? 'syn:' + syn : null, def: { on: true, src: 'voice' } });
  const EVENTS = [
    // ----- סיום ומצב -----
    E('ev:finish', 'status', 'Claude סיים לעבוד', 'סיימתי עבודה', true, 'bell3'),
    E('ev:stopped', 'status', 'Claude נעצר (עצרת אותו)', 'נעצר', false, 'down2'),
    E('ev:error', 'status', 'שגיאה בעבודה', 'שגיאה', true, 'buzz-soft'),
    E('ev:refused', 'status', 'Claude סירב / לא ביצע', 'קלוד סירב', true, 'sad'),
    E('ev:denied', 'status', 'פעולה נחסמה (תזרים / מגבלה)', 'הפעולה נחסמה', false, 'blocked'),
    E('ev:tool_error', 'status', 'כלי נכשל', 'הפעולה נכשלה', false, 'error-8bit'),
    E('ev:approval', 'status', 'מחכה לאישור שלך', 'מחכה לאישור שלך', true, 'knock'),
    E('ev:question', 'status', 'Claude שואל אותך שאלה', 'יש לי שאלה', true, 'question'),
    E('ev:queued', 'status', 'ההודעה שלך נכנסה לתור', 'ההודעה בתור', false, 'tick'),
    E('ev:compaction', 'status', 'מסכם שיחה ארוכה', 'מסכם את השיחה', false, 'whoosh'),
    E('ev:limit', 'status', 'מתקרב למגבלת המנוי — כל 10% מ-50% שנותרו', 'מתקרב למגבלת המנוי', true, 'alert'),
    // ----- מחקר -----
    E('ev:research_start', 'research', 'יוצא למחקר', 'יוצא למחקר', false, 'swoosh-up'),
    E('ev:research_stage', 'research', 'המחקר עבר לשלב הבא (חוקרים יצאו · כותב דוח)', 'המחקר עבר לשלב הבא', false, 'pluck'),
    E('ev:research_done', 'research', 'מחקר הסתיים', 'המחקר הסתיים', true, 'fanfare'),
    E('ev:research_refused', 'research', 'מחקר — Claude סירב', 'המחקר נדחה', true, 'sad'),
    E('ev:research_bg', 'research', 'Claude סיים לכתוב — מחקר עוד רץ ברקע', 'מחקר רץ ברקע, ממתין לתוצאה', true, 'tick'),
    // ----- סוכנים -----
    E('ev:agent_start', 'agents', 'Claude הפעיל סוכן', 'מפעיל סוכן', true, 'spark-up'),
    E('ev:agent_done', 'agents', 'סוכן סיים', 'סוכן סיים', false, 'done-soft'),
    // ----- מעקבים -----
    E('ev:watch_round', 'watch', 'בדיקת מעקב התחילה', 'בדיקת מעקב מתחילה', false, 'radar'),
    E('ev:watch_ok', 'watch', 'בדיקת מעקב הסתיימה — תקין', 'בדיקת המעקב הסתיימה, הכל תקין', false, 'happy'),
    E('ev:watch_warn', 'watch', 'בדיקת מעקב הסתיימה — נמצאה בעיה', 'בדיקת המעקב הסתיימה, נמצאה בעיה', true, 'warning-tone'),
    E('ev:watch_fixing', 'watch', 'מעקב — נמצאה בעיה, מתחיל תיקון (מצב תיקון)', 'בדיקת המעקב הסתיימה, נמצאה בעיה - מתחיל תיקון', true, 'warning-tone'),
    E('ev:watch_end', 'watch', 'המעקב כולו הסתיים / נעצר', 'המעקב הסתיים ונעצר', true, 'chime-down'),
    // ----- תזרים -----
    E('ev:flow_step', 'flow', 'שלב בתזרים הסתיים', 'התזרים עבר לשלב הבא', false, 'pluck'),
    E('ev:flow_done', 'flow', 'התזרים הסתיים', 'התזרים הסתיים', true, 'success'),
    // ----- פקודות -----
    E('tool:Bash', 'cmd', 'Bash — כל פקודה', 'בָּאשׁ'),
    E('tool:PowerShell', 'cmd', 'PowerShell (כלי)', 'פָּאוּאֶר שֶׁל'),
    E('cmd:powershell', 'cmd', 'PowerShell מתוך Bash', 'פָּאוּאֶר שֶׁל'),
    E('cmd:cmd', 'cmd', 'CMD', 'סִי אֶם דִּי'),
    E('cmd:git', 'cmd', 'git', 'פקודת גיט'),
    E('cmd:node', 'cmd', 'node / npm', 'נוֹד'),
    E('cmd:python', 'cmd', 'Python', 'פַּייתוֹן'),
    E('cmd:install', 'cmd', 'התקנת חבילה', 'מתקין חבילה'),
    E('cmd:ssh', 'cmd', 'חיבור לשרת (ssh)', 'מתחבר לשרת'),
    E('cmd:net', 'cmd', 'הורדה מהרשת (curl / wget)', 'מוריד מהרשת'),
    E('cmd:test', 'cmd', 'הרצת בדיקות', 'מריץ בדיקות'),
    E('cmd:build', 'cmd', 'בנייה (build)', 'בונה'),
    E('cmd:delete', 'cmd', 'מחיקת קבצים', 'מוחק קבצים'),
    E('cmd:sleep', 'cmd', 'המתנה', 'מחכה'),
    E('tool:BashOutput', 'cmd', 'בודק פלט של פקודה ברקע', 'בודק פלט'),
    E('tool:KillShell', 'cmd', 'עוצר פקודה ברקע', 'עוצר פקודה'),
    E('tool:Monitor', 'cmd', 'מנטר תהליך', 'מנטר תהליך'),
    // ----- קבצים וחיפוש -----
    E('tool:Read', 'files', 'קורא קובץ', 'קורא קובץ'),
    E('tool:Write', 'files', 'כותב קובץ חדש', 'כותב קובץ'),
    E('tool:Edit', 'files', 'עורך קובץ', 'עורך קובץ'),
    E('tool:MultiEdit', 'files', 'כמה עריכות בקובץ', 'עורך כמה שינויים'),
    E('tool:NotebookEdit', 'files', 'עורך מחברת Jupyter', 'עורך מחברת'),
    E('tool:Glob', 'files', 'מחפש קבצים לפי שם', 'מחפש קבצים'),
    E('tool:Grep', 'files', 'grep — חיפוש בתוך קבצים', 'גְּרֶפּ'),
    E('tool:LSP', 'files', 'ניתוח קוד', 'מנתח קוד'),
    // ----- רשת -----
    E('tool:WebSearch', 'web', 'חיפוש ברשת', 'מחפש ברשת'),
    E('tool:WebFetch', 'web', 'קורא דף אינטרנט', 'קורא דף אינטרנט'),
    // ----- Chrome שלך -----
    E('chrome:open', 'chrome', 'פותח Chrome / לשונית חדשה', 'פותח כְּרוֹם'),
    E('chrome:tabs', 'chrome', 'בודק לשוניות', 'בודק לשוניות'),
    E('chrome:switch', 'chrome', 'עובר ללשונית', 'עובר ללשונית'),
    E('chrome:close', 'chrome', 'סוגר לשונית', 'סוגר לשונית'),
    E('chrome:navigate', 'chrome', 'נכנס לאתר', 'נכנס לאתר'),
    E('chrome:read', 'chrome', 'קורא את הדף', 'קורא את הדף'),
    E('chrome:find', 'chrome', 'מחפש בדף', 'מחפש בדף'),
    E('chrome:click', 'chrome', 'לוחץ', 'לוחץ'),
    E('chrome:hover', 'chrome', 'מרחף מעל', 'מְרַחֵף מֵעַל'),
    E('chrome:type', 'chrome', 'מקליד', 'מקליד'),
    E('chrome:search', 'chrome', 'מקליד בשורת החיפוש', 'מקליד בשורת החיפוש'),
    E('chrome:key', 'chrome', 'לוחץ על מקש', 'לוחץ על מקש'),
    E('chrome:select', 'chrome', 'בוחר מרשימה', 'בוחר מהרשימה'),
    E('chrome:upload', 'chrome', 'מעלה קובץ', 'מעלה קובץ'),
    E('chrome:drag', 'chrome', 'גורר', 'גורר'),
    E('chrome:scroll', 'chrome', 'גולל', 'גולל'),
    E('chrome:shot', 'chrome', 'מצלם את הדף', 'מצלם את הדף'),
    E('chrome:eval', 'chrome', 'מריץ קוד בדף', 'מריץ קוד בדף'),
    E('chrome:wait', 'chrome', 'מחכה לדף', 'מחכה'),
    E('chrome:back', 'chrome', 'חוזר אחורה', 'חוזר אחורה'),
    E('chrome:forward', 'chrome', 'מתקדם קדימה', 'מתקדם קדימה'),
    E('chrome:reload', 'chrome', 'מרענן את הדף', 'מרענן'),
    E('chrome:batch', 'chrome', 'כמה פעולות ברצף', 'מבצע כמה פעולות'),
    // ----- שליטה במחשב -----
    E('pc:shot', 'pc', 'מצלם את המסך', 'מצלם את המסך'),
    E('pc:windows', 'pc', 'בודק חלונות פתוחים', 'בודק חלונות'),
    E('pc:window', 'pc', 'עובר לחלון / ממזער / סוגר', 'עובר לחלון'),
    E('pc:ui', 'pc', 'קורא את מה שעל המסך', 'קורא את המסך'),
    E('pc:act', 'pc', 'לוחץ על כפתור בתוכנה', 'לוחץ על כפתור'),
    E('pc:click', 'pc', 'לחיצת עכבר', 'לוחץ בעכבר'),
    E('pc:move', 'pc', 'מזיז את העכבר', 'מזיז את העכבר'),
    E('pc:drag', 'pc', 'גורר בעכבר', 'גורר'),
    E('pc:scroll', 'pc', 'גולל', 'גולל'),
    E('pc:type', 'pc', 'מקליד במחשב', 'מקליד'),
    E('pc:key', 'pc', 'לוחץ על מקש', 'לוחץ על מקש'),
    E('pc:open', 'pc', 'פותח תוכנה / קובץ', 'פותח תוכנה'),
    E('pc:clipboard', 'pc', 'משתמש בלוח (העתק / הדבק)', 'מעתיק'),
    // ----- צילומי מסך -----
    E('ev:screenshot', 'shot', 'כל צילום מסך (PNG) — מכל כלי', 'מצלם', false, 'camera'),
    E('ev:image', 'shot', 'Claude פותח תמונה', 'פותח תמונה'),
    // ----- כלים של Claude -----
    E('tool:TodoWrite', 'claude', 'מעדכן רשימת משימות', 'מעדכן משימות'),
    E('tool:Skill', 'claude', 'מפעיל Skill', 'מפעיל סְקִיל'),
    E('tool:ToolSearch', 'claude', 'מחפש כלי', 'מחפש כלי'),
    E('tool:ExitPlanMode', 'claude', 'מציג תוכנית', 'מציג תוכנית'),
    E('tool:AskUserQuestion', 'claude', 'שואל שאלה', 'שואל שאלה'),
    E('tool:Workflow', 'claude', 'מפעיל תהליך', 'מפעיל תהליך'),
    // ----- שיחות, תזרימים ומעקבים (כלים של האפליקציה) -----
    E('app:chat_send', 'app', 'שולח הודעה לשיחה אחרת', 'שולח הודעה'),
    E('app:chat_read', 'app', 'קורא שיחה אחרת', 'קורא שיחה'),
    E('app:chat_new', 'app', 'פותח שיחה חדשה', 'פותח שיחה חדשה'),
    E('app:flow', 'app', 'מפעיל / יוצר תזרים', 'מפעיל תזרים'),
    E('app:watch', 'app', 'מנהל מעקב', 'מנהל מעקב'),
    // ----- כלים חיצוניים -----
    E('mcp:other', 'other', 'כל כלי חיצוני אחר (MCP)', 'משתמש בכלי'),
    E('mcp:blender', 'other', 'Blender', 'בלנדר'),
    E('mcp:serena', 'other', 'Serena (ניתוח קוד)', 'סֶרֶנָה')
  ];
  // משפטים נוספים לקול (גם לבחירה חופשית לכל אירוע)
  const EXTRA_PHRASES = { 'x:claude_done': 'קלוד סיים', 'x:work_done': 'סיימתי עבודה', 'x:ready': 'מוכן', 'x:attention': 'שים לב', 'x:hello': 'שלום',
    // "מתקרב למגבלת המנוי" עם הנותר — מתנגן במקום המשפט הכללי כשעוברים מדרגה (50 / 40 / 30 / 20 / 10)
    // שלבי מחקר — מתנגנים במקום "המחקר עבר לשלב הבא" כשהשלב ידוע
    'x:rstage_researching': 'החוקרים יצאו לחקור', 'x:rstage_writing': 'כותב את דוח המחקר',
    'x:limit_50': 'מתקרב למגבלת המנוי, נותרו חמישים אחוז', 'x:limit_40': 'מתקרב למגבלת המנוי, נותרו ארבעים אחוז', 'x:limit_30': 'מתקרב למגבלת המנוי, נותרו שלושים אחוז', 'x:limit_20': 'מתקרב למגבלת המנוי, נותרו עשרים אחוז', 'x:limit_10': 'מתקרב למגבלת המנוי, נותרו עשרה אחוזים' };

  // ---------- סיווג: כלי + קלט → מפתחות אירוע ----------
  const BROWSER = {
    browser_navigate: 'chrome:navigate', browser_snapshot: 'chrome:read', browser_get_text: 'chrome:read', browser_find: 'chrome:find', browser_click: 'chrome:click',
    browser_hover: 'chrome:hover', browser_press_key: 'chrome:key', browser_select: 'chrome:select', browser_upload: 'chrome:upload', browser_drag: 'chrome:drag',
    browser_scroll: 'chrome:scroll', browser_screenshot: 'chrome:shot', browser_eval: 'chrome:eval', browser_wait: 'chrome:wait', browser_batch: 'chrome:batch'
  };
  const DESKTOP = {
    desktop_screenshot: 'pc:shot', desktop_windows: 'pc:windows', desktop_window: 'pc:window', desktop_ui: 'pc:ui', desktop_ui_action: 'pc:act', desktop_click: 'pc:click',
    desktop_move: 'pc:move', desktop_drag: 'pc:drag', desktop_scroll: 'pc:scroll', desktop_type: 'pc:type', desktop_key: 'pc:key', desktop_open: 'pc:open', desktop_clipboard: 'pc:clipboard'
  };
  const SHOT_TOOLS = /(^|_)(screenshot|look|take_screenshot|capture)$|computer$/i;
  function cmdKinds(c) {
    const s = String(c || '').trim().toLowerCase(), out = [];
    if (/^(powershell|pwsh)(\.exe)?\b/.test(s) || /\bpowershell(\.exe)?\s+-/.test(s)) out.push('cmd:powershell');
    if (/^cmd(\.exe)?\s+\/[ck]\b/.test(s)) out.push('cmd:cmd');
    if (/^git\b|\bgit\s+(status|diff|log|commit|push|pull|add|checkout|clone|fetch|merge|rebase|branch)\b/.test(s)) out.push('cmd:git');
    if (/\b(npm|npx|node|yarn|pnpm)\b/.test(s)) out.push('cmd:node');
    if (/\b(python3?|py|pip3?)\b/.test(s)) out.push('cmd:python');
    if (/\b(npm|yarn|pnpm)\s+(i|install|add)\b|\bpip3?\s+install\b|\bwinget\s+install\b|\bchoco\s+install\b|\bapt(-get)?\s+install\b/.test(s)) out.push('cmd:install');
    if (/^ssh\b|\bssh\s+-|\bscp\b/.test(s)) out.push('cmd:ssh');
    if (/\b(curl|wget|invoke-webrequest|iwr)\b/.test(s)) out.push('cmd:net');
    if (/\b(test|jest|pytest|mocha|vitest)\b/.test(s) && /\b(npm|npx|node|pytest|python|yarn)\b/.test(s)) out.push('cmd:test');
    if (/\b(build|make|msbuild|csc|tsc|webpack|vite build)\b/.test(s)) out.push('cmd:build');
    if (/^(rm|del|rmdir|remove-item)\b|\brm\s+-r|\bremove-item\b/.test(s)) out.push('cmd:delete');
    if (/^(sleep|timeout|ping\s+-n)\b|start-sleep/.test(s)) out.push('cmd:sleep');
    return out;
  }
  // מחזיר רשימת מפתחות (מהכללי לספציפי). name = שם הכלי כפי ש-Claude Code מדווח (גם mcp__server__tool)
  function classify(name, input) {
    name = String(name || ''); input = input || {};
    const keys = [];
    const m = name.match(/^mcp__([^_]+(?:_[^_]+)*?)__(.+)$/); const server = m ? m[1] : '', bare = m ? m[2] : name;
    if (m && server === 'claudechat') {
      if (BROWSER[bare]) keys.push(BROWSER[bare]);
      else if (bare === 'browser_type') { const t = JSON.stringify(input).toLowerCase(); keys.push(/search|חיפוש|"q"|omnibox|searchbox|query|\bq\b/.test(t) ? 'chrome:search' : 'chrome:type'); }
      else if (bare === 'browser_tabs') { const a = input.action || 'list'; keys.push(a === 'new' ? 'chrome:open' : a === 'switch' ? 'chrome:switch' : a === 'close' ? 'chrome:close' : 'chrome:tabs'); }
      else if (bare === 'browser_history') { const a = input.action || 'back'; keys.push(a === 'forward' ? 'chrome:forward' : a === 'reload' ? 'chrome:reload' : 'chrome:back'); }
      else if (DESKTOP[bare]) keys.push(DESKTOP[bare]);
      else if (bare === 'chat_send') keys.push('app:chat_send'); else if (bare === 'chat_read' || bare === 'chat_list') keys.push('app:chat_read'); else if (bare === 'chat_new') keys.push('app:chat_new');
      else if (/^flow_/.test(bare)) keys.push('app:flow'); else if (/^watch_/.test(bare)) keys.push('app:watch');
      else keys.push('mcp:other');
    } else if (m) {
      keys.push(server === 'blender' ? 'mcp:blender' : server === 'serena' ? 'mcp:serena' : 'mcp:other');
    } else {
      const alias = { Task: 'Agent', KillBash: 'KillShell', TaskStop: 'KillShell' }[name] || name;
      if (alias === 'Agent') return []; // "מפעיל סוכן" נשמע פעם אחת — מהאירוע ev:agent_start (כשהסוכן באמת מתחיל)
      keys.push('tool:' + alias);
      if (alias === 'Bash') keys.push(...cmdKinds(input.command));
      if (alias === 'Read' && /\.(png|jpe?g|gif|webp|bmp)$/i.test(String(input.file_path || ''))) keys.push('ev:image');
    }
    if (SHOT_TOOLS.test(bare) || keys.includes('chrome:shot') || keys.includes('pc:shot')) keys.push('ev:screenshot');
    return keys;
  }
  // מילות חיפוש נוספות (איך אנשים קוראים לזה בפועל)
  function tags(key) {
    const t = [];
    if (key === 'tool:Bash' || key.startsWith('cmd:')) t.push('bash בש באש פקודה פקודות טרמינל shell');
    if (/powershell/i.test(key)) t.push('powershell פאוורשל פאוור של');
    if (key === 'cmd:cmd') t.push('cmd סי אם די');
    if (key.startsWith('chrome:')) t.push('chrome כרום דפדפן browser אתר');
    if (/shot|screenshot|image/.test(key)) t.push('צילום צילומים מסך png screenshot תמונה מצלם');
    if (key.startsWith('pc:')) t.push('מחשב שליטה עכבר מקלדת desktop חלון');
    if (key === 'tool:Grep' || key === 'tool:Glob') t.push('grep גרפ חיפוש search');
    if (/^tool:(Read|Write|Edit|MultiEdit|NotebookEdit)$/.test(key)) t.push('קובץ קבצים file');
    if (/agent/.test(key)) t.push('סוכן סוכנים agent');
    if (key.startsWith('tool:Web')) t.push('אינטרנט רשת web');
    if (key.startsWith('ev:watch')) t.push('מעקב watch');
    if (key.startsWith('ev:research')) t.push('מחקר research');
    if (key === 'ev:finish') t.push('סיום סיים finish done');
    if (key === 'ev:refused') t.push('סירב סירוב לא מוכן refuse');
    return t.join(' ');
  }
  // ---------- רמות צלילים ----------
  // 1 = קריטיים בלבד (מה שחייב לשמוע: סיום, שגיאה, סירוב, מחכה לך, מגבלה, מחקר/תזרים שהסתיים או נתקע, וכל סבב מעקב: התחיל / תקין / בעיה / נגמר — הבעלים 11-24)
  // 2 = מפורט — גם התחלות וסיומים של סוכנים/מחקרים/סבבים, חסימות, תקלות בכלים, הודעות בין שיחות
  // 3 = כל הצלילים — גם כל פעולה (פקודה, קובץ, דפדפן, עכבר…)
  const LEVELS = { 1: 'קריטיים בלבד', 2: 'מפורט', 3: 'כל הצלילים' };
  const CRITICAL = new Set(['ev:finish', 'ev:error', 'ev:refused', 'ev:approval', 'ev:question', 'ev:limit', 'ev:research_start', 'ev:research_stage', 'ev:research_done', 'ev:research_refused', 'ev:research_bg', 'ev:watch_round', 'ev:watch_ok', 'ev:watch_warn', 'ev:watch_end', 'ev:flow_done']);
  const DETAIL = new Set(['ev:stopped', 'ev:denied', 'ev:tool_error', 'ev:compaction', 'ev:queued', 'ev:agent_start', 'ev:agent_done', 'ev:flow_step', 'app:chat_send', 'app:chat_new', 'app:flow', 'app:watch', 'tool:SendMessage']);
  const levelOf = k => CRITICAL.has(k) ? 1 : DETAIL.has(k) ? 2 : 3;
  for (const e of EVENTS) e.level = levelOf(e.key);
  const byKey = Object.fromEntries(EVENTS.map(e => [e.key, e]));
  const api = { GROUPS: G, EVENTS, EXTRA_PHRASES, byKey, classify, cmdKinds, tags, LEVELS, levelOf };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.SOUND_CATALOG = api;
})(typeof window !== 'undefined' ? window : globalThis);
