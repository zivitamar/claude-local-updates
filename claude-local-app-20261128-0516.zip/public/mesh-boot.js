// ============================================================
//  mesh-boot.js — נטען ראשון. כשעובדים על מחשב אחר (?m=<מזהה>): כל קריאה של הממשק ל-/api/… עוברת אוטומטית
//  ל-/m/<מזהה>/api/… (המנהרה המוצפנת אל המחשב ההוא) — fetch, EventSource, תמונות/קישורים. כך כל הממשק (פרויקטים, צ'אטים,
//  קבצים, Claude) עובד על המחשב ההוא בלי שום שינוי במודולים.
//  נשאר תמיד על המחשב שלך: ניהול הרשת, הצלילים (הרמקולים שלך), ההכתבה (המיקרופון שלך), חלון האפליקציה.
//  העדפות ממשק (טאבים פתוחים וכו') נשמרות בנפרד לכל מחשב.
// ============================================================
(function () {
  'use strict';
  var m = null;
  try { m = new URLSearchParams(location.search).get('m'); } catch (e) { }
  // גיבוי: המחשב שעובדים עליו נזכר בחלון הזה (רענון / הפעלה מחדש של השרת לא מחזירים בטעות למחשב המקומי)
  try { if (!m && !/[?&]local=1/.test(location.search)) m = sessionStorage.getItem('mesh.active'); if (/^[0-9a-f]{16}$/.test(m || '')) sessionStorage.setItem('mesh.active', m); else sessionStorage.removeItem('mesh.active'); } catch (e) { }
  if (!/^[0-9a-f]{16}$/.test(m || '')) { window.MESH = { remote: null, rw: function (u) { return u; } }; return; }
  var P = '/m/' + m;
  var LOCAL = /^\/api\/(mesh|stt|sounds|app)(\/|$|\?)/;
  function rw(u) { if (typeof u !== 'string') return u; if (u.charAt(0) === '/' && u.indexOf('/api/') === 0 && !LOCAL.test(u)) return P + u; return u; }
  window.MESH = { remote: m, prefix: P, rw: rw };
  var of = window.fetch;
  window.fetch = function (input, init) {
    try {
      var h = init && init.headers, local = h && (h['x-mesh-local'] || (typeof h.get === 'function' && h.get('x-mesh-local')));
      if (!local) {
        if (typeof input === 'string') input = rw(input);
        else if (input && input.url) { var u = new URL(input.url); if (u.origin === location.origin && u.pathname.indexOf('/api/') === 0 && !LOCAL.test(u.pathname)) input = new Request(P + u.pathname + u.search, input); }
      }
    } catch (e) { }
    return of.call(this, input, init);
  };
  var OES = window.EventSource;
  if (OES) { var ES = function (u, o) { return new OES(rw(u), o); }; ES.prototype = OES.prototype; ES.CONNECTING = 0; ES.OPEN = 1; ES.CLOSED = 2; window.EventSource = ES; }
  var fix = function (el) { if (!el || !el.getAttribute) return; ['src', 'href'].forEach(function (a) { var v = el.getAttribute(a); if (v && v.indexOf('/api/') === 0 && !LOCAL.test(v)) el.setAttribute(a, P + v); }); };
  new MutationObserver(function (ms) {
    ms.forEach(function (x) {
      if (x.type === 'attributes') fix(x.target);
      else x.addedNodes.forEach(function (n) { if (n.nodeType === 1) { fix(n); if (n.querySelectorAll) n.querySelectorAll('[src^="/api/"],[href^="/api/"]').forEach(fix); } });
    });
  }).observe(document.documentElement, { subtree: true, childList: true, attributes: true, attributeFilter: ['src', 'href'] });
  // העדפות ממשק לכל מחשב בנפרד (ערכת נושא וצבעים — משותפים)
  var SHARED = /^(claude\.theme|claude\.userMsgColors|mesh\.)/;
  var key = function (k) { k = String(k); return SHARED.test(k) ? k : 'm:' + m + ':' + k; };
  var gi = Storage.prototype.getItem, si = Storage.prototype.setItem, ri = Storage.prototype.removeItem;
  Storage.prototype.getItem = function (k) { return gi.call(this, key(k)); };
  Storage.prototype.setItem = function (k, v) { return si.call(this, key(k), v); };
  Storage.prototype.removeItem = function (k) { return ri.call(this, key(k)); };
})();
