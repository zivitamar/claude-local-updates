'use strict';
// ============================================================
//  cli_engine.js — מנוע "מנוי": שיחה שרצה דרך Claude Code הרשמי (claude.exe), באותו אופן שתוסף VS Code עושה.
//  מתרגם את אירועי ה-stream-json של ה-CLI לאירועי הממשק (אותם שמנוע ה-API פולט), שומר את ההודעות בפורמט
//  Anthropic הרגיל (כך ש-renderHistory עובד זהה), ומחבר: אישורי הרשאות, שאלות מ-Claude, סוכני משנה (Agent/Task),
//  עצירה, הודעות באמצע ריצה, נתוני שימוש, ו-Remote Control (תהליך שנשאר חי בין הודעות).
//  כל התלויות מוזרקות (deps). הפרוטוקול נלמד מהתוסף (extension.js) ונבדק חי — ראה docs/SUBSCRIPTION.md.
// ============================================================
const { spawn } = require('child_process');
const crypto = require('crypto');
const claude = require('./claude_cli');

const TOOL_RESULT_CAP = 60000;
const TASK_TOOLS = new Set(['Agent', 'Task']);
const REMOTE_IDLE_MS = 45 * 60 * 1000;
const authCache = { ok: false, at: 0, st: null };

const fs = require('fs'), path = require('path'), os = require('os');
// השימוש המדויק של סוכן משנה: כל הקריאות שלו מתוך הקובץ שלו (<session>/subagents/agent-<id>.jsonl).
// (ה-usage שמצורף לתוצאת Agent הוא רק של הקריאה האחרונה שלו — לא הסכום)
const sessDirCache = new Map();
function subagentCalls(sessionId, agentId) {
  if (!sessionId || !agentId) return null;
  let dir = sessDirCache.get(sessionId);
  if (dir === undefined) {
    dir = null; const root = path.join(os.homedir(), '.claude', 'projects');
    try { for (const d of fs.readdirSync(root)) { const p = path.join(root, d, sessionId); if (fs.existsSync(p) || fs.existsSync(p + '.jsonl')) { dir = p; break; } } } catch { }
    sessDirCache.set(sessionId, dir);
  }
  if (!dir) return null;
  const f = path.join(dir, 'subagents', 'agent-' + agentId + '.jsonl');
  let txt; try { txt = fs.readFileSync(f, 'utf8'); } catch { return null; }
  const out = new Map();
  for (const l of txt.split('\n')) { if (l.indexOf('"usage"') < 0) continue; let j; try { j = JSON.parse(l); } catch { continue; } if (j.type === 'assistant' && j.message && j.message.usage && j.message.model !== '<synthetic>') out.set(j.message.id, { model: j.message.model, usage: j.message.usage }); }
  return out;
}
// חוקרים עם מודל קבוע (לגרסה, לא רק למשפחה): חוקר שנכשל / סירב עובר לבא בתור — 5 ניסיונות בכל אחד
const RESEARCHER_MODELS = [['researcher-opus-5-5', 'claude-opus-5-5', 'Opus 5.5'], ['researcher-opus-4-8', 'claude-opus-4-8', 'Opus 4.8'], ['researcher-opus-4-6', 'claude-opus-4-6', 'Opus 4.6'], ['researcher-sonnet-4-6', 'claude-sonnet-4-6', 'Sonnet 4.6']];
const RESEARCHER_TRIES = 5;
function researcherAgentsFile() {
  const f = path.join(os.tmpdir(), 'claude-local-researchers.json');
  const prompt = 'You are a web researcher sub-agent. Research the topic you are given thoroughly: use WebSearch to find relevant pages, then OPEN and READ the important pages with WebFetch (a page counts as a source only if you actually read it). Cross-check facts across sources. Return detailed findings in the language of the task, each fact with the URL of the page it came from. Never invent facts or sources.';
  const obj = Object.fromEntries(RESEARCHER_MODELS.map(([name, model, label]) => [name, { description: `RESERVED fallback web researcher fixed to ${label}. Use ONLY when the app explicitly tells you to relaunch a failed or refused research topic with this exact type; otherwise use general-purpose.`, prompt, model }]));
  try { const s = JSON.stringify(obj, null, 1); if (!fs.existsSync(f) || fs.readFileSync(f, 'utf8') !== s) fs.writeFileSync(f, s); return f; } catch { return null; }
}
const researcherFor = fails => RESEARCHER_MODELS[Math.min(RESEARCHER_MODELS.length - 1, Math.floor((fails || 0) / RESEARCHER_TRIES))];
// תוצאת Agent מתוך קובץ הסשן הראשי (כשכמה חוקרים סיימו יחד, הזרם לא מצמיד לכל תוצאה את הנתונים שלה)
function agentResultFromTranscript(sessionId, toolUseId) {
  if (!sessionId || !toolUseId) return null;
  subagentCalls(sessionId, '__probe__'); const dir = sessDirCache.get(sessionId); if (!dir) return null;
  let txt = ''; try { const f = dir + '.jsonl', st = fs.statSync(f), n = Math.min(st.size, 8 * 1024 * 1024), b = Buffer.alloc(n), fd = fs.openSync(f, 'r'); fs.readSync(fd, b, 0, n, st.size - n); fs.closeSync(fd); txt = b.toString('utf8'); } catch { return null; }
  const key = '"tool_use_id":"' + toolUseId + '"';
  for (const l of txt.split('\n').reverse()) { if (l.indexOf(key) < 0 || l.indexOf('"toolUseResult"') < 0) continue; try { const j = JSON.parse(l); if (j.toolUseResult && j.toolUseResult.usage) return j.toolUseResult; } catch { } }
  return null;
}
const short = (s, n) => { s = String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
const base = p => String(p || '').split(/[\\/]/).filter(Boolean).pop() || String(p || '');

function activityOf(name, i) {
  i = i || {};
  switch (name) {
    case 'Bash': case 'PowerShell': return 'מריץ פקודה: ' + short(i.command, 70);
    case 'Read': return 'קורא: ' + short(base(i.file_path), 60);
    case 'Write': return 'כותב קובץ: ' + short(base(i.file_path), 60);
    case 'Edit': case 'MultiEdit': return 'עורך: ' + short(base(i.file_path), 60);
    case 'Glob': return 'מחפש קבצים: ' + short(i.pattern, 60);
    case 'Grep': return 'מחפש: ' + short(i.pattern, 60);
    case 'WebSearch': return 'מחפש ברשת: ' + short(i.query, 70);
    case 'WebFetch': return 'קורא דף: ' + short(i.url, 70);
    case 'Agent': case 'Task': return 'מפעיל סוכן: ' + short(i.description, 60);
    default: return 'מפעיל ' + name;
  }
}
function flattenResult(c) {
  if (typeof c === 'string') return c;
  if (Array.isArray(c)) return c.map(b => (b && b.type === 'text' ? b.text : b && b.type === 'image' ? '[image]' : b && b.text) || '').join('\n');
  try { return JSON.stringify(c); } catch { return String(c); }
}
const cap = s => (s.length > TOOL_RESULT_CAP ? s.slice(0, TOOL_RESULT_CAP) + '\n…(truncated)' : s);

// תמלול שיחה קודמת (כשאי אפשר להמשיך סשן של ה-CLI: החלפת חשבון / תיקייה / מעבר ממצב API)
function transcriptOf(conv, maxChars = 60000) {
  const lines = [];
  for (const m of conv.messages) {
    const content = Array.isArray(m.content) ? m.content : [{ type: 'text', text: String(m.content) }];
    for (const b of content) {
      if (b.type === 'text' && b.text && !b.hidden) lines.push(`${m.role === 'user' ? 'USER' : 'ASSISTANT'}: ${b.text}`);
      else if (b.type === 'tool_use') lines.push(`[assistant used tool ${b.name}: ${short(JSON.stringify(b.input), 300)}]`);
      else if (b.type === 'tool_result') lines.push(`[tool result: ${short(flattenResult(b.content), 400)}]`);
    }
  }
  let t = lines.join('\n');
  if (t.length > maxChars) t = '…(earlier part omitted)…\n' + t.slice(-maxChars);
  return t;
}

// ---------- סיכום מובנה: Claude כותב בלוק <research_summary>…</research_summary> אחרי הדוח; האפליקציה מפרידה אותו לחלונית משלו ----------
const SUM_OPEN = '<research_summary>', SUM_CLOSE = '</research_summary>';
function splitSummary(text, streaming) {
  text = String(text || '');
  const i = text.indexOf(SUM_OPEN);
  if (i < 0) {
    if (streaming) for (let k = Math.min(SUM_OPEN.length - 1, text.length); k > 0; k--) if (text.endsWith(SUM_OPEN.slice(0, k))) return { report: text.slice(0, text.length - k), summary: null }; // תגית פתיחה חלקית בסוף הזרם: לא מציגים
    return { report: text, summary: null };
  }
  const rest = text.slice(i + SUM_OPEN.length), j = rest.indexOf(SUM_CLOSE);
  return { report: text.slice(0, i).replace(/\s+$/, ''), summary: (j >= 0 ? rest.slice(0, j) : rest).trim() };
}
const MAX_ROUNDS = 26, NO_PROGRESS_MAX = 3, MAX_SUMMARY_ASKS = 2; // 26: מקום ל-20 ניסיונות לנושא + סבבי דוח / סיכום
// קישורים בטקסט (markdown או כתובת חשופה) שאינם בין המקורות שנספרו. השוואה לפי מארח+נתיב (בלי www, #, / בסוף ופרמטרים)
const urlKey = u => { try { const x = new URL(String(u).replace(/[).,;:!?\]]+$/, '')); return (x.hostname.replace(/^www\./, '') + x.pathname.replace(/\/+$/, '')).toLowerCase(); } catch { return ''; } };
function citedOutside(text, allowedUrls) {
  const allowed = new Set((allowedUrls || []).map(urlKey).filter(Boolean)); const out = new Map();
  for (const m of String(text || '').matchAll(/https?:\/\/[^\s"'<>)\]]+/g)) { const k = urlKey(m[0]); if (k && !allowed.has(k) && !out.has(k)) out.set(k, m[0]); }
  return [...out.values()];
}

function createCliEngine(deps) {
  const { saveConv, recordUsage, costOf, agentsMgr, researchMgr, stopConv, systemAppend, convWorkingDir, waitForApproval, now } = deps;
  const textOf = content => (content || []).filter(b => b.type === 'text' && !b.hidden).map(b => b.text).join('\n').trim();
  const sessions = new Map(); // convId -> S  (נשמרים רק כש-Remote Control דלוק)

  function buildArgs(cfg, conv, { resume, appendSystem, fork }) {
    // --replay-user-messages: ה-CLI מחזיר כל הודעה שלנו ברגע שהוא באמת קורא אותה — כך יודעים שהודעה שנשלחה באמצע עבודה עוד לא טופלה
    const a = ['-p', '--output-format', 'stream-json', '--verbose', '--input-format', 'stream-json', '--include-partial-messages', '--replay-user-messages', '--permission-prompt-tool=stdio'];
    if (cfg.model && cfg.model !== 'default') a.push('--model', cfg.model);
    const effort = cfg.effort; // effectiveConfig כבר השלים "רגיל" (ULTRACODE / חשיבה תמיד) — בחירה מפורשת עוברת כמו שהיא
    if (effort && effort !== 'default') a.push('--effort', effort);
    // חשיבה: כבויה = כבויה (גם ב-ULTRACODE) · תמיד / אוטומטית = adaptive במפורש (לא תלוי בהגדרות של Claude Code במחשב); "תמיד" מוסיפה הוראה לחשוב בכל תשובה
    if (cfg.thinking === 'off') a.push('--thinking=disabled'); else a.push('--thinking=adaptive');
    if (cfg.thinking !== 'off' && cfg.showThinking !== false) a.push('--thinking-display', 'summarized');
    const mode = cfg.permissionMode || (cfg.autoApprove === false ? 'default' : 'bypassPermissions');
    a.push('--permission-mode', mode);
    if (mode === 'bypassPermissions') a.push('--allow-dangerously-skip-permissions');
    if (appendSystem) a.push('--append-system-prompt', appendSystem);
    if (resume) { a.push('--resume', resume); if (fork) a.push('--fork-session'); } // fork: העתק מדויק של סשן קיים (צ'אט מ-VS Code) בלי לגעת במקור
    if (cfg.cliLoadSettings === false) a.push('--strict-mcp-config', '--setting-sources', 'user');
    a.push('--forward-subagent-text'); // הטקסט והחשיבה של סוכני המשנה מגיעים בזרם (אחרת חלון הסוכן ריק עד שהוא מסיים)
    if (conv.kind === 'research') { const f = researcherAgentsFile(); if (f) a.push('--agents', f); }
    // תיקיות נוספות של ה-Workspace + כלי השיחות/תזרימים של האפליקציה
    try {
      const wd = deps.convWorkingDir ? deps.convWorkingDir(conv, cfg) : null;
      const dirs = (deps.workspaceDirs ? deps.workspaceDirs(conv) : []).filter(d => d && d !== wd);
      if (dirs.length) a.push('--add-dir', ...dirs);
      if (deps.mcpConfig) a.push('--mcp-config', deps.mcpConfig(conv));
      if (deps.hooksSettings) a.push('--settings', deps.hooksSettings(conv));
    } catch { }
    return a;
  }

  // ---------- נקודת-שמירה להפעלה-מחדש-חמה (רק במצב מארח) ----------
  // engineSave: החלופה ל-saveConv בכל המנוע. במצב מארח כותב גם את conv.cli.live.
  function engineSave(conv) {
    let S = null;
    try { S = sessions.get(conv.id); if (S && S.conv === conv && S.hsid) stamp(S); else S = null; } catch (e) { S = null; console.error('[cli-engine] stamp', e); }
    const r = saveConv(conv);
    // ה-host מוחק מהטבעת רק שורות שאושרו — מאשרים רק אחרי שהצ'קפוינט נשמר לדיסק
    try { if (S && S.proc && typeof S.proc.ack === 'function' && S.appliedSeq) S.proc.ack(S.appliedSeq); } catch {}
    return r;
  }
  const cfgSnap = cfg => cfg ? { model: cfg.model, effort: cfg.effort, thinking: cfg.thinking, permissionMode: cfg.permissionMode, ultracode: !!cfg.ultracode, agentModel: cfg.agentModel, researchDepth: cfg.researchDepth, autoApprove: cfg.autoApprove, showThinking: cfg.showThinking, thinkOff: cfg.thinkOff } : null;
  // serializeS: בונה את ck (checkpoint) של סשן אחד לפי schema 5.1
  function serializeS(S) {
    const cap = (m, n) => [...m].slice(-n);
    const toolNames = []; for (const [id, v] of (S.toolT0 || new Map())) { } // נשמר דרך blocks; input רק לכלים כבדים
    const ck = {
      sid: S.sid, sawInit: !!S.sawInit, servedModel: S.servedModel, usedResume: !!S.usedResume, resumeId: S.resumeId || null,
      liveModel: S.liveModel, livePerm: S.livePerm, liveThinking: S.liveThinking, liveEffort: S.liveEffort, thinkMode: S.thinkMode,
      remoteOn: !!S.remoteOn, remoteUrl: S.remoteUrl || null, keepAlive: !!S.keepAlive, stderrTail: (S.stderr || '').slice(-2000),
      cmd: S.turn && S.turn.cmd || null, turnStartedAt: S.turnUse && S.turnUse.startedAt || null, skipResult: S.skipResult || 0,
      gotResult: !!S.gotResult, turnOver: !!S.turnOver, turnMsgs: S.turnMsgs || 0, stopped: !!S.stopped, apiError: S.apiError || null,
      awaitReplay: S.awaitReplay || 0, replaySeen: !!S.replaySeen,
      curMsg: S.curMsg ? { id: S.curMsg.id, model: S.curMsg.model } : null,
      blocks: S.blocks || {},
      toolT0: cap(S.toolT0 || new Map(), 200), msgUsage: cap(S.msgUsage || new Map(), 300), flushed: [...(S.flushed || new Set())].slice(-300),
      turnUse: S.turnUse || null,
      sub: [...(S.sub || new Map())].map(([k, v]) => [k, { agentId: v.agentId, taskId: v.taskId, last: (v.last || '').slice(-4000), topics: v.topics, topic: v.topic, subIdx: v.subIdx, accounted: v.accounted, judged: v.judged, liveTok: v.liveTok, usageFinal: v.usageFinal, subDone: v.subDone }]),
      research: S.research ? { id: S.research.id, subsStarted: S.subsStarted, subsRunning: S.subsRunning, reportStreaming: S.reportStreaming, topicDone: [...(S.topicDone || [])], topicFail: S.topicFail, topicSkip: [...(S.topicSkip || [])], researchDepth: S.researchDepth, researchIssues: S.researchIssues, lastProg: S.lastProg, researchOpts: S.researchOpts, rounds: S.rounds, noProgress: S.noProgress, lastRoundCount: S.lastRoundCount, gaveUp: S.gaveUp, summaryAsks: S.summaryAsks, topicsSeen: [...(S.topicsSeen || [])], fullText: S.fullText, sentLen: S.sentLen, summaryOnly: S.summaryOnly, lastSummary: S.lastSummary } : null,
      pendingCtl: S.pendingCtl ? [...S.pendingCtl.values()] : [],
      pendingWrites: (S.proc && S.proc.isHosted && S.proc.stdin && S.proc.stdin.pending) ? S.proc.stdin.pending() : [],
      queue: (S.turn && S.turn.state && S.turn.state.queue) ? S.turn.state.queue : []
    };
    return ck;
  }
  // stamp: כותב conv.cli.live לפני spawn / אחרי שינוי. בלי מארח — לא כותב כלום (התנהגות זהה להיום).
  function stamp(S) {
    if (!deps.spawnCli) return;
    const conv = S.conv; conv.cli = conv.cli || {};
    conv.cli.live = {
      v: 1, hsid: S.hsid || null, kind: conv.kind || 'chat',
      turnActive: !!(S.turn && !S.turnOver), pendingStart: false,
      appliedSeq: S.appliedSeq || 0, cfg: cfgSnap(S.cfg), argSig: S.argSig || '',
      idleUntil: S.idleUntil || 0, ck: serializeS(S)
    };
  }

  // ---------- הרצת שיחה: לולאה על "תורות" (turn). state = ה-run (תור הודעות, pendingApproval) ----------
  async function run(conv, cfg, emit, signal, state, opts = {}) {
    const cli = await claude.findClaude();
    if (!cli.found) throw new Error(cli.error);
    // בדיקת ההתחברות (~0.33 שניות) — פעם בדקה, לא לפני כל הודעה. אם האימות פג באמצע, ה-CLI נכשל וההודעה על כך מגיעה מ-onClose
    if (!authCache.ok || Date.now() - authCache.at > 60000) { const s0 = await claude.authStatus(); authCache.ok = !!s0.loggedIn; authCache.at = Date.now(); authCache.st = s0; }
    const st = authCache.st;
    if (!st.loggedIn) throw new Error('לא מחובר לחשבון Claude. פתח הגדרות › חשבון ולחץ "כניסה לחשבון".');
    const cwd = convWorkingDir(conv, cfg);
    conv.cli = conv.cli || {};
    let firstTurn = true;
    // אימוץ אחרי הפעלה-מחדש של השרת: התהליך של Claude חי ב-host — מתחברים אליו וממשיכים את התור שרץ, בלי לשלוח שוב את ההודעה
    if (opts.adopt && deps.hostChild) {
      const out = await adoptTurn({ conv, cfg, emit, signal, state, live: opts.adopt.live, cli });
      if (out && out.fatal) throw new Error(out.fatal);
      firstTurn = false;
      if (signal.aborted || !state.queue.length) return;
    }
    while (!signal.aborted) {
      let pending = null;
      let cmd = null;
      if (firstTurn) { pending = lastUserContent(conv); cmd = (lastUserMsg(conv) || {}).cmd || null; }
      else if (state.queue.length) {
        const items = state.queue.splice(0); pending = []; cmd = (items.find(q => q.cmd) || {}).cmd || null;
        for (const q of items) {
          conv.messages.push({ role: 'user', content: q.content, ts: q.ts, injected: true, ...(q.research ? { research: true } : {}), ...(q.cmd ? { cmd: q.cmd } : {}), ...(q.flow ? { flow: q.flow } : {}), ...(q.from ? { from: q.from } : {}), ...(q.fromInfo ? { fromInfo: q.fromInfo } : {}), ...(q.watch ? { watch: q.watch } : {}) });
          emit('user_injected', { id: q.id, ts: q.ts, content: q.content, cmd: q.cmd || null, silent: !!q.silent, ...(q.from ? { from: q.from } : {}), ...(q.fromInfo ? { fromInfo: q.fromInfo } : {}) });
          pending.push(...q.content);
        }
        engineSave(conv);
      }
      if (!pending) break;
      firstTurn = false;
      const out = await runTurn({ conv, cfg, emit, signal, state, cli, cwd, content: pending, cmd });
      if (out.fatal) throw new Error(out.fatal);
      if (signal.aborted || !state.queue.length) break;
    }
  }
  function lastUserContent(conv) {
    for (let i = conv.messages.length - 1; i >= 0; i--) {
      const m = conv.messages[i];
      if (m.role === 'user' && Array.isArray(m.content) && !m.content.some(b => b.type === 'tool_result')) return m.content;
    }
    return null;
  }
  const lastUserMsg = conv => { for (let i = conv.messages.length - 1; i >= 0; i--) { const m = conv.messages[i]; if (m.role === 'user' && Array.isArray(m.content) && !m.content.some(b => b.type === 'tool_result')) return m; } return null; };
  // cmd = פקודת / שנבחרה כתגית: נשלחת ל-CLI בתחילת ההודעה, אבל לא נשמרת בטקסט של הצ'אט
  const toWire = (content, cmd) => {
    let w = content.map(b => {
      if (b.type === 'text') return { type: 'text', text: b.text, _hidden: !!b.hidden, _att: /^<attached_file/.test(b.text || '') };
      if (b.type === 'image') return { type: 'image', source: b.source };
      return b;
    }).filter(b => !(b.type === 'text' && !b.text && !cmd));
    if (cmd) {
      const i = w.findIndex(b => b.type === 'text' && !b._hidden && !b._att);
      const userText = i >= 0 ? w[i].text : '';
      if (i >= 0) w.splice(i, 1);
      w.unshift({ type: 'text', text: ('/' + cmd + ' ' + userText).trim() });
    }
    return w.map(b => { if (b.type === 'text') { const { _hidden, _att, ...r } = b; return r; } return b; }).filter(b => !(b.type === 'text' && !b.text));
  };

  // ---------- סשן (תהליך claude אחד) ----------
  function newSession(conv, cfg, cli, cwd, usedResume) {
    const S = {
      conv, cwd, cfg, proc: null, procDone: false, sawInit: false, sid: null, stderr: '', buf: '', servedModel: cfg.model || '',
      blocks: {}, sub: new Map(), toolT0: new Map(), msgUsage: new Map(), flushed: new Set(), curMsg: null,
      turn: null, turnOver: false, endTimer: null, stopped: false, gotResult: false, usedResume, keepAlive: false, remoteOn: false, remoteUrl: null,
      ctl: new Map(), idleT: null, lastActivity: Date.now()
    };
    S.emit = (e, d) => { if (S.turn) S.turn.emit(e, d); };
    S.state = () => (S.turn ? S.turn.state : { queue: [], pendingApproval: null });
    S.send = (o, wid) => { try { if (S.proc && S.proc.stdin.writable) { const line = JSON.stringify(o) + '\n'; if (S.proc.isHosted) S.proc.stdin.write(line, wid || null); else S.proc.stdin.write(line); if (o.type === 'user') S.awaitReplay = (S.awaitReplay || 0) + 1; } } catch { } };
    S.control = (subtype, extra, timeoutMs = 30000) => new Promise((resolve, reject) => {
      const id = 'c' + crypto.randomBytes(4).toString('hex'); const t = setTimeout(() => { S.ctl.delete(id); reject(new Error('timeout ' + subtype)); }, timeoutMs);
      S.ctl.set(id, { resolve: v => { clearTimeout(t); resolve(v); }, reject: e => { clearTimeout(t); reject(e); } });
      S.send({ type: 'control_request', request_id: id, request: { subtype, ...extra } });
    });
    S.launch = withResume => {
      const own = conv.cli && conv.cli.sessionId, forkFrom = !own && conv.cli && conv.cli.forkFrom;
      const resumeId = own || forkFrom || null;
      const args = buildArgs(S.cfg, conv, { resume: withResume ? resumeId : null, fork: !!(withResume && forkFrom), appendSystem: systemAppend(conv, S.cfg) });
      S.argSig = argSig(S.cfg, conv);
      // MCP_STARTUP_WAIT=0: לא ממתינים שכל שרתי ה-MCP של המשתמש (blender ~5.3 שניות, serena ~3.5) יעלו לפני השאלה הראשונה — הם מתחברים ברקע.
      // נמדד: 9.6 → 2.5 שניות עד המילה הראשונה. כלי האפליקציה עצמה (claudechat) מחוברים כבר ב-init.
      // הגדרות › סוכנים: מודל לסוכני משנה — Claude Code מכבד את המשתנה הזה לכל סוכן שהוא מפעיל
      // מחקר: (1) בלי "מודל לסוכני משנה" — החוקרים רצים על מודל המחקר, וחוקרי הגיבוי על המודל הקבוע שלהם;
      // (2) ENABLE_TOOL_SEARCH=false — WebSearch / WebFetch טעונים מההתחלה (אחרת Claude הראשי לפעמים "לא מוצא" אותם ולא יכול להשלים מקורות);
      // (3) בלי משימות רקע — חוקר תמיד בחזית: המחקר מחכה לממצאים שלו
      const subEnv = conv.kind === 'research' ? { ENABLE_TOOL_SEARCH: 'false', CLAUDE_CODE_DISABLE_BACKGROUND_TASKS: '1' }
        : S.cfg.agentModel ? { CLAUDE_CODE_SUBAGENT_MODEL: String(S.cfg.agentModel) } : {};
      Object.assign(subEnv, thinkOffEnv(S.cfg, conv));
      // MAX_MCP_OUTPUT_TOKENS: עמוד של chat_history (מפת שיחה של שבועות) נכנס בשלמותו — לא נחתך במגבלת ברירת המחדל
      const env = claude.cliEnv({ CLAUDE_CODE_MCP_STARTUP_WAIT_MS: process.env.CLAUDE_MCP_WAIT_MS || '0', MAX_MCP_OUTPUT_TOKENS: '150000', ...subEnv });
      if (deps.spawnCli) {
        S.hsid = S.hsid || ('s' + crypto.randomBytes(6).toString('hex'));
        stamp(S); // כותבים את נקודת-השמירה לפני ה-spawn (אימוץ אחרי קריסה מוצא אותה)
        // sid באפשרויות (לא במפתח): כך הסשן ב-host נושא בדיוק את המזהה שבנקודת-השמירה, והאימוץ אחרי הפעלה-מחדש מוצא אותו
        S.proc = deps.spawnCli({ kind: S.conv.kind || 'chat', convId: S.conv.id }, cli.path, args, { cwd, env, sid: S.hsid });
      } else {
        S.proc = spawn(cli.path, args, { cwd, env, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
      }
      S.stderr = ''; S.buf = ''; S.sawInit = false; S.procDone = false;
      if (S.proc.isHosted) {
        // frozen (ניתוק): כמו ב-attachHosted — מה שלא יושם נשאר ב-host לשרת הבא
        S.proc.on('line', (seq, s, line) => { if (frozen) return; S.appliedSeq = seq; if (s === 'e') { S.stderr = (S.stderr + line + '\n').slice(-4000); return; } onLine(S, line); });
      } else {
        S.proc.stdout.on('data', d => onStdout(S, d));
        S.proc.stderr.on('data', d => { S.stderr = (S.stderr + d).slice(-4000); });
      }
      S.proc.on('error', e => { if (S.proc && S.proc.isHosted && (frozen || hostLost(S, e))) return; endTurn(S, { fatal: 'לא הצלחתי להפעיל את Claude Code: ' + e.message }); });
      S.proc.on('close', code => { if (frozen && S.proc && S.proc.isHosted) return; onClose(S, code); });
      try { S.proc.stdin.on('error', () => { }); } catch { }
    };
    S.flushUsage = () => flushUsage(S);
    return S;
  }
  function disposeSession(S) { if (!S) return; clearTimeout(S.idleT); clearTimeout(S.endTimer); sessions.delete(S.conv.id); try { S.proc.stdin.end(); } catch { } setTimeout(() => { if (!S.procDone) claude.killTree(S.proc); }, 3000); }
  // Haiku 5.5 + "כבויה": Claude Code מסרב לשלוח thinking:disabled ("Thinking can't be turned off") למרות שה-API מקבל אותו (עד מאמץ high).
  // נמדד 26/11 (פרוקסי שרושם את הבקשה): עם הגוף הנוסף הבקשה יוצאת disabled ו-0 בלוקי חשיבה. context_management ריק — אחרת clear_thinking של ה-CLI נדחה (400).
  // רק כשאין מודל אחר לסוכני משנה (הגוף הנוסף חל על כל הבקשות של התהליך) ולא במחקר
  const thinkOffEnv = (cfg, conv) => (cfg.thinking === 'off' && cfg.thinkOff === 'force-disabled' && !cfg.agentModel && conv.kind !== 'research')
    ? { CLAUDE_CODE_EXTRA_BODY: JSON.stringify({ thinking: { type: 'disabled' }, context_management: { edits: [] } }) } : {};
  // "תמיד": ההוראה בתחילת הטקסט של המשתמש (באותו בלוק — נמדד שבבלוק נפרד Claude מדלג). לא בפקודת / (היא חייבת להתחיל ב-/)
  //  "כבויה": בלי הערה בהודעה — נמדד 26/11 ב-Opus 5.5: עם הערת "לא לחשוב" בכל הודעה חשב 4/12, בלעדיה 1/12 (ההערה מזכירה חשיבה ומעוררת אותה).
  //  נשארים מאמץ נמוך + השורה בהוראות המערכת
  const withThinkPrefix = (wire, mode, cmd) => {
    const pre = mode === 'on' ? deps.thinkOnPrefix : null;
    if (!pre || cmd) return wire;
    const i = wire.findIndex(b => b.type === 'text' && !/^<(attached_file|previous_conversation)/.test(b.text || ''));
    if (i < 0) return [{ type: 'text', text: pre }, ...wire];
    const w = wire.slice(); w[i] = { ...w[i], text: pre + '\n\n' + w[i].text }; return w;
  };
  // חתימת ההגדרות שהתהליך הופעל איתן (מודל, effort, חשיבה, הרשאות, תיקיות, MCP). שינוי באחת מהן = תהליך חדש בתור הבא
  const argSig = (cfg, conv) => { try { return buildArgs(cfg, conv, { resume: null, appendSystem: '' }).join('\u0001') + '\u0001sub=' + (cfg.agentModel || '') + '\u0001trust=' + (deps.trustMode ? deps.trustMode() : '') + '\u0001think=' + (cfg.thinking || '') + '\u0001ultra=' + !!cfg.ultracode + '\u0001env=' + JSON.stringify(thinkOffEnv(cfg, conv)); } catch { return ''; } }; // מצב התקשורת בין Claude-ים, "תמיד לחשוב" ו-ULTRACODE נמצאים בהוראות המערכת — שינוי שלהם = תהליך חדש עם ההוראות החדשות · מודל הסוכנים משנה את סביבת התהליך
  // תהליך "חם" לכל שיחה: נשאר פתוח בין הודעות (נמדד: 2.5 → 0.8 שניות עד המילה הראשונה), נסגר אחרי 12 דקות בלי פעילות.
  // עד WARM_MAX תהליכים חמים במקביל (הישן ביותר נסגר). מחקרים לא נשארים חמים.
  const WARM_IDLE_MS = 12 * 60 * 1000, WARM_MAX = 4;
  function keepWarm(S) {
    if (S.remoteOn || S.keepAlive) return REMOTE_IDLE_MS;
    if (S.conv.kind === 'research' || S.conv.kind === 'watch-round' || process.env.CLAUDE_NO_WARM === '1') return 0; // סבב מעקב בחלון המעקב: תהליך חד-פעמי
    const idle = [...sessions.values()].filter(x => x !== S && !x.turn && !x.remoteOn && !x.keepAlive).sort((a, b) => a.lastActivity - b.lastActivity);
    while (idle.length >= WARM_MAX) disposeSession(idle.shift());
    return WARM_IDLE_MS;
  }

  function runTurn({ conv, cfg, emit, signal, state, cli, cwd, content, cmd }) {
    return new Promise(resolve => {
      let S = sessions.get(conv.id);
      if (S && (S.procDone || S.cwd !== cwd || (!S.turn && S.argSig && S.argSig !== argSig(cfg, conv)))) { disposeSession(S); S = null; }
      const reuse = !!S;
      const chromeTag = cmd === 'chrome' || cmd === 'chrome-browser' || cmd === 'built-in-browser'; if (chromeTag) cmd = null; // התגית "שליטה ב-Chrome" = הוראה להשתמש בכלי הדפדפן של האפליקציה, לא פקודת ה-/chrome של ה-CLI (שמחפשת תוסף)
      const pcTag = cmd === 'computer-use'; if (pcTag) cmd = null; // התגית "שליטה במחשב" = כלי desktop_* של האפליקציה (המסך, תוכנות, עכבר ומקלדת אמיתיים)
      let wire = withThinkPrefix(toWire(content, cmd), cfg.thinking, cmd);
      if (pcTag) wire.push({ type: 'text', text: '[The user selected computer control: do this request on his Windows PC like a person sitting at it, using the desktop_* tools (mcp__claudechat__desktop_screenshot, desktop_windows, desktop_window, desktop_ui, desktop_ui_action, desktop_click, desktop_type, desktop_key, desktop_open, ...). Read program windows as code with desktop_ui and act with desktop_ui_action when possible; use the real mouse and keyboard (desktop_click / desktop_type / desktop_key) when needed. For websites use the browser_* tools in his Chrome. Verify the result (desktop_ui or desktop_screenshot) before reporting.]' });
      if (chromeTag) wire.push({ type: 'text', text: '[The user selected browser control: do this request in the user own real Chrome (his profile, logins and open tabs) using the browser_* tools (mcp__claudechat__browser_tabs, browser_navigate, browser_snapshot, browser_click, browser_type, ...). If he refers to a tab he already has open, switch to it with browser_tabs action=switch (id or match) instead of opening a new one. Do not use the Claude in Chrome extension, Playwright, Selenium or a separate browser.]' });
      if (!S) {
        const resumeId = conv.cli && conv.cli.cwd === cwd ? (conv.cli.sessionId || conv.cli.forkFrom || null) : null;
        S = newSession(conv, cfg, cli, cwd, !!resumeId); S.resumeId = resumeId;
        S.liveModel = cfg.model; S.livePerm = cfg.permissionMode || (cfg.autoApprove === false ? 'default' : 'bypassPermissions'); S.liveThinking = cfg.thinking === 'off' ? 'off' : 'on'; S.liveEffort = cfg.effort || 'default'; // מה שהתהליך הופעל איתו (בשביל applyLive)
        if (conv.remoteControl) S.keepAlive = true;
        sessions.set(conv.id, S); // רשום כבר בזמן התור (גם תהליך שלא יישאר חם — סבב מעקב, מחקר): holdTurn של ה-Stop hook מוצא אותו
      } else { S.cfg = cfg; S.conv = conv; } // תהליך חם: אובייקט השיחה העדכני של התור הזה (אחרת התשובה נכתבת לעותק הישן ונדרסת)
      clearTimeout(S.idleT); S.lastActivity = Date.now(); S.thinkMode = cfg.thinking;
      const turn = { emit, state, signal, resolve, done: false, qTimer: null, cmd };
      // כפתור 🔬 (מחקר עמוק): רושמים מחקר שחלון המחקר מציג — שלבים, חוקרים (הסוכנים), מקורות ודוח
      const um = lastUserMsg(conv);
      if (um && um.research && researchMgr && researchMgr.createExternal) {
        const q = textOf(um.content) || conv.title;
        S.research = researchMgr.createExternal({ convId: conv.id, question: q, depth: (cfg.researchDepth || 'standard'), model: cfg.model, effort: cfg.ultracode ? 'ultracode' : (cfg.effort || ''), opts: conv.researchOpts || null, onStop: () => { try { stopConv(conv.id); } catch { } } });
        S.subsStarted = 0; S.subsRunning = 0; S.reportStreaming = false; S.topicDone = new Set(); S.topicFail = {}; S.topicSkip = new Set(); S.researchDepth = cfg.researchDepth || 'standard'; S.researchIssues = null; S.lastProg = null;
        S.researchOpts = conv.researchOpts || null; S.rounds = 0; S.noProgress = 0; S.lastRoundCount = null; S.gaveUp = false; S.summaryAsks = 0; S.topicsSeen = new Set(); S.fullText = ''; S.sentLen = 0; S.summaryOnly = false; S.lastSummary = false; S.skipResult = 0;
        conv.researchId = S.research.id; engineSave(conv);
        emit('research_started', { id: S.research.id, question: q });
      } else S.research = null;
      // תהליך חם: ה-result של התור הקודם מגיע לפעמים באיחור (נשטף רק כשנשלחת ההודעה הבאה) — אם לא הגיע, מדלגים עליו כדי שלא יסיים את התור החדש לפני הזמן
      if (reuse) S.skipResult = S.gotResult ? 0 : 1;
      S.turn = turn; S.turnOver = false; S.stopped = false; S.gotResult = false; S.turnMsgs = 0; S.apiError = null; clearTimeout(S.endTimer);
      S.turnUse = { input: 0, output: 0, cacheRead: 0, costUSD: 0, calls: 0, models: {}, startedAt: Date.now(), msgIdx: conv.messages.length };

      armTurn(S, turn);

      if (!reuse) {
        S.launch(!!S.resumeId);
        if (!S.resumeId && conv.messages.length > 1) {
          const prior = transcriptOf({ messages: conv.messages.slice(0, -1) });
          if (prior) wire = [{ type: 'text', text: '<previous_conversation>\n' + prior + '\n</previous_conversation>\n(The conversation above already happened in this chat — continue it naturally. The new message follows.)' }, ...wire];
        }
      }
      S.send({ type: 'user', message: { role: 'user', content: wire } }, 'u:' + conv.id + ':' + ((lastUserMsg(conv) || {}).ts || now()));
      emit('api_wait', { context: (conv.usage && conv.usage.context) || 0, compactAt: 0, engine: 'cli' });
    });
  }

  // armTurn: עצירה (abort) והזרקת הודעות שנכתבו בזמן עבודה. משותף לתור רגיל ולתור מאומץ אחרי הפעלה-מחדש
  function armTurn(S, turn) {
    const { signal, state, emit } = turn;
    const onAbort = () => {
      S.stopped = true;
      S.send({ type: 'control_request', request_id: 'int-' + now(), request: { subtype: 'interrupt' } }, 'int:' + S.conv.id + ':' + now());
      setTimeout(() => { if (S.turn === turn && !S.procDone) claude.killTree(S.proc); }, 3500);
    };
    signal.addEventListener('abort', onAbort, { once: true });
    turn.cleanup = () => { clearInterval(turn.qTimer); signal.removeEventListener('abort', onAbort); };
    // הודעות שנשלחות בזמן העבודה: מועברות ל-CLI (הוא קורא אותן בצעד הבא)
    turn.qTimer = setInterval(() => {
      if (S.procDone || S.turnOver || !state.queue.length) return;
      const conv = S.conv;
      const items = state.queue.splice(0); const w = [];
      for (const q of items) {
        // the sender travels with the message (another Claude / a watch round): never saved as the owner's own words
        // never stored between a tool_use and its tool_result (that split the assistant turn and orphaned results → API 400, Z380)
        pushUserSafe(S, { role: 'user', content: q.content, ts: q.ts, injected: true, ...(q.research ? { research: true } : {}), ...(q.cmd ? { cmd: q.cmd } : {}), ...(q.flow ? { flow: q.flow } : {}), ...(q.from ? { from: q.from } : {}), ...(q.fromInfo ? { fromInfo: q.fromInfo } : {}), ...(q.watch ? { watch: q.watch } : {}) });
        emit('user_injected', { id: q.id, ts: q.ts, content: q.content, silent: !!q.silent, ...(q.from ? { from: q.from } : {}), ...(q.fromInfo ? { fromInfo: q.fromInfo } : {}) });
        w.push(...withThinkPrefix(toWire(q.content, q.cmd), S.thinkMode || S.cfg.thinking, q.cmd)); // "תמיד" שהודלק באמצע עבודה — כבר בהודעה הבאה
      }
      const wid = 'q:' + crypto.createHash('sha1').update(items.map(q => q.id || q.ts).join(',')).digest('hex').slice(0, 16);
      engineSave(conv);
      S.send({ type: 'user', message: { role: 'user', content: w } }, wid);
      emit('api_wait', { context: (conv.usage && conv.usage.context) || 0, compactAt: 0, engine: 'cli' });
    }, 300);
  }

  // ---------- אימוץ אחרי הפעלה-מחדש של השרת: התהליך במארח המשיך לרוץ ----------
  const noopHandle = () => ({ addStep() { }, finish() { }, isDone: () => true, push() { }, setActivity() { }, setModel() { }, setUsage() { } });
  function restoreS(S, ck) {
    ck = ck || {};
    for (const k of ['sid', 'sawInit', 'servedModel', 'usedResume', 'resumeId', 'liveModel', 'livePerm', 'liveThinking', 'liveEffort', 'thinkMode', 'remoteOn', 'remoteUrl', 'keepAlive', 'skipResult', 'gotResult', 'turnOver', 'turnMsgs', 'stopped', 'apiError', 'awaitReplay', 'replaySeen', 'curMsg', 'turnUse']) if (ck[k] !== undefined) S[k] = ck[k];
    S.stderr = ck.stderrTail || '';
    S.blocks = ck.blocks || {};
    S.toolT0 = new Map(ck.toolT0 || []); S.msgUsage = new Map(ck.msgUsage || []); S.flushed = new Set(ck.flushed || []);
    S.sub = new Map((ck.sub || []).map(([k, v]) => {
      let handle = null;
      try { if (agentsMgr && agentsMgr.adoptExternal && v.agentId) handle = agentsMgr.adoptExternal(v.agentId, { onStop: () => { try { if (v.taskId) S.control('stop_task', { task_id: v.taskId }).catch(() => { }); } catch { } } }); } catch { }
      return [k, { ...v, handle: handle || noopHandle() }];
    }));
    const r = ck.research;
    if (r && researchMgr && researchMgr.adoptExternal) {
      try { S.research = researchMgr.adoptExternal(r.id, { onStop: () => { try { stopConv(S.conv.id); } catch { } } }); } catch { S.research = null; }
      if (S.research) {
        Object.assign(S, r); S.research = S.research; delete S.id;
        S.topicDone = new Set(r.topicDone || []); S.topicSkip = new Set(r.topicSkip || []); S.topicsSeen = new Set(r.topicsSeen || []);
        if (r.reportStreaming && r.fullText) { try { S.research.setReport(splitSummary(r.fullText, true).report); } catch { } }
      }
    } else S.research = null;
  }
  function attachHosted(S, sid) {
    S.hsid = sid; S.proc = deps.hostChild(sid);
    // frozen (ניתוק): שורות שמגיעות אחרי נקודת-השמירה האחרונה לא מיושמות כאן — ה-host שומר אותן (לא אושרו) ומעביר לשרת הבא
    S.proc.on('line', (seq, s, line) => { if (frozen) return; S.appliedSeq = seq; if (s === 'e') { S.stderr = (S.stderr + line + '\n').slice(-4000); return; } onLine(S, line); });
    S.proc.on('error', e => { if (frozen || hostLost(S, e)) return; endTurn(S, { fatal: 'Claude Code: ' + e.message }); });
    S.proc.on('close', code => { if (frozen) return; onClose(S, code); });
    try { S.proc.stdin.on('error', () => { }); } catch { }
  }
  // ה-host נפל באמצע (לא ניתוק מסודר): התהליך אבד — כמו יציאה של Claude: התור נסגר עם הודעה, והפעם הבאה מתחילה תהליך חדש (resume)
  function hostLost(S, e) {
    if (!e || e.code !== 'EHOSTLOST' || S.procDone) return false;
    if (S.proc && S.proc.exitCode === -1) return true; // לא היה מחובר בזמן ההפעלה: 'close' מגיע מיד אחרי — הוא סוגר
    S.stderr = (S.stderr + '\nתהליך Claude Local שמחזיק את Claude (host) נעצר בלי תיאום — Claude נקטע. שלח שוב כדי להמשיך.').slice(-4000);
    onClose(S, -1);
    return true;
  }
  // adoptTurn: תור שרץ בזמן ההפעלה-מחדש. ממשיכים מ-appliedSeq+1 — כל שורה מיושמת פעם אחת בדיוק
  function adoptTurn({ conv, cfg, emit, signal, state, live, cli }) {
    return new Promise(resolve => {
      const ck = live.ck || {};
      const S = newSession(conv, live.cfg ? { ...cfg, ...live.cfg } : cfg, cli || null, convWorkingDir(conv, cfg), !!ck.usedResume);
      S.argSig = live.argSig || ''; S.appliedSeq = live.appliedSeq || 0;
      restoreS(S, ck);
      attachHosted(S, live.hsid);
      sessions.set(conv.id, S);
      const turn = { emit, state, signal, resolve, done: false, qTimer: null, cmd: ck.cmd || null, adopted: true };
      S.turn = turn; const wasOver = !!S.turnOver; S.turnOver = false; S.lastActivity = Date.now();
      if (!S.turnUse) S.turnUse = { input: 0, output: 0, cacheRead: 0, costUSD: 0, calls: 0, models: {}, startedAt: Date.now(), msgIdx: conv.messages.length };
      armTurn(S, turn);
      for (const p of (ck.pendingWrites || [])) { try { S.proc.stdin.write(p.line, p.wid); } catch { } }
      for (const j of (ck.pendingCtl || [])) { try { handleControl(S, j); } catch { } }
      S.proc.attach(S.appliedSeq + 1).then(() => {
        engineSave(conv);
        if (S.proc.exitCode === null && S.proc._exitedInHost !== undefined && !S.procDone) return onClose(S, S.proc._exitedInHost);
        if (wasOver && S.turn === turn && !S.turnOver) turnEnded(S);
      });
    });
  }
  // adoptWarm: תהליך חם (בין תורות) שהמשיך לחיות — נכנס חזרה ל-sessions עם אותו זמן סגירה
  async function adoptWarm(conv, live) {
    let cli = null; try { cli = await claude.findClaude(); } catch { }
    const S = newSession(conv, live.cfg || {}, cli && cli.found ? cli : null, convWorkingDir(conv, live.cfg || {}), false);
    S.argSig = live.argSig || ''; S.appliedSeq = live.appliedSeq || 0;
    restoreS(S, live.ck); S.turn = null; S.turnOver = false;
    attachHosted(S, live.hsid);
    sessions.set(conv.id, S);
    S.proc.attach(S.appliedSeq + 1);
    S.idleUntil = live.idleUntil || (Date.now() + WARM_IDLE_MS);
    S.idleT = setTimeout(() => disposeSession(S), Math.max(0, S.idleUntil - Date.now()));
    return S;
  }
  // לפני ניתוק מסודר: נקודת-שמירה לכל סשן, ועצירת כל הטיימרים (המצב שלהם כבר נשמר)
  function checkpointAll() { for (const S of sessions.values()) { try { if (S.hsid) engineSave(S.conv); } catch (e) { console.error('[cli-engine] checkpoint', e); } } }
  // freeze: מכאן אין יישום של פלט מה-host בתהליך הזה (מיד לפני checkpointAll של הניתוק) — appliedSeq שנשמר = בדיוק מה שיושם
  let frozen = false;
  function freeze() { frozen = true; }
  function suspendTimers() { for (const S of sessions.values()) { clearTimeout(S.idleT); clearTimeout(S.endTimer); if (S.turn) clearInterval(S.turn.qTimer); } }

  function endTurn(S, res) {
    const t = S.turn; if (!t || t.done) return;
    t.done = true; t.cleanup(); S.awaitReplay = 0;
    if (S.heldUser && S.heldUser.length) { if (!flushHeldUser(S)) S.conv.messages.push(...S.heldUser.splice(0)); engineSave(S.conv); } // turn ended mid-tool (stop / crash): never lose a held message
    for (const s of S.sub.values()) if (!s.handle.isDone()) { s.handle.finish(S.stopped ? 'stopped' : 'done', { result: s.last || '' }); subDone(S, s, S.stopped ? 'stopped' : 'done'); }
    if (S.research && !S.research.isDone()) {
      // שימוש המחקר (כולל כל החוקרים) — בכל סיום: הושלם / נכשל / נעצר
      researchCost(S, false);
      if (S.stopped) S.research.finish('stopped');
      else if (res && res.fatal) S.research.finish('error', { error: res.fatal });
      else {
        if (S.apiError) S.research.finish(S.apiError.refusal ? 'refused' : 'error', { error: S.apiError.text, refusal: S.apiError.refusal ? S.apiError.text : null }); // לא "הושלם": Claude סירב / ה-API החזיר שגיאה
        else {
          const lastA = [...S.conv.messages].reverse().find(m => m.role === 'assistant');
          const raw = lastA ? textOf(lastA.content) : '';
          const sp = splitSummary(raw, false);
          if (sp.summary) S.research.setSummary(sp.summary);
          if (S.researchIssues && S.researchIssues.length) { if (sp.report.trim()) S.research.setReport(sp.report); S.research.finish('error', { error: 'המחקר לא הושלם: ' + S.researchIssues.join(' · ') }); } // "הושלם" רק כשכל הבדיקות עברו
          else if (sp.report.trim()) { S.research.setReport(sp.report); S.research.finish('done'); }
          else if (sp.summary && S.research.hasReport && S.research.hasReport()) S.research.finish('done'); // סבב "רק סיכום": הדוח כבר קיים
          else S.research.finish('error', { error: 'Claude סיים בלי לכתוב דוח (לא התקבלה תשובה).' });
        }
      }
    }
    flushUsage(S);
    // שימוש של ההודעה הזו (כולל סוכני משנה שהיא הפעילה): נשמר על התשובה האחרונה של התור, ומוצג מתחתיה
    if (S.turnUse && S.turnUse.calls) {
      const tu = S.turnUse, msgs = S.conv.messages;
      let li = -1; for (let i = msgs.length - 1; i >= Math.min(tu.msgIdx, msgs.length); i--) if (msgs[i].role === 'assistant') { li = i; break; }
      const rec = { input: tu.input, output: tu.output, costUSD: +tu.costUSD.toFixed(6), calls: tu.calls, agents: tu.agents || 0, models: Object.keys(tu.models), pct: deps.usagePct ? deps.usagePct(tu.costUSD) : null, ms: Date.now() - tu.startedAt };
      if (li >= 0) msgs[li].turnUsage = rec;
      S.emit('turn_usage', { idx: li, ...rec });
    }
    S.turnUse = null;
    engineSave(S.conv);
    S.turn = null; S.lastActivity = Date.now();
    const warmMs = !S.procDone && !S.stopped && !S.accountStale && !(res && res.fatal) ? keepWarm(S) : 0;
    if (warmMs) { // התהליך נשאר חם להודעה הבאה (Remote Control: 45 דקות; שיחה רגילה: 12 דקות בלי פעילות)
      clearTimeout(S.idleT); S.idleT = setTimeout(() => disposeSession(S), warmMs);
      S.idleUntil = Date.now() + warmMs;
      sessions.set(S.conv.id, S);
      if (S.hsid) engineSave(S.conv); // נקודת-שמירה "חם, בין תורות" — אחרי הפעלה-מחדש התהליך מאומץ כחם עם אותו זמן סגירה
    } else if (!S.procDone) { try { S.proc.stdin.end(); } catch { } setTimeout(() => { if (!S.procDone) claude.killTree(S.proc); }, 4000); sessions.delete(S.conv.id); }
    t.resolve(res || {});
  }
  function onClose(S, code) {
    S.procDone = true;
    if (S.usedResume && !S.sawInit && code !== 0 && /no conversation found|session/i.test(S.stderr)) { // --resume נכשל: מתחילים מחדש עם תמלול השיחה
      S.usedResume = false; S.conv.cli = { cwd: S.cwd, fresh: false };
      const t = S.turn;
      if (S.hsid) { const old = S.proc; S.hsid = null; try { if (old && typeof old.release === 'function') old.release(); } catch { } } // סשן host חדש לניסיון בלי resume
      S.launch(false);
      if (t) { const hist = S.conv.messages.length > 1 ? S.conv.messages.slice(0, -1) : (deps.fallbackHistory ? deps.fallbackHistory(S.conv) || [] : []); const prior = transcriptOf({ messages: hist }); /* סבב מעקב (fork שנכשל): ההיסטוריה של הצאט עצמו */ const last = lastUserContent(S.conv) || []; const w = toWire(last, (lastUserMsg(S.conv) || {}).cmd); if (prior) w.unshift({ type: 'text', text: '<previous_conversation>\n' + prior + '\n</previous_conversation>\n(Continue naturally. The new message follows.)' }); S.send({ type: 'user', message: { role: 'user', content: w } }); }
      return;
    }
    sessions.delete(S.conv.id); clearTimeout(S.idleT);
    if (S.hsid) { // התהליך ב-host הסתיים: מוחקים את נקודת-השמירה (אין מה לאמץ) ומשחררים את הסשן ב-host
      try { if (S.conv.cli) S.conv.cli.live = null; } catch { }
      const proc = S.proc; S.hsid = null;
      try { saveConv(S.conv); } catch { }
      try { if (proc && typeof proc.release === 'function') proc.release(); } catch { }
    }
    for (const p of S.ctl.values()) p.reject(new Error('process exited')); S.ctl.clear();
    if (S.turn && !S.stopped && !S.turnOver && code !== 0 && !S.gotResult) {
      const msg = S.stderr.trim().split('\n').slice(-3).join('\n') || ('Claude Code נסגר (קוד ' + code + ')');
      return endTurn(S, { fatal: /login|auth|credential|401|oauth/i.test(msg) ? 'לא מחובר לחשבון Claude (האימות פג). היכנס מחדש בהגדרות › חשבון.\n' + msg : msg });
    }
    endTurn(S, {});
  }
  // סיום תור: כשהתור הסתיים (end_turn) — (ב-v2.1.330 האירוע result לא תמיד מגיע עם partial messages, לכן לא תלויים בו)
  function turnEnded(S) {
    if (S.turnOver) return; S.turnOver = true; clearTimeout(S.endTimer);
    S.endTimer = setTimeout(() => {
      const t = S.turn; if (!t) return;
      if (t.state.queue.length) { S.turnOver = false; return; }
      // הודעה שנשלחה באמצע (למשל סבב מעקב שנכנס לתור) ו-Claude עוד לא קרא אותה: לא מסיימים — הוא יטפל בה מיד (עד 90 שניות בלי שום אירוע)
      if (S.replaySeen && S.awaitReplay > 0 && !S.stopped && Date.now() - (S.lastEvt || 0) < 90000) { S.turnOver = false; S.endTimer = setTimeout(() => turnEnded(S), 2000); return; }
      if (S.research && continueResearch(S)) return; // מינימום מקורות / נושאים / סיכום חסרים: חוזרים לעבוד, לא מסיימים
      endTurn(S, {});
    }, 700);
  }

  // ----- שימוש -----
  // טוקנים / עלות / אחוז של מחקר (השיחה הראשית + כל החוקרים שכבר נספרו). live = עדכון באמצע הריצה (כרטיס המחקר בצ'אט מתמלא)
  function researchCost(S, live) {
    let inT = 0, outT = 0, rc = 0;
    for (const [, m] of S.msgUsage) { inT += (m.usage.input_tokens || 0) + (m.usage.cache_read_input_tokens || 0) + (m.usage.cache_creation_input_tokens || 0); outT += m.usage.output_tokens || 0; rc += costOf ? costOf(m.model || S.servedModel, { ...m.usage, cache_creation: { ephemeral_1h_input_tokens: m.usage.cw1h || 0 } }) : 0; }
    // חוקרים שעוד עובדים: הטוקנים שלהם (מ-task_progress) נכנסים כבר עכשיו; העלות והאחוז המדויקים — כשהחוקר מסיים (מהקובץ שלו)
    if (live) for (const s of S.sub.values()) if (!s.accounted && s.liveTok) inT += s.liveTok;
    S.research.setCost(rc, { input: inT, output: outT }, deps.usagePct ? deps.usagePct(rc) : null, live);
  }
  function noteUsage(S, id, model, usage) {
    if (!id || !usage) return;
    const prev = S.msgUsage.get(id);
    const num = Object.fromEntries(Object.entries(usage).filter(([, v]) => typeof v === 'number'));
    if (usage.cache_creation && typeof usage.cache_creation.ephemeral_1h_input_tokens === 'number') num.cw1h = usage.cache_creation.ephemeral_1h_input_tokens;
    const merged = { ...(prev ? prev.usage : {}), ...num };
    S.msgUsage.set(id, { model: model || (prev && prev.model), usage: merged });
    if (S.research && !S.research.isDone() && Date.now() - (S.resCostAt || 0) > 1500) { S.resCostAt = Date.now(); try { researchCost(S, true); } catch { } }
  }
  function flushUsage(S) {
    const conv = S.conv; const perModel = {}; let inT = 0, outT = 0, n = 0;
    for (const [id, m] of S.msgUsage) {
      if (S.flushed.has(id)) continue; S.flushed.add(id); n++;
      const u = m.usage, model = m.model || S.servedModel;
      inT += (u.input_tokens || 0) + (u.cache_read_input_tokens || 0) + (u.cache_creation_input_tokens || 0); outT += u.output_tokens || 0;
      const pm = perModel[model] = perModel[model] || { usage: { input_tokens: 0, output_tokens: 0, cache_read_input_tokens: 0, cache_creation_input_tokens: 0, cw1h: 0 } };
      for (const k of Object.keys(pm.usage)) pm.usage[k] += u[k] || 0;
    }
    if (!n) return;
    conv.usage.input += inT; conv.usage.output += outT;
    let g = null, cost = 0;
    for (const [model, pm] of Object.entries(perModel)) {
      const { cw1h, ...rest } = pm.usage; pm.usage = { ...rest, cache_creation: { ephemeral_1h_input_tokens: cw1h } };
      g = recordUsage(model, pm.usage) || g;
      const c = costOf ? costOf(model, pm.usage) : 0; cost += c;
      const tu = S.turnUse; if (tu) { const mm = tu.models[model] = tu.models[model] || { input: 0, output: 0, costUSD: 0 }; mm.input += pm.usage.input_tokens + pm.usage.cache_read_input_tokens + pm.usage.cache_creation_input_tokens; mm.output += pm.usage.output_tokens; mm.costUSD += c; }
    }
    // שימוש של כל השיחה: טוקנים, עלות בתעריף API ואחוז מהמנוי (כל אחוז מחושב ברגע ההודעה)
    conv.usage.costUSD = (conv.usage.costUSD || 0) + cost;
    const pc = deps.usagePct ? deps.usagePct(cost) : null;
    if (pc) { conv.usage.pct = conv.usage.pct || {}; for (const [k, v] of Object.entries(pc)) conv.usage.pct[k] = (conv.usage.pct[k] || 0) + v; }
    if (S.turnUse) { const tu = S.turnUse; tu.input += inT; tu.output += outT; tu.costUSD += cost; tu.calls += n; }
    S.emit('usage', { ...conv.usage, global: g });
  }
  function liveUsageEmit(S) {
    let inT = 0, outT = 0;
    for (const [id, m] of S.msgUsage) { if (S.flushed.has(id)) continue; const u = m.usage; inT += (u.input_tokens || 0) + (u.cache_read_input_tokens || 0) + (u.cache_creation_input_tokens || 0); outT += u.output_tokens || 0; }
    S.emit('usage', { input: S.conv.usage.input + inT, output: S.conv.usage.output + outT, context: S.conv.usage.context, live: true });
  }

  // ----- קריאת stdout -----
  function onStdout(S, d) {
    S.buf += d; let i;
    while ((i = S.buf.indexOf('\n')) >= 0) {
      const line = S.buf.slice(0, i); S.buf = S.buf.slice(i + 1);
      onLine(S, line);
    }
  }
  // שורת NDJSON בודדת (מתהליך רגיל דרך onStdout, או מ-HostChild דרך אירוע 'line')
  function onLine(S, line) {
    line = (line || '').trim(); if (!line) return;
    let j; try { j = JSON.parse(line); } catch { return; }
    try { handle(S, j); } catch (e) { console.error('[cli-engine] handle', e); }
  }
  function handle(S, j) {
    const parent = j.parent_tool_use_id || null;
    if (process.env.CLAUDE_DEBUG_TURNS) console.log('[turn]', Date.now() % 100000, S.conv.id.slice(0, 6), j.type, j.subtype || (j.event && j.event.type) || '', j.event && j.event.delta && j.event.delta.stop_reason || '', 'turn=' + !!S.turn, 'msgs=' + (S.turnMsgs || 0), 'skip=' + (S.skipResult || 0));
    S.lastEvt = Date.now();
    // הודעה מצ'אט אחר של Claude (origin.kind=peer) מגיעה כ-user עם isReplay — לרשום אותה לפני הדילוג על "הד" של הודעות שלנו
    if (j.type === 'user' && !j.parent_tool_use_id && j.origin && j.origin.kind === 'peer') { notePeerMessage(S, j); return; }
    if (j.type === 'user' && j.isReplay) { S.replaySeen = true; if (S.awaitReplay > 0) S.awaitReplay--; return; } // ה-CLI קרא הודעה ששלחנו (לא הודעה חדשה לשמור)
    switch (j.type) {
      case 'system': return handleSystem(S, j);
      case 'rate_limit_event': { const u = claude.applyRateLimitEvent(j.rate_limit_info); S.emit('rate_limit', { info: j.rate_limit_info, usage: u }); return; }
      case 'stream_event': return parent ? handleSubStream(S, parent, j.event) : handleStream(S, j.event);
      case 'assistant': return parent ? handleSubAssistant(S, parent, j.message) : handleAssistant(S, j.message);
      case 'user': return parent ? handleSubUser(S, parent, j.message) : handleUser(S, j.message, j.tool_use_result || j.toolUseResult || null);
      case 'control_request': return handleControl(S, j);
      case 'control_response': { const r = j.response || {}; const p = S.ctl.get(r.request_id); if (p) { S.ctl.delete(r.request_id); r.subtype === 'success' ? p.resolve(r.response) : p.reject(new Error(r.error || 'control error')); } return; }
      case 'result': {
        // ב-v2.1.330 עם partial messages האירוע result מגיע באיחור (נשטף רק בהודעה הבאה) — לכן סוף תור נקבע לפי message_delta.
        // result שמגיע לפני שהתחילה הודעה בתור הנוכחי הוא "שאריות" של התור הקודם ומתעלמים ממנו, אלא אם זו שגיאה.
        if (S.skipResult > 0) { S.skipResult--; return; } // result של הסבב הקודם (אחרי הוראת "תמשיך לחקור")
        S.gotResult = true;
        // עצור: ה-CLI עונה ל-interrupt ב-result עם subtype=error_during_execution (terminal_reason=aborted_tools). זו עצירה, לא שגיאה — בלי באנר שגיאה
        if (j.is_error && cliUserStop(S, j)) { if (!S.stopped) S.emit('notice', { text: 'Claude נעצר: הפעולה בוטלה לפי בקשה. אפשר להמשיך לכתוב, והשיחה ממשיכה מאותה נקודה.', info: true }); turnEnded(S); return; }
        if (j.is_error && /^error/.test(String(j.subtype || ''))) return endTurn(S, { fatal: cliErrorText(S, j) }); // שגיאת ביצוע אמיתית: הודעה בעברית עם הסיבה שה-CLI מסר (נשמרת בשיחה ומוצגת באדום)
        if (j.is_error) { S.emit('notice', { text: 'Claude Code: ' + String(j.result || j.subtype), info: false }); if (!S.turnMsgs) { S.turnOver = false; turnEnded(S); } else turnEnded(S); }
        else if (S.turnMsgs || (S.turn && S.turn.cmd && j.num_turns === 0)) turnEnded(S); // פקודת / מקומית (למשל /context): תשובה בלי הודעת מודל — result עם num_turns=0
        return;
      }
      default: return;
    }
  }

  function handleSystem(S, j) {
    const conv = S.conv;
    if (j.subtype === 'init') {
      S.sawInit = true; S.sid = j.session_id;
      { const { forkFrom, ...rest } = conv.cli || {}; conv.cli = { ...rest, ...(forkFrom ? { forkedFrom: forkFrom } : {}), sessionId: j.session_id, cwd: S.cwd, model: j.model, fresh: true, tools: (j.tools || []).length }; }
      if (conv.shadowOf) { try { engineSave(conv); } catch { } } // סבב מעקב: מזהה ה-fork נשמר מיד — גם אם התוכנה תיסגר באמצע, הסשן יימחק בהפעלה הבאה
      if (j.model) S.servedModel = j.model;
      S.emit('cli_init', { sessionId: j.session_id, model: j.model, tools: j.tools, mcp: j.mcp_servers, permissionMode: j.permissionMode, version: j.claude_code_version });
      if (conv.remoteControl && !S.remoteOn) enableRemote(S).catch(e => { S.keepAlive = false; S.emit('notice', { text: 'Remote Control לא הופעל: ' + e.message, info: false }); });
    } else if (j.subtype === 'thinking_tokens') S.emit('thinking_tokens', { tokens: j.estimated_tokens });
    else if (j.subtype === 'task_started') {
      const s = S.sub.get(j.tool_use_id);
      if (s) { s.taskId = j.task_id; s.handle.setActivity('מתחיל…'); if (j.subagent_type) s.handle.setModel(j.subagent_type); }
    } else if (j.subtype === 'task_progress') {
      const s = S.sub.get(j.tool_use_id);
      if (s) { if (!s.usageFinal) s.handle.setUsage({ tokens: (j.usage && j.usage.total_tokens) || 0, steps: (j.usage && j.usage.tool_uses) || 0 }); if (j.description) s.handle.setActivity(short(j.description, 90)); }
      if (s && j.usage && j.usage.total_tokens) { s.liveTok = j.usage.total_tokens; if (S.research && !S.research.isDone() && Date.now() - (S.resCostAt || 0) > 1500) { S.resCostAt = Date.now(); try { researchCost(S, true); } catch { } } } // טוקנים של חוקרים בזמן שהם עובדים
    } else if (j.subtype === 'task_notification') {
      const s = S.sub.get(j.tool_use_id);
      if (s && !s.handle.isDone()) {
        const st = j.status === 'completed' ? 'done' : /killed|stopped|cancel/.test(j.status || '') ? 'stopped' : /fail|error/.test(j.status || '') ? 'error' : 'done';
        s.handle.finish(st, { result: s.last || j.summary || '', error: st === 'error' ? j.summary : null }); subDone(S, s, st);
      }
    } else if (j.subtype === 'compact_boundary' || j.subtype === 'compaction') S.emit('compaction', {});
  }

  async function enableRemote(S) {
    const r = await S.control('remote_control', { enabled: true, name: S.conv.title || 'Claude Local Chat' }, 45000);
    S.remoteOn = true; S.keepAlive = true; S.remoteUrl = (r && r.session_url) || null;
    S.conv.cli = { ...(S.conv.cli || {}), remoteUrl: S.remoteUrl }; engineSave(S.conv);
    S.emit('remote_control', { enabled: true, url: S.remoteUrl });
  }

  // ----- הודעת הראשי: סטרימינג חי -----
  function handleStream(S, ev) {
    const conv = S.conv;
    switch (ev.type) {
      case 'message_start': {
        if (ev.message && ev.message.model) S.servedModel = ev.message.model;
        S.turnOver = false; clearTimeout(S.endTimer); S.curMsg = ev.message || {}; S.turnMsgs = (S.turnMsgs || 0) + 1; (S.streamIds || (S.streamIds = new Set())).add(S.curMsg.id);
        S.emit('model', { model: S.servedModel });
        if (ev.message && ev.message.usage) { noteUsage(S, ev.message.id, ev.message.model, ev.message.usage); conv.usage.context = (ev.message.usage.input_tokens || 0) + (ev.message.usage.cache_read_input_tokens || 0) + (ev.message.usage.cache_creation_input_tokens || 0); }
        S.blocks = {}; break;
      }
      case 'content_block_start': {
        const b = ev.content_block || {};
        S.blocks[ev.index] = { type: b.type, id: b.id, name: b.name, json: '', t0: Date.now() };
        if (b.type === 'text') S.emit('text_start', {});
        else if (b.type === 'thinking') S.emit('thinking_start', {});
        else if (b.type === 'tool_use') { S.toolT0.set(b.id, Date.now()); S.emit('tool_start', { id: b.id, name: b.name }); }
        else if (b.type === 'server_tool_use') S.emit('server_tool_start', { id: b.id, name: b.name });
        break;
      }
      case 'content_block_delta': {
        const b = S.blocks[ev.index], d = ev.delta || {}; if (!b) break;
        if (d.type === 'text_delta') { S.emit('text', { text: d.text }); if (S.research && S.subsStarted > 0 && S.subsRunning === 0) { if (!S.reportStreaming) { S.reportStreaming = true; S.fullText = ''; S.sentLen = 0; S.research.setPhase('writing', 'כותב את הדוח…'); S.research.setReport(''); } feedReport(S, d.text); } }
        else if (d.type === 'thinking_delta') S.emit('thinking', { text: d.thinking });
        else if (d.type === 'input_json_delta') b.json += d.partial_json;
        break;
      }
      case 'content_block_stop': {
        const b = S.blocks[ev.index]; if (!b) break;
        if (b.type === 'tool_use') { let input = {}; try { input = b.json ? JSON.parse(b.json) : {}; } catch { } S.emit('tool_input', { id: b.id, name: b.name, input }); }
        else if (b.type === 'thinking') S.emit('thinking_stop', { ms: Date.now() - b.t0 });
        break;
      }
      case 'message_delta': {
        if (ev.usage && S.curMsg) noteUsage(S, S.curMsg.id, S.servedModel, ev.usage);
        liveUsageEmit(S);
        const sr = ev.delta && ev.delta.stop_reason;
        if (sr) {
          if (sr !== 'tool_use' && sr !== 'pause_turn') turnEnded(S);
          if (sr === 'refusal') { if (!S.apiError) S.apiError = { text: 'המודל החזיר סירוב (stop_reason: refusal): מסנן הבטיחות חסם את הבקשה.', refusal: true }; S.emit('api_error', { refusal: true, text: 'stop_reason: refusal' }); S.emit('notice', { text: 'מסנן הבטיחות של המודל חסם את הבקשה. אפשר לנסח אחרת או לבחור מודל אחר.', info: false }); }
        }
        break;
      }
      default: break;
    }
  }

  // הזרמת הדוח לחלון המחקר: הטקסט עד תגית הסיכום = דוח; מה שאחריה = חלונית הסיכום
  function feedReport(S, delta) {
    S.fullText = (S.fullText || '') + delta;
    const sp = splitSummary(S.fullText, true);
    if (sp.report.length > (S.sentLen || 0)) { S.research.appendReport(sp.report.slice(S.sentLen || 0)); S.sentLen = sp.report.length; }
    if (sp.summary != null) { S.lastSummary = true; S.research.setSummary(sp.summary); }
  }
  // אכיפה: Claude לא יכול לסיים לפני שעמד בדרישות שהמשתמש קבע. מחזיר true אם נשלחה לו הוראת המשך (והתור לא נגמר)
  function continueResearch(S) {
    const R = S.research; if (!R || R.isDone() || S.stopped || S.procDone || !S.turn || S.apiError) return false;
    const o = S.researchOpts || {};
    const n = R.sourceCount();
    if (!S.lastSummary) { const la = [...S.conv.messages].reverse().find(m => m.role === 'assistant'); if (la && splitSummary(textOf(la.content), false).summary != null) S.lastSummary = true; }
    const parts = []; let heavy = false, askSummary = false;
    const rounds = S.rounds || 0;
    // התקדמות = מקורות שנקראו + נושאים שנחקרו + חוקרים שיצאו. אחרי NO_PROGRESS_MAX סבבים בלי שום התקדמות (או MAX_ROUNDS) מפסיקים לדחוף, והסטטוס הסופי אומר בכנות מה חסר
    const prog = n + '|' + (S.topicDone ? S.topicDone.size : 0) + '|' + (S.subsStarted || 0);
    if (rounds > 0 && S.lastProg != null) S.noProgress = prog !== S.lastProg ? 0 : (S.noProgress || 0) + 1;
    const canPush = rounds < MAX_ROUNDS && (S.noProgress || 0) < NO_PROGRESS_MAX;
    // ---- הבדיקות (תמיד — גם כשנגמרו הניסיונות, כדי שהסטטוס יהיה אמיתי) ----
    // נושאים: TOPIC-1 = הבקשה הראשית שלך (תמיד), ואחריה הנושאים שבחרת / שהמחולל יצר. נושא "נחקר" רק כשחוקר שלו סיים עם ממצאים
    const topicsAll = ['the user\'s main request (the full research message)', ...(o.topics || [])];
    const issues = [], push = [];
    if (S.subsRunning > 0) { issues.push(`${S.subsRunning} חוקרים עדיין רצים`); push.push(`- RESEARCHERS STILL RUNNING: ${S.subsRunning} researcher sub-agent(s) have not finished. Do not write the report yet: wait for every researcher, then write the complete report. (In this research launch researchers in the FOREGROUND only — several Agent calls in one message already run in parallel.)`); }
    if (o.minSources > 0 && n < o.minSources) {
      issues.push(`נקראו ${n} מקורות מתוך מינימום ${o.minSources}`);
      // כמות חוקרים קבועה שכבר נוצלה: אסור עוד חוקרים — Claude קורא את הדפים החסרים בעצמו
      const usedAll = o.agents && o.agents.mode === 'fixed' && (S.subsStarted || 0) >= o.agents.n;
      push.push(`- MINIMUM SOURCES NOT REACHED: only ${n} distinct sources were actually READ (a source = a web page that loaded with WebFetch; failed/blocked pages (403, 404, timeouts) and search-result listings do not count). The user requires AT LEAST ${o.minSources}${o.maxSources ? ' (and at most ' + o.maxSources + ')' : ''}. ` +
        (usedAll ? `The number of researchers is fixed at ${o.agents.n} and all were used, so read the missing ${o.minSources - n} page(s) YOURSELF now: WebSearch, then open NEW pages with WebFetch — prefer pages that load (official / government sites, Wikipedia, news sites, manufacturers) and skip sites that already failed — until the app's counter reaches ${o.minSources}.`
          : `Launch more researcher sub-agents in parallel on NEW angles that open and read more pages (WebFetch) until the app's counter reaches ${o.minSources}.`));
    }
    const notDoneAll = topicsAll.map((t, i) => i + 1).filter(k => !(S.topicDone && S.topicDone.has(k)) && !(S.topicSkip && S.topicSkip.has(k))); // נושא שעצרת — לא נדרש שוב
    // נושא שנכשל 20 פעמים (5 × 4 מודלים): לא דוחפים עוד — הסטטוס הסופי יגיד שלא נחקר
    const dead = notDoneAll.filter(k => ((S.topicFail || {})[k] || 0) >= RESEARCHER_MODELS.length * RESEARCHER_TRIES);
    if (dead.length) issues.push('נושאים שנכשלו 20 פעמים: ' + dead.map(k => 'TOPIC-' + k).join(', '));
    const notDone = notDoneAll.filter(k => !dead.includes(k));
    if (notDone.length) {
      issues.push('נושאים שלא נחקרו: ' + notDone.map(k => 'TOPIC-' + k).join(', '));
      // חוקר שנכשל / סירב: מנסים שוב — 5 פעמים בכל מודל: Opus 5.5 → Opus 4.8 → Opus 4.6 → Sonnet 4.6 (עד 20)
      const typ = k => { const f = (S.topicFail || {})[k] || 0; return f ? researcherFor(f)[0] : null; };
      push.push(`- TOPICS WITHOUT FINDINGS: these topics have no researcher that FINISHED with real findings: ${notDone.map(k => `TOPIC-${k}: ${topicsAll[k - 1]}${typ(k) ? ` (failed ${(S.topicFail || {})[k]} time(s); relaunch it with the Agent parameter subagent_type:"${typ(k)}")` : ''}`).join(' | ')}. Launch (or relaunch) one dedicated researcher sub-agent for each of them NOW, in the foreground, all in one message; the description must start exactly with "TOPIC-<n>:".`);
    }
    const want = o.agents && o.agents.mode === 'fixed' ? o.agents.n : o.agents && o.agents.mode === 'topics' ? topicsAll.length : 0;
    if (want && (S.subsStarted || 0) < want) { issues.push(`יצאו ${S.subsStarted || 0} חוקרים מתוך ${want}`); push.push(`- NOT ENOUGH RESEARCHERS: the user requires EXACTLY ${want} researcher sub-agents; only ${S.subsStarted || 0} were launched. Launch ${want - (S.subsStarted || 0)} more now (dividing the topics / angles among them), in the foreground, in one message.`); }
    // הדוח עצמו: לא הודעת ביניים ("ממתין לסוכנים"), ובאורך שמתאים לעומק המחקר
    if (!push.length) {
      const la = [...S.conv.messages].reverse().find(m => m.role === 'assistant');
      const rep = la ? splitSummary(textOf(la.content), false).report : '';
      const words = (rep.match(/\S+/g) || []).length, minW = { quick: 150, standard: 350, deep: 600 }[S.researchDepth || 'standard'] || 300;
      if (words < minW || /ממתין לסיום|אשגר את|waiting for (the )?(sub-?agents|researchers)|once the (sub-?agents|researchers) (finish|complete)/i.test(rep.slice(0, 600))) {
        issues.push(`הדוח קצר מדי (${words} מילים) או שאינו דוח סופי`);
        push.push(`- THE FINAL REPORT IS MISSING: your last answer (${words} words) is not a complete final report. Write the COMPLETE final report NOW from all the researchers' findings (at least ${minW} words, well structured, with inline source links), then the <research_summary> block.`);
      }
    }
    S.researchIssues = issues; S.lastProg = prog;
    if (push.length && canPush) { heavy = true; parts.push(...push); }
    if (!canPush && o.minSources > 0 && n < o.minSources && !S.gaveUp) { S.gaveUp = true; R.markMissed(true); }
    if (heavy) S.lastRoundCount = n;
    // מקסימום מקורות: הדוח לא מצטט מקורות מעבר לאלה שנספרו (חיפוש אחד מחזיר ~10 תוצאות; מה שמעבר למקסימום לא נספר — ואסור לצטט אותו)
    let rewrite = false;
    if (!heavy && o.maxSources > 0 && (S.citeAsks || 0) < 2 && R.sourceUrls) {
      const la = [...S.conv.messages].reverse().find(m => m.role === 'assistant');
      const extra = citedOutside(la ? textOf(la.content) : '', R.sourceUrls());
      if (extra.length) {
        rewrite = true; S.citeAsks = (S.citeAsks || 0) + 1;
        parts.push(`- TOO MANY SOURCES CITED: the user allowed AT MOST ${o.maxSources} sources, and these ${R.sourceUrls().length} were collected:\n${R.sourceUrls().map((u, i) => `[${i + 1}] ${u}`).join('\n')}\nYour answer also cites ${extra.length} other source(s): ${extra.slice(0, 10).join(' , ')}. Rewrite the COMPLETE final report and the <research_summary> block citing ONLY the sources listed above (no other links). Do not search again.`);
      }
    }
    if (!S.lastSummary && (S.summaryAsks || 0) < MAX_SUMMARY_ASKS && !heavy && !rewrite) { askSummary = true; parts.push(`- THE SUMMARY BLOCK IS MISSING. Reply now with ONLY the <research_summary>...</research_summary> block (the extremely accurate concise summary of the whole research, exactly in the requested format), nothing else.`); }
    if (!parts.length) return false;
    const text = '[Research supervisor] Your answer cannot be accepted yet:\n' + parts.join('\n') + (heavy ? '\nWhen the requirements above are met, rewrite the COMPLETE final report, then the <research_summary> block. Do not add a sources list.' : '');
    if (heavy) { S.rounds = rounds + 1; R.setRounds(S.rounds); R.setReport(''); S.reportStreaming = false; S.fullText = ''; S.sentLen = 0; S.lastSummary = false; S.summaryOnly = false; R.setPhase('researching', `ממשיך לחקור — נאספו ${n}${o.minSources ? ' מתוך ' + o.minSources : ''} מקורות (סבב ${S.rounds})…`); }
    else if (rewrite) { R.setReport(''); S.reportStreaming = false; S.fullText = ''; S.sentLen = 0; S.lastSummary = false; S.summaryOnly = false; R.setPhase('writing', `מבקש מ-Claude לכתוב מחדש רק עם ${R.sourceUrls().length} המקורות שנספרו (מקסימום ${o.maxSources})…`); }
    else if (askSummary) { { const la = [...S.conv.messages].reverse().find(m => m.role === 'assistant'); const sp0 = la ? splitSummary(textOf(la.content), false) : null; if (sp0 && sp0.report.trim() && !R.hasReport()) R.setReport(sp0.report); } S.summaryAsks = (S.summaryAsks || 0) + 1; S.summaryOnly = true; S.reportStreaming = true; S.fullText = ''; S.sentLen = 0; R.setPhase('writing', 'מבקש מ-Claude את הסיכום…'); }
    const conv = S.conv; const ts = now();
    conv.messages.push({ role: 'user', content: [{ type: 'text', text, hidden: true }], ts, injected: true });
    S.emit('user_injected', { id: 'sup-' + ts, ts, content: [{ type: 'text', text, hidden: true }], silent: true });
    engineSave(conv);
    S.skipResult = S.gotResult ? 0 : 1; S.gotResult = false; S.turnOver = false; S.turnMsgs = 0;
    S.send({ type: 'user', message: { role: 'user', content: [{ type: 'text', text }] } });
    S.emit('api_wait', { context: (conv.usage && conv.usage.context) || 0, compactAt: 0, engine: 'cli' });
    return true;
  }

  // סירוב / שגיאת API: Claude Code מחזיר "הודעה סינתטית" (model '<synthetic>') שמתחילה ב-"API Error". סירוב של מסנן הבטיחות
  // (safeguards / usage policy / [cyber]) הוא לא "סיום תקין" — המחקר חייב להסתיים כ"סירב" ולא כ"הושלם".
  const REFUSAL_RE = /safeguard|usage[ -]policy|acceptable use|\[cyber\]|flagged (this|the) (session|request)|can'?t respond to your last message|refus/i;
  // result עם שגיאה: עצירה (Stop / interrupt שנשלח מעצירת סוכן / Remote Control) או שגיאת ביצוע אמיתית
  const cliUserStop = (S, j) => !!(S.stopped || (S.interruptTurn && S.interruptTurn === S.turn) || /^abort|interrupt/i.test(String(j.terminal_reason || '')));
  const CLI_ERR_HE = { error_during_execution: 'שגיאה בזמן הביצוע', error_max_turns: 'הגעה למספר הצעדים המרבי', error_max_budget_usd: 'הגעה לתקציב המרבי', error_max_structured_output_retries: 'כישלון ביצירת פלט במבנה הנדרש' };
  function cliErrorText(S, j) {
    const det = [].concat(Array.isArray(j.errors) ? j.errors : (j.errors ? [j.errors] : []), typeof j.result === 'string' ? [j.result] : []).map(x => String(typeof x === 'string' ? x : JSON.stringify(x)).trim()).filter(Boolean);
    if (j.terminal_reason && j.terminal_reason !== 'completed') det.push('terminal_reason: ' + j.terminal_reason);
    if (j.api_error_status) det.push('API status: ' + j.api_error_status);
    if (!det.length) { const e = String(S.stderr || '').trim().split('\n').slice(-3).join('\n').trim(); if (e) det.push(e); }
    return `Claude Code הפסיק לעבוד בגלל ${CLI_ERR_HE[j.subtype] || 'שגיאה'} (${j.subtype}).\n` + (det.length ? 'הסיבה שה-CLI מסר: ' + det.join(' · ') : 'ה-CLI לא מסר פירוט נוסף.') + '\nאפשר לשלוח הודעה כדי להמשיך מאותה נקודה.';
  }
  function noteApiError(S, msg, blocks) {
    if (!(msg.model === '<synthetic>' || msg.isApiErrorMessage)) return;
    const text = blocks.filter(b => b.type === 'text').map(b => b.text).join(' ').trim();
    if (!/^API Error/i.test(text) && !REFUSAL_RE.test(text)) return;
    S.apiError = { text, refusal: REFUSAL_RE.test(text) };
    S.emit('api_error', { refusal: S.apiError.refusal, text: text.slice(0, 300) }); // לצלילים: "Claude סירב" / "שגיאה"
  }
  // ---- tool-pair integrity: a user message that arrives while a tool call is open (tool_use stored, its tool_result not yet)
  // is HELD and stored right after the results. Storing it in between split the assistant turn (the next parallel tool_use
  // went into a new message) and left tool_results without their tool_use → "unexpected tool_use_id" 400 on every send.
  function openToolUse(conv) {
    const last = conv.messages[conv.messages.length - 1];
    return !!(last && last.role === 'assistant' && Array.isArray(last.content) && last.content.some(b => b && b.type === 'tool_use'));
  }
  function pushUserSafe(S, m) {
    if (openToolUse(S.conv)) { (S.heldUser || (S.heldUser = [])).push(m); return false; }
    S.conv.messages.push(m); return true;
  }
  function flushHeldUser(S) {
    if (!S.heldUser || !S.heldUser.length || openToolUse(S.conv)) return false;
    S.conv.messages.push(...S.heldUser.splice(0)); return true;
  }
  function handleAssistant(S, msg) {
    const conv = S.conv;
    if (!msg || !Array.isArray(msg.content)) return;
    noteUsage(S, msg.id, msg.model, msg.usage);
    if (msg.model) S.servedModel = msg.model;
    const blocks = msg.content.map(b => {
      if (b.type === 'text') return { type: 'text', text: b.text };
      if (b.type === 'thinking') return { type: 'thinking', thinking: b.thinking || '', signature: b.signature || '' };
      if (b.type === 'tool_use') { const { caller, ...rest } = b; return rest; }
      return b;
    }).filter(b => !(b.type === 'text' && !b.text));
    if (!blocks.length) return;
    noteApiError(S, msg, blocks);
    // הודעה שלא הגיעה בסטרימינג (תשובה של פקודת / מקומית): מציגים אותה בבת אחת
    if (!(S.streamIds && S.streamIds.has(msg.id))) for (const b of blocks) if (b.type === 'text') { S.emit('text_start', {}); S.emit('text', { text: b.text }); }
    const last = conv.messages[conv.messages.length - 1];
    if (last && last.role === 'assistant' && last.cliMsgId === msg.id) {
      for (const b of blocks) { if (b.type === 'tool_use' && last.content.some(x => x.type === 'tool_use' && x.id === b.id)) continue; last.content.push(b); }
      last.doneAt = now();
    } else conv.messages.push({ role: 'assistant', content: blocks, ts: now(), doneAt: now(), model: msg.model || S.servedModel, cliMsgId: msg.id, thinkingMs: [] });
    for (const b of blocks) if (b.type === 'tool_use') { (S.toolNames || (S.toolNames = new Map())).set(b.id, { name: b.name, input: b.input }); if (S.research && b.name === 'WebSearch' && b.input && b.input.query) S.research.addQuery(b.input.query, null); if (TASK_TOOLS.has(b.name)) startSubAgent(S, b); }
    engineSave(conv);
  }
  // מקורות למחקר: תוצאות WebSearch (כותרות + כתובות) ודפים ש-WebFetch קרא
  // מקור = דף שנקרא בפועל (WebFetch שהצליח). תוצאות חיפוש הן "נראו" בלבד — לא מקורות (אחרת 60 חיפושים = 600 "מקורות")
  function collectSources(S, name, input, text, isError) {
    if (!S.research) return;
    // מקור נספר רק מההוק PostToolUse (/api/hook/<id>/post) — כלל אחד לכל הסוכנים: דף שחזר בהצלחה (לא קוד 4xx/5xx)
    if (name === 'WebFetch') return;
    if (name !== 'WebSearch') return;
    const seenU = new Set();
    for (const m of String(text || '').matchAll(/"title"\s*:\s*"((?:[^"\\]|\\.)*)"\s*,\s*"url"\s*:\s*"([^"]+)"/g)) { seenU.add(m[2]); S.research.seen(m[2], m[1].replace(/\\"/g, '"')); }
    for (const m of String(text || '').matchAll(/https?:\/\/[^\s"'<>)\]]+/g)) if (!seenU.has(m[0])) { seenU.add(m[0]); S.research.seen(m[0], ''); }
  }
  function subDone(S, s, status) {
    if (!S.research || s.subDone) return; s.subDone = true;
    S.subsRunning = Math.max(0, (S.subsRunning || 0) - 1);
    S.research.updateSub(s.subIdx, { status, activity: status === 'done' ? 'הסתיים' : status, findings: s.last || '' });
    if (S.subsRunning === 0 && !S.reportStreaming) S.research.setPhase('writing', 'כל החוקרים סיימו — כותב את הדוח…');
  }
  // הודעה שהגיעה מצ'אט אחר של Claude (למשל צ'אט ב-VS Code ששלח עם SendMessage): נשמרת בשיחה כהודעה גלויה "📨 מ-…"
  function notePeerMessage(S, j) {
    const o = j.origin && j.origin.kind === 'peer' ? j.origin : null;
    const raw = typeof (j.message && j.message.content) === 'string' ? j.message.content : Array.isArray(j.message && j.message.content) ? j.message.content.filter(b => b.type === 'text').map(b => b.text).join('\n') : '';
    const m = !o && raw.match(/<cross-session-message[^>]*?from-name="([^"]*)"[^>]*>([\s\S]*?)<\/cross-session-message>/);
    if (!o && !m) return false;
    const name = o ? (o.name || '') : m[1], body = o ? String(o.body || '') : m[2].trim(), id = o && o.msg_id;
    const conv = S.conv; if (id && conv.messages.some(x => x.peer && x.peer.id === id)) return true;
    pushUserSafe(S, { role: 'user', content: [{ type: 'text', text: '📨 הודעה מצ\'אט אחר של Claude (' + name + '):\n' + body }], ts: now(), peer: { name, id: id || null } });
    engineSave(conv);
    S.emit('peer_message', { name, body });
    return true;
  }
  function handleUser(S, msg, tur) {
    const conv = S.conv;
    if (!msg || !Array.isArray(msg.content)) return;
    const results = msg.content.filter(b => b.type === 'tool_result');
    if (!results.length) return;
    // סוכן משנה שסיים: Claude Code מצרף לתוצאה את השימוש שלו (הקריאות של הסוכן לא מגיעות בזרם) — נספר בהודעה, בשיחה ובסוכן
    for (const r of results) {
      if (!S.sub.has(r.tool_use_id)) continue;
      const one = results.length === 1 && tur && tur.usage ? tur : null;
      if (one) accountAgent(S, r.tool_use_id, one);
      else setTimeout(() => accountAgent(S, r.tool_use_id, agentResultFromTranscript(S.sid, r.tool_use_id)), 1200); // כמה חוקרים יחד: מהקובץ של הסשן
    }
    const stored = [];
    for (const r of results) {
      const text = cap(flattenResult(r.content));
      { const tn = S.toolNames && S.toolNames.get(r.tool_use_id); if (tn) collectSources(S, tn.name, tn.input, text, !!r.is_error); }
      const t0 = S.toolT0.get(r.tool_use_id); const ms = t0 ? Date.now() - t0 : 0;
      stored.push({ type: 'tool_result', tool_use_id: r.tool_use_id, content: text, is_error: !!r.is_error, ms });
      S.emit('tool_result', { id: r.tool_use_id, output: text, is_error: !!r.is_error, ms });
      const s = S.sub.get(r.tool_use_id);
      if (s && !s.judged && !/Async agent launched|launched successfully/i.test(text)) {
        // חוקר שסיים: הנושאים שלו "נחקרו" רק כשיש ממצאים אמיתיים (לא שגיאה, לא סירוב, לא תשובה ריקה).
        // נשפט כאן גם אם אירוע task_notification כבר סגר אותו (הוא מגיע לפני התוצאה)
        s.judged = true;
        // רק הדוח של החוקר: בלי ההקדמה ובלי הסיומת (agentId… / <usage>…) ש-Claude Code מוסיף לתוצאה
        const body = text.replace(/^[\s\S]*?The report follows:\s*/, '').replace(/\n\s*agentId: [a-z0-9]+[\s\S]*$/i, '').replace(/<usage>[\s\S]*?<\/usage>/gi, '');
        const tu = text.match(/tool_uses:\s*(\d+)/i), noTools = !!(S.research && tu && +tu[1] === 0); // חוקר שלא השתמש באף כלי — לא חקר
        const good = !r.is_error && !noTools && body.trim().length >= 200 && !REFUSAL_RE.test(body.slice(0, 800));
        // הפעלה שההוק חסם (סוג חוקר לא נכון) — לא יצא חוקר בכלל, לכן זה לא "כישלון" של הנושא.
        // חוקר שהמשתמש עצר — החלטה של המשתמש: הנושא מסומן "דילגת", לא נכשל, והמפקח לא דורש אותו שוב
        const denied = r.is_error && /^PreToolUse:\S* hook error|hook error: \[Claude Local/i.test(text);
        const userStop = /Request interrupted by user/i.test(text.slice(0, 200));
        if (S.research && s.topics && s.topics.length && !denied) {
          for (const k of s.topics) { if (good) S.topicDone.add(k); else if (userStop) (S.topicSkip || (S.topicSkip = new Set())).add(k); else S.topicFail[k] = (S.topicFail[k] || 0) + 1; }
          if (S.research.setTopicFail) S.research.setTopicFail(S.topicFail);
        }
        if (denied && S.research) { S.subsStarted = Math.max(0, (S.subsStarted || 0) - 1); }
        const st = good || !S.research ? (r.is_error ? 'error' : 'done') : 'error';
        if (!s.handle.isDone()) { s.handle.finish(st, { result: text, error: st === 'error' ? text : null }); subDone(S, s, st); }
        else if (S.research && st === 'error') { S.research.updateSub(s.subIdx, { status: 'error', activity: 'נכשל / סירב — יוצא חוקר חלופי' }); }
      }
    }
    conv.messages.push({ role: 'user', content: stored, ts: now() });
    flushHeldUser(S); // messages that arrived during the tool call: now, after its results
    engineSave(conv);
    S.emit('api_wait', { context: conv.usage.context || 0, compactAt: 0, engine: 'cli' });
  }

  // שימוש של סוכן משנה שסיים: כל הקריאות שלו (מהקובץ שלו) → נספרות בהודעה / בשיחה / במחקר, ומוצגות על הסוכן
  function accountAgent(S, rid, tur) {
    const s = S.sub.get(rid); if (!s || s.accounted || !tur || !tur.usage) return; s.accounted = true;
    const model = tur.resolvedModel || S.servedModel;
    const calls = subagentCalls(S.sid, tur.agentId) || new Map([['last', { model, usage: tur.usage }]]);
    let inT = 0, outT = 0, c = 0;
    for (const [id, m] of calls) {
      noteUsage(S, 'sub:' + (tur.agentId || rid) + ':' + id, m.model, m.usage);
      const u = m.usage; inT += (u.input_tokens || 0) + (u.cache_read_input_tokens || 0) + (u.cache_creation_input_tokens || 0); outT += u.output_tokens || 0; c += costOf ? costOf(m.model, u) : 0;
    }
    if (S.research && !S.research.isDone()) { S.resCostAt = Date.now(); try { researchCost(S, true); } catch { } } // חוקר סיים: הטוקנים שלו נכנסים לכרטיס מיד
    s.usageFinal = true;
    if (s.handle.setUsage) s.handle.setUsage({ tokens: { input: inT, output: outT }, steps: tur.totalToolUseCount, costUSD: c, pct: deps.usagePct ? deps.usagePct(c) : null });
    if (tur.resolvedModel && s.handle.setModel) s.handle.setModel(tur.resolvedModel);
  }

  // ----- סוכני משנה -----
  function startSubAgent(S, b) {
    if (S.sub.has(b.id) || !agentsMgr || !agentsMgr.createExternal) return;
    const i = b.input || {};
    const handle = agentsMgr.createExternal({
      convId: S.conv.id, parentToolId: b.id, kind: 'cli-task', description: i.description || short(i.prompt, 50), prompt: i.prompt || '', model: i.subagent_type || i.model || 'agent',
      onStop: () => { const s = S.sub.get(b.id); if (s && s.taskId) S.send({ type: 'control_request', request_id: 'stop-' + s.taskId, request: { subtype: 'stop_task', task_id: s.taskId } }); else { S.interruptTurn = S.turn; S.send({ type: 'control_request', request_id: 'int-' + now(), request: { subtype: 'interrupt' } }); } }
    });
    const rec = { handle, taskId: null, last: '' };
    S.sub.set(b.id, rec);
    if (S.turnUse) S.turnUse.agents = (S.turnUse.agents || 0) + 1;
    if (S.research) {
      // כל הנושאים שהחוקר מחזיק ("TOPIC-1: … כולל TOPIC-2: …"): קודם מהתיאור; אם אין שם — מתחילת ההוראה
      const grab = s => [...new Set([...String(s || '').matchAll(/TOPIC-(\d+)/gi)].map(m => parseInt(m[1], 10)))];
      rec.topics = grab(i.description); if (!rec.topics.length) rec.topics = grab(String(i.prompt || '').slice(0, 200));
      rec.topic = rec.topics[0]; for (const k of rec.topics) if (S.topicsSeen) S.topicsSeen.add(k); rec.subIdx = S.research.addSub(i.description || i.prompt || 'חוקר', handle.id); S.subsStarted++; S.subsRunning++; S.research.setPhase('researching', S.subsStarted + ' חוקרים עובדים במקביל…'); }
  }
  function handleSubStream(S, parent, ev) {
    const s = S.sub.get(parent); if (!s) return;
    if (ev.type === 'content_block_delta' && ev.delta) {
      if (ev.delta.type === 'text_delta') { s.handle.push({ type: 'text', text: ev.delta.text }); s.handle.setActivity('כותב…'); s.last = (s.last || '') + ev.delta.text; }
      else if (ev.delta.type === 'thinking_delta' && ev.delta.thinking) { s.handle.push({ type: 'thinking', text: ev.delta.thinking }); s.handle.setActivity('חושב…'); }
    } else if (ev.type === 'content_block_start' && ev.content_block && ev.content_block.type === 'text') s.last = '';
    // (השימוש של הסוכן נספר פעם אחת בסיום שלו, מהקובץ שלו — לא כאן, כדי שלא ייספר פעמיים)
  }
  function handleSubAssistant(S, parent, msg) {
    const s = S.sub.get(parent); if (!s || !msg) return;
    for (const b of msg.content || []) {
      if (b.type === 'tool_use') { (S.toolNames || (S.toolNames = new Map())).set(b.id, { name: b.name, input: b.input }); if (S.research && b.name === 'WebSearch' && b.input && b.input.query) S.research.addQuery(b.input.query, s.subIdx); s.handle.push({ type: 'tool', id: b.id, name: b.name, input: b.input }); s.handle.setActivity(activityOf(b.name, b.input)); s.handle.addStep(); }
      else if (b.type === 'text' && b.text) s.last = b.text;
    }
  }
  function handleSubUser(S, parent, msg) {
    const s = S.sub.get(parent); if (!s || !msg) return;
    for (const r of (msg.content || [])) if (r.type === 'tool_result') {
      const out = flattenResult(r.content);
      { const tn = S.toolNames && S.toolNames.get(r.tool_use_id); if (tn) collectSources(S, tn.name, tn.input, out, !!r.is_error); }
      s.handle.push({ type: 'tool_result', id: r.tool_use_id, output: out.length > 4000 ? out.slice(0, 4000) + '\n…' : out, is_error: !!r.is_error, ms: 0 });
    }
  }

  // ----- הרשאות / שאלות מ-Claude -----
  async function handleControl(S, j) {
    const r = j.request || {};
    if (r.subtype !== 'can_use_tool') { S.send({ type: 'control_response', response: { subtype: 'error', request_id: j.request_id, error: 'unsupported by Claude Local Chat' } }); return; }
    const turn = S.turn; const state = S.state();
    const requestId = crypto.randomUUID(); const isAsk = r.tool_name === 'AskUserQuestion';
    state.pendingApproval = { id: r.tool_use_id, requestId, name: r.tool_name, input: r.input };
    if (isAsk) S.emit('ask_user', { id: r.tool_use_id, requestId, questions: (r.input && r.input.questions) || [] });
    else S.emit('approval_required', { id: r.tool_use_id, requestId, name: r.tool_name, input: r.input, title: r.title || r.display_name || null, description: r.description || r.decision_reason || null, blockedPath: r.blocked_path || null, suggestions: !!(r.permission_suggestions && r.permission_suggestions.length) });
    const ans = await waitForApproval(requestId, turn ? turn.signal : new AbortController().signal);
    state.pendingApproval = null;
    S.emit('approval_done', { id: r.tool_use_id, approved: !!ans.approved });
    if (ans.approved) {
      let input = r.input; if (isAsk && ans.answers) input = { ...r.input, answers: ans.answers };
      const resp = { behavior: 'allow', updatedInput: input }; if (ans.always && r.permission_suggestions) resp.updatedPermissions = r.permission_suggestions;
      S.send({ type: 'control_response', response: { subtype: 'success', request_id: j.request_id, response: resp } });
    } else S.send({ type: 'control_response', response: { subtype: 'success', request_id: j.request_id, response: { behavior: 'deny', message: ans.message || (turn && turn.signal.aborted ? 'Cancelled by the user.' : 'The user denied this action. Ask them how to proceed.') } } });
  }

  // ----- Remote Control מהממשק (מתג) -----
  async function setRemote(convId, enabled) {
    const S = sessions.get(convId);
    if (!S || S.procDone) return { applied: false };
    if (enabled && !S.remoteOn) { await enableRemote(S); return { applied: true, url: S.remoteUrl }; }
    if (!enabled) { try { await S.control('remote_control', { enabled: false }, 20000); } catch { } S.remoteOn = false; S.keepAlive = false; S.remoteUrl = null; if (!S.turn) disposeSession(S); return { applied: true }; }
    return { applied: true, url: S.remoteUrl };
  }
  // ⚙ שינוי בצ'אט באמצע עבודה — מיד: מודל / מצב הרשאות / חשיבה עוברים לתהליך שרץ עכשיו (בקשות בקרה של ה-CLI), והצעד הבא של Claude כבר לפיהם.
  //    מאמץ ו-ULTRACODE (חלק מהפעלת התהליך ומההוראות) — מההודעה הבאה (תהליך חדש, argSig)
  async function applyLive(convId, cfg) {
    const S = sessions.get(convId); if (!S || S.procDone || !S.proc) return { applied: [], running: false };
    const done = [], failed = [];
    const steps = [];
    if (cfg.model && cfg.model !== S.liveModel) steps.push(['model', 'set_model', { model: cfg.model }, () => { S.liveModel = cfg.model; }]);
    const pm = cfg.permissionMode || (cfg.autoApprove === false ? 'default' : 'bypassPermissions');
    if (pm && pm !== S.livePerm) steps.push(['permissionMode', 'set_permission_mode', { mode: pm }, () => { S.livePerm = pm; }]);
    // ⚠ נמדד 26/11 (פרוקסי שרושם כל בקשה ל-API): ב-Claude Code 2.1.332 החשיבה עצמה לא משתנה באמצע תור — גם לא set_max_thinking_tokens
    //   וגם לא alwaysThinkingEnabled; הבקשות הבאות נשארות adaptive / disabled כמו בהפעלה. המאמץ כן משתנה באמצע תור
    //   (apply_flag_settings effortLevel: xhigh → low כבר בבקשה הבאה). לכן:
    //   • מאמץ — מיד · חשיבה → כבויה: מיד מאמץ נמוך (גשר: כמעט בלי חשיבה בעבודה שרצה), וכיבוי מלא מההודעה הבאה (תהליך חדש)
    //   • חשיבה → תמיד: מיד המאמץ של "תמיד" (max) + ההוראה בהודעות הבאות, ומההודעה הבאה גם הדגלים
    const partial = [], next = [];
    const th = cfg.thinking === 'off' ? 'off' : 'on', thChange = th !== S.liveThinking;
    let eff = cfg.effort || 'default';
    if (thChange && th === 'off') eff = 'low';
    if (eff !== 'default' && eff !== S.liveEffort) steps.push(['effort', 'apply_flag_settings', { settings: { effortLevel: eff } }, () => { S.liveEffort = eff; }]);
    if (thChange) steps.push(['thinking-ctl', 'set_max_thinking_tokens', { max_thinking_tokens: th === 'off' ? 0 : null }, () => { S.liveThinking = th; }]);
    S.thinkMode = cfg.thinking; // ההוראה ("תמיד" / "לא לחשוב") נכנסת להודעות שנשלחות מעכשיו
    for (const [key, sub, extra, ok] of steps) { try { await S.control(sub, extra, 8000); ok(); done.push(key); } catch (e) { failed.push(key + ': ' + e.message); } }
    if (thChange || (cfg.thinking === 'on' && done.includes('effort'))) { if (done.includes('effort')) partial.push('thinking'); next.push('thinking'); }
    return { applied: done.filter(k => k !== 'thinking-ctl'), partial, next, failed, running: !!S.turn };
  }
  const remoteInfo = convId => { const S = sessions.get(convId); return S ? { alive: !S.procDone, on: S.remoteOn, url: S.remoteUrl } : null; };
  function closeConversation(convId) { const S = sessions.get(convId); if (S) { S.stopped = true; disposeSession(S); } }
  function shutdown() { for (const S of [...sessions.values()]) disposeSession(S); }
  // החשבון התחלף (החלפת חשבון / כניסה / יציאה): תהליך חם מחזיק בזיכרון את האסימון של החשבון הקודם.
  // תהליך פנוי נסגר מיד (ההודעה הבאה עולה בתהליך חדש עם החשבון החדש); תהליך באמצע תור מסיים את התור ונסגר אחריו.
  // Remote Control נשאר (הוא קשור לחשבון שבו הופעל ונסגר לבד אחרי 45 דקות בלי פעילות)
  function accountChanged() {
    let closed = 0, marked = 0;
    for (const S of [...sessions.values()]) {
      if (S.remoteOn) continue;
      if (S.turn) { S.accountStale = true; marked++; } else { disposeSession(S); closed++; }
    }
    return { closed, marked };
  }

  // ה-Stop hook חסם את התשובה (לא עמדה בהוראות): Claude ממשיך באותו תור לכתוב אותה מחדש — לא סוגרים את התור
  function holdTurn(convId) { const S = sessions.get(convId); if (!S || !S.turn) return false; clearTimeout(S.endTimer); S.turnOver = false; S.lastEvt = Date.now(); return true; }
  return { run, adoptWarm, checkpointAll, suspendTimers, freeze, buildArgs, transcriptOf, activityOf, setRemote, applyLive, remoteInfo, closeConversation, shutdown, holdTurn, accountChanged, _sessions: sessions };
}

module.exports = { createCliEngine, transcriptOf, flattenResult, activityOf };
