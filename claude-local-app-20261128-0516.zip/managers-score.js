'use strict';
// ============================================================
//  managers-score.js — a grade (0–10) for EACH of the owner's criteria (docs/MANAGER-CRITERIA.md),
//  computed only from what the manager actually did (its live decision timeline), never from what it says.
//  input: the manager summary (GET /api/managers/:id) + the exam's own facts (independent verification, times).
// ============================================================
const clamp = n => Math.max(0, Math.min(10, Math.round(n * 10) / 10));
const has = (evs, re) => evs.filter(e => re.test(e.what || '') || re.test(e.kind || ''));

/**
 * @param m   manager summary (plan, events, improvements, research, scale, roles, walls, workers, status…)
 * @param x   exam facts: { verified: bool (WE re-ran the checks), verifyDetail, minutes, budgetMin, maxWorkers, stalls: [{at, ms}] }
 * @returns { scores: [{ id, name, score, why }], avg, min }
 */
function scoreManager(m, x = {}) {
  const ev = m.events || [], plan = m.plan || [], imp = m.improvements || [];
  const t0 = m.createdAt || (ev[0] && ev[0].at) || 0, tEnd = m.finishedAt || (ev.length ? ev[ev.length - 1].at : t0);
  const web = has(ev, /^(WebSearch|WebFetch)$/), deep = has(ev, /^research_start$/), research = web.concat(deep);
  const hires = ev.filter(e => e.kind === 'hire'), reports = ev.filter(e => e.kind === 'report');
  const proves = has(ev, /^manager_prove$/), plans = ev.filter(e => e.kind === 'plan');
  const firstHire = hires.length ? hires[0].at : Infinity, firstPlan = plans.length ? plans[0].at : Infinity;
  const reads = has(ev, /^(Read|Bash|Grep|Glob)$/);
  const flows = has(ev, /^(flow_create|flow_start|flow_stop|flow_update)$/), watches = has(ev, /^(manager_watch|watch_create|watch_pause|watch_resume|watch_stop)$/);
  const toggles = has(ev, /^(flow_start|flow_stop|watch_pause|watch_resume|watch_stop)$/);
  const walls = m.wallsAll || m.walls || [];
  const wallsResearched = walls.filter(w => research.some(r => r.at > w.at - 1000 * 60 * 0) && research.some(r => r.at >= (w.firstAt || w.at) - 1000)).length;
  const proven = plan.filter(p => p.status === 'proven').length;
  const withProof = plan.filter(p => p.proof).length, withRole = plan.filter(p => p.role).length;
  const roles = Object.values(m.roles || {}).filter(Boolean);
  const distinctRoles = new Set(roles.map(r => r.trim().toLowerCase())).size;
  const verified = !!x.verified;
  const EXW = x.excludeWindows || [], inEx = t => EXW.some(([a, b]) => t >= a && t <= b), exMs = EXW.reduce((s, [a, b]) => s + Math.max(0, Math.min(b, tEnd) - Math.max(a, t0)), 0);
  const minutes = Math.max(1, (x.minutes || (tEnd - t0) / 60000) - exMs / 60000), budget = x.budgetMin || 60;
  // windows the whole account was blocked (usage limit) are not the manager's fault: not counted as stalls / reaction time / duration
  const stalls = (x.stalls || []).filter(s => !inEx(s.at));
  // the gap between a worker report and the manager's next action = how closely it keeps its hand on the pulse
  const gaps = reports.filter(r => !inEx(r.at)).map(r => { const n = ev.find(e => e.at > r.at && e.kind === 'tool'); let end = n ? n.at : r.at + 600000; for (const [wa] of EXW) if (wa > r.at && wa < end) end = wa; return (end - r.at) / 1000; }); // a limit window that starts while waiting cuts the wait there
  const avgGap = gaps.length ? gaps.reduce((a, b) => a + b, 0) / gaps.length : 600;
  // improvement → was it followed by action (a send / replan / flow) within 10 min?
  const applied = imp.filter(i => ev.some(e => e.at > i.at && e.at - i.at < 900000 && (/chat_send|flow_|manager_plan|manager_watch|watch_/.test(e.what) || e.kind === 'plan'))).length;
  const replans = Math.max(0, (m.replans || plans.length) - 1);

  const S = [];
  const add = (id, name, score, why) => S.push({ id, name, score: clamp(score), why });
  add(1, 'מחפש כל הזמן לשפר ולייעל', (imp.length ? 3 : 0) + Math.min(1, imp.length / Math.max(1, reports.length / 2)) * 4 + (imp.length ? applied / imp.length : 0) * 3, `${imp.length} שיפורים רשומים, ${applied} יושמו מיד`);
  add(2, 'מבנה עבודה ברור, מדויק וחכם', (plan.length ? 3 : 0) + (withProof / Math.max(1, plan.length)) * 3 + (withRole / Math.max(1, plan.length)) * 2 + (m.scale ? 2 : 0), `${plan.length} פריטים · ${withProof} עם הוכחה · ${withRole} עם תפקיד · scale ${m.scale ? 'יש' : 'אין'}`);
  add(3, 'יוצא למחקרים (עיצוב / ייעול / כלים)', Math.min(10, (m.research || []).length * 2 + research.length * 1.2), `${(m.research || []).length} נושאי מחקר בתוכנית · ${web.length} חיפושים · ${deep.length} מחקרים עמוקים`);
  add(4, 'תוכנית עבודה קודם, ב-SCALE מקצועי', (firstPlan < firstHire ? 5 : 0) + (m.scale && m.scale.length > 40 ? 3 : m.scale ? 1.5 : 0) + (plan.length >= 4 ? 2 : plan.length >= 2 ? 1 : 0), firstPlan < firstHire ? 'התוכנית לפני העובד הראשון' : 'עובד נפתח לפני תוכנית');
  add(5, 'מנהל בלייב, יד על הדופק', reports.length ? 10 - Math.min(8, Math.max(0, avgGap - 10) / 30) : 3, `${reports.length} דיווחים · זמן תגובה ממוצע ${Math.round(avgGap)} שנ'`);
  add(6, 'לא עוצר עד שהכל מוכן', (m.status === 'done' ? 6 : 0) + Math.max(0, 4 - stalls.length), `סטטוס ${m.status} · ${stalls.length} הפסקות ארוכות`);
  add(7, 'כישורי מנהל צוות מקצועי', (reads.length ? 2 : 0) + (proves.length ? 3 : 0) + (distinctRoles >= 2 ? 2 : distinctRoles ? 1 : 0) + (imp.length ? 1.5 : 0) + (replans ? 1.5 : 0), `בדיקות עצמיות ${reads.length} · הוכחות ${proves.length} · תפקידים ${distinctRoles} · תכנונים חוזרים ${replans}`);
  add(8, 'קיר → מחקר מיד, ושובר אותו', walls.length ? (wallsResearched / walls.length) * 6 + (walls.filter(w => w.resolved).length / walls.length) * 4 : (research.length ? 8 : 5), walls.length ? `${walls.length} קירות · ${wallsResearched} נחקרו · ${walls.filter(w => w.resolved).length} נפתרו` : 'לא היו קירות');
  add(9, 'לוקח את הפרויקט באופן אישי', (verified ? 5 : 0) + (m.status === 'done' ? 2 : 0) + Math.min(3, imp.length), verified ? 'התוצאה אומתה באופן עצמאי' : 'התוצאה לא אומתה');
  add(10, 'יסודי', (plan.length ? (proven / plan.length) * 7 : 0) + (proves.length >= plan.length ? 3 : proves.length / Math.max(1, plan.length) * 3), `${proven}/${plan.length} הוכחו · ${proves.length} הרצות הוכחה`);
  add(11, 'איכות בלי פשרות', verified ? 10 : (m.status === 'done' ? 4 : 0), x.verifyDetail || '');
  add(12, 'עובד עם מספר העובדים שנקבע', hires.length && hires.length <= (x.maxWorkers || 99) ? 10 : hires.length ? 3 : 0, `${hires.length} עובדים (מתוך ${x.maxWorkers || '?'})`);
  add(13, 'חלוקת תפקידים חכמה', hires.length ? (distinctRoles / hires.length) * 6 + (withRole / Math.max(1, plan.length)) * 4 : 0, `תפקידים: ${roles.join(', ') || '—'}`);
  add(14, 'בונה תזרים / מעקב לעובדים', (flows.concat(watches).some(e => /create|manager_watch/.test(e.what)) ? 8 : 0) + (flows.length && watches.length ? 2 : flows.length + watches.length >= 2 ? 2 : 0), `${flows.length} פעולות תזרים · ${watches.length} פעולות מעקב`);
  add(15, 'מכבה / מדליק תזרים ומעקב בזמן הנכון', toggles.length ? (toggles.some(t => flows.concat(watches).some(c0 => /create|manager_watch/.test(c0.what) && c0.at < t.at)) ? 10 : 6) : (flows.length + watches.length ? 3 : 0), `${toggles.length} הפעלות/כיבויים`);
  { // efficiency must be PROVEN (owner: "חייב להיות מוכח"): improvements carrying a numeric before/after metric, no dead time, inside the budget
    const measured = imp.filter(i => /\d/.test(i.metric || '')).length, ratio = imp.length ? measured / imp.length : 0;
    add(16, 'יעיל במקסימום', Math.min(4, measured) + ratio * 3 + (stalls.length ? Math.max(0, 1.5 - stalls.length * 0.5) : 1.5) + (minutes <= budget ? 1.5 : 0), `${measured}/${imp.length} שיפורים עם מדד מספרי · ${stalls.length} זמנים מתים · ${Math.round(minutes)} מתוך ${budget} דק'`); }
  add(17, 'אכפת לו: מחפש לייעל ומסיים מוקדם ואיכותי', (verified ? 4 : 0) + Math.min(3, imp.length * 1.5) + (minutes < budget ? 3 : 0), '');
  add(18, 'לוקח אחריות על הכל', (proves.length ? 4 : 0) + (reads.length ? 3 : 0) + (m.status === 'done' || m.status === 'deadline' ? 3 : 0), 'מאמת בעצמו ומדווח');
  add(19, 'משנה תוך כדי עבודה כשצריך', Math.min(10, replans * 3 + applied * 3 + (imp.length ? 2 : 0)), `${replans} תכנונים מחדש · ${applied} שיפורים שיושמו`);
  add(20, 'משפר תמיד במחקרים ורעיונות', (research.some(r => r.at > firstHire) ? 4 : 0) + Math.min(1, research.filter(r => r.at > firstHire).length / Math.max(1, reports.length / 2)) * 4 + (imp.length ? 2 : 0), `${research.filter(r => r.at > firstHire).length} מחקרים תוך כדי עבודה`);
  // ---- STRICT caps: no evidence → no 10 ----
  const hours = Math.max(minutes / 60, 0.25), perHour = n => n / hours;
  const cap = (id, max, why) => { const s = S.find(x => x.id === id); if (s && s.score > max) { s.score = clamp(max); s.why += ' · ⛔ ' + why; } };
  if (!walls.length) cap(8, 7, 'אין קיר במבחן — לא הוכח');
  else if (walls.some(w => !research.some(r => r.at >= w.at && r.at - w.at < 5 * 60000))) cap(8, 6, 'קיר בלי מחקר בתוך 5 דק\'');
  if (perHour(imp.length) < 2) cap(1, 6 + perHour(imp.length) * 2, `${perHour(imp.length).toFixed(1)} שיפורים לשעה (צריך ≥2)`);
  if (perHour(research.filter(r => r.at > firstHire).length) < 2) cap(20, 6 + perHour(research.filter(r => r.at > firstHire).length) * 2, 'פחות מ-2 מחקרים לשעה בזמן העבודה');
  if (!imp.some(i => /\d/.test(i.metric || ''))) cap(16, 7, 'אין שיפור עם מדד מספרי לפני/אחרי');
  if (minutes < 60) for (const id of [1, 5, 6, 9, 16, 17, 19, 20]) cap(id, 8, 'ריצה קצרה (פחות משעה) — אין הוכחה לאורך זמן');
  if (stalls.length) for (const id of [5, 6]) cap(id, 10 - stalls.length * 2, stalls.length + ' תקיעות');
  if (!replans) cap(19, 8, 'לא תכנן מחדש אף פעם');
  if (!flows.some(e => /flow_create/.test(e.what))) cap(14, 8, 'רק מעקב, בלי תזרים');
  if (!verified) for (const id of [9, 11, 17]) cap(id, 2, 'התוצאה לא עברה אימות נסתר');
  const avg = Math.round(S.reduce((a, b) => a + b.score, 0) / S.length * 10) / 10;
  return { scores: S, avg, min: Math.min(...S.map(s => s.score)) };
}
module.exports = { scoreManager };
