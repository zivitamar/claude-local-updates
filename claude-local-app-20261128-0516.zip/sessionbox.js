'use strict';
// ============================================================
//  sessionbox.js — נקודת המפגש בתוך חשבון ה-Claude של המשתמש: כתובת המרכזיה נכתבת בכותרת של סשן Claude Code
//  ("clhub <קידוד>") ברשימת הסשנים של החשבון. כל מכשיר שמחובר לאחד מחשבונות המערכת רואה את הרשימה → קורא → מתחבר.
//   • publish: בכל חשבון (פעיל + שמורים עם "אימות מכשירים") — סשן אחד עם הכותרת. משתמש בסשן ישן ומנותק של המגדלור (clm-…),
//     לא יוצר סשן חדש (בלי עלות).
//   • join (מכשיר חדש): פותח צינור במרכזיה לכל מחשב, שולח "CLJOIN1" + הכרטיס שלו + אסימון החשבון; המחשב בודק מול Anthropic
//     שהאסימון שייך לאחד ממיילי המערכת → מוסיף את המכשיר לרשת ומחזיר את הכרטיס שלו. משם — חיבור מוצפן רגיל דרך המרכזיה.
// ============================================================
const BASE = 'https://api.anthropic.com/v1/sessions';
const HDR = t => ({ authorization: 'Bearer ' + t, 'anthropic-version': '2023-06-01', 'anthropic-beta': 'oauth-2025-04-20,ccr-byoc-2025-07-29', 'content-type': 'application/json' });
const PREFIX = (process.env.CLAUDE_SESSIONBOX_PREFIX || 'clhub') + ' ';
const enc = cfg => PREFIX + Buffer.from(JSON.stringify({ u: cfg.url, n: cfg.net, k: cfg.key })).toString('base64url');
const dec = title => { try { if (!String(title || '').startsWith(PREFIX)) return null; const o = JSON.parse(Buffer.from(String(title).slice(PREFIX.length), 'base64url').toString('utf8')); return o && o.u && o.n && o.k ? { url: o.u, net: o.n, key: o.k } : null; } catch { return null; } };

async function sessions(token) { const r = await fetch(BASE + '?beta=true', { headers: HDR(token), signal: AbortSignal.timeout(20000) }); if (!r.ok) throw new Error('sessions ' + r.status); return (await r.json()).data || []; }
async function setTitle(token, id, title) { const r = await fetch(`${BASE}/${id}?beta=true`, { method: 'PATCH', headers: HDR(token), body: JSON.stringify({ title }), signal: AbortSignal.timeout(20000) }); if (!r.ok) throw new Error('title ' + r.status); }
async function profile(token) { const r = await fetch('https://api.anthropic.com/api/oauth/profile', { headers: HDR(token), signal: AbortSignal.timeout(20000) }); if (!r.ok) throw new Error('profile ' + r.status); const j = await r.json(); return String((j.account && j.account.email) || '').toLowerCase(); }
/** the hub config written in my Claude account (null = none yet) */
async function findHub(token) { for (const s of await sessions(token)) { const c = dec(s.title); if (c) return c; } return null; }

function createSessionBox({ tokens, hub, log = () => { }, everyMs = 10 * 60000 }) {
  const S = { published: {}, errors: {}, timer: null };
  async function publishOnce() {
    const cfg = hub && hub.shareable(); if (!cfg) return;
    const want = enc(cfg);
    for (const a of await tokens().catch(() => [])) {
      try {
        const list = await sessions(a.token);
        const mine = list.filter(s => String(s.title || '').startsWith(PREFIX));
        if (mine.some(s => s.title === want)) { S.published[a.email] = Date.now(); delete S.errors[a.email]; continue; }
        // reuse: an old hub title, else an old disconnected beacon session (no new session, no cost)
        const slot = mine[0] || list.filter(s => s.connection_status !== 'connected' && /^clm-[0-9a-f]{10}$/.test(s.title || '')).sort((x, y) => String(x.updated_at).localeCompare(String(y.updated_at)))[0];
        if (!slot) { S.errors[a.email] = 'no free session in this account yet'; continue; }
        await setTitle(a.token, slot.id, want);
        S.published[a.email] = Date.now(); delete S.errors[a.email]; log('[sessionbox] hub published in ' + a.email);
      } catch (e) { S.errors[a.email] = e.message; }
    }
  }
  function start() { clearInterval(S.timer); S.timer = setInterval(() => publishOnce().catch(() => { }), everyMs); if (S.timer.unref) S.timer.unref(); setTimeout(() => publishOnce().catch(() => { }), 15000); }
  return { publishOnce, start, stop: () => clearInterval(S.timer), status: () => ({ published: S.published, errors: S.errors }) };
}
module.exports = { createSessionBox, findHub, profile, sessions, enc, dec, PREFIX };
