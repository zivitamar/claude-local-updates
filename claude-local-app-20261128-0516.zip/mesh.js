'use strict';
// ============================================================
//  mesh.js — רשת המחשבים של האפליקציה ("מחשבים"): כל מחשב שהאפליקציה מותקנת עליו ומחובר לאותו חשבון Claude
//  רואה את כל השאר ועובד עליהם (צ'אטים, פרויקטים, קבצים, Claude) — בלי SSH/RDP.
//
//  אבטחה (בלי שום חבילה חיצונית — רק Node/OpenSSL):
//   * לכל מחשב זהות קבועה: מפתח X25519 (הצפנה) + Ed25519 (חתימה). מזהה המחשב = 16 תווי hex מ-SHA-256 של מפתח החתימה.
//   * חיבור בין שני מחשבים = TLS 1.2 ECDHE-PSK (ChaCha20-Poly1305): המפתח המשותף של הזוג נגזר מ-X25519 (הפרטי שלי + הציבורי שלו),
//     כך שרק שני המחשבים האמיתיים יכולים להשלים את ה-handshake (אימות הדדי), וכל חיבור מקבל מפתחות חדשים (forward secrecy).
//     מי שאין לו מפתח של חבר ברשת — נדחה בתוך ה-handshake ולא מקבל שום מידע.
//   * מי חבר ברשת: רק מחשב שהצטרף דרך חשבון ה-Claude (mesh-beacon.js — הודעה חתומה שעוברת רק בין סשנים של אותו חשבון),
//     או שחבר קיים הכיר אותו (gossip). ביטול מחשב (revoke) עובר לכל הרשת.
//
//  תעבורה: מסגרות [אורך 4 בתים][סוג 1 בית][תוכן] — JSON לבקרה, DATA לזרמים. על כל חיבור: פרוקסי HTTP מלא לשרת המקומי של המחשב השני
//  (כל ה-API, כולל SSE חי), RPC, אירועים (צלילים, מצב צ'אטים), keepalive.
// ============================================================
const fs = require('fs'), path = require('path'), os = require('os'), tls = require('tls'), net = require('net'), http = require('http'), crypto = require('crypto');

const PROTO = 1;
const CIPHERS = 'ECDHE-PSK-CHACHA20-POLY1305:ECDHE-PSK-AES256-CBC-SHA384';
const X_SPKI = Buffer.from('302a300506032b656e032100', 'hex'), E_SPKI = Buffer.from('302a300506032b6570032100', 'hex');
const T_JSON = 1, T_DATA = 2, MAX_FRAME = 32 * 1024 * 1024;
const now = () => Date.now();
const rawPub = k => k.export({ format: 'der', type: 'spki' }).subarray(-32);
const pubFromRaw = (raw, kind) => crypto.createPublicKey({ key: Buffer.concat([kind === 'x' ? X_SPKI : E_SPKI, Buffer.from(raw, 'base64')]), format: 'der', type: 'spki' });
const idFromE = eB64 => crypto.createHash('sha256').update(Buffer.from(eB64, 'base64')).digest('hex').slice(0, 16);
const b64u = b => Buffer.from(b).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const unb64u = s => Buffer.from(String(s).replace(/-/g, '+').replace(/_/g, '/'), 'base64');
const clip = (s, n) => String(s == null ? '' : s).replace(/\s+/g, ' ').trim().slice(0, n);

function lanIPs() {
  const out = [];
  for (const [name, list] of Object.entries(os.networkInterfaces() || {})) for (const a of list || []) {
    if (a.internal || a.family !== 'IPv4' && a.family !== 4) continue;
    if (/^169\.254\./.test(a.address)) continue; // APIPA
    if (/vEthernet \(Default Switch\)|WSL|docker|br-|veth|virbr/i.test(name)) continue;
    out.push(a.address);
  }
  return [...new Set(out)];
}
function osLabel() {
  let v = ''; try { v = os.version(); } catch { }
  if (process.platform === 'linux') { try { const r = fs.readFileSync('/etc/os-release', 'utf8'); const m = r.match(/^PRETTY_NAME="?([^"\n]+)"?/m); if (m) v = m[1]; } catch { } }
  return clip(v || (os.type() + ' ' + os.release()), 80);
}

function createMesh({ dataDir, appVersion = '', getLocalPort, internalToken, log = () => { }, onChange = () => { }, onPeerEvent = () => { }, summary = () => ({}), host, port }) {
  const DIR = path.join(dataDir, 'mesh'); fs.mkdirSync(DIR, { recursive: true });
  const F_ID = path.join(DIR, 'identity.json'), F_MEM = path.join(DIR, 'members.json'), F_AUDIT = path.join(DIR, 'audit.jsonl');
  // ----- זהות קבועה -----
  let ident;
  try { ident = JSON.parse(fs.readFileSync(F_ID, 'utf8')); } catch { }
  if (!ident || !ident.id) {
    const x = crypto.generateKeyPairSync('x25519'), e = crypto.generateKeyPairSync('ed25519');
    const eB64 = rawPub(e.publicKey).toString('base64');
    ident = { id: idFromE(eB64), x: { pub: rawPub(x.publicKey).toString('base64'), priv: x.privateKey.export({ format: 'der', type: 'pkcs8' }).toString('base64') }, e: { pub: eB64, priv: e.privateKey.export({ format: 'der', type: 'pkcs8' }).toString('base64') }, createdAt: now(), name: '' };
    fs.writeFileSync(F_ID, JSON.stringify(ident, null, 1), { mode: 0o600 });
  }
  const xPriv = crypto.createPrivateKey({ key: Buffer.from(ident.x.priv, 'base64'), format: 'der', type: 'pkcs8' });
  const ePriv = crypto.createPrivateKey({ key: Buffer.from(ident.e.priv, 'base64'), format: 'der', type: 'pkcs8' });
  const ID = ident.id;
  // ----- חברי הרשת -----
  let members = {};
  try { members = JSON.parse(fs.readFileSync(F_MEM, 'utf8')) || {}; } catch { }
  let saveT = null;
  const saveMembers = () => { clearTimeout(saveT); saveT = setTimeout(() => { try { fs.writeFileSync(F_MEM + '.tmp', JSON.stringify(members, null, 1)); fs.renameSync(F_MEM + '.tmp', F_MEM); } catch (e) { log('[mesh] save ' + e.message); } }, 200); };
  const audit = o => { try { fs.appendFileSync(F_AUDIT, JSON.stringify({ ts: now(), ...o }) + '\n'); } catch { } };
  const pskCache = new Map();
  function pskFor(peerId) {
    if (pskCache.has(peerId)) return pskCache.get(peerId);
    const m = members[peerId]; if (!m || m.revoked) return null;
    const shared = crypto.diffieHellman({ privateKey: xPriv, publicKey: pubFromRaw(m.x, 'x') });
    const k = Buffer.from(crypto.hkdfSync('sha256', shared, Buffer.from('clmesh-v1'), Buffer.from([ID, peerId].sort().join('|')), 32));
    pskCache.set(peerId, k); return k;
  }
  // ----- מידע על המחשב הזה -----
  let listenPort = 0;
  function selfInfo() {
    let user = ''; try { user = os.userInfo().username; } catch { }
    return { name: ident.name || '', nameTs: ident.nameTs || 0, host: os.hostname(), user, os: osLabel(), platform: process.platform, arch: process.arch, ips: lanIPs(), port: listenPort, version: appVersion, startedAt: STARTED };
  }
  const STARTED = now();
  const displayName = (m, info) => (m && m.name) || (info && info.name) || (info && info.host) || (m && m.id) || '';

  // ----- חיבורים -----
  const conns = new Map(); // peerId -> Conn
  const peerSummary = new Map(); // peerId -> { ...summary, at }
  let server = null, stopped = false;

  function frame(type, payload) { const h = Buffer.alloc(5); h.writeUInt32BE(payload.length + 1, 0); h[4] = type; return Buffer.concat([h, payload]); }
  function makeConn(sock, peerId, dir, addr) {
    const c = { peerId, sock, dir, addr, alive: true, since: now(), lastRx: now(), rtt: null, chans: new Map(), rpcs: new Map(), nextChan: dir === 'out' ? 1 : 2, info: null, path: addr === 'relay' ? 'relay' : /^(127\.|::1|localhost)/.test(addr || '') ? 'local' : 'direct' };
    let buf = Buffer.alloc(0);
    sock.setNoDelay(true); sock.setKeepAlive(true, 15000);
    sock.on('data', d => {
      c.lastRx = now(); buf = buf.length ? Buffer.concat([buf, d]) : d;
      while (buf.length >= 5) {
        const len = buf.readUInt32BE(0); if (len > MAX_FRAME || len < 1) { sock.destroy(new Error('bad frame')); return; }
        if (buf.length < 4 + len) break;
        const type = buf[4], body = buf.subarray(5, 4 + len); buf = buf.subarray(4 + len);
        try { if (type === T_JSON) onJson(c, JSON.parse(body.toString('utf8'))); else if (type === T_DATA) onData(c, body.readUInt32BE(0), body.subarray(4)); } catch (e) { log('[mesh] frame ' + e.message); }
      }
    });
    const close = () => { if (!c.alive) return; c.alive = false; for (const ch of c.chans.values()) { try { ch.onClose && ch.onClose(); } catch { } } c.chans.clear(); for (const r of c.rpcs.values()) r.reject(new Error('המחשב התנתק')); c.rpcs.clear(); if (conns.get(peerId) === c) { conns.delete(peerId); log(`[mesh] ${short(peerId)} disconnected`); onChange(); } };
    sock.on('close', close); sock.on('error', () => { }); sock.on('end', () => sock.destroy());
    c.send = o => { if (!c.alive) return false; return sock.write(frame(T_JSON, Buffer.from(JSON.stringify(o)))); };
    c.data = (chan, b) => { if (!c.alive) return false; const h = Buffer.alloc(4); h.writeUInt32BE(chan, 0); return sock.write(frame(T_DATA, Buffer.concat([h, b]))); };
    return c;
  }
  const short = id => (members[id] ? displayName(members[id], members[id].info) + ' ' : '') + String(id).slice(0, 6);
  function adopt(c) {
    const old = conns.get(c.peerId);
    if (old && old.alive) {
      // שני חיבורים במקביל (שני הצדדים חייגו): נשאר זה שיזם המחשב עם המזהה הקטן יותר — שני הצדדים מחליטים אותו דבר
      const initiatorOf = x => x.dir === 'out' ? ID : x.peerId;
      const keepNew = initiatorOf(c) < initiatorOf(old) ? true : initiatorOf(c) > initiatorOf(old) ? false : c.since > old.since;
      if (!keepNew) { c.sock.end(); return false; }
      old.alive = false; old.sock.destroy();
    }
    conns.set(c.peerId, c); const m = members[c.peerId]; if (m) { m.lastSeen = now(); m.lastAddr = c.addr; saveMembers(); }
    c.send({ t: 'hello', v: PROTO, id: ID, info: selfInfo(), members: gossip(), sum: summary() });
    try { const rc = relay && relay.shareable(); if (rc) c.send({ t: 'evt', k: 'relay-cfg', d: rc }); } catch { }
    log(`[mesh] connected ${c.dir} ${short(c.peerId)} via ${c.addr}`); onChange();
    return true;
  }
  function onJson(c, m) {
    switch (m.t) {
      case 'hello': {
        c.info = stripVerified(m.info || {}); const mem = members[c.peerId];
        if (mem) { mem.info = { ...(mem.info || {}), ...c.info }; if (c.info.nameTs > (mem.nameTs || 0) && c.info.name) { mem.name = c.info.name; mem.nameTs = c.info.nameTs; } mem.lastSeen = now(); saveMembers(); }
        if (m.sum) peerSummary.set(c.peerId, { ...m.sum, at: now() });
        mergeGossip(m.members || [], c.peerId); onChange(); break;
      }
      case 'roster': mergeGossip(m.members || [], c.peerId); onChange(); break;
      case 'ping': c.send({ t: 'pong', ts: m.ts }); break;
      case 'pong': c.rtt = now() - m.ts; break;
      case 'sum': peerSummary.set(c.peerId, { ...(m.sum || {}), at: now() }); onChange(); break;
      case 'evt': try { onPeerEvent(c.peerId, m.k, m.d); } catch (e) { log('[mesh] evt ' + e.message); } break;
      case 'rpc': handleRpc(c, m); break;
      case 'rpcres': { const r = c.rpcs.get(m.id); if (r) { c.rpcs.delete(m.id); m.e ? r.reject(new Error(m.e)) : r.resolve(m.r); } break; }
      case 'req': serveReq(c, m); break;
      case 'reqend': { const ch = c.chans.get(m.c); if (ch && ch.req) ch.req.end(); break; }
      case 'res': { const ch = c.chans.get(m.c); if (ch && ch.onRes) ch.onRes(m); break; }
      case 'end': { const ch = c.chans.get(m.c); if (ch) { c.chans.delete(m.c); ch.onEnd && ch.onEnd(); } break; }
      case 'err': { const ch = c.chans.get(m.c); if (ch) { c.chans.delete(m.c); ch.onErr && ch.onErr(m.e); } break; }
      case 'abort': { const ch = c.chans.get(m.c); if (ch) { c.chans.delete(m.c); try { ch.req && ch.req.destroy(); ch.res && ch.res.destroy(); } catch { } } break; }
      case 'pause': { const ch = c.chans.get(m.c); if (ch && ch.res) ch.res.pause(); break; }
      case 'resume': { const ch = c.chans.get(m.c); if (ch && ch.res) ch.res.resume(); break; }
      // ערוץ דו-כיווני כללי (למשל הכתבה מהטלפון): chopen {c,k} → הודעות טקסט chmsg {c,d} + נתונים בינאריים כ-DATA על אותו ערוץ → chclose
      case 'chopen': openChannel(c, m); break;
      case 'chmsg': { const ch = c.chans.get(m.c); if (ch && ch.onMsg) ch.onMsg(String(m.d == null ? '' : m.d)); break; }
      case 'chclose': { const ch = c.chans.get(m.c); if (ch) { c.chans.delete(m.c); try { ch.onClose && ch.onClose(); } catch { } } break; }
    }
  }
  const chanHandlers = new Map(); // kind -> (peerId, virtualConn) => void
  function openChannel(c, m) {
    const fn = chanHandlers.get(m.k);
    if (!fn || typeof m.c !== 'number' || c.chans.has(m.c)) { c.send({ t: 'chclose', c: m.c, e: 'unknown channel ' + m.k }); return; }
    audit({ from: c.peerId, kind: 'channel', k: String(m.k).slice(0, 40) });
    const { EventEmitter } = require('events');
    const v = new EventEmitter(); let open = true;
    v.peerId = c.peerId;
    v.send = d => { if (open) c.send({ t: 'chmsg', c: m.c, d: typeof d === 'string' ? d : JSON.stringify(d) }); };
    v.sendBinary = b => { if (open) c.data(m.c, Buffer.from(b)); };
    v.close = () => { if (!open) return; open = false; if (c.chans.get(m.c) === ch) c.chans.delete(m.c); c.send({ t: 'chclose', c: m.c }); v.emit('close'); };
    const ch = { onMsg: t => v.emit('text', t), onData: b => v.emit('binary', Buffer.from(b)), onClose: () => { if (!open) return; open = false; v.emit('close'); } };
    c.chans.set(m.c, ch);
    try { fn(c.peerId, v); } catch (e) { log('[mesh] channel ' + m.k + ' ' + e.message); v.close(); }
  }
  function onData(c, chan, b) { const ch = c.chans.get(chan); if (!ch) return; if (ch.req) ch.req.write(b); else if (ch.onData) ch.onData(b); }

  // ----- צד היעד: בקשת HTTP שהגיעה ממחשב אחר → השרת המקומי שלי (127.0.0.1), והתשובה חוזרת בזרם -----
  function serveReq(c, m) {
    const p = String(m.p || '/');
    if (!p.startsWith('/') || p.startsWith('/m/') || /^\/api\/mesh(\/|$)/.test(p)) { c.send({ t: 'res', c: m.c, s: 403, h: { 'content-type': 'application/json' } }); c.data(m.c, Buffer.from('{"error":"not allowed via mesh"}')); c.send({ t: 'end', c: m.c }); return; }
    const headers = { ...(m.h || {}) }; for (const k of Object.keys(headers)) if (/^(host|connection|x-mesh-.*)$/i.test(k)) delete headers[k];
    delete headers['if-none-match']; delete headers['if-modified-since']; // the phone gateway frames a body-less 304 as chunked → corrupts the keep-alive stream; always send the full (gzipped) file
    if ((m.m || 'GET') === 'GET' && /\.(js|css)(\?|$)/.test(p)) headers['accept-encoding'] = 'gzip'; // smaller over the mesh/hub (the browser at the other end decodes it)
    headers['x-mesh-token'] = internalToken; headers['x-mesh-from'] = c.peerId; headers.host = '127.0.0.1';
    audit({ from: c.peerId, kind: 'http', method: m.m, path: p.slice(0, 300) });
    const req = http.request({ host: '127.0.0.1', port: getLocalPort(), method: m.m || 'GET', path: p, headers }, res => {
      const h = {}; for (const [k, v] of Object.entries(res.headers)) if (!/^(connection|transfer-encoding|keep-alive)$/i.test(k)) h[k] = v;
      c.send({ t: 'res', c: m.c, s: res.statusCode, h });
      ch.res = res;
      res.on('data', d => { if (!c.data(m.c, d)) { res.pause(); c.sock.once('drain', () => res.resume()); } });
      res.on('end', () => { if (c.chans.get(m.c) === ch) { c.chans.delete(m.c); c.send({ t: 'end', c: m.c }); } });
      res.on('error', e => { if (c.chans.get(m.c) === ch) { c.chans.delete(m.c); c.send({ t: 'err', c: m.c, e: e.message }); } });
    });
    const ch = { req, onClose: () => { try { req.destroy(); } catch { } } };
    req.on('error', e => { if (c.chans.get(m.c) === ch) { c.chans.delete(m.c); c.send({ t: 'err', c: m.c, e: e.message }); } });
    c.chans.set(m.c, ch);
    if (m.nobody) req.end();
  }
  // ----- צד המקור: הדפדפן פנה ל-/m/<id>/… → הבקשה עוברת במנהרה, והתשובה (כולל SSE חי) נכתבת חזרה -----
  function proxy(req, res, peerId, upstreamPath) {
    const c = conns.get(peerId);
    if (!c || !c.alive) { res.writeHead(503, { 'content-type': 'application/json; charset=utf-8' }); res.end(JSON.stringify({ error: 'המחשב ' + (members[peerId] ? displayName(members[peerId], members[peerId].info) : peerId) + ' לא מחובר כרגע', offline: true })); return; }
    const chan = c.nextChan; c.nextChan += 2;
    const headers = {}; for (const [k, v] of Object.entries(req.headers)) if (!/^(host|connection|cookie|x-mesh-.*|accept-encoding)$/i.test(k)) headers[k] = v;
    const hasBody = !/^(GET|HEAD|DELETE|OPTIONS)$/i.test(req.method) || +req.headers['content-length'] > 0 || req.headers['transfer-encoding'];
    let done = false;
    const ch = {
      onRes: m => { const h = { ...(m.h || {}) }; if (m.s !== 206) delete h['content-length']; res.writeHead(m.s || 502, h); if (h['content-type'] && /event-stream/.test(h['content-type'])) res.flushHeaders && res.flushHeaders(); },
      onData: b => { if (!res.write(b)) { c.send({ t: 'pause', c: chan }); res.once('drain', () => c.send({ t: 'resume', c: chan })); } },
      onEnd: () => { done = true; res.end(); },
      onErr: e => { done = true; if (!res.headersSent) res.writeHead(502, { 'content-type': 'application/json; charset=utf-8' }); res.end(res.headersSent ? '' : JSON.stringify({ error: 'שגיאה במחשב המרוחק: ' + e })); },
      onClose: () => { if (!done) { done = true; try { if (!res.headersSent) res.writeHead(503, { 'content-type': 'application/json' }); res.end(); } catch { } } }
    };
    c.chans.set(chan, ch);
    c.send({ t: 'req', c: chan, m: req.method, p: upstreamPath, h: headers, nobody: !hasBody });
    if (hasBody) { req.on('data', d => c.data(chan, d)); req.on('end', () => c.send({ t: 'reqend', c: chan })); }
    res.on('close', () => { if (!done) { done = true; c.chans.delete(chan); c.send({ t: 'abort', c: chan }); } });
  }
  // ----- RPC + אירועים -----
  const rpcHandlers = new Map();
  function handleRpc(c, m) {
    const fn = rpcHandlers.get(m.m);
    audit({ from: c.peerId, kind: 'rpc', method: m.m });
    if (!fn) return c.send({ t: 'rpcres', id: m.id, e: 'unknown method ' + m.m });
    Promise.resolve().then(() => fn(m.a || {}, c.peerId)).then(r => c.send({ t: 'rpcres', id: m.id, r }), e => c.send({ t: 'rpcres', id: m.id, e: String(e && e.message || e) }));
  }
  function rpc(peerId, method, args, timeoutMs = 120000) {
    const c = conns.get(peerId); if (!c || !c.alive) return Promise.reject(new Error('המחשב לא מחובר כרגע'));
    const id = crypto.randomUUID();
    return new Promise((resolve, reject) => {
      const t = setTimeout(() => { c.rpcs.delete(id); reject(new Error('אין תשובה מהמחשב (timeout)')); }, timeoutMs);
      c.rpcs.set(id, { resolve: v => { clearTimeout(t); resolve(v); }, reject: e => { clearTimeout(t); reject(e); } });
      c.send({ t: 'rpc', id, m: method, a: args });
    });
  }
  const broadcast = (k, d) => { for (const c of conns.values()) if (c.alive) c.send({ t: 'evt', k, d }); };
  let lastSumJson = '';
  function pushSummary(force) { const s = summary(); const j = JSON.stringify(s); if (!force && j === lastSumJson) return; lastSumJson = j; for (const c of conns.values()) if (c.alive) c.send({ t: 'sum', sum: s }); }

  // ----- gossip: מי חבר ברשת (מפתחות, שם, ביטולים) -----
  function gossip() {
    const list = [{ id: ID, x: ident.x.pub, e: ident.e.pub, name: ident.name || '', nameTs: ident.nameTs || 0, info: selfInfo() }];
    for (const m of Object.values(members)) list.push({ id: m.id, x: m.x, e: m.e, name: m.name || '', nameTs: m.nameTs || 0, info: m.info || {}, revoked: !!m.revoked, revokedTs: m.revokedTs || 0 });
    return list;
  }
  function mergeGossip(list, fromPeer) {
    let changed = false, added = false;
    // טלפון לא מכניס חברים לרשת ולא מבטל מחשבים: ממנו מקבלים רק את הפרטים של עצמו (שם/מידע). טלפון שנגנב לא יכול
    // להשתיל "מחשב" של תוקף שיישאר עם גישה מלאה אחרי שהטלפון בוטל, ולא לבטל את המחשבים שלך.
    const fm = members[fromPeer], fromPhone = !!(fm && fm.info && (fm.info.kind === 'phone' || fm.info.platform === 'android'));
    for (const g of list) {
      if (!g || !g.id || !g.x || !g.e || idFromE(g.e) !== g.id) continue; // מזהה חייב להתאים למפתח
      if (fromPhone && g.id !== fromPeer) continue;
      if (g.id === ID) { if (g.revoked && !ident.revokedNotice) { ident.revokedNotice = g.revokedTs; log('[mesh] this machine was revoked by ' + short(fromPeer)); } continue; }
      let m = members[g.id];
      if (!m) { if (g.revoked) continue; m = members[g.id] = { id: g.id, x: g.x, e: g.e, name: g.name || '', nameTs: g.nameTs || 0, info: g.info || {}, addedAt: now(), via: 'gossip:' + fromPeer }; changed = true; added = true; audit({ kind: 'member-added', id: g.id, via: 'gossip', from: fromPeer }); continue; }
      if (m.x !== g.x || m.e !== g.e) continue; // אותו מזהה עם מפתח אחר — מתעלמים
      if (g.revoked && (g.revokedTs || 0) > (m.unrevokedTs || 0) && !m.revoked) { m.revoked = true; m.revokedTs = g.revokedTs; pskCache.delete(g.id); const c = conns.get(g.id); if (c) c.sock.destroy(); changed = true; audit({ kind: 'member-revoked', id: g.id, via: fromPeer }); }
      if ((g.nameTs || 0) > (m.nameTs || 0)) { m.name = g.name; m.nameTs = g.nameTs; changed = true; }
      if (g.info && g.info.ips && g.info.ips.length && !conns.has(g.id)) { m.info = { ...(m.info || {}), ...(fromPhone ? stripVerified(g.info) : g.info) }; changed = true; } // טלפון על עצמו: בלי שדות אימות
    }
    if (changed) { saveMembers(); }
    // חבר חדש נוסף: מעבירים מיד לכל המחוברים (כל מחשב מעביר הלאה רק אם למד משהו חדש — מתכנס, בלי לולאה),
    // אחרת מחשב ותיק דוחה את החדש שמחייג אליו (עוד לא מכיר את המפתח שלו)
    if (added) setImmediate(broadcastRoster);
  }
  function broadcastRoster() { const l = gossip(); for (const c of conns.values()) if (c.alive) c.send({ t: 'roster', members: l }); }

  // ----- האזנה + חיוג -----
  const tlsBase = { ciphers: CIPHERS, minVersion: 'TLSv1.2', maxVersion: 'TLSv1.2' };
  function listen(preferred, bindHost) {
    return new Promise(resolve => {
      const tryPort = p => {
        const s = tls.createServer({ ...tlsBase, pskIdentityHint: 'clmesh', pskCallback: (sock, identity) => {
          // צימוד טלפון (mesh-enroll.js): identity "enroll-<nonce>" — מפתח מהסוד שעל מסך המחשב, חיבור שלא נכנס לרשת
          if (/^enroll-[0-9a-f]{16}$/.test(identity)) { const k = enrollHook ? enrollHook.psk(identity, sock) : null; if (k) sock.meshEnroll = identity; return k; }
          const k = /^[0-9a-f]{16}$/.test(identity) ? pskFor(identity) : null; if (k) sock.meshPeer = identity; return k;
        } }, sock => {
          if (sock.meshEnroll) { if (enrollHook) enrollHook.onConn(sock, sock.meshEnroll); else sock.destroy(); return; }
          const peerId = sock.meshPeer; if (!peerId) return sock.destroy();
          const c = makeConn(sock, peerId, 'in', sock.remoteAddress || 'relay'); adopt(c); // a hub pipe has no network address
        });
        // tests only: a 'direct-off' file in the data dir = this PC refuses every direct (TCP) connection; only hub pipes get in
        s.on('connection', sock => { if (!sock.relayed && process.env.CLAUDE_LOCAL_TEST && fs.existsSync(path.join(dataDir, 'direct-off'))) sock.destroy(); });
        s.on('tlsClientError', () => { }); // ניסיון בלי מפתח — נדחה בשקט
        s.once('error', e => { if (e.code === 'EADDRINUSE' && p < preferred + 40) tryPort(p + 1); else { log('[mesh] listen failed ' + e.message); resolve(0); } });
        s.listen(p, bindHost, () => { server = s; listenPort = s.address().port; log(`[mesh] listening ${bindHost}:${listenPort} id=${ID}`); resolve(listenPort); });
      };
      tryPort(preferred);
    });
  }
  // 🌐 the hub (relay.js): a pipe from another of my devices = one more TCP connection to the same server; a direct dial that fails → the hub
  let relay = null;
  // a hub pipe: "CLJOIN1 {card, token}" = a NEW device of mine asking to join (checked by joinHook against my accounts);
  // anything else = an encrypted mesh connection (TLS) like a TCP one
  let joinHook = null;
  function acceptStream(d) {
    d.once('data', first => {
      if (first.length >= 8 && first.subarray(0, 8).toString() === 'CLJOIN1 ') { let buf = first; const onD = x => { buf = Buffer.concat([buf, x]); tryLine(); }; const tryLine = () => { const i = buf.indexOf(10); if (i < 0) { if (buf.length > 65536) d.destroy(); return; } d.off('data', onD); let j = null; try { j = JSON.parse(buf.subarray(8, i).toString()); } catch { } Promise.resolve(j && joinHook ? joinHook(j) : { error: 'bad request' }).catch(e => ({ error: e.message })).then(r => { try { d.end('CLJOIN1-' + (r && r.ok ? 'OK ' : 'NO ') + JSON.stringify(r || {}) + String.fromCharCode(10)); } catch { } }); }; d.on('data', onD); tryLine(); return; }
      d.pause(); d.unshift(first); if (server) server.emit('connection', d); else d.destroy();
    });
  }
  function relayDial(peerId, st) {
    if (!relay || !relay.isUp() || !relay.peers().includes(peerId)) return false;
    relay.open(peerId).then(d => {
      const sock = tls.connect({ ...tlsBase, socket: d, checkServerIdentity: () => undefined, pskCallback: () => ({ identity: ID, psk: pskFor(peerId) }) });
      const to = setTimeout(() => sock.destroy(), 8000);
      sock.once('secureConnect', () => { clearTimeout(to); st.busy = false; st.backoff = 2000; adopt(makeConn(sock, peerId, 'out', 'relay')); });
      sock.once('error', () => { clearTimeout(to); st.busy = false; st.next = now() + st.backoff; st.backoff = Math.min(st.backoff * 2, 60000); });
    }).catch(() => { st.busy = false; st.next = now() + st.backoff; st.backoff = Math.min(st.backoff * 2, 60000); });
    return true;
  }
  const dialState = new Map(); // peerId -> { next, backoff, busy }
  function dial(peerId) {
    const m = members[peerId]; if (!m || m.revoked || stopped) return;
    const st = dialState.get(peerId) || { next: 0, backoff: 2000, busy: false }; dialState.set(peerId, st);
    if (st.busy || now() < st.next || (conns.get(peerId) && conns.get(peerId).alive)) return;
    const info = m.info || {}; const port = info.port; if (!port) return;
    const addrs = [...new Set([...(m.lastAddr ? [m.lastAddr] : []), ...(info.ips || []), ...(process.env.CLAUDE_MESH_LOOPBACK ? ['127.0.0.1'] : [])])].filter(a => !/^::ffff:/.test(a) || true).map(a => a.replace(/^::ffff:/, ''));
    if (!addrs.length) { if (relayDial(peerId, st)) st.busy = true; return; }
    st.busy = true; let i = 0;
    const next = () => {
      if (i >= addrs.length && !stopped && relayDial(peerId, st)) return; // every direct address failed → through the hub
      if (i >= addrs.length || stopped) { st.busy = false; st.next = now() + st.backoff; st.backoff = Math.min(st.backoff * 2, 60000); return; }
      const addr = addrs[i++]; let settled = false;
      const sock = tls.connect({ ...tlsBase, host: addr, port, checkServerIdentity: () => undefined, pskCallback: () => ({ identity: ID, psk: pskFor(peerId) }) });
      const to = setTimeout(() => { if (!settled) { settled = true; sock.destroy(); next(); } }, 4000);
      sock.once('secureConnect', () => { if (settled) return; settled = true; clearTimeout(to); st.busy = false; st.backoff = 2000; const c = makeConn(sock, peerId, 'out', addr); adopt(c); });
      sock.once('error', () => { if (settled) return; settled = true; clearTimeout(to); next(); });
    };
    next();
  }
  let timer = null;
  function tick() {
    if (stopped) return;
    for (const id of Object.keys(members)) dial(id);
    for (const c of conns.values()) {
      // טלפון: לא מעירים את הרדיו שלו כל 3 שניות — ping כל 25 שניות, וניתוק רק אחרי 90 שניות שקט (הטלפון שולח ping משלו)
      const phone = !!(c.info && (c.info.kind === 'phone' || c.info.platform === 'android'));
      if (now() - c.lastRx > (phone ? 90000 : 35000)) { c.sock.destroy(); continue; }
      if (phone) { if (now() - (c.lastPing || 0) < 25000) continue; c.lastPing = now(); }
      c.send({ t: 'ping', ts: now() });
    }
    pushSummary(false);
  }

  // ----- הצטרפות דרך חשבון Claude: הודעה חתומה (mesh-beacon מעביר אותה בין סשנים של אותו חשבון בלבד) -----
  function helloText(kind = 'hello') {
    // 🌐 the hub of my network travels inside my signed card (beacon through my own Claude account / pairing code): a new device of mine
    // anywhere in the world learns how to reach me — it is not stored in member info and not gossiped
    const hubCfg = (() => { try { const c = relay && relay.shareable(); return c ? { url: c.url, net: c.net, key: c.key } : undefined; } catch { return undefined; } })();
    const payload = JSON.stringify({ v: PROTO, k: kind, id: ID, x: ident.x.pub, e: ident.e.pub, info: selfInfo(), ...(hubCfg ? { hub: hubCfg } : {}), ts: now(), n: crypto.randomBytes(8).toString('hex') });
    const sig = crypto.sign(null, Buffer.from(payload), ePriv);
    return 'CLMESH1 ' + b64u(Buffer.from(JSON.stringify({ p: payload, s: sig.toString('base64') })));
  }
  // בדיקת כרטיס בלי להכניס לרשת (צימוד טלפון): חתימה, מזהה, גיל. זורק שגיאה אם לא תקין
  function verifyCard(text) {
    const m = String(text || '').trim().match(/^CLMESH1 ([A-Za-z0-9_-]+)$/); if (!m) throw new Error('format');
    let env, p; try { env = JSON.parse(unb64u(m[1]).toString('utf8')); p = JSON.parse(env.p); } catch { throw new Error('json'); }
    if (!p || p.v !== PROTO || !/^[0-9a-f]{16}$/.test(p.id) || idFromE(p.e) !== p.id) throw new Error('identity');
    if (!crypto.verify(null, Buffer.from(env.p), pubFromRaw(p.e, 'e'), Buffer.from(env.s, 'base64'))) throw new Error('signature');
    if (Math.abs(now() - (p.ts || 0)) > 24 * 3600000) throw new Error('stale');
    if (p.id === ID) throw new Error('self');
    if (members[p.id] && members[p.id].revoked) throw new Error('revoked');
    return { text: String(text).trim(), id: p.id, x: p.x, e: p.e, info: p.info || {}, k: p.k, ts: p.ts };
  }
  // הערה על חבר (למשל: "אומת כחשבון Claude שלך ע״י itamar") — נשמרת ב-info ועוברת ב-gossip לכל המחשבים
  // שדות שרק מחשב רושם (אימות חשבון של טלפון) — מכשיר לא יכול להצהיר עליהם בעצמו
  const VERIFIED_KEYS = ['account', 'verifiedBy', 'verifiedAt', 'via'];
  function stripVerified(info) { const o = { ...(info || {}) }; for (const k of VERIFIED_KEYS) delete o[k]; return o; }
  function annotate(id, obj) { const m = members[id]; if (!m) return false; m.info = { ...(m.info || {}), ...obj }; saveMembers(); broadcastRoster(); onChange(); return true; }
  let enrollHook = null;
  // מחזיר { ok, id, kind, added } — הודעה שלא עוברת בדיקה נזרקת
  function acceptAccountHello(text, fromName, via = 'account') {
    const m = String(text || '').trim().match(/^CLMESH1 ([A-Za-z0-9_-]+)$/); if (!m) return { ok: false, error: 'format' };
    let env, p; try { env = JSON.parse(unb64u(m[1]).toString('utf8')); p = JSON.parse(env.p); } catch { return { ok: false, error: 'json' }; }
    if (!p || p.v !== PROTO || !/^[0-9a-f]{16}$/.test(p.id) || idFromE(p.e) !== p.id) return { ok: false, error: 'identity' };
    if (!crypto.verify(null, Buffer.from(env.p), pubFromRaw(p.e, 'e'), Buffer.from(env.s, 'base64'))) return { ok: false, error: 'signature' };
    if (fromName && !String(fromName).startsWith('clm-' + p.id.slice(0, 10))) return { ok: false, error: 'sender name does not match the machine id' };
    if (Math.abs(now() - (p.ts || 0)) > 24 * 3600000) return { ok: false, error: 'stale' };
    if (p.id === ID) return { ok: false, error: 'self' };
    let m2 = members[p.id], added = false;
    if (m2 && (m2.x !== p.x || m2.e !== p.e)) return { ok: false, error: 'key mismatch for a known machine' };
    if (!m2) { m2 = members[p.id] = { id: p.id, x: p.x, e: p.e, name: '', nameTs: 0, info: stripVerified(p.info || {}), addedAt: now(), via }; /* "אומת ע״י…" — רק מחשב רושם (annotate), לא כרטיס שמכשיר שלח */ added = true; audit({ kind: 'member-added', id: p.id, via, fromName }); log(`[mesh] joined via Claude account: ${p.info && p.info.host} ${p.id}`); }
    else { if (m2.revoked) return { ok: false, error: 'revoked' }; m2.info = { ...(m2.info || {}), ...stripVerified(p.info || {}) }; }
    if (p.hub && relay) { try { relay.adopt(p.hub); } catch { } } // a device of mine that already knows the hub → so do I
    saveMembers(); pskCache.delete(p.id); dialState.delete(p.id); setImmediate(() => dial(p.id)); if (added) setImmediate(broadcastRoster); onChange();
    return { ok: true, id: p.id, kind: p.k, added };
  }

  // ----- פעולות -----
  function machines() {
    const self = { id: ID, self: true, online: true, name: ident.name || '', displayName: ident.name || os.hostname(), info: selfInfo(), summary: summary(), path: 'self' };
    const list = Object.values(members).filter(m => !m.revoked).map(m => {
      // מה שמחשב אימת (חשבון Claude של טלפון) נשאר גם כשהמכשיר מחובר; המכשיר עצמו לא יכול לדרוס אותו (stripVerified)
      const c = conns.get(m.id), on = !!(c && c.alive), info = c && c.info ? { ...(m.info || {}), ...c.info } : (m.info || {});
      return { id: m.id, self: false, online: on, name: m.name || '', displayName: displayName(m, info), info, summary: on ? peerSummary.get(m.id) || null : null, lastSeen: on ? now() : m.lastSeen || null, rtt: on ? c.rtt : null, path: on ? c.path : null, addr: on ? c.addr : m.lastAddr || null, via: m.via, addedAt: m.addedAt };
    });
    return [self, ...list.sort((a, b) => (b.online - a.online) || String(a.displayName).localeCompare(String(b.displayName)))];
  }
  function rename(id, name) {
    name = clip(name, 40); const ts = now();
    if (id === ID) { ident.name = name; ident.nameTs = ts; fs.writeFileSync(F_ID, JSON.stringify(ident, null, 1), { mode: 0o600 }); }
    else { const m = members[id]; if (!m) return false; m.name = name; m.nameTs = ts; saveMembers(); }
    broadcastRoster(); onChange(); return true;
  }
  function revoke(id) {
    const m = members[id]; if (!m || id === ID) return false;
    m.revoked = true; m.revokedTs = now(); pskCache.delete(id); const c = conns.get(id); if (c) c.sock.destroy();
    saveMembers(); audit({ kind: 'member-revoked', id, via: 'local' }); broadcastRoster(); onChange(); return true;
  }
  async function start({ bindHost } = {}) {
    stopped = false;
    const p = await listen(port || +process.env.CLAUDE_MESH_PORT || 47400, bindHost || host || process.env.CLAUDE_MESH_HOST || '0.0.0.0');
    timer = setInterval(tick, 3000); setTimeout(tick, 300);
    return p;
  }
  function stop() { stopped = true; clearInterval(timer); try { server && server.close(); } catch { } for (const c of conns.values()) c.sock.destroy(); conns.clear(); }
  // הוספה ידנית (לבדיקות/גיבוי): מקבל את "כרטיס" המחשב שמחזיר card()
  const card = () => helloText('card');

  return {
    id: ID, start, stop, machines, rename, revoke, proxy, rpc, broadcast, pushSummary, helloText, acceptAccountHello, card,
    handle: (method, fn) => rpcHandlers.set(method, fn), channel: (kind, fn) => chanHandlers.set(kind, fn), verifyCard, annotate, setEnroll: h => { enrollHook = h; }, isConnected: id => !!(conns.get(id) && conns.get(id).alive),
    member: id => members[id] || null, self: () => ({ id: ID, ...selfInfo(), displayName: ident.name || os.hostname() }),
    setRelay: r => { relay = r; }, setJoinHook: f => { joinHook = f; }, acceptStream, shareRelay: () => { const rc = relay && relay.shareable(); if (rc) broadcast('relay-cfg', rc); },
    port: () => listenPort, audit: (n = 200) => { try { return fs.readFileSync(F_AUDIT, 'utf8').trim().split('\n').slice(-n).map(l => JSON.parse(l)); } catch { return []; } }
  };
}

module.exports = { createMesh, lanIPs, osLabel };
