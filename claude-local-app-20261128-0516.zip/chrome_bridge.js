'use strict';
// ============================================================
//  גשר לתוסף "Claude Local — שליטה בכרום" שרץ בתוך ה-Chrome האמיתי של המשתמש.
//  התוסף מתחבר לכאן ב-WebSocket (ws://127.0.0.1:<port>/api/chrome-bridge); השרת שולח לו בקשות ({op, params}) ומקבל תשובות ואירועים.
//  אבטחה: רק התוסף שלנו (Origin = chrome-extension://<המזהה הקבוע מ-key.json>) מתקבל. אתרים לא יכולים לזייף Origin של תוסף.
//  מימוש WebSocket מינימלי (RFC 6455) — בלי ספריות חיצוניות.
// ============================================================
const crypto = require('crypto'), fs = require('fs'), path = require('path');
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
let EXT_ID = ''; try { EXT_ID = JSON.parse(fs.readFileSync(path.join(__dirname, 'chrome-extension', 'key.json'), 'utf8')).id; } catch { }

function createChromeBridge({ log = () => { }, ports = () => [], onHello = null, gateCheck = null, onGate = null } = {}) {
  const conns = new Set();
  const eventFns = new Set();
  let seq = 0;

  function frame(text, opcode = 1) {
    const payload = Buffer.isBuffer(text) ? text : Buffer.from(String(text), 'utf8'); const n = payload.length;
    let head;
    if (n < 126) { head = Buffer.alloc(2); head[1] = n; }
    else if (n < 65536) { head = Buffer.alloc(4); head[1] = 126; head.writeUInt16BE(n, 2); }
    else { head = Buffer.alloc(10); head[1] = 127; head.writeBigUInt64BE(BigInt(n), 2); }
    head[0] = 0x80 | opcode;
    return Buffer.concat([head, payload]);
  }

  function handleUpgrade(req, sock) {
    const origin = String(req.headers.origin || '');
    const okOrigin = (EXT_ID && origin === 'chrome-extension://' + EXT_ID) || (process.env.CLAUDE_BRIDGE_ANY_EXTENSION === '1' && /^chrome-extension:\/\//.test(origin));
    const key = req.headers['sec-websocket-key'];
    if (!okOrigin || !key) { try { sock.end('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n'); } catch { } log('bridge: rejected origin ' + origin); return; }
    const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
    sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
    sock.setNoDelay(true);
    const c = { sock, pend: new Map(), info: {}, since: Date.now(), lastSeen: Date.now(), alive: true };
    c.send = o => { if (c.alive) try { sock.write(frame(JSON.stringify(o))); } catch { } };
    conns.add(c);
    let buf = Buffer.alloc(0), parts = [];
    sock.on('data', d => {
      buf = Buffer.concat([buf, d]);
      while (buf.length >= 2) {
        const fin = (buf[0] & 0x80) !== 0, opcode = buf[0] & 0x0f, masked = (buf[1] & 0x80) !== 0;
        let len = buf[1] & 0x7f, off = 2;
        if (len === 126) { if (buf.length < 4) return; len = buf.readUInt16BE(2); off = 4; }
        else if (len === 127) { if (buf.length < 10) return; len = Number(buf.readBigUInt64BE(2)); off = 10; }
        const mlen = masked ? 4 : 0; if (buf.length < off + mlen + len) return;
        let payload = buf.subarray(off + mlen, off + mlen + len);
        if (masked) { const m = buf.subarray(off, off + 4); payload = Buffer.from(payload); for (let i = 0; i < payload.length; i++) payload[i] ^= m[i & 3]; }
        buf = buf.subarray(off + mlen + len);
        if (opcode === 8) { try { sock.write(frame(Buffer.alloc(0), 8)); sock.end(); } catch { } return; }
        if (opcode === 9) { try { sock.write(frame(payload, 10)); } catch { } continue; }
        if (opcode === 10) continue;
        if (opcode === 1 || opcode === 2 || opcode === 0) { parts.push(payload); if (!fin) continue; const text = Buffer.concat(parts).toString('utf8'); parts = []; onText(c, text); }
      }
    });
    const gone = () => { if (!c.alive) return; c.alive = false; conns.delete(c); for (const p of c.pend.values()) p.rej(new Error('התוסף בכרום התנתק')); c.pend.clear(); log('bridge: extension disconnected'); if (onGate) try { onGate(null, c.info); } catch { } };
    sock.on('close', gone); sock.on('error', gone); sock.on('end', gone);
  }

  function onText(c, text) {
    let m; try { m = JSON.parse(text); } catch { return; }
    c.lastSeen = Date.now();
    if (m.type === 'hello') {
      c.info = { version: m.version, extId: m.extId, windows: m.windows, paused: !!m.paused };
      if (onHello && onHello(c.info) === 'reload') { log('bridge: extension v' + m.version + ' is outdated → reload'); c.send({ type: 'reload' }); return; }
      c.send({ type: 'welcome', ports: ports() }); log('bridge: extension connected v' + m.version);
      // 🚫 השער לפס 'ניפוי באגים': האם הכרום של התוסף הזה הופעל עם --silent-debugger-extension-api — רק אז התוסף מתחבר ל-debugger
      if (gateCheck) Promise.resolve(gateCheck(c.sock)).then(g => { if (!c.alive) return; c.gate = g || { silent: false }; c.send({ type: 'gate', silent: !!c.gate.silent, reason: c.gate.reason || '' }); log('bridge: gate ' + (c.gate.silent ? 'SILENT (no bar)' : 'NOT silent — will not attach') + (c.gate.browserPid ? ' pid ' + c.gate.browserPid : '')); if (onGate) try { onGate(c.gate, c.info); } catch { } }).catch(e => log('bridge: gate check failed ' + e.message));
      return;
    }
    if (m.type === 'ping') { c.send({ type: 'pong', t: m.t }); return; }
    if (m.type === 'res') { const p = c.pend.get(m.id); if (p) { c.pend.delete(m.id); clearTimeout(p.timer); m.error ? p.rej(new Error(m.error)) : p.res(m.result); } return; }
    if (m.type === 'event') for (const fn of eventFns) { try { fn(m); } catch { } }
  }

  // החיבור הפעיל: האחרון שדיבר (אם יש כמה פרופילים של כרום עם התוסף)
  const pick = () => [...conns].filter(c => c.alive).sort((a, b) => b.lastSeen - a.lastSeen)[0] || null;
  function call(op, params, ms = 30000) {
    const c = pick();
    if (!c) return Promise.reject(Object.assign(new Error('NO_EXTENSION'), { code: 'NO_EXTENSION' }));
    const id = ++seq;
    return new Promise((res, rej) => {
      const timer = setTimeout(() => { if (c.pend.has(id)) { c.pend.delete(id); rej(new Error('הכרום לא ענה בזמן (' + op + (params && params.method ? ' ' + params.method : '') + ')')); } }, ms);
      c.pend.set(id, { res, rej, timer });
      c.send({ type: 'req', id, op, params: params || {} });
    });
  }
  async function waitConnected(ms = 0) { const t0 = Date.now(); while (!pick()) { if (Date.now() - t0 >= ms) return false; await new Promise(r => setTimeout(r, 100)); } return true; }
  return {
    handleUpgrade, call, waitConnected, onEvent: fn => { eventFns.add(fn); return () => eventFns.delete(fn); },
    connected: () => !!pick(),
    status: () => ({ extensionId: EXT_ID, connected: [...conns].filter(c => c.alive).map(c => ({ ...c.info, since: c.since, lastSeen: c.lastSeen, gate: c.gate ? { silent: !!c.gate.silent, reason: c.gate.reason, browserPid: c.gate.browserPid || null } : null })) })
  };
}
module.exports = { createChromeBridge, EXT_ID };
