'use strict';
// ============================================================
//  history_reader.js — קריאה מהירה של כל ההיסטוריה של שיחה (כולל הארכיון: אלפי הודעות, שבועות)
//  מקור = רשימת הודעות בפורמט האפליקציה ({role, content, ts}) — משיחה באפליקציה (ארכיון + חי) או מצ'אט ב-VS Code.
//  "אינדקס תורות": תור = הודעה שלך + מה ש-Claude עשה עד ההודעה הבאה שלך (התשובה הסופית, כמה כלים, אילו).
//  מצבים: stats · outline (מפת כל השיחה, בדפים) · search (איפה דיברו על משהו) · read (טקסט מלא של תורות).
// ============================================================

const isTurnStart = m => m && m.role === 'user' && Array.isArray(m.content) && m.content.some(b => b && b.type !== 'tool_result' && !(b.type === 'text' && b.hidden));
const userText = m => (m.content || []).filter(b => b && b.type === 'text' && !b.hidden).map(b => b.text).join('\n').trim();
const one = s => String(s || '').replace(/\s+/g, ' ').trim();
const clip = (s, n) => { s = one(s); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
const dt = ts => { if (!ts) return '?'; const d = new Date(ts), p = n => String(n).padStart(2, '0'); return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${String(d.getFullYear()).slice(2)} ${p(d.getHours())}:${p(d.getMinutes())}`; };
const argOf = i => { i = i || {}; return one(i.command || i.file_path || i.path || i.pattern || i.query || i.url || i.description || i.prompt || i.code || '').slice(0, 160); };

// בונה את אינדקס התורות מכל ההודעות (איטרטור סינכרוני או אסינכרוני). מהיר: 34,680 הודעות ≈ 0.4 שנ'
async function buildIndex(iter) {
  const turns = []; let i = -1, cur = null, firstTs = null, lastTs = null;
  const close = () => { if (cur) turns.push(cur); };
  for await (const m of iter) {
    i++; if (!m) continue;
    if (m.ts) { if (!firstTs) firstTs = m.ts; lastTs = m.ts; }
    if (isTurnStart(m)) { close(); cur = { n: turns.length + 1, idx: i, end: i, ts: m.ts || null, user: userText(m), answer: '', tools: 0, toolNames: {}, peer: !!m.peer, watch: m.watch ? m.watch.n : null }; continue; }
    if (!cur) { cur = { n: 1, idx: 0, end: i, ts: m.ts || null, user: '', answer: '', tools: 0, toolNames: {} }; }
    cur.end = i;
    if (m.role === 'assistant') for (const b of m.content || []) {
      if (b.type === 'text' && b.text && b.text.trim()) cur.answer = b.text.trim();
      else if (b.type === 'tool_use') { cur.tools++; cur.toolNames[b.name] = (cur.toolNames[b.name] || 0) + 1; }
    }
  }
  close();
  return { turns, total: i + 1, firstTs, lastTs };
}

function stats(ix, title) {
  const days = ix.firstTs && ix.lastTs ? Math.max(1, Math.round((ix.lastTs - ix.firstTs) / 864e5)) : 0;
  return `${title ? `"${title}" — ` : ''}${ix.total} הודעות, ${ix.turns.length} תורות (הודעות של המשתמש), מ-${dt(ix.firstTs)} עד ${dt(ix.lastTs)} (${days} ימים).`;
}

// מפת השיחה: כל תור בשורה — מספר, תאריך, מה ביקשת, מה Claude ענה בסוף, כמה כלים. בדפים לפי תקציב תווים
function outline(ix, { from = 1, chars = 90000, cap = 320 } = {}) {
  const out = []; let used = 0, n = Math.max(1, from | 0);
  for (; n <= ix.turns.length; n++) {
    const t = ix.turns[n - 1];
    const tools = t.tools ? ` (${t.tools} כלים: ${Object.entries(t.toolNames).sort((a, b) => b[1] - a[1]).slice(0, 4).map(([k, v]) => k + '×' + v).join(', ')})` : '';
    const line = `T${t.n} [${dt(t.ts)}]${t.peer ? ' 📨' : ''}${t.watch ? ' 🔁' : ''} 👤 ${clip(t.user, cap) || '(בלי טקסט)'}\n   🤖 ${clip(t.answer, cap) || '(בלי תשובת טקסט)'}${tools}`;
    if (used + line.length > chars && out.length) break;
    out.push(line); used += line.length + 1;
  }
  const next = n <= ix.turns.length ? n : null;
  return { text: out.join('\n'), next, shown: out.length };
}

// חיפוש בכל ההודעות: במה שכתבת, בתשובות, בכלים ובתוצאות שלהם. מחזיר תורות + קטעים
async function search(iter, ix, query, { limit = 60 } = {}) {
  const words = one(query).toLowerCase().split(' ').filter(w => w.length > 1);
  if (!words.length) return { hits: [], text: 'שאילתה ריקה' };
  const turnAt = idx => { let lo = 0, hi = ix.turns.length - 1, r = 0; while (lo <= hi) { const mid = (lo + hi) >> 1; if (ix.turns[mid].idx <= idx) { r = mid; lo = mid + 1; } else hi = mid - 1; } return ix.turns[r]; };
  const hits = []; let i = -1; const seen = new Set();
  for await (const m of iter) {
    i++; if (!m || hits.length >= limit) continue;
    const parts = [];
    for (const b of m.content || []) {
      if (b.type === 'text' && b.text && !b.hidden) parts.push(['טקסט', b.text]);
      else if (b.type === 'tool_use') parts.push(['כלי ' + b.name, JSON.stringify(b.input || {})]);
      else if (b.type === 'tool_result') parts.push(['תוצאה', typeof b.content === 'string' ? b.content : JSON.stringify(b.content || '')]);
    }
    for (const [kind, s] of parts) {
      const low = s.toLowerCase(); if (!words.every(w => low.includes(w))) continue;
      const t = turnAt(i), key = t.n + kind; if (seen.has(key)) continue; seen.add(key);
      const p = low.indexOf(words[0]); const snip = one(s.slice(Math.max(0, p - 140), p + 260));
      hits.push({ turn: t.n, idx: i, ts: m.ts || t.ts, who: m.role === 'user' ? (kind === 'טקסט' ? 'משתמש' : kind) : 'Claude · ' + kind, snip });
      if (hits.length >= limit) break;
    }
  }
  const text = hits.length ? hits.map(h => `T${h.turn} [${dt(h.ts)}] ${h.who}: …${h.snip}…`).join('\n') : `לא נמצא "${query}" בשיחה (${ix.total} הודעות נבדקו).`;
  return { hits, text };
}

// טקסט מלא של תורות from..to: ההודעה שלך, כל הטקסט של Claude, הכלים (שם + פרמטר + תחילת התוצאה)
// msgs = ההודעות מ-base והלאה (לפחות עד סוף התור האחרון שמבוקש)
function readTurns(msgs, base, ix, from, to, { chars = 90000 } = {}) {
  const a = Math.max(1, from | 0), b = Math.min(ix.turns.length, Math.max(a, to | 0 || a));
  const out = []; let used = 0, n = a;
  for (; n <= b; n++) {
    const t = ix.turns[n - 1]; const lines = [`══ T${t.n} [${dt(t.ts)}] ══`];
    const res = {};
    for (let k = t.idx; k <= t.end; k++) { const m = msgs[k - base]; if (m && m.role === 'user') for (const x of m.content || []) if (x.type === 'tool_result') res[x.tool_use_id] = x; }
    for (let k = t.idx; k <= t.end; k++) {
      const m = msgs[k - base]; if (!m) continue;
      if (m.role === 'user') { const u = userText(m); if (u) lines.push('👤 ' + (u.length > 6000 ? u.slice(0, 6000) + '…' : u)); continue; }
      for (const x of m.content || []) {
        if (x.type === 'text' && x.text && x.text.trim()) lines.push('🤖 ' + (x.text.length > 6000 ? x.text.slice(0, 6000) + '…' : x.text.trim()));
        else if (x.type === 'tool_use') { const r = res[x.id]; const rs = r ? one(typeof r.content === 'string' ? r.content : JSON.stringify(r.content || '')).slice(0, 300) : ''; lines.push(`   ⚙ ${x.name}: ${argOf(x.input)}${r ? (r.is_error ? ' ✗ ' : ' → ') + rs : ''}`); }
      }
    }
    const block = lines.join('\n');
    if (used + block.length > chars && out.length) break;
    out.push(block); used += block.length + 2;
  }
  return { text: out.join('\n\n'), next: n <= b ? n : null };
}

module.exports = { buildIndex, stats, outline, search, readTurns, isTurnStart, dt };
