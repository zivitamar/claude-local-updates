'use strict';
// ============================================================
//  relay.js — "המרכזיה" מצד המחשב: התקנה אוטומטית בחשבון Cloudflare של המשתמש + חיבור קבוע + צינורות לרשת המחשבים.
//  - install(token): מוצא את החשבון, דואג לתת-דומיין workers.dev, מעלה את relay/hub-worker.js עם Durable Object, מפעיל.
//  - חיבור בקרה קבוע (WebSocket) עם חיבור-מחדש אוטומטי (backoff עד 30 שנ', ping כל 25 שנ') — שורד נפילת רשת / שינה / אתחול.
//  - open(peerId) → Duplex: צינור בתים דרך המרכזיה (המחשב השני / הטלפון מקבלים "incoming" ומתחברים לאותו sid).
//  - incoming → onStream(duplex, fromId): רשת המחשבים מקבלת אותו כמו חיבור TCP רגיל (אותה הצפנה, אותו פרוטוקול).
//  ההגדרה (כתובת, מזהה רשת, מפתח) נשמרת ב-DATA_DIR/relay.json ומופצת למכשירים שלך דרך הרשת המוצפנת בלבד.
// ============================================================
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const { Duplex } = require('stream');
const CF = 'https://api.cloudflare.com/client/v4';
const SCRIPT = 'claude-local-hub';
const WS = globalThis.WebSocket;

function createRelay({ dataDir, selfId, log = () => { }, onStream = () => { }, onPeers = () => { }, fetchImpl = globalThis.fetch }) {
  const FILE = path.join(dataDir, 'relay.json');
  let cfg = null; try { cfg = JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { }
  if (!cfg && process.env.CLAUDE_HUB_TEST_CFG) { try { cfg = JSON.parse(process.env.CLAUDE_HUB_TEST_CFG); } catch { } } // tests only
  const save = () => { fs.mkdirSync(dataDir, { recursive: true }); const t = FILE + '.tmp'; fs.writeFileSync(t, JSON.stringify(cfg, null, 1)); fs.renameSync(t, FILE); };
  const S = { ctl: null, up: false, backoff: 1000, timer: null, ping: null, peers: [], lastError: '', stopped: false, connectedAt: 0 };

  // ---------------- install on the user's Cloudflare ----------------
  async function cf(token, method, p, body, isForm) {
    const r = await fetchImpl(CF + p, { method, headers: { authorization: 'Bearer ' + token, ...(body && !isForm ? { 'content-type': 'application/json' } : {}) }, body: body ? (isForm ? body : JSON.stringify(body)) : undefined, signal: AbortSignal.timeout(30000) });
    let j = null; try { j = await r.json(); } catch { }
    if (!r.ok || !j || j.success === false) { const e = new Error(((j && j.errors && j.errors.map(x => x.message).join('; ')) || ('HTTP ' + r.status))); e.status = r.status; e.cf = j; throw e; }
    return j.result;
  }
  async function install(token, o = {}) {
    token = String(token || '').trim(); if (token.length < 20) throw Object.assign(new Error('Token לא תקין'), { status: 400 });
    const steps = [];
    const accts = await cf(token, 'GET', '/accounts?per_page=50'); if (!accts || !accts.length) throw new Error('ה-Token לא רואה אף חשבון Cloudflare');
    const acct = accts[0]; steps.push('חשבון: ' + acct.name);
    let sub = null; try { sub = (await cf(token, 'GET', `/accounts/${acct.id}/workers/subdomain`)).subdomain; } catch { }
    if (!sub) { const want = ('cl' + crypto.randomBytes(4).toString('hex')); sub = (await cf(token, 'PUT', `/accounts/${acct.id}/workers/subdomain`, { subdomain: want })).subdomain; steps.push('נוצר תת-דומיין: ' + sub); }
    const net = (cfg && cfg.net) || crypto.randomBytes(16).toString('hex');
    const key = (cfg && cfg.key) || crypto.randomBytes(24).toString('base64url');
    const code = fs.readFileSync(path.join(__dirname, 'relay', 'hub-worker.js'), 'utf8');
    const upload = async withMigration => {
      const meta = { main_module: 'hub.js', compatibility_date: '2025-06-01', bindings: [{ type: 'durable_object_namespace', name: 'HUB', class_name: 'Hub' }, { type: 'secret_text', name: 'HUB_KEY', text: key }, { type: 'plain_text', name: 'LOCATION', text: o.location || 'eeur' }], ...(withMigration ? { migrations: { new_tag: 'v1', new_sqlite_classes: ['Hub'] } } : {}) };
      const fd = new FormData();
      fd.append('metadata', new Blob([JSON.stringify(meta)], { type: 'application/json' }));
      fd.append('hub.js', new Blob([code], { type: 'application/javascript+module' }), 'hub.js');
      return cf(token, 'PUT', `/accounts/${acct.id}/workers/scripts/${SCRIPT}`, fd, true);
    };
    try { await upload(true); } catch (e) { if (/migration|already|tag/i.test(e.message)) await upload(false); else throw e; } // re-install: the class already exists
    steps.push('המרכזיה הועלתה');
    await cf(token, 'POST', `/accounts/${acct.id}/workers/scripts/${SCRIPT}/subdomain`, { enabled: true, previews_enabled: false }).catch(e => { if (!/already/i.test(e.message)) throw e; });
    const url = `https://${SCRIPT}.${sub}.workers.dev`;
    // a new workers.dev route takes a little while to answer: wait for /health (up to 90 s)
    let healthy = false; for (let i = 0; i < 45 && !healthy; i++) { try { const r = await fetchImpl(url + '/health', { signal: AbortSignal.timeout(5000) }); healthy = r.ok; } catch { } if (!healthy) await new Promise(r => setTimeout(r, 2000)); }
    steps.push(healthy ? 'המרכזיה עונה' : 'המרכזיה עוד לא עונה (נמשיך לנסות ברקע)');
    cfg = { url, net, key, account: acct.name, installedAt: Date.now(), by: selfId };
    save(); connect(true);
    return { ok: true, url, healthy, steps };
  }
  // a config learned from another of MY devices (over the encrypted mesh)
  function adopt(c) {
    const urlOk = /^https:\/\//.test(c && c.url || '') || (!!process.env.CLAUDE_LOCAL_TEST && /^http:\/\/(127\.0\.0\.1|localhost)[:/]/.test(c && c.url || '')); // tests: a local hub
    if (!c || !urlOk || !/^[0-9a-f]{32}$/.test(c.net || '') || !c.key) return false;
    if (cfg && cfg.url === c.url && cfg.net === c.net && cfg.key === c.key) return false;
    cfg = { url: c.url, net: c.net, key: c.key, account: c.account || '', installedAt: c.installedAt || Date.now(), by: c.by || '' }; save(); connect(true); log('[relay] got the hub from my network: ' + cfg.url); return true;
  }
  // ---------------- "Connect Cloudflare" with one click: the OAuth (PKCE) login of Cloudflare's own CLI (wrangler) ----------------
  // The owner signs in on Cloudflare in the browser and approves; the callback returns to localhost:8976 (wrangler's fixed
  // redirect), the code is exchanged for a token, and the hub is installed with it. No key to copy, no npm needed.
  const OAUTH = { client: '54d11594-84e4-41aa-b438-e81b8fa78ee7', auth: 'https://dash.cloudflare.com/oauth2/auth', token: 'https://dash.cloudflare.com/oauth2/token', redirect: 'http://localhost:8976/oauth/callback', scope: 'account:read user:read workers:write workers_scripts:write offline_access' };
  const login = { state: 'idle', error: null, url: null, steps: [], srv: null, at: 0 };
  function loginStatus() { return { state: login.state, error: login.error, url: login.url, steps: login.steps }; }
  function startLogin(openUrl) {
    if (login.srv) { try { login.srv.close(); } catch { } login.srv = null; }
    const verifier = crypto.randomBytes(48).toString('base64url'), challenge = crypto.createHash('sha256').update(verifier).digest('base64url'), state = crypto.randomBytes(16).toString('hex');
    const url = OAUTH.auth + '?' + new URLSearchParams({ response_type: 'code', client_id: OAUTH.client, redirect_uri: OAUTH.redirect, scope: OAUTH.scope, state, code_challenge: challenge, code_challenge_method: 'S256' });
    Object.assign(login, { state: 'waiting', error: null, url, steps: [], at: Date.now() });
    return new Promise((resolve, reject) => {
      const http = require('http');
      const page = (ok, msg) => `<!doctype html><meta charset="utf-8"><body style="font-family:system-ui;background:#1f1f1e;color:#eee;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;direction:rtl"><div style="text-align:center"><div style="font-size:56px">${ok ? '✅' : '❌'}</div><h2>${msg}</h2><p style="color:#aaa">אפשר לסגור את הלשונית ולחזור ל-Claude מקומי.</p></div>`;
      const srv = http.createServer(async (req, res) => {
        const u = new URL(req.url, 'http://localhost:8976');
        if (u.pathname !== '/oauth/callback') { res.writeHead(404); return res.end(); }
        if (u.searchParams.get('state') !== state) { res.writeHead(400, { 'content-type': 'text/html; charset=utf-8' }); return res.end(page(false, 'הבקשה לא תואמת — נסה שוב מהאפליקציה')); }
        const code = u.searchParams.get('code');
        if (!code) { login.state = 'error'; login.error = u.searchParams.get('error_description') || u.searchParams.get('error') || 'הגישה לא אושרה'; res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }); res.end(page(false, 'הגישה לא אושרה')); srv.close(); login.srv = null; return; }
        res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }); res.end(page(true, 'Cloudflare חובר — מתקין את המרכזיה…'));
        srv.close(); login.srv = null; login.state = 'installing';
        try {
          const r = await fetchImpl(OAUTH.token, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ grant_type: 'authorization_code', code, client_id: OAUTH.client, redirect_uri: OAUTH.redirect, code_verifier: verifier }).toString(), signal: AbortSignal.timeout(30000) });
          const j = await r.json().catch(() => ({}));
          if (!r.ok || !j.access_token) throw new Error('Cloudflare לא החזיר הרשאה: ' + (j.error_description || j.error || ('HTTP ' + r.status)));
          const out = await install(j.access_token);
          login.state = 'done'; login.steps = out.steps; log('[relay] connected by Cloudflare login: ' + out.url);
        } catch (e) { login.state = 'error'; login.error = e.message; log('[relay] login install failed: ' + e.message); }
      });
      srv.on('error', e => { login.state = 'error'; login.error = e.code === 'EADDRINUSE' ? 'פורט 8976 תפוס (אולי wrangler פתוח) — סגור אותו ונסה שוב' : e.message; reject(new Error(login.error)); });
      srv.listen(8976, '127.0.0.1', () => { login.srv = srv; try { openUrl && openUrl(url); } catch { } resolve(loginStatus()); });
      setTimeout(() => { if (login.srv === srv) { try { srv.close(); } catch { } login.srv = null; if (login.state === 'waiting') { login.state = 'error'; login.error = 'עבר הזמן (10 דקות) — לחץ שוב "חבר Cloudflare"'; } } }, 10 * 60000);
    });
  }
  function remove() { cfg = null; try { fs.unlinkSync(FILE); } catch { } disconnect(); }
  const wsUrl = (kind, extra = '') => cfg.url.replace(/^http/, 'ws') + `/${kind}/${cfg.net}${extra}?id=${selfId}&k=${encodeURIComponent(cfg.key)}`;

  // ---------------- control channel: always on, reconnects by itself ----------------
  function disconnect() { clearTimeout(S.timer); clearInterval(S.ping); if (S.ctl) { try { S.ctl.close(); } catch { } } S.ctl = null; S.up = false; }
  function connect(now) {
    clearTimeout(S.timer); if (S.stopped || !cfg || !WS) return;
    if (now) { disconnect(); S.backoff = 1000; }
    if (S.ctl) return;
    let ws; try { ws = new WS(wsUrl('c')); } catch (e) { S.lastError = e.message; return retry(); }
    S.ctl = ws; ws.binaryType = 'arraybuffer';
    ws.onopen = () => { S.up = true; S.backoff = 1000; S.connectedAt = Date.now(); S.lastError = ''; log('[relay] connected ' + cfg.url); clearInterval(S.ping); S.ping = setInterval(() => { try { ws.send('{"t":"ping"}'); } catch { } }, 25000); };
    ws.onmessage = ev => {
      if (typeof ev.data !== 'string') return; let j; try { j = JSON.parse(ev.data); } catch { return; }
      if (j.t === 'peers') { S.peers = j.ids || []; try { onPeers(S.peers); } catch { } }
      else if (j.t === 'incoming' && /^[0-9a-f]{16}$/.test(j.from || '') && /^[0-9a-f]{16,40}$/.test(j.sid || '')) { const d = pipe(j.sid, j.from); d.once('relay-open', () => { try { onStream(d, j.from); } catch (e) { log('[relay] onStream ' + e.message); d.destroy(); } }); }
    };
    ws.onclose = ev => { if (S.ctl === ws) { S.ctl = null; S.up = false; clearInterval(S.ping); S.lastError = 'closed ' + (ev && ev.code); retry(); } };
    ws.onerror = () => { S.lastError = 'error'; };
  }
  function retry() { clearTimeout(S.timer); if (S.stopped || !cfg) return; S.timer = setTimeout(() => connect(false), S.backoff); S.backoff = Math.min(S.backoff * 2, 30000); }

  // ---------------- pipes ----------------
  function pipe(sid, peerId) {
    const ws = new WS(wsUrl('d', '/' + sid)); ws.binaryType = 'arraybuffer';
    let open = false; const pending = [];
    const d = new Duplex({
      write(chunk, enc, cb) { if (open) { try { ws.send(chunk); cb(); } catch (e) { cb(e); } } else { pending.push([chunk, cb]); } },
      read() { },
      final(cb) { try { ws.close(1000); } catch { } cb(); },
      destroy(err, cb) { try { ws.close(1000); } catch { } cb(err); }
    });
    d.remoteAddress = 'relay:' + peerId; d.remotePort = 0; d.relayed = true; d.setNoDelay = () => d; d.setKeepAlive = () => d; d.setTimeout = () => d; d.unref = () => d; d.ref = () => d;
    ws.onmessage = ev => {
      if (typeof ev.data === 'string') { if (!open && ev.data.includes('"open"')) { open = true; for (const [c, cb] of pending.splice(0)) { try { ws.send(c); cb(); } catch (e) { cb(e); } } d.emit('relay-open'); } return; }
      d.push(Buffer.from(ev.data));
    };
    ws.onclose = () => { d.push(null); if (!d.destroyed) d.destroy(); };
    ws.onerror = () => { };
    return d;
  }
  /** a pipe to peerId; resolves when the other side joined (or rejects after timeoutMs) */
  function open(peerId, timeoutMs = 8000) {
    return new Promise((resolve, reject) => {
      if (!cfg || !S.up || !S.ctl) return reject(new Error('המרכזיה לא מחוברת'));
      if (!S.peers.includes(peerId)) return reject(new Error('המכשיר לא מחובר למרכזיה'));
      const sid = crypto.randomBytes(12).toString('hex');
      const d = pipe(sid, peerId);
      const to = setTimeout(() => { d.destroy(); reject(new Error('timeout')); }, timeoutMs);
      d.once('relay-open', () => { clearTimeout(to); resolve(d); });
      try { S.ctl.send(JSON.stringify({ t: 'dial', to: peerId, sid })); } catch (e) { clearTimeout(to); d.destroy(); reject(e); }
    });
  }
  function status() { return { configured: !!cfg, url: cfg ? cfg.url : null, account: cfg ? cfg.account : null, up: S.up, peers: S.peers, since: S.connectedAt || null, error: S.lastError || null }; }
  function shareable() { return cfg ? { url: cfg.url, net: cfg.net, key: cfg.key, account: cfg.account, installedAt: cfg.installedAt, by: cfg.by } : null; }
  function stop() { S.stopped = true; disconnect(); }
  if (cfg) setTimeout(() => connect(true), 50);
  return { install, startLogin, loginStatus, adopt, remove, open, status, shareable, connect: () => connect(true), stop, isUp: () => S.up, peers: () => S.peers.slice() };
}
module.exports = { createRelay, SCRIPT };
