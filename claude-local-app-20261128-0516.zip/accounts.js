'use strict';
// ============================================================
//  accounts.js — כמה חשבונות Claude (מנוי) וכמה מפתחות API, שמורים במחשב.
//
//  מנוי: כל חשבון שנכנסים אליו נשמר ב"כספת" (DATA_DIR/accounts/<id>.json): אסימוני הכניסה של Claude Code
//  (.credentials.json → claudeAiOauth) + פרטי החשבון (.claude.json → oauthAccount). "החלפת חשבון" = כתיבת החשבון
//  השמור לקבצים ש-Claude Code קורא — בלי כניסה מחדש בדפדפן. אסימון הרענון מתחלף (rotation) בכל רענון, ולכן החשבון
//  הפעיל נשמר מחדש לפני כל החלפה ובכל בדיקת סטטוס. אף פעם לא מריצים `claude auth logout` בהחלפה (זה מבטל את האסימון).
//  "הוספת חשבון" = כניסה בתיקיית CLAUDE_CONFIG_DIR זמנית (לא נוגעת בחשבון הפעיל) → ייבוא לכספת → מחיקת התיקייה.
//  לכל חשבון דגל deviceAuth: טלפון / מכשיר חדש שמאשר את הצימוד בחשבון הזה — מתקבל לרשת.
//
//  API: רשימת מפתחות (DATA_DIR/apikeys.json) עם שם + "של איזה חשבון"; המפתח הפעיל = cfg.apiKey (כמו קודם).
// ============================================================
const fs = require('fs'), os = require('os'), path = require('path'), crypto = require('crypto');

function writeAtomic(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.${crypto.randomBytes(3).toString('hex')}.tmp`;
  fs.writeFileSync(tmp, data, { encoding: 'utf8', mode: 0o600 });
  for (let i = 0; ; i++) {
    try { fs.renameSync(tmp, file); return; }
    catch (e) {
      if ((e.code === 'EPERM' || e.code === 'EBUSY' || e.code === 'EACCES') && i < 8) { const t = Date.now() + 25; while (Date.now() < t) { } continue; }
      try { fs.writeFileSync(file, data, { encoding: 'utf8', mode: 0o600 }); } finally { try { fs.unlinkSync(tmp); } catch { } }
      return;
    }
  }
}
const readJson = f => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } };
const lc = s => String(s || '').trim().toLowerCase();

function createAccounts({ dataDir, env = process.env, home = os.homedir(), log = () => { } }) {
  const VAULT = path.join(dataDir, 'accounts');
  const KEYS_FILE = path.join(dataDir, 'apikeys.json');
  // איפה Claude Code שומר את הכניסה: CLAUDE_CONFIG_DIR (אם מוגדר) או ~/.claude + ~/.claude.json
  const cliPaths = dir => {
    const d = dir || env.CLAUDE_CONFIG_DIR || '';
    if (d) return { creds: path.join(d, '.credentials.json'), cfg: path.join(d, '.claude.json') };
    const legacy = path.join(home, '.claude', '.config.json'); // גרסאות ישנות של Claude Code
    return { creds: path.join(home, '.claude', '.credentials.json'), cfg: fs.existsSync(legacy) ? legacy : path.join(home, '.claude.json') };
  };
  const idOf = (accountUuid, orgUuid) => crypto.createHash('sha256').update(String(accountUuid) + '|' + String(orgUuid || '')).digest('hex').slice(0, 16);
  const entryFile = id => path.join(VAULT, String(id).replace(/[^a-f0-9]/g, '') + '.json');

  // הכניסה החיה (מה ש-Claude Code משתמש בו עכשיו) בתיקייה dir (ריק = האמיתית)
  function readLive(dir) {
    const p = cliPaths(dir);
    const creds = readJson(p.creds), gcfg = readJson(p.cfg);
    const oauth = creds && creds.claudeAiOauth, acct = gcfg && gcfg.oauthAccount;
    if (!oauth || !oauth.accessToken || !oauth.refreshToken) return null;
    const accountUuid = (acct && acct.accountUuid) || oauth.accountUuid, orgUuid = (acct && acct.organizationUuid) || oauth.organizationUuid || '';
    if (!accountUuid) return null;
    // אסימונים של חשבון אחד ופרטים של חשבון אחר (באמצע כתיבה של ה-CLI) — לא שומרים תמונת מצב שבורה
    if (acct && oauth.accountUuid && acct.accountUuid && acct.accountUuid !== oauth.accountUuid) return null;
    return { id: idOf(accountUuid, orgUuid), oauth, oauthAccount: acct || null, accountUuid, orgUuid };
  }
  function readEntry(id) { const e = readJson(entryFile(id)); return e && e.id === id ? e : null; }
  function listEntries() {
    let files = []; try { files = fs.readdirSync(VAULT).filter(f => /^[a-f0-9]{16}\.json$/.test(f)); } catch { }
    return files.map(f => readJson(path.join(VAULT, f))).filter(e => e && e.id && e.oauth);
  }
  function writeEntry(e) { writeAtomic(entryFile(e.id), JSON.stringify(e, null, 2)); }
  function entryFromLive(live, prev) {
    const a = live.oauthAccount || (prev && prev.oauthAccount) || {};
    return {
      id: live.id, accountUuid: live.accountUuid, orgUuid: live.orgUuid,
      email: a.emailAddress || (prev && prev.email) || '', displayName: a.displayName || a.fullName || (prev && prev.displayName) || '',
      orgName: a.organizationName || (prev && prev.orgName) || '',
      plan: live.oauth.subscriptionType || (prev && prev.plan) || '', tier: live.oauth.rateLimitTier || (prev && prev.tier) || '',
      deviceAuth: prev ? prev.deviceAuth !== false : true,
      addedAt: (prev && prev.addedAt) || Date.now(), savedAt: Date.now(), lastUsedAt: (prev && prev.lastUsedAt) || 0,
      oauth: live.oauth, oauthAccount: live.oauthAccount || (prev && prev.oauthAccount) || null
    };
  }
  // שומר את החשבון הפעיל בכספת (או מעדכן את האסימונים שהתחלפו). כותב רק כשמשהו השתנה
  function snapshotActive() {
    const live = readLive(); if (!live) return null;
    const prev = readEntry(live.id);
    if (prev && JSON.stringify(prev.oauth) === JSON.stringify(live.oauth) && (!live.oauthAccount || JSON.stringify(prev.oauthAccount) === JSON.stringify(live.oauthAccount))) return prev;
    const e = entryFromLive(live, prev); writeEntry(e);
    if (!prev) log('[accounts] saved account ' + (e.email || e.id));
    return e;
  }
  const pub = (e, activeId) => ({
    id: e.id, email: e.email, displayName: e.displayName, orgName: e.orgName, plan: e.plan, tier: e.tier,
    deviceAuth: e.deviceAuth !== false, addedAt: e.addedAt, lastUsedAt: e.lastUsedAt || 0, active: e.id === activeId,
    // אסימון הרענון פג → צריך כניסה מחדש לחשבון הזה
    expired: !!(e.oauth && e.oauth.refreshTokenExpiresAt && e.oauth.refreshTokenExpiresAt < Date.now()),
    expiresAt: (e.oauth && e.oauth.refreshTokenExpiresAt) || null
  });
  function list() {
    const live = snapshotActive(); const activeId = live ? live.id : null;
    return listEntries().map(e => pub(e, activeId)).sort((a, b) => (b.active - a.active) || (b.lastUsedAt - a.lastUsedAt) || (a.addedAt - b.addedAt));
  }
  function activeId() { const l = readLive(); return l ? l.id : null; }

  // כתיבת חשבון לקבצים של Claude Code. משנים רק את claudeAiOauth ואת oauthAccount — כל השאר (MCP, פרויקטים) נשאר
  function writeLive(e, dir) {
    const p = cliPaths(dir);
    const creds = readJson(p.creds) || {};
    creds.claudeAiOauth = e.oauth;
    writeAtomic(p.creds, JSON.stringify(creds));
    let raw = null; try { raw = fs.readFileSync(p.cfg, 'utf8'); } catch { }
    let gcfg = {}; if (raw != null) { try { gcfg = JSON.parse(raw); } catch (err) { throw new Error('לא הצלחתי לקרוא את ' + p.cfg + ': ' + err.message); } }
    if (e.oauthAccount) gcfg.oauthAccount = e.oauthAccount; else delete gcfg.oauthAccount;
    writeAtomic(p.cfg, JSON.stringify(gcfg, null, 2));
  }
  // החלפה בלי כניסה מחדש. מחזיר { from, to, rollback() }
  function switchTo(id) {
    const target = readEntry(id); if (!target) throw Object.assign(new Error('החשבון לא נמצא בחשבונות השמורים'), { status: 404 });
    const cur = snapshotActive();
    if (cur && cur.id === id) return { from: cur.id, to: id, same: true, rollback: () => { } };
    const p = cliPaths();
    const backup = { creds: (() => { try { return fs.readFileSync(p.creds, 'utf8'); } catch { return null; } })(), cfgAcct: (readJson(p.cfg) || {}).oauthAccount };
    writeLive(target);
    target.lastUsedAt = Date.now(); writeEntry(target);
    log('[accounts] switched ' + (cur ? cur.email || cur.id : 'none') + ' → ' + (target.email || target.id));
    return {
      from: cur ? cur.id : null, to: id,
      rollback: () => {
        if (backup.creds != null) writeAtomic(p.creds, backup.creds); else { try { const c = readJson(p.creds) || {}; delete c.claudeAiOauth; writeAtomic(p.creds, JSON.stringify(c)); } catch { } }
        const g = readJson(p.cfg) || {}; if (backup.cfgAcct) g.oauthAccount = backup.cfgAcct; else delete g.oauthAccount; writeAtomic(p.cfg, JSON.stringify(g, null, 2));
        log('[accounts] switch rolled back');
      }
    };
  }
  // ייבוא מכניסה שנעשתה בתיקייה זמנית ("הוספת חשבון")
  function importFrom(dir) {
    const live = readLive(dir); if (!live) throw new Error('לא נמצאה כניסה שמורה בתיקייה הזמנית');
    const prev = readEntry(live.id); const e = entryFromLive(live, prev); writeEntry(e);
    log('[accounts] ' + (prev ? 'refreshed' : 'added') + ' account ' + (e.email || e.id));
    return { entry: pub(e, activeId()), isNew: !prev };
  }
  function remove(id) {
    if (!readEntry(id)) return false;
    if (activeId() === id) throw Object.assign(new Error('זה החשבון הפעיל — קודם החלף לחשבון אחר (או התנתק)'), { status: 409 });
    fs.unlinkSync(entryFile(id)); log('[accounts] removed ' + id); return true;
  }
  function setDeviceAuth(id, on) { const e = readEntry(id); if (!e) return null; e.deviceAuth = !!on; writeEntry(e); return pub(e, activeId()); }
  // לאימות טלפון: אילו חשבונות מותרים / חסומים במפורש
  function devicePolicy() {
    try { snapshotActive(); } catch { }
    const all = listEntries(), m = e => ({ email: lc(e.email), orgId: e.orgUuid || null });
    return { allow: all.filter(e => e.deviceAuth !== false && e.email).map(m), deny: all.filter(e => e.deviceAuth === false && e.email).map(m) };
  }

  // =========================== מפתחות API ===========================
  const keyPreview = k => k ? String(k).slice(0, 10) + '…' + String(k).slice(-4) : '';
  function loadKeys() { const j = readJson(KEYS_FILE); return j && Array.isArray(j.keys) ? j.keys.filter(k => k && k.id && typeof k.key === 'string') : []; }
  function saveKeys(keys) { writeAtomic(KEYS_FILE, JSON.stringify({ keys }, null, 2)); }
  const validKey = k => typeof k === 'string' && k.trim().length >= 20 && !/\s/.test(k.trim());
  const clean = (s, n) => String(s == null ? '' : s).replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, n);
  // המפתח הפעיל (cfg.apiKey) תמיד מופיע ברשימה — גם מפתח שהוגדר לפני שהייתה רשימה
  function keysEnsure(activeKey) {
    const keys = loadKeys();
    if (activeKey && !keys.some(k => k.key === activeKey)) { keys.unshift({ id: crypto.randomUUID(), name: 'מפתח ראשי', account: '', key: activeKey, addedAt: Date.now() }); saveKeys(keys); }
    return keys;
  }
  function keysList(activeKey) { return keysEnsure(activeKey).map(k => ({ id: k.id, name: k.name || '', account: k.account || '', preview: keyPreview(k.key), active: !!activeKey && k.key === activeKey, addedAt: k.addedAt || 0, lastUsedAt: k.lastUsedAt || 0 })); }
  function keyAdd({ key, name, account }, activeKey) {
    key = String(key || '').trim(); if (!validKey(key)) throw Object.assign(new Error('מפתח לא תקין (מתחיל ב-sk-ant-…)'), { status: 400 });
    const keys = keysEnsure(activeKey);
    const dup = keys.find(k => k.key === key); if (dup) throw Object.assign(new Error('המפתח הזה כבר שמור בשם "' + (dup.name || '') + '"'), { status: 409 });
    const k = { id: crypto.randomUUID(), name: clean(name, 60) || 'מפתח ' + (keys.length + 1), account: clean(account, 120), key, addedAt: Date.now() };
    keys.push(k); saveKeys(keys); return k;
  }
  function keyEdit(id, patch, activeKey) {
    const keys = keysEnsure(activeKey); const k = keys.find(x => x.id === id); if (!k) throw Object.assign(new Error('המפתח לא נמצא'), { status: 404 });
    const old = k.key;
    if (patch.name != null) k.name = clean(patch.name, 60) || k.name;
    if (patch.account != null) k.account = clean(patch.account, 120);
    if (patch.key != null && String(patch.key).trim()) {
      const nk = String(patch.key).trim(); if (!validKey(nk)) throw Object.assign(new Error('מפתח לא תקין'), { status: 400 });
      if (keys.some(x => x !== k && x.key === nk)) throw Object.assign(new Error('המפתח הזה כבר שמור'), { status: 409 });
      k.key = nk;
    }
    saveKeys(keys); return { key: k, wasActive: !!activeKey && old === activeKey, oldKey: old };
  }
  function keyRemove(id, activeKey) {
    const keys = keysEnsure(activeKey); const i = keys.findIndex(x => x.id === id); if (i < 0) return null;
    const [k] = keys.splice(i, 1); saveKeys(keys); return { key: k, wasActive: !!activeKey && k.key === activeKey };
  }
  function keyGet(id, activeKey) { return keysEnsure(activeKey).find(x => x.id === id) || null; }
  function keyTouch(id) { const keys = loadKeys(); const k = keys.find(x => x.id === id); if (k) { k.lastUsedAt = Date.now(); saveKeys(keys); } }

  // 🌐 tokens of every account of this system that may admit devices (the account mailbox, accountbox.js):
  // the live login as is (the CLI keeps it fresh), saved ones refreshed here when they are about to expire
  async function deviceTokens() {
    const out = []; const live = readLive(); const liveId = live ? live.id : null;
    if (live && live.oauth && live.oauth.accessToken) out.push({ email: lc((live.oauthAccount || {}).emailAddress || ''), token: live.oauth.accessToken });
    for (const e of listEntries()) {
      if (e.id === liveId || e.deviceAuth === false || !e.oauth || !e.oauth.refreshToken) continue;
      try {
        if (!e.oauth.accessToken || (e.oauth.expiresAt || 0) < Date.now() + 120000) {
          const r = await fetch('https://console.anthropic.com/v1/oauth/token', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ grant_type: 'refresh_token', refresh_token: e.oauth.refreshToken, client_id: '9d1c250a-e61b-44d9-88ed-5944d1962f5e' }), signal: AbortSignal.timeout(20000) });
          const j = await r.json().catch(() => ({})); if (!r.ok || !j.access_token) { log('[accounts] refresh ' + (e.email || e.id) + ': ' + (j.error || r.status)); continue; }
          e.oauth = { ...e.oauth, accessToken: j.access_token, refreshToken: j.refresh_token || e.oauth.refreshToken, expiresAt: Date.now() + (Number(j.expires_in) || 3600) * 1000 }; writeEntry(e);
        }
        out.push({ email: lc(e.email), token: e.oauth.accessToken });
      } catch (err) { log('[accounts] token ' + err.message); }
    }
    return out;
  }
  return { deviceTokens, cliPaths, readLive, snapshotActive, list, activeId, switchTo, importFrom, remove, setDeviceAuth, devicePolicy, readEntry, keysList, keyAdd, keyEdit, keyRemove, keyGet, keyTouch, keyPreview };
}
module.exports = { createAccounts };
