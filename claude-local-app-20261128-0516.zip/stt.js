'use strict';
// ============================================================
//  הכתבה קולית חיה (דיבור -> טקסט, עברית + אנגלית בלבד)
//  הדפדפן/EXE שולח אודיו PCM 16kHz מונו ב-WebSocket (/api/stt/ws) -> השרת מעביר ל-worker פייתון קבוע
//  (stt/stt_worker.py: faster-whisper, המודל נטען פעם אחת בשימוש הראשון ונשאר חם) -> טקסט ביניים + סופי חוזרים לדפדפן.
//  אין תלויות npm: שרת WebSocket מינימלי (RFC 6455) כאן.
//  משתני סביבה: STT_PYTHON (python עם faster-whisper), STT_MODEL, STT_DEVICE (auto|cuda|cpu), STT_COMPUTE.
// ============================================================
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { EventEmitter } = require('events');

const WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MAX_FRAME = 8 * 1024 * 1024;

// ---------- WebSocket מינימלי (צד שרת) ----------
class WsConn extends EventEmitter {
  constructor(socket, head) {
    super();
    this.socket = socket; this.buf = head && head.length ? Buffer.from(head) : Buffer.alloc(0); this.frag = null; this.closed = false;
    socket.setNoDelay(true);
    socket.on('data', d => { this.buf = this.buf.length ? Buffer.concat([this.buf, d]) : d; this.parse(); });
    socket.on('close', () => this._closed());
    socket.on('error', () => this._closed());
    if (this.buf.length) setImmediate(() => this.parse());
  }
  _closed() { if (this.closed) return; this.closed = true; this.emit('close'); }
  parse() {
    while (!this.closed) {
      const b = this.buf;
      if (b.length < 2) return;
      const fin = (b[0] & 0x80) !== 0, op = b[0] & 0x0f, masked = (b[1] & 0x80) !== 0;
      let len = b[1] & 0x7f, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; len = Number(b.readBigUInt64BE(2)); off = 10; }
      if (len > MAX_FRAME) return this.close(1009);
      const mlen = masked ? 4 : 0;
      if (b.length < off + mlen + len) return;
      let payload = Buffer.from(b.subarray(off + mlen, off + mlen + len));
      if (masked) { const m = b.subarray(off, off + 4); for (let i = 0; i < payload.length; i++) payload[i] ^= m[i & 3]; }
      this.buf = b.subarray(off + mlen + len);
      if (op === 0x8) return this.close();
      if (op === 0x9) { this.frame(0xA, payload); continue; }
      if (op === 0xA) continue;
      if (op === 0x0) { if (!this.frag) continue; this.frag.parts.push(payload); if (fin) { const f = this.frag; this.frag = null; this.deliver(f.op, Buffer.concat(f.parts)); } continue; }
      if (!fin) { this.frag = { op, parts: [payload] }; continue; }
      this.deliver(op, payload);
    }
  }
  deliver(op, data) { if (op === 0x1) this.emit('text', data.toString('utf8')); else if (op === 0x2) this.emit('binary', data); }
  frame(op, data) {
    if (this.closed) return;
    const n = data.length; let h;
    if (n < 126) { h = Buffer.alloc(2); h[1] = n; }
    else if (n < 65536) { h = Buffer.alloc(4); h[1] = 126; h.writeUInt16BE(n, 2); }
    else { h = Buffer.alloc(10); h[1] = 127; h.writeBigUInt64BE(BigInt(n), 2); }
    h[0] = 0x80 | op;
    try { this.socket.write(Buffer.concat([h, data])); } catch { }
  }
  send(obj) { this.frame(0x1, Buffer.from(typeof obj === 'string' ? obj : JSON.stringify(obj), 'utf8')); }
  close(code = 1000) {
    if (this.closed) return;
    const p = Buffer.alloc(2); p.writeUInt16BE(code, 0); this.frame(0x8, p);
    try { this.socket.end(); } catch { }
    setTimeout(() => { try { this.socket.destroy(); } catch { } }, 1000).unref();
    this._closed();
  }
}

const isLocalHost = h => /^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/i.test(h || '');
const isLocalOrigin = o => !o || /^http:\/\/(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/i.test(o);

function createStt({ dataDir, rootDir, log = (...a) => console.log('[stt]', ...a) }) {
  const sessions = new Map();     // sid -> { ws, done }
  let worker = null;              // { proc, state: 'loading'|'ready'|'dead', info, error, stderr }
  let lastError = '';

  // מנוע ההכתבה צריך Python עם faster-whisper. סדר: משתנה סביבה · מה שעבד בפעם הקודמת במחשב הזה (נשמר בתיקיית הנתונים —
  // לא בקוד) · סביבה שהאפליקציה עצמה התקינה (%LOCALAPPDATA%\ClaudeLocal\stt-python). אין? האפליקציה מתקינה לבד (provisionPython).
  const LOCAL = process.env.LOCALAPPDATA || path.join(require('os').homedir(), 'AppData', 'Local');
  const PY_DIR = process.env.STT_PY_DIR || path.join(LOCAL, 'ClaudeLocal', 'stt-python');
  const REMEMBER = path.join(dataDir, 'stt', 'python.txt');
  function pythonCandidates() {
    const list = [];
    if (process.env.STT_PYTHON) list.push(process.env.STT_PYTHON);
    try { const r = fs.readFileSync(REMEMBER, 'utf8').trim(); if (r) list.push(r); } catch { }
    list.push(path.join(PY_DIR, 'python.exe'));
    list.push(path.join(rootDir, 'stt', 'venv', 'Scripts', 'python.exe'));
    return [...new Set(list)].filter(p => { try { return fs.statSync(p).isFile(); } catch { return false; } });
  }
  function remember(py) { try { fs.mkdirSync(path.dirname(REMEMBER), { recursive: true }); fs.writeFileSync(REMEMBER, py); } catch { } }
  // התקנה עצמית (פעם אחת): Python embeddable הרשמי (python.org) → pip → faster-whisper (+ ספריות CUDA אם יש כרטיס NVIDIA).
  // בתיקייה של האפליקציה בלבד — בלי התקנה במערכת ובלי לשנות PATH. המודלים עצמם יורדים בהפעלה הראשונה של המנוע.
  let provisioning = null; const prov = { state: 'idle', msg: '', error: '' };
  function run(cmd, args, opts = {}) {
    return new Promise((res, rej) => { const p = spawn(cmd, args, { windowsHide: true, ...opts }); let out = '', err = ''; p.stdout && p.stdout.on('data', d => out += d); p.stderr && p.stderr.on('data', d => err += d); p.on('error', rej); p.on('close', c => c === 0 ? res(out) : rej(new Error((err || out).trim().split('\n').slice(-3).join(' | ').slice(-400) || ('exit ' + c)))); });
  }
  async function download(url, dst) { const r = await fetch(url); if (!r.ok) throw new Error('הורדה נכשלה ' + r.status + ' ' + url); fs.writeFileSync(dst, Buffer.from(await r.arrayBuffer())); }
  function provisionPython() {
    if (provisioning) return provisioning;
    provisioning = (async () => {
      try {
        if (process.platform !== 'win32') throw new Error('התקנה אוטומטית נתמכת ב-Windows');
        const py = path.join(PY_DIR, 'python.exe');
        fs.mkdirSync(PY_DIR, { recursive: true });
        if (!fs.existsSync(py)) {
          prov.state = 'installing'; prov.msg = 'מוריד Python (פעם אחת)…'; log(prov.msg);
          const zip = path.join(PY_DIR, 'python-embed.zip');
          await download('https://www.python.org/ftp/python/3.11.9/python-3.11.9-embed-amd64.zip', zip);
          // tar של Windows (System32) — לא GNU tar של Git שעלול להיות ראשון ב-PATH (הוא קורא "C:" כשרת מרוחק ונכשל)
          await run(path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe'), ['-xf', zip, '-C', PY_DIR]); fs.unlinkSync(zip);
          // embeddable: מאפשרים site-packages (pip)
          const pth = fs.readdirSync(PY_DIR).find(f => /^python\d+\._pth$/.test(f));
          if (pth) { const f = path.join(PY_DIR, pth); fs.writeFileSync(f, fs.readFileSync(f, 'utf8').replace(/^#\s*import site/m, 'import site') + '\nLib\\site-packages\n'); }
        }
        let hasPip = true; try { await run(py, ['-m', 'pip', '--version']); } catch { hasPip = false; }
        if (!hasPip) { prov.msg = 'מתקין pip…'; const gp = path.join(PY_DIR, 'get-pip.py'); await download('https://bootstrap.pypa.io/get-pip.py', gp); await run(py, [gp, '--no-warn-script-location']); }
        let gpu = false; try { await run('nvidia-smi', ['-L']); gpu = true; } catch { }
        prov.msg = 'מתקין את מנוע זיהוי הדיבור (faster-whisper' + (gpu ? ' + CUDA' : '') + ')…'; log(prov.msg);
        await run(py, ['-m', 'pip', 'install', '--no-warn-script-location', '--disable-pip-version-check', 'faster-whisper', ...(gpu ? ['nvidia-cublas-cu12', 'nvidia-cudnn-cu12==9.*'] : [])]);
        await run(py, ['-c', 'import faster_whisper']);
        prov.state = 'done'; prov.msg = 'מנוע ההכתבה הותקן'; log(prov.msg, py);
        return py;
      } catch (e) { prov.state = 'error'; prov.error = e.message; log('provision failed', e.message); return null; }
      finally { provisioning = null; }
    })();
    return provisioning;
  }

  // הסקריפט נקרא מתוך האפליקציה (גם מתוך app.asar של ה-EXE) ונכתב לתיקיית הנתונים, כי פייתון לא קורא מתוך asar
  function workerScript() {
    const src = fs.readFileSync(path.join(rootDir, 'stt', 'stt_worker.py'));
    const dir = path.join(dataDir, 'stt'); fs.mkdirSync(dir, { recursive: true });
    const dst = path.join(dir, 'stt_worker.py');
    let same = false; try { same = fs.readFileSync(dst).equals(src); } catch { }
    if (!same) fs.writeFileSync(dst, src);
    return dst;
  }

  function broadcast(ev) { for (const s of sessions.values()) s.ws.send(ev); }

  function ensureWorker(pyList) {
    if (worker && worker.state !== 'dead') return worker;
    const cands = pyList || pythonCandidates();
    if (!cands.length) {
      // אין Python עם faster-whisper — מתקינים לבד ומפעילים כשמוכן
      lastError = 'מתקין את מנוע ההכתבה (פעם אחת, אוטומטית)…';
      provisionPython().then(py => { if (py) { broadcast({ type: 'status', state: 'loading' }); ensureWorker([py]); } else { lastError = 'התקנת מנוע ההכתבה נכשלה: ' + prov.error; for (const s of sessions.values()) { s.ws.send({ type: 'error', message: lastError }); s.done = true; } } });
      broadcast({ type: 'status', state: 'installing', message: lastError });
      return null;
    }
    const py = cands[0];
    let script; try { script = workerScript(); } catch (e) { lastError = 'קובץ מנוע ההכתבה חסר: ' + e.message; return null; }
    const proc = spawn(py, ['-I', script], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true, env: { ...process.env, PYTHONIOENCODING: 'utf-8' } });
    const w = worker = { proc, state: 'loading', info: null, error: '', stderr: '', python: py, startedAt: Date.now() };
    log('starting worker', py);
    let out = '';
    proc.stdout.setEncoding('utf8');
    proc.stdout.on('data', d => {
      out += d; let i;
      while ((i = out.indexOf('\n')) >= 0) {
        const line = out.slice(0, i); out = out.slice(i + 1);
        let ev; try { ev = JSON.parse(line); } catch { continue; }
        onEvent(w, ev);
      }
    });
    proc.stderr.setEncoding('utf8');
    proc.stderr.on('data', d => { w.stderr = (w.stderr + d).slice(-4000); });
    proc.stdin.on('error', () => { });
    proc.on('error', e => { w.error = e.message; });
    proc.on('exit', code => {
      const wasLoading = w.state === 'loading';
      w.state = 'dead';
      const tail = (w.stderr || '').trim().split('\n').slice(-3).join(' | ');
      lastError = w.error || ('מנוע ההכתבה נסגר (קוד ' + code + ')' + (tail ? ': ' + tail.slice(-300) : ''));
      log('worker exited', code, tail.slice(-300));
      // python בלי faster-whisper: מנסים את המועמד הבא
      if (wasLoading && /No module named/.test(w.stderr) && cands.length > 1) { ensureWorker(cands.slice(1)); if (worker && worker.state !== 'dead') { broadcast({ type: 'status', state: 'loading' }); for (const [sid, s] of sessions) if (!s.done) send({ op: 'start', sid, lang: s.lang }); return; } }
      for (const [sid, s] of sessions) { s.ws.send({ type: 'error', message: 'מנוע זיהוי הדיבור לא עלה: ' + lastError }); s.done = true; }
    });
    return w;
  }

  function onEvent(w, ev) {
    if (ev.type === 'ready') { w.state = 'ready'; w.info = ev; remember(w.python); log('ready', ev.model, ev.device, ev.compute, ev.load_ms + 'ms'); broadcast({ type: 'status', state: 'ready', device: ev.device }); return; }
    if (ev.type === 'models') { w.info = { ...(w.info || {}), en_model: ev.en_model, lid_model: ev.lid_model, rest_load_ms: ev.load_ms }; log('english/language-id ready', ev.en_model, ev.lid_model, ev.load_ms + 'ms'); return; }
    if (ev.type === 'error' && !ev.sid) { w.error = ev.message; lastError = ev.message; return; }
    const s = ev.sid && sessions.get(ev.sid);
    if (!s) return;
    if (ev.type === 'error') { s.ws.send({ type: 'error', message: 'שגיאה בזיהוי הדיבור: ' + ev.message }); return; }
    if (ev.type === 'done') s.done = true;
    s.ws.send(ev);
  }

  function send(obj, bin) {
    if (!worker || worker.state === 'dead') return false;
    try { worker.proc.stdin.write(JSON.stringify(obj) + '\n'); if (bin) worker.proc.stdin.write(bin); return true; } catch { return false; }
  }

  function handleUpgrade(req, socket, head) {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname !== '/api/stt/ws') return false;
    // רק מהממשק המקומי (כמו כל ה-API): Host ו-Origin מקומיים
    if (!isLocalHost(req.headers.host) || !isLocalOrigin(req.headers.origin)) { socket.end('HTTP/1.1 403 Forbidden\r\n\r\n'); return true; }
    const key = req.headers['sec-websocket-key'];
    if (!key || String(req.headers.upgrade || '').toLowerCase() !== 'websocket') { socket.end('HTTP/1.1 400 Bad Request\r\n\r\n'); return true; }
    const accept = crypto.createHash('sha1').update(key + WS_GUID).digest('base64');
    socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
    serveSession(new WsConn(socket, head));
    return true;
  }
  // סשן הכתבה על כל "צינור" עם אותו ממשק כמו WsConn: send(obj) / close() / אירועים text, binary, close.
  // מקומי = WebSocket; מהטלפון = ערוץ מוצפן ברשת המחשבים (mesh.js chopen 'stt') — אותו מנוע, אותה איכות.
  function serveSession(ws) {
    let sid = null;
    ws.on('text', t => {
      let m; try { m = JSON.parse(t); } catch { return; }
      if (m.op === 'start' && !sid) {
        const lang = ['he', 'en', 'auto'].includes(m.lang) ? m.lang : (process.env.STT_LANG || 'auto');
        const w = ensureWorker();
        if (!w) { ws.send({ type: 'error', message: 'מנוע זיהוי הדיבור לא זמין: ' + lastError }); return ws.close(); }
        sid = crypto.randomBytes(8).toString('hex');
        sessions.set(sid, { ws, lang, done: false });
        send({ op: 'start', sid, lang });
        ws.send({ type: 'status', state: w.state, sid, device: w.info && w.info.device });
      } else if (m.op === 'stop' && sid) send({ op: 'stop', sid });
    });
    ws.on('binary', data => { if (sid && data.length) send({ op: 'audio', sid, n: data.length }, data); });
    ws.on('close', () => { if (sid) { const s = sessions.get(sid); if (s && !s.done) send({ op: 'cancel', sid }); sessions.delete(sid); } });
  }

  function status() {
    const w = worker;
    return { state: w ? w.state : (provisioning ? 'installing' : 'off'), python: w ? w.python : (pythonCandidates()[0] || null), info: w && w.info, error: (w && w.state === 'dead') || !w ? lastError : '', sessions: sessions.size, install: { ...prov } };
  }
  function warm() { ensureWorker(); return status(); }
  function shutdown() { try { if (worker && worker.state !== 'dead') worker.proc.kill(); } catch { } }
  process.on('exit', shutdown);

  return { handleUpgrade, serveSession, status, warm, shutdown };
}

module.exports = { createStt, WsConn };
