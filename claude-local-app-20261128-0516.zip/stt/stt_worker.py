"""Live dictation worker (Hebrew + English only) for Claude Local.

The Node server (stt.js) starts this process once, on first use, and keeps it alive: the model is loaded ONCE.
Protocol (binary-safe, one request per line on stdin, JSON events per line on stdout, ASCII-escaped):
  stdin:  {"op":"start","sid":"..","lang":"auto|he|en"}\n
          {"op":"audio","sid":"..","n":<bytes>}\n  followed by <bytes> of PCM int16 little-endian, 16 kHz mono
          {"op":"stop","sid":".."}\n     finish: decode what is left, send its final, then "done"
          {"op":"cancel","sid":".."}\n   drop the session (no more events)
          {"op":"ping"}\n
  stdout: {"type":"ready",...} {"type":"models",...} {"type":"partial","sid","text"} {"type":"final","sid","text","lang","ms"}
          {"type":"done","sid"} {"type":"error","message"} {"type":"pong"}
Live algorithm: Silero VAD (bundled with faster-whisper, run statefully) marks speech per 32 ms frame. While an
utterance is in progress its whole audio is re-decoded (greedy) every STEP seconds -> "partial" (words appear live and
get corrected). After END_SIL of silence the utterance is decoded once more with beam search -> "final" (committed).
Models (chosen by measurement, tests/stt_eval.py): Hebrew = ivrit.ai large-v3-turbo fine-tune; English = general
large-v3-turbo; language = whisper-small, he/en ONLY (no other language can be produced), English checked by decoder
confidence before it is accepted.
"""
import argparse, json, os, sys, threading, time, re

import numpy as np

SR = 16000
FRAME = 512                      # Silero frame = 32 ms
STEP_S = float(os.environ.get("STT_STEP_S", "0.4"))        # interim re-decode period (audio seconds)
END_SIL_S = float(os.environ.get("STT_END_SIL_S", "0.8"))  # silence that ends an utterance
MAX_UTT_S = float(os.environ.get("STT_MAX_UTT_S", "24"))   # force a cut before Whisper's 30 s window
PAD_S = 0.3              # audio kept after the last speech frame
PRE_PAD_S = 0.4          # and before the first one (VAD onset lags the first syllable)
EN_THRESHOLD = float(os.environ.get("STT_EN_THRESHOLD", "0.8"))   # P(en) share needed to call an utterance English
# live (interim) text: Hebrew until the utterance has LID_MIN_S of audio, then its language is decided once with the
# stricter LIVE_EN_THRESHOLD. Measured on speech-onset prefixes: 2 s @0.9 -> 12/12 English right, 2/80 Hebrew wrong;
# 1.5 s @0.9 -> 6/80 Hebrew wrong. The final text re-decides on the whole utterance (EN_THRESHOLD).
LID_MIN_S = 2.0
LIVE_EN_THRESHOLD = 0.9
SPEECH_P, SILENCE_P = 0.5, 0.35

# protocol output = the real stdout; anything else printing (libraries) goes to stderr
_OUT = os.fdopen(os.dup(1), "w", encoding="ascii", errors="backslashreplace", buffering=1)
os.dup2(2, 1)
sys.stdout = sys.stderr
_out_lock = threading.Lock()


def emit(**o):
    with _out_lock:
        _OUT.write(json.dumps(o, ensure_ascii=True) + "\n")
        _OUT.flush()


def log(*a):
    print("[stt]", *a, file=sys.stderr, flush=True)


def add_cuda_dlls():
    """cuBLAS/cuDNN for CTranslate2 on Windows ship inside torch/lib (or nvidia-* wheels): add them without importing torch."""
    import importlib.util
    dirs = []
    spec = importlib.util.find_spec("torch")
    if spec and spec.submodule_search_locations:
        dirs.append(os.path.join(list(spec.submodule_search_locations)[0], "lib"))
    for pkg in ("nvidia.cublas", "nvidia.cudnn"):
        try:
            s = importlib.util.find_spec(pkg)
            if s and s.submodule_search_locations:
                dirs.append(os.path.join(list(s.submodule_search_locations)[0], "bin"))
        except Exception:
            pass
    for d in dirs:
        if os.path.isdir(d):
            try:
                os.add_dll_directory(d)
            except Exception:
                pass
            os.environ["PATH"] = d + os.pathsep + os.environ.get("PATH", "")


_BIDI = re.compile("[‎‏‪-‮⁦-⁩﻿]")


def clean(t):
    return " ".join(_BIDI.sub("", t or "").split())


class Engine:
    """Hebrew model (ivrit.ai fine-tune) + English model (general Whisper) + he/en language id.
    Measured on this machine (tests/stt_eval.py): the Hebrew fine-tune is the most accurate on Hebrew but always
    detects "he" and is weak on English; the general model is accurate on English and detects he/en reliably."""

    def __init__(self, he_name, en_name, lid_name, device, compute):
        from faster_whisper import WhisperModel
        from faster_whisper.vad import get_vad_model
        import ctranslate2
        t0 = time.time()
        if device == "auto":
            device = "cuda" if ctranslate2.get_cuda_device_count() > 0 else "cpu"
        if compute == "auto":
            if device == "cuda":
                types = ctranslate2.get_supported_compute_types("cuda")
                compute = "int8_float16" if "int8_float16" in types else "int8"   # Pascal (GTX 10xx): int8
            else:
                compute = "int8"
        self._cache = {}
        try:
            self.he = self._load(WhisperModel, he_name, device, compute)
            self._warm(self.he, "he")
        except Exception as e:  # no usable GPU (driver/VRAM): CPU still works, slower
            if device != "cuda":
                raise
            log("cuda failed, falling back to cpu:", repr(e))
            device, compute = "cpu", "int8"
            self.he = self._load(WhisperModel, he_name, device, compute)
            self._warm(self.he, "he")
        self.device, self.compute = device, compute
        self.en = self.lid = None              # loaded in the background: Hebrew dictation works as soon as `he` is up
        self.names = {"he": he_name, "en": he_name, "lid": "none"}
        self.vad = get_vad_model()
        self.encodes = 0
        self._wrap_encode(self.he)
        self.load_ms = int(1000 * (time.time() - t0))
        threading.Thread(target=self._load_rest, args=(WhisperModel, he_name, en_name, lid_name), daemon=True).start()

    def _load_rest(self, WhisperModel, he_name, en_name, lid_name):
        t0 = time.time()
        device, compute = self.device, self.compute
        en = lid = None
        if en_name and en_name != "none" and en_name != he_name:
            try:
                en = self._load(WhisperModel, en_name, device, compute)
                self._warm(en, "en")
                self._wrap_encode(en)
            except Exception as e:
                log("english model not available, Hebrew model will do English too:", repr(e))
        if lid_name == "en":
            lid = en
        elif lid_name and lid_name != "none":
            try:
                lid = self._load(WhisperModel, lid_name, device, compute)
                self._wrap_encode(lid)
            except Exception as e:
                log("language-id model not available:", repr(e))
                lid = en
        self.en = en
        self.lid = lid                         # set last: language() needs it, decode() then finds self.en ready
        self.names = {"he": he_name, "en": en_name if en else he_name, "lid": lid_name if lid else "none"}
        ms = int(1000 * (time.time() - t0))
        log(f"english + language-id models ready in {ms} ms: {self.names}")
        emit(type="models", en_model=self.names["en"], lid_model=self.names["lid"], load_ms=ms)

    def _wrap_encode(self, m):
        """One encoder pass can serve both language detection and decoding (same model, same features)."""
        orig = m.encode

        def encode(features, *args, _orig=orig, _id=id(m), **kw):
            c = self._cache.get(_id)
            if c is not None and c[0].shape == features.shape and np.array_equal(c[0], features):
                return c[1]
            self.encodes += 1
            return _orig(features, *args, **kw)
        m.encode = encode

    @staticmethod
    def _load(WhisperModel, name, device, compute):
        # CPU fallback only (no usable GPU): measured ~5 s per decode with 16 threads vs ~6 s default -> not live, but works
        kw = {"cpu_threads": max(4, (os.cpu_count() or 8) // 2)} if device == "cpu" else {}
        try:
            return WhisperModel(name, device=device, compute_type=compute, local_files_only=True, **kw)
        except Exception as e:
            if "local" not in str(e).lower() and "not found" not in str(e).lower() and "cannot find" not in str(e).lower():
                raise
            log("model not in cache, downloading", name)
            return WhisperModel(name, device=device, compute_type=compute, **kw)

    @staticmethod
    def _warm(m, lang):
        segs, _ = m.transcribe(np.zeros(SR, np.float32), language=lang, beam_size=1, without_timestamps=True)
        list(segs)

    def speech_probs(self, audio, state):
        """Silero speech probability per 512-sample frame (len(audio) a multiple of 512). STATEFUL streaming: the
        recurrent state + 64-sample context carry over between calls, so 0.4 s pieces score exactly like one
        whole-file pass (resetting the state each call missed speech - measured)."""
        n = len(audio) // FRAME
        if n == 0:
            return np.zeros(0, np.float32)
        frames = audio[: n * FRAME].reshape(n, FRAME).astype(np.float32)
        ctx = np.concatenate([state["ctx"][None], frames[:-1, -64:]], 0) if n > 1 else state["ctx"][None]
        inp = np.concatenate([ctx, frames], 1)
        out, state["h"], state["c"] = self.vad.session.run(None, {"input": inp, "h": state["h"], "c": state["c"]})
        state["ctx"] = frames[-1, -64:].copy()
        return np.asarray(out, np.float32).reshape(-1)

    def _encode(self, m, audio):
        from faster_whisper.audio import pad_or_trim
        features = m.feature_extractor(audio)
        content = features.shape[-1] - 1
        seg = pad_or_trim(features[:, : min(m.feature_extractor.nb_max_frames, content)])
        enc = m.encode(seg)
        self._cache[id(m)] = (seg, enc)
        return enc

    def language(self, audio, threshold=None):
        """'he' or 'en' only (no other language can ever be chosen). English needs P(en)/(P(he)+P(en)) >= EN_THRESHOLD:
        measured on full utterances, 0.8 kept every English clip (12/12) and cut Hebrew->English mistakes to 1/80."""
        if self.lid is None:
            return "he"
        enc = self._encode(self.lid, audio)
        try:
            probs = dict(self.lid.model.detect_language(enc)[0])
        finally:
            if self.lid is not self.en and self.lid is not self.he:  # else decode() reuses this encoder pass
                self._cache.pop(id(self.lid), None)
        ph, pe = probs.get("<|he|>", 0.0), probs.get("<|en|>", 0.0)
        return "en" if pe / max(1e-9, ph + pe) >= (threshold or EN_THRESHOLD) else "he"

    def _run(self, lang, audio, beam):
        m = self.en if (lang == "en" and self.en is not None) else self.he
        segs, _ = m.transcribe(audio, language=lang, beam_size=beam, best_of=beam,
                               temperature=[0.0] if beam == 1 else [0.0, 0.2, 0.4],
                               condition_on_previous_text=False, without_timestamps=True, vad_filter=False)
        segs = list(segs)
        n = sum(max(1, len(s.tokens)) for s in segs) or 1
        lp = sum(s.avg_logprob * max(1, len(s.tokens)) for s in segs) / n
        return clean(" ".join(s.text.strip() for s in segs)), lp

    def decode(self, audio, lang, beam, verify=False):
        """Text of one utterance (<= 30 s). lang: 'he' | 'en' | 'auto'.
        verify (final text): when the language id says English, the utterance is ALSO decoded as Hebrew and the more
        confident decode wins. Measured: Hebrew clips scored >= 0.35 higher as Hebrew (incl. a Kan clip both language
        detectors called English), English clips >= 0.04 higher as English (14/14)."""
        t0 = time.time()
        try:
            if lang not in ("he", "en"):
                lang = self.language(audio)
                if verify and lang == "en" and self.en is not None:
                    t_en, lp_en = self._run("en", audio, beam)
                    t_he, lp_he = self._run("he", audio, beam)
                    log(f"verify en {lp_en:.3f} vs he {lp_he:.3f}")
                    text, lang = (t_en, "en") if lp_en > lp_he else (t_he, "he")
                    return text, lang, int(1000 * (time.time() - t0))
            text, _ = self._run(lang, audio, beam)
        finally:
            self._cache.clear()
        return text, lang, int(1000 * (time.time() - t0))


class Session:
    def __init__(self, sid, lang):
        self.sid, self.lang = sid, (lang if lang in ("he", "en", "auto") else "auto")
        self.buf = np.zeros(0, np.float32)   # audio from sample self.base on
        self.base = 0                        # absolute index of buf[0]
        self.total = 0                       # absolute samples received
        self.probs = np.zeros(0, np.float32) # VAD prob per absolute frame
        self.utt = 0                         # absolute start of the uncommitted region
        self.last_interim = 0                # absolute sample count at the last interim decode
        self.last_partial = ""
        self.utt_lang = None
        self.stopping = False
        self.cancelled = False
        self.done = False
        self.lock = threading.Lock()          # reader thread appends while the decoder reads/trims
        self.vad_state = {"h": np.zeros((1, 1, 128), np.float32), "c": np.zeros((1, 1, 128), np.float32), "ctx": np.zeros(64, np.float32)}

    def append(self, pcm16):
        a = np.frombuffer(pcm16, dtype="<i2").astype(np.float32) / 32768.0
        with self.lock:
            self.buf = np.concatenate([self.buf, a])
            self.total += len(a)

    def audio(self, start, end):
        with self.lock:
            return self.buf[max(0, start - self.base): max(0, end - self.base)]

    def trim(self):
        keep_from = max(0, self.utt - SR)  # keep 1 s before the uncommitted region (VAD context)
        with self.lock:
            if keep_from - self.base > SR * 5:
                self.buf = self.buf[keep_from - self.base:]
                self.base = keep_from


class Worker:
    def __init__(self, engine):
        self.e = engine
        self.sessions = {}
        self.cv = threading.Condition()
        self.eof = False                 # stdin closed = the server is gone -> exit

    # ---- stdin reader ----
    def reader(self):
        inp = sys.stdin.buffer
        while True:
            line = inp.readline()
            if not line:
                with self.cv:
                    self.eof = True
                    self.cv.notify_all()
                return
            try:
                msg = json.loads(line)
            except Exception:
                continue
            op = msg.get("op")
            if op == "audio":
                n = int(msg.get("n", 0))
                data = inp.read(n) if n > 0 else b""
                with self.cv:
                    s = self.sessions.get(msg.get("sid"))
                    if s and not s.stopping:
                        s.append(data[: len(data) - len(data) % 2])
                        self.cv.notify_all()
            elif op == "start":
                with self.cv:
                    self.sessions[msg["sid"]] = Session(msg["sid"], msg.get("lang", "auto"))
                    self.cv.notify_all()
            elif op == "stop":
                with self.cv:
                    s = self.sessions.get(msg.get("sid"))
                    if s:
                        s.stopping = True
                    else:
                        emit(type="done", sid=msg.get("sid"))
                    self.cv.notify_all()
            elif op == "cancel":
                with self.cv:
                    s = self.sessions.pop(msg.get("sid"), None)
                    if s:
                        s.cancelled = True
            elif op == "ping":
                emit(type="pong")

    # ---- decoder loop ----
    def has_work(self, s):
        return s.stopping or (s.total - s.last_interim) >= STEP_S * SR

    def loop(self):
        while True:
            with self.cv:
                while not self.eof and not any(self.has_work(s) for s in self.sessions.values()):
                    self.cv.wait(0.5)
                if self.eof and not self.sessions:
                    return
                work = [s for s in self.sessions.values() if self.has_work(s)]
            for s in work:
                try:
                    self.step(s)
                except Exception as ex:
                    log("step failed:", repr(ex))
                    emit(type="error", sid=s.sid, message=str(ex)[:300])
                    s.stopping, s.done = True, True
                if s.done:
                    with self.cv:
                        self.sessions.pop(s.sid, None)
            if self.eof and not self.sessions:
                return

    def update_vad(self, s, upto):
        """Speech probs for every complete 512-frame up to absolute sample `upto`."""
        have = len(s.probs)
        nfr = upto // FRAME
        if nfr <= have:
            return
        start = have * FRAME
        a = s.audio(start, nfr * FRAME)
        if len(a) != (nfr - have) * FRAME:  # trimmed away (should not happen): treat as silence
            s.probs = np.concatenate([s.probs, np.zeros(nfr - have, np.float32)])
            return
        s.probs = np.concatenate([s.probs, self.e.speech_probs(a, s.vad_state)])

    def step(self, s):
        if s.cancelled:
            s.done = True
            return
        with self.cv:
            total, stopping = s.total, s.stopping
        self.update_vad(s, total)
        f0 = s.utt // FRAME
        p = s.probs[f0:]
        speech = np.nonzero(p >= SPEECH_P)[0]
        if len(speech) == 0:
            if stopping:
                emit(type="done", sid=s.sid)
                s.done = True
            elif total - s.utt > SR:           # silence only: slide the start forward
                s.utt = max(s.utt, total - int(0.5 * SR))
                s.last_interim = total
                s.trim()
            else:
                s.last_interim = total
            return
        first, last = f0 + speech[0], f0 + speech[-1]
        # silence after the last speech frame (frames below SILENCE_P, counted from the end)
        trailing = (len(s.probs) - 1 - last) * FRAME / SR
        start = max(s.utt, first * FRAME - int(PRE_PAD_S * SR))
        span = (total - start) / SR
        if stopping or trailing >= END_SIL_S:
            end = min(total, (last + 1) * FRAME + int(PAD_S * SR))
            self.finalize(s, start, end)
            if stopping:
                emit(type="done", sid=s.sid)
                s.done = True
            return
        if span >= MAX_UTT_S:                    # very long run-on speech: cut at the longest pause
            cut = self.best_cut(s, first, len(s.probs))
            self.finalize(s, start, cut)
            return
        # interim
        s.last_interim = total
        region = s.audio(start, total)
        lang = s.utt_lang or (s.lang if s.lang in ("he", "en") else None)
        if lang is None:
            if len(region) >= LID_MIN_S * SR:
                lang = s.utt_lang = self.e.language(region, LIVE_EN_THRESHOLD)   # once per utterance, for the live text
            else:
                lang = "he"                                  # Hebrew until there is enough audio to tell
        text, lang, ms = self.e.decode(region, lang, beam=1)
        if text != s.last_partial and not s.cancelled:
            s.last_partial = text
            emit(type="partial", sid=s.sid, text=text, lang=lang, ms=ms)

    def best_cut(self, s, first, nfr):
        p = s.probs[first:nfr] < SILENCE_P
        best, best_len, run_start = None, 0, None
        lo = int(5 * SR / FRAME)
        for i, sil in enumerate(p):
            if sil and run_start is None:
                run_start = i
            if (not sil or i == len(p) - 1) and run_start is not None:
                ln = i - run_start
                if run_start >= lo and ln > best_len:
                    best, best_len = run_start + ln // 2, ln
                run_start = None
        if best is None:
            return nfr * FRAME
        return (first + best) * FRAME

    def finalize(self, s, start, end):
        text, lang, ms = "", s.utt_lang or s.lang, 0
        if end - start >= int(0.2 * SR):
            text, lang, ms = self.e.decode(s.audio(start, end), s.lang, beam=5, verify=True)
        s.utt = end
        s.last_interim = s.total
        s.last_partial = ""
        s.utt_lang = None
        s.trim()
        if not s.cancelled:
            emit(type="final", sid=s.sid, text=text, lang=lang, ms=ms, at=round(end / SR, 2))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default=os.environ.get("STT_MODEL", "ivrit-ai/whisper-large-v3-turbo-ct2"))        # Hebrew
    ap.add_argument("--en-model", default=os.environ.get("STT_EN_MODEL", "mobiuslabsgmbh/faster-whisper-large-v3-turbo"))
    ap.add_argument("--lid-model", default=os.environ.get("STT_LID_MODEL", "Systran/faster-whisper-small"))  # 'en' = the English model
    ap.add_argument("--device", default=os.environ.get("STT_DEVICE", "auto"))
    ap.add_argument("--compute", default=os.environ.get("STT_COMPUTE", "auto"))
    a = ap.parse_args()
    add_cuda_dlls()
    w = Worker(None)
    th = threading.Thread(target=w.reader, daemon=True)
    th.start()                         # audio sent while the model loads is kept, not lost
    try:
        w.e = Engine(a.model, a.en_model, a.lid_model, a.device, a.compute)
    except Exception as ex:
        emit(type="error", message="model load failed: " + repr(ex)[:400])
        log("fatal:", repr(ex))
        return 2
    emit(type="ready", model=w.e.names["he"], en_model=w.e.names["en"], lid_model=w.e.names["lid"],
         device=w.e.device, compute=w.e.compute, load_ms=w.e.load_ms)
    log(f"ready {w.e.names} on {w.e.device}/{w.e.compute} in {w.e.load_ms} ms")
    w.loop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
