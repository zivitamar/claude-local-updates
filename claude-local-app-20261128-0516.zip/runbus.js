'use strict';
// ============================================================
//  Run bus: ריצה של שיחה מנותקת מחיבור ה-HTTP.
//  כל ריצה שומרת את האירועים של "האיטרציה" הנוכחית (טקסט/חשיבה מאוחדים, עדכוני סוכנים
//  מוחלפים במקום) כדי שכל לקוח יוכל להתחבר באמצע (attach): snapshot → replay → live.
//  בתחילת כל איטרציה (rebase) ההודעות שכבר נשמרו בשיחה הן הבסיס והמאגר מתאפס.
// ============================================================
const EVENT_CAP = 5000;

function createRun({ conv, title }) {
  return {
    id: conv.id, conv, title: title || conv.title || '', controller: new AbortController(), queue: [],
    startedAt: Date.now(), baseMsgCount: conv.messages.length, events: [], seq: 0, listeners: new Set(),
    pendingApproval: null, agents: new Map(), research: new Map(), lastEventAt: Date.now(), _agentIdx: new Map(), _researchIdx: new Map(),
    finished: false
  };
}

function emit(run, type, data) {
  run.lastEventAt = Date.now();
  const seq = ++run.seq;
  const last = run.events[run.events.length - 1];
  if ((type === 'text' || type === 'thinking') && last && last.type === type && data && typeof data.text === 'string') {
    last.data = { ...last.data, text: last.data.text + data.text };
  } else if (type === 'agent_update' && data && run._agentIdx.has(data.id)) {
    run.events[run._agentIdx.get(data.id)].data = data;
  } else if (type === 'research_update' && data && run._researchIdx.has(data.id)) {
    run.events[run._researchIdx.get(data.id)].data = data;
  } else {
    run.events.push({ seq, type, data });
    if (type === 'agent_update') run._agentIdx.set(data.id, run.events.length - 1);
    if (type === 'research_update') run._researchIdx.set(data.id, run.events.length - 1);
    if (run.events.length > EVENT_CAP) compact(run);
  }
  if (type === 'agent_update' && data) run.agents.set(data.id, data);
  if (type === 'research_update' && data) run.research.set(data.id, data);
  for (const l of [...run.listeners]) { try { l(type, data, seq); } catch { } }
}

// מאגר ענק (איטרציה ארוכה מאוד) — שומרים את הסוף ומחשבים מחדש את האינדקסים
function compact(run) {
  run.events = run.events.slice(-Math.floor(EVENT_CAP * 0.8));
  run._agentIdx.clear(); run._researchIdx.clear();
  run.events.forEach((e, i) => {
    if (e.type === 'agent_update') run._agentIdx.set(e.data.id, i);
    if (e.type === 'research_update') run._researchIdx.set(e.data.id, i);
  });
}

function rebase(run) {
  run.baseMsgCount = run.conv.messages.length;
  run.events = [];
  run._agentIdx.clear();
  run._researchIdx.clear();
}

const sse = (res, type, data, seq) => {
  if (res.writableEnded || res.destroyed) return;
  res.write(`${seq ? 'id: ' + seq + '\n' : ''}event: ${type}\ndata: ${JSON.stringify(data === undefined ? {} : data)}\n\n`);
};

function openSSE(res) {
  res.writeHead(200, { 'content-type': 'text/event-stream; charset=utf-8', 'cache-control': 'no-cache', connection: 'keep-alive', 'x-accel-buffering': 'no' });
  const hb = setInterval(() => { if (!res.writableEnded && !res.destroyed) res.write(': ping\n\n'); }, 15000);
  res.on('close', () => clearInterval(hb));
  return () => clearInterval(hb);
}

// snapshot של ריצה פעילה: ההודעות עד הבסיס + ההודעות שבתור + אישור שממתין
function snapshot(run) {
  const conv = run.conv;
  return {
    running: true, startedAt: run.startedAt, pendingApproval: run.pendingApproval,
    queued: run.queue.map(q => ({ id: q.id, ts: q.ts, content: q.content, ...(q.from ? { from: q.from } : {}), ...(q.fromInfo ? { fromInfo: q.fromInfo } : {}), ...(q.watch ? { watch: q.watch } : {}), ...(q.flow ? { flow: q.flow } : {}) })), // who sent a waiting message travels with it
    agents: [...run.agents.values()], research: [...run.research.values()],
    conv: { ...conv, system: undefined, messages: conv.messages.slice(0, run.baseMsgCount) }
  };
}

// מחבר תגובת HTTP לריצה: snapshot → replay → live → done
function attach(run, req, res, { withSnapshot = true, mapSnapshot = null } = {}) {
  const stopHb = openSSE(res);
  if (withSnapshot) { const s = snapshot(run); sse(res, 'snapshot', mapSnapshot ? mapSnapshot(s) : s); }
  for (const ev of run.events) sse(res, ev.type, ev.data, ev.seq);
  const l = (type, data, seq) => {
    sse(res, type, data, seq);
    if (type === 'done') { run.listeners.delete(l); stopHb(); if (!res.writableEnded) res.end(); }
  };
  run.listeners.add(l);
  const off = () => run.listeners.delete(l);
  // רק res 'close' (ב-Node 16+ האירוע 'close' של req יכול לקפוץ מיד אחרי קריאת גוף הבקשה)
  res.on('close', off);
  return off;
}

module.exports = { createRun, emit, rebase, attach, snapshot, openSSE, sse };
