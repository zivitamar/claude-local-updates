'use strict';
// ============================================================
//  תת-סוכנים (הכלי "agent"): מופע Claude עצמאי שעובד על משימה אחת עם כלים משלו
//  ומחזיר דוח לסוכן הראשי. כמה סוכנים באותה תשובה רצים במקביל.
//  הרישום (registry) שומר לכל סוכן: סטטוס, פעילות נוכחית בעברית, צעדים, טוקנים, עלות,
//  תמליל אירועים חי (לפאנל הסוכנים) — ונשמר לדיסק ב-data/agents/<id>.json.
//  כל התלויות מוזרקות (deps) כדי שאפשר יהיה לבדוק את המודול עם Claude מדומה.
// ============================================================
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const MAX_STEPS = 60;
const EVENT_CAP = 2000;
const OUT_CAP = 4000;
const NOTIFY_MS = 400;
const TERMINAL = new Set(['done', 'error', 'stopped', 'interrupted']);

const AGENT_TOOL = {
  name: 'agent',
  description:
    'Launch a sub-agent: an independent Claude instance that works on ONE self-contained task with its own context and tools ' +
    '(shell, files, web search/fetch) and returns a final report to you. Use it to parallelize independent work — call "agent" ' +
    'several times in ONE response and the sub-agents run at the same time — or to offload a large exploration/search that would ' +
    'flood your own context. The sub-agent does NOT see this conversation: put every needed detail (paths, goals, constraints, ' +
    'what to return) in the prompt. The user watches every sub-agent live in the Agents panel and can stop it.',
  input_schema: {
    type: 'object',
    properties: {
      description: { type: 'string', description: 'Short label (3-6 words) shown to the user, e.g. "Scan logs for errors"' },
      prompt: { type: 'string', description: 'The full, self-contained task for the sub-agent, including exactly what it should report back' },
      model: { type: 'string', description: 'Optional: "haiku" (fast, cheap), "sonnet", "opus", or an exact model id. Default: the configured agent model' }
    },
    required: ['description', 'prompt']
  }
};

const short = (s, n) => { s = String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
const base = p => String(p || '').split(/[\\/]/).filter(Boolean).pop() || String(p || '');

// תיאור פעילות בעברית לפי הכלי
function activityFor(name, input) {
  const i = input || {};
  switch (name) {
    case 'run_command': return 'מריץ פקודה: ' + short(i.command, 70);
    case 'read_file': return 'קורא: ' + short(base(i.path), 60);
    case 'write_file': return 'כותב קובץ: ' + short(base(i.path), 60);
    case 'edit_file': return 'עורך: ' + short(base(i.path), 60);
    case 'list_directory': return 'מציג תיקייה: ' + short(i.path || '.', 60);
    case 'search_files': return 'מחפש: ' + short(i.pattern, 60);
    case 'web_search': return 'מחפש ברשת: ' + short(i.query, 70);
    case 'web_fetch': return 'קורא דף: ' + short(i.url, 70);
    default: return 'מפעיל ' + name;
  }
}

function createAgents(deps) {
  const {
    dataDir, callClaudeSmart, recordUsage, costOf, executeTool, flowGuard,
    TOOLS, READ_ONLY_TOOLS, cleanBlock
  } = deps;
  const AGENTS_DIR = path.join(dataDir, 'agents');
  const agents = new Map(); // id -> record
  const notifyHandlers = new Set(); // (summary) => void — השרת מעביר ל-run bus של השיחה
  let active = 0;
  let waiters = [];
  const maxParallel = () => Math.max(1, Math.min(16, Number(deps.maxParallel ? deps.maxParallel() : 4) || 4));

  // ---------- טעינת היסטוריה מהדיסק ----------
  try {
    if (fs.existsSync(AGENTS_DIR)) {
      const files = fs.readdirSync(AGENTS_DIR).filter(f => f.endsWith('.json'))
        .map(f => { try { return { f, t: fs.statSync(path.join(AGENTS_DIR, f)).mtimeMs }; } catch { return null; } })
        .filter(Boolean).sort((a, b) => b.t - a.t).slice(0, 300);
      for (const { f } of files) {
        try {
          const rec = JSON.parse(fs.readFileSync(path.join(AGENTS_DIR, f), 'utf8'));
          if (!rec || !rec.id) continue;
          if (!TERMINAL.has(rec.status)) {
            // סוכן חיצוני (רץ בתוך Claude Code שחי במארח) — ייתכן שימשיך אחרי הפעלה מחדש: שומרים את המצב הקודם לאימוץ
            if (rec.kind === 'cli-task') { rec._bootStatus = rec.status; rec._bootActivity = rec.activity; rec._bootEndedAt = rec.endedAt || null; }
            rec.status = 'interrupted'; rec.activity = 'הופסק (השרת נסגר)'; rec.endedAt = rec.endedAt || Date.now();
          }
          rec.listeners = new Set();
          agents.set(rec.id, rec);
        } catch { }
      }
    }
  } catch { }

  function serialize(rec) {
    const { listeners, controller, _notifyT, _lastNotify, onUpdate, _bootStatus, _bootActivity, _bootEndedAt, ...rest } = rec;
    return rest;
  }
  function persist(rec) {
    try { fs.mkdirSync(AGENTS_DIR, { recursive: true }); fs.writeFileSync(path.join(AGENTS_DIR, rec.id + '.json'), JSON.stringify(serialize(rec)), 'utf8'); }
    catch (e) { console.error('[agents] persist failed', e.message); }
  }
  function summary(rec) {
    return {
      id: rec.id, convId: rec.convId || null, parentToolId: rec.parentToolId || null, researchId: rec.researchId || null,
      kind: rec.kind, description: rec.description, model: rec.model, status: rec.status, activity: rec.activity,
      steps: rec.steps, tokens: rec.tokens, costUSD: rec.costUSD, pct: rec.pct || null, startedAt: rec.startedAt, endedAt: rec.endedAt || null,
      error: rec.error || null, resultPreview: rec.result ? short(rec.result, 300) : ''
    };
  }

  // ---------- התראות (throttled) ----------
  function notifyNow(rec) {
    clearTimeout(rec._notifyT); rec._notifyT = null;
    rec._lastNotify = Date.now();
    const s = summary(rec);
    for (const h of notifyHandlers) { try { h(s); } catch (e) { console.error('[agents] notify handler', e.message); } }
    if (rec.onUpdate) { try { rec.onUpdate(s); } catch { } }
    for (const l of rec.listeners) { try { l('update', s); } catch { } }
  }
  function notify(rec) {
    if (rec._notifyT) return;
    const wait = NOTIFY_MS - (Date.now() - (rec._lastNotify || 0));
    if (wait <= 0) return notifyNow(rec);
    rec._notifyT = setTimeout(() => notifyNow(rec), wait);
  }
  function setActivity(rec, text) {
    if (rec.activity === text) return;
    rec.activity = text;
    notify(rec);
  }

  // ---------- תמליל אירועים (טקסט/חשיבה מאוחדים) ----------
  function pushEvent(rec, ev) {
    ev.t = Date.now();
    const last = rec.events[rec.events.length - 1];
    if ((ev.type === 'text' || ev.type === 'thinking') && last && last.type === ev.type) {
      last.text += ev.text;
    } else {
      const stored = { ...ev, seq: ++rec.seq };
      rec.events.push(stored);
      if (rec.events.length > EVENT_CAP) { rec.events.splice(0, rec.events.length - EVENT_CAP); rec.truncated = true; }
    }
    for (const l of rec.listeners) { try { l('event', ev); } catch { } }
  }

  // ---------- הגבלת מקביליות ----------
  async function acquire(signal) {
    while (active >= maxParallel()) {
      if (signal.aborted) throw Object.assign(new Error('aborted'), { name: 'AbortError' });
      await new Promise(r => { waiters.push(r); signal.addEventListener('abort', r, { once: true }); });
    }
    if (signal.aborted) throw Object.assign(new Error('aborted'), { name: 'AbortError' });
    active++;
  }
  function release() {
    active = Math.max(0, active - 1);
    const ws = waiters; waiters = [];
    for (const w of ws) w(); // כולם בודקים שוב (מונע הרעבה מממתינים שבוטלו)
  }

  function register(o) {
    const rec = {
      id: crypto.randomUUID(), convId: o.convId || null, parentToolId: o.parentToolId || null, researchId: o.researchId || null,
      kind: o.kind || 'agent', description: short(o.description || 'סוכן', 120), prompt: String(o.prompt || ''), model: o.model,
      status: 'queued', startedAt: Date.now(), endedAt: null, activity: 'ממתין…', steps: 0,
      tokens: { input: 0, output: 0 }, costUSD: 0, result: '', error: null, events: [], seq: 0,
      listeners: new Set(), controller: null, onUpdate: o.onUpdate || null
    };
    agents.set(rec.id, rec);
    pushEvent(rec, { type: 'prompt', text: rec.prompt });
    persist(rec);
    notifyNow(rec);
    return rec;
  }

  // ---------- הריצה עצמה ----------
  async function runSubAgent(o) {
    const rec = register(o);
    const controller = new AbortController();
    rec.controller = controller;
    const onParentAbort = () => { rec.stoppedBy = rec.stoppedBy || 'parent'; controller.abort(); };
    if (o.parentSignal) {
      if (o.parentSignal.aborted) onParentAbort();
      else o.parentSignal.addEventListener('abort', onParentAbort, { once: true });
    }
    const signal = controller.signal;
    const tools = Array.isArray(o.tools) ? o.tools : [];
    const clientNames = new Set(tools.filter(t => t.input_schema).map(t => t.name));
    const maxSteps = Math.max(1, Number(o.maxSteps) || MAX_STEPS);
    const subCfg = {
      ...o.cfg, model: o.model, ultracode: false, autoFallback: false, showThinking: true,
      thinking: o.thinking || 'auto', effort: 'default', maxTokens: Number(o.maxTokens) || 32000
    };
    const messages = [{ role: 'user', content: [{ type: 'text', text: rec.prompt }] }];
    let acquired = false, lastStop = null, emptyRetry = false;

    const subEmit = (type, d) => {
      switch (type) {
        case 'text': if (d.text) { pushEvent(rec, { type: 'text', text: d.text }); setActivity(rec, 'כותב…'); } break;
        case 'thinking': if (d.text) { pushEvent(rec, { type: 'thinking', text: d.text }); setActivity(rec, 'חושב…'); } break;
        case 'thinking_start': setActivity(rec, 'חושב…'); break;
        case 'tool_start': setActivity(rec, 'מכין ' + d.name + '…'); break;
        case 'server_tool_start': setActivity(rec, d.name === 'web_search' ? 'מחפש ברשת…' : d.name === 'web_fetch' ? 'קורא דף…' : 'מפעיל ' + d.name + '…'); break;
        case 'server_tool_input': pushEvent(rec, { type: 'server_tool', id: d.id, name: d.name, input: d.input }); setActivity(rec, activityFor(d.name, d.input)); break;
        case 'server_tool_result': pushEvent(rec, { type: 'server_result', id: d.id, name: d.name, items: (d.items || []).slice(0, 20), error: d.error || null }); break;
        case 'notice': pushEvent(rec, { type: 'notice', text: d.text }); setActivity(rec, short(d.text, 80)); break;
        default: break;
      }
    };

    try {
      if (active >= maxParallel()) setActivity(rec, 'ממתין בתור (מגבלת סוכנים במקביל)…');
      await acquire(signal);
      acquired = true;
      rec.status = 'running';
      rec.runStartedAt = Date.now();
      setActivity(rec, 'מתחיל…');
      notifyNow(rec);

      while (!signal.aborted) {
        if (rec.steps >= maxSteps) {
          rec.result = (rec.result ? rec.result + '\n\n' : '') + `(stopped after the maximum of ${maxSteps} steps)`;
          break;
        }
        rec.steps++;
        setActivity(rec, 'ממתין לתשובה מ-Claude…');
        const resp = await callClaudeSmart({
          cfg: subCfg, system: o.system, rawMessages: messages, signal, emit: subEmit,
          tools, betas: o.betas || [], keepTrailingAssistant: lastStop === 'pause_turn'
        });
        const u = resp.usage || {};
        rec.tokens.input += (u.input_tokens || 0) + (u.cache_read_input_tokens || 0) + (u.cache_creation_input_tokens || 0);
        rec.tokens.output += u.output_tokens || 0;
        rec.costUSD += costOf(resp.servedModel || subCfg.model, u);
        try { recordUsage(resp.servedModel || subCfg.model, u); } catch { }
        if (o.onContent) { try { o.onContent(resp.content, rec); } catch (e) { console.error('[agents] onContent', e.message); } }

        const content = resp.content.map(cleanBlock).filter(b => !(b.type === 'text' && !b.text));
        lastStop = resp.stopReason;
        if (resp.stopReason === 'refusal') {
          rec.error = 'מסנן הבטיחות של המודל סירב למשימה';
          rec.result = content.filter(b => b.type === 'text').map(b => b.text).join('\n').trim();
          rec.status = 'error';
          break;
        }
        if (!content.length) {
          if (!emptyRetry) { emptyRetry = true; rec.steps--; continue; }
          break;
        }
        emptyRetry = false;
        messages.push({ role: 'assistant', content });
        const text = content.filter(b => b.type === 'text').map(b => b.text).join('\n').trim();
        if (text) rec.result = text;
        if (resp.stopReason === 'pause_turn') continue;
        const toolUses = content.filter(b => b.type === 'tool_use');
        if (resp.stopReason === 'max_tokens' && !toolUses.length) {
          messages.push({ role: 'user', content: [{ type: 'text', text: '(continue exactly where you stopped)' }] });
          continue;
        }
        if (resp.stopReason !== 'tool_use' || !toolUses.length) break;

        const results = [];
        for (const block of toolUses) {
          pushEvent(rec, { type: 'tool', id: block.id, name: block.name, input: block.input });
          setActivity(rec, activityFor(block.name, block.input));
          const t0 = Date.now();
          let r;
          const gate = flowGuard.checkFlow(block.name, block.input);
          const lockG = deps.lockGate ? deps.lockGate(o.convId, block.name, block.input) : null; // 🔒 מעקב נעול — גם לסוכן משנה
          if (signal.aborted) r = { output: 'Cancelled by the user.', is_error: true };
          else if (lockG) r = { output: lockG.reason, is_error: true };
          else if (!clientNames.has(block.name)) r = { output: `The tool "${block.name}" is not available to this sub-agent${o.readOnly ? ' (read-only mode: the user turned off auto-approve, so sub-agents may only read)' : ''}.`, is_error: true };
          else if (!gate.allowed) r = { output: gate.reason, is_error: true };
          else r = await executeTool(block.name, block.input, o.cwd, signal);
          let output = String(r.output == null ? '' : r.output);
          if (gate.reminder && !r.is_error) output += gate.reminder;
          pushEvent(rec, { type: 'tool_result', id: block.id, output: output.length > OUT_CAP ? output.slice(0, OUT_CAP) + '\n…' : output, is_error: !!r.is_error, ms: Date.now() - t0 });
          results.push({ type: 'tool_result', tool_use_id: block.id, content: output || '(no output)', is_error: !!r.is_error });
        }
        messages.push({ role: 'user', content: results });
        setActivity(rec, 'ממשיך…');
      }
      if (signal.aborted) throw Object.assign(new Error('aborted'), { name: 'AbortError' });
      if (rec.status !== 'error') { rec.status = 'done'; rec.activity = 'הסתיים'; }
      else rec.activity = 'שגיאה';
      if (!rec.result) rec.result = '(the sub-agent finished without a text answer)';
    } catch (e) {
      if (signal.aborted || e.name === 'AbortError') {
        rec.status = 'stopped';
        rec.activity = rec.stoppedBy === 'user' ? 'נעצר על ידי המשתמש' : 'נעצר';
      } else {
        rec.status = 'error';
        rec.error = e.message;
        rec.activity = 'שגיאה: ' + short(e.message, 80);
        pushEvent(rec, { type: 'error', text: e.message });
      }
    } finally {
      if (acquired) release();
      if (o.parentSignal) o.parentSignal.removeEventListener('abort', onParentAbort);
      rec.endedAt = Date.now();
      rec.controller = null;
      pushEvent(rec, { type: 'end', status: rec.status });
      persist(rec);
      notifyNow(rec);
      for (const l of rec.listeners) { try { l('end', summary(rec)); } catch { } }
    }
    return {
      id: rec.id, status: rec.status, result: rec.result, error: rec.error, steps: rec.steps,
      costUSD: rec.costUSD, tokens: rec.tokens, ms: rec.endedAt - rec.startedAt, stoppedBy: rec.stoppedBy || null
    };
  }

  // ---------- הכלי "agent" מתוך הסוכן הראשי ----------
  async function runAgentTool(input, ctx) {
    const i = input || {};
    const prompt = String(i.prompt || '').trim();
    if (!prompt) return { output: 'The "prompt" field is required: give the sub-agent a complete task.', is_error: true };
    const cfg = ctx.cfg;
    const model = deps.resolveModel(i.model, cfg.agentModel || cfg.model);
    const readOnly = cfg.autoApprove === false;
    const clientTools = readOnly ? TOOLS.filter(t => READ_ONLY_TOOLS.has(t.name)) : TOOLS;
    const tools = [...clientTools, ...deps.webTools({ search: 5, fetch: 5 })];
    const r = await runSubAgent({
      kind: 'agent', description: i.description || short(prompt, 50), prompt,
      system: deps.agentSystem({ cfg, cwd: ctx.cwd, model, readOnly, convId: ctx.convId }),
      model, tools, betas: deps.webBetas(), cfg, parentSignal: ctx.signal, convId: ctx.convId,
      parentToolId: ctx.toolId, cwd: ctx.cwd, readOnly
    });
    const head = `[sub-agent ${r.id.slice(0, 8)} · ${model} · ${r.status} · ${r.steps} steps · ${Math.round(r.ms / 1000)}s · $${r.costUSD.toFixed(4)}]`;
    if (r.status === 'stopped') {
      return { output: `${head}\nThe ${r.stoppedBy === 'user' ? 'user stopped this sub-agent' : 'sub-agent was stopped'} before it finished.${r.result ? '\nPartial output:\n' + r.result : ''}`, is_error: true };
    }
    if (r.status === 'error') return { output: `${head}\nThe sub-agent failed: ${r.error || 'unknown error'}${r.result ? '\nPartial output:\n' + r.result : ''}`, is_error: true };
    return { output: `${head}\n\n${r.result}`, is_error: false };
  }

  // ---------- ניהול ----------
  function list({ convId, limit = 200 } = {}) {
    return [...agents.values()].filter(a => !convId || a.convId === convId)
      .sort((a, b) => b.startedAt - a.startedAt).slice(0, limit).map(summary);
  }
  function get(id) { const a = agents.get(id); return a ? { ...serialize(a), summary: summary(a) } : null; }
  function stop(id) {
    const a = agents.get(id);
    if (!a || !a.controller) return false;
    a.stoppedBy = 'user';
    a.controller.abort();
    return true;
  }
  function stopAll({ convId } = {}) {
    let n = 0;
    for (const a of agents.values()) if (a.controller && (!convId || a.convId === convId)) { a.stoppedBy = 'user'; a.controller.abort(); n++; }
    return n;
  }
  function runningCount(convId) { let n = 0; for (const a of agents.values()) if (a.controller && (!convId || a.convId === convId)) n++; return n; }
  // מאזין לאירועים חיים של סוכן אחד: fn(kind: 'event'|'update'|'end', data). מחזיר פונקציית ביטול
  function subscribe(id, fn) {
    const a = agents.get(id);
    if (!a) return null;
    a.listeners.add(fn);
    return () => a.listeners.delete(fn);
  }
  function onNotify(fn) { notifyHandlers.add(fn); return () => notifyHandlers.delete(fn); }

  // ---------- סוכן "חיצוני": רץ בתוך Claude Code (מצב מנוי) — אנחנו רק רושמים אותו, מעדכנים ויכולים לעצור ----------
  // o: {convId, parentToolId, kind, description, prompt, model, onStop}. מחזיר handle לעדכון מהמנוע.
  function createExternal(o) {
    const rec = register({ ...o, kind: o.kind || 'cli-task' });
    rec.status = 'running'; rec.runStartedAt = Date.now(); rec.activity = 'מתחיל…';
    rec.controller = extController(o.onStop);
    notifyNow(rec);
    return extHandle(rec);
  }
  function extController(onStop) {
    return { abort: () => { try { if (onStop) onStop(); } catch (e) { console.error('[agents] onStop', e.message); } } };
  }
  // אימוץ סוכן חיצוני אחרי הפעלה מחדש של השרת (Claude Code המשיך לרוץ במארח). null = אין מה לאמץ
  function adoptExternal(id, { onStop } = {}) {
    const rec = agents.get(id);
    if (!rec || rec.kind !== 'cli-task') return null;
    if (rec.controller && !TERMINAL.has(rec.status)) { rec.controller = extController(onStop); return extHandle(rec); } // כבר מאומץ
    if (!rec._bootStatus) return null;
    rec.status = rec._bootStatus; rec.activity = rec._bootActivity || 'ממשיך…'; rec.endedAt = rec._bootEndedAt || null;
    delete rec._bootStatus; delete rec._bootActivity; delete rec._bootEndedAt;
    rec.controller = extController(onStop);
    persist(rec); notifyNow(rec);
    return extHandle(rec);
  }
  function extHandle(rec) {
    return {
      id: rec.id,
      isDone: () => TERMINAL.has(rec.status),
      push: ev => pushEvent(rec, ev),
      setActivity: t => setActivity(rec, t),
      setModel: m => { rec.model = m; notify(rec); },
      setUsage: ({ tokens, steps, costUSD, pct } = {}) => { if (tokens != null) rec.tokens = typeof tokens === 'object' ? tokens : { input: tokens, output: 0 }; if (steps != null) rec.steps = steps; if (costUSD != null) rec.costUSD = costUSD; if (pct !== undefined) rec.pct = pct; notify(rec); },
      addStep: () => { rec.steps++; notify(rec); },
      finish: (status, { result, error } = {}) => {
        if (TERMINAL.has(rec.status)) return;
        rec.status = status || 'done';
        if (result) rec.result = result; if (error) rec.error = error;
        rec.activity = rec.status === 'done' ? 'הסתיים' : rec.status === 'stopped' ? 'נעצר על ידי המשתמש' : 'שגיאה';
        rec.endedAt = Date.now(); rec.controller = null;
        if (rec.status === 'stopped') rec.stoppedBy = 'user';
        pushEvent(rec, { type: 'end', status: rec.status });
        persist(rec); notifyNow(rec);
        for (const l of rec.listeners) { try { l('end', summary(rec)); } catch { } }
      }
    };
  }

  return {
    AGENT_TOOL, runSubAgent, runAgentTool, list, get, stop, stopAll, runningCount, subscribe, onNotify, summary, createExternal, adoptExternal,
    isTerminal: s => TERMINAL.has(s), _registry: agents
  };
}

module.exports = { createAgents, AGENT_TOOL, activityFor };
