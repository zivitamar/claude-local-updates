// ClaudeDesktop.exe — שליטה במחשב עבור Claude (כמו אדם): מסך, חלונות, קריאת תוכנות כקוד (UI Automation), עכבר ומקלדת אמיתיים.
// פרוטוקול: שורת JSON לכל בקשה ב-stdin {id, op, ...} → שורת JSON ב-stdout {id, ok, result | error}.
// נבנה ע"י desktop.js עם csc של .NET Framework (קיים בכל Windows) — בלי התקנות.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Automation;

static class N {
  [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr v);
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc f, IntPtr l);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern int GetWindowTextLength(IntPtr h);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] public static extern bool IsZoomed(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr PostMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] public static extern IntPtr GetWindow(IntPtr h, uint c);
  [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int i);
  [DllImport("dwmapi.dll")] public static extern int DwmGetWindowAttribute(IntPtr h, int a, out int v, int s);
  [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
  [DllImport("user32.dll")] public static extern uint SendInput(uint n, INPUT[] i, int s);
  [DllImport("user32.dll")] public static extern int GetSystemMetrics(int i);
  [DllImport("user32.dll")] public static extern short VkKeyScan(char c);
  [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte sc, uint f, UIntPtr e);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
  [StructLayout(LayoutKind.Sequential)] public struct MOUSEINPUT { public int dx, dy; public uint mouseData, dwFlags, time; public IntPtr extra; }
  [StructLayout(LayoutKind.Sequential)] public struct KEYBDINPUT { public ushort wVk, wScan; public uint dwFlags, time; public IntPtr extra; }
  [StructLayout(LayoutKind.Explicit)] public struct INPUT { [FieldOffset(0)] public uint type; [FieldOffset(8)] public MOUSEINPUT mi; [FieldOffset(8)] public KEYBDINPUT ki; }
}

static class Program {
  static readonly JavaScriptSerializer J = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
  static readonly object OutLock = new object();
  static Dictionary<int, AutomationElement> refs = new Dictionary<int, AutomationElement>();
  static readonly Random Rnd = new Random();

  static void Main() {
    try { N.SetProcessDpiAwarenessContext(new IntPtr(-4)); } catch { try { N.SetProcessDPIAware(); } catch { } }
    Console.InputEncoding = new UTF8Encoding(false); Console.OutputEncoding = new UTF8Encoding(false);
    var stdin = new StreamReader(Console.OpenStandardInput(), new UTF8Encoding(false));
    string line;
    while ((line = stdin.ReadLine()) != null) {
      if (line.Trim().Length == 0) continue;
      Dictionary<string, object> req = null; object id = null;
      try { req = J.Deserialize<Dictionary<string, object>>(line); id = req.ContainsKey("id") ? req["id"] : null; Reply(id, true, Handle(req)); }
      catch (Exception e) { Reply(id, false, e.Message); }
    }
  }
  static void Reply(object id, bool ok, object r) {
    var o = new Dictionary<string, object> { { "id", id }, { "ok", ok } }; if (ok) o["result"] = r; else o["error"] = r;
    var s = J.Serialize(o); lock (OutLock) { Console.Out.Write(s + "\n"); Console.Out.Flush(); }
  }
  static string S(Dictionary<string, object> q, string k, string d = null) { return q.ContainsKey(k) && q[k] != null ? Convert.ToString(q[k]) : d; }
  static int I(Dictionary<string, object> q, string k, int d = 0) { return q.ContainsKey(k) && q[k] != null ? Convert.ToInt32(q[k]) : d; }
  static bool B(Dictionary<string, object> q, string k) { return q.ContainsKey(k) && q[k] is bool && (bool)q[k]; }

  static object Handle(Dictionary<string, object> q) {
    switch (S(q, "op")) {
      case "ping": return "pong";
      case "screenshot": return Screenshot(q);
      case "windows": return Windows();
      case "window": return WindowAct(q);
      case "ui": return UiTree(q);
      case "ui_act": return UiAct(q);
      case "mouse": return Mouse(q);
      case "type": TypeText(S(q, "text", "")); return "ok";
      case "key": Keys(S(q, "keys", "")); return "ok";
      case "cursor": { N.POINT p; N.GetCursorPos(out p); return new Dictionary<string, object> { { "x", p.X }, { "y", p.Y } }; }
      case "clipboard": return Clip(q);
      case "open": { var psi = new ProcessStartInfo(S(q, "target")) { UseShellExecute = true }; if (S(q, "args") != null) psi.Arguments = S(q, "args"); var p = Process.Start(psi); return p != null ? (object)p.Id : "started"; }
      default: throw new Exception("unknown op " + S(q, "op"));
    }
  }

  // ---------- מסך ----------
  static object Screenshot(Dictionary<string, object> q) {
    int vx = N.GetSystemMetrics(76), vy = N.GetSystemMetrics(77), vw = N.GetSystemMetrics(78), vh = N.GetSystemMetrics(79);
    int x = I(q, "x", vx), y = I(q, "y", vy), w = I(q, "w", vw), h = I(q, "h", vh);
    if (S(q, "hwnd") != null) { N.RECT r; N.GetWindowRect(new IntPtr(Convert.ToInt64(q["hwnd"])), out r); x = r.L; y = r.T; w = r.R - r.L; h = r.B - r.T; }
    int maxw = I(q, "maxw", 1600);
    using (var bmp = new Bitmap(w, h, PixelFormat.Format24bppRgb)) {
      using (var g = Graphics.FromImage(bmp)) g.CopyFromScreen(x, y, 0, 0, new Size(w, h), CopyPixelOperation.SourceCopy);
      double scale = w > maxw ? (double)w / maxw : 1.0; int ow = (int)Math.Round(w / scale), oh = (int)Math.Round(h / scale);
      using (var outb = scale > 1 ? new Bitmap(bmp, ow, oh) : (Bitmap)bmp.Clone()) using (var ms = new MemoryStream()) {
        var enc = ImageCodecInfo.GetImageEncoders().First(c => c.MimeType == "image/jpeg"); var ep = new EncoderParameters(1); ep.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 80L);
        outb.Save(ms, enc, ep);
        return new Dictionary<string, object> { { "jpeg", Convert.ToBase64String(ms.ToArray()) }, { "x", x }, { "y", y }, { "w", ow }, { "h", oh }, { "scale", scale } };
      }
    }
  }

  // ---------- חלונות ----------
  static object Windows() {
    var list = new List<object>(); IntPtr fg = N.GetForegroundWindow();
    N.EnumWindows((h, l) => {
      if (!N.IsWindowVisible(h)) return true;
      int len = N.GetWindowTextLength(h); if (len == 0) return true;
      int cloaked; if (N.DwmGetWindowAttribute(h, 14, out cloaked, 4) == 0 && cloaked != 0) return true; // חלונות מוסתרים של אפליקציות Store
      if ((N.GetWindowLong(h, -20) & 0x80) != 0) return true; // WS_EX_TOOLWINDOW
      var sb = new StringBuilder(len + 1); N.GetWindowText(h, sb, sb.Capacity);
      uint pid; N.GetWindowThreadProcessId(h, out pid); string pn = ""; try { pn = Process.GetProcessById((int)pid).ProcessName; } catch { }
      N.RECT r; N.GetWindowRect(h, out r);
      list.Add(new Dictionary<string, object> { { "hwnd", h.ToInt64() }, { "title", sb.ToString() }, { "pid", pid }, { "process", pn }, { "x", r.L }, { "y", r.T }, { "w", r.R - r.L }, { "h", r.B - r.T }, { "minimized", N.IsIconic(h) }, { "maximized", N.IsZoomed(h) }, { "foreground", h == fg } });
      return true;
    }, IntPtr.Zero);
    return list;
  }
  static object WindowAct(Dictionary<string, object> q) {
    var h = new IntPtr(Convert.ToInt64(q["hwnd"])); string a = S(q, "action", "focus");
    switch (a) {
      case "focus": if (N.IsIconic(h)) N.ShowWindow(h, 9); keybd_alt(); N.BringWindowToTop(h); N.SetForegroundWindow(h); break;
      case "minimize": N.ShowWindow(h, 6); break;
      case "maximize": N.ShowWindow(h, 3); break;
      case "restore": N.ShowWindow(h, 9); break;
      case "close": N.PostMessage(h, 0x0010, IntPtr.Zero, IntPtr.Zero); break;
      default: throw new Exception("unknown window action " + a);
    }
    Thread.Sleep(120); return "ok";
  }
  static void keybd_alt() { N.keybd_event(0x12, 0, 0, UIntPtr.Zero); N.keybd_event(0x12, 0, 2, UIntPtr.Zero); } // מאפשר SetForegroundWindow

  // ---------- קריאת תוכנה כקוד (UI Automation) ----------
  static readonly HashSet<ControlType> Interesting = new HashSet<ControlType> { ControlType.Button, ControlType.CheckBox, ControlType.ComboBox, ControlType.Edit, ControlType.Hyperlink, ControlType.ListItem, ControlType.MenuItem, ControlType.RadioButton, ControlType.Slider, ControlType.Spinner, ControlType.SplitButton, ControlType.Tab, ControlType.TabItem, ControlType.TreeItem, ControlType.DataItem, ControlType.Document, ControlType.Menu, ControlType.MenuBar, ControlType.Text, ControlType.Header, ControlType.HeaderItem, ControlType.Window, ControlType.ToolBar, ControlType.List, ControlType.Tree, ControlType.Table, ControlType.Group };
  static object UiTree(Dictionary<string, object> q) {
    var h = new IntPtr(Convert.ToInt64(q["hwnd"])); int max = I(q, "max", 220), maxDepth = I(q, "depth", 25); string filter = (S(q, "filter", "") ?? "").ToLowerInvariant();
    var root = AutomationElement.FromHandle(h); refs = new Dictionary<int, AutomationElement>();
    var lines = new List<string>(); int n = 0; var walker = TreeWalker.ControlViewWalker; var t0 = DateTime.UtcNow;
    Action<AutomationElement, int> walk = null;
    walk = (el, depth) => {
      if (n >= max || depth > maxDepth || (DateTime.UtcNow - t0).TotalSeconds > 12) return;
      AutomationElement.AutomationElementInformation c; try { c = el.Current; } catch { return; }
      if (!c.IsOffscreen || depth < 2) {
        string name = (c.Name ?? "").Replace("\n", " ").Replace("\r", " "); if (name.Length > 90) name = name.Substring(0, 90) + "…";
        bool want = Interesting.Contains(c.ControlType) && (name.Length > 0 || c.ControlType == ControlType.Edit || c.ControlType == ControlType.ComboBox || c.ControlType == ControlType.Document);
        if (want && (filter.Length == 0 || name.ToLowerInvariant().Contains(filter) || (c.AutomationId ?? "").ToLowerInvariant().Contains(filter))) {
          n++; refs[n] = el;
          var pats = new List<string>(); string val = null;
          foreach (var p in el.GetSupportedPatterns()) { var pn = p.ProgrammaticName.Replace("PatternIdentifiers.Pattern", ""); if (pn == "Invoke" || pn == "Toggle" || pn == "Value" || pn == "ExpandCollapse" || pn == "SelectionItem" || pn == "RangeValue") pats.Add(pn); }
          try { object vp; if (el.TryGetCurrentPattern(ValuePattern.Pattern, out vp)) { val = ((ValuePattern)vp).Current.Value; if (val != null && val.Length > 60) val = val.Substring(0, 60) + "…"; } } catch { }
          try { object tp; if (el.TryGetCurrentPattern(TogglePattern.Pattern, out tp)) val = (val == null ? "" : val + " ") + "[" + ((TogglePattern)tp).Current.ToggleState + "]"; } catch { }
          var r = c.BoundingRectangle;
          lines.Add(new string(' ', Math.Min(depth, 8)) + "[" + n + "] " + c.ControlType.ProgrammaticName.Replace("ControlType.", "") + " \"" + name + "\"" + (string.IsNullOrEmpty(c.AutomationId) ? "" : " id=" + c.AutomationId) + (val != null ? " value=\"" + val + "\"" : "") + (pats.Count > 0 ? " {" + string.Join(",", pats) + "}" : "") + (c.IsEnabled ? "" : " (disabled)") + (r.IsEmpty ? "" : " @" + (int)(r.X + r.Width / 2) + "," + (int)(r.Y + r.Height / 2)));
        }
      }
      AutomationElement ch = null; try { ch = walker.GetFirstChild(el); } catch { }
      while (ch != null && n < max) { walk(ch, depth + 1); try { ch = walker.GetNextSibling(ch); } catch { ch = null; } }
    };
    walk(root, 0);
    string title = ""; try { title = root.Current.Name; } catch { }
    return new Dictionary<string, object> { { "title", title }, { "count", n }, { "lines", lines }, { "truncated", n >= max } };
  }
  static object UiAct(Dictionary<string, object> q) {
    int r = I(q, "ref"); if (!refs.ContainsKey(r)) throw new Exception("אלמנט " + r + " לא קיים — קרא שוב את החלון (desktop_ui)");
    var el = refs[r]; string a = S(q, "action", "invoke"); object p;
    switch (a) {
      case "invoke":
        if (el.TryGetCurrentPattern(InvokePattern.Pattern, out p)) { ((InvokePattern)p).Invoke(); break; }
        if (el.TryGetCurrentPattern(TogglePattern.Pattern, out p)) { ((TogglePattern)p).Toggle(); break; }
        if (el.TryGetCurrentPattern(SelectionItemPattern.Pattern, out p)) { ((SelectionItemPattern)p).Select(); break; }
        if (el.TryGetCurrentPattern(ExpandCollapsePattern.Pattern, out p)) { ((ExpandCollapsePattern)p).Expand(); break; }
        throw new Exception("לאלמנט אין פעולת לחיצה בלי עכבר — השתמש ב-desktop_click בנקודה שלו");
      case "toggle": ((TogglePattern)el.GetCurrentPattern(TogglePattern.Pattern)).Toggle(); break;
      case "set_value": ((ValuePattern)el.GetCurrentPattern(ValuePattern.Pattern)).SetValue(S(q, "value", "")); break;
      case "expand": ((ExpandCollapsePattern)el.GetCurrentPattern(ExpandCollapsePattern.Pattern)).Expand(); break;
      case "collapse": ((ExpandCollapsePattern)el.GetCurrentPattern(ExpandCollapsePattern.Pattern)).Collapse(); break;
      case "select": ((SelectionItemPattern)el.GetCurrentPattern(SelectionItemPattern.Pattern)).Select(); break;
      case "focus": el.SetFocus(); break;
      case "read": { string v = ""; if (el.TryGetCurrentPattern(ValuePattern.Pattern, out p)) v = ((ValuePattern)p).Current.Value; else if (el.TryGetCurrentPattern(TextPattern.Pattern, out p)) v = ((TextPattern)p).DocumentRange.GetText(20000); else v = el.Current.Name; return v; }
      default: throw new Exception("unknown ui action " + a);
    }
    Thread.Sleep(80); return "ok";
  }

  // ---------- עכבר ומקלדת אמיתיים (כמו אדם) ----------
  static void MouseRaw(uint flags, int x = 0, int y = 0, uint data = 0, bool abs = false) {
    var inp = new N.INPUT { type = 0 }; inp.mi.dwFlags = flags; inp.mi.mouseData = data;
    if (abs) { int vx = N.GetSystemMetrics(76), vy = N.GetSystemMetrics(77), vw = N.GetSystemMetrics(78), vh = N.GetSystemMetrics(79); inp.mi.dx = (int)Math.Round((x - vx) * 65535.0 / (vw - 1)); inp.mi.dy = (int)Math.Round((y - vy) * 65535.0 / (vh - 1)); inp.mi.dwFlags |= 0x8000 | 0x4000; }
    N.SendInput(1, new[] { inp }, Marshal.SizeOf(typeof(N.INPUT)));
  }
  static void MoveHuman(int x, int y) {
    N.POINT p; N.GetCursorPos(out p); double sx = p.X, sy = p.Y; double d = Math.Sqrt((x - sx) * (x - sx) + (y - sy) * (y - sy));
    int steps = Math.Max(6, Math.Min(28, (int)(d / 40))); double cx = (sx + x) / 2 + (Rnd.NextDouble() - 0.5) * Math.Min(120, d / 3), cy = (sy + y) / 2 + (Rnd.NextDouble() - 0.5) * Math.Min(120, d / 3);
    for (int i = 1; i <= steps; i++) { double t = (double)i / steps; t = t * t * (3 - 2 * t); double u = 1 - t; MouseRaw(0x0001, (int)Math.Round(u * u * sx + 2 * u * t * cx + t * t * x), (int)Math.Round(u * u * sy + 2 * u * t * cy + t * t * y), 0, true); Thread.Sleep(5 + Rnd.Next(6)); }
    MouseRaw(0x0001, x, y, 0, true);
  }
  static object Mouse(Dictionary<string, object> q) {
    string a = S(q, "action", "click"); int x = I(q, "x"), y = I(q, "y");
    bool right = S(q, "button", "left") == "right"; uint down = right ? 0x0008u : 0x0002u, up = right ? 0x0010u : 0x0004u;
    switch (a) {
      case "move": MoveHuman(x, y); break;
      case "click": case "double": case "right":
        if (a == "right") { down = 0x0008; up = 0x0010; }
        MoveHuman(x, y); Thread.Sleep(30 + Rnd.Next(40));
        for (int k = 0; k < (a == "double" ? 2 : 1); k++) { MouseRaw(down); Thread.Sleep(40 + Rnd.Next(50)); MouseRaw(up); if (a == "double") Thread.Sleep(70); }
        break;
      case "drag": MoveHuman(x, y); Thread.Sleep(60); MouseRaw(0x0002); Thread.Sleep(90); MoveHuman(I(q, "x2"), I(q, "y2")); Thread.Sleep(90); MouseRaw(0x0004); break;
      case "scroll": if (q.ContainsKey("x")) MoveHuman(x, y); int notches = I(q, "amount", -3); MouseRaw(0x0800, 0, 0, unchecked((uint)(notches * 120))); break;
      default: throw new Exception("unknown mouse action " + a);
    }
    N.POINT pp; N.GetCursorPos(out pp); return new Dictionary<string, object> { { "x", pp.X }, { "y", pp.Y } };
  }
  static void Key(ushort vk, bool upk, bool ext = false) { var i = new N.INPUT { type = 1 }; i.ki.wVk = vk; i.ki.dwFlags = (upk ? 2u : 0u) | (ext ? 1u : 0u); N.SendInput(1, new[] { i }, Marshal.SizeOf(typeof(N.INPUT))); }
  static void TypeText(string text) {
    foreach (char ch in text) {
      if (ch == '\n') { Key(0x0D, false); Key(0x0D, true); }
      else if (ch == '\t') { Key(0x09, false); Key(0x09, true); }
      else { var d = new N.INPUT { type = 1 }; d.ki.wScan = ch; d.ki.dwFlags = 0x0004; var u = d; u.ki.dwFlags = 0x0004 | 0x0002; N.SendInput(2, new[] { d, u }, Marshal.SizeOf(typeof(N.INPUT))); }
      Thread.Sleep(8 + Rnd.Next(22));
    }
  }
  static readonly Dictionary<string, ushort> VK = new Dictionary<string, ushort>(StringComparer.OrdinalIgnoreCase) {
    {"ctrl",0x11},{"control",0x11},{"alt",0x12},{"shift",0x10},{"win",0x5B},{"enter",0x0D},{"return",0x0D},{"tab",0x09},{"esc",0x1B},{"escape",0x1B},{"space",0x20},{"backspace",0x08},{"delete",0x2E},{"del",0x2E},{"insert",0x2D},
    {"home",0x24},{"end",0x23},{"pageup",0x21},{"pagedown",0x22},{"up",0x26},{"down",0x28},{"left",0x25},{"right",0x27},{"arrowup",0x26},{"arrowdown",0x28},{"arrowleft",0x25},{"arrowright",0x27},
    {"f1",0x70},{"f2",0x71},{"f3",0x72},{"f4",0x73},{"f5",0x74},{"f6",0x75},{"f7",0x76},{"f8",0x77},{"f9",0x78},{"f10",0x79},{"f11",0x7A},{"f12",0x7B},{"printscreen",0x2C},{"capslock",0x14},{"menu",0x5D}};
  static readonly HashSet<ushort> Ext = new HashSet<ushort> { 0x2E, 0x2D, 0x24, 0x23, 0x21, 0x22, 0x26, 0x28, 0x25, 0x27, 0x5B };
  static void Keys(string spec) {
    foreach (var combo in spec.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)) {
      var parts = combo.Split('+'); var vks = new List<ushort>();
      foreach (var p in parts) {
        ushort v; if (VK.TryGetValue(p, out v)) { vks.Add(v); continue; }
        if (p.Length == 1) {
          char c = char.ToUpperInvariant(p[0]);
          // אות/ספרה באנגלית = המקש הפיזי (VK_A..VK_Z, VK_0..VK_9) — עובד גם כשפריסת המקלדת בעברית
          if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) { vks.Add((ushort)c); continue; }
          short s = N.VkKeyScan(p[0]); if (s != -1) { vks.Add((ushort)(s & 0xFF)); continue; }
        }
        throw new Exception("מקש לא מוכר: " + p);
      }
      foreach (var v in vks) { Key(v, false, Ext.Contains(v)); Thread.Sleep(15); }
      for (int i = vks.Count - 1; i >= 0; i--) { Key(vks[i], true, Ext.Contains(vks[i])); Thread.Sleep(10); }
      Thread.Sleep(40);
    }
  }
  static object Clip(Dictionary<string, object> q) {
    object result = null; Exception err = null; string set = S(q, "set");
    var t = new Thread(() => { try { if (set != null) { System.Windows.Forms.Clipboard.SetText(set); result = "ok"; } else result = System.Windows.Forms.Clipboard.ContainsText() ? System.Windows.Forms.Clipboard.GetText() : ""; } catch (Exception e) { err = e; } });
    t.SetApartmentState(ApartmentState.STA); t.Start(); t.Join(5000); if (err != null) throw err; return result;
  }
}
