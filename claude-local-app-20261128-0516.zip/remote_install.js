'use strict';
// ============================================================
//  remote_install.js — התקנת האפליקציה על מחשב אחר דרך SSH, והתחברות לחשבון Claude שלו בלי לגשת לשרת.
//
//  1. מזהה מערכת (Linux / Windows), אורז את האפליקציה (רק קבצי הריצה) ומעלה דרך SSH (בלי scp — דרך stdin).
//  2. מריץ את סקריפט ההתקנה: Node משלה (רשמי, SHA-256), שירות שעולה לבד אחרי אתחול, פורט הרשת בחומת האש.
//  3. מתחבר לחשבון: מבקש מהאפליקציה שם להתחיל כניסה. ה-CLI הרשמי מוסר כתובת שחוזרת ל-http://localhost:<port>/callback;
//     מנהרת SSH (‎-L) מעבירה את הפורט הזה מהמחשב הזה לשרת — כך כשהמשתמש מאשר בדפדפן שלו, החזרה מגיעה ישר ל-CLI בשרת.
//     גיבוי: הכתובת הידנית (מציגה קוד) + הדבקת הקוד דרך submitCode.
//  4. אחרי הכניסה — המגדלור בשרת מצטרף לבד לרשת (דרך החשבון) והוא מופיע בפס המחשבים.
// ============================================================
const fs = require('fs'), path = require('path'), os = require('os'), crypto = require('crypto'), { spawn } = require('child_process');

const IS_WIN = process.platform === 'win32';
const SSH = IS_WIN ? (fs.existsSync(path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'OpenSSH', 'ssh.exe')) ? path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'OpenSSH', 'ssh.exe') : 'ssh.exe') : 'ssh';
const TAR = IS_WIN ? path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe') : 'tar';
const RUNTIME_JS = /^(agents|answer_rules|browser|chat_tools|chrome_bridge|claude_cli|cli_engine|conv_archive|desktop|file_preview|flow_guard|flows|fsapi|history_reader|mesh|mesh-beacon|pricing|remote_install|research|runbus|server|stt|sub_meter|sub_scan|tools|vscode_chats|watches)\.js$/;

// ---------- אריזה: רק מה שהשרת צריך כדי לרוץ (עובד גם מתוך ה-asar של ה-EXE) ----------
function copyTree(src, dst, filter) {
  const st = fs.statSync(src);
  if (st.isDirectory()) { fs.mkdirSync(dst, { recursive: true }); for (const n of fs.readdirSync(src)) { const s = path.join(src, n); if (filter && !filter(s)) continue; copyTree(s, path.join(dst, n), filter); } }
  else fs.writeFileSync(dst, fs.readFileSync(src));
}
function makeBundle(appDir, outDir = os.tmpdir(), format = 'tgz') {
  const stage = fs.mkdtempSync(path.join(outDir, 'cl-bundle-'));
  const app = path.join(stage, 'app'); fs.mkdirSync(app);
  for (const n of fs.readdirSync(appDir)) {
    const s = path.join(appDir, n);
    if (RUNTIME_JS.test(n) || /^(package|build-info)\.json$/.test(n)) copyTree(s, path.join(app, n));
  }
  for (const d of ['public', 'chrome-extension', 'stt', path.join('tools', 'remote')]) { const s = path.join(appDir, d); if (fs.existsSync(s)) copyTree(s, path.join(app, d), p => !/[\\/](node_modules|venv|__pycache__)([\\/]|$)/.test(p)); }
  const out = path.join(stage, 'claude-local-bundle.' + (format === 'zip' ? 'zip' : 'tgz'));
  return new Promise((resolve, reject) => {
    const t = spawn(TAR, format === 'zip' ? ['-a', '-cf', out, '-C', app, '.'] : ['-czf', out, '-C', app, '.'], { windowsHide: true });
    let err = ''; t.stderr.on('data', d => (err += d));
    t.on('close', c => c === 0 ? resolve({ file: out, size: fs.statSync(out).size, stage }) : reject(new Error('tar failed: ' + err.slice(0, 300))));
    t.on('error', reject);
  });
}

// ---------- SSH ----------
// target: "user@host", "user@host:port" או שם מקובץ ssh_config; opts: { configFile, identity, password }
function sshArgs(t, extra = []) {
  const a = ['-o', 'ConnectTimeout=15', '-o', 'ServerAliveInterval=15', '-o', 'StrictHostKeyChecking=accept-new'];
  if (t.configFile) a.push('-F', t.configFile);
  if (t.identity) a.push('-i', t.identity);
  if (!t.password) a.push('-o', 'BatchMode=yes');
  let host = t.target; const m = String(host).match(/^(.*?):(\d+)$/); if (m) { host = m[1]; a.push('-p', m[2]); }
  return [...a, ...extra, host];
}
function askpassEnv(t) {
  if (!t.password) return process.env;
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cl-ask-'));
  const f = path.join(dir, IS_WIN ? 'ask.cmd' : 'ask.sh');
  fs.writeFileSync(path.join(dir, 'pw'), t.password, { mode: 0o600 });
  if (IS_WIN) fs.writeFileSync(f, '@type "' + path.join(dir, 'pw') + '"\r\n'); else { fs.writeFileSync(f, '#!/bin/sh\ncat ' + JSON.stringify(path.join(dir, 'pw')) + '\n'); fs.chmodSync(f, 0o700); }
  setTimeout(() => { try { fs.rmSync(dir, { recursive: true, force: true }); } catch { } }, 10 * 60 * 1000);
  return { ...process.env, SSH_ASKPASS: f, SSH_ASKPASS_REQUIRE: 'force', DISPLAY: process.env.DISPLAY || 'none' };
}
function ssh(t, command, { input, timeoutMs = 300000 } = {}) {
  return new Promise(resolve => {
    const p = spawn(SSH, sshArgs(t, []).concat([command]), { env: askpassEnv(t), windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    let out = '', err = ''; p.stdout.on('data', d => (out += d)); p.stderr.on('data', d => (err += d));
    const to = setTimeout(() => { try { p.kill(); } catch { } }, timeoutMs);
    p.on('close', code => { clearTimeout(to); resolve({ code, out, err: err.replace(/Warning: Permanently added[^\n]*\n?/g, '') }); });
    p.on('error', e => { clearTimeout(to); resolve({ code: -1, out, err: e.message }); });
    p.stdin.on('error', () => { }); // הצד השני סגר — התוצאה תגיע ב-close
    if (input) { if (Buffer.isBuffer(input)) p.stdin.end(input); else { input.on('error', () => { }); input.pipe(p.stdin); } } else p.stdin.end();
  });
}
// העלאת קובץ ב-scp (חלק מ-OpenSSH; עובד גם מול שרת Windows)
const SCP = IS_WIN ? path.join(path.dirname(SSH), 'scp.exe') : 'scp';
function scp(t, localFile, remotePath, timeoutMs = 600000) {
  return new Promise(resolve => {
    const a = ['-o', 'ConnectTimeout=15', '-o', 'StrictHostKeyChecking=accept-new', '-q'];
    if (t.configFile) a.push('-F', t.configFile); if (t.identity) a.push('-i', t.identity); if (!t.password) a.push('-o', 'BatchMode=yes');
    let host = t.target; const m = String(host).match(/^(.*?):(\d+)$/); if (m) { host = m[1]; a.push('-P', m[2]); }
    const p = spawn(fs.existsSync(SCP) || !IS_WIN ? SCP : 'scp.exe', [...a, localFile, `${host}:${remotePath}`], { env: askpassEnv(t), windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    let err = ''; p.stderr.on('data', d => (err += d));
    const to = setTimeout(() => { try { p.kill(); } catch { } }, timeoutMs);
    p.on('close', code => { clearTimeout(to); resolve({ code, err: err.replace(/Warning: Permanently added[^\n]*\n?/g, '') }); });
    p.on('error', e => { clearTimeout(to); resolve({ code: -1, err: e.message }); });
  });
}
const shq = s => "'" + String(s).replace(/'/g, "'\\''") + "'";

// ---------- התקנה ----------
const jobs = new Map(); // target -> { steps[], status, os, port, login, tunnel }
function jobPublic(j) { return { target: j.target, status: j.status, os: j.os, port: j.port, meshPort: j.meshPort, installed: j.installed || null, steps: j.steps.slice(-30), login: j.login ? { status: j.login.status, browserUrl: j.login.browserUrl || null, url: j.login.url || null, callbackPort: j.login.callbackPort || null, error: j.login.error || null } : null, tunnel: j.tunnel ? { port: j.tunnel.port, alive: !!j.tunnel.alive } : null, error: j.error || null, startedAt: j.startedAt, endedAt: j.endedAt || null }; }
async function install(t, { appDir, port = 3456, meshPort = 47400, login = true, log = () => { } } = {}) {
  const key = t.target; const j = { target: key, status: 'running', steps: [], port, meshPort, startedAt: Date.now() }; jobs.set(key, j);
  const step = s => { j.steps.push({ at: Date.now(), s }); log('[remote-install] ' + key + ': ' + s); };
  try {
    step('בודק חיבור SSH ומערכת הפעלה');
    const probe = await ssh(t, 'uname -sm 2>/dev/null || ver', { timeoutMs: 40000 });
    if (probe.code !== 0 && !/Windows/i.test(probe.out)) throw new Error('אין חיבור SSH: ' + (probe.err || probe.out).trim().split('\n').slice(-2).join(' '));
    j.os = /Linux/i.test(probe.out) ? 'linux' : /Windows|Microsoft/i.test(probe.out) ? 'windows' : /Darwin/i.test(probe.out) ? 'mac' : 'unknown';
    step('מערכת: ' + probe.out.trim().split('\n')[0]);
    if (j.os === 'linux' || j.os === 'mac') {
      step('אורז את האפליקציה');
      const b = await makeBundle(appDir); step(`חבילה: ${(b.size / 1048576).toFixed(1)}MB`);
      const tag = crypto.randomBytes(4).toString('hex'), rb = `/tmp/cl-bundle-${tag}.tgz`, rs = `/tmp/cl-install-${tag}.sh`;
      step('מעלה (SSH)');
      let r = await ssh(t, `cat > ${rb}`, { input: fs.createReadStream(b.file) }); if (r.code !== 0) throw new Error('העלאה נכשלה: ' + r.err.trim());
      r = await ssh(t, `cat > ${rs}`, { input: fs.readFileSync(path.join(appDir, 'tools', 'remote', 'install-linux.sh')) }); if (r.code !== 0) throw new Error('העלאת הסקריפט נכשלה: ' + r.err.trim());
      fs.rm(b.stage, { recursive: true, force: true }, () => { });
      step('מתקין (Node משלה, שירות, חומת אש)');
      r = await ssh(t, `sh ${rs} ${rb} ${+port} ${+meshPort}; c=$?; rm -f ${rb} ${rs}; exit $c`, { timeoutMs: 600000 });
      const line = (r.out.match(/CLAUDE_LOCAL_INSTALLED [^\n]*/) || [])[0];
      if (!line) throw new Error('ההתקנה נכשלה: ' + (r.err || r.out).trim().split('\n').slice(-4).join(' | '));
      j.installed = Object.fromEntries(line.replace('CLAUDE_LOCAL_INSTALLED ', '').split(' ').map(kv => kv.split('=')));
      step('הותקן ורץ: ' + line.replace('CLAUDE_LOCAL_INSTALLED ', ''));
    } else if (j.os === 'windows') {
      await installWindows(t, j, { appDir, port, meshPort, step });
    } else throw new Error('מערכת לא נתמכת: ' + probe.out.trim());
    if (login) await startRemoteLogin(t, j, step); else j.status = 'installed';
    return jobPublic(j);
  } catch (e) { j.status = 'error'; j.error = e.message; j.endedAt = Date.now(); step('❌ ' + e.message); return jobPublic(j); }
}
// קריאה ל-API של האפליקציה בשרת (שמאזינה רק ל-127.0.0.1 שם) — דרך SSH
async function remoteApi(t, j, method, p, body) {
  const url = `http://127.0.0.1:${j.port}${p}`;
  const b64 = body ? Buffer.from(JSON.stringify(body), 'utf8').toString('base64') : '';
  const cmd = j.os === 'windows' // גוף הבקשה ב-base64: שום מירכאות לא נשברות בדרך (cmd → powershell)
    ? `powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Console]::OutputEncoding=[Text.Encoding]::UTF8; $b=${b64 ? `[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${b64}'))` : '$null'}; try { $r=Invoke-WebRequest -UseBasicParsing -Method ${method} -Uri '${url}' -ContentType 'application/json' -Body $b; [Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray()) } catch { $_.ErrorDetails.Message }"`
    :`curl -s -X ${method} -H 'content-type: application/json' ${body ? '-d ' + shq(JSON.stringify(body)) : ''} ${shq(url)} || wget -qO- --method=${method} ${body ? '--body-data=' + shq(JSON.stringify(body)) + " --header='content-type: application/json'" : ''} ${shq(url)}`;
  const r = await ssh(t, cmd, { timeoutMs: 60000 });
  try { return JSON.parse(r.out); } catch { return { error: (r.out || r.err).trim().slice(0, 300) }; }
}
async function startRemoteLogin(t, j, step) {
  const cfg = await remoteApi(t, j, 'GET', '/api/config');
  if (cfg && cfg.cliLoggedIn) { step('כבר מחובר לחשבון Claude — מצטרף לרשת לבד'); j.status = 'done'; j.login = { status: 'success' }; await remoteApi(t, j, 'POST', '/api/mesh/discover'); j.endedAt = Date.now(); return; }
  step('מתחיל התחברות לחשבון Claude בשרת');
  let l = null; for (let i = 0; i < 20 && !(l && l.id); i++) { l = await remoteApi(t, j, 'POST', '/api/account/login', { capture: true }); if (!(l && l.id)) await new Promise(r => setTimeout(r, 6000)); } // ה-CLI אולי עוד יורד בהפעלה הראשונה
  if (!l || !l.id) throw new Error('לא הצלחתי להתחיל התחברות בשרת: ' + JSON.stringify(l).slice(0, 200));
  j.login = { id: l.id, status: 'pending' };
  for (let i = 0; i < 40 && !(j.login.browserUrl || j.login.url); i++) { await new Promise(r => setTimeout(r, 750)); const s = await remoteApi(t, j, 'GET', '/api/account/login/' + l.id); Object.assign(j.login, { status: s.status, browserUrl: s.browserUrl, url: s.url, callbackPort: s.callbackPort, error: s.error }); }
  if (j.login.callbackPort) { openTunnel(t, j, j.login.callbackPort); step(`מנהרה: localhost:${j.login.callbackPort} במחשב הזה ← השרת (החזרה מהאימות תגיע לשרת)`); }
  step('✅ ממתין שתאשר בדפדפן: ' + (j.login.browserUrl || j.login.url));
  j.status = 'awaiting-login';
  watchLogin(t, j, step);
}
function openTunnel(t, j, port) {
  closeTunnel(j);
  const p = spawn(SSH, sshArgs(t, ['-N', '-o', 'ExitOnForwardFailure=yes', '-L', `127.0.0.1:${port}:127.0.0.1:${port}`]), { env: askpassEnv(t), windowsHide: true, stdio: ['ignore', 'ignore', 'pipe'] });
  j.tunnel = { port, proc: p, alive: true }; let err = ''; p.stderr.on('data', d => (err += d));
  p.on('close', () => { if (j.tunnel && j.tunnel.proc === p) { j.tunnel.alive = false; j.tunnel.error = err.trim().slice(-200); } });
  setTimeout(() => closeTunnel(j), 15 * 60 * 1000); // לא נשאר פתוח לנצח
}
function closeTunnel(j) { if (j.tunnel && j.tunnel.proc) { try { j.tunnel.proc.kill(); } catch { } j.tunnel.alive = false; } }
function watchLogin(t, j, step) {
  const t0 = Date.now();
  const iv = setInterval(async () => {
    if (Date.now() - t0 > 15 * 60 * 1000) { clearInterval(iv); j.status = 'login-timeout'; closeTunnel(j); step('ההתחברות לא הושלמה תוך 15 דקות'); return; }
    const s = await remoteApi(t, j, 'GET', '/api/account/login/' + j.login.id).catch(() => null); if (!s || !s.status) return;
    j.login.status = s.status; if (s.error) j.login.error = s.error;
    if (s.status === 'success') { clearInterval(iv); closeTunnel(j); step('✅ השרת מחובר לחשבון Claude — מצטרף לרשת'); await remoteApi(t, j, 'POST', '/api/mesh/discover').catch(() => { }); j.status = 'done'; j.endedAt = Date.now(); }
    else if (s.status !== 'pending') { clearInterval(iv); closeTunnel(j); j.status = 'login-error'; step('ההתחברות נכשלה: ' + (s.error || s.status)); }
  }, 3000);
  j.stopWatch = () => clearInterval(iv);
}
async function submitCode(target, code) { const j = jobs.get(target); if (!j || !j.login || !j.login.id) return { ok: false, error: 'אין התחברות פעילה ל-' + target }; const t = j._t; return remoteApi(t, j, 'POST', `/api/account/login/${j.login.id}/code`, { code }); }
async function cancel(target) { const j = jobs.get(target); if (!j) return false; if (j.stopWatch) j.stopWatch(); closeTunnel(j); if (j.login && j.login.id && j._t) await remoteApi(j._t, j, 'POST', `/api/account/login/${j.login.id}/cancel`).catch(() => { }); j.status = 'cancelled'; return true; }
function status(target) { const j = jobs.get(target); return j ? jobPublic(j) : null; }
function list() { return [...jobs.values()].map(jobPublic); }

// ---------- Windows (Windows 10/11 + Server 2016/2019/2022/2025 עם OpenSSH) ----------
async function installWindows(t, j, { appDir, port, meshPort, step }) {
  step('אורז את האפליקציה (Windows · zip)');
  const b = await makeBundle(appDir, os.tmpdir(), 'zip'); step(`חבילה: ${(b.size / 1048576).toFixed(1)}MB`);
  const tag = crypto.randomBytes(4).toString('hex');
  let r = await ssh(t, `powershell -NoProfile -Command "$d=Join-Path $env:TEMP 'cl-${tag}'; New-Item -ItemType Directory -Force $d | Out-Null; Write-Output $d"`, { timeoutMs: 60000 });
  const remoteTmp = (r.out || '').trim().split(/\r?\n/).pop(); if (r.code !== 0 || !/^[A-Za-z]:\\/.test(remoteTmp)) throw new Error('לא נוצרה תיקייה זמנית בשרת: ' + (r.err || r.out).trim());
  const rt = remoteTmp.replace(/\\/g, '/');
  step('מעלה (scp)');
  r = await scp(t, b.file, rt + '/bundle.zip'); if (r.code !== 0) throw new Error('העלאה נכשלה: ' + r.err.trim());
  const ps1 = path.join(b.stage, 'install-windows.ps1'); fs.writeFileSync(ps1, fs.readFileSync(path.join(appDir, 'tools', 'remote', 'install-windows.ps1')));
  r = await scp(t, ps1, rt + '/install.ps1'); if (r.code !== 0) throw new Error('העלאת הסקריפט נכשלה: ' + r.err.trim());
  fs.rm(b.stage, { recursive: true, force: true }, () => { });
  step('מתקין (Node משלה, משימה מתוזמנת שעולה לבד, חומת אש)');
  r = await ssh(t, `powershell -NoProfile -ExecutionPolicy Bypass -File "${remoteTmp}\\install.ps1" -Bundle "${remoteTmp}\\bundle.zip" -Port ${+port} -MeshPort ${+meshPort} & rmdir /s /q "${remoteTmp}"`, { timeoutMs: 900000 });
  const line = (r.out.match(/CLAUDE_LOCAL_INSTALLED [^\r\n]*/) || [])[0];
  if (!line) throw new Error('ההתקנה נכשלה: ' + (r.err || r.out).trim().split(/\r?\n/).slice(-4).join(' | '));
  j.installed = Object.fromEntries(line.replace('CLAUDE_LOCAL_INSTALLED ', '').split(' ').map(kv => kv.split('=')));
  step('הותקן ורץ: ' + line.replace('CLAUDE_LOCAL_INSTALLED ', ''));
}

function create({ appDir, log }) {
  return {
    install: async (target, o = {}) => { const t = { target, configFile: o.configFile, identity: o.identity, password: o.password }; const p = install(t, { appDir, port: o.port || 3456, meshPort: o.meshPort || 47400, login: o.login !== false, log }); const j = jobs.get(target); if (j) j._t = t; return p; },
    status, list, submitCode, cancel, makeBundle: () => makeBundle(appDir), ssh: (target, cmd, o) => ssh({ target, configFile: o && o.configFile }, cmd, o)
  };
}
module.exports = { create, makeBundle };
