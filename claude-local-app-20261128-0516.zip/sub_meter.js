'use strict';
// ============================================================
//  sub_meter.js — "כמה אחוז מהמנוי זה עלה" לכל הודעה / שיחה / מחקר.
//  החשבון מדווח רק אחוז ניצול של כל חלון (שבועי / 5 שעות). כדי לתרגם הודעה בודדת לאחוז:
//  סוכמים את העלות בתעריף API של כל מה שנשלח מאז תחילת החלון (כל שיחות Claude Code במחשב — sub_scan.js)
//  ומחלקים באחוז שהחשבון מדווח → "כמה $ = 1%" של החלון. אחוז הודעה = העלות שלה / הערך הזה.
//  מתעדכן כל 15 דקות ובכל פעם שהאחוז של החשבון זז. הסריקה רצה ב-worker thread (לא חוסמת את השרת).
// ============================================================
const path = require('path');
const LEN = { five_hour: 5 * 3600e3, seven_day: 7 * 24 * 3600e3 };

module.exports = function createSubMeter({ dataDir, getUsage, isSub }) {
  const cacheFile = path.join(dataDir, 'sub-scan-cache.json');
  let state = { windows: {}, at: 0 }, running = null, lastUtil = '';

  // worker thread: לא חוסם את השרת. (לא תהליך נפרד: ב-EXE מופעל Electron מלא במקום Node)
  function runScan(starts) {
    return new Promise((resolve, reject) => {
      const { Worker } = require('worker_threads');
      const w = new Worker(path.join(__dirname, 'sub_scan.js'), { workerData: { cacheFile, starts } });
      const t = setTimeout(() => { try { w.terminate(); } catch { } reject(new Error('scan timeout')); }, 180000);
      w.once('message', m => { clearTimeout(t); resolve(m); });
      w.once('error', e => { clearTimeout(t); reject(e); });
      w.once('exit', code => { clearTimeout(t); if (code) reject(new Error('scan exited ' + code)); });
    });
  }

  function refresh() {
    if (running) return running;
    running = (async () => {
      if (!isSub()) return state;
      const u = await getUsage();
      const ws = ((u && u.windows) || []).filter(w => LEN[w.key] && w.resetsAt && typeof w.utilization === 'number');
      if (!ws.length) return state;
      const starts = ws.map(w => w.resetsAt - LEN[w.key]);
      const t0 = Date.now(); const res = await runScan(starts);
      const windows = {};
      ws.forEach((w, i) => {
        const cost = res.costs[starts[i]] || 0;
        windows[w.key] = { label: w.label, util: w.utilization, cost, perPct: w.utilization >= 1 && cost > 0 ? cost / w.utilization : null, start: starts[i], resetsAt: w.resetsAt };
      });
      state = { windows, at: Date.now(), files: res.files, readMB: res.readMB, scanMs: Date.now() - t0 };
      lastUtil = ws.map(w => w.key + ':' + Math.round(w.utilization)).join(',');
      return state;
    })().catch(e => { state.error = e.message; return state; }).finally(() => { running = null; });
    return running;
  }
  // אחוז מכל חלון שעלות כזו (בתעריף API) מהווה. null = אין עדיין כיול (מצב API, או חלון בלי ניצול)
  function pct(costUSD) {
    if (!isSub() || !(costUSD > 0)) return null;
    const out = {}; let any = false;
    for (const [k, w] of Object.entries(state.windows)) if (w.perPct) { out[k] = +(costUSD / w.perPct).toFixed(5); any = true; }
    return any ? out : null;
  }
  // האחוז של החשבון זז (אירוע rate_limit / קריאת usage): מכיילים מחדש
  function onUtil(windows) {
    const sig = (windows || []).filter(w => LEN[w.key]).map(w => w.key + ':' + Math.round(w.utilization)).join(',');
    if (sig && sig !== lastUtil) refresh();
  }
  const timer = setInterval(() => { if (isSub()) refresh(); }, 15 * 60 * 1000); if (timer.unref) timer.unref();
  setTimeout(() => { if (isSub()) refresh(); }, 8000).unref?.();
  return { refresh, pct, onUtil, get state() { return state; } };
};
