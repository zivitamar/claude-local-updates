'use strict';
// ============================================================
//  FS API — ה-Explorer שבצד שמאל (כמו VS Code): רשימה, קריאה, כתיבה, יצירה,
//  שינוי שם, מחיקה לסל המחזור, פתיחה באפליקציה, "הצג ב-Explorer", בורר תיקיות.
//  כל הנתיבים מועברים לתהליכי PowerShell דרך משתני סביבה (UTF-16) כדי שעברית ורווחים יעבדו תמיד.
// ============================================================
const fs = require('fs');
const fsp = fs.promises;
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');

const IS_WIN = process.platform === 'win32';
const MAX_LIST = 5000;
const MAX_READ = 3 * 1024 * 1024;
const IMG_MIME = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.bmp': 'image/bmp' };

function httpError(status, message) { return Object.assign(new Error(message), { status }); }

function norm(p, base) {
  if (p == null || String(p).trim() === '') throw httpError(400, 'path is required');
  p = String(p).trim().replace(/^["']|["']$/g, '');
  if (p.startsWith('~')) p = path.join(os.homedir(), p.slice(1));
  if (IS_WIN && /^[a-zA-Z]:$/.test(p)) p += '\\';
  return path.isAbsolute(p) ? path.normalize(p) : path.resolve(base || os.homedir(), p);
}

// מריץ סקריפט PowerShell קצר. הנתיבים עוברים ב-env (P1/P2) ולא בתוך הסקריפט.
function ps(script, env = {}, { timeoutMs = 20000, sta = false } = {}) {
  return new Promise((resolve, reject) => {
    const full = '[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; $ErrorActionPreference="Stop"; ' + script;
    const args = ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass'];
    if (sta) args.push('-STA');
    args.push('-EncodedCommand', Buffer.from(full, 'utf16le').toString('base64'));
    const child = spawn('powershell.exe', args, { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'], env: { ...process.env, ...env } });
    const out = [], err = [];
    child.stdout.on('data', d => out.push(d));
    child.stderr.on('data', d => err.push(d));
    const t = setTimeout(() => { try { child.kill(); } catch { } reject(httpError(504, 'PowerShell timeout')); }, timeoutMs);
    child.on('error', e => { clearTimeout(t); reject(e); });
    child.on('close', code => {
      clearTimeout(t);
      const so = Buffer.concat(out).toString('utf8').trim();
      const se = Buffer.concat(err).toString('utf8').trim();
      if (code !== 0) return reject(httpError(500, (se.match(/<S S="Error">([\s\S]*?)<\/S>/) || [])[1] || se || 'PowerShell exit ' + code));
      resolve(so);
    });
  });
}

async function list(p) {
  const dir = norm(p);
  let st;
  try { st = await fsp.stat(dir); } catch { throw httpError(404, 'התיקייה לא נמצאה: ' + dir); }
  if (!st.isDirectory()) throw httpError(400, 'זו לא תיקייה: ' + dir);
  let dirents;
  try { dirents = await fsp.readdir(dir, { withFileTypes: true }); } catch (e) { throw httpError(403, 'אין גישה לתיקייה: ' + (e.code || e.message)); }
  const entries = [];
  for (const d of dirents.slice(0, MAX_LIST)) {
    const full = path.join(dir, d.name);
    let isDir = d.isDirectory(), size = 0, mtime = 0;
    if (d.isSymbolicLink()) { try { isDir = (await fsp.stat(full)).isDirectory(); } catch { } }
    if (!isDir) { try { const s = await fsp.stat(full); size = s.size; mtime = s.mtimeMs; } catch { } }
    entries.push({ name: d.name, path: full, dir: isDir, size, mtime, ext: isDir ? '' : path.extname(d.name).toLowerCase(), hidden: d.name.startsWith('.') || d.name.startsWith('$') || /^(desktop\.ini|thumbs\.db|ntuser\..*)$/i.test(d.name) });
  }
  entries.sort((a, b) => (b.dir - a.dir) || a.name.localeCompare(b.name, 'he', { numeric: true, sensitivity: 'base' }));
  const parent = path.dirname(dir);
  return { path: dir, parent: parent !== dir ? parent : null, entries, truncated: dirents.length > MAX_LIST };
}

async function read(p) {
  const file = norm(p);
  let st;
  try { st = await fsp.stat(file); } catch { throw httpError(404, 'הקובץ לא נמצא: ' + file); }
  if (st.isDirectory()) throw httpError(400, 'זו תיקייה: ' + file);
  const ext = path.extname(file).toLowerCase();
  if (IMG_MIME[ext]) return { path: file, size: st.size, mtime: st.mtimeMs, image: true, mime: IMG_MIME[ext] };
  if (st.size > MAX_READ) return { path: file, size: st.size, mtime: st.mtimeMs, tooLarge: true };
  const buf = await fsp.readFile(file);
  if (buf.subarray(0, 8000).includes(0)) return { path: file, size: st.size, mtime: st.mtimeMs, binary: true };
  return { path: file, size: st.size, mtime: st.mtimeMs, text: buf.toString('utf8') };
}

async function write(p, text) {
  const file = norm(p);
  await fsp.mkdir(path.dirname(file), { recursive: true });
  await fsp.writeFile(file, String(text ?? ''), 'utf8');
  const st = await fsp.stat(file);
  return { path: file, size: st.size, mtime: st.mtimeMs };
}

async function mkdir(p) {
  const dir = norm(p);
  if (fs.existsSync(dir)) throw httpError(409, 'כבר קיים: ' + dir);
  await fsp.mkdir(dir, { recursive: true });
  return { path: dir };
}

async function newFile(p) {
  const file = norm(p);
  if (fs.existsSync(file)) throw httpError(409, 'כבר קיים: ' + file);
  await fsp.mkdir(path.dirname(file), { recursive: true });
  await fsp.writeFile(file, '', { flag: 'wx' });
  return { path: file };
}

async function rename(from, to) {
  const a = norm(from);
  const b = path.isAbsolute(String(to || '')) ? norm(to) : path.join(path.dirname(a), String(to || '').trim());
  if (!String(to || '').trim()) throw httpError(400, 'שם חדש ריק');
  if (!fs.existsSync(a)) throw httpError(404, 'לא נמצא: ' + a);
  if (fs.existsSync(b) && a.toLowerCase() !== b.toLowerCase()) throw httpError(409, 'כבר קיים: ' + b);
  await fsp.rename(a, b);
  return { path: b };
}

// מחיקה לסל המחזור (אפשר לשחזר), לא מחיקה סופית
async function remove(p) {
  const target = norm(p);
  if (!fs.existsSync(target)) throw httpError(404, 'לא נמצא: ' + target);
  if (path.parse(target).root === target) throw httpError(400, 'אי אפשר למחוק כונן שלם');
  const isDir = fs.statSync(target).isDirectory();
  if (!IS_WIN || process.env.CLAUDE_FS_NO_RECYCLE === '1') { // בדיקות: לא ממלאים את סל המיחזור של הבעלים בקבצי בדיקה
    await fsp.rm(target, { recursive: true, force: true }); return { path: target, recycled: false }; }
  await ps(`Add-Type -AssemblyName Microsoft.VisualBasic; ` +
    (isDir ? `[Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory($env:P1, 'OnlyErrorDialogs', 'SendToRecycleBin')`
      : `[Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($env:P1, 'OnlyErrorDialogs', 'SendToRecycleBin')`), { P1: target });
  if (fs.existsSync(target)) throw httpError(500, 'המחיקה נכשלה: ' + target);
  return { path: target, recycled: true };
}

// פתיחה באפליקציית ברירת המחדל (קובץ) או בסייר הקבצים (תיקייה)
// בדיקות: CLAUDE_FS_OPEN_RECORD — נרשם לקובץ במקום לפתוח חלון על המסך של הבעלים
function recordOpen(op, target) { if (!process.env.CLAUDE_FS_OPEN_RECORD) return false; try { fs.appendFileSync(process.env.CLAUDE_FS_OPEN_RECORD, JSON.stringify({ t: Date.now(), op, path: target }) + '\n'); } catch { } return true; }
async function open(p) {
  const target = norm(p);
  if (!fs.existsSync(target)) throw httpError(404, 'לא נמצא: ' + target);
  if (recordOpen('open', target)) return { ok: true, path: target, recorded: true };
  if (!IS_WIN) { spawn(process.platform === 'darwin' ? 'open' : 'xdg-open', [target], { detached: true, stdio: 'ignore' }).unref(); return { ok: true }; }
  await ps('Start-Process -FilePath $env:P1', { P1: target });
  return { ok: true, path: target };
}

// "הצג בסייר הקבצים" — פותח את התיקייה ומסמן את הקובץ
async function reveal(p) {
  const target = norm(p);
  if (!fs.existsSync(target)) throw httpError(404, 'לא נמצא: ' + target);
  if (recordOpen('reveal', target)) return { ok: true, path: target, recorded: true };
  if (!IS_WIN) return open(path.dirname(target));
  spawn('explorer.exe', [`/select,"${target}"`], { detached: true, stdio: 'ignore', windowsVerbatimArguments: true }).unref();
  return { ok: true, path: target };
}

// חלון "בחר תיקייה" של Windows (לדפדפן; ב-EXE משתמשים בדיאלוג של Electron)
async function pickFolder({ initial, title, testAutoCloseMs } = {}) {
  if (!IS_WIN) throw httpError(501, 'Folder picker is only implemented on Windows');
  const start = initial && fs.existsSync(norm(initial)) ? norm(initial) : os.homedir();
  const autoClose = Number(testAutoCloseMs) > 0 ? Math.min(Number(testAutoCloseMs), 60000) : 0;
  const script = `Add-Type -AssemblyName System.Windows.Forms;
$f = New-Object System.Windows.Forms.Form; $f.TopMost = $true; $f.ShowInTaskbar = $false; $f.StartPosition = 'CenterScreen'; $f.Width = 1; $f.Height = 1; $f.Opacity = 0;
$d = New-Object System.Windows.Forms.FolderBrowserDialog; $d.Description = $env:P2; $d.SelectedPath = $env:P1; $d.ShowNewFolderButton = $true;
${autoClose ? `Add-Type -TypeDefinition @'
using System; using System.Runtime.InteropServices; using System.Text;
public static class ClcDlg {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumThreadWindows(uint tid, EnumProc cb, IntPtr l);
  [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder sb, int n);
  [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
  public static int CloseDialogs() { int n = 0; EnumThreadWindows(GetCurrentThreadId(), (h, l) => { var sb = new StringBuilder(64); GetClassName(h, sb, 64); if (sb.ToString() == "#32770") { PostMessage(h, 0x0010, IntPtr.Zero, IntPtr.Zero); n++; } return true; }, IntPtr.Zero); return n; }
}
'@;
$t = New-Object System.Windows.Forms.Timer; $t.Interval = ${autoClose}; $t.add_Tick({ $t.Stop(); [void][ClcDlg]::CloseDialogs() }); $t.Start();` : ''}
$f.Show(); $f.Activate();
$r = $d.ShowDialog($f); $f.Close();
if ($r -eq [System.Windows.Forms.DialogResult]::OK) { Write-Output ('OK|' + $d.SelectedPath) } else { Write-Output 'CANCEL|' }`;
  const out = await ps(script, { P1: start, P2: title || 'בחר תיקייה ש-Claude יעבוד עליה' }, { timeoutMs: 10 * 60 * 1000, sta: true });
  const line = out.split(/\r?\n/).pop() || '';
  if (line.startsWith('OK|') && line.length > 3) return { path: line.slice(3) };
  return { cancelled: true };
}

async function stat(p) {
  const target = norm(p);
  try { const s = await fsp.stat(target); return { path: target, exists: true, dir: s.isDirectory(), size: s.size, mtime: s.mtimeMs }; }
  catch { return { path: target, exists: false }; }
}

// הצצה קצרה לכרטיס נתיב בצ'אט (קריאה בלבד): תיקייה → עד 40 פריטים · טקסט → 14 שורות ראשונות · אחרת → גודל וסוג
const PEEK_IMG = /\.(png|jpe?g|gif|webp|bmp|svg|ico|avif)$/i, PEEK_DOC = /\.(pdf|docx?|dotx|xlsx?|xlsm|pptx?|odt|ods|odp|rtf|epub)$/i;
async function peek(p) {
  // אבטחה: קריאה בלבד, נתיב מוחלט מקומי בלבד — בלי \\שרת (ריחוף לא ישלח הזדהות SMB לשרת זר), בלי \\.\ / \\?\ (התקנים)
  const raw = String(p || '');
  if (!raw || raw.length > 1024 || /[\u0000-\u001f]/.test(raw)) throw httpError(400, 'נתיב לא תקין');
  if (/^[\\/]{2}/.test(raw.trim())) return { path: raw, exists: false, blocked: 'unc' };
  if (!/^(?:[A-Za-z]:[\\/]|\/|~[\\/]?$|~[\\/])/.test(raw.trim().replace(/^["']|["']$/g, ''))) throw httpError(400, 'נדרש נתיב מוחלט');
  const target = norm(p);
  if (/^[\\/]{2}/.test(target)) return { path: target, exists: false, blocked: 'unc' };
  let s; try { s = await fsp.stat(target); } catch { return { path: target, exists: false }; }
  if (s.isDirectory()) {
    let ents = []; try { ents = await fsp.readdir(target, { withFileTypes: true }); } catch (e) { return { path: target, exists: true, dir: true, entries: [], total: 0, error: e.code || e.message }; }
    const all = ents.map(d => ({ name: d.name, dir: d.isDirectory() })).sort((a, b) => (b.dir - a.dir) || a.name.localeCompare(b.name));
    return { path: target, exists: true, dir: true, mtime: s.mtimeMs, total: all.length, entries: all.slice(0, 40) };
  }
  const ext = path.extname(target).slice(1).toLowerCase();
  const out = { path: target, exists: true, dir: false, size: s.size, mtime: s.mtimeMs, ext, kind: PEEK_IMG.test(target) ? 'image' : PEEK_DOC.test(target) ? 'doc' : 'binary' };
  if (out.kind === 'binary' && s.size > 0) {
    let fh; try {
      fh = await fsp.open(target, 'r'); const buf = Buffer.alloc(Math.min(16384, s.size)); const { bytesRead } = await fh.read(buf, 0, buf.length, 0);
      const b = buf.subarray(0, bytesRead);
      if (!b.includes(0)) { out.kind = 'text'; const lines = b.toString('utf8').replace(/^\uFEFF/, '').split(/\r?\n/); out.lines = lines.slice(0, 14).map(l => l.length > 200 ? l.slice(0, 200) + '…' : l); out.more = lines.length > 14 || bytesRead < s.size; }
    } catch { } finally { if (fh) await fh.close().catch(() => { }); }
  } else if (out.kind === 'binary') out.kind = 'text', out.lines = [], out.more = false;
  return out;
}

// מיקומים מהירים: בית, שולחן עבודה, מסמכים, הורדות, כוננים
function places(desktop) {
  const home = os.homedir();
  const cand = [
    { name: 'שולחן העבודה', path: desktop || path.join(home, 'Desktop'), icon: 'desktop' },
    { name: 'מסמכים', path: path.join(home, 'Documents'), icon: 'docs' },
    { name: 'הורדות', path: path.join(home, 'Downloads'), icon: 'download' },
    { name: 'תיקיית הבית', path: home, icon: 'home' }
  ].filter(x => { try { return fs.existsSync(x.path); } catch { return false; } });
  const drives = [];
  if (IS_WIN) for (let c = 67; c <= 90; c++) { const d = String.fromCharCode(c) + ':\\'; try { if (fs.existsSync(d)) drives.push({ name: d, path: d, icon: 'drive' }); } catch { } }
  return { home, places: cand, drives };
}

// גרירה מהדפדפן נותנת רק שם תיקייה (בלי נתיב) — מחפשים אותה במקומות הסבירים
async function locate(name, extraRoots = []) {
  name = String(name || '').trim();
  if (!name || /[\\/:*?"<>|]/.test(name)) throw httpError(400, 'שם לא תקין');
  const home = os.homedir();
  const roots = [...new Set([...extraRoots.filter(Boolean), ...places().places.map(p => p.path), path.join(home, 'OneDrive'), home].map(r => { try { return path.normalize(r); } catch { return null; } }).filter(Boolean))];
  const found = new Set();
  const SKIP = new Set(['node_modules', '.git', 'AppData', '$Recycle.Bin', 'Windows', 'Program Files', 'Program Files (x86)']);
  async function walk(dir, depth) {
    if (found.size >= 20 || depth > 3) return;
    let ents; try { ents = await fsp.readdir(dir, { withFileTypes: true }); } catch { return; }
    for (const e of ents) {
      if (!e.isDirectory() || SKIP.has(e.name)) continue;
      const full = path.join(dir, e.name);
      if (e.name.toLowerCase() === name.toLowerCase()) found.add(full);
      if (depth < 3) await walk(full, depth + 1);
    }
  }
  for (const r of roots) { if (fs.existsSync(r)) await walk(r, 1); }
  return { name, matches: [...found] };
}

const MEDIA_MIME = { '.mp4': 'video/mp4', '.m4v': 'video/mp4', '.webm': 'video/webm', '.mov': 'video/quicktime', '.ogv': 'video/ogg', '.mkv': 'video/x-matroska', '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.ogg': 'audio/ogg', '.m4a': 'audio/mp4', '.flac': 'audio/flac', '.pdf': 'application/pdf' };
// קובץ גולמי (תמונה / סרטון / שמע): תומך ב-Range כדי שסרטון ינוגן ויקפוץ לכל נקודה בלי לטעון את כולו
function rawStream(p, res, req) {
  const file = norm(p);
  const ext = path.extname(file).toLowerCase();
  let st; try { st = fs.statSync(file); } catch { st = null; }
  if (!st || st.isDirectory()) { res.writeHead(404); return res.end('Not found'); }
  const type = IMG_MIME[ext] || MEDIA_MIME[ext] || 'application/octet-stream';
  const range = req && /^bytes=(\d*)-(\d*)$/.exec(String(req.headers.range || '').trim());
  if (range && (range[1] || range[2])) {
    const start = range[1] ? Number(range[1]) : Math.max(0, st.size - Number(range[2]));
    const end = range[1] && range[2] ? Math.min(Number(range[2]), st.size - 1) : st.size - 1;
    if (start >= st.size || start > end) { res.writeHead(416, { 'content-range': `bytes */${st.size}` }); return res.end(); }
    res.writeHead(206, { 'content-type': type, 'cache-control': 'no-store', 'accept-ranges': 'bytes', 'content-range': `bytes ${start}-${end}/${st.size}`, 'content-length': end - start + 1 });
    return fs.createReadStream(file, { start, end }).pipe(res);
  }
  res.writeHead(200, { 'content-type': type, 'cache-control': 'no-store', 'accept-ranges': 'bytes', 'content-length': st.size });
  fs.createReadStream(file).pipe(res);
}

module.exports = { list, read, write, mkdir, newFile, rename, remove, open, reveal, pickFolder, stat, peek, places, locate, rawStream, norm, httpError };
