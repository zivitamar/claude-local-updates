'use strict';
// ============================================================
//  flows.js — "תזרים" (Flow): רצף שלבים שהשרת מריץ על שיחה / פרויקט, ו-Claude לא יכול לעקוף.
//
//  * התזרים נשמר ב-data/flows/<id>.json, וכל הרצה ב-data/flows/runs/<runId>.json
//  * השרת (לא Claude) מחליט איזה שלב רץ עכשיו, בודק את התוצאה (פקודה / טקסט / שופט) ובוחר את המעבר הבא
//  * לכל שלב יש זמן מקסימום. מגבלות להרצה כולה (מקסימום שלבים / זמן כולל / חזרות לאותו שלב) — רק אם הבעלים הגדיר אותן.
//    בלי מגבלה (ברירת המחדל, הבעלים 26/11): תזרים בלולאה זורם לנצח, עד שהבעלים עוצר אותו
//  * תקלה זמנית (תור של Claude שקרס / שגיאת API / חריגה בשרת / Claude תקוע / השיחה תפוסה) לא מפרקת את התזרים:
//    השלב רץ שוב עם המתנה הולכת וגדלה (נרשם ביומן ההרצה). רק עצירה של הבעלים, מגבלה שהבעלים הגדיר, או מעבר "עצירה" מסיימים
//  * הרצה שרצה כשהשרת נסגר — ממשיכה אחרי שהוא עולה (מצב ההרצה נשמר בקובץ)
//  * 🔒 נעילה: תזרים נעול — אסור לשנות / למחוק אותו (גם לא ל-Claude, גם לא בעריכת הקובץ: עותק נעול נשמר בצד ומשוחזר)
//  * סוגי שלב: task (משימה ל-Claude), research (מחקר ברשת + מסקנות), command (פקודה במחשב),
//              watch (בדיקה חוזרת של פקודה במשך זמן מוגבל), wait (המתנה)
//  * מעברים: on.ok / on.fail / on.timeout = 'next' | 'end' | 'stop' | <מזהה שלב>
//  * תזמון: none | at (פעם אחת בשעה) | every (כל X דקות) | daily (כל יום בשעה)
// ============================================================
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');

const STEP_TYPES = ['task', 'research', 'command', 'watch', 'wait'];
const CHECK_TYPES = ['none', 'contains', 'not_contains', 'command', 'judge'];
const DEFAULT_TIMEOUT = { task: 30, research: 25, command: 10, watch: 30, wait: 0 };
// מגבלות להרצה: null = ללא הגבלה (ברירת מחדל). עד 26/11 ברירת המחדל הייתה 40 / 180 / 5 — תזרים שנשמר לפני כן ושהערכים שלו
// (ברירת מחדל ישנה או חיתוך לתקרות הישנות 200/720/30) לא נבחרו ע"י הבעלים: בטעינה כל המגבלות של תזרים / הרצה מלפני v2 הופכות ל"ללא הגבלה" (פעם אחת, limitsV=2)
const LIMIT_KEYS = ['maxSteps', 'maxMinutes', 'maxVisits'];
const OLD_DEFAULT_LIMITS = { maxSteps: 40, maxMinutes: 180, maxVisits: 5 };
const LIMIT_RANGE = { maxSteps: [1, 1e6, true], maxMinutes: [0.02, 525600, false], maxVisits: [1, 1e6, true] };
const LIMITS_V = 2;
const TERMINAL = new Set(['done', 'failed', 'stopped', 'timeout']);
const REFUSAL_RE = /safeguard|usage[ -]policy|acceptable use|\[cyber\]|flagged (this|the) (session|request)|can'?t respond to your last message/i;
const has = (o, k) => !!o && Object.prototype.hasOwnProperty.call(o, k);
// ערך מגבלה: ריק / 0 / null / לא מספר = ללא הגבלה
function limitVal(k, v) {
  if (v == null || v === '' || v === false) return null;
  const n = Number(v); if (!Number.isFinite(n) || n <= 0) return null;
  const [lo, hi, int] = LIMIT_RANGE[k]; const x = Math.min(hi, Math.max(lo, n));
  return int ? Math.round(x) : x;
}
// הצגת שלב בתוך טקסט ארוך: הסוף של התשובה (שם הסיכום), חתוך בתחילת שורה — לא באמצע מילה / בלוק markdown
function tailText(s, max) {
  s = String(s == null ? '' : s).replace(/\u0000/g, '').replace(/\r\n/g, '\n').trim();
  if (s.length <= max) return s;
  let t = s.slice(-max); const nl = t.indexOf('\n'); if (nl > 0 && nl < max * 0.4) t = t.slice(nl + 1);
  return '…\n' + t;
}

const clampInt = (v, lo, hi, d) => { const n = Math.round(Number(v)); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d; };
const clampNum = (v, lo, hi, d) => { const n = Number(v); return Number.isFinite(n) && n > 0 ? Math.min(hi, Math.max(lo, n)) : d; };
const str = (v, max) => String(v == null ? '' : v).replace(/\u0000/g, '').slice(0, max);

// ---------- אכיפה בהוק: אילו כלים Claude רשאי להפעיל בכל שלב ----------
// guard: off = בלי אכיפה · steps (ברירת מחדל) = נאכף רק בשלבים שהוגדרה בהם רשימת כלים מותרים (allow) · strict = כל שלב נאכף; שלב בלי רשימה = קריאה בלבד
const GUARDS = ['off', 'steps', 'strict'];
const CATEGORIES = {
  read: { label: 'קריאה וחיפוש בקבצים', re: /^(Read|Glob|Grep|LS|NotebookRead|ToolSearch|ListAgents|TodoWrite|TodoRead)$/ },
  write: { label: 'כתיבה ועריכה של קבצים', re: /^(Write|Edit|MultiEdit|NotebookEdit)$/ },
  shell: { label: 'פקודות (Bash / PowerShell)', re: /^(Bash|PowerShell|Monitor|BashOutput|KillShell)$/ },
  web: { label: 'רשת (חיפוש וקריאת דפים)', re: /^(WebSearch|WebFetch)$/ },
  browser: { label: 'דפדפן Chrome', re: /^mcp__claudechat__browser_/ },
  agents: { label: 'סוכני משנה', re: /^(Task|Agent|SendMessage|TaskStop|Workflow)$/ },
  chats: { label: "צ'אטים ותזרימים של האפליקציה", re: /^mcp__claudechat__(chat_|flow_)/ },
  mcp: { label: 'כלי MCP אחרים', re: /^mcp__(?!claudechat__)/ },
  all: { label: 'הכול', re: /.*/ }
};
const toolAllowed = (allow, name) => (allow || []).some(m => (CATEGORIES[m] ? CATEGORIES[m].re.test(name) : m === name || (m.endsWith('*') && name.startsWith(m.slice(0, -1)))));
const briefInput = input => { input = input || {}; const v = input.command || input.file_path || input.path || input.url || input.pattern || input.query || input.prompt || input.description || input.expression || ''; return String(v).replace(/\s+/g, ' ').slice(0, 110); };

function createFlows(deps) {
  const { dataDir, sendToChat, waitTurn, createChat, stopChat, getChat, findChatByCode, chatDir, projectDir, oneShot, killTree, onEvent } = deps;
  const now = deps.now || (() => Date.now());
  const DIR = path.join(dataDir, 'flows');
  const RUNS = path.join(DIR, 'runs');
  const LOCKDIR = path.join(DIR, 'locks');
  fs.mkdirSync(RUNS, { recursive: true }); fs.mkdirSync(LOCKDIR, { recursive: true });
  const active = new Map(); // runId -> { run, abort: AbortController, procs:Set, suspend?:bool }
  const emitEv = (type, data) => { try { onEvent && onEvent(type, data); } catch { } };
  // המתנה בין ניסיונות אחרי תקלה זמנית: base, ×2 בכל פעם, עד max
  const RETRY_BASE = Number(deps.retryBaseMs != null ? deps.retryBaseMs : process.env.FLOWS_RETRY_BASE_MS) || 3000;
  const RETRY_MAX = Number(deps.retryMaxMs != null ? deps.retryMaxMs : process.env.FLOWS_RETRY_MAX_MS) || 300000;
  const backoff = n => Math.min(RETRY_MAX, RETRY_BASE * Math.pow(2, Math.max(0, n - 1)));

  // ---------- אחסון ----------
  const flowFile = id => path.join(DIR, String(id).replace(/[^\w-]/g, '') + '.json');
  const runFile = id => path.join(RUNS, String(id).replace(/[^\w-]/g, '') + '.json');
  const readJson = f => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } };
  const writeJson = (f, o) => { const tmp = f + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(o, null, 1), 'utf8'); fs.renameSync(tmp, f); };

  // ---------- 🔒 נעילה: רשימת הנעולים + עותק נעול של כל תזרים (מקור האמת בזמן שהוא נעול) ----------
  const LOCKS_FILE = path.join(LOCKDIR, 'locks.json');
  // מפתח הנעילה: המזהה בלי תווים שאינם חלק משם הקובץ, באותיות קטנות — כי גם flowFile פותח את אותו קובץ בכל איות (Windows)
  const lk = id => String(id == null ? '' : id).replace(/[^\w-]/g, '').toLowerCase();
  let locksText = null; try { locksText = fs.readFileSync(LOCKS_FILE, 'utf8'); } catch { }
  const locks = (() => { let o = null; try { o = JSON.parse(locksText); } catch { } const out = {}; if (o && typeof o === 'object' && !Array.isArray(o)) for (const [k, v] of Object.entries(o)) if (v && typeof v === 'object') out[lk(k)] = v; return out; })(); // id -> { at, hash, snapshot, blocked:[], blockedTotal }
  const saveLocks = () => { try { const txt = JSON.stringify(locks, null, 1); const tmp = LOCKS_FILE + '.tmp'; fs.writeFileSync(tmp, txt, 'utf8'); fs.renameSync(tmp, LOCKS_FILE); locksText = txt; } catch (e) { console.error('[flows] save locks', e.message); } };
  const hashOf = o => crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex');
  const isLocked = id => !!locks[lk(id)];
  // קובץ של תזרים נעול שהשתנה מבחוץ (עריכה ישירה של הקובץ) / נמחק — משוחזר מהעותק הנעול, ונרשם כניסיון חסום
  function guardLocked(id, f) {
    const L = locks[lk(id)]; if (!L) return f;
    if (f && hashOf(f) === L.hash) return f;
    try { writeJson(flowFile((L.snapshot && L.snapshot.id) || id), L.snapshot); } catch { }
    noteBlocked(id, { by: 'file', what: f ? 'עריכה ישירה של קובץ התזרים — שוחזר מהעותק הנעול' : 'מחיקת קובץ התזרים — שוחזר מהעותק הנעול' });
    console.log('[flows] locked flow file was changed outside the app — restored', id);
    emitEv('flow_saved', { id, restored: true });
    return JSON.parse(JSON.stringify(L.snapshot));
  }
  function noteBlocked(id, o = {}) {
    const L = locks[lk(id)]; if (!L) return;
    L.blockedTotal = (L.blockedTotal || 0) + 1; (L.blocked = L.blocked || []).push({ at: now(), by: o.by || 'tool', what: str(o.what, 160), tool: str(o.tool, 60) });
    if (L.blocked.length > 20) L.blocked.splice(0, L.blocked.length - 20);
    saveLocks(); emitEv('flow_saved', { id: String(id) });
  }
  const lockInfo = id => { const L = locks[lk(id)]; return L ? { at: L.at, blocked: (L.blocked || []).slice(-5), blockedTotal: L.blockedTotal || 0 } : null; };
  const lockedIds = () => Object.keys(locks).map(k => (locks[k].snapshot && locks[k].snapshot.id) || k);

  // תזרים שנשמר לפני שהמגבלות הפכו לאופציונליות: ערך שזהה בדיוק לברירת המחדל הישנה = לא נבחר ע"י הבעלים → ללא הגבלה
  function migrate(f, file) {
    if (!f || typeof f !== 'object' || f.limitsV === LIMITS_V) return f;
    // לפני v2 הבעלים מעולם לא בחר מגבלות: כל ערך היה ברירת מחדל ישנה או חיתוך (clamp) של הישן (למשל 40/720/30) → ללא הגבלה
    for (const k of LIMIT_KEYS) f[k] = null;
    f.limitsV = LIMITS_V;
    if (!isLocked(f.id)) { try { writeJson(file, f); } catch { } }
    return f;
  }
  const loadFlow = file => { const f = readJson(file); if (!f || !f.id || !Array.isArray(f.steps)) return null; return migrate(f, file); };
  // 🔒 קובץ תזרים שמסומן locked:true נשאר נעול גם אם רשימת הנעילות (locks.json) נמחקה / נערכה כשהשרת היה כבוי
  try {
    let rebuilt = 0;
    for (const n of fs.readdirSync(DIR)) {
      if (!n.endsWith('.json')) continue; const f = loadFlow(path.join(DIR, n));
      if (!f || f.locked !== true || locks[lk(f.id)]) continue;
      locks[lk(f.id)] = { at: f.lockedAt || now(), hash: hashOf(f), snapshot: f, blocked: [{ at: now(), by: 'file', what: 'רשימת הנעילות נמחקה / נערכה — הנעילה שוחזרה מקובץ התזרים', tool: '' }], blockedTotal: 1 };
      rebuilt++; console.log('[flows] lock restored from the flow file', f.id);
    }
    if (rebuilt) saveLocks();
  } catch { }
  // 🔒 שומר: רשימת הנעילות וקבצי התזרימים הנעולים שנערכו / נמחקו מבחוץ בזמן שהשרת רץ — משוחזרים מהזיכרון (תוך שנייה וחצי) ונרשמים כניסיון חסום
  function verifyLocks() {
    try {
      if (!Object.keys(locks).length && (locksText == null || locksText.trim() === '{}')) return;
      if (!fs.existsSync(DIR)) return;
      let cur = null; try { cur = fs.readFileSync(LOCKS_FILE, 'utf8'); } catch { }
      if (cur !== locksText) {
        console.log('[flows] locks file was changed outside the app — restored');
        const ids = Object.keys(locks); saveLocks();
        for (const id of ids) noteBlocked(id, { by: 'file', what: 'עריכה / מחיקה של רשימת הנעילות (locks.json) — שוחזרה' });
      }
      for (const id of lockedIds()) guardLocked(id, loadFlow(flowFile(id)));
    } catch (e) { console.error('[flows] verify locks', e.message); }
  }
  const lockWatch = setInterval(verifyLocks, Number(deps.lockWatchMs) || 1500); lockWatch.unref && lockWatch.unref();
  function listFlows() {
    try {
      const ids = new Set(); const out = [];
      for (const n of fs.readdirSync(DIR)) { if (!n.endsWith('.json')) continue; let f = loadFlow(path.join(DIR, n)); if (!f) continue; if (isLocked(f.id)) f = guardLocked(f.id, f); ids.add(f.id); out.push(f); }
      for (const id of lockedIds()) if (!ids.has(id)) { const f = guardLocked(id, null); if (f) out.push(f); } // תזרים נעול שהקובץ שלו נמחק
      return out.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    } catch { return []; }
  }
  const getFlow = id => { const f = loadFlow(flowFile(id)); return isLocked(id) ? guardLocked(id, f) : f; };
  function saveRun(run) { try { writeJson(runFile(run.id), run); } catch (e) { console.error('[flows] save run', e.message); } emitEv('flow_run', summary(run)); }
  function listRuns({ flowId, limit = 30 } = {}) {
    try {
      const rs = fs.readdirSync(RUNS).filter(f => f.endsWith('.json')).map(f => readJson(path.join(RUNS, f))).filter(Boolean);
      return rs.filter(r => !flowId || r.flowId === flowId).sort((a, b) => (b.startedAt || 0) - (a.startedAt || 0)).slice(0, limit);
    } catch { return []; }
  }
  const getRun = id => (active.has(id) ? active.get(id).run : readJson(runFile(id)));
  function summary(r) { return { id: r.id, flowId: r.flowId, flowName: r.flowName, status: r.status, reason: r.reason || '', startedAt: r.startedAt, endedAt: r.endedAt || null, convId: r.convId, stepId: r.stepId || null, stepNo: r.stepNo || 0, total: (r.steps || []).length, trigger: r.trigger, retryAt: r.retryAt || null, transient: r.transientTotal || 0, resumed: r.resumed || 0 }; }

  // ---------- בדיקה ונרמול ----------
  // מקבל תזרים "גולמי" (מהממשק / מ-Claude) ומחזיר {flow, errors}. מעברים יכולים להיות מזהה / שם שלב / מספר (1-based)
  function normalize(input, base = {}) {
    const errors = [];
    const f = {
      id: base.id || input.id || crypto.randomUUID(),
      name: str(input.name != null ? input.name : base.name, 80).trim(),
      description: str(input.description != null ? input.description : base.description, 400).trim(),
      scope: null, steps: [], enabled: input.enabled != null ? !!input.enabled : (base.enabled != null ? !!base.enabled : true),
      // מגבלות: רק מה שהבעלים קבע. חסר / ריק / 0 = ללא הגבלה
      maxSteps: limitVal('maxSteps', has(input, 'maxSteps') ? input.maxSteps : base.maxSteps),
      maxMinutes: limitVal('maxMinutes', has(input, 'maxMinutes') ? input.maxMinutes : base.maxMinutes),
      maxVisits: limitVal('maxVisits', has(input, 'maxVisits') ? input.maxVisits : base.maxVisits),
      // 🔬 מחקר עמוק בתזרים: N איטרציות עם מחקר ואז 2N בלי (N = 1 / 2 / 3, תמיד נאכף בהוק)
      researchQuota: [1, 2, 3].includes(Number(has(input, 'researchQuota') ? input.researchQuota : base.researchQuota)) ? Number(has(input, 'researchQuota') ? input.researchQuota : base.researchQuota) : 1,
      limitsV: LIMITS_V,
      guard: GUARDS.includes(input.guard) ? input.guard : (GUARDS.includes(base.guard) ? base.guard : 'steps'),
      schedule: { mode: 'none' }, createdAt: base.createdAt || now(), updatedAt: now()
    };
    if (base.locked) { f.locked = true; f.lockedAt = base.lockedAt || null; } // הנעילה משתנה רק דרך setLock (לא דרך עריכה)
    if (!f.name) errors.push('חסר שם לתזרים');
    const sc = input.scope || base.scope || {};
    if ((sc.type === 'chat' || sc.type === 'project') && sc.id) f.scope = { type: sc.type, id: str(sc.id, 80) };
    else errors.push('חסר יעד: שיחה או פרויקט');
    const raw = Array.isArray(input.steps) ? input.steps : (Array.isArray(base.steps) ? base.steps : []);
    if (!raw.length) errors.push('התזרים חייב לפחות שלב אחד');
    if (raw.length > 60) errors.push('יותר מדי שלבים (מקסימום 60)');
    const ids = new Set();
    raw.slice(0, 60).forEach((s, i) => {
      s = s || {};
      let id = str(s.id, 40).replace(/[^\w-]/g, ''); if (!id || ids.has(id)) id = 's' + (i + 1) + (ids.has('s' + (i + 1)) ? '-' + crypto.randomBytes(2).toString('hex') : '');
      ids.add(id);
      const type = STEP_TYPES.includes(s.type) ? s.type : 'task';
      const st = { id, name: str(s.name, 80).trim() || ('שלב ' + (i + 1)), type };
      if (type === 'task' || type === 'research') { st.prompt = str(s.prompt, 8000).trim(); if (!st.prompt) errors.push(`שלב ${i + 1}: חסרה הוראה ל-Claude`); }
      if (type === 'command' || type === 'watch') { st.command = str(s.command, 4000).trim(); if (!st.command) errors.push(`שלב ${i + 1}: חסרה פקודה`); }
      if (type === 'watch') st.everySec = clampNum(s.everySec, 0.2, 3600, 10);
      if (type === 'wait') { st.waitSec = clampNum(s.waitSec, 0.1, 86400, 60); }
      if (type !== 'wait') st.timeoutMin = clampNum(s.timeoutMin, 0.02, 240, DEFAULT_TIMEOUT[type]);
      if (type === 'task' || type === 'research') st.idleMin = Number.isFinite(Number(s.idleMin)) ? Math.min(240, Math.max(0, Number(s.idleMin))) : 20;
      if (type === 'task' || type === 'research' || type === 'command') st.retries = clampInt(s.retries, 0, 5, 0);
      if (s.chat) st.chat = str(s.chat, 20).trim();
      if (type === 'task' || type === 'research') { const al = (Array.isArray(s.allow) ? s.allow : []).map(x => str(x, 80).trim()).filter(Boolean).slice(0, 40); if (al.length) st.allow = [...new Set(al)]; }
      const ck = s.check || {};
      if (type === 'task' || type === 'research' || type === 'watch' || type === 'command') {
        const ct = CHECK_TYPES.includes(ck.type) ? ck.type : 'none';
        st.check = { type: ct, value: str(ck.value, 2000) };
        if (ct !== 'none' && !st.check.value.trim()) errors.push(`שלב ${i + 1}: לבדיקה "${ct}" חסר ערך`);
      }
      st.on = { ok: 'next', fail: 'stop', timeout: 'stop', ...((s.on && typeof s.on === 'object') ? s.on : {}) };
      f.steps.push(st);
    });
    // פתרון מעברים: 'next' | 'end' | 'stop' | id | שם | מספר
    const byName = new Map(f.steps.map(s => [s.name, s.id]));
    for (const [i, st] of f.steps.entries()) {
      for (const k of ['ok', 'fail', 'timeout']) {
        let v = st.on[k]; v = v == null ? '' : String(v).trim();
        if (!v) v = k === 'ok' ? 'next' : 'stop';
        if (!['next', 'end', 'stop'].includes(v)) {
          const num = /^#?(\d{1,3})$/.exec(v);
          if (num && f.steps[Number(num[1]) - 1]) v = f.steps[Number(num[1]) - 1].id;
          else if (ids.has(v)) { /* מזהה */ }
          else if (byName.has(v)) v = byName.get(v);
          else { errors.push(`שלב ${i + 1}: המעבר "${v}" לא מצביע על שלב קיים`); v = k === 'ok' ? 'next' : 'stop'; }
        }
        st.on[k] = v;
      }
    }
    const sch = input.schedule != null ? input.schedule : base.schedule;
    if (sch && sch.mode && sch.mode !== 'none') {
      if (sch.mode === 'at') { const at = Number(sch.at); if (at > 0) f.schedule = { mode: 'at', at, done: !!sch.done && at === Number((base.schedule || {}).at) }; else errors.push('תזמון: חסרה שעה'); }
      else if (sch.mode === 'every') { f.schedule = { mode: 'every', everyMin: clampInt(sch.everyMin, 1, 10080, 60), nextAt: Number(sch.nextAt) || (now() + clampInt(sch.everyMin, 1, 10080, 60) * 60000) }; }
      else if (sch.mode === 'daily') { const m = /^(\d{1,2}):(\d{2})$/.exec(String(sch.time || '')); if (m && +m[1] < 24 && +m[2] < 60) f.schedule = { mode: 'daily', time: m[1].padStart(2, '0') + ':' + m[2], lastDay: sch.lastDay || '' }; else errors.push('תזמון: שעה לא תקינה (HH:MM)'); }
    }
    // תזרים עם שלב שחוזר על עצמו בלי מוצא: מזהירים (אבל מגבלות מונעות תקיעה)
    return { flow: f, errors };
  }

  const lockedErr = (id, what) => { const f = getFlow(id); const e = new Error(`🔒 התזרים «${f ? f.name : id}» נעול ע"י הבעלים — אי אפשר ${what} אותו. כדי לשנות: לבטל קודם את הנעילה (כפתור 🔒 בחלון התזרים, באפליקציה). The user LOCKED this flow.`); e.status = 423; e.locked = true; return e; };
  function saveFlow(input, baseId, opts = {}) {
    // POST עם id של תזרים קיים (למשל טיוטה ששמרו פעמיים) = עדכון שלו — גם זה נאכף בנעילה
    if (!baseId && input && input.id && isLocked(input.id)) { noteBlocked(input.id, { by: opts.by || 'api', what: 'ניסיון לשמור מחדש תזרים נעול' }); throw lockedErr(input.id, 'לשמור מחדש'); }
    const base = baseId ? getFlow(baseId) : null;
    if (baseId && !base) { const e = new Error('התזרים לא נמצא'); e.status = 404; throw e; }
    if (base && isLocked(base.id)) { noteBlocked(base.id, { by: opts.by || 'api', what: 'ניסיון לערוך תזרים נעול', tool: opts.tool }); throw lockedErr(base.id, 'לערוך'); }
    const { flow, errors } = normalize(input, base || {});
    if (errors.length) { const e = new Error(errors.join(' · ')); e.status = 400; e.errors = errors; throw e; }
    writeJson(flowFile(flow.id), flow);
    emitEv('flow_saved', { id: flow.id });
    return flow;
  }
  function removeFlow(id, opts = {}) {
    if (isLocked(id)) { noteBlocked(id, { by: opts.by || 'api', what: 'ניסיון למחוק תזרים נעול', tool: opts.tool }); throw lockedErr(id, 'למחוק'); }
    for (const [rid, a] of active) if (lk(a.run.flowId) === lk(id)) stopRun(rid, 'התזרים נמחק');
    try { fs.unlinkSync(flowFile(id)); } catch { return false; }
    emitEv('flow_saved', { id });
    return true;
  }
  // 🔒 נעילה / ביטול נעילה. מי מורשה לבטל (רק הבעלים, מחלון האפליקציה) — נבדק בשרת לפני הקריאה
  function setLock(id, on) {
    const f = getFlow(id); if (!f) return null;
    const k = lk(f.id);
    if (on) { f.locked = true; f.lockedAt = now(); writeJson(flowFile(f.id), f); locks[k] = { at: f.lockedAt, hash: hashOf(f), snapshot: f, blocked: (locks[k] && locks[k].blocked) || [], blockedTotal: (locks[k] && locks[k].blockedTotal) || 0 }; }
    else { delete f.locked; delete f.lockedAt; delete locks[k]; writeJson(flowFile(f.id), f); }
    saveLocks(); emitEv('flow_saved', { id: f.id });
    console.log(`[flows] ${f.id} ${on ? 'locked' : 'unlocked'}`);
    return f;
  }

  // ---------- עריכה חלקית (כלי flow_update של Claude) ----------
  // patch: name / description / enabled / guard / schedule / maxSteps / maxMinutes / maxVisits (0 או null = ללא הגבלה) /
  //        steps (רשימה מלאה במקום הקיימת) / ops: [{op:'add', at, step} | {op:'remove', step} | {op:'edit', step, set} | {op:'move', step, to}]
  //        step = מזהה / מספר (1-based) / שם. at / to = מיקום (1-based) ברשימה אחרי הפעולות הקודמות
  function resolveStep(steps, ref) {
    if (ref == null) return -1; const s = String(ref).trim();
    const byId = steps.findIndex(x => x.id === s); if (byId >= 0) return byId;
    const num = /^#?(\d{1,4})$/.exec(s); if (num) { const i = Number(num[1]) - 1; return i >= 0 && i < steps.length ? i : -1; }
    return steps.findIndex(x => x.name === s);
  }
  function updateFlow(id, patch = {}, opts = {}) {
    const base = getFlow(id); if (!base) { const e = new Error('התזרים לא נמצא'); e.status = 404; throw e; }
    if (isLocked(base.id)) { noteBlocked(base.id, { by: opts.by || 'tool', what: 'ניסיון לערוך תזרים נעול', tool: opts.tool }); throw lockedErr(base.id, 'לערוך'); }
    const next = JSON.parse(JSON.stringify(base));
    for (const k of ['name', 'description', 'enabled', 'guard', 'schedule', 'researchQuota']) if (has(patch, k) && patch[k] !== undefined) next[k] = patch[k];
    for (const k of LIMIT_KEYS) if (has(patch, k) && patch[k] !== undefined) next[k] = patch[k];
    if (Array.isArray(patch.steps)) next.steps = patch.steps;
    const notes = [];
    const ops = Array.isArray(patch.ops) ? patch.ops : [];
    for (const [n, op] of ops.entries()) {
      const steps = next.steps; const kind = op && op.op;
      const bad = m => { const e = new Error(`פעולה ${n + 1} (${kind || '?'}): ${m}`); e.status = 400; throw e; };
      if (kind === 'add') {
        const at = op.at == null ? steps.length + 1 : Number(op.at); if (!Number.isFinite(at) || at < 1 || at > steps.length + 1) bad('מיקום לא תקין (1 עד ' + (steps.length + 1) + ')');
        const st = { ...(op.step || {}) }; if (st.id && steps.some(x => x.id === st.id)) delete st.id;
        if (!st.id) { let k = steps.length + 1; while (steps.some(x => x.id === 's' + k)) k++; st.id = 's' + k; }
        steps.splice(at - 1, 0, st); notes.push(`נוסף שלב «${st.name || st.id}» במקום ${at}`);
      } else if (kind === 'remove') {
        const i = resolveStep(steps, op.step); if (i < 0) bad('השלב לא נמצא: ' + op.step);
        const gone = steps[i].id; notes.push(`הוסר שלב «${steps[i].name}»`); steps.splice(i, 1);
        for (const s of steps) if (s.on) for (const k of ['ok', 'fail', 'timeout']) if (s.on[k] === gone) s.on[k] = k === 'ok' ? 'next' : 'stop';
      } else if (kind === 'edit') {
        const i = resolveStep(steps, op.step); if (i < 0) bad('השלב לא נמצא: ' + op.step);
        const set = op.set || {}; const s = steps[i];
        for (const [k, v] of Object.entries(set)) { if (k === 'id') continue; if (k === 'check' || k === 'on') s[k] = { ...(s[k] || {}), ...(v || {}) }; else s[k] = v; }
        notes.push(`עודכן שלב ${i + 1} «${s.name}»`);
      } else if (kind === 'move') {
        const i = resolveStep(steps, op.step); if (i < 0) bad('השלב לא נמצא: ' + op.step);
        const to = Number(op.to); if (!Number.isFinite(to) || to < 1 || to > steps.length) bad('מיקום יעד לא תקין');
        const [s] = steps.splice(i, 1); steps.splice(to - 1, 0, s); notes.push(`שלב «${s.name}» הועבר למקום ${to}`);
      } else bad('פעולה לא מוכרת (add / remove / edit / move)');
    }
    const saved = saveFlow(next, base.id, opts);
    return { flow: saved, notes };
  }

  // ---------- הרצת פקודת מעטפת ----------
  function runShell(command, { cwd, timeoutMs, signal, procs }) {
    return new Promise(resolve => {
      let out = '', done = false, timedOut = false;
      // 🔒 פקודה של תזרים שמנסה לשנות / לעקוף נעילה של תזרים (קובצי התזרימים, ביטול נעילה, הפעלה מחדש) — לא מורצת
      if (deps.commandGate) { let why = null; try { why = deps.commandGate(String(command || '')); } catch { } if (why) return resolve({ code: -1, out: '🔒 ' + why, timedOut: false, blocked: true }); }
      let p;
      try { p = spawn(command, { shell: true, cwd: cwd || undefined, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] }); }
      catch (e) { return resolve({ code: -1, out: 'spawn failed: ' + e.message, timedOut: false }); }
      if (procs) procs.add(p);
      const add = d => { out = (out + d).slice(-12000); };
      p.stdout.on('data', add); p.stderr.on('data', add);
      const fin = (code) => { if (done) return; done = true; clearTimeout(t); if (procs) procs.delete(p); signal && signal.removeEventListener('abort', onAbort); resolve({ code, out: out.trim(), timedOut }); };
      const kill = () => { try { killTree ? killTree(p) : p.kill(); } catch { } };
      const t = setTimeout(() => { timedOut = true; kill(); setTimeout(() => fin(-1), 1500); }, timeoutMs || 600000);
      const onAbort = () => { kill(); setTimeout(() => fin(-2), 500); };
      if (signal) { if (signal.aborted) onAbort(); else signal.addEventListener('abort', onAbort); }
      p.on('error', e => { out += '\n' + e.message; fin(-1); });
      p.on('close', code => fin(code == null ? -1 : code));
    });
  }
  const sleep = (ms, signal) => new Promise(res => { const t = setTimeout(res, ms); if (signal) signal.addEventListener('abort', () => { clearTimeout(t); res(); }, { once: true }); });

  // ---------- בדיקת תוצאה ----------
  async function evalCheck(check, { text, cwd, signal, procs }) {
    if (!check || check.type === 'none') return { ok: true, why: '' };
    const v = check.value || '';
    if (check.type === 'contains') return text.toLowerCase().includes(v.toLowerCase()) ? { ok: true, why: `נמצא "${v}"` } : { ok: false, why: `לא נמצא "${v}" בתשובה` };
    if (check.type === 'not_contains') return !text.toLowerCase().includes(v.toLowerCase()) ? { ok: true, why: `לא נמצא "${v}"` } : { ok: false, why: `נמצא "${v}" בתשובה` };
    if (check.type === 'command') {
      const r = await runShell(v, { cwd, timeoutMs: 180000, signal, procs });
      return { ok: r.code === 0, why: `בדיקת פקודה יצאה עם קוד ${r.code}${r.timedOut ? ' (תם הזמן)' : ''}: ${r.out.slice(-300)}` };
    }
    if (check.type === 'judge') {
      try {
        const ans = await oneShot(`You are a strict verifier. Criteria for success:\n${v}\n\nThe assistant's final report for this step:\n"""\n${text.slice(-6000)}\n"""\n\nDid the step meet the criteria, judged ONLY by the report? Answer on the first line with exactly PASS or FAIL, then one short line (Hebrew) explaining why.`, { model: 'haiku', maxTokens: 120 });
        const ok = /^\s*PASS\b/i.test(ans);
        return { ok, why: 'שופט: ' + ans.replace(/\s+/g, ' ').slice(0, 240) };
      } catch (e) { return { ok: false, why: 'השופט נכשל: ' + e.message }; }
    }
    return { ok: true, why: '' };
  }

  // ---------- הרצה ----------
  // text = תקציר (תאימות לאחור), body = התוכן המלא של התוצאה (תשובת Claude / פלט הפקודה), why = שורת הבדיקה
  const log = (run, kind, o = {}) => {
    const e = { ts: now(), kind, ...o, text: o.text != null ? str(o.text, 700) : undefined };
    if (o.body != null) e.body = str(o.body, 6000); if (o.why != null) e.why = str(o.why, 400);
    run.log.push(e); if (run.log.length > 500) { run.log.splice(0, run.log.length - 500); run.logTrimmed = (run.logTrimmed || 0) + 1; }
    saveRun(run);
  };

  function preamble(run, step, no, total) {
    const ck = step.check && step.check.type !== 'none' ? ` After you finish, the engine will verify it (${step.check.type}: ${step.check.value.slice(0, 200)}).` : '';
    const al = step.allow && step.allow.length ? step.allow : ((run.guard || 'steps') === 'strict' ? ['read'] : null);
    const hook = al && (run.guard || 'steps') !== 'off' ? ` HOOK ENFORCEMENT: a hook checks EVERY tool call you make. In this step ONLY these tool groups are allowed: ${al.join(', ')}. Any other tool call is blocked by the hook and logged, so do not attempt it. Do nothing outside this step.` : '';
    return `[FLOW "${run.flowName}" — step ${no}/${total}: "${step.name}"]${hook} You are being driven by an automated flow engine. Do ONLY this step, exactly as written. Do not start other steps or skip ahead: the engine decides what happens next from the result. You must finish within ${step.timeoutMin} minutes or the engine stops you.${ck} If something fails, say plainly what failed. End with a short summary of the result, in the user's language.` + (step.type === 'research' ? ' This is a RESEARCH step: search the web (WebSearch/WebFetch), cross-check sources, and write down clear numbered conclusions and what to try next.' : '');
  }

  // תוצאה של שלב: outcome = ok | fail | timeout | stopped, ו-transient=true = תקלה זמנית (השלב ירוץ שוב אחרי המתנה, לא ניתוב)
  async function execStep(run, step, ctx) {
    const { signal, procs } = ctx;
    const timeoutMs = (step.timeoutMin || 0) * 60000;
    const cwd = ctx.cwd;
    if (step.type === 'wait') {
      log(run, 'info', { stepId: step.id, text: `ממתין ${step.waitSec} שניות` });
      const t0 = now(); await sleep(step.waitSec * 1000, signal);
      return signal.aborted ? { outcome: 'stopped', text: '' } : { outcome: 'ok', text: `חיכה ${Math.round((now() - t0) / 1000)} שניות`, why: `חיכה ${Math.round((now() - t0) / 1000)} שניות` };
    }
    if (step.type === 'command') {
      const r = await runShell(step.command, { cwd, timeoutMs, signal, procs });
      if (signal.aborted) return { outcome: 'stopped', text: r.out, body: r.out };
      if (/^spawn failed/.test(r.out)) return { outcome: 'error', transient: true, text: r.out, why: 'הפקודה לא הופעלה (תקלה זמנית)' };
      if (r.timedOut) return { outcome: 'timeout', text: r.out, why: 'הפקודה לא הסתיימה בזמן', body: tailText(r.out, 6000) };
      let ok = r.code === 0; let why = `קוד יציאה ${r.code}`;
      if (ok && step.check && step.check.type !== 'none') { const c = await evalCheck(step.check, { text: r.out, cwd, signal, procs }); ok = c.ok; why += ' · ' + c.why; }
      return { outcome: ok ? 'ok' : 'fail', text: `${why}\n${r.out.slice(-1200)}`, why, body: tailText(r.out, 6000) };
    }
    if (step.type === 'watch') {
      const t0 = now(); let n = 0, last = '';
      while (!signal.aborted && now() - t0 < timeoutMs) {
        n++;
        const r = await runShell(step.command, { cwd, timeoutMs: Math.min(120000, Math.max(5000, timeoutMs - (now() - t0))), signal, procs });
        last = `ניסיון ${n}: קוד ${r.code}\n${r.out.slice(-600)}`;
        let ok = r.code === 0;
        if (ok && step.check && step.check.type !== 'none') ok = (await evalCheck(step.check, { text: r.out, cwd, signal, procs })).ok;
        if (ok) return { outcome: 'ok', text: last, why: `הצליח בניסיון ${n}`, body: last.split('\n').slice(1).join('\n') };
        log(run, 'info', { stepId: step.id, text: last.split('\n')[0] + ' — עדיין לא' });
        await sleep(step.everySec * 1000, signal);
      }
      return signal.aborted ? { outcome: 'stopped', text: last } : { outcome: 'timeout', text: last, why: `לא הצליח תוך ${step.timeoutMin} דק׳ (${n} ניסיונות)`, body: last };
    }
    // task / research — Claude עובד בשיחה
    let convId = run.convId;
    if (step.chat) { const c = findChatByCode(step.chat); if (c) convId = c.id; else return { outcome: 'fail', text: `השיחה ${step.chat} לא נמצאה`, why: `השיחה ${step.chat} לא נמצאה` }; }
    const conv = getChat(convId); if (!conv) return { outcome: 'fail', text: 'השיחה של התזרים נמחקה', why: 'השיחה של התזרים נמחקה' };
    const total = run.steps.length;
    // החלפת שרת חמה (HOT-UPDATE): השלב כבר נשלח לפני ההחלפה, ו-Claude שלו ממשיך לרוץ (אומץ מתהליך המארח) — לא שולחים שוב
    // (שליחה חוזרת = אותה הנחיה פעמיים). מחכים לתשובה של התור שאומץ, מההודעה של השלב והלאה
    const adopted = ctx.resumed && deps.continuedTurn && deps.continuedTurn(convId) ? lastFlowMessage(getChat(convId), run, step) : -1;
    if (adopted >= 0) {
      log(run, 'info', { stepId: step.id, text: 'השרת הוחלף באמצע השלב — Claude ממשיך את אותו תור (לא נשלח שוב)' });
      return finishTask(convId, adopted, step, signal, procs, cwd, timeoutMs);
    }
    // אם בשיחה כבר רץ משהו — מחכים שיסתיים (בתוך זמן השלב). שיחה תפוסה כל הזמן = תקלה זמנית
    const idle = await waitTurn(convId, { timeoutMs, idleMs: 0, signal, onlyWaitIdle: true });
    if (signal.aborted) return { outcome: 'stopped', text: '' };
    if (idle.timedOut) return { outcome: 'error', transient: true, text: 'השיחה הייתה תפוסה כל זמן השלב', why: 'השיחה הייתה תפוסה כל זמן השלב' };
    const before = getChat(convId).messages.length;
    const meta = { runId: run.id, flowId: run.flowId, flowName: run.flowName, stepId: step.id, stepName: step.name, no: run.stepNo, total };
    const text = (step.type === 'research' ? '🔎 ' : '') + step.prompt;
    await sendToChat(convId, text, { hidden: preamble(run, step, run.stepNo, total), flow: meta, from: 'flow' });
    return finishTask(convId, before, step, signal, procs, cwd, timeoutMs);
  }
  // ההודעה האחרונה של המשתמש בשיחה — אם היא ההודעה של השלב הזה בהרצה הזו: האינדקס שלה, אחרת -1
  function lastFlowMessage(conv, run, step) {
    const msgs = (conv && conv.messages) || [];
    for (let i = msgs.length - 1; i >= 0; i--) {
      const m = msgs[i]; if (!m || m.role !== 'user') continue;
      return m.flow && m.flow.runId === run.id && m.flow.stepId === step.id ? i : -1;
    }
    return -1;
  }
  // מחכים לסוף התור של Claude (מההודעה before והלאה) ובודקים את התוצאה
  async function finishTask(convId, before, step, signal, procs, cwd, timeoutMs) {
    const w = await waitTurn(convId, { timeoutMs, idleMs: (step.idleMin || 0) * 60000, signal, since: before });
    if (signal.aborted) { stopChat(convId); return { outcome: 'stopped', text: w.text || '' }; }
    const reply = String(w.text || '');
    // Claude תקוע (לא זז) / התור קרס / שגיאת API — תקלה זמנית: השלב ירוץ שוב. סירוב של מסנן הבטיחות = כשל רגיל (ניסיון חוזר לא ישנה)
    if (w.timedOut && w.stalled) return { outcome: 'error', transient: true, text: (w.reason || 'Claude תקוע') + (reply ? '\n' + tailText(reply, 600) : ''), why: w.reason || 'Claude תקוע' };
    if (w.timedOut) return { outcome: 'timeout', text: (w.reason || 'עבר הזמן') + (reply ? '\n' + reply.slice(-600) : ''), why: w.reason || 'עבר הזמן', body: tailText(reply, 6000) };
    if (w.error) return { outcome: 'error', transient: true, text: 'שגיאה: ' + w.error, why: 'התור של Claude נכשל: ' + String(w.error).slice(0, 200) };
    if (/^\s*API Error/i.test(reply) && !REFUSAL_RE.test(reply)) return { outcome: 'error', transient: true, text: reply.slice(0, 600), why: 'שגיאת API: ' + reply.trim().split('\n')[0].slice(0, 200) };
    const c = await evalCheck(step.check, { text: reply, cwd: chatDir(convId) || cwd, signal, procs });
    return { outcome: c.ok ? 'ok' : 'fail', text: (c.why ? c.why + '\n' : '') + reply.slice(-700), why: c.why || (c.ok ? 'הושלם' : 'נכשל'), body: tailText(reply, 6000), _before: before };
  }

  // הרצה: resume=true = המשך הרצה שנקטעה (השרת הופעל מחדש) מהשלב שבו היא הייתה
  async function execute(run, { resume = false } = {}) {
    const a = active.get(run.id); const { signal } = a.abort;
    const t0 = run.startedAt;
    const L = run.limits || {};
    let idx = resume ? Math.max(0, Number(run.stepIdx) || 0) : 0; const steps = run.steps;
    let skipVisit = resume && !!run.stepId; // השלב שנקטע כבר נספר כביקור
    let resumedStep = resume && run.stepId ? run.stepId : null; // השלב שנקטע — בניסיון הראשון אחרי ההמשך הוא אולי עדיין רץ (החלפה חמה)
    let ended = false;
    // השרת נסגר (suspend): ההרצה לא מסתיימת ולא עוברת שלב — נשארת "רצה" על הדיסק
    const finish = (status, reason) => { if (a.suspend || suspended) return suspend(); if (ended) return; ended = true; run.status = status; run.reason = reason || ''; run.endedAt = now(); run.stepId = null; run.retryAt = null; log(run, 'end', { text: `${status}: ${reason || ''}` }); active.delete(run.id); emitEv('flow_run_end', summary(run)); };
    // נקטע כי השרת נסגר: ההרצה נשארת "רצה" בקובץ וממשיכה כשהשרת עולה
    const suspend = () => { if (ended) return; ended = true; run.retryAt = null; log(run, 'info', { stepId: run.stepId || undefined, text: 'השרת נסגר — ההרצה תמשיך מהשלב הזה כשהשרת יעלה שוב' }); active.delete(run.id); };
    const aborted = () => ((a.suspend || suspended) ? (suspend(), true) : signal.aborted ? (finish('stopped', run.stopReason || 'נעצר'), true) : false);
    const overTime = () => L.maxMinutes && now() - t0 > L.maxMinutes * 60000;
    let crash = 0; // חריגות בשרת מחוץ לשלב — גם הן לא מפרקות את התזרים
    for (;;) {
      try {
        if (!run.convId || !getChat(run.convId)) {
          // יעד ההרצה: שיחה קיימת, או שיחה חדשה בתוך הפרויקט (בהמשך הרצה — השיחה שכבר נפתחה לה)
          let projectId = null;
          if (run.scope.type === 'chat') {
            const c = getChat(run.scope.id); if (!c) return finish('failed', 'השיחה של התזרים לא נמצאה');
            run.convId = c.id; projectId = c.projectId || null;
          } else {
            projectId = run.scope.id;
            const c = createChat({ projectId, title: '⚙ ' + run.flowName });
            if (!c) return finish('failed', 'הפרויקט לא נמצא');
            run.convId = c.id;
          }
          run.projectId = projectId; saveRun(run);
        }
        const cwd = chatDir(run.convId) || (run.projectId && projectDir(run.projectId)) || process.cwd();
        for (;;) {
          if (aborted()) return;
          if (overTime()) return finish('timeout', `עבר הזמן הכולל שהגדרת (${L.maxMinutes} דקות)`);
          if (L.maxSteps && run.stepNo >= L.maxSteps) return finish('failed', `הגעת למגבלת ${L.maxSteps} שלבים שהגדרת`);
          if (idx < 0 || idx >= steps.length) return finish('done', 'כל השלבים הסתיימו');
          const step = steps[idx];
          if (!skipVisit) run.visits[step.id] = (run.visits[step.id] || 0) + 1;
          skipVisit = false;
          if (L.maxVisits && run.visits[step.id] > L.maxVisits) return finish('failed', `השלב "${step.name}" חזר יותר מ-${L.maxVisits} פעמים (המגבלה שהגדרת) — הלולאה נעצרה`);
          let attempt = 0, transient = 0, res;
          for (;;) {
            run.stepNo++; run.stepId = step.id; run.stepIdx = idx; attempt++;
            log(run, 'step', { stepId: step.id, name: step.name, no: run.stepNo, attempt, visit: run.visits[step.id], text: `מתחיל שלב ${idx + 1}/${steps.length} "${step.name}"` + (attempt > 1 ? ` (ניסיון ${attempt})` : '') + (transient ? ` (אחרי תקלה זמנית ${transient})` : '') });
            const resumed = resumedStep === step.id && attempt === 1 && !transient; resumedStep = null;
            try { res = await execStep(run, step, { signal, procs: a.procs, cwd, resumed }); }
            catch (e) { console.error('[flows] step error', e && e.message); res = { outcome: 'error', transient: true, text: 'חריגה בשרת: ' + (e && e.message), why: 'חריגה בשרת: ' + (e && e.message) }; }
            if (aborted()) return;
            if (res.transient) {
              transient++; run.transientTotal = (run.transientTotal || 0) + 1; attempt--; // תקלה זמנית לא נחשבת לניסיון של הבעלים (retries)
              const waitMs = backoff(transient);
              log(run, 'result', { stepId: step.id, name: step.name, outcome: 'error', transient: true, text: res.text, why: res.why, body: res.body });
              log(run, 'retry', { stepId: step.id, waitMs, n: transient, text: `תקלה זמנית (${str(res.why || res.text, 120).split('\n')[0]}) — השלב ירוץ שוב בעוד ${Math.round(waitMs / 100) / 10} שנ׳ (תקלה ${transient})` });
              run.retryAt = now() + waitMs; saveRun(run);
              await sleep(waitMs, signal); run.retryAt = null;
              if (aborted()) return;
              if (overTime()) return finish('timeout', `עבר הזמן הכולל שהגדרת (${L.maxMinutes} דקות)`);
              continue;
            }
            log(run, 'result', { stepId: step.id, name: step.name, outcome: res.outcome, text: res.text, why: res.why, body: res.body });
            if (res.outcome !== 'ok' && attempt <= (step.retries || 0)) { log(run, 'info', { stepId: step.id, text: `נכשל — ניסיון חוזר ${attempt}/${step.retries}` }); continue; }
            break;
          }
          crash = 0;
          const route = step.on[res.outcome === 'ok' ? 'ok' : res.outcome === 'timeout' ? 'timeout' : 'fail'] || (res.outcome === 'ok' ? 'next' : 'stop');
          if (route === 'stop') return finish(res.outcome === 'timeout' ? 'timeout' : 'failed', `שלב "${step.name}" ${res.outcome === 'timeout' ? 'לא הסתיים בזמן' : 'נכשל'} — המעבר שהוגדר: עצירה` + (res.why || res.text ? ' — ' + String(res.why || res.text).split('\n')[0].slice(0, 160) : ''));
          if (route === 'end') return finish('done', `הסתיים בשלב "${step.name}" (${res.outcome})`);
          if (route === 'next') idx++;
          else { const j = steps.findIndex(s => s.id === route); if (j < 0) return finish('failed', 'מעבר לשלב שלא קיים'); log(run, 'info', { stepId: step.id, text: `${res.outcome} ← קופץ לשלב "${steps[j].name}"` }); idx = j; }
        }
      } catch (e) {
        // חריגה בשרת (שמירה לקובץ / יצירת שיחה / באג) — לא מסיימים את ההרצה: ממתינים וממשיכים מאותו שלב
        console.error('[flows]', e);
        crash++; run.transientTotal = (run.transientTotal || 0) + 1;
        const waitMs = backoff(crash);
        try { run.log.push({ ts: now(), kind: 'retry', stepId: run.stepId || undefined, waitMs, n: crash, text: `חריגה בשרת (${str(e && e.message, 160)}) — ממשיך בעוד ${Math.round(waitMs / 100) / 10} שנ׳` }); run.retryAt = now() + waitMs; saveRun(run); } catch { }
        skipVisit = true;
        await sleep(waitMs, signal); run.retryAt = null;
        if (aborted()) return;
      }
    }
  }

  // ההוק של Claude Code (PreToolUse) קורא לכאן לכל כלי: מותר / חסום. מחוץ לתזרים — אין התערבות. בתוך תזרים רץ: רק מה שהשלב הנוכחי מתיר
  function gate(convId, toolName, input) {
    let run = null; for (const a of active.values()) if (a.run.convId === convId && a.run.status === 'running') run = a.run;
    if (!run) return null;
    const guard = run.guard || 'steps';
    if (guard === 'off') return null;
    const step = run.steps[run.stepIdx];
    const label = step ? `שלב ${run.stepIdx + 1}/${run.steps.length} "${step.name}"` : 'בין שלבים';
    const claudeStep = step && (step.type === 'task' || step.type === 'research');
    const allow = step && step.allow && step.allow.length ? step.allow : (guard === 'strict' ? ['read'] : null);
    let ok = true, why = '';
    // 🔬 מחקר עמוק (research_start): מותר בכל שלב של Claude, לפי מכסה קבועה — N איטרציות עם מחקר, ואז 2N איטרציות בלי.
    // איטרציה = הרצת שלב (run.stepNo). מחקר אחד לכל היותר באיטרציה. בתקופת ההמתנה: רק חיפוש רגיל ברשת (WebSearch / WebFetch).
    if (/^mcp__claudechat__research_(status|read)$/.test(toolName) && claudeStep) return { allow: true, silent: true };
    if (toolName === 'mcp__claudechat__research_start' && claudeStep) {
      const N = [1, 2, 3].includes(run.researchQuota) ? run.researchQuota : 1;
      const rq = run.rq || (run.rq = { used: 0, cooldownUntil: 0, lastIter: 0 });
      const it = run.stepNo || 0;
      if (it <= rq.cooldownUntil) { ok = false; why = `🔬 מגבלת מחקר בתזרים "${run.flowName}": אחרי ${N} איטרציות עם מחקר עמוק חובה ${2 * N} איטרציות בלי מחקר. אפשר שוב מאיטרציה ${rq.cooldownUntil + 1} (עכשיו ${it}). בינתיים: עצור, הבן מה הבעיה, והשתמש רק בחיפוש רגיל ברשת (WebSearch / WebFetch).`; }
      else if (rq.lastIter === it) { ok = false; why = `🔬 כבר הופעל מחקר עמוק באיטרציה הזו (${it}) — מחקר אחד לכל היותר באיטרציה. חכה לתוצאה שלו (research_status / research_read).`; }
      else { rq.lastIter = it; rq.used++; if (rq.used >= N) { rq.cooldownUntil = it + 2 * N; rq.used = 0; } }
      log(run, 'info', { stepId: step && step.id, text: (ok ? '🔬 מחקר עמוק אושר (איטרציה ' + it + ', מכסה ' + N + '/' + 2 * N + ')' : '🔒 מחקר נחסם: ' + why) });
      saveRun && saveRun(run);
      return ok ? { allow: true } : { allow: false, reason: why };
    }
    if (!claudeStep) { ok = false; why = `התזרים "${run.flowName}" רץ כרגע ב${step ? 'שלב שאינו של Claude (' + step.type + ')' : 'מעבר בין שלבים'} — Claude לא פועל עכשיו.`; }
    else if (allow && !toolAllowed(allow, toolName)) { ok = false; why = `התזרים "${run.flowName}" ב${label} מתיר רק: ${allow.map(m => (CATEGORIES[m] ? CATEGORIES[m].label : m)).join(', ')}. הכלי ${toolName} חסום. בצע רק את מה שהשלב דורש, בכלים המותרים.`; }
    if (!allow && ok) return { allow: true, silent: true }; // תזרים בלי רשימת כלים לשלב: לא מתערבים ולא מציפים את היומן
    log(run, 'info', { stepId: step && step.id, text: (ok ? '✅ ' : '🔒 נחסם: ') + toolName + (briefInput(input) ? ' — ' + briefInput(input) : '') });
    return ok ? { allow: true } : { allow: false, reason: why };
  }

  function start(flowId, { trigger = 'manual', convId } = {}) {
    const flow = getFlow(flowId); if (!flow) { const e = new Error('התזרים לא נמצא'); e.status = 404; throw e; }
    for (const a of active.values()) if (a.run.flowId === flowId) { const e = new Error('התזרים כבר רץ'); e.status = 409; throw e; }
    const scope = convId ? { type: 'chat', id: convId } : flow.scope;
    const run = {
      id: crypto.randomUUID(), flowId, flowName: flow.name, status: 'running', reason: '', startedAt: now(), endedAt: null, trigger,
      scope, convId: null, projectId: null, stepId: null, stepIdx: 0, stepNo: 0, visits: {}, researchQuota: flow.researchQuota || 1, rq: { used: 0, cooldownUntil: 0, lastIter: 0 }, guard: flow.guard || 'steps', steps: JSON.parse(JSON.stringify(flow.steps)),
      limits: { maxSteps: flow.maxSteps, maxMinutes: flow.maxMinutes, maxVisits: flow.maxVisits }, limitsV: LIMITS_V, log: []
    };
    active.set(run.id, { run, abort: new AbortController(), procs: new Set() });
    log(run, 'start', { text: `תזרים "${flow.name}" התחיל (${trigger})` });
    execute(run);
    return run;
  }
  function stopRun(runId, reason) {
    const a = active.get(runId); if (!a) return false;
    a.run.stopReason = reason || 'נעצר על ידי המשתמש'; a.abort.abort();
    for (const p of a.procs) { try { killTree ? killTree(p) : p.kill(); } catch { } }
    if (a.run.convId) { try { stopChat(a.run.convId); } catch { } }
    return true;
  }
  const activeRuns = () => [...active.values()].map(a => a.run);
  const runOfFlow = flowId => { for (const a of active.values()) if (lk(a.run.flowId) === lk(flowId)) return a.run; return null; };

  // ---------- תזמון ----------
  function tick() {
    const t = now(); const d = new Date(t);
    const day = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    for (const f of listFlows()) {
      if (!f.enabled || !f.schedule || f.schedule.mode === 'none') continue;
      const s = f.schedule; let fire = false;
      if (s.mode === 'at') { if (!s.done && t >= s.at) { fire = true; s.done = true; } }
      else if (s.mode === 'every') { if (t >= s.nextAt) { fire = true; s.nextAt = t + s.everyMin * 60000; } }
      else if (s.mode === 'daily') { const hm = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); if (hm >= s.time && s.lastDay !== day) { fire = true; s.lastDay = day; } }
      if (!fire) continue;
      try { writeJson(flowFile(f.id), f); const L = locks[lk(f.id)]; if (L) { L.snapshot = JSON.parse(JSON.stringify(f)); L.hash = hashOf(f); saveLocks(); } } catch { } // מצב התזמון של תזרים נעול = של המנוע, לא עריכה: העותק הנעול מתעדכן
      try { start(f.id, { trigger: 'schedule' }); } catch (e) { if (e.status !== 409) console.error('[flows] schedule', e.message); }
    }
  }
  let timer = null, resumeT = null, suspended = false;
  // מפעיל את התזמון, וממשיך הרצות שנקטעו כשהשרת נסגר (אחרי שהשרת סיים לעלות)
  function startScheduler(ms = 10000) {
    if (suspended) return;
    if (!timer) { timer = setInterval(tick, ms); timer.unref && timer.unref(); }
    // ממשיכים רק אחרי שהשרת אימץ את התורים שרצו בתהליך המארח (deps.ready) — כדי ששלב שעדיין רץ לא יישלח שוב
    if (!resumeT && pendingResume.length) {
      resumeT = setTimeout(() => {
        Promise.resolve().then(() => deps.ready && deps.ready()).catch(e => console.error('[flows] ready', e && e.message))
          .then(() => { resumeT = null; if (!suspended) resumeInterrupted(); });
      }, deps.resumeDelayMs != null ? deps.resumeDelayMs : 1500);
    }
  }
  // השרת נסגר / מתנתק (abort-all / detach מהתהליך הראשי — HOT-UPDATE-PLAN 0.1b): המתזמן עוצר, ושום הרצה לא מסתיימת ולא עוברת שלב —
  // השלב הנוכחי לא נקטע מכאן (התהליך הראשי עוצר את הריצות), וכשהוא חוזר ההרצה נשארת "רצה" על הדיסק וממשיכה בעלייה הבאה
  function suspendAll() {
    if (suspended) return; suspended = true;
    clearInterval(timer); timer = null; clearTimeout(resumeT); resumeT = null;
    for (const a of active.values()) a.suspend = true;
  }
  const isSuspended = () => suspended;
  // סגירת השרת: ההרצות לא "נעצרות" — הן נשמרות כרצות וממשיכות כשהשרת עולה שוב
  function shutdown() {
    verifyLocks(); // רשימת נעילות שנערכה מבחוץ לא "נטענת" בהפעלה הבאה
    clearInterval(timer); timer = null; clearTimeout(resumeT); resumeT = null; clearInterval(lockWatch);
    for (const a of [...active.values()]) { a.suspend = true; a.abort.abort(); for (const p of a.procs) { try { killTree ? killTree(p) : p.kill(); } catch { } } }
  }

  // הרצות שרצו כשהשרת נסגר: ממשיכות מהשלב שבו הן היו. הרצה פגומה (בלי שלבים / יעד) או של תזרים שנמחק — מסומנת כנעצרה
  const pendingResume = [];
  for (const r of listRuns({ limit: 500 })) {
    if (r.status !== 'running') continue;
    const okRun = Array.isArray(r.steps) && r.steps.length && r.scope && r.scope.id && r.flowId && fs.existsSync(flowFile(r.flowId));
    if (okRun) { pendingResume.push(r.id); continue; }
    r.status = 'stopped'; r.reason = 'השרת הופעל מחדש באמצע ההרצה (לא ניתן להמשיך: ' + (r.flowId && !fs.existsSync(flowFile(r.flowId)) ? 'התזרים נמחק' : 'ההרצה חסרה נתונים') + ')'; r.endedAt = now();
    try { writeJson(runFile(r.id), r); } catch { }
  }
  function resumeInterrupted() {
    const done = [];
    if (suspended) return done;
    while (pendingResume.length) {
      const rid = pendingResume.shift(); const r = readJson(runFile(rid));
      if (!r || r.status !== 'running' || active.has(rid)) continue;
      if (runOfFlow(r.flowId)) { r.status = 'stopped'; r.reason = 'הרצה אחרת של התזרים כבר רצה'; r.endedAt = now(); try { writeJson(runFile(r.id), r); } catch { } continue; }
      r.log = Array.isArray(r.log) ? r.log : []; r.visits = r.visits || {}; r.limits = r.limits || {};
      if (r.limitsV !== LIMITS_V) for (const k of LIMIT_KEYS) r.limits[k] = null; // הרצה מלפני v2: המגבלות לא נבחרו ע"י הבעלים → ללא הגבלה
      r.limitsV = LIMITS_V; r.resumed = (r.resumed || 0) + 1; r.retryAt = null;
      active.set(r.id, { run: r, abort: new AbortController(), procs: new Set() });
      const st = r.steps[Math.max(0, Number(r.stepIdx) || 0)];
      log(r, 'resume', { stepId: r.stepId || undefined, text: `השרת הופעל מחדש — ההרצה ממשיכה${st ? ` מהשלב "${st.name}"` : ''} (המשך ${r.resumed})` });
      execute(r, { resume: true });
      done.push(r.id);
    }
    return done;
  }

  return { listFlows, getFlow, saveFlow, updateFlow, removeFlow, setLock, isLocked, lockedIds, lockInfo, noteBlocked, normalize, start, stopRun, getRun, listRuns, activeRuns, runOfFlow, summary, tick, startScheduler, shutdown, suspend: suspendAll, isSuspended, resumeInterrupted, TERMINAL, runShell, gate, CATEGORIES, GUARDS };
}

// ---------- בנייה אוטומטית של תזרים מתיאור (Claude) ----------
const SPEC = `A flow is a JSON object: {"name": str, "description": str, "maxMinutes": number (OPTIONAL total time cap; omit = no limit), "maxVisits": int (OPTIONAL max times one step may repeat; omit = no limit), "steps": [ ... ]}. A flow has NO limits unless the user asked for one: a loop flow is meant to keep flowing forever until the user stops it.
Each step: {"name": short Hebrew name, "type": "task"|"research"|"command"|"watch"|"wait", ...}
 - task: {"prompt": instruction to Claude (Hebrew, one concrete action), "timeoutMin": int, "retries": int 0-5, "check": {"type":"none"|"contains"|"not_contains"|"command"|"judge","value": str}}
 - research: like task, Claude searches the web and writes numbered conclusions
 - command: {"command": shell command run on the computer (exit code 0 = success), "timeoutMin": int}
 - watch: {"command": ..., "everySec": int, "timeoutMin": int} repeats the command until it succeeds or the time runs out
 - wait: {"waitSec": int}
 Routing per step: "on": {"ok": X, "fail": X, "timeout": X} where X is "next" | "end" | "stop" | the NUMBER (1-based) of another step. Default ok=next, fail=stop, timeout=stop.
Use loops by routing back to an earlier step (a loop runs until the user stops it, unless the user asked for a limit). A good work loop: 1) try the task, check it (command test or judge) -> ok: end; fail: go to a research step -> then a "try again using the conclusions" task -> test -> fail: back to the research step. Every task/command step must have a realistic timeoutMin so nothing hangs.`;

function extractJson(text) {
  const s = String(text || ''); const a = s.indexOf('{'), b = s.lastIndexOf('}');
  if (a < 0 || b <= a) throw new Error('Claude לא החזיר תזרים');
  return JSON.parse(s.slice(a, b + 1));
}
async function generateFlowDraft(goal, { oneShot, scope, existingChatsHint }) {
  const prompt = `Design an automation flow for this goal (the user's words, Hebrew):\n"""${goal}"""\n\n${SPEC}\n${existingChatsHint || ''}\nOutput ONLY the JSON object, no explanation, no code fence.`;
  const out = await oneShot(prompt, { model: 'sonnet', maxTokens: 3000, timeoutMs: 120000, system: 'You design precise automation flows and output only valid JSON.' });
  const j = extractJson(out);
  return { ...j, scope };
}

module.exports = { createFlows, generateFlowDraft, SPEC, STEP_TYPES, CHECK_TYPES, TERMINAL };
