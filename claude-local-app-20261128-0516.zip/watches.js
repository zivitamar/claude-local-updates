'use strict';
// ============================================================
//  מערכת מעקבים (Tasks): משימה קבועה שמעירה את Claude בשיחה כל X זמן ומחייבת אותו לבצע את מה שכתוב בפרומפט — לבדוק ולתקן.
//  כל מעקב: מזהה (W1, W2…), שם קצר, שיחה, פרומפט, כל כמה דקות, למשך כמה זמן (או ללא הגבלה), עצירה לפי מנוי (אופציונלי).
//  סבב שמגיע כש-Claude עסוק בשיחה — נכנס לתור של השיחה ורץ מיד אחרי (לא נבלע ולא נערם: סבב אחד בכל פעם).
//  נשמר ב-DATA_DIR/watches.json וממשיך אחרי הפעלה מחדש.
// ============================================================
const fs = require('fs'), path = require('path'), crypto = require('crypto');

const MAX_RUNS_KEPT = 300;
// שני הסטטוסים היחידים של סבב (הבעלים 25/11) — השורה האחרונה של Claude חייבת להיות בדיוק אחת מהן
const OK_LINE = 'סטטוס: תקין', BAD_LINE = 'סטטוס: לא תקין';
// אורך 'דקה' של המתזמן (רק לבדיקות אפשר לקצר: CLAUDE_WATCH_MINUTE_MS=2000)
const MINUTE_MS = Number(process.env.CLAUDE_WATCH_MINUTE_MS) || 60000;
const clip = (s, n) => { s = String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
const fmtDur = min => { if (min == null) return 'ללא הגבלה'; if (min % 1440 === 0) return (min / 1440) + ' ימים'; if (min % 60 === 0) return (min / 60) + ' שעות'; return min + ' דקות'; };
const fmtEvery = min => (min % 1440 === 0 ? (min / 1440 === 1 ? 'יום' : (min / 1440) + ' ימים') : min % 60 === 0 ? (min / 60 === 1 ? 'שעה' : (min / 60) + ' שעות') : (min === 1 ? 'דקה' : min + ' דקות'));

function createWatches({ dataDir, now = () => Date.now(), sendToChat, waitTurn, getConv, startShadow = null, endShadow = () => { }, audit = null, usageRemaining, onEvent = () => { }, log = () => { }, tickMs = 1000 }) {
  const FILE = path.join(dataDir, 'watches.json');
  let st = { seq: 0, watches: [] };
  try { const j = JSON.parse(fs.readFileSync(FILE, 'utf8')); if (j && Array.isArray(j.watches)) st = { seq: j.seq || 0, watches: j.watches }; } catch { }
  // סבב שרץ כשהשרת נסגר — מטופל ב-boot() (השרת קורא לה אחרי שהוא עלה). עד אז ה-tick לא מתחיל סבב: w.current מלא ו-w.fixing מדולג
  // סבבים שהיו "רצים" כשהקובץ נטען (מהתהליך הקודם) — רק בהם boot() מטפל; סבב שהתחיל בתהליך הזה לא נוגעים בו
  const loadedCurrent = new Map(st.watches.filter(w => w.current || w.fixing).map(w => [w.id, w.current || null]));
  let suspended = false, booted = false; // suspend(): השרת נסגר / מתנתק — לא רושמים תוצאה לסבב שנקטע (נשאר על הדיסק כמו שהוא)
  let saveT = null;
  const saveNow = () => { try { fs.mkdirSync(dataDir, { recursive: true }); fs.writeFileSync(FILE + '.tmp', JSON.stringify(st)); fs.renameSync(FILE + '.tmp', FILE); } catch (e) { log('[watches] save ' + e.message); } };
  const save = () => { clearTimeout(saveT); saveT = setTimeout(saveNow, 150); };
  const byId = id => st.watches.find(w => w.id === String(id || '').toUpperCase().replace(/^#/, '')) || null;
  const isActive = w => w.status === 'active' || w.status === 'paused';

  function summary(w) {
    const last = [...w.runs].reverse().find(r => r.status !== 'running') || null;
    return {
      id: w.id, name: w.name, convId: w.convId, prompt: w.prompt, everyMin: w.everyMin, durationMin: w.durationMin, stopAtRemainingPct: w.stopAtRemainingPct,
      status: w.status, createdAt: w.createdAt, endsAt: w.endsAt, nextRunAt: w.status === 'active' && !w.fixing ? w.nextRunAt : null, pausedAt: w.pausedAt || null, pausedRemainingMs: w.status === 'paused' ? (w.pausedRemainingMs != null ? w.pausedRemainingMs : null) : null,
      fixMode: w.fixMode !== false, fixing: w.fixing ? { n: w.fixing.n, since: w.fixing.since, bad: w.fixing.bad, total: w.fixing.total, attempts: w.fixing.attempts } : null,
      endedAt: w.endedAt || null, endReason: w.endReason || null, runCount: w.runCount, current: w.current || null, actionsInDock: !!w.actionsInDock, editedAt: w.editedAt || null,
      locked: !!w.locked, lockedAt: w.lockedAt || null, blocked: (w.blocked || []).slice(-5), blockedTotal: w.blockedTotal || (w.blocked || []).length, createdBy: w.createdBy || 'user',
      last: last ? { n: last.n, status: last.status, summary: last.summary, problem: last.problem || null, forced: !!last.forced, at: last.at, endedAt: last.endedAt, cause: last.cause || null, resumes: last.resumes || 0 } : null,
      resumes: (() => { const r = w.current ? w.runs.find(x => x.n === w.current) : null; return r && r.resumes ? { n: r.n, resumes: r.resumes, resumedAfter: r.resumedAfter || null } : null; })(),
      okCount: w.runs.filter(r => r.status === 'ok').length, warnCount: w.runs.filter(r => r.status !== 'ok' && r.status !== 'running').length, errCount: 0 // שני סטטוסים בלבד: תקין / לא תקין
    };
  }
  const full = w => ({ ...summary(w), runs: w.runs.slice(-100) });
  const emit = w => { try { onEvent('watch_update', summary(w)); } catch { } };

  // ----- טקסט הסבב: שורה קצרה גלויה + הוראות מלאות נסתרות ל-Claude -----
  function untilText(w) { return w.durationMin == null ? 'ללא הגבלת זמן' : 'עד ' + new Date(w.endsAt).toLocaleString('he-IL', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' }); }
  function rulesText(w, docked) {
    const base = `REPORT — full transparency: write the round report in the same language as the TASK. Put every item of the task on its own line: "✅ <item> — <the evidence you actually saw>" or "❌ <item> — <what is wrong>". A problem you found, fixed AND verified in this round is ✅ ("תוקן ואומת" + the evidence). Anything you could not check is ❌.
MARKS — each item's mark depends ONLY on that item's own value against the TASK's rule: ✅ when it meets the rule — even when other items fail and the status is ${BAD_LINE} — and ❌ only when it does not meet the rule or could not be checked. Never put ❌ on an item whose value meets the rule, never write words that say it is OK ("תקין", "התנאי מתקיים") on a ❌ line, and write every item exactly ONCE — no corrections inside the report (if you notice a mistake, write the whole list again cleanly).
FACTS — state only what a tool output in THIS round shows: no counts, quotes, "all N lines" or "appears nowhere" that you did not see in an output of this round, and nothing copied from an earlier report.
JUDGE BY THIS ROUND ONLY: check every item again now with a tool and judge it only by the value you see in THIS round against the TASK's own rule — never copy a ✅ from an earlier round. A value that changed since an earlier round is not a problem by itself, and an item that was ❌ before and is OK now is simply ✅. Do not add requirements the TASK does not state. An independent auditor (a separate model) reads the tool outputs of this round and checks every mark (✅ and ❌) and every fact in your report against them.
STATUS — an iron rule the app checks on every round: the LAST line of your answer must be EXACTLY one of these two lines, character for character, with nothing else on it (no emoji, no bold, no extra word, no comma, no period):
${OK_LINE}
${BAD_LINE}
If even ONE item is not OK (any ❌ or ⚠️) → ${BAD_LINE} — even if everything else is OK. ${OK_LINE} only when every item is ✅. The app rejects any other last line and any contradiction (a ❌/⚠️ with "תקין", or "תקין" without ✅ evidence); only this line decides the round's result and its sound.`;
    const prev = docked ? [...(w.runs || [])].reverse().find(r => r.status !== 'running' && r.reply) : null; // הסבבים הקודמים לא נמצאים בעותק — הדיווח האחרון נמסר כאן להמשכיות
    const where = docked ? `
This round runs in a SEPARATE session: a private copy of the chat, running in parallel to it. The user keeps talking with you in the chat itself, and does not see this round there — only in the watch window. Do the task by yourself, without asking the user anything (no questions, no AskUserQuestion); just report.${prev ? `
Your report from the previous round (${prev.n}) of this watch — HISTORY ONLY, for continuity (it is not evidence for this round; values may have changed since):
<<<
${prev.reply}
>>>` : ''}` : '';
    const ctl = w.locked
      ? `
🔒 The user LOCKED this watch (${w.id}) against changes: you may NOT stop, pause, resume or edit it — not with the watch tools, not through the app's HTTP API (curl / Invoke-RestMethod), not by MCP calls and not by editing files. If the user asks for a change, tell them to unlock it first (the 🔒 button in the watch window).`
      : `
The user may talk to you normally between rounds. If the user asks to stop / pause / resume this watch, use the tools mcp__claudechat__watch_stop / watch_pause / watch_resume with id ${w.id} (watch_list shows all watches). If the user asks to CHANGE it (the task text, how often, for how long, its name, the stop-at-% rule) use mcp__claudechat__watch_update with id ${w.id} — it keeps running with the new values.`;
    const fix = w.fixMode !== false ? `
🔧 FIX MODE is ON for this watch (the user's rule): if any item is not OK, the round does NOT end with a "not OK" report — fix every such item now and verify each fix with a tool output, then check all items again and report. The app will not let you finish with ${BAD_LINE} while something can still be fixed. Only an item that truly needs the user (a permission, a password, hardware, a purchase) may stay ❌ — say exactly what the user must do.` : '';
    return base + fix + where + ctl;
  }
  function roundTexts(w, n, docked) {
    const visible = `🔁 מעקב ${w.id} «${w.name}» · סבב ${n}`;
    const hidden = `[WATCH ${w.id} "${w.name}" — automatic round ${n} (every ${w.everyMin} min, ${w.durationMin == null ? 'no time limit' : 'until ' + new Date(w.endsAt).toISOString()}). This is not a new request: it is the standing task the user gave you, and the app wakes you to do it on schedule. You MUST do it now, fully.
TASK (exactly as the user defined it):
<<<
${w.prompt}
>>>
Do the whole task: check every item in it. If something is broken or not as required — fix it if you can (that is part of the task) and verify the fix.
${rulesText(w, docked)}]`;
    return { visible, hidden };
  }
  function creationHidden(w, docked) {
    return `[The user opened a WATCH (מעקב) on this message: id ${w.id}, name "${w.name}". The app will wake you automatically every ${w.everyMin} min, ${w.durationMin == null ? 'with no time limit (until the user stops it)' : 'for ' + fmtDur(w.durationMin) + ' (until ' + new Date(w.endsAt).toISOString() + ')'}${w.stopAtRemainingPct != null ? `, and it stops by itself when the subscription has ${w.stopAtRemainingPct}% or less left` : ''}. Each later round arrives as a short message "🔁 מעקב ${w.id} · סבב N" with the task.
This message is round 1: do the task in this message fully now — check every item, fix problems if you can, verify.
${rulesText(w, docked)}]`;
  }

  // ----- תוצאת סבב: התשובה של Claude אחרי הודעת הסבב -----
  // עד ההודעה הגלויה הבאה (הודעה שלך / סבב אחר). הערות נסתרות של האפליקציה באמצע (למשל "ההוראות השתנו") לא קוטעות את הסבב
  const turnStart = m => m && m.role === 'user' && Array.isArray(m.content) && m.content.some(b => b && b.type !== 'tool_result' && !(b.type === 'text' && b.hidden));
  // כל הטקסטים ש-Claude כתב בסבב (לפי הסדר): מההודעה של הסבב עד ההודעה הגלויה הבאה, ועוד כל "נדרשת שורת סטטוס" של אותו סבב (גם אם באה אחרי הודעה שלך)
  const sameRound = (m, id, n) => !!(m && m.role === 'user' && m.watch && m.watch.id === id && m.watch.n === n);
  function roundTextsOf(convId, id, n) {
    let conv; try { conv = getConv(convId); } catch { return []; }
    const msgs = conv.messages || [], out = []; let inSeg = false;
    for (const m of msgs) {
      if (sameRound(m, id, n)) { inSeg = true; continue; }
      if (turnStart(m)) { inSeg = false; continue; }
      if (inSeg && m.role === 'assistant') { const x = (m.content || []).filter(b => b.type === 'text' && !b.hidden).map(b => b.text).join('\n').trim(); if (x) out.push(x); }
    }
    return out;
  }
  function roundReply(convId, id, n) { const l = roundTextsOf(convId, id, n); return l[l.length - 1] || ''; }

  // ===== שורת הסטטוס — חוק ברזל (הבעלים 25/11) =====
  // בדיוק אחת משתי שורות, תו בתו, בלי שום תוספת (בלי אמוג'י, הדגשה, מילה, פסיק או נקודה): "סטטוס: תקין" / "סטטוס: לא תקין".
  // פריט אחד לא תקין = "לא תקין". "תקין" רק עם ראיות (✅) ובלי שום סימן תקלה / ניסוח של תקלה / פריט לא מסומן בדיווח האחרון — אחרת זה זיוף ונחסם.
  // Claude לא מסר שורה תקנית גם אחרי כל הבקשות / נכשל / נעצר / נתקע → האפליקציה קובעת "לא תקין" (עם הסיבה). כל סבב = אחד משני סטטוסים + ההקלטה שלו.
  const PROBLEM_RE = /❌|⚠|🔴|⛔|✖|✗|✘|✕|❎|🚫|🟥|🟠|🟧|🟡|❗|‼|⁉|❓|🛑|💥/;
  const OK_MARK_RE = /✅|☑️|✔️|✔/;
  // ניסוח של תקלה — מילה שלמה (בעברית: לא חלק ממילה אחרת, כמו "נפל" בתוך "נפלא"), ולא בתוך שלילה ("אין", "לא נמצאו", "0 failed")
  const HB = '(?<![\\u0590-\\u05FF])', HE = '(?![\\u0590-\\u05FF])';
  // כל צורות הנטייה (נקבה / רבים) ואותיות שימוש בתחילת המילה ("שנכשל", "והשרת נפל"); מילים נפוצות של תקלה (חורג, חסר, לא נמצא, פג תוקף, degraded, missing...)
  const NEG_PARTS = ['לא תקינ(?:ה|ים|ות)', 'לא תקין', 'לא עובד(?:ת|ים|ות)?', 'לא עונ(?:ה|ים|ות)', 'לא מגיב(?:ה|ים|ות)?', 'לא זמינ(?:ה|ים|ות)', 'לא זמין', 'לא פעיל(?:ה|ים|ות)?', 'לא רצ(?:ה|ים|ות)', 'לא רץ', 'לא נגיש(?:ה|ים|ות)?',
    'לא תוקנ(?:ה|ו)', 'לא תוקן', 'לא נמצא(?:ה|ו)?', 'לא קיימ(?:ת|ים|ות)', 'לא קיים', 'לא תואמ(?:ת|ים|ות)', 'לא תואם', 'לא נבדק(?:ה|ו)?', 'לא הצלחתי', 'לא בדקתי', 'דילגתי',
    'נכשל(?:ה|ו)?', 'קרס(?:ה|ו)?', 'נפל(?:ה|ו)?', 'תקוע(?:ה|ים|ות)?', 'שבור(?:ה|ים|ות)?', 'חורג(?:ת|ים|ות)?', 'חריגה', 'מעל הסף', 'חסר(?:ה|ים|ות)?', 'פג(?:ה)? (?:ה)?תוקפ(?:ו|ה)', 'פג(?:ה)? (?:ה)?תוקף', 'יש תקלה', 'יש שגיאה', 'שגיאה \\d+'];
  const NEG_HE_G = new RegExp(NEG_PARTS.map(p => HB + '[ובכלמשה]{0,2}(?:' + p + ')' + HE).join('|'), 'g');
  const NEG_EN_G = /\b(?:failed|failing|failure|broken|offline|unreachable|unresolved|unhealthy|degraded|expired|missing|mismatch(?:ed)?|exceed(?:s|ed|ing)?|above (?:the )?threshold|timed out|no such file|not found|crash(?:ed|ing)?|not (?:ok|working|responding|running|fixed|reachable)|does ?n[o']t work|is down|error \d{3})\b/gi;
  // שלילה — לכל התאמה בנפרד: מילת שלילה לפניה (צמודה, או עד 2 מילים לפניה בלי פסיק/נקודה ביניהן: "אין קבצים חסרים"),
  // או אפס אחריה ("failed=0", "Failed Devices : 0", "failed (0)")
  const NEG_BEFORE = /(?:^|[^\p{L}\p{N}])(?:אין|ללא|בלי|לא|אף|no|not|none|without|zero|never|did ?n[o']t|has ?n[o']t|have ?n[o']t|0)(?:\s+[\p{L}\p{N}]+){0,2}[\s:-]*$/iu;
  const ZERO_AFTER = /^[^\n.;:=]{0,24}[:=]\s*0(?![\d.,])|^\s*\(?0\)?(?![\d.,])/;
  const FIXED_RE = new RegExp(HB + '(?<!לא )(תוקן|תוקנה|תוקנו|תיקנתי)' + HE + '|(?<!not )\\b(fixed|resolved)\\b', 'i'); // "תוקן" — אבל לא "לא תוקן" / "not fixed"
  function negLine(l) {
    if (FIXED_RE.test(l) && !/לא תוקן|not fixed|unresolved/i.test(l)) return false;
    for (const re of [NEG_HE_G, NEG_EN_G]) { re.lastIndex = 0; let m; while ((m = re.exec(l))) { const i = m.index, before = l.slice(Math.max(0, i - 30), i), after = l.slice(i + m[0].length); if (/^לא /.test(m[0].replace(/^[ובכלמשה]{0,2}/, '')) ? false : NEG_BEFORE.test(before)) continue; if (ZERO_AFTER.test(after)) continue; return true; } }
    return false;
  }
  // ===== סימון שסותר את עצמו (הבעלים 25/11: "אני לא מוכן לחולשות") — נבדק בכל סבב, גם כשהסטטוס "לא תקין" =====
  // (א) שורה עם ❌ שאומרת שהפריט עומד בדרישה ("❌ disk.txt — 85%, מתחת ל-90%, תקין") · (ב) שורה עם ✅ וגם ❌
  // (ג) שורה עם ✅ שמתארת תקלה ("✅ app.log — נמצאה שורת ERROR ... נכשל") · (ד) אותו פריט פעמיים עם סימונים שונים (שתי רשימות / "תיקון" באמצע הדיווח)
  const X_MARK_RE = /❌|✖|✗|✘|✕|❎|🚫|🔴|⛔|🟥/;
  const PASS_PARTS = ['תקינ(?:ה|ים|ות)', 'תקין', 'התנאי (?:מתקיים|התקיים|נשמר)', 'הדרישה (?:מתקיימת|התקיימה)', 'מתקיים התנאי', 'עומד(?:ת|ים|ות)? (?:בתנאי|בדרישה|בדרישות|בכלל)', 'הסעיף עובר', 'הבדיקה עוברת', 'עובר(?:ת)? את הבדיקה', 'עבר(?:ה|ו)? בהצלחה'];
  // ✅ שמתאר תקלה: רק מילים חזקות של כישלון. "לא נמצא" / "לא קיים" / "חסר" בשורת ✅ הם בדרך כלל היעדר של תקלה ("לא נמצאה שורת ERROR") — לא נחשבים כאן
  const FAIL_PARTS = ['נכשל(?:ה|ו)?', 'קרס(?:ה|ו)?', 'נפל(?:ה|ו)?', 'שבור(?:ה|ים|ות)?', 'חורג(?:ת|ים|ות)?', 'חריגה', 'מעל הסף', 'פג(?:ה)? (?:ה)?תוקפ(?:ו|ה)', 'פג(?:ה)? (?:ה)?תוקף', 'לא תקינ(?:ה|ים|ות)', 'לא תקין', 'לא עובד(?:ת|ים|ות)?', 'לא עונ(?:ה|ים|ות)', 'לא מגיב(?:ה|ים|ות)?', 'לא זמינ(?:ה|ים|ות)', 'לא זמין', 'לא פעיל(?:ה|ים|ות)?', 'לא תוקנ(?:ה|ו)', 'לא תוקן', 'לא תואמ(?:ת|ים|ות)', 'לא תואם', 'לא עומד(?:ת|ים|ות)? ב', 'יש תקלה', 'יש שגיאה'];
  const FAIL_HE_G = new RegExp(FAIL_PARTS.map(p => HB + '[ובכלמשה]{0,2}(?:' + p + ')' + HE).join('|'), 'g');
  const FAIL_EN_G = /\b(?:failed|failing|failure|broken|exceed(?:s|ed|ing)?|above (?:the )?threshold|expired|is down|not ok|not working|not responding|does ?n[o']t meet|mismatch(?:ed)?)\b/gi;
  function failLine(l) {
    const s = unquote(l); if (/(?:לא|not)\s*✅/i.test(s)) return true;
    if (FIXED_RE.test(s) && !/לא תוקן|not fixed|unresolved/i.test(s)) return false;
    for (const re of [FAIL_HE_G, FAIL_EN_G]) { re.lastIndex = 0; let m; while ((m = re.exec(s))) { const before = s.slice(Math.max(0, m.index - 30), m.index), after = s.slice(m.index + m[0].length); if (!/^לא /.test(m[0].replace(/^[ובכלמשה]{0,2}/, '')) && NEG_BEFORE.test(before)) continue; if (ZERO_AFTER.test(after)) continue; return true; } }
    return false;
  }
  const PASS_HE_G = new RegExp(PASS_PARTS.map(p => HB + '[ובכלמשה]{0,2}(?:' + p + ')' + HE).join('|'), 'g');
  const PASS_EN_G = /\b(?:condition (?:is )?(?:met|satisfied)|requirement (?:is )?(?:met|satisfied)|meets the (?:requirement|rule|condition)|passes|passed the check|is (?:OK|fine)|as required)\b/gi;
  const unquote = l => String(l).replace(/`[^`]*`|"[^"\n]{0,80}"|“[^”\n]{0,80}”|«[^»\n]{0,80}»/g, ' '); // ערכים מצוטטים (`…`, "…") הם ראיה, לא ניסוח של המסקנה
  function passLine(l) {
    const s = unquote(l);
    for (const re of [PASS_HE_G, PASS_EN_G]) { re.lastIndex = 0; let m; while ((m = re.exec(s))) { const before = s.slice(Math.max(0, m.index - 30), m.index); if (NEG_BEFORE.test(before) || /(?:^|[^\p{L}\p{N}])[ובכלמשה]{1,2}(?:לא|אין|ללא|בלי)(?:\s+[\p{L}\p{N}]+){0,2}[\s:-]*$/u.test(before) || /(?:אינו|אינה|אינם|אינן|isn't|is not|are not|aren't|does not|doesn't)\s*$/i.test(before)) continue; return m[0]; } }
    return null;
  }
  const FILE_TOK = /[\p{L}\p{N}_.-]*[\p{L}\p{N}_-]\.(?:json|txt|log|ini|conf|cfg|ya?ml|xml|csv|md|js|ts|py|ps1|sh|bat|cmd|exe|dll|tmp|env|toml|lock|html?|css)\b/giu;
  // מספר הפריט בתחילת שורה מסומנת: "❌ (1) …" / "✅ 2. …" / "❌ סעיף 3 …" / "✅ **(1)** …"
  const itemNo = l => { const s = String(l).replace(/^[\s\-*•·]*(?:✅|☑️|✔️|✔|❌|✖|✗|✘|✕|❎|🚫|🔴|⛔|🟥|⚠️?|❗|❓)+[\s*_]*/u, ''); const m = s.match(/^(?:\(|\[)?(\d{1,2})(?:\)|\]|\.(?!\d)|:)/) || s.match(/^(?:סעיף|פריט|item)\s*(\d{1,2})\b/i); return m ? +m[1] : null; };
  function markConflicts(rep, task) {
    const out = [], byNo = new Map(), byFile = new Map();
    const taskFiles = new Map(); for (const m of String(task || '').matchAll(FILE_TOK)) { const k = m[0].toLowerCase(); taskFiles.set(k, (taskFiles.get(k) || 0) + 1); }
    for (const l of rep) {
      const ok = OK_MARK_RE.test(l), bad = X_MARK_RE.test(l);
      if (!ok && !bad) continue;
      if (ok && bad) { out.push({ line: l, why: 'both' }); continue; }
      if (bad) { const p = passLine(l); if (p) { out.push({ line: l, why: 'xpass', word: p }); continue; } }
      if (ok && !PROBLEM_RE.test(l) && failLine(l)) { out.push({ line: l, why: 'okfail' }); continue; }
      const mark = ok ? 'ok' : 'bad';
      const no = itemNo(l); if (no != null) { const s = byNo.get(no) || new Set(); s.add(mark); byNo.set(no, s); }
      // נושא השורה = מה שלפני "—" / ":" הראשונים (לא קבצים שמוזכרים בראיה, כמו רשימת קבצים בתיקייה)
      const u = unquote(l), cut = u.search(/\s[—–-]\s|:\s/), subj = cut > 0 && cut < 120 ? u.slice(0, cut) : u.slice(0, 60);
      const f = (subj.match(FILE_TOK) || [])[0]; if (f && taskFiles.get(f.toLowerCase()) === 1) { const k = f.toLowerCase(), s = byFile.get(k) || { marks: new Set(), lines: [] }; s.marks.add(mark); s.lines.push(l); byFile.set(k, s); }
    }
    for (const [no, s] of byNo) if (s.size > 1) out.push({ line: rep.find(l => itemNo(l) === no && (OK_MARK_RE.test(l) || X_MARK_RE.test(l))) || '', why: 'twice', item: '(' + no + ')' });
    for (const [f, s] of byFile) if (s.marks.size > 1 && !out.some(o => o.why === 'twice' && s.lines.includes(o.line))) out.push({ line: s.lines[0], why: 'twice', item: f });
    return out;
  }
  // כמה פריטים ממוספרים יש במשימה: "(1) … (2) …" או שורות "1. …" — רצף 1..N (אחרת לא סופרים)
  function taskItems(task) {
    const s0 = String(task || ''), nums = new Set();
    for (const m of s0.matchAll(/\((\d{1,2})\)/g)) nums.add(+m[1]);
    for (const m of s0.matchAll(/^\s*(\d{1,2})[.)]\s/gm)) nums.add(+m[1]);
    const n = nums.size; if (n < 2 || n > 30) return 0;
    for (let k = 1; k <= n; k++) if (!nums.has(k)) return 0;
    return n;
  }
  // פריט ברשימה (בתחילת שורה, לא מוזח, בתבנית "פריט — ראיה") בלי ✅ / ❌. שורות משנה מוזחות וצעדים ממוספרים בלי "—" — חופשיים
  const ITEM_RE = /^([-*•·▪◦‣]|\d+[.)])\s.*\s[—–]\s/;
  const clean = l => String(l || '').replace(/[‎‏⁦-⁩﻿]/g, '').trim(); // סימני כיוון בלתי נראים בלבד
  const linesOf = t => String(t || '').split(/\r?\n/).map(clean).filter(l => l && !/^(```|---+|\*\*\*+)$/.test(l));
  function lastLine(text) { const ls = linesOf(text); return ls[ls.length - 1] || ''; }
  function statusOf(text) { const l = lastLine(text); return l === OK_LINE ? 'ok' : l === BAD_LINE ? 'warn' : null; }
  // texts = כל הטקסטים של הסבב (האחרון = התשובה הסופית). הדיווח הקובע = הטקסט האחרון שיש בו סימוני פריטים (✅ / סימן תקלה)
  function checkRound(texts, task) {
    const list = (texts || []).filter(Boolean); const fin = list[list.length - 1] || '';
    const last = lastLine(fin), status = statusOf(fin);
    let reportText = null; for (let k = list.length - 1; k >= 0 && reportText == null; k--) { const ls = linesOf(list[k]).filter(l => l !== OK_LINE && l !== BAD_LINE); if (ls.some(l => OK_MARK_RE.test(l) || PROBLEM_RE.test(l))) reportText = list[k]; }
    if (reportText == null) reportText = fin;
    const rep = linesOf(reportText).filter(l => l !== OK_LINE && l !== BAD_LINE);
    const problems = rep.filter(l => PROBLEM_RE.test(l) || negLine(l)); // סימן תקלה, או ניסוח של תקלה (גם בשורה עם ✅) שלא "תוקן" ולא בשלילה
    const okItems = rep.filter(l => OK_MARK_RE.test(l) && !problems.includes(l));
    const raw = String(reportText).split(/\r?\n/).map(l => l.replace(/[‎‏⁦-⁩﻿]/g, '')); // עם ההזחה המקורית
    const unmarked = raw.filter(l => ITEM_RE.test(l) && !OK_MARK_RE.test(l) && !PROBLEM_RE.test(l)).map(l => l.trim());
    // הבעיה העיקרית להצגה: שורה עם סימן תקלה ובלי ✅ (שורה מבולבלת עם ❌ וגם ✅ — רק אם אין אחרת)
    const main = problems.find(l => PROBLEM_RE.test(l) && !OK_MARK_RE.test(l)) || problems.find(l => !OK_MARK_RE.test(l)) || problems[0] || '';
    // כיסוי: למשימה עם N פריטים ממוספרים — לפחות N שורות מסומנות (✅ / ❌) בדיווח. פחות = פריט שדולג / סיכום בשורה אחת
    const need = taskItems(task), marked = rep.filter(l => OK_MARK_RE.test(l) || PROBLEM_RE.test(l)).length;
    const conflicts = markConflicts(rep, task); // סימון שסותר את עצמו — נחסם בכל סטטוס (גם "לא תקין"), לפני כל בדיקה אחרת של הסטטוס
    const verdict = !status ? 'missing' : conflicts.length ? 'markconflict' : status === 'ok' && problems.length ? 'contradiction' : status === 'ok' && unmarked.length ? 'unmarked' : status === 'ok' && !okItems.length ? 'noevidence' : status === 'ok' && need && marked < need ? 'incomplete' : null;
    return { status, last, problems, main, okItems, unmarked, need, marked, conflicts, verdict };
  }
  function demandText(w, n, c) {
    const head = `[Claude Local — WATCH ${w.id} round ${n} — STATUS LINE REQUIRED]`;
    if (c.verdict === 'missing') return `${head} The LAST line of your answer must be EXACTLY one of these two lines, with nothing else on it (no emoji, no bold, no extra word, comma or period):
${OK_LINE}
${BAD_LINE}
Your last line was: "${clip(c.last, 160)}". If even one item is not OK → ${BAD_LINE}. ${OK_LINE} only if every item is ✅ (with evidence in the report). Output just the correct line.`;
    if (c.verdict === 'contradiction') return `${head} Your report shows a problem: «${clip(c.main, 200)}» — but your status says תקין. That is not allowed: while any item is not OK the status is ${BAD_LINE}. If it is still not OK → end with exactly: ${BAD_LINE}. Only if you already fixed it AND verified it in this round → write the whole item list again (every item "✅ <item> — תוקן ואומת: <the evidence you saw>"), then ${OK_LINE}.`;
    if (c.verdict === 'markconflict') {
      const k = c.conflicts[0] || {}, why = k.why === 'both' ? 'this line has both ✅ and ❌' : k.why === 'xpass' ? `this line is marked ❌ but its own words say the item passes («${clip(k.word, 40)}»)` : k.why === 'okfail' ? 'this line is marked ✅ but its own words describe a failure' : `item ${k.item || ''} appears more than once with different marks`;
      return `${head} Your report contradicts itself: «${clip(k.line, 220)}» — ${why}.${c.conflicts.length > 1 ? ` (${c.conflicts.length} such lines.)` : ''} Each item gets exactly ONE line with ONE mark, decided only by THAT item's own value against the TASK's rule: ✅ if it meets the rule — even when other items fail — and ❌ only if it does not meet it (or could not be checked). Do not write corrections inside the report and do not put words that say "OK" on a ❌ line. Write the whole item list again, once, then the status line: any ❌ → ${BAD_LINE}; every item ✅ → ${OK_LINE}.`;
    }
    if (c.verdict === 'incomplete') return `${head} The task lists ${c.need} numbered items, but your report has only ${c.marked} marked item line(s). Every item of the task must be checked in THIS round and be on its own line: "✅ (k) <item> — <the evidence you saw>" or "❌ (k) <item> — <what is wrong>". Check now any item you did not check, then write the whole list again (all ${c.need}) and end with the status line (any ❌ → ${BAD_LINE}).`;
    if (c.verdict === 'unmarked') return `${head} Your report has items without a mark: «${clip(c.unmarked[0], 160)}». Every item line must start with ✅ (OK, with the evidence) or ❌ (not OK, what is wrong). Write the item list again with a mark on every item, then the status line (any ❌ → ${BAD_LINE}).`;
    return `${head} You wrote ${OK_LINE} without showing the checks. Write the item list first — every item of the task on its own line: "✅ <item> — <the evidence you saw>" or "❌ <item> — <what is wrong>" — then the status line (any ❌ → ${BAD_LINE}).`;
  }
  // 🔎 הבודק העצמאי מצא ש"תקין" לא נתמך בפלטים של הסבב — Claude מקבל את הממצא ומתבקש לבדוק שוב (אם תוקן ואומת עכשיו — הפלט החדש יראה את זה)
  // iss = { statusWrong, markErrors, unsupported } — מה שהבודק מצא בדיווח (בכל סטטוס)
  function auditDemandText(w, n, a, iss) {
    iss = iss || { statusWrong: true, markErrors: [], unsupported: [] };
    const parts = [];
    if (iss.statusWrong) {
      const bad = (a.items || []).filter(x => x.state !== 'ok').map(x => '  - ' + x.item + ': ' + (x.state === 'not_checked' ? 'NOT CHECKED' : 'NOT OK') + (x.evidence ? ' (' + clip(x.evidence, 160) + ')' : '')).join('\n');
      parts.push(`• You ended with ${OK_LINE}, but the outputs do not confirm it: «${clip(a.reason, 300)}»${bad ? '\n' + bad : ''}`);
    }
    if (iss.markErrors.length) parts.push('• Item marks that do not match the tool outputs:\n' + iss.markErrors.slice(0, 8).map(x => `  - ${x.item}: your report marks it ${x.mark === 'none' ? '(no mark / missing)' : x.mark === 'both' ? 'both ✅ and ❌ / contradicts itself' : x.mark}, but the outputs show ${x.should === '✅' ? 'it MEETS the rule' : 'it does NOT meet the rule (or was not checked)'}${x.evidence ? ' (' + clip(x.evidence, 160) + ')' : ''} → it should be ${x.should}`).join('\n'));
    if (iss.unsupported.length) parts.push('• Facts in your report that no tool output of THIS round shows:\n' + iss.unsupported.slice(0, 6).map(x => `  - «${clip(x.claim, 200)}» — ${clip(x.why, 160)}`).join('\n'));
    return `[Claude Local — WATCH ${w.id} round ${n} — INDEPENDENT AUDIT] An independent auditor (a separate model that reads only the tool outputs of this round, not your words) checked your report and found:
${parts.join('\n')}
Check each of these again NOW with a tool (read / run it — do not rely on memory or on an earlier report). If it is not OK and you may fix it — fix it and show the fixed value with another tool output. Then write the WHOLE report again, once: every item on its own line, ✅ when its value meets the TASK's rule (even when other items fail), ❌ only when it does not; state only facts that a tool output of this round shows. If after re-checking you are sure the auditor is wrong about an item, keep your mark and quote the tool output that proves it. End with exactly one line: ${OK_LINE} or ${BAD_LINE} (any ❌ → ${BAD_LINE}).]`;
  }
  // ה-Stop hook (סוף תשובה של Claude): רק בתור של הסבב עצמו — ההודעה הגלויה האחרונה בשיחה היא של הסבב (או "נדרשת שורת סטטוס" שלו),
  // או הודעה שלך שנכנסה באמצע הסבב (אז התשובה הסופית מכסה גם את הסבב). סבב שכבר נמסרה לו שורה תקנית — לא נדרש שוב. עד 6 בקשות בסבב
  const MAX_DEMANDS = 6;
  // ===== 🔧 מצב תיקון (הבעלים 26/11): סבב שמצא פריט לא תקין לא נגמר בדוח "לא תקין" — Claude נכנס לתיקון, השעון של המעקב עוצר,
  //  ואין דוח עד שכל הפריטים תקינים (עם הוכחה). אז דוח ✅ על הכל, והמעקב חוזר לסבבים הרגילים. ההקלטה: "בדיקת המעקב הסתיימה, נמצאה בעיה - מתחיל תיקון".
  //  במנוי: ה-Stop hook לא נותן ל-Claude לסיים את התור ב"לא תקין" — הוא ממשיך לתקן באותו תור. ב-API (אין hook): הודעות המשך.
  //  עד FIX_MAX בקשות (פריט שבאמת צריך אותך — הרשאה, סיסמה, חומרה — לא יתוקן לבד): אז "לא תקין" עם הסיבה ועם מה שצריך ממך.
  const FIX_MAX = 12;
  const badLines = c => (c.problems || []).filter(l => PROBLEM_RE.test(l) || negLine(l));
  function fixText(w, n, c, k) {
    const bad = badLines(c).slice(0, 12).map(l => '  ' + clip(l, 220)).join('\n');
    return `[Claude Local — WATCH ${w.id} round ${n} — FIX MODE (${k}/${FIX_MAX})] This round found item(s) that are NOT OK:
${bad || '  (see your report)'}
The watch is in FIX MODE — the user's rule: the watch clock is stopped and this round does NOT end while any item is not OK. Do not stop and do not report yet. Fix every item that is not OK now (that is part of the task) and verify each fix with a tool output. Then check ALL items of the task again in this round and write the whole report again, once: "✅ <item> — תוקן ואומת: <the evidence you saw>" for every item you fixed, "✅ <item> — <evidence>" for the others, and end with ${OK_LINE} — only when every item is ✅. While anything can still be fixed you may not end with ${BAD_LINE}: keep fixing.
Only an item that truly cannot be fixed by you at all (it needs the user: a permission, a password, hardware, a purchase) may stay ❌ — then write exactly what the user must do, and end with ${BAD_LINE}.]`;
  }
  function beginFix(w, n, r, c) {
    if (w.fixing && w.fixing.n === n) return;
    const bad = badLines(c).length || 1;
    w.fixing = { n, since: now(), bad, total: Math.max(c.need || 0, c.marked || 0, bad), attempts: 0 };
    r.fixing = true; r.fixStartAt = now(); r.fixBad = bad; r.fixTotal = w.fixing.total;
  }
  function roundOfTurn(convId) {
    const cands = st.watches.filter(x => x.current && x.currentConv === convId); if (!cands.length) return null;
    let conv; try { conv = getConv(convId); } catch { return null; }
    const msgs = conv.messages || [];
    let lastTS = -1; for (let i = msgs.length - 1; i >= 0; i--) if (turnStart(msgs[i])) { lastTS = i; break; }
    let best = null;
    for (const w of cands) {
      let at = -1; for (let i = msgs.length - 1; i >= 0; i--) if (sameRound(msgs[i], w.id, w.current)) { at = i; break; }
      if (at < 0) continue; // ההודעה של הסבב עוד בתור — התור הזה לא שלו
      // סבב שנכנס באמצע תור אחר שלך (בצ'אט עצמו): נחשב רק אחרי ש-Claude כבר כתב משהו אחרי ההודעה שלו — אחרת זו התשובה לבקשה שלך, לא לסבב
      if (msgs[at].injected && !w.currentConv.startsWith('wsh-') && !msgs.slice(at + 1).some(m => m.role === 'assistant')) continue;
      const inTurn = at === lastTS || (lastTS > at && msgs.slice(at + 1, lastTS + 1).every(m => !turnStart(m) || m.injected)); // אחריה רק הודעות שנכנסו באמצע אותה ריצה
      if (inTurn && (!best || at > best.at)) best = { w, at };
    }
    return best ? best.w : null;
  }
  function stopGate(convId, answer) {
    const w = roundOfTurn(convId); if (!w) return null;
    const n = w.current, r = w.runs.find(x => x.n === n); if (!r || r.accepted) return null;
    const texts = roundTextsOf(convId, w.id, n); const a = String(answer || '').trim();
    if (a && texts[texts.length - 1] !== a) texts.push(a);
    const c = checkRound(texts, w.prompt);
    if (!c.verdict && c.status === 'warn' && w.fixMode !== false && w.status === 'active' && (r.fixDemands || 0) < FIX_MAX) {
      beginFix(w, n, r, c); r.fixDemands = (r.fixDemands || 0) + 1; w.fixing.attempts = r.fixDemands; save(); emit(w);
      return { id: w.id, n, verdict: 'fix', reason: fixText(w, n, c, r.fixDemands) };
    }
    if (!c.verdict) { r.accepted = true; r.finalText = String(texts[texts.length - 1] || '').slice(-4000); /* עם השורות כמו שהן — השורה האחרונה היא שורת הסטטוס */ save(); return null; } // שורה תקנית ועקבית — זו התשובה הקובעת של הסבב
    if ((r.hookDemands || 0) >= MAX_DEMANDS) return null; // לא נתקעים לנצח — אחרי הסבב האפליקציה תבקש שוב בתור נפרד, ואם אין — "לא תקין"
    r.hookDemands = (r.hookDemands || 0) + 1; r.demands = (r.demands || 0) + 1; save();
    return { id: w.id, n, verdict: c.verdict, reason: demandText(w, n, c) };
  }

  // סבב "רק בחלון המעקב" לא נשאר תלוי לנצח (אישור שלא נענה, שאלה, תהליך תקוע): מגבלת זמן → "לא תקין"
  const roundTimeout = w => Math.max(30, (w.everyMin || 1) * 3) * MINUTE_MS;
  async function track(w, n) {
    const r = w.runs.find(x => x.n === n); if (!r) return;
    const convId = (w.current === n && w.currentConv) || w.convId; // סבב בחלון המעקב רץ בשיחה-צל משלו
    const waitOpts = r.shadow ? { idleMs: Math.min(20, Math.max(10, w.everyMin * 2)) * MINUTE_MS, timeoutMs: roundTimeout(w) } : { idleMs: 0 }; // בצ'אט עצמו לא עוצרים את הריצה שלך
    let res = null;
    try { res = await waitTurn(convId, waitOpts); } catch (e) { res = { error: e.message }; }
    if (suspended) return; // השרת נסגר באמצע — הסבב נשאר "רץ" על הדיסק וימשיך / ייסגר ב-boot() בעלייה הבאה
    // התשובה שה-Stop hook אישר — רק אם היא עוד לא נשמרה בשיחה (מרוץ שמירה). אם כבר יש בסבב תשובה מאוחרת יותר (אחרי דרישה) — היא הקובעת
    const texts0 = () => { const t = roundTextsOf(convId, w.id, n), ft = r.finalText && String(r.finalText).trim(); if (ft && !t.some(x => x === ft || x.endsWith(ft) || ft.endsWith(x))) t.push(ft); return t; };
    let texts = texts0(), c = checkRound(texts, w.prompt);
    // גיבוי (גם במצב API, שאין בו Stop hook): התשובה הסתיימה בלי שורה תקנית / עם סתירה / עם סימון שסותר את עצמו — האפליקציה מבקשת שוב, עד 2 פעמים
    const gateFix = async () => {
      for (let k = 0; k < 2 && c.verdict && !(res && (res.stopped || res.error || res.timedOut)) && byId(w.id) && isActive(w); k++) { // מעקב שנעצר / הסתיים — לא שולחים עוד בקשות
        r.demands = (r.demands || 0) + 1; save();
        try { await sendToChat(convId, `↩️ מעקב ${w.id} · סבב ${n} · ${c.verdict === 'markconflict' ? 'דיווח שסותר את עצמו' : 'נדרשת שורת סטטוס'}`, { hidden: demandText(w, n, c), watch: { id: w.id, n, name: w.name, followup: true } }); res = await waitTurn(convId, waitOpts); }
        catch (e) { res = { error: e.message }; break; }
        if (suspended) return;
        texts = texts0(); c = checkRound(texts, w.prompt);
      }
    };
    await gateFix(); if (suspended) return;
    // 🔧 מצב תיקון — גיבוי (ב-API אין Stop hook; במנוי ה-hook כבר החזיק את Claude בתור): "לא תקין" → הודעת תיקון, עד שהכל תקין
    while (texts.length && !c.verdict && c.status === 'warn' && w.fixMode !== false && byId(w.id) && w.status === 'active' && !(res && (res.stopped || res.error || res.timedOut)) && (r.fixDemands || 0) < FIX_MAX) {
      beginFix(w, n, r, c); r.fixDemands = (r.fixDemands || 0) + 1; w.fixing.attempts = r.fixDemands; r.accepted = false; r.finalText = null; save(); emit(w);
      try { await sendToChat(convId, `🔧 מעקב ${w.id} · סבב ${n} · מצב תיקון`, { hidden: fixText(w, n, c, r.fixDemands), watch: { id: w.id, n, name: w.name, followup: true, fix: true } }); res = await waitTurn(convId, waitOpts); }
      catch (e) { res = { error: e.message }; break; }
      if (suspended) return;
      texts = texts0(); c = checkRound(texts, w.prompt);
      await gateFix(); if (suspended) return;
    }
    // 🔎 בודק עצמאי — בכל סבב (גם "לא תקין"): מודל נפרד קורא את מה ש-Claude באמת הריץ וראה בסבב (פלטי הכלים) ובודק את הסטטוס, כל סימון (✅ וגם ❌)
    //    וכל עובדה בדיווח. ממצא → Claude מקבל אותו ובודק שוב עם כלי (עד 2 פעמים). "תקין" שעדיין לא מאושר → "לא תקין" עם הממצא.
    //    בודק שלא זמין — לא חוסם, ומסומן בסבב (שקיפות). מה שנשאר במחלוקת אחרי 2 בדיקות חוזרות — מוצג בכרטיס הסבב
    let aud = null;
    const doneSoFar = () => texts.length && !c.verdict && (c.status === 'ok' || c.status === 'warn') && !(res && (res.stopped || res.error || res.timedOut));
    const issuesOf = a => { if (!a || !/^(ok|not_ok)$/.test(a.verdict)) return null; const st = c.status === 'ok' && a.verdict === 'not_ok', me = a.markErrors || [], un = a.unsupported || []; return st || me.length || un.length ? { statusWrong: st, markErrors: me, unsupported: un } : null; };
    if (audit && doneSoFar()) {
      const hist = [];
      for (let k = 0; k < 3; k++) {
        try { aud = await audit(w, n, convId, texts[texts.length - 1], c.status); } catch (e) { aud = { verdict: 'unavailable', reason: String(e && e.message || e).slice(0, 200) }; }
        if (suspended) return;
        const iss = issuesOf(aud);
        hist.push({ status: c.status, verdict: aud && aud.verdict, markErrors: iss ? iss.markErrors.length : 0, unsupported: iss ? iss.unsupported.length : 0 });
        if (!iss || k === 2 || !(byId(w.id) && isActive(w))) break;
        if (k >= 1 && !iss.statusWrong && !iss.markErrors.length) break; // רק "עובדה לא נתמכת" — בקשה חוזרת אחת מספיקה; מה שנשאר מוצג בכרטיס
        r.demands = (r.demands || 0) + 1; r.auditDemands = (r.auditDemands || 0) + 1; r.accepted = false; r.finalText = null; save(); // התשובה החדשה נבדקת מחדש גם ב-Stop hook
        try { await sendToChat(convId, `↩️ מעקב ${w.id} · סבב ${n} · בודק עצמאי`, { hidden: auditDemandText(w, n, aud, iss), watch: { id: w.id, n, name: w.name, followup: true, audit: true } }); res = await waitTurn(convId, waitOpts); }
        catch (e) { res = { error: e.message }; break; }
        if (suspended) return;
        texts = texts0(); c = checkRound(texts, w.prompt);
        await gateFix(); if (suspended) return; // התשובה החדשה עוברת שוב את השער (שורת סטטוס / סתירה)
        if (!doneSoFar()) break; // Claude שבר את השורה / הסבב נעצר — הטיפול הרגיל למטה
      }
      if (aud) { const iss = issuesOf(aud); r.audit = { verdict: aud.verdict, reason: aud.reason || '', items: (aud.items || []).slice(0, 20), markErrors: iss ? iss.markErrors.slice(0, 10) : [], unsupported: iss ? iss.unsupported.slice(0, 8) : [], checks: hist.length, history: hist, calls: aud.calls || 0, ms: aud.ms || 0, model: aud.model || null, forStatus: c.status }; }
    }
    if (suspended) return;
    const text = texts[texts.length - 1] || '';
    r.endedAt = now(); r.reply = clip(text, 2000); r.report = String(text || '').slice(-6000); // הדיווח המלא (עם השורות) — מוצג בחלון המעקב
    let status, problem = '', cause = null;
    // הסבב עצמו כבר נגמר בשורה תקנית, והריצה המשיכה לדבר אחר (הודעה שלך) שנעצר/נכשל — התוצאה של הסבב עומדת
    const roundClosed = (() => { try { const ms = getConv(convId).messages || []; let last = -1; ms.forEach((m, i) => { if (sameRound(m, w.id, n)) last = i; }); return last >= 0 && ms.slice(last + 1).some(m => turnStart(m) && !sameRound(m, w.id, n)); } catch { return false; } })();
    const broken = res && (res.stopped || res.error || res.timedOut) && !roundClosed;
    if (text && !c.verdict && (!broken || r.accepted) && !(c.status === 'ok' && aud && aud.verdict === 'not_ok')) { status = c.status; if (status === 'warn') problem = clip(c.main || '', 200); }
    else if (text && !c.verdict && c.status === 'ok' && aud && aud.verdict === 'not_ok') { status = 'warn'; cause = 'audit'; problem = 'בודק עצמאי: ' + clip(aud.reason || 'לא אישר את "תקין"', 180) + ' — האפליקציה קבעה: לא תקין'; } // שורה תקנית ועקבית — וסבב שהסתיים (או שהתשובה הסופית שלו כבר אושרה)
    else if (res && res.timedOut) { status = 'warn'; cause = 'timeout'; problem = 'הסבב לא הסתיים בזמן (' + clip(res.reason || '', 120) + ') — נעצר'; }
    else if (res && res.stopped) { status = 'warn'; cause = 'stopped'; problem = 'הסבב נעצר באמצע — לא נבדק עד הסוף'; }
    else if (res && res.error) { status = 'warn'; cause = 'error'; problem = 'הסבב נכשל: ' + clip(res.error, 200); }
    else if (!text) { status = 'warn'; cause = 'empty'; problem = 'Claude לא כתב דיווח'; }
    else if (c.verdict === 'missing') { status = 'warn'; cause = 'nostatus'; problem = 'Claude לא מסר שורת סטטוס תקנית (גם אחרי ' + (r.demands || 0) + ' בקשות) — האפליקציה קבעה: לא תקין'; }
    else { status = 'warn'; cause = c.verdict; problem = (c.verdict === 'markconflict' ? 'הדיווח סותר את עצמו: «' + clip((c.conflicts[0] || {}).line || '', 120) + '»' : c.verdict === 'contradiction' ? 'סתירה: הדיווח מראה «' + clip(c.main, 120) + '» אבל השורה אמרה תקין' : c.verdict === 'unmarked' ? 'פריט בלי סימון ✅/❌: «' + clip(c.unmarked[0], 100) + '»' : c.verdict === 'incomplete' ? 'בדיווח רק ' + c.marked + ' מתוך ' + c.need + ' הפריטים של המשימה' : 'נכתב "תקין" בלי ראיות (✅) לבדיקות') + ' — האפליקציה קבעה: לא תקין'; }
    r.status = status; r.summary = status === 'ok' ? OK_LINE : BAD_LINE; r.problem = problem || null; r.cause = cause; r.forced = !!cause;
    r.problemLines = (checkRound([text], w.prompt).problems || []).slice(0, 30); // שורות שהשער מזהה כתקלה (גם עם ✅) — מוצגות באדום בכרטיס הסבב
    // סבב שנמשך יותר מהמרווח (Claude תיקן וחיכה בתוך הסבב): הסבב הבא אחרי מרווח מלא מסוף הסבב — לא מיד (נמדד 26/11: Haiku, סבב 89ש → הבא אחרי שנייה)
    if (w.status === 'active' && w.nextRunAt && now() > w.nextRunAt + w.everyMin * MINUTE_MS / 2) w.nextRunAt = now() + w.everyMin * MINUTE_MS; // חריגה קטנה (תקורה) — בלי שינוי
    if (w.fixing && w.fixing.n === n) {
      const dur = Math.max(0, now() - w.fixing.since);
      r.fixMs = dur; r.fixAttempts = w.fixing.attempts; r.fixed = status === 'ok'; if (status !== 'ok' && !cause) { r.cause = 'unfixed'; r.problem = (r.problem ? r.problem + ' — ' : '') + 'לא תוקן גם אחרי ' + w.fixing.attempts + ' סבבי תיקון'; }
      if (w.endsAt) w.endsAt += dur;
      w.nextRunAt = now() + w.everyMin * MINUTE_MS; // השעון חוזר לעבוד מאפס — סבב רגיל אחרי מרווח מלא
      w.fixing = null;
    }
    if (w.current === n) { w.current = null; w.currentConv = null; }
    save(); emit(w);
    if (r.shadow) { try { endShadow(convId); } catch (e) { log('[watches] endShadow ' + e.message); } }
  }

  // "רק בחלון המעקב" (actionsInDock): הסבב רץ בשיחה-צל — עותק של הצ'אט, במקביל לצ'אט, ושום דבר ממנו לא נכנס לצ'אט
  const docked = w => !!(w.actionsInDock && startShadow);
  // השיחה של הסבב ידועה מיד (לפני כל המתנה): ה-Stop hook של הצ'אט לא יתבלבל עם סבב שעוד עולה
  function beginRun(w, n, run) {
    if (docked(w)) { run.shadow = true; w.currentConv = `wsh-${w.id}-${n}-${crypto.randomBytes(4).toString('hex')}`; }
    else w.currentConv = w.convId;
  }
  async function deliver(w, run, n, { visible, hidden, content, cmd, research }) {
    if (run.shadow) { await startShadow(w, n, { visible, hidden, content, cmd, research, id: w.currentConv }); run.queued = false; }
    else { const r = await sendToChat(w.convId, visible, { hidden, watch: { id: w.id, n, name: w.name } }); run.queued = !!(r && r.queued); }
  }
  // סבב שלא נשלח (אין חיבור, הצ'אט נמחק…) — גם הוא "לא תקין" עם הסיבה (שני סטטוסים בלבד)
  function failRun(w, run, e) {
    run.status = 'warn'; run.summary = BAD_LINE; run.problem = 'הסבב לא נשלח: ' + clip(e && e.message || String(e), 200); run.cause = 'send'; run.forced = true; run.endedAt = now();
    const cid = w.currentConv; w.current = null; w.currentConv = null; save(); emit(w);
    if (run.shadow && cid) { try { endShadow(cid); } catch { } }
  }
  async function startRound(w) {
    const n = w.runCount + 1, at = now();
    w.runCount = n; w.current = n; w.lastRunAt = at;
    w.nextRunAt = at + w.everyMin * MINUTE_MS;
    const run = { n, at, status: 'running', summary: '' };
    w.runs.push(run); if (w.runs.length > MAX_RUNS_KEPT) w.runs.splice(0, w.runs.length - MAX_RUNS_KEPT);
    beginRun(w, n, run);
    save(); emit(w);
    const { visible, hidden } = roundTexts(w, n, !!run.shadow);
    try { await deliver(w, run, n, { visible, hidden }); save(); emit(w); }
    catch (e) { if (suspended) return; failRun(w, run, e); return; }
    if (suspended) return;
    track(w, n);
  }
  // מעקב שנפתח "רק בחלון המעקב": ההודעה שכתבת (עם הקבצים המצורפים) היא סבב 1 — רצה מיד בשיחה-צל, לא בצ'אט
  async function startDockedFirstRound(w, content, { cmd, research } = {}) {
    const at = now();
    w.runCount = 1; w.current = 1; w.lastRunAt = at;
    const run = { n: 1, at, status: 'running', summary: '' }; w.runs.push(run);
    beginRun(w, 1, run);
    save(); emit(w);
    const visible = `⏱ מעקב ${w.id} «${w.name}» · סבב 1`;
    const c = [...(content || [])]; // ההודעה כמו שנכתבה: טקסט, קבצים מצורפים, והנחיית מחקר (🔬) אם נבחרה
    try { await deliver(w, run, 1, { visible, hidden: creationHidden(w, true), content: c.length ? c : null, cmd, research }); save(); emit(w); }
    catch (e) { if (suspended) return; failRun(w, run, e); return; }
    if (suspended) return;
    track(w, 1);
  }

  function end(w, status, reason) {
    if (!isActive(w)) return;
    w.status = status; w.endedAt = now(); w.endReason = reason; w.nextRunAt = null;
    save(); emit(w); log(`[watches] ${w.id} ${status}: ${reason}`);
  }

  // ----- המתזמן -----
  let usageAt = 0, usageVal = null, usageBusy = false;
  async function refreshUsage() {
    if (usageBusy || Date.now() - usageAt < 60000) return; usageBusy = true;
    try { usageVal = usageRemaining ? await usageRemaining() : null; } catch { usageVal = null; }
    usageAt = Date.now(); usageBusy = false;
  }
  function tick() {
    if (suspended) return; // השרת נסגר / מתנתק — לא מתחילים כלום ולא מסיימים כלום (לפני boot() סבב שנקטע לא מתחיל מחדש: w.current מלא, w.fixing מדולג)
    const t = now();
    const needUsage = st.watches.some(w => w.status === 'active' && w.stopAtRemainingPct != null);
    if (needUsage) refreshUsage();
    for (const w of st.watches) {
      if (w.status !== 'active') continue;
      if (w.fixing) continue; // 🔧 בתיקון: השעון עוצר (לא נגמר בזמן, לא מתחיל סבב)
      if (w.endsAt && t >= w.endsAt) { end(w, 'done', 'הזמן שהוגדר הסתיים'); continue; }
      if (w.stopAtRemainingPct != null && usageVal && typeof usageVal.remaining === 'number' && usageVal.remaining <= w.stopAtRemainingPct) { end(w, 'usage', `נשארו ${Math.round(usageVal.remaining)}% מהמנוי (${usageVal.label}) — סף העצירה ${w.stopAtRemainingPct}%`); continue; }
      if (!w.current && w.nextRunAt && t >= w.nextRunAt) startRound(w);
    }
  }
  const timer = setInterval(tick, tickMs); if (timer.unref) timer.unref();

  // ----- פעולות -----
  function normalize(o) {
    const num = (v, d) => { const x = Number(v); return Number.isFinite(x) && x > 0 ? x : d; };
    const everyMin = Math.max(1, Math.round(num(o.everyMin, 5)));
    const durationMin = o.durationMin == null || o.durationMin === '' || o.unlimited ? null : Math.max(1, Math.round(num(o.durationMin, 60)));
    const pct = o.stopAtRemainingPct == null || o.stopAtRemainingPct === '' ? null : Math.max(1, Math.min(99, Math.round(Number(o.stopAtRemainingPct))));
    return { everyMin, durationMin, stopAtRemainingPct: Number.isFinite(pct) ? pct : null };
  }
  function autoName(prompt) { const s = clip(String(prompt || '').replace(/[`*_#>\[\]]/g, ''), 200).split(/\s+/).slice(0, 4).join(' '); return s || 'מעקב'; }
  // יצירה. firstRoundFromMessage=true: ההודעה שיצרה את המעקב היא סבב 1 (נשלחת ע"י השרת עם creationHidden), וכאן רק עוקבים אחריה
  function create(o) {
    const n = normalize(o), t = now();
    const w = {
      id: 'W' + (++st.seq), name: clip(o.name || autoName(o.prompt), 40), convId: o.convId, prompt: String(o.prompt || '').slice(0, 20000),
      ...n, status: 'active', createdAt: t, endsAt: n.durationMin == null ? null : t + n.durationMin * MINUTE_MS,
      nextRunAt: t + n.everyMin * MINUTE_MS, runCount: 0, current: null, runs: [], createdBy: o.createdBy || 'user',
      ...(o.actionsInDock ? { actionsInDock: true } : {}), fixMode: o.fixMode !== false
    };
    st.watches.push(w); save(); emit(w);
    return w;
  }
  function beginFirstRound(w) { // ההודעה המקורית נשלחה עכשיו (או נכנסה לתור) — זה סבב 1
    w.runCount = 1; w.current = 1; w.currentConv = w.convId; w.lastRunAt = now(); w.runs.push({ n: 1, at: now(), status: 'running', summary: '' }); save(); emit(w);
    track(w, 1);
  }
  function stop(id, by = 'user') { const w = byId(id); if (!w) return null; end(w, 'stopped', by === 'claude' ? 'נעצר ע"י Claude לבקשתך' : 'נעצר ידנית'); return summary(w); }
  // השהיה עוצרת את השעון (הבעלים 26/11): הזמן שנשאר עד הסבב הבא נשמר, וההמשך ממשיך ממנו — עצר כשנשארו 3:00 → ממשיך מ-3:00,
  // כמה זמן שלא יעבור בהשהיה. גם משך המעקב ("למשך…") לא נאכל בזמן ההשהיה
  function pause(id) { const w = byId(id); if (!w || w.status !== 'active') return w ? summary(w) : null; const t = now(); w.status = 'paused'; w.pausedAt = t; w.pausedRemainingMs = w.current ? null : Math.max(0, (w.nextRunAt || t) - t); save(); emit(w); return summary(w); }
  function resume(id) {
    const w = byId(id); if (!w || w.status !== 'paused') return w ? summary(w) : null;
    const t = now(), paused = Math.max(0, t - (w.pausedAt || t));
    w.status = 'active'; w.nextRunAt = t + (w.pausedRemainingMs != null ? w.pausedRemainingMs : 0);
    if (w.endsAt) w.endsAt += paused;
    w.pausedAt = null; w.pausedRemainingMs = null;
    save(); emit(w); setImmediate(tick); return summary(w);
  }
  // "סבב עכשיו": מתחיל מיד (ואם סבב קודם עוד נסגר — הבא יתחיל ברגע שיסתיים)
  function runNow(id) { const w = byId(id); if (!w || w.status !== 'active') return w ? summary(w) : null; w.nextRunAt = now(); save(); emit(w); setImmediate(tick); return summary(w); }
  function rename(id, name) { const w = byId(id); if (!w) return null; w.name = clip(name, 40) || w.name; save(); emit(w); return summary(w); }
  // עריכה בלי לעצור: שם · משימה · כל כמה · למשך (מעכשיו) / ללא הגבלה · עצירה לפי מנוי. הסבב הבא כבר לפי החדש
  function update(id, o = {}) {
    const w = byId(id); if (!w) return null;
    if (typeof o.name === 'string' && o.name.trim()) w.name = clip(o.name.trim(), 40);
    if (typeof o.prompt === 'string' && o.prompt.trim()) w.prompt = String(o.prompt).slice(0, 20000);
    if (o.everyMin != null) {
      const ev = Math.max(1, Math.round(Number(o.everyMin) || w.everyMin));
      if (ev !== w.everyMin) { w.everyMin = ev; if (w.status === 'active' && !w.current) w.nextRunAt = Math.max(now(), (w.lastRunAt || now()) + ev * MINUTE_MS); }
    }
    if (o.unlimited || ('durationMin' in o && (o.durationMin == null || o.durationMin === ''))) { w.durationMin = null; w.endsAt = null; }
    else if (o.durationMin != null) { const d = Math.max(1, Math.round(Number(o.durationMin) || 60)); w.durationMin = d; w.endsAt = now() + d * MINUTE_MS; }
    if ('stopAtRemainingPct' in o) { const p = o.stopAtRemainingPct == null || o.stopAtRemainingPct === '' ? null : Math.max(1, Math.min(99, Math.round(Number(o.stopAtRemainingPct)))); w.stopAtRemainingPct = Number.isFinite(p) ? p : null; }
    if ('actionsInDock' in o) w.actionsInDock = !!o.actionsInDock;
    if ('fixMode' in o) w.fixMode = o.fixMode !== false;
    w.editedAt = now();
    save(); emit(w); setImmediate(tick);
    return summary(w);
  }
  function remove(id) { const i = st.watches.findIndex(w => w.id === String(id).toUpperCase()); if (i < 0) return false; if (isActive(st.watches[i])) return false; const w = st.watches.splice(i, 1)[0]; save(); try { onEvent('watch_removed', { id: w.id, convId: w.convId }); } catch { } return true; }
  // 🔒 נעילה לשינויים (הבעלים בלבד, מהממשק): Claude לא יכול לעצור / להשהות / להפעיל / לערוך מעקב נעול
  function setLock(id, on) { const w = byId(id); if (!w) return null; w.locked = !!on; w.lockedAt = on ? now() : null; save(); emit(w); log(`[watches] ${w.id} ${on ? 'locked' : 'unlocked'}`); return summary(w); }
  // 🔧 מעקב בתיקון נעול ל-Claude עד שהכל תקין (הבעלים 26/11: "אין לו שום דרך לעקוף") — כל ההגנות של נעילה חלות עליו: כלים, API, קבצים, חלון האפליקציה
  function lockedList() { return st.watches.filter(w => (w.locked || w.fixing) && isActive(w)).map(w => ({ id: w.id, name: w.name, convId: w.convId, fixing: !!w.fixing && !w.locked })); }
  // ניסיון של Claude לגעת במעקב נעול — נחסם ונרשם (מוצג בחלון המעקב)
  function noteBlocked(id, o = {}) { const w = byId(id); if (!w) return; w.blockedTotal = (w.blockedTotal || (w.blocked || []).length) + 1; (w.blocked = w.blocked || []).push({ at: now(), by: o.by || 'tool', what: clip(o.what || '', 120), tool: clip(o.tool || '', 60) }); if (w.blocked.length > 20) w.blocked.splice(0, w.blocked.length - 20); save(); emit(w); }
  function list({ convId, all } = {}) { return st.watches.filter(w => (!convId || w.convId === convId) && (all || isActive(w) || (w.endedAt && Date.now() - w.endedAt < 7 * 86400000))).map(summary).reverse(); }
  function get(id) { const w = byId(id); return w ? full(w) : null; }
  function activeFor(convId) { return st.watches.filter(w => w.convId === convId && isActive(w)); }
  function removeForConv(convId) { for (const w of st.watches) if (w.convId === convId && isActive(w)) end(w, 'stopped', 'השיחה נמחקה'); }

  // סבב של מעקב רץ עכשיו בשיחה הזו? (ה-Stop hook דורש בו שורת סטטוס)
  // סבב "רק בחלון המעקב" רץ בשיחה-צל משלו — שם נדרשת שורת הסטטוס, לא בצ'אט (התשובות שלך בצ'אט לא נחסמות בגללו)
  function roundRunning(convId) { const w = st.watches.find(x => x.current && x.currentConv === convId); return w ? { id: w.id, n: w.current, name: w.name } : null; }
  function roundConv(id) { const w = byId(id); return w && w.current ? w.currentConv || null : null; }
  // סבבים שנקטעו כשהתוכנה נסגרה ("לא תקין") ועוד לא הושמעה להם ההקלטה — מוחזרים פעם אחת
  function interruptedUnannounced() { const out = []; for (const w of st.watches) for (const r of w.runs) if (r.cause === 'interrupted' && !r.announced) { r.announced = true; out.push({ id: w.id, n: r.n, convId: w.convId }); } if (out.length) save(); return out; }

  // ===== עלייה: סבבים שרצו כשהשרת נסגר (HOT-UPDATE-PLAN שלב 0.1) =====
  //  • סבב ששיחה שלו אומצה (adoptedConvIds — הריצה עוד חיה) → רק ממשיכים לעקוב אחריו
  //  • סבב בתיקון (w.fixing.n === w.current) → לא מסומן: "ממשיך לתקן" לאותו סבב, ועד RESUME_MAX הפסקות. בפעם ה-RESUME_MAX — "לא תקין"
  //  • סבב רגיל → "לא תקין" (נקטע) כמו קודם; w.fixing שנשאר מסבב אחר נמחק; nextRunAt לא נשאר בעבר
  const RESUME_MAX = 3;
  function resumeFixText(w, n, r, docked) {
    const f = w.fixing || {};
    const head = docked ? roundTexts(w, n, true).hidden + '\n\n' : ''; // שיחת-צל חדשה — בלי ההודעות הקודמות של הסבב: המשימה המלאה שוב
    return head + `[Claude Local — WATCH ${w.id} round ${n} — FIX MODE RESUMED after the app restarted (interruption ${r.resumes}/${RESUME_MAX})] The app restarted in the middle of this round while it was in FIX MODE (${f.bad || 1} item(s) were NOT OK). The round did NOT end and the watch clock is still stopped: continue fixing from where you stopped. Check the current state with a tool first (part of the work may already be done). Fix every item that is not OK and verify each fix with a tool output. Then check ALL items of the task again and write the whole report once: "✅ <item> — תוקן ואומת: <evidence>" for what you fixed, "✅ <item> — <evidence>" for the others, and end with ${OK_LINE} — only when every item is ✅. Only an item that truly needs the user (a permission, a password, hardware) may stay ❌ — then write what the user must do and end with ${BAD_LINE}.]`;
  }
  function closeInterrupted(w, r, problem) {
    const t = now();
    r.status = 'warn'; r.summary = BAD_LINE; r.problem = problem; r.cause = 'interrupted'; r.forced = true; r.endedAt = t;
    if (w.fixing && w.fixing.n === r.n) { const dur = Math.max(0, t - (w.fixing.since || t)); r.fixMs = dur; r.fixAttempts = w.fixing.attempts; r.fixed = false; if (w.endsAt) w.endsAt += dur; }
    w.fixing = null; w.current = null; w.currentConv = null;
    if (w.status === 'active' && (!w.nextRunAt || w.nextRunAt < t)) w.nextRunAt = t + w.everyMin * MINUTE_MS;
  }
  async function resumeFix(w, n, r) {
    const visible = `🔧 מעקב ${w.id} · סבב ${n} · ממשיך לתקן (אחרי הפעלה מחדש)`;
    try {
      if (r.shadow && startShadow) {
        const id = `wsh-${w.id}-${n}-${crypto.randomBytes(4).toString('hex')}`;
        w.currentConv = id; save();
        await startShadow(w, n, { visible, hidden: resumeFixText(w, n, r, true), id });
      } else {
        w.currentConv = w.convId; save();
        await sendToChat(w.convId, visible, { hidden: resumeFixText(w, n, r, false), watch: { id: w.id, n, name: w.name, followup: true, fix: true } });
      }
    } catch (e) {
      if (suspended) return;
      closeInterrupted(w, r, 'הסבב נקטע באמצע תיקון, וההמשך לא נשלח: ' + clip(e && e.message || String(e), 160)); r.cause = 'send'; save(); emit(w); return;
    }
    if (suspended) return;
    save(); emit(w);
    track(w, n);
  }
  function boot(adoptedConvIds = new Set()) {
    if (booted) return { resumed: [], interrupted: [], adopted: [] }; booted = true;
    const adopted = adoptedConvIds instanceof Set ? adoptedConvIds : new Set(adoptedConvIds || []);
    const out = { resumed: [], interrupted: [], adopted: [] }, changed = new Set(), t = now();
    for (const w of st.watches) {
      if (!loadedCurrent.has(w.id) || loadedCurrent.get(w.id) !== (w.current || null)) continue; // לא היה רץ בעלייה / סבב חדש של התהליך הזה
      const n = w.current, r = n ? w.runs.find(x => x.n === n) : null;
      if (!r || r.status !== 'running') { // אין סבב רץ (או מצביע ישן) — לא נשאר "בתיקון" / "סבב נוכחי" תלוי
        if (w.current || w.fixing) { w.current = null; w.currentConv = null; w.fixing = null; if (w.status === 'active' && (!w.nextRunAt || w.nextRunAt < t)) w.nextRunAt = t + w.everyMin * MINUTE_MS; changed.add(w); }
        continue;
      }
      if (adopted.has(w.currentConv || w.convId)) { out.adopted.push({ id: w.id, n }); track(w, n); continue; }
      if (w.fixing && w.fixing.n === n && w.status === 'active' && w.fixMode !== false) {
        r.resumes = (r.resumes || 0) + 1; r.resumedAfter = t;
        if (r.resumes >= RESUME_MAX) { closeInterrupted(w, r, `לא תקין (נקטע ${RESUME_MAX} פעמים באמצע תיקון)`); out.interrupted.push({ id: w.id, n, resumes: r.resumes }); changed.add(w); continue; }
        out.resumed.push({ id: w.id, n, resumes: r.resumes }); changed.add(w);
        resumeFix(w, n, r);
        continue;
      }
      closeInterrupted(w, r, 'הסבב נקטע — התוכנה נסגרה באמצע הסבב'); out.interrupted.push({ id: w.id, n }); changed.add(w);
    }
    saveNow();
    for (const w of changed) emit(w);
    if (out.resumed.length || out.interrupted.length || out.adopted.length) log(`[watches] boot: resumed ${out.resumed.map(x => x.id + '#' + x.n).join(',') || '-'} · interrupted ${out.interrupted.map(x => x.id + '#' + x.n).join(',') || '-'} · adopted ${out.adopted.map(x => x.id + '#' + x.n).join(',') || '-'}`);
    return out;
  }
  // השרת נסגר / מתנתק (abort-all / detach מהתהליך הראשי): שום תוצאה לא נרשמת לסבב שנקטע — w.current ו-w.fixing נשארים על הדיסק
  function suspend() {
    if (suspended) return; suspended = true;
    clearTimeout(saveT); saveNow();
    log('[watches] suspended — rounds in progress stay on disk for the next start');
  }
  const isSuspended = () => suspended;
  // מעקב שיש בו עבודה עכשיו (סבב רץ / תיקון) — העדכון לא מוחל באמצע
  const busyList = () => st.watches.filter(w => w.current || w.fixing).map(w => ({ id: w.id, n: w.current || (w.fixing && w.fixing.n) || null, fixing: !!w.fixing, conv: (w.current && w.currentConv) || null }));
  return { boot, suspend, isSuspended, busyList, statusOf, checkRound, stopGate, OK_LINE, BAD_LINE, roundRunning, roundConv, interruptedUnannounced, create, beginFirstRound, startDockedFirstRound, creationHidden, stop, pause, resume, runNow, rename, update, remove, setLock, lockedList, noteBlocked, list, get, activeFor, removeForConv, summary, tick, fmtEvery, fmtDur, _state: () => st };
}

// ----- כלים ל-Claude (דרך שרת ה-MCP של האפליקציה) -----
const T = (name, description, properties, required) => ({ name, description, input_schema: { type: 'object', properties: properties || {}, ...(required ? { required } : {}) } });
const WATCH_TOOLS = [
  T('watch_list', 'WATCHES (מעקבים): list the watches of this chat (all=true: of all chats) — id, name, interval, status, next round, last result.', { all: { type: 'boolean' } }),
  T('watch_stop', 'WATCHES: stop a watch for good (when the user asks to stop / close it). id like W3. A watch the user LOCKED (🔒) cannot be stopped, paused, resumed or edited by you at all.', { id: { type: 'string' } }, ['id']),
  T('watch_pause', 'WATCHES: pause a watch (no rounds until resumed).', { id: { type: 'string' } }, ['id']),
  T('watch_resume', 'WATCHES: resume a paused watch (runs a round right away).', { id: { type: 'string' } }, ['id']),
  T('watch_update', 'WATCHES: EDIT a watch without stopping it — whenever the user asks to change its task text, interval, duration, name or the stop-at-% rule. Send only the fields to change: task (the new full standing task, in the user\'s words — replaces the old one), every_min, duration_min (from now; null or unlimited=true = no time limit), name, stop_at_remaining_pct (null = off), actions_in_dock. The next round already uses the new values. Use watch_list to see the current values first.', { id: { type: 'string' }, task: { type: 'string' }, every_min: { type: 'number' }, duration_min: { type: ['number', 'null'] }, unlimited: { type: 'boolean' }, name: { type: 'string' }, stop_at_remaining_pct: { type: ['number', 'null'] }, actions_in_dock: { type: 'boolean' } }, ['id']),
  T('watch_create', 'WATCHES: open a new watch in THIS chat only when the user explicitly asks for one in words: the app will wake you every every_min minutes to do the task. duration_min omitted = no time limit. stop_at_remaining_pct = stop when the subscription has that % or less left.', { name: { type: 'string' }, task: { type: 'string', description: 'the exact standing task, in the user\'s words' }, every_min: { type: 'number' }, duration_min: { type: 'number' }, stop_at_remaining_pct: { type: 'number' } }, ['task', 'every_min'])
];

module.exports = { createWatches, WATCH_TOOLS };
