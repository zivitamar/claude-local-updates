'use strict';
// ============================================================
//  chrome_flags.js — 🚫 הפס "ניפוי באגים של הדפדפן הזה מתבצע על ידי…" אף פעם (REQUESTS-10, מחקר: docs/research/chrome-no-debug-bar-decision.md)
//  Chrome מציג את הפס על כל חיבור של chrome.debugger, בכל החלונות — חוץ משני מקרים בקוד של Chrome (debugger_api.cc, כולל 157):
//    (א) הדפדפן הופעל עם --silent-debugger-extension-api   (ב) התוסף מותקן במדיניות ארגונית
//  שכבה A (כאן): המתג נוסף לכל דרך שבה Chrome נפתח — קיצורי דרך (שולחן עבודה, תפריט התחל, שורת המשימות), פתיחת קישורים
//    (ChromeHTML), והפתיחה האוטומטית בכניסה למחשב. גיבוי מלא לפני כל שינוי + ביטול בקריאה אחת. הפרופיל של Chrome — לא נוגעים בו בכלל.
//  שכבה C (השער): browserForSocket — לאיזה תהליך Chrome שייך החיבור של התוסף, והאם הוא הופעל עם המתג. בלי המתג התוסף לא מתחבר.
// ============================================================
const fs = require('fs'), os = require('os'), path = require('path'), { execFile } = require('child_process');
const SWITCH = '--silent-debugger-extension-api';
const ps = (script, timeout = 60000) => new Promise(res => execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], { windowsHide: true, timeout, maxBuffer: 16 * 1024 * 1024 }, (err, out, errOut) => res({ ok: !err, out: String(out || ''), err: String(errOut || (err && err.message) || '') })));
const q = s => "'" + String(s).replace(/'/g, "''") + "'";

// ---------- שכבה C: איזה Chrome מחזיק את החיבור של התוסף, והאם המתג אצלו ----------
// החיבור של ה-service worker של התוסף יוצא מתהליך הרשת של Chrome (--type=utility) → עולים בשרשרת ההורים עד chrome.exe בלי --type= = הדפדפן עצמו
async function browserForSocket(sock) {
  if (process.platform !== 'win32') return { silent: false, reason: 'לא Windows' };
  const rp = sock && sock.remotePort, lp = sock && sock.localPort; if (!rp || !lp) return { silent: false, reason: 'אין פרטי חיבור' };
  const r = await ps(`$c = Get-NetTCPConnection -LocalPort ${+rp} -RemotePort ${+lp} -State Established -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $c) { 'NOCONN'; exit }
$all = @{}; Get-CimInstance Win32_Process -Property ProcessId,ParentProcessId,Name,CommandLine | ForEach-Object { $all[[int]$_.ProcessId] = $_ }
$p = [int]$c.OwningProcess
for ($i = 0; $i -lt 12 -and $all.ContainsKey($p); $i++) { $x = $all[$p]; if ($x.Name -ieq 'chrome.exe' -and ($x.CommandLine -notmatch '--type=')) { 'PID ' + $p; 'CMD ' + $x.CommandLine; exit }; $p = [int]$x.ParentProcessId }
'NOBROWSER'`, 30000);
  const pid = (/^PID (\d+)/m.exec(r.out) || [])[1], cmd = ((/^CMD (.*)$/m.exec(r.out) || [])[1] || '').trim();
  if (!pid) return { silent: false, reason: /NOCONN/.test(r.out) ? 'לא נמצא החיבור של התוסף' : 'לא נמצא תהליך הכרום של התוסף', raw: r.out.slice(0, 300) };
  const silent = cmd.split(/\s+/).includes(SWITCH) || cmd.includes(' ' + SWITCH + ' ') || cmd.endsWith(' ' + SWITCH);
  return { silent, browserPid: +pid, reason: silent ? 'Chrome הופעל עם ההגדרה שמונעת את הפס' : 'Chrome שרץ עכשיו הופעל בלי ההגדרה שמונעת את הפס (נפתח לפני שהיא נוספה) — צריך לסגור אותו לגמרי ולפתוח שוב פעם אחת', cmd: cmd.slice(0, 400) };
}

// ---------- שכבה A: המתג בכל דרכי הפתיחה ----------
// קיצורי דרך: IShellLinkW + IPersistFile (לא WScript.Shell — הוא עלול למחוק את AppUserModelID ואז הסמל בשורת המשימות מתפצל)
const LNK_CS = `using System; using System.Text; using System.Runtime.InteropServices;
namespace CL { [ComImport, Guid("00021401-0000-0000-C000-000000000046")] public class ShellLink { }
[ComImport, InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("000214F9-0000-0000-C000-000000000046")] public interface IShellLinkW {
 void GetPath([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder f, int c, IntPtr fd, uint fl); void GetIDList(out IntPtr p); void SetIDList(IntPtr p);
 void GetDescription([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder n, int c); void SetDescription([MarshalAs(UnmanagedType.LPWStr)] string n);
 void GetWorkingDirectory([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder d, int c); void SetWorkingDirectory([MarshalAs(UnmanagedType.LPWStr)] string d);
 void GetArguments([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder a, int c); void SetArguments([MarshalAs(UnmanagedType.LPWStr)] string a);
 void GetHotkey(out short h); void SetHotkey(short h); void GetShowCmd(out int s); void SetShowCmd(int s);
 void GetIconLocation([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder p, int c, out int i); void SetIconLocation([MarshalAs(UnmanagedType.LPWStr)] string p, int i);
 void SetRelativePath([MarshalAs(UnmanagedType.LPWStr)] string p, uint r); void Resolve(IntPtr h, uint f); void SetPath([MarshalAs(UnmanagedType.LPWStr)] string p); }
[ComImport, InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("0000010b-0000-0000-C000-000000000046")] public interface IPersistFile {
 void GetClassID(out Guid c); [PreserveSig] int IsDirty(); void Load([MarshalAs(UnmanagedType.LPWStr)] string f, uint m); void Save([MarshalAs(UnmanagedType.LPWStr)] string f, [MarshalAs(UnmanagedType.Bool)] bool r);
 void SaveCompleted([MarshalAs(UnmanagedType.LPWStr)] string f); void GetCurFile([MarshalAs(UnmanagedType.LPWStr)] out string f); }
public static class L { public static string Read(string f) { var l = (IShellLinkW)new ShellLink(); ((IPersistFile)l).Load(f, 0); var p = new StringBuilder(1024); l.GetPath(p, 1024, IntPtr.Zero, 0); var a = new StringBuilder(8192); l.GetArguments(a, 8192); return p.ToString() + "\\t" + a.ToString(); }
 public static void SetArgs(string f, string args) { var l = (IShellLinkW)new ShellLink(); var pf = (IPersistFile)l; pf.Load(f, 2); l.SetArguments(args); pf.Save(f, true); } } }`;
function lnkRoots() {
  const A = process.env.APPDATA || '', P = process.env.ProgramData || 'C:\\ProgramData', PUB = process.env.PUBLIC || 'C:\\Users\\Public';
  return [path.join(A, 'Microsoft', 'Internet Explorer', 'Quick Launch'), path.join(A, 'Microsoft', 'Windows', 'Start Menu', 'Programs'), path.join(P, 'Microsoft', 'Windows', 'Start Menu', 'Programs'), path.join(PUB, 'Desktop')];
}
// המתג מתווסף לפני כל שאר הארגומנטים (ולפני --single-argument, שאחריו הכל הופך לארגומנט אחד)
const withSwitch = args => { const a = String(args || '').trim(); if (a.split(/\s+/).includes(SWITCH)) return null; return (SWITCH + ' ' + a).trim(); };
const withoutSwitch = args => String(args || '').split(/\s+/).filter(x => x && x !== SWITCH).join(' ');
const CHROME_RE = /\\google\\chrome\\application\\(chrome|chrome_proxy)\.exe$/i;

/**
 * apply({ roots, regRoot, runKey, backupDir, dryRun }) — מוסיף את המתג לכל קיצורי הדרך של Chrome, לפקודת פתיחת הקישורים, ולפתיחה האוטומטית.
 * roots: תיקיות לסרוק (ברירת מחדל: כל המקומות של המשתמש + שולחן העבודה האמיתי, כולל OneDrive). regRoot: שורש הרישום (בבדיקות — מפתח זמני).
 * מחזיר { changed:[...], already:[...], failed:[...], backup }. אידמפוטנטי — הרצה שנייה לא משנה כלום.
 */
async function apply(o = {}) {
  if (process.platform !== 'win32') return { changed: [], already: [], failed: [{ what: 'platform', error: 'Windows only' }] };
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupDir = o.backupDir || path.join(process.env.LOCALAPPDATA || os.tmpdir(), 'ClaudeLocal', 'chrome-flag-backup', stamp);
  const res = { changed: [], already: [], failed: [], backup: backupDir };
  // שולחן העבודה האמיתי (במחשב הזה הוא בתוך OneDrive) — דרך ה-API של Windows
  let roots = o.roots;
  if (!roots) { const d = await ps(`[Environment]::GetFolderPath('Desktop'); [Environment]::GetFolderPath('Startup')`); roots = [...lnkRoots(), ...d.out.split(/\r?\n/).map(s => s.trim()).filter(Boolean)]; }
  const files = []; const walk = (d, depth) => { if (depth > 6) return; let es; try { es = fs.readdirSync(d, { withFileTypes: true }); } catch { return; } for (const e of es) { const p = path.join(d, e.name); if (e.isDirectory()) walk(p, depth + 1); else if (/\.lnk$/i.test(e.name)) files.push(p); } };
  for (const r of roots) walk(r, 0);
  if (files.length) {
    const lst = path.join(os.tmpdir(), 'cl-lnk-' + process.pid + '.txt'); fs.writeFileSync(lst, files.join('\n'), 'utf8');
    const r = await ps(`Add-Type -TypeDefinition @'\n${LNK_CS}\n'@\nforeach ($f in [IO.File]::ReadAllLines(${q(lst)}, [Text.Encoding]::UTF8)) { try { 'LNK ' + $f + '\t' + [CL.L]::Read($f) } catch { 'ERR ' + $f } }`, 120000);
    try { fs.unlinkSync(lst); } catch { }
    const items = []; for (const line of r.out.split(/\r?\n/)) { const m = /^LNK (.*?)\t(.*?)\t(.*)$/.exec(line); if (m && CHROME_RE.test(m[2])) items.push({ file: m[1], target: m[2], args: m[3] }); }
    const todo = []; for (const it of items) { const na = withSwitch(it.args); if (na == null) res.already.push(it.file); else todo.push({ ...it, newArgs: na }); }
    if (todo.length && !o.dryRun) {
      fs.mkdirSync(path.join(backupDir, 'lnk'), { recursive: true });
      todo.forEach((t, i) => { try { fs.copyFileSync(t.file, path.join(backupDir, 'lnk', i + '-' + path.basename(t.file))); } catch { } });
      fs.writeFileSync(path.join(backupDir, 'lnk.json'), JSON.stringify(todo.map((t, i) => ({ file: t.file, copy: i + '-' + path.basename(t.file), target: t.target, args: t.args })), null, 1));
      // AppUserModelID לפני ואחרי — חייב להישאר זהה (אחרת הסמל בשורת המשימות מתפצל) → אחרת משחזרים מהגיבוי
      const job = path.join(os.tmpdir(), 'cl-lnkjob-' + process.pid + '.json'); fs.writeFileSync(job, JSON.stringify(todo.map(t => ({ f: t.file, a: t.newArgs }))), 'utf8');
      const w = await ps(`Add-Type -TypeDefinition @'\n${LNK_CS}\n'@\n$sh = New-Object -ComObject Shell.Application
function Aumid($f) { try { $d = $sh.Namespace([IO.Path]::GetDirectoryName($f)); $i = $d.ParseName([IO.Path]::GetFileName($f)); return [string]$i.ExtendedProperty('System.AppUserModel.ID') } catch { return '?' } }
foreach ($j in (Get-Content -Raw -Encoding UTF8 ${q(job)} | ConvertFrom-Json)) { try { $b = Aumid $j.f; [CL.L]::SetArgs($j.f, $j.a); $a2 = Aumid $j.f; $chk = ([CL.L]::Read($j.f) -split "\`t")[1]; 'OK ' + $j.f + '\t' + $b + '\t' + $a2 + '\t' + $chk } catch { 'FAIL ' + $j.f + '\t' + $_.Exception.Message } }`, 120000);
      try { fs.unlinkSync(job); } catch { }
      const L = todo.map((t, i) => ({ ...t, copy: path.join(backupDir, 'lnk', i + '-' + path.basename(t.file)) }));
      for (const line of w.out.split(/\r?\n/)) {
        let m = /^OK (.*?)\t(.*?)\t(.*?)\t(.*)$/.exec(line);
        if (m) { const t = L.find(x => x.file === m[1]); const aumidOk = m[2] === m[3]; if (aumidOk && m[4].split(/\s+/).includes(SWITCH)) res.changed.push({ what: 'lnk', file: m[1], aumid: m[2] }); else { try { if (t) fs.copyFileSync(t.copy, t.file); } catch { } res.failed.push({ what: 'lnk', file: m[1], error: aumidOk ? 'המתג לא נשמר' : 'AppUserModelID השתנה — שוחזר מהגיבוי' }); } continue; }
        m = /^FAIL (.*?)\t(.*)$/.exec(line); if (m) res.failed.push({ what: 'lnk', file: m[1], error: m[2] });
      }
    } else if (todo.length) for (const t of todo) res.changed.push({ what: 'lnk', file: t.file, dryRun: true });
  }
  // פתיחת קישורים (ChromeHTML / ChromePDF): עותק ב-HKCU שמסתיר את HKLM, עם המתג לפני --single-argument
  const regRoot = o.regRoot || 'HKCU\\Software\\Classes';
  for (const progId of ['ChromeHTML', 'ChromePDF']) {
    const hku = `${regRoot}\\${progId}`, hkm = `HKLM\\Software\\Classes\\${progId}`;
    const r = await ps(`$u = 'Registry::' + ${q(hku)}; $m = 'Registry::' + ${q(hkm)}
$cu = (Get-ItemProperty -LiteralPath ($u + '\\shell\\open\\command') -ErrorAction SilentlyContinue).'(default)'
$cm = (Get-ItemProperty -LiteralPath ($m + '\\shell\\open\\command') -ErrorAction SilentlyContinue).'(default)'
'U ' + $cu; 'M ' + $cm; 'UEXISTS ' + (Test-Path -LiteralPath $u)`);
    const cu = ((/^U (.*)$/m.exec(r.out) || [])[1] || '').trim(), cm = ((/^M (.*)$/m.exec(r.out) || [])[1] || '').trim(), uExists = /UEXISTS True/.test(r.out);
    const cur = cu || cm; if (!cur) continue;
    if (cur.includes(SWITCH)) { res.already.push(hku); continue; }
    const neu = cur.replace(/^("[^"]*chrome\.exe"|\S*chrome\.exe)\s*/i, (x, exe) => exe + ' ' + SWITCH + ' ');
    if (neu === cur) { res.failed.push({ what: 'reg', key: hku, error: 'פקודה לא מוכרת: ' + cur.slice(0, 120) }); continue; }
    if (o.dryRun) { res.changed.push({ what: 'reg', key: hku, to: neu, dryRun: true }); continue; }
    fs.mkdirSync(backupDir, { recursive: true });
    fs.appendFileSync(path.join(backupDir, 'reg.json'), JSON.stringify({ key: hku, existed: uExists, old: cu || null }) + '\n');
    const w = await ps(`$u = 'Registry::' + ${q(hku)}
if (-not (Test-Path -LiteralPath $u)) { & reg.exe copy ${q(hkm)} ${q(hku)} /s /f | Out-Null }
if (-not (Test-Path -LiteralPath ($u + '\\shell\\open\\command'))) { New-Item -Path ($u + '\\shell\\open\\command') -Force | Out-Null }
Set-ItemProperty -LiteralPath ($u + '\\shell\\open\\command') -Name '(default)' -Value ${q(neu)}
(Get-ItemProperty -LiteralPath ($u + '\\shell\\open\\command')).'(default)'`);
    if (w.out.includes(SWITCH)) res.changed.push({ what: 'reg', key: hku, to: neu }); else res.failed.push({ what: 'reg', key: hku, error: (w.err || w.out).slice(0, 200) });
  }
  // הפתיחה האוטומטית של Chrome בכניסה למחשב (Run → GoogleChromeAutoLaunch_*)
  const runKey = o.runKey || 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run';
  { const r = await ps(`$k = Get-ItemProperty -LiteralPath ('Registry::' + ${q(runKey)}) -ErrorAction SilentlyContinue; if ($k) { $k.PSObject.Properties | Where-Object { $_.Name -like 'GoogleChromeAutoLaunch*' } | ForEach-Object { 'RUN ' + $_.Name + '\t' + $_.Value } }`);
    for (const line of r.out.split(/\r?\n/)) { const m = /^RUN (.*?)\t(.*)$/.exec(line); if (!m) continue; const [, name, val] = m;
      if (val.includes(SWITCH)) { res.already.push(runKey + '\\' + name); continue; }
      const neu = val.replace(/^("[^"]*chrome\.exe"|\S*chrome\.exe)\s*/i, (x, exe) => exe + ' ' + SWITCH + ' ');
      if (neu === val) { res.failed.push({ what: 'run', key: name, error: 'ערך לא מוכר' }); continue; }
      if (o.dryRun) { res.changed.push({ what: 'run', key: name, to: neu, dryRun: true }); continue; }
      fs.mkdirSync(backupDir, { recursive: true }); fs.appendFileSync(path.join(backupDir, 'run.json'), JSON.stringify({ key: runKey, name, old: val }) + '\n');
      const w = await ps(`Set-ItemProperty -LiteralPath ('Registry::' + ${q(runKey)}) -Name ${q(name)} -Value ${q(neu)}; (Get-ItemProperty -LiteralPath ('Registry::' + ${q(runKey)})).PSObject.Properties[${q(name)}].Value`);
      res.changed.push({ what: 'run', key: name, to: neu, verified: w.out.includes(SWITCH) }); }
  }
  if (!o.dryRun && (res.changed.length || res.failed.length)) { try { fs.mkdirSync(backupDir, { recursive: true }); fs.writeFileSync(path.join(backupDir, 'result.json'), JSON.stringify(res, null, 1)); } catch { } }
  return res;
}
/** revert(backupDir) — מחזיר הכל בדיוק כמו שהיה: קיצורי הדרך מהעותקים, מפתחות הרישום לערך הקודם (ומפתח שנוצר — נמחק) */
async function revert(backupDir) {
  const out = { restored: [], failed: [] };
  try { for (const l of JSON.parse(fs.readFileSync(path.join(backupDir, 'lnk.json'), 'utf8'))) { try { fs.copyFileSync(path.join(backupDir, 'lnk', l.copy), l.file); out.restored.push(l.file); } catch (e) { out.failed.push({ file: l.file, error: e.message }); } } } catch { }
  try { for (const line of fs.readFileSync(path.join(backupDir, 'reg.json'), 'utf8').split('\n').filter(Boolean)) { const r = JSON.parse(line);
    const w = r.existed ? await ps(`Set-ItemProperty -LiteralPath ('Registry::' + ${q(r.key + '\\shell\\open\\command')}) -Name '(default)' -Value ${q(r.old || '')}`) : await ps(`Remove-Item -LiteralPath ('Registry::' + ${q(r.key)}) -Recurse -Force -ErrorAction SilentlyContinue`);
    (w.ok ? out.restored : out.failed).push(r.key); } } catch { }
  try { for (const line of fs.readFileSync(path.join(backupDir, 'run.json'), 'utf8').split('\n').filter(Boolean)) { const r = JSON.parse(line); const w = await ps(`Set-ItemProperty -LiteralPath ('Registry::' + ${q(r.key)}) -Name ${q(r.name)} -Value ${q(r.old)}`); (w.ok ? out.restored : out.failed).push(r.name); } } catch { }
  return out;
}
module.exports = { SWITCH, browserForSocket, apply, revert, withSwitch, withoutSwitch };
