'use strict';
// ============================================================
//  mesh-enroll.js — צימוד טלפון לרשת המחשבים + אימות שהוא שלך דרך חשבון Claude ("witness login").
//
//  1. במחשב: "📱 חבר טלפון" פותח חלון צימוד (10 דקות, שימוש אחד): QR + קוד של 20 תווים (4 לאיתור + 80 ביט סוד).
//  2. הטלפון מתחבר לפורט הרשת עם TLS-PSK שהמפתח שלו נגזר מהסוד (identity "enroll-<nonce>") — רק מי שרואה את המסך
//     יכול להשלים את ה-handshake, ובאותו רגע הטלפון יודע שזה המחשב הנכון (הגנה מפני דף התחברות מזויף).
//     מותר רק מהרשת הביתית/loopback, עד 5 ניסיונות לחלון.
//  3. החשבון: המחשב מריץ את ה-CLI הרשמי `claude auth login` בתיקיית CLAUDE_CONFIG_DIR זמנית (לא נוגע בכניסה האמיתית שלו
//     ולא ב-VS Code). הקישור מגיע לטלפון (העתק / פתח / פתח במחשב / QR / שתף). האישור חוזר לבד: ל-CLI עצמו, דרך כל מחשב
//     אחר שלך (login-armed — מאזין זמני על אותו פורט), או דרך הטלפון (callback שהטלפון תפס). אחרת — הדבקת כתובת/קוד.
//  4. כשה-CLI מצליח: האימייל וה-org של החשבון שאישר מושווים לחשבון של המחשבים. תואם → הטלפון נכנס לרשת (via 'phone-account'),
//     ה-gossip מפיץ אותו לכל המחשבים. בכל תוצאה: `claude auth logout` בתיקייה הזמנית + מחיקתה (נבדק שנמחקה).
//  הטלפון לעולם לא מקבל טוקן/סיסמה/credentials — רק את הקישור והקוד החד-פעמיים, שחסרי ערך בלי ה-verifier שנשאר ב-CLI.
// ============================================================
const crypto = require('crypto'), dgram = require('dgram'), fs = require('fs'), os = require('os'), path = require('path'), http = require('http');

const CROCK = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
function b32(buf) { let bits = 0, val = 0, out = ''; for (const b of buf) { val = (val << 8) | b; bits += 8; while (bits >= 5) { out += CROCK[(val >>> (bits - 5)) & 31]; bits -= 5; } } if (bits > 0) out += CROCK[(val << (5 - bits)) & 31]; return out; }
function unb32(s) { s = String(s).toUpperCase().replace(/[^0-9A-Z]/g, '').replace(/O/g, '0').replace(/[IL]/g, '1'); let bits = 0, val = 0; const out = []; for (const ch of s) { const i = CROCK.indexOf(ch); if (i < 0) continue; val = (val << 5) | i; bits += 5; if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; } } return Buffer.from(out); }
const isPrivate = a => { a = String(a || '').replace(/^::ffff:/, ''); return /^(127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|169\.254\.)/.test(a) || a === '::1' || /^(fe80|fc|fd)/i.test(a); };
const sha256 = s => crypto.createHash('sha256').update(String(s)).digest('hex');
const now = () => Date.now();
const WINDOW_MS = 10 * 60 * 1000, MAX_TRIES = 5;
const URL_OK = /^https:\/\/(claude\.ai|claude\.com|platform\.claude\.com|console\.anthropic\.com)\//;

// אותו חשבון: אותו מייל, ואם לשניהם יש ארגון — אותו ארגון
const sameAcct = (a, x) => !!(a && x && a.email && x.email && String(a.email).toLowerCase() === String(x.email).toLowerCase() && (!x.orgId || !a.orgId || a.orgId === x.orgId));

// accountPolicy (אופציונלי): () => { allow:[{email,orgId}], deny:[...] } — החשבונות השמורים במחשב שסומנו "מאושר לאימות מכשירים".
// טלפון שמאשר את הצימוד באחד מהם מתקבל, גם אם זה לא החשבון הפעיל של המחשב; חשבון שסומן "לא מאושר" — נדחה.
function createEnroll({ mesh, claude, log = () => { }, accountId, otherAccount, accountPolicy, openUrl, allowCallbackPort, onChange = () => { } }) {
  const wins = new Map(); // nonce -> חלון צימוד
  let udp = null;

  const pub = w => ({ nonce: w.nonce, code: w.code, qr: w.qr, expiresAt: w.expiresAt, state: w.state, tries: w.tries, phone: w.phone ? { id: w.phone.id, name: w.phone.info.name || w.phone.info.model || '', model: w.phone.info.model || '', os: w.phone.info.os || '' } : null, account: w.account || null, allowed: allowedEmails(w), link: w.link ? { browserUrl: w.link.browserUrl, manualUrl: w.link.manualUrl, callbackPort: w.link.callbackPort, expiresAt: w.link.expiresAt } : null, error: w.error || null, log: w.log.slice(-30) });
  function note(w, state, text, extra) {
    if (state) w.state = state; w.log.push({ t: now(), state: w.state, text });
    for (const l of [...w.listeners]) try { l(pub(w)); } catch { }
    if (w.sess) w.sess.send({ t: 'enroll-state', state: w.state, text, ...(extra || {}) });
    onChange(w);
  }
  function fingerprint() { const c = mesh.self && mesh.self(); return crypto.createHash('sha256').update(String(mesh.id)).digest('base64url').slice(0, 16); }

  // ----- חלון צימוד -----
  function open() {
    for (const w of wins.values()) if (w.state === 'open' && !w.sess) close(w, 'replaced'); // חלון אחד פתוח בכל פעם
    const nonce = crypto.randomBytes(8).toString('hex'), secret = crypto.randomBytes(10), lookup = b32(crypto.randomBytes(3)).slice(0, 4);
    const code = (lookup + b32(secret)).match(/.{4}/g).join('-');
    const self = mesh.self(); const port = mesh.port();
    const w = { nonce, secret, lookup, code, createdAt: now(), expiresAt: now() + WINDOW_MS, tries: 0, state: 'open', listeners: new Set(), log: [], phone: null, sess: null, link: null, tmp: null, loginId: null };
    w.qr = `clmesh-enroll:1?pc=${mesh.id}&fp=${fingerprint()}&n=${nonce}&k=${b32(secret)}&a=${encodeURIComponent((self.ips || []).join(','))}&p=${port}&t=${w.expiresAt}`;
    wins.set(nonce, w); startUdp();
    w.timer = setTimeout(() => { if (['open', 'phone', 'link', 'needs-pc-approval'].includes(w.state)) close(w, 'expired'); }, WINDOW_MS + 1000);
    note(w, 'open', 'ממתין לטלפון…');
    return pub(w);
  }
  function close(w, why) {
    clearTimeout(w.timer);
    if (w.loginId) { try { claude.cancelLogin(w.loginId); } catch { } }
    cleanupTemp(w);
    if (w.link) { try { mesh.broadcast('login-disarm', { port: w.link.callbackPort, by: mesh.id }); } catch { } }
    if (!['done', 'rejected'].includes(w.state)) note(w, why === 'expired' ? 'expired' : 'cancelled', why === 'expired' ? 'פג תוקף החלון' : 'בוטל');
    if (w.sess) { try { w.sess.end(); } catch { } w.sess = null; }
    setTimeout(() => wins.delete(w.nonce), 60000);
    if (![...wins.values()].some(x => x.state === 'open')) stopUdp();
  }
  function cleanupTemp(w) {
    if (!w.tmp) return; const dir = w.tmp; w.tmp = null;
    Promise.resolve(claude.logout({ CLAUDE_CONFIG_DIR: dir }).catch(() => null)).finally(() => {
      try { fs.rmSync(dir, { recursive: true, force: true }); } catch { }
      log('[enroll] witness dir ' + (fs.existsSync(dir) ? 'NOT removed: ' : 'removed: ') + dir);
    });
  }
  // תיקיות witness ישנות (קריסה באמצע) — נמחקות בהפעלה
  try { for (const f of fs.readdirSync(os.tmpdir())) if (/^cl-witness-/.test(f)) { const p = path.join(os.tmpdir(), f); try { if (now() - fs.statSync(p).mtimeMs > 15 * 60000) fs.rmSync(p, { recursive: true, force: true }); } catch { } } } catch { }

  // ----- גילוי ברשת הביתית לקוד שהוקלד (UDP, רק כשחלון פתוח) -----
  function startUdp() {
    if (udp) return;
    try {
      udp = dgram.createSocket({ type: 'udp4', reuseAddr: true });
      udp.on('message', (msg, rinfo) => {
        const m = String(msg).match(/^CLMESH-ENROLL1 ([0-9A-Z]{4})$/); if (!m || !isPrivate(rinfo.address)) return;
        const w = [...wins.values()].find(x => x.state === 'open' && x.lookup === m[1]); if (!w) return;
        const r = Buffer.from('CLMESH-ENROLL1-PC ' + JSON.stringify({ pc: mesh.id, n: w.nonce, p: mesh.port() }));
        udp.send(r, rinfo.port, rinfo.address);
      });
      udp.on('error', e => { log('[enroll] udp ' + e.message); stopUdp(); });
      udp.bind(mesh.port() || 47400);
    } catch (e) { log('[enroll] udp ' + e.message); udp = null; }
  }
  function stopUdp() { try { udp && udp.close(); } catch { } udp = null; }

  // ----- TLS: identity "enroll-<nonce>" -----
  function psk(identity, sock) {
    const m = String(identity).match(/^enroll-([0-9a-f]{16})$/); if (!m) return null;
    const w = wins.get(m[1]); const addr = sock && (sock.remoteAddress || (sock._parent && sock._parent.remoteAddress));
    if (!w || w.state !== 'open' || w.sess || now() > w.expiresAt) return null;
    if (!isPrivate(addr)) { note(w, null, 'נדחה: ניסיון צימוד מחוץ לרשת הביתית (' + addr + ')'); return null; }
    if (w.tries >= MAX_TRIES) return null;
    w.tries++;
    return Buffer.from(crypto.hkdfSync('sha256', w.secret, Buffer.from('clmesh-enroll-v1'), Buffer.from(w.nonce), 32));
  }
  // ----- סשן צימוד על החיבור המוצפן: מסגרות JSON באותו פורמט כמו הרשת -----
  function onConn(sock, identity) {
    const nonce = String(identity).slice(7); const w = wins.get(nonce);
    if (!w || w.sess) return sock.destroy();
    let buf = Buffer.alloc(0);
    const sess = w.sess = {
      send: o => { try { const b = Buffer.from(JSON.stringify(o)); const h = Buffer.alloc(5); h.writeUInt32BE(b.length + 1, 0); h[4] = 1; sock.write(Buffer.concat([h, b])); } catch { } },
      end: () => { try { sock.end(); } catch { } }
    };
    sock.setNoDelay(true);
    sock.on('data', d => {
      buf = Buffer.concat([buf, d]);
      while (buf.length >= 5) { const len = buf.readUInt32BE(0); if (len < 1 || len > 1 << 20) return sock.destroy(); if (buf.length < 4 + len) break; const type = buf[4], body = buf.subarray(5, 4 + len); buf = buf.subarray(4 + len); if (type === 1) { try { handle(w, JSON.parse(body.toString('utf8'))); } catch (e) { log('[enroll] ' + e.message); } } }
    });
    sock.on('close', () => { if (w.sess === sess) { w.sess = null; if (!['done', 'rejected', 'expired', 'cancelled'].includes(w.state)) { note(w, 'open', 'הטלפון התנתק — אפשר לנסות שוב'); if (w.loginId) { try { claude.cancelLogin(w.loginId); } catch { } w.loginId = null; } cleanupTemp(w); w.link = null; } } });
    sock.on('error', () => { });
    note(w, 'phone', 'טלפון מתחבר…');
  }

  async function handle(w, m) {
    if (m.t === 'enroll-hello') {
      let card; try { card = mesh.verifyCard(m.card); } catch (e) { w.sess.send({ t: 'enroll-done', ok: false, error: 'כרטיס לא תקין: ' + e.message }); return; }
      w.phone = card;
      w.sess.send({ t: 'enroll-pc', card: mesh.card(), pc: mesh.id, name: (mesh.self().displayName || '') });
      note(w, 'phone', '📱 ' + (card.info.model || card.info.name || 'טלפון') + ' מחובר — בודק חשבון Claude…');
      // מול איזה חשבון משווים: של המחשב הזה, ואם הוא לא מחובר — של מחשב אחר ברשת שמחובר
      let pol = null; try { pol = accountPolicy ? await accountPolicy() : null; } catch { pol = null; }
      w.allow = ((pol && pol.allow) || []).filter(x => x && x.email); w.deny = ((pol && pol.deny) || []).filter(x => x && x.email);
      let acct = null; try { acct = await accountId(); } catch { }
      if (!acct || !acct.loggedIn) { try { acct = await otherAccount(); } catch { acct = null; } }
      const usable = acct && acct.loggedIn && acct.email && !w.deny.some(d => sameAcct(acct, d));
      if (usable) w.account = { email: acct.email, orgId: acct.orgId || null, by: acct.by || mesh.id };
      else if (w.allow.length) w.account = { email: w.allow[0].email, orgId: w.allow[0].orgId || null, by: mesh.id, saved: true }; // החשבון הפעיל לא מאושר / אין — חשבון שמור מאושר
      else { w.account = null; note(w, 'needs-pc-approval', acct && acct.loggedIn ? 'החשבון של המחשב לא מאושר לאימות מכשירים — אשר את הטלפון כאן במחשב' : 'אף מחשב לא מחובר לחשבון Claude — אשר את הטלפון כאן במחשב'); return; }
      return startWitness(w);
    }
    if (!w.phone) return;
    if (m.t === 'enroll-callback' && w.link) {
      const p = String(m.path || ''); const st = (p.match(/[?&]state=([^&]+)/) || [])[1];
      if (!/^\/callback\?/.test(p) || !st || sha256(decodeURIComponent(st)) !== w.link.stateHash) { w.sess.send({ t: 'enroll-callback-res', status: 400, body: 'invalid callback' }); return; }
      note(w, null, 'התקבל אישור מהטלפון — מעביר ל-Claude…');
      const r = await replay(w.link.callbackPort, p); w.sess.send({ t: 'enroll-callback-res', ...r }); return;
    }
    if (m.t === 'enroll-code' && w.loginId) { const ok = claude.submitLoginCode(w.loginId, String(m.code || '')); note(w, null, ok ? 'התקבל קוד מהטלפון — בודק…' : 'הקוד לא נמסר (הכניסה כבר לא פעילה)'); return; }
    if (m.t === 'enroll-open-pc' && w.link) { const u = String(m.url || ''); if (URL_OK.test(u) && (u === w.link.browserUrl || u === w.link.manualUrl)) { openUrl(u); note(w, null, '🌐 הקישור נפתח בדפדפן של המחשב הזה'); w.sess.send({ t: 'enroll-opened', on: mesh.id }); } return; }
    if (m.t === 'enroll-open-on' && w.link) { const u = String(m.url || ''); if (!URL_OK.test(u) || (u !== w.link.browserUrl && u !== w.link.manualUrl)) return; try { await mesh.rpc(String(m.pc || ''), 'open-url', { url: u }, 15000); note(w, null, '🌐 הקישור נפתח במחשב ' + (mesh.member(m.pc) ? (mesh.member(m.pc).name || (mesh.member(m.pc).info || {}).host || m.pc) : m.pc)); w.sess.send({ t: 'enroll-opened', on: m.pc }); } catch (e) { w.sess.send({ t: 'enroll-opened', on: m.pc, error: e.message }); } return; }
    if (m.t === 'enroll-relink' && !w.loginId && w.account) return startWitness(w);
    if (m.t === 'enroll-cancel') return close(w, 'cancelled');
  }

  function replay(port, p) {
    return new Promise(res => { const q = http.get({ host: '127.0.0.1', port, path: p, headers: { host: 'localhost:' + port } }, rs => { let b = ''; rs.on('data', d => (b += d)); rs.on('end', () => res({ status: rs.statusCode, headers: { 'content-type': rs.headers['content-type'] || 'text/html; charset=utf-8' }, body: b.slice(0, 200000) })); }); q.on('error', e => res({ status: 502, headers: { 'content-type': 'text/plain' }, body: e.message })); });
  }

  // הכניסה בטלפון התקבלה בחשבון a: מותר אם הוא החשבון שמולו בודקים או אחד השמורים-המאושרים, ולא אם סומן "לא מאושר"
  function isAllowed(w, a) {
    if (!a || !a.loggedIn || !a.email) return false;
    if ((w.deny || []).some(d => sameAcct(a, d))) return false;
    return sameAcct(a, w.account) || (w.allow || []).some(x => sameAcct(a, x));
  }
  function allowedEmails(w) {
    const out = []; const add = e => { e = String(e || '').toLowerCase(); if (e && !out.includes(e)) out.push(e); };
    if (w.account) add(w.account.email); for (const x of w.allow || []) add(x.email);
    return out;
  }
  async function startWitness(w) {
    w.tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'cl-witness-'));
    let l;
    try { l = await claude.startLogin({ capture: true, env: { CLAUDE_CONFIG_DIR: w.tmp }, registry: 'witness' }); }
    catch (e) { note(w, 'error', 'לא הצלחתי להתחיל כניסה: ' + e.message); cleanupTemp(w); return; }
    w.loginId = l.id;
    let s = null; for (let i = 0; i < 60; i++) { s = claude.getLogin(l.id); if (s && (s.browserUrl || s.status !== 'pending')) break; await new Promise(r => setTimeout(r, 250)); }
    if (!s || !s.browserUrl) { note(w, 'error', 'ה-CLI לא מסר קישור התחברות'); cleanupTemp(w); return; }
    const state = new URL(s.browserUrl).searchParams.get('state') || '';
    w.link = { browserUrl: s.browserUrl, manualUrl: s.url || null, callbackPort: s.callbackPort, stateHash: sha256(state), expiresAt: (s.startedAt || now()) + 10 * 60000 };
    allowCallbackPort(s.callbackPort, w.link.expiresAt);
    try { mesh.broadcast('login-armed', { port: s.callbackPort, stateHash: w.link.stateHash, by: mesh.id, until: w.link.expiresAt }); } catch { }
    w.sess && w.sess.send({ t: 'enroll-login', loginId: l.id, browserUrl: w.link.browserUrl, manualUrl: w.link.manualUrl, callbackPort: w.link.callbackPort, stateHash: w.link.stateHash, expiresAt: w.link.expiresAt, account: { email: w.account.email }, allowed: allowedEmails(w) });
    note(w, 'link', 'הקישור נשלח לטלפון — ממתין לאישור בדפדפן…');
    // מחכים לסוף הכניסה
    for (;;) {
      await new Promise(r => setTimeout(r, 400));
      const st = claude.getLogin(l.id); if (!st || st.status === 'pending') { if (!wins.has(w.nonce) || ['cancelled', 'expired'].includes(w.state)) return; continue; }
      try { mesh.broadcast('login-disarm', { port: w.link.callbackPort, by: mesh.id }); } catch { }
      w.loginId = null;
      if (st.status !== 'success') { note(w, 'link-failed', 'הכניסה לא הושלמה: ' + (st.error || st.status)); w.sess && w.sess.send({ t: 'enroll-login-failed', error: st.error || st.status }); cleanupTemp(w); w.link = null; return; }
      note(w, 'verifying', 'בודק שזה חשבון Claude מאושר…');
      let a = st.auth; if (!a) { try { a = await claude.authStatus({ CLAUDE_CONFIG_DIR: w.tmp }); } catch { } }
      const same = isAllowed(w, a);
      cleanupTemp(w);
      if (!same) { note(w, 'rejected', 'הקישור אושר בחשבון אחר (' + ((a && a.email) || '?') + ') — הטלפון לא נוסף'); w.sess && w.sess.send({ t: 'enroll-done', ok: false, error: 'other-account', email: (a && a.email) || null }); setTimeout(() => close(w, 'rejected'), 1500); return; }
      return admit(w, 'phone-account', a.email);
    }
  }
  function admit(w, via, email) {
    const card = w.phone.text;
    const r = mesh.acceptAccountHello(card, null, via);
    if (!r.ok) { note(w, 'rejected', 'לא הצלחתי להוסיף את הטלפון: ' + r.error); w.sess && w.sess.send({ t: 'enroll-done', ok: false, error: r.error }); return; }
    try { mesh.annotate(w.phone.id, { account: email || null, verifiedBy: mesh.id, verifiedAt: now(), via }); } catch { }
    note(w, 'done', '✓ ' + (w.phone.info.model || 'הטלפון') + ' נוסף לרשת' + (email ? ' · ' + email : ''));
    w.sess && w.sess.send({ t: 'enroll-done', ok: true, email: email || null, pc: mesh.id, port: mesh.port() });
    clearTimeout(w.timer); setTimeout(() => { if (w.sess) w.sess.end(); }, 1500); setTimeout(() => wins.delete(w.nonce), 120000);
    if (![...wins.values()].some(x => x.state === 'open')) stopUdp();
  }
  // אין אף מחשב מחובר ל-Claude: אישור ידני — רק מהמחשב עצמו (הנתיב חסום ממכשירים אחרים)
  function approveHere(nonce) { const w = wins.get(nonce); if (!w || !w.phone || w.state !== 'needs-pc-approval') return { ok: false, error: 'אין טלפון שממתין לאישור' }; admit(w, 'phone-pc', null); return { ok: true }; }
  function cancel(nonce) { const w = wins.get(nonce); if (!w) return false; close(w, 'cancelled'); return true; }
  function get(nonce) { const w = wins.get(nonce); return w ? pub(w) : null; }
  function subscribe(nonce, fn) { const w = wins.get(nonce); if (!w) return null; w.listeners.add(fn); fn(pub(w)); return () => w.listeners.delete(fn); }
  return { open, psk, onConn, approveHere, cancel, get, subscribe, _b32: b32, _unb32: unb32 };
}

module.exports = { createEnroll, b32, unb32, isPrivate };
