'use strict';
// ============================================================
//  Local cost estimate for Anthropic usage.
//  Anthropic does NOT expose remaining credit balance to a normal user API key,
//  so we track SPEND locally (tokens x list price) and show remaining =
//  (the budget the user says they loaded) - (tracked spend). Prices are the
//  public list prices, USD per 1,000,000 tokens (table of 2026-11-03).
//  cw = cache write (5 min, 1.25x input), cr = cache read.
// ============================================================
const P = (inp, out, cr, label) => ({ in: inp, out, cw: +(inp * 1.25).toFixed(4), cr, label });
// most specific first: 'opus-5-5' before 'opus-5', 'sonnet-5-5' before 'sonnet-5'
const TABLE = [
  ['fable-5-2', P(8, 40, 0.20, 'Fable 5.2')], ['mythos-5-2', P(8, 40, 0.20, 'Mythos 5.2')],
  ['fable-5-1', P(10, 50, 1.00, 'Fable 5.1')], ['mythos-5-1', P(10, 50, 1.00, 'Mythos 5.1')],
  ['fable', P(10, 50, 1.00, 'Fable')], ['mythos', P(10, 50, 1.00, 'Mythos')],
  ['opus-5-5', P(4, 20, 0.20, 'Opus 5.5')],
  ['opus-5', P(5, 25, 0.50, 'Opus 5')], ['opus-4-8', P(5, 25, 0.50, 'Opus 4.8')],
  ['opus-4-7', P(5, 25, 0.50, 'Opus 4.7')], ['opus-4-6', P(5, 25, 0.50, 'Opus 4.6')],
  ['opus', P(5, 25, 0.50, 'Opus')],
  ['sonnet-5-5', P(2, 10, 0.10, 'Sonnet 5.5')], ['sonnet-5', P(2, 10, 0.20, 'Sonnet 5')],
  ['sonnet-4-6', P(3, 15, 0.30, 'Sonnet 4.6')], ['sonnet', P(3, 15, 0.30, 'Sonnet')],
  ['haiku-5-5', P(0.10, 0.50, 0.01, 'Haiku 5.5')], ['haiku-4-5', P(1, 5, 0.10, 'Haiku 4.5')],
  ['haiku', P(1, 5, 0.10, 'Haiku')]
];
const PRICES = Object.fromEntries(TABLE);
const DEFAULT = PRICES['opus-5-5'];

function priceFor(model) {
  const id = String(model || '').toLowerCase();
  for (const [k, p] of TABLE) if (id.includes(k)) return p;
  return DEFAULT;
}

// Server tools: web search is billed $10 per 1,000 searches; web fetch has no extra fee (only the tokens).
const WEB_SEARCH_USD = 0.01;

// usage object from the API: { input_tokens, output_tokens, cache_read_input_tokens, cache_creation_input_tokens,
//                              server_tool_use: { web_search_requests, web_fetch_requests } }
function costOf(model, u) {
  const p = priceFor(model);
  u = u || {};
  const inp = u.input_tokens || 0;
  const out = u.output_tokens || 0;
  const cr = u.cache_read_input_tokens || 0;
  const cw = u.cache_creation_input_tokens || 0;
  // כתיבה למטמון של שעה (Claude Code משתמש בה) עולה פי 2 מהקלט; של 5 דקות פי 1.25
  const cw1h = Math.min(cw, (u.cache_creation && Number(u.cache_creation.ephemeral_1h_input_tokens)) || 0);
  const searches = (u.server_tool_use && Number(u.server_tool_use.web_search_requests)) || 0;
  return (inp * p.in + out * p.out + (cw - cw1h) * p.cw + cw1h * p.in * 2 + cr * p.cr) / 1e6 + searches * WEB_SEARCH_USD;
}

module.exports = { priceFor, costOf, PRICES, WEB_SEARCH_USD };
