'use strict';
// ============================================================
//  updater.js — עדכונים אוטומטיים מ-GitHub Releases (REQUESTS-8 ד).
//  כל התקנה — של הבעלים וגם של כל מי שהוריד את התוכנה, עם חשבון Claude משלו — מושכת גרסאות ישירות מ-GitHub,
//  בלי תלות בשרת של הבעלים.
//    1. manifest.json חתום (ed25519; המפתח הפרטי רק אצל הבעלים, הציבורי כאן) — חתימה שגויה = לא נוגעים בכלום
//    2. קוד האפליקציה (zip) נבדק מול ה-sha256 שבמניפסט, ונפרס ל-%LOCALAPPDATA%\ClaudeLocal\live\<build>
//    3. כשאין עבודה רצה — השרת עולה מחדש מהקוד החדש (אותו מנגנון של "קוד חי" / Ctrl+Shift+R), והחלון נטען מחדש
//  מצבים (הגדרה updates.mode): auto (ברירת מחדל) · manual — כפתור "יש עדכון · עדכן" · off.
//  מחשב שמצא גרסה חדשה מודיע לכל המחשבים המחוברים (רשת המחשבים) → הם בודקים מיד. ה-APK מקבל את אותה גרסה דרך המחשב.
// ============================================================
const fs = require('fs'), path = require('path'), os = require('os'), crypto = require('crypto'), https = require('https'), http = require('http');
const { execFile } = require('child_process');

const PUBLIC_KEY_PEM = '-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAO48ff/EjsPRpO8bn5RI/4O0/4CmaQiOgYwHZMEtM7Mk=\n-----END PUBLIC KEY-----\n';
// the public feed: branch 'feed' of github.com/zivitamar/claude-local-updates (always the latest release only), via GitHub's CDN
const DEFAULT_FEED = 'https://raw.githubusercontent.com/zivitamar/claude-local-updates/feed/';
const CHECK_EVERY_MS = 30 * 60 * 1000;

function canonical(v) {
  if (Array.isArray(v)) return '[' + v.map(canonical).join(',') + ']';
  if (v && typeof v === 'object') return '{' + Object.keys(v).filter(k => k !== 'sig').sort().map(k => JSON.stringify(k) + ':' + canonical(v[k])).join(',') + '}';
  return JSON.stringify(v);
}
function verifyManifest(m, pem = PUBLIC_KEY_PEM) {
  try { return !!(m && m.sig && crypto.verify(null, Buffer.from(canonical(m)), pem, Buffer.from(m.sig, 'base64'))); } catch { return false; }
}
function signManifest(m, privatePem) { return { ...m, sig: crypto.sign(null, Buffer.from(canonical(m)), privatePem).toString('base64') }; }

// GET (follows redirects); to a buffer or straight to a file. raw.githubusercontent.com caches ~5 min — a cache-buster per check
function get(url, { toFile, maxBytes = 300e6, timeoutMs = 120000, redirects = 6 } = {}) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith('https:') ? https : http;
    const req = lib.get(url, { headers: { 'user-agent': 'ClaudeLocal-Updater', accept: '*/*' }, timeout: timeoutMs }, res => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && redirects > 0) { res.resume(); return resolve(get(new URL(res.headers.location, url).href, { toFile, maxBytes, timeoutMs, redirects: redirects - 1 })); }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error('HTTP ' + res.statusCode + ' ' + url)); }
      const hash = crypto.createHash('sha256'); let n = 0; const chunks = []; const out = toFile ? fs.createWriteStream(toFile) : null;
      res.on('data', d => { n += d.length; if (n > maxBytes) { req.destroy(new Error('too big')); return; } hash.update(d); if (out) out.write(d); else chunks.push(d); });
      res.on('end', () => { const sha256 = hash.digest('hex'); if (out) out.end(() => resolve({ file: toFile, size: n, sha256 })); else resolve({ buf: Buffer.concat(chunks), size: n, sha256 }); });
      res.on('error', reject);
    });
    req.on('timeout', () => req.destroy(new Error('timeout ' + url)));
    req.on('error', reject);
  });
}
const sha256File = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const newer = (a, b) => String(a || '') > String(b || '');
function unzip(zip, dir) { // Windows 10+ / macOS / Linux: tar (bsdtar) opens zip
  fs.mkdirSync(dir, { recursive: true });
  return new Promise((res, rej) => execFile(process.platform === 'win32' ? path.join(process.env.SystemRoot || 'C:/Windows', 'System32', 'tar.exe') : 'tar', ['-xf', zip, '-C', dir], { windowsHide: true, timeout: 120000 }, e => e ? rej(e) : res()));
}

// בדיקת חבילה לפני התקנה: כל קובץ JS של השרת עובר הידור (שגיאת תחביר = שבור) וכל קובץ מקומי שנטען חייב להימצא בחבילה
function verifyPackage(dir) {
  // רק הקבצים שהשרת באמת טוען: גרף ה-require מ-server.js (קבצי worker / ESM שלא נטענים לא נבדקים)
  const vm = require('vm'), problems = [], files = [], seen = new Set();
  const queue = [path.join(dir, 'server.js')];
  for (const extra of ['main.js', 'server-child.js', 'host-child.js']) { const p = path.join(dir, 'electron', extra); if (fs.existsSync(p)) queue.push(p); }
  while (queue.length) {
    const f = queue.shift(); if (seen.has(f)) continue; seen.add(f); files.push(f);
    let src = ''; try { src = fs.readFileSync(f, 'utf8'); } catch { continue; }
    for (const m of src.matchAll(/require\(\s*['"](\.{1,2}\/[^'"]+)['"]\s*\)/g)) {
      const base = path.resolve(path.dirname(f), m[1]);
      const hit = [base, base + '.js', path.join(base, 'index.js')].find(c => { try { return fs.statSync(c).isFile(); } catch { return false; } });
      if (hit && /\.js$/.test(hit)) queue.push(hit);
    }
  }
  for (const f of files) {
    let src; try { src = fs.readFileSync(f, 'utf8'); } catch { problems.push(path.relative(dir, f) + ': unreadable'); continue; }
    try { new vm.Script('(function (exports, require, module, __filename, __dirname) {' + src.replace(/^#!.*/, '') + '\n})', { filename: f }); }
    catch (e) { problems.push(path.relative(dir, f) + ': ' + e.message); }
    for (const m of src.matchAll(/require\(\s*['"](\.{1,2}\/[^'"]+)['"]\s*\)/g)) {
      const base = path.resolve(path.dirname(f), m[1]);
      if (![base, base + '.js', base + '.json', path.join(base, 'index.js')].some(c => { try { return fs.statSync(c).isFile(); } catch { return false; } })) problems.push(path.relative(dir, f) + ": require('" + m[1] + "') missing");
    }
  }
  return problems;
}

function createUpdater({ dataDir, liveDir, currentBuild, version, getMode, isIdle, restart, emit = () => { }, broadcast = () => { }, log = () => { }, enabled = true, feed }) {
  feed = String(feed || process.env.CLAUDE_UPDATES_URL || DEFAULT_FEED); if (!feed.endsWith('/')) feed += '/';
  const upDir = path.join(dataDir, 'updates'); fs.mkdirSync(upDir, { recursive: true });
  const st = { enabled, feed, current: currentBuild(), version, latest: null, status: enabled ? 'idle' : 'disabled', error: null, lastCheck: 0, staged: null, applying: false };
  let checking = null, idleT = null, timer = null;
  const pub = () => ({ enabled: st.enabled, mode: getMode(), current: st.current, version: st.version, latest: st.latest ? { build: st.latest.build, version: st.latest.version, notes: st.latest.notes || '', publishedAt: st.latest.publishedAt, apk: st.latest.apk ? { versionCode: st.latest.apk.versionCode, versionName: st.latest.apk.versionName, size: st.latest.apk.size, sha256: st.latest.apk.sha256 } : null } : null, available: !!(st.latest && newer(st.latest.build, st.current)), status: st.status, error: st.error, lastCheck: st.lastCheck, staged: !!st.staged });
  const changed = () => { try { emit('update_status', pub()); } catch { } };

  async function check(reason = 'timer') {
    if (!st.enabled || getMode() === 'off') return pub();
    if (checking) return checking;
    checking = (async () => {
      try {
        const r = await get(feed + 'manifest.json?t=' + Math.floor(Date.now() / 60000), { maxBytes: 1e6, timeoutMs: 30000 });
        const m = JSON.parse(r.buf.toString('utf8'));
        if (!verifyManifest(m)) throw new Error('חתימה לא תקינה במניפסט העדכון — לא מעדכנים');
        st.latest = m; st.lastCheck = Date.now(); st.error = null;
        if (newer(m.build, st.current)) {
          if (st.status !== 'ready' && !st.applying) st.status = 'available';
          log('[update] new version ' + m.build + ' (current ' + st.current + ', ' + reason + ')');
          if (reason !== 'mesh') { try { broadcast({ build: m.build }); } catch { } }
          changed();
          if (getMode() === 'auto') { await stage(); applyWhenIdle(); }
        } else { st.status = 'uptodate'; changed(); }
      } catch (e) { st.error = e.message; st.status = st.latest && newer(st.latest.build, st.current) ? st.status : 'error'; st.lastCheck = Date.now(); log('[update] check failed: ' + e.message); changed(); }
      return pub();
    })().finally(() => { checking = null; });
    return checking;
  }

  async function stage() {
    const m = st.latest; if (!m || !m.app || !newer(m.build, st.current)) return null;
    if (st.staged && st.staged.build === m.build) return st.staged;
    st.status = 'downloading'; changed();
    const zip = path.join(upDir, 'app-' + m.build + '.zip');
    const r = await get(feed + m.app.file, { toFile: zip });
    if (r.sha256 !== m.app.sha256) { try { fs.unlinkSync(zip); } catch { } st.status = 'error'; st.error = 'הקובץ שהורד לא תואם לחתימה (sha256)'; changed(); throw new Error(st.error); }
    const dir = path.join(liveDir, m.build + '-update');
    fs.rmSync(dir, { recursive: true, force: true });
    await unzip(zip, dir);
    if (!fs.existsSync(path.join(dir, 'server.js'))) { st.status = 'error'; st.error = 'חבילת העדכון לא שלמה'; changed(); throw new Error(st.error); }
    // הבעלים 27/11 ("לעולם לא קורס"): חבילה שקובץ בה חסר / שבור לא מותקנת בכלל — נשארים על הגרסה העובדת
    const bad = verifyPackage(dir);
    if (bad.length) { try { fs.rmSync(dir, { recursive: true, force: true }); } catch { } st.status = 'error'; st.error = 'העדכון ' + m.build + ' שבור ולא הותקן: ' + bad.slice(0, 3).join(' · '); log('[update] REJECTED ' + m.build + ': ' + bad.join(' | ')); changed(); throw new Error(st.error); }
    fs.writeFileSync(path.join(dir, 'build-info.json'), JSON.stringify({ builtAt: m.build, source: 'github' }));
    try { fs.unlinkSync(zip); } catch { }
    st.staged = { build: m.build, dir, version: m.version };
    st.status = 'ready'; changed(); log('[update] ' + m.build + ' ready in ' + dir);
    return st.staged;
  }
  function applyWhenIdle() {
    clearInterval(idleT);
    const tryNow = () => { if (st.applying || !st.staged) return; if (getMode() !== 'auto') { clearInterval(idleT); return; } if (isIdle()) { clearInterval(idleT); apply().catch(() => { }); } };
    idleT = setInterval(tryNow, 15000); tryNow();
  }
  // the new code becomes "live code"; the app restarts its server from it and reloads the window
  async function apply() {
    if (st.applying) return pub();
    if (!st.staged) await stage();
    if (!st.staged) return pub();
    st.applying = true; st.status = 'applying'; changed();
    fs.mkdirSync(liveDir, { recursive: true });
    fs.writeFileSync(path.join(liveDir, 'current.json'), JSON.stringify({ dir: st.staged.dir, builtAt: st.staged.build, version: st.staged.version, source: 'github' }));
    log('[update] applying ' + st.staged.build + ' → restart');
    setTimeout(() => { try { restart(); } catch (e) { log('[update] restart failed: ' + e.message); } }, 900);
    return pub();
  }
  // the APK of the same release, for the owner's phones (they ask their PC over the encrypted mesh)
  async function apkFile() {
    const m = st.latest || (await check('apk'), st.latest); if (!m || !m.apk) return null;
    const f = path.join(upDir, m.apk.file);
    if (!fs.existsSync(f) || sha256File(f) !== m.apk.sha256) { const r = await get(feed + m.apk.file, { toFile: f }); if (r.sha256 !== m.apk.sha256) { try { fs.unlinkSync(f); } catch { } throw new Error('APK לא תואם לחתימה'); } }
    return { ...m.apk, file: f }; // the full path last: the manifest's own `file` is only the name (11-25: it overwrote the path → HTTP 500)
  }
  function start() {
    if (!st.enabled) return;
    setTimeout(() => check('start'), Number(process.env.CLAUDE_UPDATES_FIRST_MS) || 60000);
    timer = setInterval(() => check('timer'), Number(process.env.CLAUDE_UPDATES_EVERY_MS) || CHECK_EVERY_MS);
  }
  function stop() { clearInterval(timer); clearInterval(idleT); }
  return { check, stage, apply, apkFile, start, stop, status: pub, onMesh: d => { if (d && newer(d.build, st.current)) check('mesh'); } };
}

module.exports = { createUpdater, verifyPackage,verifyManifest, signManifest, canonical, get, sha256File, PUBLIC_KEY_PEM, DEFAULT_FEED };
