// ============================================================
//  Claude Local — "המרכזיה": Cloudflare Worker + Durable Object (נפרס אוטומטית לחשבון Cloudflare של המשתמש).
//  רק צינור בתים: התוכן כבר מוצפן מקצה לקצה ע"י רשת המחשבים (TLS-PSK / הלחיצה של הטלפון) — המרכזיה לא יכולה לקרוא אותו.
//   GET /c/<net>?id=<dev>&k=<key>        → WebSocket בקרה (אחד לכל מכשיר): נוכחות + "מישהו רוצה להתחבר אליך"
//        ← {t:'peers', ids:[…]} · {t:'incoming', from, sid}   → {t:'dial', to, sid}
//   GET /d/<net>/<sid>?id=<dev>&k=<key>  → WebSocket נתונים: שני צדדים עם אותו sid מחוברים זה לזה (בינארי, כמו שהוא)
//   GET /health                           → "ok"
//  אימות: k = מפתח הרשת (סוד שנקבע בהתקנה, משותף רק בין המכשירים שלך דרך הרשת המוצפנת). DO אחד לכל רשת.
//  WebSocket Hibernation: חיבור רדום לא עולה כסף; ping → pong אוטומטי בלי להעיר את האובייקט.
// ============================================================
const ok = (s, t = 'ok', type = 'text/plain') => new Response(t, { status: s, headers: { 'content-type': type, 'cache-control': 'no-store' } });
const ID_RE = /^[0-9a-f]{16}$/, NET_RE = /^[0-9a-f]{32}$/, SID_RE = /^[0-9a-f]{16,40}$/;

export default {
  async fetch(req, env) {
    const u = new URL(req.url);
    if (u.pathname === '/health') return ok(200, 'ok');
    const m = u.pathname.match(/^\/(c|d)\/([0-9a-f]{32})(?:\/([0-9a-f]{16,40}))?$/);
    if (!m) return ok(404, 'not found');
    if (req.headers.get('Upgrade') !== 'websocket') return ok(426, 'websocket only');
    // the key is checked in constant time against the secret set at install
    const k = u.searchParams.get('k') || '';
    if (!env.HUB_KEY || !(await same(k, env.HUB_KEY))) return ok(403, 'forbidden');
    if (!NET_RE.test(m[2]) || !ID_RE.test(u.searchParams.get('id') || '')) return ok(400, 'bad id');
    const stub = env.HUB.get(env.HUB.idFromName(m[2]), { locationHint: env.LOCATION || undefined });
    return stub.fetch(req);
  }
};
async function same(a, b) {
  const enc = new TextEncoder(), x = await crypto.subtle.digest('SHA-256', enc.encode(a)), y = await crypto.subtle.digest('SHA-256', enc.encode(b));
  return crypto.subtle.timingSafeEqual ? crypto.subtle.timingSafeEqual(x, y) : new Uint8Array(x).every((v, i) => v === new Uint8Array(y)[i]);
}

export class Hub {
  constructor(state, env) {
    this.state = state; this.env = env;
    try { this.state.setWebSocketAutoResponse(new WebSocketRequestResponsePair('{"t":"ping"}', '{"t":"pong"}')); } catch { }
  }
  async fetch(req) {
    const u = new URL(req.url), m = u.pathname.match(/^\/(c|d)\/[0-9a-f]{32}(?:\/([0-9a-f]{16,40}))?$/);
    const id = u.searchParams.get('id');
    const pair = new WebSocketPair(); const [client, server] = Object.values(pair);
    if (m[1] === 'c') {
      // one control socket per device: a new one replaces the old (phone switched network / PC restarted)
      for (const old of this.state.getWebSockets('c:' + id)) { try { old.close(4000, 'replaced'); } catch { } }
      this.state.acceptWebSocket(server, ['c', 'c:' + id]);
      server.serializeAttachment({ kind: 'c', id });
      this.peers();
    } else {
      const sid = m[2]; if (!SID_RE.test(sid || '')) return new Response('bad sid', { status: 400 });
      const same = this.state.getWebSockets('d:' + sid);
      if (same.length >= 2) return new Response('busy', { status: 409 });
      this.state.acceptWebSocket(server, ['d', 'd:' + sid]);
      server.serializeAttachment({ kind: 'd', id, sid, at: Date.now() });
      // both ends here → tell each one the pipe is open (bytes may flow)
      if (same.length === 1) for (const w of [...same, server]) { try { w.send('{"t":"open"}'); } catch { } }
    }
    return new Response(null, { status: 101, webSocket: client });
  }
  live(tag, except) { return this.state.getWebSockets(tag).filter(w => w !== except && w.readyState === 1); }
  peers(except) {
    const ids = [...new Set(this.live('c', except).map(w => { try { return w.deserializeAttachment().id; } catch { return null; } }).filter(Boolean))];
    const msg = JSON.stringify({ t: 'peers', ids, at: Date.now() });
    for (const w of this.live('c', except)) { try { w.send(msg); } catch { } }
  }
  async webSocketMessage(ws, data) {
    let a; try { a = ws.deserializeAttachment(); } catch { return; }
    if (a.kind === 'd') { // pipe: to the other end of the same sid, as-is
      for (const w of this.state.getWebSockets('d:' + a.sid)) if (w !== ws) { try { w.send(data); } catch { } }
      return;
    }
    if (typeof data !== 'string') return;
    let j; try { j = JSON.parse(data); } catch { return; }
    if (j.t === 'dial' && ID_RE.test(j.to || '') && SID_RE.test(j.sid || '')) {
      const tgt = this.live('c:' + j.to);
      if (!tgt.length) { try { ws.send(JSON.stringify({ t: 'offline', to: j.to, sid: j.sid })); } catch { } return; }
      for (const w of tgt) { try { w.send(JSON.stringify({ t: 'incoming', from: a.id, sid: j.sid })); } catch { } }
    } else if (j.t === 'peers') this.peers();
  }
  async webSocketClose(ws, code) {
    let a; try { a = ws.deserializeAttachment(); } catch { a = null; }
    if (a && a.kind === 'd') { for (const w of this.state.getWebSockets('d:' + a.sid)) if (w !== ws) { try { w.close(1000, 'peer closed'); } catch { } } }
    else this.peers(ws);
    try { ws.close(code === 1005 ? 1000 : code, 'bye'); } catch { }
  }
  async webSocketError(ws) { await this.webSocketClose(ws, 1011); }
}
