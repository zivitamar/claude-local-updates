				import worker, * as OTHER_EXPORTS from "C:\\Users\\zivit\\OneDrive\\שולחן העבודה\\קלוד API\\relay\\hub-worker.js";
				import * as __MIDDLEWARE_0__ from "D:\\מערכת לייצור קריוקי\\data\\cache\\npm\\_npx\\c943b712072b77c4\\node_modules\\wrangler\\templates\\middleware\\middleware-ensure-req-body-drained.ts";
import * as __MIDDLEWARE_1__ from "D:\\מערכת לייצור קריוקי\\data\\cache\\npm\\_npx\\c943b712072b77c4\\node_modules\\wrangler\\templates\\middleware\\middleware-miniflare3-json-error.ts";

				export * from "C:\\Users\\zivit\\OneDrive\\שולחן העבודה\\קלוד API\\relay\\hub-worker.js";
				const MIDDLEWARE_TEST_INJECT = "__INJECT_FOR_TESTING_WRANGLER_MIDDLEWARE__";
				export const __INTERNAL_WRANGLER_MIDDLEWARE__ = [
					
					__MIDDLEWARE_0__.default,__MIDDLEWARE_1__.default
				]
				export default worker;