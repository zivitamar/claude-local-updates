var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// hub-worker.js
var ok = /* @__PURE__ */ __name((s, t = "ok", type = "text/plain") => new Response(t, { status: s, headers: { "content-type": type, "cache-control": "no-store" } }), "ok");
var ID_RE = /^[0-9a-f]{16}$/;
var NET_RE = /^[0-9a-f]{32}$/;
var SID_RE = /^[0-9a-f]{16,40}$/;
var hub_worker_default = {
  async fetch(req, env) {
    const u = new URL(req.url);
    if (u.pathname === "/health") return ok(200, "ok");
    const m = u.pathname.match(/^\/(c|d)\/([0-9a-f]{32})(?:\/([0-9a-f]{16,40}))?$/);
    if (!m) return ok(404, "not found");
    if (req.headers.get("Upgrade") !== "websocket") return ok(426, "websocket only");
    const k = u.searchParams.get("k") || "";
    if (!env.HUB_KEY || !await same(k, env.HUB_KEY)) return ok(403, "forbidden");
    if (!NET_RE.test(m[2]) || !ID_RE.test(u.searchParams.get("id") || "")) return ok(400, "bad id");
    const stub = env.HUB.get(env.HUB.idFromName(m[2]), { locationHint: env.LOCATION || void 0 });
    return stub.fetch(req);
  }
};
async function same(a, b) {
  const enc = new TextEncoder(), x = await crypto.subtle.digest("SHA-256", enc.encode(a)), y = await crypto.subtle.digest("SHA-256", enc.encode(b));
  return crypto.subtle.timingSafeEqual ? crypto.subtle.timingSafeEqual(x, y) : new Uint8Array(x).every((v, i) => v === new Uint8Array(y)[i]);
}
__name(same, "same");
var Hub = class {
  static {
    __name(this, "Hub");
  }
  constructor(state, env) {
    this.state = state;
    this.env = env;
    try {
      this.state.setWebSocketAutoResponse(new WebSocketRequestResponsePair('{"t":"ping"}', '{"t":"pong"}'));
    } catch {
    }
  }
  async fetch(req) {
    const u = new URL(req.url), m = u.pathname.match(/^\/(c|d)\/[0-9a-f]{32}(?:\/([0-9a-f]{16,40}))?$/);
    const id = u.searchParams.get("id");
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    if (m[1] === "c") {
      for (const old of this.state.getWebSockets("c:" + id)) {
        try {
          old.close(4e3, "replaced");
        } catch {
        }
      }
      this.state.acceptWebSocket(server, ["c", "c:" + id]);
      server.serializeAttachment({ kind: "c", id });
      this.peers();
    } else {
      const sid = m[2];
      if (!SID_RE.test(sid || "")) return new Response("bad sid", { status: 400 });
      const same2 = this.state.getWebSockets("d:" + sid);
      if (same2.length >= 2) return new Response("busy", { status: 409 });
      this.state.acceptWebSocket(server, ["d", "d:" + sid]);
      server.serializeAttachment({ kind: "d", id, sid, at: Date.now() });
      if (same2.length === 1) for (const w of [...same2, server]) {
        try {
          w.send('{"t":"open"}');
        } catch {
        }
      }
    }
    return new Response(null, { status: 101, webSocket: client });
  }
  live(tag, except) {
    return this.state.getWebSockets(tag).filter((w) => w !== except && w.readyState === 1);
  }
  peers(except) {
    const ids = [...new Set(this.live("c", except).map((w) => {
      try {
        return w.deserializeAttachment().id;
      } catch {
        return null;
      }
    }).filter(Boolean))];
    const msg = JSON.stringify({ t: "peers", ids, at: Date.now() });
    for (const w of this.live("c", except)) {
      try {
        w.send(msg);
      } catch {
      }
    }
  }
  async webSocketMessage(ws, data) {
    let a;
    try {
      a = ws.deserializeAttachment();
    } catch {
      return;
    }
    if (a.kind === "d") {
      for (const w of this.state.getWebSockets("d:" + a.sid)) if (w !== ws) {
        try {
          w.send(data);
        } catch {
        }
      }
      return;
    }
    if (typeof data !== "string") return;
    let j;
    try {
      j = JSON.parse(data);
    } catch {
      return;
    }
    if (j.t === "dial" && ID_RE.test(j.to || "") && SID_RE.test(j.sid || "")) {
      const tgt = this.live("c:" + j.to);
      if (!tgt.length) {
        try {
          ws.send(JSON.stringify({ t: "offline", to: j.to, sid: j.sid }));
        } catch {
        }
        return;
      }
      for (const w of tgt) {
        try {
          w.send(JSON.stringify({ t: "incoming", from: a.id, sid: j.sid }));
        } catch {
        }
      }
    } else if (j.t === "peers") this.peers();
  }
  async webSocketClose(ws, code) {
    let a;
    try {
      a = ws.deserializeAttachment();
    } catch {
      a = null;
    }
    if (a && a.kind === "d") {
      for (const w of this.state.getWebSockets("d:" + a.sid)) if (w !== ws) {
        try {
          w.close(1e3, "peer closed");
        } catch {
        }
      }
    } else this.peers(ws);
    try {
      ws.close(code === 1005 ? 1e3 : code, "bye");
    } catch {
    }
  }
  async webSocketError(ws) {
    await this.webSocketClose(ws, 1011);
  }
};

// D:/מערכת לייצור קריוקי/data/cache/npm/_npx/c943b712072b77c4/node_modules/wrangler/templates/middleware/middleware-ensure-req-body-drained.ts
var drainBody = /* @__PURE__ */ __name(async (request, env, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env);
  } finally {
    try {
      if (request.body !== null && !request.bodyUsed) {
        const reader = request.body.getReader();
        while (!(await reader.read()).done) {
        }
      }
    } catch (e) {
      console.error("Failed to drain the unused request body.", e);
    }
  }
}, "drainBody");
var middleware_ensure_req_body_drained_default = drainBody;

// D:/מערכת לייצור קריוקי/data/cache/npm/_npx/c943b712072b77c4/node_modules/wrangler/templates/middleware/middleware-miniflare3-json-error.ts
function reduceError(e) {
  return {
    name: e?.name,
    message: e?.message ?? String(e),
    stack: e?.stack,
    cause: e?.cause === void 0 ? void 0 : reduceError(e.cause)
  };
}
__name(reduceError, "reduceError");
var jsonError = /* @__PURE__ */ __name(async (request, env, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env);
  } catch (e) {
    const error = reduceError(e);
    const body = JSON.stringify(error);
    const headers = {
      "Content-Type": "application/json",
      "MF-Experimental-Error-Stack": "true"
    };
    const encoded = encodeURIComponent(body);
    if (encoded.length <= 8192) {
      headers["MF-Experimental-Error-Stack-Payload"] = encoded;
    }
    return new Response(body, { status: 500, headers });
  }
}, "jsonError");
var middleware_miniflare3_json_error_default = jsonError;

// .wrangler/tmp/bundle-AjFEg4/middleware-insertion-facade.js
var __INTERNAL_WRANGLER_MIDDLEWARE__ = [
  middleware_ensure_req_body_drained_default,
  middleware_miniflare3_json_error_default
];
var middleware_insertion_facade_default = hub_worker_default;

// D:/מערכת לייצור קריוקי/data/cache/npm/_npx/c943b712072b77c4/node_modules/wrangler/templates/middleware/common.ts
var __facade_middleware__ = [];
function __facade_register__(...args) {
  __facade_middleware__.push(...args.flat());
}
__name(__facade_register__, "__facade_register__");
function __facade_invokeChain__(request, env, ctx, dispatch, middlewareChain) {
  const [head, ...tail] = middlewareChain;
  const middlewareCtx = {
    dispatch,
    next(newRequest, newEnv) {
      return __facade_invokeChain__(newRequest, newEnv, ctx, dispatch, tail);
    }
  };
  return head(request, env, ctx, middlewareCtx);
}
__name(__facade_invokeChain__, "__facade_invokeChain__");
function __facade_invoke__(request, env, ctx, dispatch, finalMiddleware) {
  return __facade_invokeChain__(request, env, ctx, dispatch, [
    ...__facade_middleware__,
    finalMiddleware
  ]);
}
__name(__facade_invoke__, "__facade_invoke__");

// .wrangler/tmp/bundle-AjFEg4/middleware-loader.entry.ts
var __Facade_ScheduledController__ = class ___Facade_ScheduledController__ {
  constructor(scheduledTime, cron, noRetry) {
    this.scheduledTime = scheduledTime;
    this.cron = cron;
    this.#noRetry = noRetry;
  }
  scheduledTime;
  cron;
  static {
    __name(this, "__Facade_ScheduledController__");
  }
  #noRetry;
  noRetry() {
    if (!(this instanceof ___Facade_ScheduledController__)) {
      throw new TypeError("Illegal invocation");
    }
    this.#noRetry();
  }
};
function wrapExportedHandler(worker) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return worker;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  const fetchDispatcher = /* @__PURE__ */ __name(function(request, env, ctx) {
    if (worker.fetch === void 0) {
      throw new Error("Handler does not export a fetch() function.");
    }
    return worker.fetch(request, env, ctx);
  }, "fetchDispatcher");
  return {
    ...worker,
    fetch(request, env, ctx) {
      const dispatcher = /* @__PURE__ */ __name(function(type, init) {
        if (type === "scheduled" && worker.scheduled !== void 0) {
          const controller = new __Facade_ScheduledController__(
            Date.now(),
            init.cron ?? "",
            () => {
            }
          );
          return worker.scheduled(controller, env, ctx);
        }
      }, "dispatcher");
      return __facade_invoke__(request, env, ctx, dispatcher, fetchDispatcher);
    }
  };
}
__name(wrapExportedHandler, "wrapExportedHandler");
function wrapWorkerEntrypoint(klass) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return klass;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  return class extends klass {
    #fetchDispatcher = /* @__PURE__ */ __name((request, env, ctx) => {
      this.env = env;
      this.ctx = ctx;
      if (super.fetch === void 0) {
        throw new Error("Entrypoint class does not define a fetch() function.");
      }
      return super.fetch(request);
    }, "#fetchDispatcher");
    #dispatcher = /* @__PURE__ */ __name((type, init) => {
      if (type === "scheduled" && super.scheduled !== void 0) {
        const controller = new __Facade_ScheduledController__(
          Date.now(),
          init.cron ?? "",
          () => {
          }
        );
        return super.scheduled(controller);
      }
    }, "#dispatcher");
    fetch(request) {
      return __facade_invoke__(
        request,
        this.env,
        this.ctx,
        this.#dispatcher,
        this.#fetchDispatcher
      );
    }
  };
}
__name(wrapWorkerEntrypoint, "wrapWorkerEntrypoint");
var WRAPPED_ENTRY;
if (typeof middleware_insertion_facade_default === "object") {
  WRAPPED_ENTRY = wrapExportedHandler(middleware_insertion_facade_default);
} else if (typeof middleware_insertion_facade_default === "function") {
  WRAPPED_ENTRY = wrapWorkerEntrypoint(middleware_insertion_facade_default);
}
var middleware_loader_entry_default = WRAPPED_ENTRY;
export {
  Hub,
  __INTERNAL_WRANGLER_MIDDLEWARE__,
  middleware_loader_entry_default as default
};
//# sourceMappingURL=hub-worker.js.map
