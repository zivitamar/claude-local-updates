'use strict';
// ============================================================
//  file_preview.js — תצוגה של כל סוגי הקבצים בתוך האפליקציה (חצי החלון ליד הצ'אט). בלי ספריות חיצוניות.
//  GET /api/fs/preview?path=…  →  { kind, … }
//   text / code / log …  → { kind:'text', text, lang }          json / jsonl / ipynb → { kind:'json', text }
//   md → { kind:'markdown', text }     html → { kind:'html', text }      csv / tsv → { kind:'table', rows }
//   docx / dotx / docm → { kind:'doc', html }   (פסקאות, כותרות, מודגש/נטוי/קו תחתון, רשימות, טבלאות, תמונות, ימין-לשמאל)
//   xlsx / xlsm → { kind:'sheets', sheets:[{ name, rows }] }      pptx → { kind:'slides', slides:[{ n, title, lines, images }] }
//   odt / ods / odp → doc / sheets / slides (OpenDocument)          zip / jar / apk / vsix / nupkg / epub → { kind:'archive', entries }
//   doc / xls / ppt (פורמט בינארי ישן) → { kind:'text', text, note }  (הטקסט שבקובץ)      rtf → { kind:'text', text }
//   pdf / תמונה / וידאו / שמע → { kind:'pdf' | 'media' } (נפתחים ישירות מ-/api/fs/raw)     כל השאר → { kind:'binary', hex }
// ============================================================
const fs = require('fs'), path = require('path'), zlib = require('zlib');

const MAX_FILE = 80 * 1024 * 1024, MAX_TEXT = 4 * 1024 * 1024, MAX_ROWS = 2000, MAX_COLS = 60, MAX_IMG = 3 * 1024 * 1024;
const EXT = s => path.extname(s).toLowerCase().replace(/^\./, '');
const TEXT_EXT = new Set(('txt log ini cfg conf env properties toml yaml yml xml xsd xsl svg plist csproj vcxproj sln props targets gradle ' +
  'js mjs cjs jsx ts tsx vue svelte css scss sass less py pyw rb php java kt kts scala go rs c h cc cpp cxx hpp hh cs fs vb swift m mm dart lua pl pm r jl ' +
  'sh bash zsh fish ps1 psm1 psd1 bat cmd vbs ahk sql graphql gql proto dockerfile makefile mk cmake tf hcl nix ' +
  'gitignore gitattributes editorconfig npmrc yarnrc eslintrc prettierrc babelrc lock srt vtt ass sub tex bib rst adoc org textile diff patch reg inf').split(' '));
const LANG = { js: 'js', mjs: 'js', cjs: 'js', jsx: 'js', ts: 'ts', tsx: 'ts', py: 'python', pyw: 'python', sh: 'bash', bash: 'bash', zsh: 'bash', ps1: 'powershell', psm1: 'powershell', bat: 'bat', cmd: 'bat', yml: 'yaml', yaml: 'yaml', toml: 'toml', rb: 'ruby', sql: 'sql', css: 'css', html: 'html', xml: 'xml' };
const MEDIA = /^(png|jpe?g|gif|webp|bmp|ico|avif|mp4|webm|mov|m4v|ogv|mkv|mp3|wav|ogg|oga|m4a|flac|opus|aac)$/;
const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const xmlText = s => String(s || '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(+n)).replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16))).replace(/&amp;/g, '&');

// ---------- ZIP (Office / OpenDocument / ארכיונים) ----------
function readZip(buf) {
  let eocd = -1; for (let i = buf.length - 22; i >= Math.max(0, buf.length - 66000); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('לא קובץ ZIP תקין');
  const n = buf.readUInt16LE(eocd + 10), cdOff = buf.readUInt32LE(eocd + 16), entries = [];
  let p = cdOff;
  for (let i = 0; i < n && p + 46 <= buf.length; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) break;
    const method = buf.readUInt16LE(p + 10), dtime = buf.readUInt16LE(p + 12), ddate = buf.readUInt16LE(p + 14), csize = buf.readUInt32LE(p + 20), size = buf.readUInt32LE(p + 24);
    const nl = buf.readUInt16LE(p + 28), xl = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lho = buf.readUInt32LE(p + 42), flags = buf.readUInt16LE(p + 8);
    const name = buf.subarray(p + 46, p + 46 + nl).toString(flags & 0x800 ? 'utf8' : 'latin1');
    const date = new Date(1980 + (ddate >> 9), ((ddate >> 5) & 15) - 1, ddate & 31, dtime >> 11, (dtime >> 5) & 63, (dtime & 31) * 2).getTime();
    entries.push({ name, method, csize, size, lho, date, dir: name.endsWith('/') });
    p += 46 + nl + xl + cl;
  }
  const map = new Map(entries.map(e => [e.name.replace(/\\/g, '/'), e]));
  const get = name => {
    const e = map.get(name) || map.get(name.replace(/^\//, '')); if (!e || e.dir) return null;
    const lh = e.lho; if (buf.readUInt32LE(lh) !== 0x04034b50) return null;
    const start = lh + 30 + buf.readUInt16LE(lh + 26) + buf.readUInt16LE(lh + 28), data = buf.subarray(start, start + e.csize);
    return e.method === 0 ? data : e.method === 8 ? zlib.inflateRawSync(data) : null;
  };
  return { entries, get, text: name => { const b = get(name); return b ? b.toString('utf8') : ''; } };
}
const relsOf = (z, part) => { const dir = path.posix.dirname(part), base = path.posix.basename(part); const x = z.text(`${dir}/_rels/${base}.rels`); const m = {}; for (const r of x.matchAll(/<Relationship\b[^>]*>/g)) { const id = (r[0].match(/\bId="([^"]+)"/) || [])[1], t = (r[0].match(/\bTarget="([^"]+)"/) || [])[1], ext = /TargetMode="External"/.test(r[0]); if (id && t) m[id] = ext ? { external: t } : path.posix.normalize(t.startsWith('/') ? t.slice(1) : `${dir}/${t}`); } return m; };
const MIME = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', bmp: 'image/bmp', webp: 'image/webp', svg: 'image/svg+xml', emf: '', wmf: '', tif: 'image/tiff', tiff: 'image/tiff' };
function dataUri(z, part) { const ext = EXT(part), mime = MIME[ext]; if (!mime) return ''; const b = z.get(part); return b && b.length <= MAX_IMG ? `data:${mime};base64,${b.toString('base64')}` : ''; }
// אלמנטים ברמה העליונה (עם עומק — טבלה בתוך טבלה לא נשברת)
function topLevel(xml, tags) {
  const out = [], re = new RegExp(`<(/?)(${tags.join('|')})(?=[\\s>/])[^>]*?(/?)>`, 'g'); let depth = 0, start = -1, tag = '', m;
  while ((m = re.exec(xml))) {
    const close = m[1] === '/', self = m[3] === '/';
    if (!close && depth === 0) { start = m.index; tag = m[2]; }
    if (self) { if (depth === 0) out.push({ tag: m[2], xml: m[0] }); continue; }
    if (!close) depth++; else { depth--; if (depth === 0 && start >= 0) { out.push({ tag, xml: xml.slice(start, re.lastIndex) }); start = -1; } }
  }
  return out;
}

// ---------- Word (docx) ----------
function docx(z) {
  const doc = z.text('word/document.xml'); if (!doc) throw new Error('אין word/document.xml');
  const rels = relsOf(z, 'word/document.xml'), styles = z.text('word/styles.xml'), styleName = {};
  for (const s of styles.matchAll(/<w:style\b[^>]*w:styleId="([^"]+)"[^>]*>[\s\S]*?<w:name w:val="([^"]+)"/g)) styleName[s[1]] = s[2].toLowerCase();
  const body = (doc.match(/<w:body>([\s\S]*)<\/w:body>/) || [, doc])[1];
  const runs = pxml => {
    let h = '';
    for (const el of topLevel(pxml, ['w:r', 'w:hyperlink', 'w:ins', 'w:smartTag', 'w:fldSimple'])) {
      if (el.tag !== 'w:r') { const inner = el.xml.replace(/^<[^>]+>/, '').replace(/<\/[^>]+>$/, ''); const id = (el.xml.match(/r:id="([^"]+)"/) || [])[1]; const txt = runs(inner); h += el.tag === 'w:hyperlink' && id && rels[id] && rels[id].external ? `<a href="${esc(rels[id].external)}" target="_blank" rel="noopener">${txt}</a>` : txt; continue; }
      const rpr = (el.xml.match(/<w:rPr>([\s\S]*?)<\/w:rPr>/) || [, ''])[1];
      const on = t => new RegExp(`<w:${t}(?:\\s+w:val="(?:true|1|on|single|double)")?\\s*/>`).test(rpr);
      let t = '';
      for (const c of el.xml.matchAll(/<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>|<w:tab\/>|<w:br(?:\s[^>]*)?\/>|<w:cr\/>|<a:blip\b[^>]*r:embed="([^"]+)"|<w:sym\b[^>]*w:char="([0-9A-F]+)"/g)) {
        if (c[1] != null) t += esc(xmlText(c[1])); else if (c[0].startsWith('<w:tab')) t += '&emsp;'; else if (c[2]) { const u = rels[c[2]] && typeof rels[c[2]] === 'string' ? dataUri(z, rels[c[2]]) : ''; if (u) t += `<img src="${u}" alt="">`; } else if (c[3]) t += '•'; else t += '<br>';
      }
      if (!t) continue;
      if (on('b')) t = `<b>${t}</b>`; if (on('i')) t = `<i>${t}</i>`; if (/<w:u\s+w:val="(?!none)/.test(rpr)) t = `<u>${t}</u>`; if (on('strike')) t = `<s>${t}</s>`;
      // עיצוב הריצה כמו ב-Word: גודל, צבע, גופן, סימון — ערכים מאומתים בלבד
      const css = [], sz = +((rpr.match(/<w:sz w:val="(\d{1,3})"/) || [])[1] || 0), col = (rpr.match(/<w:color w:val="([0-9A-Fa-f]{6})"/) || [])[1];
      const font = (rpr.match(/<w:rFonts\b[^>]*w:(?:ascii|hAnsi|cs)="([\w .\-]{1,40})"/) || [])[1], hl = (rpr.match(/<w:highlight w:val="([a-zA-Z]{3,20})"/) || [])[1];
      if (sz >= 8 && sz <= 200) css.push(`font-size:${(sz / 2 * 4 / 3).toFixed(1)}px`);
      if (col && col !== '000000') css.push(`color:#${col}`);
      if (font) css.push(`font-family:'${font}'`);
      if (hl && hl !== 'none') css.push(`background:${hl.toLowerCase()}`);
      if (/<w:vertAlign w:val="superscript"/.test(rpr)) t = `<sup>${t}</sup>`; else if (/<w:vertAlign w:val="subscript"/.test(rpr)) t = `<sub>${t}</sub>`;
      if (css.length) t = `<span style="${css.join(';')}">${t}</span>`;
      h += t;
    }
    return h;
  };
  const para = pxml => {
    const ppr = (pxml.match(/<w:pPr>([\s\S]*?)<\/w:pPr>/) || [, ''])[1];
    const sid = (ppr.match(/<w:pStyle w:val="([^"]+)"/) || [])[1], sname = styleName[sid] || String(sid || '').toLowerCase();
    const rtl = /<w:bidi(?:\s+w:val="(?:true|1|on)")?\s*\/>/.test(ppr), align = (ppr.match(/<w:jc w:val="([^"]+)"/) || [])[1];
    const inner = runs(pxml), dir = rtl ? ' dir="rtl"' : ' dir="auto"', st = align === 'center' ? ' style="text-align:center"' : align === 'right' || align === 'end' ? ' style="text-align:right"' : '';
    const hm = sname.match(/^(?:heading|כותרת)\s*(\d)/) || (sname === 'title' ? [0, 1] : null);
    if (hm) return { html: `<h${Math.min(6, +hm[1] || 1)}${dir}${st}>${inner || '&nbsp;'}</h${Math.min(6, +hm[1] || 1)}>` };
    if (/<w:numPr>/.test(ppr) || /list/.test(sname)) return { li: true, level: +((ppr.match(/<w:ilvl w:val="(\d+)"/) || [])[1] || 0), html: `<li${dir}>${inner}</li>` };
    return { html: inner ? `<p${dir}${st}>${inner}</p>` : '<p class="fv-empty">&nbsp;</p>' };
  };
  const table = txml => {
    let h = '<table class="fv-table">';
    for (const tr of topLevel(txml.replace(/^<w:tbl>|<\/w:tbl>$/g, ''), ['w:tr'])) {
      h += '<tr>';
      for (const tc of topLevel(tr.xml.replace(/^<w:tr\b[^>]*>|<\/w:tr>$/g, ''), ['w:tc'])) {
        const span = +((tc.xml.match(/<w:gridSpan w:val="(\d+)"/) || [])[1] || 1);
        h += `<td${span > 1 ? ` colspan="${span}"` : ''}>${block(tc.xml.replace(/^<w:tc>|<\/w:tc>$/g, ''))}</td>`;
      }
      h += '</tr>';
    }
    return h + '</table>';
  };
  const block = xml => {
    let h = '', list = false;
    for (const el of topLevel(xml, ['w:p', 'w:tbl', 'w:sdt'])) {
      if (el.tag === 'w:sdt') { h += block((el.xml.match(/<w:sdtContent>([\s\S]*)<\/w:sdtContent>/) || [, ''])[1]); continue; }
      if (el.tag === 'w:tbl') { if (list) { h += '</ul>'; list = false; } h += table(el.xml); continue; }
      const p = para(el.xml);
      if (p.li && !list) { h += '<ul>'; list = true; } else if (!p.li && list) { h += '</ul>'; list = false; }
      h += p.li && p.level ? p.html.replace('<li', `<li style="margin-inline-start:${p.level * 22}px"`) : p.html;
    }
    return h + (list ? '</ul>' : '');
  };
  return { kind: 'doc', html: block(body) };
}

// ---------- Excel (xlsx) ----------
const colIdx = ref => { const l = (ref.match(/^[A-Z]+/) || ['A'])[0]; let n = 0; for (const ch of l) n = n * 26 + ch.charCodeAt(0) - 64; return n - 1; };
function xlsx(z) {
  const shared = []; for (const si of z.text('xl/sharedStrings.xml').matchAll(/<si>([\s\S]*?)<\/si>/g)) shared.push([...si[1].matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g)].map(m => xmlText(m[1])).join(''));
  const wb = z.text('xl/workbook.xml'), rels = relsOf(z, 'xl/workbook.xml'), sheets = [];
  for (const s of wb.matchAll(/<sheet\b[^>]*>/g)) {
    const name = xmlText((s[0].match(/\bname="([^"]*)"/) || [])[1] || 'גיליון'), rid = (s[0].match(/r:id="([^"]+)"/) || [])[1], part = rels[rid];
    const x = typeof part === 'string' ? z.text(part) : ''; const rows = []; let truncated = false;
    for (const r of x.matchAll(/<row\b[^>]*?(?:\/>|>([\s\S]*?)<\/row>)/g)) {
      const rn = +((r[0].match(/\br="(\d+)"/) || [])[1] || rows.length + 1) - 1; if (rn >= MAX_ROWS) { truncated = true; break; }
      const row = rows[rn] = rows[rn] || [];
      for (const c of (r[1] || '').matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
        const ref = (c[1].match(/\br="([A-Z]+\d+)"/) || [])[1], t = (c[1].match(/\bt="([^"]+)"/) || [])[1], ci = ref ? colIdx(ref) : row.length; if (ci >= MAX_COLS) { truncated = true; continue; }
        const v = ((c[2] || '').match(/<v>([\s\S]*?)<\/v>/) || [])[1];
        row[ci] = t === 's' ? (shared[+v] || '') : t === 'inlineStr' ? [...(c[2] || '').matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g)].map(m => xmlText(m[1])).join('') : t === 'b' ? (v === '1' ? 'TRUE' : 'FALSE') : xmlText(v == null ? '' : v);
      }
    }
    for (let i = 0; i < rows.length; i++) rows[i] = Array.from(rows[i] || [], v => v == null ? '' : v);
    sheets.push({ name, rows, truncated, rtl: /<sheetView\b[^>]*rightToLeft="(?:1|true)"/.test(x) });
  }
  return { kind: 'sheets', sheets };
}

// ---------- PowerPoint (pptx) ----------
function pptx(z) {
  const pres = z.text('ppt/presentation.xml'), rels = relsOf(z, 'ppt/presentation.xml'), slides = [];
  const ids = [...pres.matchAll(/<p:sldId\b[^>]*r:id="([^"]+)"/g)].map(m => rels[m[1]]).filter(p => typeof p === 'string');
  ids.forEach((part, i) => {
    const x = z.text(part), srels = relsOf(z, part); let title = '', lines = [];
    for (const sp of topLevel(x, ['p:sp', 'p:graphicFrame'])) {
      const isTitle = /<p:ph\b[^>]*type="(?:title|ctrTitle)"/.test(sp.xml);
      const paras = [...sp.xml.matchAll(/<a:p>([\s\S]*?)<\/a:p>/g)].map(p => [...p[1].matchAll(/<a:t>([\s\S]*?)<\/a:t>/g)].map(t => xmlText(t[1])).join('')).filter(s => s.trim());
      if (isTitle && !title) title = paras.join(' '); else lines.push(...paras);
    }
    const images = [...x.matchAll(/<a:blip\b[^>]*r:embed="([^"]+)"/g)].map(m => srels[m[1]]).filter(p => typeof p === 'string').slice(0, 4).map(p => dataUri(z, p)).filter(Boolean);
    const notesPart = Object.values(srels).find(p => typeof p === 'string' && /notesSlide/.test(p)); const notes = notesPart ? topLevel(z.text(notesPart), ['p:sp']).filter(sp => !/<p:ph\b[^>]*type="(?:sldNum|sldImg|hdr|ftr|dt)"/.test(sp.xml)).map(sp => [...sp.xml.matchAll(/<a:t>([\s\S]*?)<\/a:t>/g)].map(t => xmlText(t[1])).join(' ')).join(' ').trim() : '';
    slides.push({ n: i + 1, title, lines, images, notes });
  });
  return { kind: 'slides', slides };
}

// ---------- OpenDocument (odt / ods / odp) ----------
function odf(z, ext) {
  const x = z.text('content.xml'); if (!x) throw new Error('אין content.xml');
  const txt = s => xmlText(String(s).replace(/<text:tab\/>/g, '\t').replace(/<text:line-break\/>/g, '\n').replace(/<text:s(?:\s+text:c="(\d+)")?\/>/g, (m, n) => ' '.repeat(+n || 1)).replace(/<[^>]+>/g, ''));
  if (ext === 'ods') {
    const sheets = [];
    for (const t of x.matchAll(/<table:table\b[^>]*table:name="([^"]*)"[^>]*>([\s\S]*?)<\/table:table>/g)) {
      const rows = [];
      for (const r of t[2].matchAll(/<table:table-row\b[^>]*>([\s\S]*?)<\/table:table-row>/g)) { const row = []; for (const c of r[1].matchAll(/<table:table-cell\b([^>]*?)(?:\/>|>([\s\S]*?)<\/table:table-cell>)/g)) { const rep = Math.min(+((c[1].match(/number-columns-repeated="(\d+)"/) || [])[1] || 1), MAX_COLS); const v = txt(c[2] || ''); for (let k = 0; k < rep && row.length < MAX_COLS; k++) row.push(v); } while (row.length && row[row.length - 1] === '') row.pop(); if (rows.length < MAX_ROWS) rows.push(row); }
      while (rows.length && !rows[rows.length - 1].length) rows.pop();
      sheets.push({ name: xmlText(t[1]), rows });
    }
    return { kind: 'sheets', sheets };
  }
  if (ext === 'odp') { const slides = []; [...x.matchAll(/<draw:page\b[^>]*>([\s\S]*?)<\/draw:page>/g)].forEach((p, i) => { const lines = [...p[1].matchAll(/<text:(?:p|h)\b[^>]*>([\s\S]*?)<\/text:(?:p|h)>/g)].map(m => txt(m[1])).filter(s => s.trim()); slides.push({ n: i + 1, title: lines.shift() || '', lines, images: [] }); }); return { kind: 'slides', slides }; }
  let h = '';
  for (const m of x.matchAll(/<text:(h|p)\b([^>]*)>([\s\S]*?)<\/text:\1>|<text:list-item>([\s\S]*?)<\/text:list-item>/g)) {
    if (m[4] != null) { h += `<li dir="auto">${esc(txt(m[4]))}</li>`; continue; }
    const lvl = +((m[2].match(/outline-level="(\d)"/) || [])[1] || 1); const t = esc(txt(m[3]));
    h += m[1] === 'h' ? `<h${lvl} dir="auto">${t}</h${lvl}>` : `<p dir="auto">${t || '&nbsp;'}</p>`;
  }
  return { kind: 'doc', html: h.replace(/(<li[\s\S]*?<\/li>)+/g, s => `<ul>${s}</ul>`) };
}

// ---------- פורמטים בינאריים ישנים: Compound File (OLE) → doc (טבלת קטעים) · xls (BIFF8) · ppt (רשומות טקסט) ----------
function readCfb(buf) {
  if (buf.length < 512 || buf.readUInt32LE(0) !== 0xe011cfd0) throw new Error('לא קובץ Office ישן');
  const ss = 1 << buf.readUInt16LE(30), mss = 1 << buf.readUInt16LE(32), nFat = buf.readUInt32LE(44), dirStart = buf.readInt32LE(48), cutoff = buf.readUInt32LE(56), miniFatStart = buf.readInt32LE(60), difatStart = buf.readInt32LE(68);
  const sec = n => buf.subarray(512 + n * ss, 512 + (n + 1) * ss);
  const fatSecs = []; for (let i = 0; i < 109 && fatSecs.length < nFat; i++) { const s = buf.readInt32LE(76 + i * 4); if (s >= 0) fatSecs.push(s); }
  for (let d = difatStart, guard = 0; d >= 0 && fatSecs.length < nFat && guard < 10000; guard++) { const b = sec(d); for (let i = 0; i < ss / 4 - 1 && fatSecs.length < nFat; i++) { const s = b.readInt32LE(i * 4); if (s >= 0) fatSecs.push(s); } d = b.readInt32LE(ss - 4); }
  const fat = []; for (const s of fatSecs) { const b = sec(s); for (let i = 0; i < ss / 4; i++) fat.push(b.readInt32LE(i * 4)); }
  const chain = (start, f) => { const out = []; for (let s = start, g = 0; s >= 0 && s < f.length + 1e6 && g < 1e6; g++) { out.push(s); s = f[s]; if (s === undefined) break; } return out; };
  const readChain = start => Buffer.concat(chain(start, fat).map(sec));
  const dir = readChain(dirStart), entries = [];
  for (let o = 0; o + 128 <= dir.length; o += 128) { const nl = dir.readUInt16LE(o + 64); if (!nl) { entries.push(null); continue; } entries.push({ name: dir.subarray(o, o + Math.max(0, nl - 2)).toString('utf16le'), type: dir[o + 66], start: dir.readInt32LE(o + 116), size: dir.readUInt32LE(o + 120) }); }
  const root = entries[0]; const ministream = root ? readChain(root.start) : Buffer.alloc(0);
  const miniFat = []; if (miniFatStart >= 0) { const b = readChain(miniFatStart); for (let i = 0; i + 4 <= b.length; i += 4) miniFat.push(b.readInt32LE(i)); }
  const stream = name => {
    const e = entries.find(x => x && x.type === 2 && x.name === name); if (!e) return null;
    if (e.size < cutoff) return Buffer.concat(chain(e.start, miniFat).map(s => ministream.subarray(s * mss, (s + 1) * mss))).subarray(0, e.size);
    return readChain(e.start).subarray(0, e.size);
  };
  return { entries: entries.filter(Boolean), stream };
}
const CP1252 = { 0x80: '€', 0x82: '‚', 0x84: '„', 0x85: '…', 0x91: '‘', 0x92: '’', 0x93: '“', 0x94: '”', 0x95: '•', 0x96: '–', 0x97: '—', 0x99: '™' };
const cp1252 = b => { let s = ''; for (const c of b) s += CP1252[c] || String.fromCharCode(c); return s; };
// Word 97-2003: FIB → טבלת הקטעים (CLX) → הטקסט של המסמך
function legacyDoc(cfb) {
  const wd = cfb.stream('WordDocument'); if (!wd) throw new Error('אין WordDocument');
  const flags = wd.readUInt16LE(0x0a), table = cfb.stream(flags & 0x0200 ? '1Table' : '0Table'); if (!table) throw new Error('אין טבלה');
  const fcClx = wd.readUInt32LE(0x01a2), lcbClx = wd.readUInt32LE(0x01a6), clx = table.subarray(fcClx, fcClx + lcbClx);
  let p = 0; while (p < clx.length && clx[p] === 0x01) p += 3 + clx.readUInt16LE(p + 1); // Prc
  if (clx[p] !== 0x02) throw new Error('אין טבלת קטעים');
  const lcb = clx.readUInt32LE(p + 1), pcd = clx.subarray(p + 5, p + 5 + lcb), n = (lcb - 4) / 12; let text = '';
  for (let i = 0; i < n; i++) {
    const cpS = pcd.readUInt32LE(i * 4), cpE = pcd.readUInt32LE((i + 1) * 4), fcRaw = pcd.readUInt32LE((n + 1) * 4 + i * 8 + 2), comp = (fcRaw & 0x40000000) !== 0, fc = fcRaw & 0x3fffffff, len = cpE - cpS;
    text += comp ? cp1252(wd.subarray(fc / 2, fc / 2 + len)) : wd.subarray(fc, fc + len * 2).toString('utf16le');
  }
  return text.replace(/\r\n?|\x0b/g, '\n').replace(/\x07/g, '\t').replace(/\x0c/g, '\n\n').replace(/[\x00-\x08\x0e-\x1f]/g, '').replace(/\x13[^\x14\x15]*\x14?([^\x15]*)\x15/g, '$1').replace(/\n{3,}/g, '\n\n').trim();
}
// Excel 97-2003 (BIFF8): גיליונות + מחרוזות משותפות + מספרים
function legacyXls(cfb) {
  const wb = cfb.stream('Workbook') || cfb.stream('Book'); if (!wb) throw new Error('אין Workbook');
  const recs = []; for (let o = 0; o + 4 <= wb.length;) { const t = wb.readUInt16LE(o), l = wb.readUInt16LE(o + 2); recs.push({ t, o, d: wb.subarray(o + 4, o + 4 + l) }); o += 4 + l; }
  const sst = [], sheets = [];
  for (let i = 0; i < recs.length; i++) {
    const r = recs[i];
    if (r.t === 0x0085) { const pos = r.d.readUInt32LE(0), len = r.d[6], hi = r.d[7] & 1; sheets.push({ pos, name: hi ? r.d.subarray(8, 8 + len * 2).toString('utf16le') : r.d.subarray(8, 8 + len).toString('latin1'), rows: [] }); }
    if (r.t === 0x00fc) { // SST + CONTINUE
      const parts = [r.d]; for (let j = i + 1; j < recs.length && recs[j].t === 0x003c; j++) parts.push(recs[j].d);
      let pi = 0, o = 8; const total = r.d.readUInt32LE(4);
      const need = () => { if (o >= parts[pi].length) { pi++; o = 0; } };
      for (let k = 0; k < total && pi < parts.length; k++) {
        need(); if (pi >= parts.length) break; let d = parts[pi];
        const cch = d.readUInt16LE(o); let fl = d[o + 2]; o += 3; let rt = 0, sz = 0;
        if (fl & 8) { rt = d.readUInt16LE(o); o += 2; } if (fl & 4) { sz = d.readUInt32LE(o); o += 4; }
        let s = '', left = cch;
        while (left > 0) { need(); d = parts[pi]; if (o === 0 && s) { fl = d[0]; o = 1; } const wide = fl & 1, can = Math.min(left, Math.floor((d.length - o) / (wide ? 2 : 1))); s += wide ? d.subarray(o, o + can * 2).toString('utf16le') : d.subarray(o, o + can).toString('latin1'); o += can * (wide ? 2 : 1); left -= can; if (left > 0) { pi++; o = 0; if (pi >= parts.length) break; } }
        o += rt * 4 + sz; while (pi < parts.length && o > parts[pi].length) { o -= parts[pi].length; pi++; }
        sst.push(s);
      }
    }
  }
  const rk = v => { let n = (v & 2) ? (v >> 2) : (() => { const b = Buffer.alloc(8); b.writeInt32LE(0, 0); b.writeInt32LE(v & 0xfffffffc, 4); return b.readDoubleLE(0); })(); if (v & 1) n /= 100; return n; };
  for (const sh of sheets) {
    const start = recs.findIndex(r => r.o === sh.pos); if (start < 0) continue; const rows = sh.rows;
    const put = (r, c, v) => { if (r >= MAX_ROWS || c >= MAX_COLS) return; (rows[r] = rows[r] || [])[c] = v; };
    for (let i = start + 1; i < recs.length && recs[i].t !== 0x000a; i++) {
      const { t, d } = recs[i];
      if (t === 0x00fd) put(d.readUInt16LE(0), d.readUInt16LE(2), sst[d.readUInt32LE(6)] || '');
      else if (t === 0x0203) put(d.readUInt16LE(0), d.readUInt16LE(2), String(+d.readDoubleLE(6).toFixed(10)));
      else if (t === 0x027e) put(d.readUInt16LE(0), d.readUInt16LE(2), String(rk(d.readInt32LE(6))));
      else if (t === 0x00bd) { const r = d.readUInt16LE(0), c0 = d.readUInt16LE(2), cnt = (d.length - 6) / 6; for (let k = 0; k < cnt; k++) put(r, c0 + k, String(rk(d.readInt32LE(4 + k * 6 + 2)))); }
      else if (t === 0x0204) { const len = d.readUInt16LE(6), hi = d[8] & 1; put(d.readUInt16LE(0), d.readUInt16LE(2), hi ? d.subarray(9, 9 + len * 2).toString('utf16le') : d.subarray(9, 9 + len).toString('latin1')); }
      else if (t === 0x0006 && d.readUInt16LE(12) !== 0xffff) put(d.readUInt16LE(0), d.readUInt16LE(2), String(+d.readDoubleLE(6).toFixed(10)));
      else if (t === 0x023e && d.length >= 2) sh.rtl = !!(d.readUInt16LE(0) & 0x0040); // WINDOW2: גיליון מימין לשמאל
    }
    for (let r = 0; r < rows.length; r++) rows[r] = Array.from(rows[r] || [], v => v == null ? '' : v);
  }
  return { kind: 'sheets', sheets: sheets.map(s => ({ name: s.name, rows: s.rows, rtl: !!s.rtl })) };
}
// PowerPoint 97-2003: רשומות טקסט, מחולקות לשקפים
function legacyPpt(cfb) {
  const pd = cfb.stream('PowerPoint Document'); if (!pd) throw new Error('אין PowerPoint Document');
  // הטקסט של השקפים נמצא ב-SlideListWithText (0x0FF0) עם instance 0; כל SlidePersistAtom (0x03F3) פותח שקף. (instance 1 = תבניות, 2 = הערות)
  const slides = []; let cur = null, found = false;
  const walk = (o, end, depth) => {
    while (o + 8 <= end) {
      const h = pd.readUInt16LE(o), ver = h & 0xf, inst = h >> 4, type = pd.readUInt16LE(o + 2), len = pd.readUInt32LE(o + 4), body = o + 8;
      if (type === 0x0ff0) { if (inst === 0) { found = true; inSlides(body, Math.min(end, body + len)); } o = body + len; continue; }
      if (ver === 0xf && depth < 6 && len > 0) walk(body, Math.min(end, body + len), depth + 1);
      o = body + len;
    }
  };
  const inSlides = (o, end) => {
    while (o + 8 <= end) {
      const type = pd.readUInt16LE(o + 2), len = pd.readUInt32LE(o + 4), body = o + 8;
      if (type === 0x03f3) { cur = { n: slides.length + 1, title: '', lines: [], images: [] }; slides.push(cur); }
      else if ((type === 0x0fa0 || type === 0x0fa8) && cur) { const s = (type === 0x0fa0 ? pd.subarray(body, body + len).toString('utf16le') : cp1252(pd.subarray(body, body + len))).replace(/\r/g, '\n').trim(); if (s && s !== '*') { if (!cur.title) cur.title = s; else cur.lines.push(s); } }
      o = body + len;
    }
  };
  walk(0, pd.length, 0);
  if (found && slides.some(s => s.title || s.lines.length)) return { kind: 'slides', slides };
  // גרסאות חדשות יותר: הטקסט בתוך כל שקף (Slide 0x03EE) — מדלגים על תבניות (0x03F8) והערות (0x03F0)
  const out = []; let sl = null;
  const walk2 = (o, end, depth) => {
    while (o + 8 <= end) {
      const ver = pd.readUInt16LE(o) & 0xf, type = pd.readUInt16LE(o + 2), len = pd.readUInt32LE(o + 4), body = o + 8;
      if (type === 0x03f8 || type === 0x03f0 || type === 0x0fc9) { o = body + len; continue; }
      if (type === 0x03ee) { sl = { n: out.length + 1, title: '', lines: [], images: [] }; out.push(sl); walk2(body, Math.min(end, body + len), depth + 1); sl = null; o = body + len; continue; }
      if (sl && (type === 0x0fa0 || type === 0x0fa8)) { const s = (type === 0x0fa0 ? pd.subarray(body, body + len).toString('utf16le') : cp1252(pd.subarray(body, body + len))).replace(/\r/g, '\n').trim(); if (s && s !== '*') { if (!sl.title) sl.title = s; else sl.lines.push(s); } }
      if (ver === 0xf && depth < 14 && len > 0) walk2(body, Math.min(end, body + len), depth + 1);
      o = body + len;
    }
  };
  walk2(0, pd.length, 0);
  if (!out.length) throw new Error('אין שקפים');
  return { kind: 'slides', slides: out };
}
function legacyText(buf) {
  const parts = [], u16 = buf.toString('utf16le'); for (const m of u16.matchAll(/[ -~ -ɏ֐-׿؀-ۿ‐-‧\r\n\t]{4,}/g)) parts.push(m[0]);
  const ascii = buf.toString('latin1'); for (const m of ascii.matchAll(/[\x20-\x7e\r\n\t]{8,}/g)) parts.push(m[0]);
  const seen = new Set(), out = []; for (const p of parts) { const k = p.trim(); if (k.length < 4 || seen.has(k) || /^[\W\d_]+$/.test(k)) continue; seen.add(k); out.push(k); }
  return out.join('\n').replace(/\r/g, '\n').replace(/\n{3,}/g, '\n\n').slice(0, MAX_TEXT);
}
function rtfText(s) {
  let t = s.replace(/\{\\\*[^{}]*\}/g, '').replace(/\{\\(?:fonttbl|colortbl|stylesheet|info)[\s\S]*?\}\s*/g, '');
  t = t.replace(/\\u(-?\d+)\??/g, (_, n) => String.fromCharCode((+n + 65536) % 65536)).replace(/\\'([0-9a-f]{2})/gi, (_, h) => String.fromCharCode(parseInt(h, 16)));
  return t.replace(/\\par[d]?\b ?/g, '\n').replace(/\\line\b ?/g, '\n').replace(/\\tab\b ?/g, '\t').replace(/\\[a-z]+-?\d* ?/gi, '').replace(/[{}]/g, '').replace(/\n{3,}/g, '\n\n').trim();
}
// CSV / TSV
function parseCsv(text, sep) {
  if (!sep) { const head = text.slice(0, 4000); const cnt = c => (head.match(new RegExp(c === '|' ? '\\|' : c, 'g')) || []).length; sep = ['\t', ';', ','].sort((a, b) => cnt(b) - cnt(a))[0]; }
  const rows = []; let row = [], cur = '', q = false;
  for (let i = 0; i < text.length && rows.length < MAX_ROWS; i++) {
    const ch = text[i];
    if (q) { if (ch === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += ch; continue; }
    if (ch === '"') q = true; else if (ch === sep) { row.push(cur); cur = ''; } else if (ch === '\n' || ch === '\r') { if (ch === '\r' && text[i + 1] === '\n') i++; row.push(cur); rows.push(row.slice(0, MAX_COLS)); row = []; cur = ''; } else cur += ch;
  }
  if (cur || row.length) { row.push(cur); rows.push(row.slice(0, MAX_COLS)); }
  return rows;
}
const isBinary = b => { const n = Math.min(b.length, 8000); let bad = 0; for (let i = 0; i < n; i++) { if (b[i] === 0) return true; if (b[i] < 9 || (b[i] > 13 && b[i] < 32)) bad++; } return bad > n * 0.1; };
const decode = b => (b[0] === 0xff && b[1] === 0xfe) ? b.subarray(2).toString('utf16le') : (b[0] === 0xfe && b[1] === 0xff) ? Buffer.from(b.subarray(2)).swap16().toString('utf16le') : b.toString('utf8').replace(/^﻿/, '');

function preview(file) {
  const st = fs.statSync(file); if (st.isDirectory()) return { kind: 'dir', path: file };
  const ext = EXT(file), base = path.basename(file).toLowerCase(), meta = { path: file, size: st.size, mtime: st.mtimeMs, ext };
  if (MEDIA.test(ext)) return { ...meta, kind: 'media' };
  if (ext === 'pdf') return { ...meta, kind: 'pdf' };
  if (st.size > MAX_FILE) return { ...meta, kind: 'binary', note: 'הקובץ גדול מדי לתצוגה (' + Math.round(st.size / 1048576) + ' MB)', hex: '' };
  const OFFICE = { docx: 1, docm: 1, dotx: 1, dotm: 1, xlsx: 1, xlsm: 1, xltx: 1, pptx: 1, pptm: 1, ppsx: 1, potx: 1, odt: 1, ods: 1, odp: 1, ott: 1 };
  const ARCH = /^(zip|jar|war|apk|aab|vsix|nupkg|xpi|crx|epub|whl|egg|ipa|appx|msix|kmz|cbz|sketch|xd|fig)$/;
  if (OFFICE[ext] || ARCH.test(ext)) {
    const z = readZip(fs.readFileSync(file));
    try {
      if (/^(docx|docm|dotx|dotm)$/.test(ext)) return { ...meta, ...docx(z) };
      if (/^(xlsx|xlsm|xltx)$/.test(ext)) return { ...meta, ...xlsx(z) };
      if (/^(pptx|pptm|ppsx|potx)$/.test(ext)) return { ...meta, ...pptx(z) };
      if (/^(odt|ods|odp|ott)$/.test(ext)) return { ...meta, ...odf(z, ext === 'ott' ? 'odt' : ext) };
    } catch (e) { return { ...meta, kind: 'archive', note: 'לא הצלחתי להציג את המסמך (' + e.message + ') — זה מה שבתוכו:', entries: z.entries.slice(0, 3000).map(e => ({ name: e.name, size: e.size, csize: e.csize, date: e.date, dir: e.dir })) }; }
    return { ...meta, kind: 'archive', entries: z.entries.slice(0, 3000).map(e => ({ name: e.name, size: e.size, csize: e.csize, date: e.date, dir: e.dir })), total: z.entries.length };
  }
  const buf = fs.readFileSync(file);
  if (/^(doc|dot|xls|xlt|ppt|pps|msg|pub|vsd)$/.test(ext) && buf.length > 8 && buf.readUInt32LE(0) === 0xe011cfd0) {
    const note = 'פורמט Office ישן (97-2003) — מוצג התוכן בלי העיצוב. לעיצוב המלא: ↗ פתח באפליקציה ברירת המחדל';
    try {
      const cfb = readCfb(buf);
      if (/^(doc|dot)$/.test(ext)) return { ...meta, kind: 'text', text: legacyDoc(cfb), note };
      if (/^(xls|xlt)$/.test(ext)) return { ...meta, ...legacyXls(cfb), note };
      if (/^(ppt|pps)$/.test(ext)) return { ...meta, ...legacyPpt(cfb), note };
    } catch (e) { /* נופלים לחילוץ הטקסט הגס */ }
    return { ...meta, kind: 'text', text: legacyText(buf), note: 'פורמט ישן — מוצג הטקסט שנמצא בקובץ, בלי עיצוב' };
  }
  if (ext === 'rtf') return { ...meta, kind: 'text', text: rtfText(buf.toString('latin1')), note: 'RTF — הטקסט בלי עיצוב' };
  const big = buf.length > MAX_TEXT, slice = big ? buf.subarray(0, MAX_TEXT) : buf;
  if (isBinary(slice) && !TEXT_EXT.has(ext)) return { ...meta, kind: 'binary', hex: hexDump(buf.subarray(0, 1024)) };
  const text = decode(slice);
  if (/^(json|jsonc|json5|geojson|ipynb|har|webmanifest|map|jsonl|ndjson)$/.test(ext) || /^(package|tsconfig|composer)(-lock)?\.json$/.test(base)) return { ...meta, kind: 'json', text, truncated: big, lines: /^(jsonl|ndjson)$/.test(ext) };
  if (/^(md|markdown|mdx|mdown)$/.test(ext)) return { ...meta, kind: 'markdown', text, truncated: big };
  if (/^(html?|xhtml)$/.test(ext)) return { ...meta, kind: 'html', text, truncated: big };
  if (/^(csv|tsv|tab)$/.test(ext)) return { ...meta, kind: 'table', rows: parseCsv(text, ext === 'tsv' || ext === 'tab' ? '\t' : ''), truncated: big };
  return { ...meta, kind: 'text', text, lang: LANG[ext] || ext || (base === 'dockerfile' ? 'dockerfile' : ''), truncated: big };
}
function hexDump(b) { const out = []; for (let i = 0; i < b.length; i += 16) { const r = b.subarray(i, i + 16); out.push(i.toString(16).padStart(6, '0') + '  ' + [...r].map(x => x.toString(16).padStart(2, '0')).join(' ').padEnd(48) + '  ' + [...r].map(x => (x >= 32 && x < 127 ? String.fromCharCode(x) : '.')).join('')); } return out.join('\n'); }

module.exports = { preview, readZip, docx, xlsx, pptx, parseCsv, legacyText, rtfText };
