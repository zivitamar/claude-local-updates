// Claude Local — שליטה בכרום (תוסף מקומי).
// מתחבר רק לאפליקציה במחשב (ws://127.0.0.1:<port>/api/chrome-bridge) ומבצע בשבילה פעולות בדפדפן הזה:
// רשימת לשוניות, פתיחה/מעבר/סגירה, ופקודות DevTools לדף (chrome.debugger) — קריאת הדף כקוד, לחיצות והקלדה כאירועי קלט בתוך הדפדפן.
// העכבר והמקלדת של המחשב לא נתפסים, והחלון לא נגנב לפוקוס. שום דבר לא נשלח מחוץ למחשב.
'use strict';
const VERSION = chrome.runtime.getManifest().version;
const DEFAULT_PORTS = [3456, 51845];
const conns = new Map();          // port -> { ws, open, port, lastMsg }
const discovered = new Set();     // פורטים שהאפליקציה דיווחה עליהם (שרתים נוספים במחשב)
const attached = new Map();       // tabId -> { at, lastUse }
let claudeGroup = null;           // קבוצת הלשוניות "Claude" (לשוניות חדשות שClaude פותח)
let paused = false;

async function settings() { try { return await chrome.storage.local.get(['ports', 'paused', 'onlyPorts']); } catch { return {}; } }
async function portList() {
  const s = await settings(); paused = !!s.paused;
  const extra = Array.isArray(s.ports) ? s.ports : [];
  const list = s.onlyPorts ? extra : [...DEFAULT_PORTS, ...extra, ...discovered]; // onlyPorts: רק הפורטים שהוגדרו (בדיקות)
  return [...new Set(list)].filter(p => p > 0 && p < 65536);
}

function sendTo(c, o) { try { if (c.open) c.ws.send(JSON.stringify(o)); } catch { } }
function broadcast(o) { for (const c of conns.values()) sendTo(c, o); }

const retry = new Map(); // port -> { fails, next } — פורט שלא עונה (האפליקציה סגורה) נבדק בתדירות יורדת עד פעם ב-20 שניות
function connect(port) {
  if (conns.has(port)) return;
  const rt = retry.get(port); if (rt && Date.now() < rt.next) return;
  let ws; try { ws = new WebSocket(`ws://127.0.0.1:${port}/api/chrome-bridge`); } catch { return; }
  const c = { ws, port, open: false, lastMsg: Date.now() };
  conns.set(port, c);
  ws.addEventListener('close', () => { if (!c.open) { const f = ((retry.get(port) || {}).fails || 0) + 1; retry.set(port, { fails: f, next: Date.now() + Math.min(20000, 1500 * 2 ** f) }); } });
  ws.onopen = async () => {
    c.open = true; retry.delete(port);
    const wins = await chrome.windows.getAll({}).catch(() => []);
    sendTo(c, { type: 'hello', version: VERSION, extId: chrome.runtime.id, windows: wins.length, paused });
    badge();
  };
  ws.onmessage = ev => { c.lastMsg = Date.now(); let m; try { m = JSON.parse(ev.data); } catch { return; } onMessage(c, m); };
  ws.onclose = () => { conns.delete(port); badge(); };
  ws.onerror = () => { };
}

function badge() {
  const n = [...conns.values()].filter(c => c.open).length;
  chrome.action.setBadgeText({ text: paused ? '❚❚' : n ? '●' : '' }).catch(() => { });
  chrome.action.setBadgeBackgroundColor({ color: paused ? '#888' : '#d97757' }).catch(() => { });
}

async function tick() {
  const want = await portList();
  for (const [p, c] of conns) if (!want.includes(p)) { conns.delete(p); try { c.ws.close(); } catch { } } // פורט שהוסר מהרשימה — מתנתקים
  for (const p of want) connect(p);
  for (const c of conns.values()) if (c.open) sendTo(c, { type: 'ping', t: Date.now() }); // שומר את ה-service worker ער כל עוד יש חיבור
  // ניתוק debugger מלשוניות שלא היו בשימוש 90 שניות (הפס "Claude Local מנפה באגים" נעלם)
  for (const [tabId, a] of attached) if (Date.now() - a.lastUse > 90000) { attached.delete(tabId); chrome.debugger.detach({ tabId }).catch(() => { }); }
}

// חלון ללשונית חדשה: החלון האחרון שהמשתמש עבד בו — אבל לא חלון ממוזער (שם הדף בגודל 0 והאתר "נשבר")
async function lastFocusedNormalWindow() {
  try { const w = await chrome.windows.getLastFocused({ windowTypes: ['normal'] }); if (w && w.id != null && w.state !== 'minimized') return w; } catch { }
  const all = await chrome.windows.getAll({ windowTypes: ['normal'] });
  return all.find(w => w.state !== 'minimized') || null; // אין חלון פתוח שאינו ממוזער → tabs.create יפתח חלון חדש (לא בפוקוס)
}
// ===== הדף תמיד בגודל האמיתי של החלון (REQUESTS-10) =====
// אף פעם לא "מזייפים" גודל (Emulation.setDeviceMetricsOverride / setVisibleSize): נמדד ב-Chrome 157 — מזעור לא מכווץ את הדף,
// וגודל מזויף נשאר תקוע אחרי שחזור / הגדלה (היוטיוב "מכווץ" עם שוליים לבנים). במקום זה: אחרי כל פעולה בודקים שהדף בגודל של הלשונית
// (innerWidth/innerHeight מול tab.width/height לפי הזום), ואם לא — מרפאים: clearDeviceMetricsOverride, ואם עדיין לא — ניתוק וחיבור מחדש
async function realSize(tabId) {
  try {
    const t = await chrome.tabs.get(tabId); const z = await chrome.tabs.getZoom(tabId).catch(() => 1);
    const r = await chrome.debugger.sendCommand({ tabId }, 'Runtime.evaluate', { expression: '[innerWidth,innerHeight]', returnByValue: true });
    const [iw, ih] = (r && r.result && r.result.value) || [0, 0];
    const ok = !t.width || !t.height || (Math.abs(iw - t.width / z) <= 2 && Math.abs(ih - t.height / z) <= 2);
    return { ok, iw, ih, tw: t.width, th: t.height, z };
  } catch { return { ok: true }; }
}
async function heal(tabId, force) {
  if (!attached.has(tabId)) return;
  await chrome.debugger.sendCommand({ tabId }, 'Emulation.clearDeviceMetricsOverride').catch(() => { });
  let s = await realSize(tabId); if (s.ok && !force) return s;
  // ניתוק מנקה כל אמולציה (ResetWebContentsEmulation) — מתחברים שוב
  attached.delete(tabId); await chrome.debugger.detach({ tabId }).catch(() => { }); await attach(tabId).catch(() => { });
  return realSize(tabId);
}
// שחזור / הגדלה / שינוי גודל / פוקוס של חלון: בודקים את הלשוניות המחוברות שבו
async function checkWindow(windowId) {
  for (const tabId of [...attached.keys()]) { try { const t = await chrome.tabs.get(tabId); if (t.windowId !== windowId) continue; const w = await chrome.windows.get(windowId); if (w.state === 'minimized') continue; const s = await realSize(tabId); if (!s.ok) await heal(tabId); } catch { } }
}
async function checkTab(tabId) { if (!attached.has(tabId)) return; try { const t = await chrome.tabs.get(tabId); const w = await chrome.windows.get(t.windowId); if (w.state === 'minimized') return; let s = await realSize(tabId); if (!s.ok) { await new Promise(r => setTimeout(r, 300)); s = await realSize(tabId); if (!s.ok) await heal(tabId); } } catch { } }
chrome.tabs.onActivated.addListener(i => checkTab(i.tabId));
chrome.tabs.onZoomChange.addListener(i => checkTab(i.tabId));
chrome.tabs.onUpdated.addListener((id, ch) => { if (ch.status === 'complete') checkTab(id); });
setInterval(() => { for (const id of attached.keys()) checkTab(id); }, 5000);
chrome.windows.onBoundsChanged.addListener(w => { if (w && w.state !== 'minimized') checkWindow(w.id); });
chrome.windows.onFocusChanged.addListener(id => { if (id !== chrome.windows.WINDOW_ID_NONE) checkWindow(id); });
// קלט (לחיצה / הקלדה): "פוקוס מדומה" רק לזמן הפעולה (+2 שניות) — לא כל הזמן (הוא מחזיק את הדף "גלוי" ומבזבז מעבד גם כשהחלון ממוזער)
const focusOff = new Map();
async function focusFor(tabId) {
  clearTimeout(focusOff.get(tabId));
  await chrome.debugger.sendCommand({ tabId }, 'Emulation.setFocusEmulationEnabled', { enabled: true }).catch(() => { });
  focusOff.set(tabId, setTimeout(() => { focusOff.delete(tabId); if (attached.has(tabId)) chrome.debugger.sendCommand({ tabId }, 'Emulation.setFocusEmulationEnabled', { enabled: false }).catch(() => { }); }, 2000));
}

async function listTabs() {
  const [tabs, wins, lf] = await Promise.all([chrome.tabs.query({}), chrome.windows.getAll({}), lastFocusedNormalWindow()]);
  const winIdx = new Map(wins.map((w, i) => [w.id, i + 1]));
  let groups = []; try { groups = await chrome.tabGroups.query({}); } catch { }
  const gName = new Map(groups.map(g => [g.id, g.title || '']));
  return {
    lastFocusedWindow: lf ? lf.id : null,
    tabs: tabs.map(t => ({ id: t.id, windowId: t.windowId, window: winIdx.get(t.windowId) || 0, index: t.index, title: t.title || '', url: t.url || t.pendingUrl || '', active: !!t.active, focusedWindow: !!(lf && t.windowId === lf.id), group: t.groupId >= 0 ? (gName.get(t.groupId) || 'קבוצה') : '', status: t.status, discarded: !!t.discarded, attached: attached.has(t.id) }))
  };
}

async function ensureGroup(tabId, windowId) {
  try {
    if (claudeGroup != null) { const g = await chrome.tabGroups.get(claudeGroup).catch(() => null); if (g && g.windowId === windowId) { await chrome.tabs.group({ tabIds: [tabId], groupId: claudeGroup }); return; } }
    claudeGroup = await chrome.tabs.group({ tabIds: [tabId], createProperties: { windowId } });
    await chrome.tabGroups.update(claudeGroup, { title: 'Claude', color: 'orange' });
  } catch { }
}

// ===== 🚫 הפס "ניפוי באגים של הדפדפן הזה מתבצע על ידי…" — אף פעם (REQUESTS-10) =====
// Chrome מציג את הפס על כל חיבור של chrome.debugger, בכל החלונות, אלא אם (א) Chrome הופעל עם --silent-debugger-extension-api
// או (ב) התוסף מותקן במדיניות ארגונית. השער: לא מתחברים ל-debugger אם אף אחד מהם לא מוכח. את (א) בודקת האפליקציה במחשב —
// היא מוצאת את תהליך הכרום שהתוסף הזה רץ בו (לפי חיבור ה-WebSocket) וקוראת את שורת הפקודה שלו; התשובה מגיעה בהודעת gate.
let gate = { silent: false, reason: 'עוד לא נבדק', at: 0 };
async function gateOk() {
  if (gate.silent) return true;
  try { const me = await chrome.management.getSelf(); if (me && me.installType === 'admin') return true; } catch { } // מותקן במדיניות — Chrome לא מציג את הפס
  return false;
}
async function attach(tabId) {
  const a = attached.get(tabId); if (a) { a.lastUse = Date.now(); return; }
  if (!(await gateOk())) throw new Error('NO_SILENT: ' + (gate.reason || 'Chrome רץ בלי ההגדרה שמונעת את הפס') + ' — לא מתחבר (אחרת Chrome יציג את הפס "ניפוי באגים" בכל החלונות). Chrome צריך להיפתח מחדש פעם אחת עם ההגדרה החדשה.');
  try { await chrome.debugger.attach({ tabId }, '1.3'); }
  catch (e) {
    const msg = String(e && e.message || e);
    if (!/already attached/i.test(msg)) {
      const t = await chrome.tabs.get(tabId).catch(() => null);
      if (t && /^(chrome|edge|about|chrome-extension|devtools):/i.test(t.url || '')) throw new Error('אי אפשר לשלוט בדף מערכת של Chrome (' + (t.url || '').slice(0, 40) + '). פתח אתר רגיל.');
      throw new Error('החיבור ללשונית נכשל: ' + msg);
    }
  }
  attached.set(tabId, { at: Date.now(), lastUse: Date.now() });
  // שאריות של גרסה קודמת (גודל מזויף 1366×900) — מנקים מיד. אין יותר הקפאה / פוקוס קבוע / גודל מזויף
  await chrome.debugger.sendCommand({ tabId }, 'Emulation.clearDeviceMetricsOverride').catch(() => { });
  chrome.debugger.sendCommand({ tabId }, 'Page.enable').catch(() => { });
}

async function op(name, p) {
  p = p || {};
  if (paused && name !== 'status') throw new Error('השליטה בכרום מושהית (בתוסף Claude Local). לחץ על סמל התוסף והפעל מחדש.');
  switch (name) {
    case 'status': return { version: VERSION, paused, attached: [...attached.keys()], ports: [...conns.keys()], gate, installType: await chrome.management.getSelf().then(x => x.installType).catch(() => null) };
    case 'windows.snapshot': { const ws = await chrome.windows.getAll({ populate: true }); return ws.map(w => ({ id: w.id, state: w.state, type: w.type, focused: w.focused, left: w.left, top: w.top, width: w.width, height: w.height, incognito: w.incognito, tabs: (w.tabs || []).map(t => ({ url: t.url || t.pendingUrl || '', pinned: t.pinned, active: t.active, title: t.title || '' })) })); }
    case 'tabs.list': return listTabs();
    case 'tabs.create': {
      const w = p.windowId != null ? { id: p.windowId } : await lastFocusedNormalWindow();
      const t = w ? await chrome.tabs.create({ windowId: w.id, url: p.url || 'about:blank', active: true }) : (await chrome.windows.create({ url: p.url || 'about:blank', focused: false, state: 'normal', width: 1366, height: 900 })).tabs[0];
      await ensureGroup(t.id, t.windowId);
      return { id: t.id, windowId: t.windowId, url: t.url || t.pendingUrl || '', title: t.title || '' };
    }
    case 'tabs.activate': { await chrome.tabs.update(p.tabId, { active: true }); return { ok: true }; }
    case 'tabs.close': { attached.delete(p.tabId); await chrome.tabs.remove(p.tabId); return { ok: true }; }
    case 'tabs.get': { const t = await chrome.tabs.get(p.tabId); return { id: t.id, windowId: t.windowId, url: t.url || '', title: t.title || '', active: t.active, status: t.status }; }
    case 'cdp': {
      const tabId = p.tabId;
      if (p.method === 'Page.bringToFront') { await chrome.tabs.update(tabId, { active: true }); return {}; } // מחליף לשונית בתוך החלון — בלי להעביר את פוקוס המחשב לכרום
      if (/^Emulation\.(setDeviceMetricsOverride|setVisibleSize|setPageScaleFactor|setScrollbarsHidden)$/.test(p.method) || (p.method === 'Page.setWebLifecycleState')) return {}; // אסור: משנה את גודל הדף / מקפיא אותו
      let params = p.params || {};
      if (p.method === 'Page.captureScreenshot') {
        const t = await chrome.tabs.get(tabId); const w = await chrome.windows.get(t.windowId);
        if (w.state === 'minimized') throw new Error('window_minimized: החלון של הלשונית ממוזער — אין צילום מסך (צילום בחלון ממוזער נתקע ומשבש את גודל הדף). אפשר לקרוא את הדף כקוד (snapshot / get_text).');
        const { clip, captureBeyondViewport, fromSurface, ...rest } = params; params = rest; // בלי clip / דף מלא: הם משנים את גודל הדף בזמן הצילום
      }
      await attach(tabId);
      if (/^Input\./.test(p.method)) await focusFor(tabId);
      let r;
      if (p.method === 'Page.captureScreenshot') {
        r = await Promise.race([chrome.debugger.sendCommand({ tabId }, p.method, params), new Promise((_, rej) => setTimeout(() => rej(new Error('screenshot_timeout')), 5000))]).catch(async e => { await heal(tabId, true); throw e; });
      } else r = await chrome.debugger.sendCommand({ tabId }, p.method, params);
      const a = attached.get(tabId); if (a) a.lastUse = Date.now();
      if (/^(Page\.captureScreenshot|Input\.|Page\.navigate)/.test(p.method)) setTimeout(() => checkTab(tabId), 300);
      return r || {};
    }
    case 'detach': { attached.delete(p.tabId); await chrome.debugger.detach({ tabId: p.tabId }).catch(() => { }); return { ok: true }; }
    default: throw new Error('פעולה לא מוכרת: ' + name);
  }
}

async function onMessage(c, m) {
  if (m.type === 'reload') { setTimeout(() => chrome.runtime.reload(), 200); return; } // האפליקציה עדכנה את קבצי התוסף בדיסק
  if (m.type === 'welcome') { for (const p of m.ports || []) if (p && !discovered.has(p)) { discovered.add(p); connect(p); } return; }
  if (m.type === 'gate') { gate = { silent: !!m.silent, reason: m.reason || '', at: Date.now() }; if (!gate.silent && !(await gateOk())) for (const tabId of [...attached.keys()]) { attached.delete(tabId); chrome.debugger.detach({ tabId }).catch(() => { }); } return; }
  if (m.type === 'pong' || m.type === 'ping') return;
  if (m.type !== 'req') return;
  try { const result = await op(m.op, m.params); sendTo(c, { type: 'res', id: m.id, result }); }
  catch (e) { sendTo(c, { type: 'res', id: m.id, error: String(e && e.message || e) }); }
}

chrome.debugger.onEvent.addListener((src, method, params) => {
  if (!src.tabId) return;
  if (method === 'Page.javascriptDialogOpening' || method === 'Page.frameNavigated' || method === 'Page.loadEventFired') broadcast({ type: 'event', tabId: src.tabId, method, params });
});
chrome.debugger.onDetach.addListener((src, reason) => { if (src.tabId) { attached.delete(src.tabId); broadcast({ type: 'event', tabId: src.tabId, method: 'detached', params: { reason } }); } });
chrome.tabs.onRemoved.addListener(tabId => { attached.delete(tabId); broadcast({ type: 'event', tabId, method: 'tabClosed', params: {} }); });
chrome.storage.onChanged.addListener(ch => { if (ch.paused) { paused = !!ch.paused.newValue; badge(); if (paused) for (const tabId of [...attached.keys()]) { attached.delete(tabId); chrome.debugger.detach({ tabId }).catch(() => { }); } } if (ch.ports || ch.onlyPorts) tick(); });
chrome.runtime.onMessage.addListener((msg, _s, reply) => {
  if (msg && msg.q === 'status') { (async () => { const s = await settings(); reply({ version: VERSION, paused: !!s.paused, ports: [...conns.values()].map(c => ({ port: c.port, open: c.open })), attached: [...attached.keys()], extra: s.ports || [] }); })(); return true; }
  if (msg && msg.q === 'detachAll') { for (const tabId of [...attached.keys()]) { attached.delete(tabId); chrome.debugger.detach({ tabId }).catch(() => { }); } reply({ ok: true }); return false; }
  return false;
});
chrome.alarms.create('claude-local-keep', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(() => tick());
chrome.runtime.onStartup.addListener(() => tick());
chrome.runtime.onInstalled.addListener(() => tick());
setInterval(tick, 3000);
tick();
