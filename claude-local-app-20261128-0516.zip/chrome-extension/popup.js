'use strict';
const $ = id => document.getElementById(id);
async function paint() {
  const s = await chrome.runtime.sendMessage({ q: 'status' }).catch(() => null);
  if (!s) { $('st').innerHTML = '<span class="off">התוסף לא עונה</span>'; return; }
  const open = s.ports.filter(p => p.open);
  $('st').innerHTML = s.paused ? '<span class="off">❚❚ מושהה — Claude לא יכול לשלוט בכרום</span>'
    : open.length ? `<span class="ok">● מחובר לאפליקציה</span> <span class="dim">(פורט ${open.map(p => p.port).join(', ')})</span>` + (s.attached.length ? `<div class="dim">Claude עובד עכשיו ב-${s.attached.length} לשוניות</div>` : '')
      : '<span class="off">○ האפליקציה Claude Local לא פתוחה</span>';
  $('pause').textContent = s.paused ? '▶ הפעל שליטה' : '❚❚ השהה שליטה';
  $('pause').onclick = async () => { await chrome.storage.local.set({ paused: !s.paused }); setTimeout(paint, 150); };
  $('detach').onclick = async () => { await chrome.runtime.sendMessage({ q: 'detachAll' }); setTimeout(paint, 150); };
  $('add').onclick = async () => { const p = parseInt($('port').value, 10); if (!(p > 0 && p < 65536)) return; const cur = (await chrome.storage.local.get('ports')).ports || []; await chrome.storage.local.set({ ports: [...new Set([...cur, p])] }); $('port').value = ''; setTimeout(paint, 1500); };
}
paint(); setInterval(paint, 1500);
