'use strict';
// ============================================================
//  מחקר עמוק (הכלי "deep_research"): מתכנן → חוקרים במקביל (תת-סוכנים עם חיפוש/קריאת דפים
//  ברשת) → איסוף מקורות עם מספור → כותב דוח Markdown עם הפניות [n] ורשימת מקורות.
//  כל מחקר נשמר ב-data/research/<id>.json ומופיע בחלון המחקרים, כולל התקדמות חיה.
// ============================================================
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DEPTHS = {
  quick: { subqs: 2, search: 3, fetch: 0, label: 'מהיר' },
  standard: { subqs: 4, search: 5, fetch: 2, label: 'רגיל' },
  deep: { subqs: 6, search: 8, fetch: 4, label: 'עמוק' }
};
const REPORT_CAP = 25000;
const NOTIFY_MS = 400;
const TERMINAL = new Set(['done', 'error', 'stopped', 'interrupted', 'refused']);

const RESEARCH_TOOL = {
  name: 'deep_research',
  description:
    'Run a deep, multi-agent WEB research: a planner splits the question into sub-questions, several researcher sub-agents ' +
    'search and read the web in parallel, and a writer produces a Markdown report with numbered citations [n] and a sources list. ' +
    'Use it when the user asks for researched / sourced / up-to-date information, comparisons, market or technical research. ' +
    'It takes from about 1 minute (quick) to several minutes (deep). Present the returned report to the user (you may shorten it, keep the citations).',
  input_schema: {
    type: 'object',
    properties: {
      question: { type: 'string', description: 'The full research question, with all context needed (the researchers do not see this conversation)' },
      depth: { type: 'string', enum: ['quick', 'standard', 'deep'], description: 'quick = 2 researchers, standard = 4, deep = 6 (more searches and page reads). Default: the user setting' }
    },
    required: ['question']
  }
};

const short = (s, n) => { s = String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
const isHebrew = s => /[\u0590-\u05FF]/.test(String(s || ''));
// כותרת ראשונית (עד 5 מילים) עד שקלוד מנסח כותרת טובה יותר; מחקרים ישנים בלי כותרת מקבלים אותה
function heuristicTitle(q) {
  const t = String(q || '').replace(/https?:\/\/\S+/g, ' ').replace(/[`*_#>\[\]{}()"\u201c\u201d]/g, ' ').replace(/\s+/g, ' ').trim();
  if (!t) return 'מחקר';
  let out = t.split(' ').slice(0, 5).join(' ');
  if (out.length > 40) out = out.slice(0, 40).replace(/\s+\S*$/, '');
  return out || 'מחקר';
}
const today = () => new Date().toISOString().slice(0, 10);

// מוציא JSON מתשובת המתכנן (גם אם עטוף ב-```json או בטקסט)
function parsePlan(text, n, question) {
  const s = String(text || '');
  const a = s.indexOf('{'), b = s.lastIndexOf('}');
  if (a >= 0 && b > a) {
    try {
      const j = JSON.parse(s.slice(a, b + 1));
      const subs = (Array.isArray(j.subquestions) ? j.subquestions : []).map(x => String(x || '').trim()).filter(Boolean);
      if (subs.length) return { language: String(j.language || '').trim(), subquestions: subs.slice(0, n) };
    } catch { }
  }
  const lines = s.split(/\r?\n/).map(l => l.replace(/^\s*(\d+[.)]|[-*•])\s*/, '').trim()).filter(l => l.length > 8 && /\?|\S{4,}/.test(l));
  return { language: '', subquestions: (lines.length ? lines : [question]).slice(0, n) };
}

// הדוח לא מסיים ברשימת מקורות: המקורות מוצגים בנפרד (לשונית "מקורות"). מוחקים סעיף מקורות/Sources אחרון, אם הוא האחרון בדוח
function stripSourcesSection(text) {
  const t = String(text || '');
  const re = /^#{1,6}[ \t]*(?:\*\*)?[ \t]*(?:מקורות|רשימת מקורות|מקורות ו[^\n]*|Sources|References|Bibliography|Source list)[ \t]*(?:\*\*)?[ \t]*:?[ \t]*$/gim;
  let last = -1, m;
  while ((m = re.exec(t))) last = m.index;
  if (last < 0) return t;
  const tail = t.slice(last).split('\n').slice(1).join('\n');
  if (/^#{1,6}[ \t]+\S/m.test(tail)) return t; // אחריו יש סעיף אחר: לא נוגעים
  return t.slice(0, last).replace(/\s+$/, '');
}

function createResearch(deps) {
  const { dataDir, agents, callClaudeSmart, recordUsage, costOf } = deps;
  const DIR = path.join(dataDir, 'research');
  const items = new Map();
  const notifyHandlers = new Set();

  try {
    if (fs.existsSync(DIR)) {
      const files = fs.readdirSync(DIR).filter(f => f.endsWith('.json'))
        .map(f => { try { return { f, t: fs.statSync(path.join(DIR, f)).mtimeMs }; } catch { return null; } })
        .filter(Boolean).sort((a, b) => b.t - a.t).slice(0, 200);
      for (const { f } of files) {
        try {
          const r = JSON.parse(fs.readFileSync(path.join(DIR, f), 'utf8'));
          if (!r || !r.id) continue;
          if (!TERMINAL.has(r.status)) {
            // מחקר חיצוני (רץ בתוך Claude Code שחי במארח) — ייתכן שימשיך אחרי הפעלה מחדש: שומרים את המצב הקודם לאימוץ
            if (r.kind === 'cli') { r._bootStatus = r.status; r._bootPhase = r.phase; r._bootEndedAt = r.endedAt || null; }
            r.status = 'interrupted'; r.phase = 'הופסק (השרת נסגר)'; r.endedAt = r.endedAt || Date.now();
          }
          // תיקון מחקרים ישנים שסומנו "הושלם" בטעות: בלי דוח ובלי מקורות = נכשל (כנראה סירוב). עם דוח אבל בלי חוקרים ובלי מקורות = תשובה ולא מחקר
          if (r.status === 'done' && !(r.sources || []).length && !(r.subquestions || []).length) {
            if (!String(r.report || '').trim()) { r.status = 'error'; r.error = r.error || 'המחקר סומן "הושלם" בטעות: לא נכתב דוח ולא נאספו מקורות (כנראה Claude סירב).'; r.phase = 'שגיאה: לא נכתב דוח'; }
            else { r.noResearch = true; r.phase = 'הסתיים — תשובה בלי חוקרים ובלי מקורות'; }
          }
          r.listeners = new Set();
          items.set(r.id, r);
        } catch { }
      }
    }
  } catch { }

  function serialize(r) { const { listeners, controller, _t, _last, onUpdate, _num, _seen, _pend, _seenBase, _bootStatus, _bootPhase, _bootEndedAt, ...rest } = r; return rest; }
  function persist(r) {
    try { fs.mkdirSync(DIR, { recursive: true }); fs.writeFileSync(path.join(DIR, r.id + '.json'), JSON.stringify(serialize(r)), 'utf8'); }
    catch (e) { console.error('[research] persist failed', e.message); }
  }
  function summary(r) {
    return {
      id: r.id, convId: r.convId || null, parentToolId: r.parentToolId || null, parentConvId: r.parentConvId || null, question: r.question, depth: r.depth,
      model: r.model, status: r.status, phase: r.phase,
      subquestions: (r.subquestions || []).map(s => ({ q: s.q, agentId: s.agentId || null, status: s.status, activity: s.activity || '' })),
      sourcesCount: (r.sources || []).length, seenCount: r.seenCount || 0, fetchCalls: r.fetchCalls || 0, fetchFailed: r.fetchFailed || 0, costUSD: r.costUSD, tokens: r.tokens || null, pct: r.pct || null, startedAt: r.startedAt,
      endedAt: r.endedAt || null, error: r.error || null, reportPreview: r.report ? short(r.report, 240) : '',
      title: r.title || heuristicTitle(r.question), folderId: r.folderId || null, effort: r.effort || '', noResearch: !!r.noResearch, loopEnded: r.loopEnded || null, loopError: r.loopError || null,
      opts: r.opts || null, queriesCount: (r.queries || []).length, summaryReady: !!r.summaryText, rounds: r.rounds || 0, minSourcesMissed: !!r.minSourcesMissed, overMax: r.overMax || 0, blockedCalls: r.blockedCalls || 0,
      refusal: r.refusal || null, chainId: r.chainId || r.id, attempt: r.attempt || 1, retryMode: r.retryMode || null, retriedAs: r.retriedAs || null,
      originalQuestion: r.originalQuestion || null, rephrased: !!r.rephrased, loop: r.loop || null
    };
  }
  function notifyNow(r) {
    clearTimeout(r._t); r._t = null; r._last = Date.now();
    const s = summary(r);
    for (const h of notifyHandlers) { try { h(s); } catch (e) { console.error('[research] notify', e.message); } }
    for (const l of r.listeners) { try { l('update', s); } catch { } }
  }
  function notify(r) {
    if (r._t) return;
    const wait = NOTIFY_MS - (Date.now() - (r._last || 0));
    if (wait <= 0) return notifyNow(r);
    r._t = setTimeout(() => notifyNow(r), wait);
  }
  const setPhase = (r, status, phase) => { r.status = status; r.phase = phase; persist(r); notifyNow(r); };
  const addCost = (r, model, u) => {
    r.costUSD += costOf(model, u || {});
    r.tokens.input += ((u && u.input_tokens) || 0) + ((u && u.cache_read_input_tokens) || 0) + ((u && u.cache_creation_input_tokens) || 0);
    r.tokens.output += (u && u.output_tokens) || 0;
    try { recordUsage(model, u || {}); } catch { }
  };

  // ---------- מקורות ----------
  function release(r, url) { if (r._pend instanceof Map && url) r._pend.delete(String(url).replace(/#.*$/, '').replace(/\/$/, '')); }
  function sourceNum(r, url, title, snippet) {
    if (!url) return 0;
    const key = String(url).replace(/#.*$/, '').replace(/\/$/, '');
    let s = r._num.get(key);
    if (!s) {
      const max = (r.opts && r.opts.maxSources) || 0;
      if (max > 0 && r.sources.length >= max) { r.overMax = (r.overMax || 0) + 1; seen(r, url, title); return 0; } // מקסימום מקורות: לא נספר מעבר למה שנקבע
      s = { n: r.sources.length + 1, url, title: title || '', snippets: [] };
      r.sources.push(s); r._num.set(key, s);
    }
    if (title && !s.title) s.title = title;
    const sn = short(snippet, 300);
    if (sn && s.snippets.length < 3 && !s.snippets.includes(sn)) s.snippets.push(sn);
    return s.n;
  }
  function seen(r, url, title, pageAge) {
    if (!url) return;
    const key = String(url).replace(/#.*$/, '').replace(/\/$/, '');
    if (!r._seen.has(key)) { r._seen.set(key, { url, title: title || '', pageAge: pageAge || null }); r.seenCount = r._seen.size + (r._seenBase || 0); }
  }
  // עובר על תוכן תשובה של חוקר: תוצאות חיפוש, דפים שנקראו, הפניות בטקסט → טקסט עם [n]
  function absorb(r, sub, content) {
    let annotated = '';
    for (const b of content || []) {
      if (b.type === 'web_search_tool_result' && Array.isArray(b.content)) {
        for (const x of b.content) if (x && x.url) seen(r, x.url, x.title, x.page_age);
      } else if (b.type === 'web_fetch_tool_result' && b.content && b.content.url) {
        const doc = b.content.content || {};
        sourceNum(r, b.content.url, doc.title || '', '');
      } else if (b.type === 'text' && b.text) {
        let t = b.text;
        if (Array.isArray(b.citations) && b.citations.length) {
          const nums = [...new Set(b.citations.filter(c => c && c.url).map(c => sourceNum(r, c.url, c.title, c.cited_text)).filter(Boolean))];
          if (nums.length) t += ' ' + nums.map(n => `[${n}]`).join('');
        }
        annotated += t;
      }
    }
    if (annotated.trim()) sub.findings = ((sub.findings || '') + annotated).slice(-20000);
    notify(r);
  }

  // ---------- הריצה ----------
  async function run(o) {
    const cfg = o.cfg;
    const depth = DEPTHS[o.depth] ? o.depth : (DEPTHS[cfg.researchDepth] ? cfg.researchDepth : 'standard');
    const D = DEPTHS[depth];
    const model = deps.resolveModel(o.model || cfg.researchModel, cfg.researchModel || cfg.agentModel || cfg.model);
    const r = {
      id: crypto.randomUUID(), convId: o.convId || null, parentToolId: o.parentToolId || null,
      question: String(o.question || '').trim(), depth, model, effort: o.effort || '', status: 'planning', phase: 'מתכנן את המחקר…',
      subquestions: [], sources: [], seenCount: 0, report: '', language: '', startedAt: Date.now(), endedAt: null,
      costUSD: 0, tokens: { input: 0, output: 0 }, error: null,
      listeners: new Set(), controller: new AbortController(), _num: new Map(), _seen: new Map()
    };
    items.set(r.id, r);
    if (o.onStart) { try { o.onStart(r.id); } catch { } }
    const onParentAbort = () => r.controller.abort();
    if (o.parentSignal) { if (o.parentSignal.aborted) r.controller.abort(); else o.parentSignal.addEventListener('abort', onParentAbort, { once: true }); }
    const signal = r.controller.signal;
    const baseCfg = { ...cfg, model, ultracode: false, autoFallback: false, effort: (o.effort && o.effort !== 'default') ? o.effort : 'default', showThinking: true };
    persist(r); notifyNow(r);

    try {
      if (!r.question) throw new Error('Empty research question');
      // 1) מתכנן
      const plannerPrompt = `Break the research question below into ${D.subqs} focused, non-overlapping sub-questions that together fully answer it.
Each sub-question must be self-contained (include names, places, dates and context), specific and web-searchable.
Today's date: ${today()}.
Return ONLY JSON, no other text: {"language": "<the language the question is written in, e.g. Hebrew / English>", "subquestions": ["...", "..."]}

Research question:
${r.question}`;
      const plan = await callClaudeSmart({
        cfg: { ...baseCfg, thinking: 'off', maxTokens: 4000 }, system: 'You are a meticulous research planner. You output only valid JSON.',
        rawMessages: [{ role: 'user', content: [{ type: 'text', text: plannerPrompt }] }], signal, emit: () => { }, tools: []
      });
      addCost(r, plan.servedModel || model, plan.usage);
      const planText = (plan.content || []).filter(b => b.type === 'text').map(b => b.text).join('\n');
      const parsed = parsePlan(planText, D.subqs, r.question);
      r.language = parsed.language || (isHebrew(r.question) ? 'Hebrew' : 'English');
      r.subquestions = parsed.subquestions.map(q => ({ q, agentId: null, status: 'queued', activity: 'ממתין…', findings: '' }));
      setPhase(r, 'researching', `${r.subquestions.length} חוקרים עובדים במקביל…`);

      // 2) חוקרים במקביל (כל אחד הוא תת-סוכן שמופיע גם בפאנל הסוכנים)
      const tools = deps.webTools({ search: D.search, fetch: D.fetch });
      const betas = D.fetch > 0 ? deps.webBetas() : [];
      const researcherSystem = `You are a web researcher sub-agent inside "Claude Local Chat". Research ONE sub-question of a bigger research question.
- Use web_search with several different, precise queries${D.fetch ? '; use web_fetch to read the 1-2 most relevant pages in full' : ''}.
- Prefer primary, authoritative and recent sources; cross-check important facts across sources.
- Then write your findings: concrete facts, numbers, dates, names and quotes, each supported by the sources you found. Note disagreements and uncertainty.
- At most ~450 words. Write in ${r.language}. Today's date: ${today()}.`;
      const results = await Promise.all(r.subquestions.map((sub, idx) => agents.runSubAgent({
        kind: 'research', description: `חוקר ${idx + 1}: ${short(sub.q, 70)}`,
        prompt: `Main research question (context only): ${r.question}\n\nYour sub-question: ${sub.q}`,
        system: researcherSystem, model, tools, betas, cfg: baseCfg, parentSignal: signal,
        convId: r.convId, parentToolId: r.parentToolId, researchId: r.id, cwd: o.cwd, maxSteps: 8, maxTokens: 16000,
        onContent: content => absorb(r, sub, content),
        onUpdate: s => { sub.agentId = s.id; sub.status = s.status; sub.activity = s.activity; notify(r); }
      }).then(res => {
        sub.agentId = res.id; sub.status = res.status; sub.activity = res.status === 'done' ? 'הסתיים' : (res.error || res.status);
        addCostOnly(r, res);
        if (!sub.findings && res.result) sub.findings = res.result;
        return res;
      })));
      if (signal.aborted) throw Object.assign(new Error('aborted'), { name: 'AbortError' });
      const ok = results.filter(x => x.status === 'done');
      if (!ok.length) throw new Error('כל החוקרים נכשלו: ' + results.map(x => x.error || x.status).join('; '));

      // אם המודל לא ציטט כלום — ממספרים את תוצאות החיפוש הראשונות כמקורות
      if (!r.sources.length) for (const s of [...r._seen.values()].slice(0, 15)) sourceNum(r, s.url, s.title, '');

      // 3) כותב הדוח (בשידור חי לחלון המחקר)
      setPhase(r, 'writing', 'כותב את הדוח…');
      const srcList = r.sources.slice(0, 80).map(s => `[${s.n}] ${s.title || '(untitled)'} — ${s.url}${s.snippets.length ? '\n    ' + s.snippets.map(x => `"${x}"`).join('\n    ') : ''}`).join('\n');
      const findings = r.subquestions.map((s, i) => `### Sub-question ${i + 1}: ${s.q}\n${s.status === 'done' ? (s.findings || '(no findings)').slice(0, 9000) : '(this researcher did not finish: ' + s.status + ')'}`).join('\n\n');
      const writerPrompt = `Research question: ${r.question}
Today's date: ${today()}

Write the final research report in ${r.language}, in Markdown:
- Start with a heading and a short, direct answer (2-4 sentences).
- Then well-organized sections with the important details; use tables where they help (comparisons, numbers).
- Cite sources inline with their numbers in square brackets right after each claim, e.g. [3] or [2][5]. Use ONLY the numbered sources listed below — never invent sources or numbers.
- Point out disagreements between sources and anything uncertain or unverified.
- Do NOT add a sources / references list at the end — it is appended automatically.

Numbered sources:
${srcList || '(none)'}

Findings from the researchers (the [n] markers refer to the numbered sources):
${findings}`;
      const writer = await callClaudeSmart({
        cfg: { ...baseCfg, thinking: 'auto', maxTokens: 32000 }, system: 'You are a meticulous research writer. You only state what the provided sources support, and you cite them.',
        rawMessages: [{ role: 'user', content: [{ type: 'text', text: writerPrompt }] }], signal, tools: [],
        emit: (type, d) => {
          if (type === 'text' && d.text) { r.report += d.text; for (const l of r.listeners) { try { l('delta', d.text); } catch { } } notify(r); }
        }
      });
      addCost(r, writer.servedModel || model, writer.usage);
      const body = (writer.content || []).filter(b => b.type === 'text').map(b => b.text).join('\n').trim() || r.report.trim();
      r.report = stripSourcesSection(body);
      r.endedAt = Date.now();
      setPhase(r, 'done', 'הושלם');
    } catch (e) {
      r.endedAt = Date.now();
      if (signal.aborted || e.name === 'AbortError') setPhase(r, 'stopped', 'נעצר');
      else { r.error = e.message; setPhase(r, 'error', 'שגיאה: ' + short(e.message, 100)); }
    } finally {
      if (o.parentSignal) o.parentSignal.removeEventListener('abort', onParentAbort);
      r.controller = null;
      for (const l of r.listeners) { try { l('end', summary(r)); } catch { } }
    }
    return r;
  }
  // עלות החוקרים כבר נרשמה בשימוש הכללי ע"י agents — כאן רק מצרפים לסכום של המחקר
  function addCostOnly(r, res) {
    r.costUSD += res.costUSD || 0;
    if (res.tokens) { r.tokens.input += res.tokens.input || 0; r.tokens.output += res.tokens.output || 0; }
  }

  // ---------- הכלי מתוך הסוכן הראשי ----------
  async function runResearchTool(input, ctx) {
    const i = input || {};
    if (!String(i.question || '').trim()) return { output: 'The "question" field is required.', is_error: true };
    const r = await run({ question: i.question, depth: i.depth, cfg: ctx.cfg, convId: ctx.convId, parentToolId: ctx.toolId, parentSignal: ctx.signal, cwd: ctx.cwd });
    const secs = Math.round(((r.endedAt || Date.now()) - r.startedAt) / 1000);
    const head = `(Deep research ${r.id.slice(0, 8)} · ${r.depth} · ${r.sources.length} sources · ${secs}s · $${r.costUSD.toFixed(4)})`;
    if (r.status === 'stopped') return { output: head + '\nThe research was stopped before it finished.', is_error: true };
    if (r.status !== 'done') return { output: head + '\nThe research failed: ' + (r.error || r.status), is_error: true };
    let rep = r.report;
    if (r.sources.length) rep += '\n\n## ' + (isHebrew(r.question) ? 'מקורות' : 'Sources') + '\n' + r.sources.map(s => `${s.n}. [${(s.title || s.url).replace(/[[\]]/g, '')}](${s.url})`).join('\n'); // לכלי בשיחה: כן מצרפים את רשימת המקורות
    if (rep.length > REPORT_CAP) rep = rep.slice(0, REPORT_CAP) + '\n\n…(the report was truncated here; the full report is in the Research panel)';
    return { output: head + '\n\n' + rep, is_error: false };
  }

  // מחקר עצמאי מכפתור בממשק (לא קשור לשיחה) — חוזר מיד עם id, רץ ברקע
  function start({ question, depth, cfg }) {
    return new Promise((resolve, reject) => {
      if (!String(question || '').trim()) return reject(Object.assign(new Error('Empty question'), { status: 400 }));
      run({ question, depth, cfg, onStart: id => resolve(id) }).catch(e => console.error('[research] standalone', e.message));
    });
  }

  // ---------- מחקר "חיצוני": רץ בתוך Claude Code (מצב מנוי). המנוע מעדכן, אנחנו רק רושמים, שומרים ומשדרים לחלון המחקר ----------
  function createExternal(o) {
    const r = {
      id: crypto.randomUUID(), convId: o.convId || null, parentToolId: o.parentToolId || null, question: String(o.question || '').trim(),
      depth: DEPTHS[o.depth] ? o.depth : 'standard', model: o.model || '', effort: o.effort || '', title: o.title || '', status: 'planning', phase: 'מתכנן את המחקר…', subquestions: [], sources: [], seenCount: 0,
      report: '', language: '', startedAt: Date.now(), endedAt: null, costUSD: 0, tokens: { input: 0, output: 0 }, error: null, kind: 'cli', opts: o.opts || null, summaryText: '', queries: [], rounds: 0,
      ...((o.meta && typeof o.meta === 'object') ? o.meta : {}),
      listeners: new Set(), controller: extController(o.onStop), _num: new Map(), _seen: new Map()
    };
    items.set(r.id, r); persist(r); notifyNow(r);
    return extHandle(r);
  }
  function extController(onStop) { return { abort: () => { try { if (onStop) onStop(); } catch { } } }; }
  // אימוץ מחקר חיצוני אחרי הפעלה מחדש של השרת (Claude Code המשיך לרוץ במארח). null = אין מה לאמץ
  function adoptExternal(id, { onStop } = {}) {
    const r = items.get(id);
    if (!r || r.kind !== 'cli') return null;
    if (r.controller && !TERMINAL.has(r.status)) { r.controller = extController(onStop); return extHandle(r); } // כבר מאומץ
    if (!r._bootStatus) return null;
    r.status = r._bootStatus; r.phase = r._bootPhase || 'ממשיך…'; r.endedAt = r._bootEndedAt || null;
    delete r._bootStatus; delete r._bootPhase; delete r._bootEndedAt;
    if (!Array.isArray(r.sources)) r.sources = [];
    if (!Array.isArray(r.subquestions)) r.subquestions = [];
    if (!Array.isArray(r.queries)) r.queries = [];
    if (typeof r.report !== 'string') r.report = String(r.report || '');
    // מפות פנימיות (לא נשמרות לדיסק) נבנות מחדש מהמקורות — המספור [n] נשמר ולא מתחיל מ-1
    r._num = new Map(); r._seen = new Map(); r._pend = new Map();
    for (const s of r.sources) {
      if (!s || !s.url) continue;
      if (!Array.isArray(s.snippets)) s.snippets = [];
      const key = String(s.url).replace(/#.*$/, '').replace(/\/$/, '');
      r._num.set(key, s);
    }
    r._seenBase = Math.max(0, r.seenCount || 0); // הקישורים שנראו לפני ההפעלה מחדש לא נשמרו — הספירה ממשיכה מהמספר שהיה
    r.seenCount = r._seenBase;
    r.controller = extController(onStop);
    persist(r); notifyNow(r);
    return extHandle(r);
  }
  function extHandle(r) {
    return {
      id: r.id, isDone: () => TERMINAL.has(r.status),
      setPhase: (status, phase) => { if (!TERMINAL.has(r.status)) setPhase(r, status, phase); },
      addSub: (q, agentId) => { r.subquestions.push({ q: short(q, 300), agentId: agentId || null, status: 'running', activity: 'עובד…', findings: '' }); notify(r); return r.subquestions.length - 1; },
      updateSub: (i, patch) => { const s = r.subquestions[i]; if (s) { Object.assign(s, patch); notify(r); } },
      source: (url, title, snippet) => { const n = sourceNum(r, url, title, snippet); release(r, url); notify(r); return n; },
      release: url => release(r, url), // דף שהקריאה שלו נכשלה: משחרר את המקום ששמר
      setTopicFail: m => { r.topicFail = { ...(m || {}) }; notify(r); },
      seen: (url, title) => { seen(r, url, title); notify(r); },
      appendReport: text => { r.report += text; for (const l of r.listeners) { try { l('delta', text); } catch { } } notify(r); },
      setReport: text => { r.report = stripSourcesSection(text); notify(r); },
      sourceCount: () => r.sources.length,
      sourceUrls: () => r.sources.map(s => s.url),
      hasReport: () => !!String(r.report || '').trim(),
      setSummary: text => { r.summaryText = String(text || '').trim(); notify(r); },
      addQuery: (q, sub) => { q = short(q, 300); if (!q || r.queries.some(x => x.q === q)) return; r.queries.push({ q, sub: sub == null ? null : sub, at: Date.now() }); if (r.queries.length > 600) r.queries.shift(); notify(r); },
      setRounds: n => { r.rounds = n; notify(r); },
      markMissed: v => { r.minSourcesMissed = !!v; },
      setCost: (costUSD, tokens, pct, live) => { if (costUSD != null) r.costUSD = costUSD; if (tokens) r.tokens = tokens; if (pct !== undefined) r.pct = pct; if (live) notify(r); }, // live = באמצע הריצה: הכרטיס והמסך מתעדכנים
      finish: (status, { error, refusal } = {}) => {
        if (TERMINAL.has(r.status)) return;
        r.endedAt = Date.now(); r.controller = null; if (error) r.error = error;
        if (status === 'refused') r.refusal = { text: String(refusal || error || ''), at: Date.now() };
        r.report = stripSourcesSection(r.report); // המקורות בלשונית נפרדת — לא ברשימה בסוף הדוח
        if (status === 'done' && !r.subquestions.length && !r.sources.length) r.noResearch = true; // קלוד ענה ישירות: בלי חוקרים ובלי מקורות — תשובה ולא מחקר (ייתכן שסירב בתוכן התשובה)
        setPhase(r, status, status === 'done' ? (r.noResearch ? 'הסתיים — תשובה בלי חוקרים ובלי מקורות' : 'הושלם') : status === 'stopped' ? 'נעצר' : status === 'refused' ? 'Claude סירב לבצע את המחקר' : 'שגיאה: ' + short(error || '', 100));
        for (const l of r.listeners) { try { l('end', summary(r)); } catch { } }
      }
    };
  }

  // ---------- תיקיות מחקרים + מחיקה ----------
  const FOLDERS_FILE = path.join(dataDir, 'research-folders.json');
  let folderList = [];
  try { const j = JSON.parse(fs.readFileSync(FOLDERS_FILE, 'utf8')); if (Array.isArray(j)) folderList = j.filter(f => f && f.id && f.name); } catch { }
  const saveFolders = () => { try { fs.mkdirSync(dataDir, { recursive: true }); fs.writeFileSync(FOLDERS_FILE, JSON.stringify(folderList), 'utf8'); } catch (e) { console.error('[research] folders', e.message); } };
  const folders = () => folderList.map(f => ({ ...f }));
  function upsertFolder({ id, name }) {
    name = String(name || '').trim().slice(0, 60); if (!name) return null;
    let f = id && folderList.find(x => x.id === id);
    if (f) f.name = name; else { f = { id: crypto.randomUUID(), name, createdAt: Date.now() }; folderList.push(f); }
    saveFolders(); return { ...f };
  }
  function removeFolder(id) {
    const i = folderList.findIndex(f => f.id === id); if (i < 0) return false;
    folderList.splice(i, 1); saveFolders();
    for (const r of items.values()) if (r.folderId === id) { delete r.folderId; persist(r); notifyNow(r); } // המחקרים לא נמחקים: חוזרים ל"ללא תיקייה"
    return true;
  }
  // מחיקת מחקר (ושרשרת הניסיונות שלו). מחקר שרץ נעצר קודם. מחזיר את הרשומות שנמחקו (כדי שהשרת ימחק גם את השיחות שלהן)
  function remove(id) {
    const r = items.get(id); if (!r) return null;
    const chain = r.chainId || r.id;
    const victims = [...items.values()].filter(x => x.id === id || (x.chainId || x.id) === chain);
    const gone = [];
    for (const v of victims) {
      if (v.controller) { try { v.controller.abort(); } catch { } }
      for (const l of v.listeners || []) { try { l('end', summary(v)); } catch { } }
      items.delete(v.id);
      try { fs.unlinkSync(path.join(DIR, v.id + '.json')); } catch { }
      gone.push({ id: v.id, convId: v.convId || null, chainId: chain });
    }
    return gone;
  }

  // עדכון שדות שרשרת הניסיונות (attempt / retriedAs / loop ...) על מחקר קיים — נשמר ומשודר לחלון המחקר
  function annotate(id, patch) {
    const r = items.get(id); if (!r) return false;
    for (const [k, v] of Object.entries(patch || {})) { if (v === null) delete r[k]; else r[k] = v; }
    persist(r); notifyNow(r); return true;
  }
  function list({ limit = 100 } = {}) { return [...items.values()].sort((a, b) => b.startedAt - a.startedAt).slice(0, limit).map(summary); }
  function get(id) { const r = items.get(id); return r ? { ...serialize(r), summary: summary(r) } : null; }
  function liveFor(convId) { let r = null; for (const x of items.values()) if (x.convId === convId && !TERMINAL.has(x.status)) r = x; return r; }
  // מההוק PostToolUse (כל הסוכנים, גם החוקרים): דף שנקרא בהצלחה = מקור; נכשל = משחרר את המקום
  function hookFetch(convId, url, ok, title) {
    const r = liveFor(convId); if (!r || !url) return false;
    r.fetchCalls = (r.fetchCalls || 0) + 1; if (!ok) r.fetchFailed = (r.fetchFailed || 0) + 1;
    if (ok) sourceNum(r, url, '', ''); release(r, url); notify(r); return true;
  }
  function hookSearch(convId, query, resp) {
    const r = liveFor(convId); if (!r) return false;
    const q = short(query, 300); if (q && !r.queries.some(x => x.q === q)) { r.queries.push({ q, sub: null, at: Date.now() }); if (r.queries.length > 600) r.queries.shift(); }
    const txt = typeof resp === 'string' ? resp : JSON.stringify(resp || '');
    for (const m of txt.matchAll(/"title"\s*:\s*"((?:[^"\\]|\\.)*)"\s*,\s*"url"\s*:\s*"([^"]+)"/g)) seen(r, m[2], m[1].replace(/\\"/g, '"'));
    notify(r); return true;
  }
  // מצב המקורות של המחקר החי בשיחה (להוק: אכיפת מקסימום מקורות לפני ש-WebSearch / WebFetch רצים)
  function sourceGateInfo(convId, url) {
    let r = null; for (const x of items.values()) if (x.convId === convId && !TERMINAL.has(x.status)) r = x;
    if (!r) return null;
    const key = url ? String(url).replace(/#.*$/, '').replace(/\/$/, '') : '';
    // שמירת מקום: דף שאושר לקריאה תופס מקום עד שהתוצאה שלו חוזרת — כך חוקרים במקביל לא עוברים יחד את המקסימום
    const pend = (r._pend instanceof Map) ? r._pend : (r._pend = new Map()); const now = Date.now();
    for (const [k, t] of pend) if (now - t > 180000 || (r._num && r._num.has(k))) pend.delete(k);
    return { id: r.id, count: r.sources.length, pending: pend.size, min: (r.opts && r.opts.minSources) || 0, max: (r.opts && r.opts.maxSources) || 0, known: !!(key && r._num && r._num.has(key)), reserved: !!(key && pend.has(key)),
      reserve: () => { if (key) pend.set(key, now); }, blocked: () => { r.blockedCalls = (r.blockedCalls || 0) + 1; },
      agents: (r.opts && r.opts.agents) || null, activeSubs: r.subquestions.filter(s => s.status !== 'error').length, topicFail: r.topicFail || {} };
  }
  function stop(id) { const r = items.get(id); if (!r || !r.controller) return false; r.controller.abort(); return true; }
  function stopAll({ convId } = {}) { let n = 0; for (const r of items.values()) if (r.controller && (!convId || r.convId === convId)) { r.controller.abort(); n++; } return n; }
  function subscribe(id, fn) { const r = items.get(id); if (!r) return null; r.listeners.add(fn); return () => r.listeners.delete(fn); }
  function onNotify(fn) { notifyHandlers.add(fn); return () => notifyHandlers.delete(fn); }
  function runningCount(convId) { let n = 0; for (const r of items.values()) if (r.controller && (!convId || r.convId === convId)) n++; return n; }
  // מחקרים שרצים בתוך תהליך השרת (סוכני API) — לא שורדים החלפת שרת. מחקר 'cli' רץ בתוך Claude של שיחה (במארח) וממשיך
  function inProcessCount() { let n = 0; for (const r of items.values()) if (r.controller && r.kind !== 'cli') n++; return n; }

  return { RESEARCH_TOOL, DEPTHS, run, runResearchTool, start, createExternal, adoptExternal, annotate, remove, folders, upsertFolder, removeFolder, heuristicTitle, list, get, sourceGateInfo, hookFetch, hookSearch, stop, stopAll, subscribe, onNotify, summary, runningCount, inProcessCount, isTerminal: s => TERMINAL.has(s) };
}

module.exports = { createResearch, RESEARCH_TOOL, DEPTHS, parsePlan, stripSourcesSection };
