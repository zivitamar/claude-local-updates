'use strict';
// ============================================================
//  claude_cli.js — חיבור לחשבון המנוי (Pro/Max/Ultra) דרך Claude Code הרשמי (אותו מנגנון כמו תוסף VS Code):
//   • מציאת הקובץ claude.exe (אצל התוסף של VS Code או ב-PATH) — הגרסה החדשה ביותר
//   • כניסה / יציאה / החלפת חשבון:  claude auth login | logout | status   (הכניסה פותחת את הדפדפן, מאמתים שם,
//     והפרטים נשמרים אוטומטית ב-~/.claude/.credentials.json — בדיוק כמו ב-VS Code)
//   • נתוני שימוש אמיתיים של המנוי (5 שעות / שבועי / לפי מודל + שימוש נוסף) דרך בקשת הבקרה get_usage של ה-CLI עצמו
//   • רשימת פקודות ה-/ של Claude Code (initialize)
//  למה לא קריאה ישירה ל-API עם הטוקן של המנוי? בדקנו: ה-API דוחה (429) כל בקשה שמגיעה מאפליקציה צד-שלישי עם טוקן מנוי,
//  ולכן שיחות במצב מנוי רצות דרך ה-CLI הרשמי (cli_engine.js). ראה docs/SUBSCRIPTION.md.
// ============================================================
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');

const IS_WIN = process.platform === 'win32';
const HOME = os.homedir();
const ENTRYPOINT = 'claude-local-chat';

// ---------- מציאת ה-CLI ----------
const verParts = v => String(v || '0').split(/[.\-]/).map(x => parseInt(x, 10) || 0);
function cmpVer(a, b) { const A = verParts(a), B = verParts(b); for (let i = 0; i < 4; i++) { const d = (A[i] || 0) - (B[i] || 0); if (d) return d; } return 0; }

// העותק של האפליקציה עצמה (לא תלוי ב-VS Code): %LOCALAPPDATA%\ClaudeLocal\cli\<גרסה>\claude.exe
// כשנמצא רק העותק שבתוך התוסף של VS Code — הוא מועתק לכאן (VS Code יכול להיות סגור, להתעדכן או להימחק — האפליקציה ממשיכה).
// במחשב בלי Claude Code בכלל (חבר בלי VS Code) — האפליקציה מורידה לבד את הגרסה הרשמית (downloads.claude.ai) ובודקת SHA-256.
const APP_HOME = IS_WIN ? path.join(process.env.LOCALAPPDATA || path.join(HOME, 'AppData', 'Local'), 'ClaudeLocal') : path.join(process.env.XDG_DATA_HOME || path.join(HOME, '.local', 'share'), 'claude-local');
const APP_CLI_ROOT = process.env.CLAUDE_LOCAL_CLI_DIR || path.join(APP_HOME, 'cli');
function candidatePaths() {
  const out = [];
  if (process.env.CLAUDE_CLI_PATH) out.push({ path: process.env.CLAUDE_CLI_PATH, source: 'env' });
  const exe = IS_WIN ? 'claude.exe' : 'claude';
  try { for (const v of fs.readdirSync(APP_CLI_ROOT)) if (/^\d+\.\d+\.\d+/.test(v)) out.push({ path: path.join(APP_CLI_ROOT, v, exe), source: 'app' }); } catch { }
  for (const base of ['.vscode', '.vscode-insiders', '.cursor', '.windsurf', '.vscode-oss']) {
    const dir = path.join(HOME, base, 'extensions');
    let names = [];
    try { names = fs.readdirSync(dir).filter(n => /^anthropic\.claude-code-/i.test(n)); } catch { }
    for (const n of names) {
      const m = n.match(/claude-code-(\d+\.\d+\.\d+)/);
      out.push({ path: path.join(dir, n, 'resources', 'native-binary', exe), source: 'vscode:' + base, hintVersion: m && m[1] });
    }
  }
  for (const d of String(process.env.PATH || '').split(path.delimiter).filter(Boolean)) {
    out.push({ path: path.join(d, exe), source: 'path' });
    // npm-global: <npm>/node_modules/@anthropic-ai/claude-code/bin/claude.exe
    out.push({ path: path.join(d, 'node_modules', '@anthropic-ai', 'claude-code', 'bin', exe), source: 'npm' });
  }
  if (IS_WIN && process.env.LOCALAPPDATA) out.push({ path: path.join(process.env.LOCALAPPDATA, 'Programs', 'claude', exe), source: 'local' });
  out.push({ path: path.join(HOME, '.local', 'bin', exe), source: 'local' });
  return out.filter(c => { try { return fs.statSync(c.path).isFile(); } catch { return false; } });
}

let cliCache = null;
async function findClaude({ force = false } = {}) {
  if (cliCache && !force && Date.now() - cliCache.at < 5 * 60 * 1000) return cliCache.info;
  const cands = candidatePaths();
  const seen = new Set(), list = [];
  for (const c of cands) { const k = c.path.toLowerCase(); if (seen.has(k)) continue; seen.add(k); list.push(c); }
  let best = null;
  for (const c of list) {
    const v = await runOnce(c.path, ['--version'], { timeout: 20000 }).then(r => (String(r.stdout).match(/(\d+\.\d+\.\d+)/) || [])[1]).catch(() => null);
    if (!v) continue;
    // אותה גרסה: מעדיפים את העותק של האפליקציה (לא תלוי ב-VS Code)
    if (!best || cmpVer(v, best.version) > 0 || (cmpVer(v, best.version) === 0 && c.source === 'app' && best.source !== 'app')) best = { path: c.path, version: v, source: c.source };
  }
  if (best && best.source !== 'app' && best.source !== 'env') adoptCopy(best); // ברקע: עותק של האפליקציה, לפעם הבאה
  if (!best) { provision(); } // אין Claude Code בכלל — מורידים את הרשמי (ברקע)
  const info = best ? { found: true, ...best } : { found: false, installing: !!provisioning, error: provisioning ? 'מתקין את Claude Code (פעם אחת, אוטומטית)… ' + (provState.msg || '') : ('לא נמצאה התוכנה Claude Code' + (provState.error ? ': ' + provState.error : '')) };
  cliCache = { at: Date.now(), info };
  return info;
}
let adopting = null;
function adoptCopy(best) {
  if (adopting) return; const exe = IS_WIN ? 'claude.exe' : 'claude', dir = path.join(APP_CLI_ROOT, best.version), dst = path.join(dir, exe);
  try { if (fs.statSync(dst).size === fs.statSync(best.path).size) return; } catch { }
  adopting = (async () => { try { fs.mkdirSync(dir, { recursive: true }); await fs.promises.copyFile(best.path, dst + '.part'); fs.renameSync(dst + '.part', dst); cliCache = null; console.log('[cli] app copy ready:', dst); } catch (e) { console.error('[cli] copy failed', e.message); try { fs.unlinkSync(dst + '.part'); } catch { } } finally { adopting = null; } })();
}
// הורדה רשמית (כמו ה-installer של Anthropic, בלי לשנות PATH): latest → manifest.json (SHA-256) → claude.exe
const DL_BASE = 'https://downloads.claude.ai/claude-code-releases';
let provisioning = null; const provState = { msg: '', error: '' };
function provision() {
  if (provisioning) return provisioning;
  provisioning = (async () => {
    try {
      provState.error = ''; provState.msg = 'בודק גרסה…';
      const platform = process.platform === 'win32' ? (process.arch === 'arm64' ? 'win32-arm64' : 'win32-x64') : process.platform === 'darwin' ? (process.arch === 'arm64' ? 'darwin-arm64' : 'darwin-x64') : (process.arch === 'arm64' ? 'linux-arm64' : 'linux-x64');
      const version = String(await (await fetch(DL_BASE + '/latest')).text()).trim();
      if (!/^\d+\.\d+\.\d+/.test(version)) throw new Error('downloads.claude.ai החזיר תשובה לא צפויה');
      const man = await (await fetch(`${DL_BASE}/${version}/manifest.json`)).json();
      const sum = man && man.platforms && man.platforms[platform] && man.platforms[platform].checksum; if (!sum) throw new Error('אין גרסה למערכת ' + platform);
      const exe = IS_WIN ? 'claude.exe' : 'claude', dir = path.join(APP_CLI_ROOT, version), dst = path.join(dir, exe);
      fs.mkdirSync(dir, { recursive: true });
      provState.msg = 'מוריד את Claude Code ' + version + '…';
      const res = await fetch(`${DL_BASE}/${version}/${platform}/${exe}`); if (!res.ok) throw new Error('הורדה נכשלה (' + res.status + ')');
      const buf = Buffer.from(await res.arrayBuffer());
      const got = crypto.createHash('sha256').update(buf).digest('hex');
      if (got !== String(sum).toLowerCase()) throw new Error('בדיקת SHA-256 נכשלה — הקובץ לא נשמר');
      fs.writeFileSync(dst + '.part', buf); if (!IS_WIN) fs.chmodSync(dst + '.part', 0o755); fs.renameSync(dst + '.part', dst);
      provState.msg = 'הותקן: ' + version; cliCache = null; console.log('[cli] downloaded official Claude Code', version, '→', dst);
      return dst;
    } catch (e) { provState.error = e.message; provState.msg = ''; console.error('[cli] provision failed', e.message); return null; }
    finally { provisioning = null; }
  })();
  return provisioning;
}

// ---------- הרצת תהליך ----------
function cliEnv(extra = {}) {
  const env = { ...process.env, ...extra };
  delete env.NODE_OPTIONS; delete env.DEBUG; delete env.ELECTRON_RUN_AS_NODE;
  // משתנים של תוסף VS Code / סשן אחר לא אמורים "לדלוף" לתהליך שלנו
  for (const k of Object.keys(env)) if (/^(CLAUDECODE|CLAUDE_CODE_SSE_PORT|CLAUDE_CODE_IDE_|CLAUDE_CODE_SESSION|CLAUDE_CODE_PARENT)/.test(k)) delete env[k];
  // שום קשר ל-VS Code גם כשהאפליקציה הופעלה מתוכו: בלי VSCODE_* / TERM_PROGRAM=vscode, ובלי GIT_ASKPASS של VS Code
  // (אחרת git מבקש סיסמה דרך VS Code — ונכשל כשהוא סגור; בלעדיו git משתמש ב-Credential Manager הרגיל)
  for (const k of Object.keys(env)) if (/^(VSCODE_|ELECTRON_NO_ATTACH_CONSOLE$|GIT_ASKPASS$|TERM_PROGRAM)/.test(k)) delete env[k];
  if (/askpass/i.test(env.SSH_ASKPASS || '') && /vscode|code/i.test(env.SSH_ASKPASS)) delete env.SSH_ASKPASS;
  // תוסף ה-Python של VS Code (debugpy): משתני דיבאגר + תיקייה שהוא דוחף ל-PATH — לא שייכים לסשן של האפליקציה
  for (const k of Object.keys(env)) if (/^(BUNDLED_DEBUGPY_PATH|PYDEVD_|DEBUGPY_)/.test(k)) delete env[k];
  // מארח הסשנים: הצינור/הטוקן/הנתיבים שלו לא יוצאים אף פעם לתהליך ש-Claude מריץ (HOT-UPDATE-PLAN 1.7, סעיף 8)
  for (const k of Object.keys(env)) if (/^CLAUDE_HOST_/i.test(k)) delete env[k];
  for (const k of Object.keys(env)) if (/^path$/i.test(k) && env[k]) env[k] = env[k].split(';').filter(p => !/[\\/]\.vscode[\\/]extensions[\\/]/i.test(p)).join(';');
  // במצב מנוי ה-CLI חייב להשתמש בכניסה לחשבון — לא במפתח API / כתובת / ספק אחר שנמצאים במשתני הסביבה
  for (const k of Object.keys(env)) if (/^(ANTHROPIC_API_KEY|ANTHROPIC_AUTH_TOKEN|ANTHROPIC_BASE_URL|ANTHROPIC_BEDROCK_BASE_URL|CLAUDE_CODE_USE_BEDROCK|CLAUDE_CODE_USE_VERTEX|CLAUDE_CODE_USE_FOUNDRY)$/.test(k)) delete env[k];
  // בדיקות בלבד: פרוקסי מקומי שרושם מה ה-CLI שולח ל-API (thinking / effort) — רק כשהבדיקה מגדירה אותו במפורש
  if (process.env.CLAUDE_TEST_CLI_BASE_URL && /^http:\/\/127\.0\.0\.1:\d+$/.test(process.env.CLAUDE_TEST_CLI_BASE_URL)) env.ANTHROPIC_BASE_URL = process.env.CLAUDE_TEST_CLI_BASE_URL;
  env.CLAUDE_CODE_ENTRYPOINT = ENTRYPOINT;
  return env;
}
function runOnce(file, args, { cwd, timeout = 30000, env, input } = {}) { // input = טקסט ל-stdin (פרומפט ארוך: שורת הפקודה ב-Windows מוגבלת ל-32K תווים)
  return new Promise((resolve, reject) => {
    let out = '', err = '', done = false;
    let child;
    try { child = spawn(file, args, { cwd: cwd || HOME, env: cliEnv(env), windowsHide: true, stdio: [input != null ? 'pipe' : 'ignore', 'pipe', 'pipe'] }); }
    catch (e) { return reject(e); }
    if (input != null) { child.stdin.on('error', () => { }); child.stdin.end(String(input), 'utf8'); }
    const t = setTimeout(() => { if (!done) { done = true; killTree(child); reject(Object.assign(new Error('timeout'), { code: 'ETIMEDOUT' })); } }, timeout);
    child.stdout.on('data', d => (out += d)); child.stderr.on('data', d => (err += d));
    child.on('error', e => { if (!done) { done = true; clearTimeout(t); reject(e); } });
    child.on('close', code => { if (!done) { done = true; clearTimeout(t); resolve({ code, stdout: out, stderr: err }); } });
  });
}
function killTree(child) {
  if (child && child.isHosted) return child.killTree();   // תהליך שמוחזק במארח הסשנים — המארח מריץ את taskkill /T
  if (!child || child.killed || child.exitCode !== null) return;
  try {
    if (IS_WIN && child.pid) spawn('taskkill', ['/pid', String(child.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' }).on('error', () => { });
    else child.kill('SIGKILL');
  } catch { }
}

// ---------- חשבון: סטטוס / כניסה / יציאה ----------
// env אופציונלי: CLAUDE_CONFIG_DIR לבדיקות (לא נוגעים בכניסה האמיתית)
async function authStatus(env) {
  const cli = await findClaude();
  if (!cli.found) return { loggedIn: false, cli };
  try {
    const r = await runOnce(cli.path, ['auth', 'status'], { timeout: 25000, env });
    let j = null; try { j = JSON.parse(r.stdout); } catch { }
    if (j) return { ...j, cli };
    return { loggedIn: false, cli, raw: (r.stdout + r.stderr).slice(0, 300) };
  } catch (e) { return { loggedIn: false, cli, error: e.message }; }
}

const logins = new Map(); // id -> record
const URL_RE = /https?:\/\/[^\s"'<>]+/g;
function loginPublic(l) { return { id: l.id, status: l.status, url: l.url, browserUrl: l.browserUrl || null, callbackPort: l.callbackPort || null, startedAt: l.startedAt, endedAt: l.endedAt || null, output: l.output.slice(-1500), error: l.error || null, provider: l.provider, pid: l.pid, auth: l.auth || null }; }

async function startLogin({ provider = 'claudeai', email, sso = false, env, debugFile, capture, registry = 'main' } = {}) {
  const cli = await findClaude();
  if (!cli.found) throw Object.assign(new Error(cli.error), { status: 400 });
  // רק כניסה אחת פעילה לכל "רישום": כניסת אימות של טלפון (registry 'witness', תיקיית CLAUDE_CONFIG_DIR זמנית) לא מבטלת
  // כניסה אמיתית של המחשב, ולהפך
  for (const l of logins.values()) if (l.status === 'pending' && (l.registry || 'main') === registry) cancelLogin(l.id);
  const args = [...(debugFile ? ['--debug-file', debugFile] : []), 'auth', 'login', provider === 'console' ? '--console' : '--claudeai'];
  if (email) args.push('--email', String(email));
  if (sso) args.push('--sso');
  const id = crypto.randomUUID();
  const rec = { id, status: 'pending', url: null, output: '', startedAt: Date.now(), provider, opened: false, env, pid: null, registry };
  // BROWSER: אם ה-CLI לא מצליח לפתוח דפדפן לבד — אנחנו פותחים את הכתובת (פעם אחת) כשהיא מופיעה בפלט
  // בשרת בלי מסך (או בהתקנה מרחוק דרך SSH): ה-CLI מעביר ל-BROWSER כתובת שחוזרת ל-http://localhost:<port>/callback.
  // לוכדים אותה: מי שמאמת במחשב אחר מקבל אותה, ומנהרת SSH מעבירה את החזרה מהדפדפן שלו לכאן — בלי להדביק קוד.
  const headless = !IS_WIN && !process.env.DISPLAY && !process.env.WAYLAND_DISPLAY;
  let capFile = null; const capEnv = {};
  if (capture || headless || process.env.CLAUDE_LOGIN_CAPTURE === '1') {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cl-login-')); capFile = path.join(dir, 'url.txt');
    // Windows: ב-URL יש & — ב-cmd רגיל הוא מפצל את הפקודה (נבדק: הקובץ יצא ריק). עם delayed expansion התו נשאר בתוך המשתנה
    if (IS_WIN) { const f = path.join(dir, 'cap.cmd'); fs.writeFileSync(f, '@echo off\r\nsetlocal EnableDelayedExpansion\r\nset "u=%~1"\r\n>>"' + capFile + '" echo(!u!\r\n'); capEnv.BROWSER = f; }
    else {
      const f = path.join(dir, 'cap.sh');
      fs.writeFileSync(f, '#!/bin/sh\necho "$1" >> ' + JSON.stringify(capFile) + '\nif [ -n "$DISPLAY$WAYLAND_DISPLAY" ] && command -v xdg-open >/dev/null 2>&1; then xdg-open "$1" >/dev/null 2>&1 & fi\n');
      fs.chmodSync(f, 0o755); capEnv.BROWSER = f;
    }
  }
  const child = spawn(cli.path, args, { cwd: HOME, env: cliEnv({ ...(env || {}), ...capEnv }), windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
  if (capFile) { const iv = setInterval(() => { try { const t = fs.readFileSync(capFile, 'utf8'); const u = (t.match(URL_RE) || [])[0]; if (u && !rec.browserUrl) { rec.browserUrl = u; try { const ru = new URL(u).searchParams.get('redirect_uri'); const m = ru && ru.match(/^http:\/\/localhost:(\d+)\//); if (m) rec.callbackPort = +m[1]; } catch { } } } catch { } if (rec.status !== 'pending' || rec.browserUrl) clearInterval(iv); }, 250); }
  rec.child = child; rec.pid = child.pid;
  const onData = d => {
    rec.output += String(d);
    const m = rec.output.match(URL_RE);
    if (m && !rec.url) { rec.url = m.find(u => /oauth|authorize|claude|anthropic/i.test(u)) || m[0]; }
  };
  child.stdout.on('data', onData); child.stderr.on('data', onData);
  child.on('error', e => { rec.status = 'error'; rec.error = e.message; rec.endedAt = Date.now(); });
  child.on('close', async code => {
    rec.endedAt = Date.now();
    if (rec.status === 'cancelled') return;
    if (code === 0) { rec.status = 'success'; rec.auth = await authStatus(env).catch(() => null); if (!env) resetAccount(); } // כניסה בתיקייה זמנית לא נוגעת במטמון של החשבון האמיתי
    else { rec.status = 'error'; rec.error = (rec.output.trim().split('\n').pop() || 'הכניסה נכשלה') + ` (קוד ${code})`; }
  });
  const to = setTimeout(() => { if (rec.status === 'pending') { rec.error = 'עבר זמן רב מדי בלי אימות בדפדפן'; cancelLogin(id, 'error'); } }, 10 * 60 * 1000);
  child.on('close', () => clearTimeout(to));
  logins.set(id, rec);
  // אם ה-CLI לא פתח דפדפן תוך 6 שניות — פותחים אנחנו
  // הערה חשובה: ה-CLI פותח בעצמו את הדפדפן בכתובת עם חזרה אוטומטית ל-localhost. לא פותחים כאן עוד כתובת (הכתובת שמודפסת היא
  // מסלול ה'הדבק קוד' הידני, והיא הייתה גורמת להצגת קוד להעתקה). השדה 'הדבק קוד' בממשק נשאר רק כגיבוי.
  return loginPublic(rec);
}
function openUrl(url) {
  try {
    if (IS_WIN) spawn('rundll32', ['url.dll,FileProtocolHandler', url], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
    else spawn(process.platform === 'darwin' ? 'open' : 'xdg-open', [url], { detached: true, stdio: 'ignore' }).unref();
  } catch { }
}
// אם הדפדפן לא מחזיר אוטומטית (ה-CLI מבקש "Paste code here") — אפשר להדביק את הקוד מהדף
function submitLoginCode(id, code) { const l = logins.get(id); if (!l || l.status !== 'pending') return false; try { l.child.stdin.write(String(code).trim() + '\n'); return true; } catch { return false; } }
function getLogin(id) { const l = logins.get(id); return l ? loginPublic(l) : null; }
function cancelLogin(id, as = 'cancelled') { const l = logins.get(id); if (!l) return false; if (l.status === 'pending') { l.status = as; l.endedAt = Date.now(); } killTree(l.child); return true; }

async function logout(env) {
  const cli = await findClaude();
  if (!cli.found) throw Object.assign(new Error(cli.error), { status: 400 });
  const r = await runOnce(cli.path, ['auth', 'logout'], { timeout: 30000, env });
  resetAccount();
  return { ok: r.code === 0, output: (r.stdout + r.stderr).slice(0, 300) };
}

// ---------- תהליך עזר ארוך-טווח: נתוני שימוש / סטטוס / פקודות (בקשות בקרה של ה-CLI) ----------
let helper = null, helperStarting = null;
// כל תהליך עזר נהרג לפי עצמו (לא "התהליך הנוכחי"): קודם, שתי קריאות במקביל הפעילו שני תהליכים — אחד נשאר יתום לנצח (נצפו 120 תהליכים, 25GB)
function killHelper(h) { if (!h) return; clearInterval(h.idleT); killTree(h.proc); if (helper === h) helper = null; }
function stopHelper() { killHelper(helper); }
// החשבון התחלף (כניסה / יציאה / החלפה — גם מחוץ לאפליקציה): התהליך-העוזר מחזיק בזיכרון את האסימון של החשבון הקודם →
// סוגרים אותו ומנקים את המטמונים; הקריאה הבאה עולה עם החשבון החדש
function resetAccount() { cliCache = null; usageCache = null; stopHelper(); }
// קריאות במקביל חולקות את אותה הפעלה (helperStarting) — אף פעם לא שני תהליכים
async function ensureHelper(env) {
  if (helper && helper.proc.exitCode === null) { helper.lastUse = Date.now(); if (helper.ready) await helper.ready; return helper; }
  if (!helperStarting) helperStarting = startHelper(env).finally(() => { helperStarting = null; });
  return helperStarting;
}
async function startHelper(env) {
  const cli = await findClaude();
  if (!cli.found) throw new Error(cli.error);
  const proc = spawn(cli.path, ['-p', '--output-format', 'stream-json', '--verbose', '--input-format', 'stream-json', '--permission-prompt-tool=stdio', '--strict-mcp-config', '--setting-sources', 'user'],
    { cwd: HOME, env: cliEnv(env), windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
  const h = helper = { proc, buf: '', pending: new Map(), lastUse: Date.now(), initResp: null, idleT: null, ready: null };
  proc.stdout.on('data', d => {
    h.buf += d; let i;
    while ((i = h.buf.indexOf(String.fromCharCode(10))) >= 0) {
      const line = h.buf.slice(0, i); h.buf = h.buf.slice(i + 1);
      let j; try { j = JSON.parse(line); } catch { continue; }
      if (j.type === 'control_response' && j.response) {
        const p = h.pending.get(j.response.request_id);
        if (p) { h.pending.delete(j.response.request_id); j.response.subtype === 'success' ? p.resolve(j.response.response) : p.reject(new Error(j.response.error || 'control error')); }
      }
    }
  });
  proc.stderr.on('data', () => { });
  const fail = () => { for (const p of h.pending.values()) p.reject(new Error('helper exited')); h.pending.clear(); clearInterval(h.idleT); if (helper === h) helper = null; };
  proc.on('close', fail); proc.on('error', fail);
  // נסגר לבד אחרי 10 דקות בלי שימוש (חוסך זיכרון) — כל תהליך עם הטיימר של עצמו
  h.idleT = setInterval(() => { if (Date.now() - h.lastUse > 10 * 60 * 1000) killHelper(h); }, 60000);
  if (h.idleT.unref) h.idleT.unref();
  h.ready = helperRequestRaw(h, 'initialize', {}, 30000).then(r => { h.initResp = r; return h; });
  try { await h.ready; } catch (e) { killHelper(h); throw e; } // אתחול שנכשל לא משאיר תהליך חי
  return h;
}
function helperRequestRaw(h, subtype, extra, timeoutMs = 25000) {
  return new Promise((resolve, reject) => {
    const id = 'r' + crypto.randomBytes(5).toString('hex');
    const t = setTimeout(() => { h.pending.delete(id); reject(new Error('timeout: ' + subtype)); }, timeoutMs);
    h.pending.set(id, { resolve: v => { clearTimeout(t); resolve(v); }, reject: e => { clearTimeout(t); reject(e); } });
    try { h.proc.stdin.write(JSON.stringify({ type: 'control_request', request_id: id, request: { subtype, ...extra } }) + '\n'); }
    catch (e) { h.pending.delete(id); clearTimeout(t); reject(e); }
  });
}
async function helperRequest(subtype, extra, timeoutMs, env) { const h = await ensureHelper(env); h.lastUse = Date.now(); return helperRequestRaw(h, subtype, extra || {}, timeoutMs); }

let usageCache = null, lastUsageHeal = 0;
const LIMIT_LABELS = { weekly_all: 'שבועי · כל המודלים', weekly_scoped: 'שבועי', session: 'חלון 5 שעות', five_hour: 'חלון 5 שעות', daily: 'יומי' };
function normalizeUsage(u, status) {
  const rl = (u && u.rate_limits) || {};
  const windows = [];
  const add = (key, label, w) => { if (w && typeof w.utilization === 'number') windows.push({ key, label, utilization: w.utilization, resetsAt: w.resets_at ? Date.parse(w.resets_at) : null }); };
  add('five_hour', 'חלון 5 שעות', rl.five_hour);
  add('seven_day', 'שבועי · כל המודלים', rl.seven_day);
  add('seven_day_opus', 'שבועי · Opus', rl.seven_day_opus);
  add('seven_day_sonnet', 'שבועי · Sonnet', rl.seven_day_sonnet);
  const scoped = (rl.limits || []).filter(l => l.kind === 'weekly_scoped' && l.scope && l.scope.model);
  for (const l of scoped) windows.push({ key: 'scoped:' + (l.scope.model.display_name || l.scope.model.id), label: 'שבועי · ' + (l.scope.model.display_name || l.scope.model.id), utilization: l.percent, resetsAt: l.resets_at ? Date.parse(l.resets_at) : null, active: !!l.is_active });
  const ex = rl.extra_usage || null;
  const rows = (status && status.sections || []).flatMap(s => s.rows || []);
  const row = lbl => (rows.find(r => r.label === lbl) || {}).value || null;
  return {
    ok: !!(u && u.rate_limits_available !== false),
    subscriptionType: u && u.subscription_type || null,
    plan: row('Login method') || null, email: row('Email') || null, org: row('Organization') || null,
    windows,
    extraUsage: ex ? { enabled: !!ex.is_enabled, monthlyLimit: ex.monthly_limit, used: ex.used_credits, utilization: ex.utilization, currency: ex.currency, disabledReason: ex.disabled_reason || null } : null,
    session: u && u.session || null,
    fetchedAt: Date.now()
  };
}
async function getUsage({ force = false, env } = {}) {
  if (usageCache && !force && Date.now() - usageCache.at < 45000) return usageCache.data;
  let [u, st] = await Promise.all([helperRequest('get_usage', {}, 30000, env), helperRequest('get_status', {}, 30000, env).catch(() => null)]);
  let data = normalizeUsage(u, st);
  // אין נתונים מהעוזר (למשל: האסימון שבזיכרון שלו כבר לא תקף אחרי החלפת חשבון) → עוזר חדש פעם אחת ושוב
  if (!data.ok && !env && Date.now() - lastUsageHeal > 60000) {
    lastUsageHeal = Date.now(); stopHelper();
    [u, st] = await Promise.all([helperRequest('get_usage', {}, 30000, env), helperRequest('get_status', {}, 30000, env).catch(() => null)]);
    data = normalizeUsage(u, st); data.healed = true;
  }
  usageCache = { at: Date.now(), data };
  return data;
}
// עדכון חי מאירוע rate_limit_event בזמן ריצה (utilization 0..1)
function applyRateLimitEvent(info) {
  if (!usageCache || !info || !info.unifiedWindows) return null;
  const d = usageCache.data;
  for (const [k, w] of Object.entries(info.unifiedWindows)) {
    const key = k === 'five_hour' || k === 'seven_day' ? k : k;
    const cur = d.windows.find(x => x.key === key);
    const val = typeof w.utilization === 'number' ? w.utilization * 100 : null;
    if (cur && val != null) { cur.utilization = val; if (w.resetsAt) cur.resetsAt = w.resetsAt * 1000; }
  }
  d.fetchedAt = Date.now();
  return d;
}
async function getCommands(env) {
  const h = await ensureHelper(env);
  return ((h.initResp && h.initResp.commands) || []).map(c => ({ name: c.name, description: c.description, argumentHint: c.argumentHint || '', builtin: !!c.builtin }));
}


// רשימת המודלים של החשבון, כפי ש-Claude Code עצמו מדווח (initialize) — כולל יכולות Effort / חשיבה
async function getModels(env) {
  const h = await ensureHelper(env);
  return ((h.initResp && h.initResp.models) || []).map(m => ({
    id: m.value, name: m.displayName || m.value, resolved: m.resolvedModel, description: m.description || '',
    effort: m.supportsEffort ? Object.fromEntries(['low', 'medium', 'high', 'xhigh', 'max'].map(k => [k, (m.supportedEffortLevels || []).includes(k)])) : null,
    thinkingTypes: { adaptive: !!m.supportsAdaptiveThinking, disabled: m.supportsThinkingOff !== false, enabled: false },
    created: '', maxTokens: 0, contextWindow: 0, compaction: true, refusalModel: false
  }));
}
async function getAccountInfo(env) { const h = await ensureHelper(env); return (h.initResp && h.initResp.account) || null; }
async function getInit(env) { const h = await ensureHelper(env); return h.initResp || {}; }

process.on('exit', () => { try { if (helper) helper.proc.kill(); } catch { } });

module.exports = {
  getModels, getAccountInfo, getInit,
  findClaude, cliEnv, killTree, runOnce, authStatus, startLogin, getLogin, cancelLogin, submitLoginCode, logout, getUsage, applyRateLimitEvent, getCommands,
  helperRequest, stopHelper, resetAccount, openUrl, ENTRYPOINT, cmpVer, LIMIT_LABELS
};
