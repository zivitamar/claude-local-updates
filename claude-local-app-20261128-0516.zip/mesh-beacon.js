'use strict';
// ============================================================
//  mesh-beacon.js — "מגדלור": ההצטרפות האוטומטית של מחשב לרשת דרך חשבון ה-Claude בלבד (בלי קוד, בלי אישור).
//
//  איך: על כל מחשב רץ סשן Claude Code קטן ושקט (haiku, רק הכלים ListAgents + SendMessage, בלי MCP), בשם clm-<מזהה המחשב>,
//  עם Remote Control דלוק. Anthropic מעבירה הודעות בין סשנים רק בתוך אותו חשבון (וכל מחשב רואה ב-ListAgents את הסשנים של
//  החשבון שלו בכל המחשבים) — זה עוגן האמון. כל מחשב שולח למגדלורים האחרים הודעת CLMESH1 חתומה (המפתחות הציבוריים שלו +
//  כתובות), ומי שמקבל מוסיף אותו לרשת ועונה עם שלו. מכאן והלאה כל התקשורת עוברת ישירות ומוצפנת (mesh.js), לא דרך Claude.
//
//  ההודעה עצמה לא תלויה ב-Claude: שליחה — הוק PreToolUse מחליף את קלט ה-SendMessage בטקסט המדויק (Claude לא יכול לשנות אותו);
//  קבלה — האפליקציה קוראת את ההודעה הנכנסת ישירות מהזרם (<cross-session-message from-name=…>), והחתימה נבדקת.
// ============================================================
const fs = require('fs'), path = require('path'), crypto = require('crypto'), { spawn } = require('child_process');

const SILENT = 'You are a silent network beacon of the user\'s desktop app. Never use a tool unless the latest user message starts with "BEACON-SEND" or "BEACON-LIST". For "BEACON-LIST": call ListAgents once, then reply "ok". For "BEACON-SEND": call SendMessage once (the app fills in the exact recipient and text), then reply "ok". When a message from another Claude session arrives: do nothing and reply only "ok". Never reply with anything longer than "ok".';

function createBeacon({ mesh, findClaude, cliEnv, dataDir, hookUrl, log = () => { }, onStatus = () => { } }) {
  const NAME = 'clm-' + mesh.id.slice(0, 10);
  const DIR = path.join(dataDir, 'mesh', 'beacon'); fs.mkdirSync(DIR, { recursive: true });
  const st = { state: 'off', name: NAME, error: null, rc: null, lastListAt: 0, peers: [], sent: 0, received: 0, joined: 0, rejected: 0, startedAt: null, costUSD: 0 };
  let proc = null, buf = '', ctl = new Map(), sendQueue = [], listWanted = false, busy = false, restartT = null, stopped = true, listTimer = null;
  const status = () => ({ ...st, peers: st.peers.slice(0, 50) });
  const set = patch => { Object.assign(st, patch); try { onStatus(status()); } catch { } };

  function settings() {
    return JSON.stringify({
      crossSessionInbound: 'accept', isolatePeerMachines: false,
      permissions: { allow: ['ListAgents', 'SendMessage'] },
      hooks: { PreToolUse: [{ matcher: '.*', hooks: [{ type: 'command', command: `curl.exe -s -X POST -H "content-type: application/json" --data-binary @- ${hookUrl}`.replace(/^curl\.exe/, process.platform === 'win32' ? 'curl.exe' : 'curl'), timeout: 15 }] }] }
    });
  }
  async function start() {
    if (proc) return status(); stopped = false;
    const cli = await findClaude(); if (!cli.found) { set({ state: 'error', error: 'Claude Code לא נמצא' }); return status(); }
    set({ state: 'starting', error: null, startedAt: Date.now() });
    const args = ['-p', '--input-format', 'stream-json', '--output-format', 'stream-json', '--verbose', '--replay-user-messages', '--model', 'haiku',
      '--tools', 'ListAgents,SendMessage', '--strict-mcp-config', '--mcp-config', '{"mcpServers":{}}', '--no-session-persistence', '--name', NAME,
      '--permission-mode', 'default', '--settings', settings(), '--append-system-prompt', SILENT];
    const p = proc = spawn(cli.path, args, { cwd: DIR, env: cliEnv({ CLAUDE_CODE_ENTRYPOINT: 'claude-local-chat' }), windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    buf = '';
    p.stdout.on('data', d => { buf += d; let i; while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i); buf = buf.slice(i + 1); let j; try { j = JSON.parse(line); } catch { continue; } try { onMsg(j); } catch (e) { log('[beacon] ' + e.message); } } });
    let errTail = ''; p.stderr.on('data', d => { errTail = (errTail + d).slice(-800); });
    p.on('exit', code => {
      if (proc !== p) return; proc = null; busy = false; for (const f of ctl.values()) f({ subtype: 'error', error: 'exit' }); ctl.clear();
      set({ state: stopped ? 'off' : 'error', error: stopped ? null : 'המגדלור נסגר (' + code + ') ' + errTail.trim().split('\n').pop() });
      if (!stopped) { clearTimeout(restartT); restartT = setTimeout(start, 30000); }
    });
    await control({ subtype: 'initialize' }, 30000);
    const r = await control({ subtype: 'remote_control', enabled: true, name: NAME }, 45000);
    if (r && r.subtype === 'success') set({ state: 'connected', rc: (r.response && r.response.session_url) || null });
    else set({ state: 'connected-local', error: 'Remote Control לא הופעל — רק מחשבים באותה רשת מקומית' });
    clearInterval(listTimer); listTimer = setInterval(() => discover(), 10 * 60 * 1000);
    setTimeout(() => discover(), 1500);
    return status();
  }
  function stop() { stopped = true; clearInterval(listTimer); clearTimeout(restartT); if (proc) { try { proc.kill(); } catch { } } proc = null; set({ state: 'off' }); }
  function control(request, ms) {
    return new Promise(res => {
      if (!proc) return res({ subtype: 'error', error: 'no process' });
      const id = crypto.randomUUID(); ctl.set(id, res);
      proc.stdin.write(JSON.stringify({ type: 'control_request', request_id: id, request }) + '\n');
      setTimeout(() => { if (ctl.has(id)) { ctl.delete(id); res({ subtype: 'timeout' }); } }, ms);
    });
  }
  const say = text => { if (proc) proc.stdin.write(JSON.stringify({ type: 'user', message: { role: 'user', content: [{ type: 'text', text }] } }) + '\n'); };
  // תור: הודעה אחת בכל פעם (כל אחת = תור קצר של haiku)
  function pump() {
    if (busy || !proc || !/^connected/.test(st.state)) return;
    if (listWanted) { listWanted = false; busy = true; pendingList = true; say('BEACON-LIST'); return; }
    const s = sendQueue[0]; if (!s) return;
    busy = true; say(`BEACON-SEND to ${s.to}`);
  }
  let pendingList = false;
  function discover() { listWanted = true; pump(); return status(); }
  function sendTo(to, text) { sendQueue.push({ to, text, at: Date.now() }); pump(); }

  // ההוק של המגדלור (נקרא לפני כל כלי): ListAgents — רק כשביקשנו; SendMessage — הקלט המדויק מהתור בלבד
  function hook(j) {
    const name = String((j && j.tool_name) || ''), allow = upd => ({ hookSpecificOutput: { hookEventName: 'PreToolUse', permissionDecision: 'allow', permissionDecisionReason: 'mesh beacon', ...(upd ? { updatedInput: upd } : {}) } });
    const deny = why => ({ hookSpecificOutput: { hookEventName: 'PreToolUse', permissionDecision: 'deny', permissionDecisionReason: why } });
    if (name === 'ListAgents') return pendingList ? allow() : deny('not requested');
    if (name === 'SendMessage') { const s = sendQueue[0]; if (!s) return deny('nothing to send'); s.used = true; return allow({ to: s.to, message: s.text, summary: 'mesh' }); }
    return deny('beacon: only ListAgents / SendMessage');
  }
  function onMsg(j) {
    if (j.type === 'control_response') { const r = j.response || {}; const f = ctl.get(r.request_id); if (f) { ctl.delete(r.request_id); f(r); } return; }
    if (j.type === 'result') {
      st.costUSD += Number(j.total_cost_usd) || 0;
      if (sendQueue[0] && sendQueue[0].used) { sendQueue.shift(); st.sent++; }
      else if (sendQueue[0] && !pendingList) { const s = sendQueue[0]; s.tries = (s.tries || 0) + 1; if (s.tries >= 3) sendQueue.shift(); }
      pendingList = false; busy = false; set({}); setTimeout(pump, 200); return;
    }
    if (j.type === 'user' && j.message) {
      const content = j.message.content;
      if (Array.isArray(content)) for (const b of content) if (b.type === 'tool_result') onToolResult(b);
      const text = typeof content === 'string' ? content : Array.isArray(content) ? content.filter(b => b.type === 'text').map(b => b.text).join('\n') : '';
      if (text.includes('<cross-session-message')) onInbound(text);
    }
  }
  function onToolResult(b) {
    const t = typeof b.content === 'string' ? b.content : Array.isArray(b.content) ? b.content.map(x => x.text || '').join('\n') : '';
    if (!/Peer sessions|This session is/.test(t)) return;
    // שורות כמו:  clm-1a2b3c4d5e [ab12cd]  ·  Remote Control  ·  idle  ·  …
    const peers = [];
    for (const line of t.split('\n')) { const m = line.match(/^\s*(clm-[0-9a-f]{10})\s+\[([0-9a-f]+)\]\s*(.*)$/); if (m && m[1] !== NAME) peers.push({ name: m[1], ref: m[2], desc: m[3].replace(/\s+/g, ' ').trim() }); }
    set({ peers, lastListAt: Date.now() });
    // לכל מגדלור שלא מחובר אלינו ברשת — שולחים את הכרטיס החתום שלנו (פעם אחת לכל מגדלור, אלא אם עבר זמן)
    const byName = new Map(); for (const p of peers) { const prev = byName.get(p.name); if (!prev || /Remote Control/i.test(p.desc)) byName.set(p.name, p); }
    for (const p of byName.values()) {
      const idPrefix = p.name.slice(4);
      const known = Object.keys(mesh.machines().reduce((a, m) => (a[m.id] = 1, a), {})).find(id => id.startsWith(idPrefix));
      if (known && mesh.isConnected(known)) continue;
      sendTo(`${p.name} [${p.ref}]`, mesh.helloText('hello'));
    }
  }
  function onInbound(text) {
    const re = /<cross-session-message\s+([^>]*)>\n?([\s\S]*?)\n?<\/cross-session-message>/g; let m;
    while ((m = re.exec(text))) {
      const attrs = {}; m[1].replace(/([a-z-]+)="([^"]*)"/g, (_, k, v) => (attrs[k] = v));
      const body = m[2].trim(); if (!body.startsWith('CLMESH1 ')) continue;
      st.received++;
      const r = mesh.acceptAccountHello(body, attrs['from-name'] || '');
      if (!r.ok) { st.rejected++; log('[beacon] rejected message from ' + attrs['from-name'] + ': ' + r.error); set({}); continue; }
      if (r.added) st.joined++;
      log(`[beacon] ${r.kind} from ${attrs['from-name']} (${r.id})${r.added ? ' — new machine joined' : ''}`);
      if (r.kind === 'hello' && attrs.from) sendTo(attrs.from, mesh.helloText('ack')); // תשובה לכתובת המדויקת של השולח
      set({});
    }
  }
  return { start, stop, discover, status, hook, name: NAME };
}

module.exports = { createBeacon };
