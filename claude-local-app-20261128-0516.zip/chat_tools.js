'use strict';
// הגדרות הכלים ש-Claude מקבל כדי לעבוד עם שיחות אחרות ועם תזרימים.
// משמש גם את שרת ה-MCP (מצב מנוי, דרך /api/mcp/<שיחה> — שרת MCP ב-HTTP) וגם את מצב ה-API (כלים רגילים).
const stepSchema = {
  type: 'object',
  properties: {
    name: { type: 'string', description: 'Short step name (Hebrew)' },
    type: { type: 'string', enum: ['task', 'research', 'command', 'watch', 'wait'], description: 'task = instruction to Claude; research = web research + numbered conclusions; command = shell command (exit 0 = ok); watch = repeat a command until it succeeds or time runs out; wait = pause' },
    prompt: { type: 'string', description: 'For task/research: what Claude must do in this step' },
    command: { type: 'string', description: 'For command/watch: the shell command' },
    allow: { type: 'array', items: { type: 'string' }, description: 'task/research: tool groups Claude may use in this step, ENFORCED by a hook that blocks everything else: read, write, shell, web, browser, agents, chats, mcp, all (or exact tool names). Always set it so Claude cannot deviate from the step.' },
    waitSec: { type: 'number' }, everySec: { type: 'number', description: 'watch: seconds between attempts' },
    timeoutMin: { type: 'number', description: 'Hard time limit for this step in minutes (always set a realistic one)' },
    retries: { type: 'number', description: 'Extra automatic attempts before taking the fail route (0-5)' },
    check: { type: 'object', description: 'How the ENGINE verifies the result', properties: { type: { type: 'string', enum: ['none', 'contains', 'not_contains', 'command', 'judge'] }, value: { type: 'string', description: 'text to find / shell command (exit 0 = pass) / success criteria for the judge' } } },
    on: { type: 'object', description: 'Routing: where to go after ok / fail / timeout. Each is "next" | "end" | "stop" | the NUMBER (1-based) of another step', properties: { ok: { type: 'string' }, fail: { type: 'string' }, timeout: { type: 'string' } } }
  },
  required: ['name', 'type']
};

const TOOL_DEFS = [
  {
    name: 'machine_list', description: 'List ALL of the user\'s computers connected to this app (the app\'s computer network, same Claude account): id, name, online, host/user/OS, how many chats run / finished on each. Then use chat_list / chat_read / chat_send / chat_new with machine=<id or name> to work with Claude on ANOTHER computer (e.g. ask the Claude on server X to do something there).',
    input_schema: { type: 'object', properties: {} }
  },
  {
    name: 'machine_install', description: 'INSTALL this app on another computer over SSH (Linux of any kind, or Windows 10/11/Server with OpenSSH) and connect it to the user\'s Claude account, so it joins the user\'s computer network. It uploads the app, installs its own Node runtime + a service that survives reboots, opens only the encrypted network port, then starts the Claude login ON THAT SERVER and returns the login link: give the link to the user — they open it on THEIR computer and approve; the approval reaches the server through an SSH tunnel (no code to paste). After that the server appears in the app\'s computers bar by itself. target = "user@host", "user@host:port" or a host name from an ssh config file (ssh_config = its path). password only if the server has no SSH key.',
    input_schema: { type: 'object', properties: { target: { type: 'string' }, ssh_config: { type: 'string', description: 'Path of an ssh config file that defines the host' }, password: { type: 'string' }, port: { type: 'number', description: 'App web port on the server (default 3456, local only)' }, mesh_port: { type: 'number', description: 'Encrypted network port (default 47400)' }, login: { type: 'boolean', description: 'Start the Claude login (default true)' } }, required: ['target'] }
  },
  { name: 'machine_install_status', description: 'Progress of machine_install on a target (steps, login state: pending / success). No target = all.', input_schema: { type: 'object', properties: { target: { type: 'string' } } } },
  { name: 'machine_login_code', description: 'Fallback only: if the user opened the backup login link and got a CODE to paste, submit it to the server\'s login with this.', input_schema: { type: 'object', properties: { target: { type: 'string' }, code: { type: 'string' } }, required: ['target', 'code'] } },
  {
    name: 'chat_list', description: 'List the chats of the user\'s chat app with their short codes (e.g. Y142), titles, project and whether Claude is running in them. Default: the current chat\'s project.',
    input_schema: { type: 'object', properties: { project: { type: 'string', description: 'Project name or id; "*" = all projects' }, machine: { type: 'string', description: 'Run this on ANOTHER computer of the user (id, name or hostname from machine_list). Omit = this computer.' } } }
  },
  {
    name: 'chat_read', description: 'Read the latest messages of another chat by its code (e.g. "Y142").',
    input_schema: { type: 'object', properties: { code: { type: 'string' }, last: { type: 'number', description: 'How many recent messages (default 10, max 60)' }, machine: { type: 'string', description: 'Run this on ANOTHER computer of the user (id, name or hostname from machine_list). Omit = this computer.' } }, required: ['code'] }
  },
  {
    name: 'chat_send', description: 'Send a message to another chat by its code, as if you wrote it there; Claude in that chat will work on it. With wait=true you get that chat\'s answer back (up to timeout_sec, default 300).',
    input_schema: { type: 'object', properties: { code: { type: 'string' }, text: { type: 'string' }, wait: { type: 'boolean' }, timeout_sec: { type: 'number' }, machine: { type: 'string', description: 'Run this on ANOTHER computer of the user (id, name or hostname from machine_list). Omit = this computer.' } }, required: ['code', 'text'] }
  },
  {
    name: 'chat_new', description: 'Create a new chat in a project (optionally with a first message that starts working immediately). Returns its code.',
    input_schema: { type: 'object', properties: { title: { type: 'string', description: '3-4 words' }, text: { type: 'string', description: 'First message (optional)' }, project: { type: 'string', description: 'Project name or id (default: current)' }, machine: { type: 'string', description: 'Run this on ANOTHER computer of the user (id, name or hostname from machine_list). Omit = this computer.' } } }
  },
  {
    name: 'vscode_chats', description: 'List/search ALL of the user\'s Claude Code chats from VS Code (every window and folder on this PC; also terminal chats with source="all"): title, open now (idle/busy) or closed, folder, model, permission mode, last activity and session id. Use it to find the exact chat the user means. An OPEN chat can receive a message with the SendMessage tool (its live name is shown); any chat can be copied into this app with vscode_chat_open.',
    input_schema: { type: 'object', properties: { query: { type: 'string', description: 'Part of the chat title / first message, or a session id' }, source: { type: 'string', enum: ['vscode', 'all'], description: 'vscode (default) = VS Code chats; all = also terminal/other chats' }, limit: { type: 'number', description: 'Default 40' } } }
  },
  {
    name: 'vscode_chat_read', description: 'Read a VS Code Claude Code chat (by title or session id from vscode_chats). Default: the latest messages. For its WHOLE history (weeks, thousands of messages) use mode "outline" / "search" / "read" exactly like chat_history.',
    input_schema: { type: 'object', properties: { chat: { type: 'string', description: 'Title or session id' }, last: { type: 'number', description: 'How many recent messages (default 12, max 60)' }, mode: { type: 'string', enum: ['last', 'stats', 'outline', 'search', 'read'] }, query: { type: 'string' }, from: { type: 'number' }, to: { type: 'number' } }, required: ['chat'] }
  },
  {
    name: 'research_start',
    description: 'Start a web research in the app\'s research engine — THE way to research in this app (parallel researcher agents, real read sources, live card in this chat, sounds, full research screen for the user). It runs in the background; when it finishes, THIS chat is woken automatically with the result. Pick depth by the request: "quick" for a small/simple question, "standard" by default, "deep" when the user asks for thorough / deep / exhaustive research. Optional: topics (sub-topics, each gets a researcher), min_sources / max_sources, researchers (exact number). After starting, tell the user the research is running in the background — do NOT say you finished.',
    input_schema: { type: 'object', properties: { question: { type: 'string', description: 'The full research request, in the user\'s words' }, depth: { type: 'string', enum: ['quick', 'standard', 'deep'] }, topics: { type: 'array', items: { type: 'string' } }, min_sources: { type: 'number' }, max_sources: { type: 'number' }, researchers: { type: 'number' } }, required: ['question'] }
  },
  {
    name: 'research_status', description: 'Live status of a research: status, phase, researchers (each one\'s state), sources read so far, elapsed time, tokens. Use it to follow a running research.',
    input_schema: { type: 'object', properties: { id: { type: 'string' } }, required: ['id'] }
  },
  {
    name: 'research_read', description: 'Read a research (also while it runs): part "summary" | "report" | "sources" | "plan" | "log".',
    input_schema: { type: 'object', properties: { id: { type: 'string' }, part: { type: 'string', enum: ['summary', 'report', 'sources', 'plan', 'log'] } }, required: ['id'] }
  },
  {
    name: 'chat_history',
    description: 'FAST full-history reader of a chat — THIS chat (omit code) or another chat of this app (code, e.g. "E724"), INCLUDING the archived part (imported chats can hold weeks and tens of thousands of messages; it is all readable here). Use it whenever the user asks about anything said earlier, or asks you to go over / learn the whole history. Modes: "outline" = a map of the WHOLE conversation, one line per user turn (date, what the user asked, Claude\'s final answer, tools used) in pages — call again with from=<next> until next is empty to know the entire history; "search" = find every place something was discussed (query; words AND-ed; searches user text, answers, tool calls and results); "read" = the full text of turns from..to (turn numbers T<n> from outline/search); "stats" = size and date range.',
    input_schema: { type: 'object', properties: { code: { type: 'string', description: 'Chat code; omit for the current chat' }, mode: { type: 'string', enum: ['stats', 'outline', 'search', 'read'] }, query: { type: 'string' }, from: { type: 'number', description: 'outline: first turn of the page (default 1) · read: first turn' }, to: { type: 'number', description: 'read: last turn (default = from)' } }, required: ['mode'] }
  },
  {
    name: 'vscode_chat_open', description: 'Copy a VS Code Claude Code chat into a NEW chat in this app, exactly: the new chat continues from the very same point with the full original context (an official fork of the same Claude Code session — the original in VS Code is not touched), the same folder (so the same CLAUDE.md, memory, hooks and settings), the same model and permission mode. Its history is shown in the new chat. Use it when the user asks to move / copy / open a VS Code chat here. Returns the new chat code.',
    input_schema: { type: 'object', properties: { chat: { type: 'string', description: 'Title or session id (from vscode_chats). If several match, use the session id.' }, title: { type: 'string', description: 'Name for the new chat (default: the original title)' } }, required: ['chat'] }
  },
  { name: 'flow_list', description: 'List the user\'s flows (תזרימים): scripted step sequences the server runs and enforces.', input_schema: { type: 'object', properties: {} } },
  {
    name: 'flow_create',
    description: 'Create a flow (תזרים): an ordered list of steps with per-step time limits, checks done by the SERVER and routing (ok/fail/timeout -> next/end/stop/step number) for loops and retries. The user sees the steps in the Flow panel and can edit them. scope "this_chat" binds the flow to the current chat, "project" runs it in a new chat of the current project. Do NOT start it unless the user asked you to.',
    input_schema: {
      type: 'object',
      properties: {
        name: { type: 'string' }, description: { type: 'string' }, scope: { type: 'string', enum: ['this_chat', 'project'] }, worker: { type: 'string', description: 'Work manager only: the code of one of YOUR worker chats — the flow is bound to that worker (it drives the worker, not you)' },
        researchQuota: { type: 'number', enum: [1, 2, 3], description: 'Deep research (research_start) inside the flow, ENFORCED by the hook: N iterations (step runs) may start a research, then the next 2N iterations may NOT (only plain WebSearch/WebFetch). 1 = 1 with / 2 without (default), 2 = 2/4, 3 = 3/6. At most one research per iteration. A research started inside a flow MUST pass both min_sources and max_sources (min ≤ max), or it is refused.' }, guard: { type: 'string', enum: ['off', 'steps', 'strict'], description: 'Hook enforcement: steps = enforce the allow list of steps that have one (default); strict = every step enforced (no list = read only); off = none' }, steps: { type: 'array', items: stepSchema }, maxMinutes: { type: 'number', description: 'OPTIONAL total time cap for the whole run, only if the user asked for one (omit = no limit: a loop flow keeps running until the user stops it)' }, maxVisits: { type: 'number', description: 'OPTIONAL: how many times one step may repeat, only if the user asked (omit = no limit)' }, maxSteps: { type: 'number', description: 'OPTIONAL: max step executions per run, only if the user asked (omit = no limit)' },
        schedule: { type: 'object', description: 'Optional: {mode:"every",everyMin:N} | {mode:"daily",time:"HH:MM"} | {mode:"at",at:<epoch ms>}', properties: { mode: { type: 'string' }, everyMin: { type: 'number' }, time: { type: 'string' }, at: { type: 'number' } } }
      },
      required: ['name', 'steps']
    }
  },
  { name: 'flow_start', description: 'Start an existing flow now (only when the user asked for it).', input_schema: { type: 'object', properties: { id: { type: 'string' } }, required: ['id'] } },
  { name: 'flow_get', description: 'Read ONE flow in full: every step in order (number, id, type, name, instruction / command, check, time limits, retries, allowed tools, routing), its scope, schedule, limits, whether the user LOCKED it, and its current / last run. Use it before flow_update. id = the flow id or its exact name.', input_schema: { type: 'object', properties: { id: { type: 'string' } }, required: ['id'] } },
  {
    name: 'flow_update',
    description: 'Edit an existing flow when the USER asks you to: rename it, change its description, schedule, limits (maxSteps / maxMinutes / maxVisits — 0 = no limit), guard, enabled, or its steps. Steps: either "steps" = the full new list (replaces all), or "ops" = ordered edits: {op:"add", at:<1-based position in the list, e.g. 2 = between step 1 and 2>, step:{...}} | {op:"remove", step:<step id | number | name>} | {op:"edit", step:<ref>, set:{name?, prompt?, command?, type?, timeoutMin?, retries?, check?, on?, allow?, ...}} | {op:"move", step:<ref>, to:<1-based position>}. Ops apply in order; numbers in "on" routing refer to positions in the FINAL list. A flow the user LOCKED (🔒) cannot be edited, stopped or deleted by you in any way — the tool refuses; tell the user to unlock it in the flow window first. Call flow_get first to see the steps.',
    input_schema: {
      type: 'object',
      properties: {
        id: { type: 'string', description: 'Flow id or exact name' }, name: { type: 'string' }, description: { type: 'string' }, enabled: { type: 'boolean' },
        researchQuota: { type: 'number', enum: [1, 2, 3], description: 'Deep research (research_start) inside the flow, ENFORCED by the hook: N iterations (step runs) may start a research, then the next 2N iterations may NOT (only plain WebSearch/WebFetch). 1 = 1 with / 2 without (default), 2 = 2/4, 3 = 3/6. At most one research per iteration. A research started inside a flow MUST pass both min_sources and max_sources (min ≤ max), or it is refused.' }, guard: { type: 'string', enum: ['off', 'steps', 'strict'] },
        maxSteps: { type: 'number', description: '0 = no limit' }, maxMinutes: { type: 'number', description: '0 = no limit' }, maxVisits: { type: 'number', description: '0 = no limit' },
        schedule: { type: 'object', description: '{mode:"none"} | {mode:"every",everyMin:N} | {mode:"daily",time:"HH:MM"} | {mode:"at",at:<epoch ms>}', properties: { mode: { type: 'string' }, everyMin: { type: 'number' }, time: { type: 'string' }, at: { type: 'number' } } },
        steps: { type: 'array', items: stepSchema, description: 'Full replacement list (optional)' },
        ops: { type: 'array', description: 'Ordered step edits (optional)', items: { type: 'object', properties: { op: { type: 'string', enum: ['add', 'remove', 'edit', 'move'] }, at: { type: 'number' }, to: { type: 'number' }, step: { description: 'add: the new step object; remove / edit / move: step id, 1-based number or name' }, set: { type: 'object', description: 'edit: fields to change' } }, required: ['op'] } }
      },
      required: ['id']
    }
  },
  { name: 'flow_stop', description: 'Stop the running run of a flow (only when the user asked). Refused for a flow the user LOCKED.', input_schema: { type: 'object', properties: { id: { type: 'string', description: 'Flow id / name, or a run id' } }, required: ['id'] } },
  { name: 'flow_delete', description: 'Delete a flow (only when the user explicitly asked). Refused for a flow the user LOCKED.', input_schema: { type: 'object', properties: { id: { type: 'string' } }, required: ['id'] } }
];
const TOOL_NAMES = new Set(TOOL_DEFS.map(t => t.name));

module.exports = { TOOL_DEFS, TOOL_NAMES };
