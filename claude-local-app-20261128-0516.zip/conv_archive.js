'use strict';
// ============================================================
//  conv_archive.js — היסטוריה ארוכה של שיחה (למשל צ'אט שהועתק מ-VS Code) נשמרת בקובץ נפרד, לקריאה בלבד:
//   <id>.jsonl   — הודעה אחת בכל שורה, בפורמט ההודעות של האפליקציה
//   <id>.idx.json — מיקום (בתים) של תחילת כל הודעה → קריאת כל טווח הודעות בלי לטעון את כל הקובץ
//   <id>.txt     — טקסט לחיפוש (שורה לכל הודעה) → Ctrl+F על כל ההיסטוריה
//  כך קובץ השיחה עצמו נשאר קטן (נשמר אחרי כל הודעה), והמסך טוען רק את החלק שרואים.
// ============================================================
const fs = require('fs'), path = require('path');

function textForSearch(m) {
  const parts = [];
  for (const b of Array.isArray(m.content) ? m.content : [{ type: 'text', text: String(m.content || '') }]) {
    if (!b) continue;
    if (b.type === 'text' && !b.hidden && b.text) parts.push(b.text);
    else if (b.type === 'tool_use') parts.push(b.name + ' ' + (() => { try { return JSON.stringify(b.input || {}).slice(0, 4000); } catch { return ''; } })());
    else if (b.type === 'tool_result') parts.push(String(b.content || '').slice(0, 6000));
    else if (b.type === 'local_notice' && b.text) parts.push(b.text);
    else if (b.type === 'compaction' && b.content) parts.push(String(b.content).slice(0, 4000));
  }
  return parts.join(' ').replace(/[\r\n\t]+/g, ' ');
}

module.exports = function createArchive(dataDir) {
  const DIR = path.join(dataDir, 'archives');
  const files = id => ({ data: path.join(DIR, id + '.jsonl'), idx: path.join(DIR, id + '.idx.json'), txt: path.join(DIR, id + '.txt') });
  const cache = new Map(); // id -> { offsets, txt?: string[] }

  // בונה ארכיון מרצף הודעות (async iterable). מחזיר { count, bytes }
  async function build(id, messages) {
    fs.mkdirSync(DIR, { recursive: true });
    const f = files(id), tmp = { data: f.data + '.tmp', txt: f.txt + '.tmp' };
    const dfd = fs.openSync(tmp.data, 'w'), tfd = fs.openSync(tmp.txt, 'w');
    const offsets = [], owner = {}; let pos = 0, count = 0; const toolAt = new Map();
    try {
      for await (const m of messages) {
        const line = Buffer.from(JSON.stringify(m) + '\n', 'utf8');
        offsets.push(pos); fs.writeSync(dfd, line); pos += line.length;
        // תוצאת כלי מוצגת בתוך הכרטיס של הכלי (בהודעה של Claude) — מוצאים בחיפוש את ההודעה שבה הכרטיס מופיע
        if (Array.isArray(m.content)) for (const b of m.content) { if (b && b.type === 'tool_use') toolAt.set(b.id, count); else if (b && b.type === 'tool_result' && toolAt.has(b.tool_use_id)) owner[count] = toolAt.get(b.tool_use_id); }
        fs.writeSync(tfd, textForSearch(m) + '\n'); count++;
      }
    } finally { fs.closeSync(dfd); fs.closeSync(tfd); }
    offsets.push(pos);
    fs.renameSync(tmp.data, f.data); fs.renameSync(tmp.txt, f.txt);
    fs.writeFileSync(f.idx, JSON.stringify({ offsets, owner }));
    cache.delete(id);
    return { count, bytes: pos };
  }
  function entry(id) {
    let e = cache.get(id);
    if (!e) { const j = JSON.parse(fs.readFileSync(files(id).idx, 'utf8')); e = Array.isArray(j) ? { offsets: j, owner: {}, txt: null } : { offsets: j.offsets, owner: j.owner || {}, txt: null }; cache.set(id, e); }
    return e;
  }
  const count = id => { try { return entry(id).offsets.length - 1; } catch { return 0; } };
  // הודעות [from, to) מהארכיון
  function read(id, from, to) {
    const o = entry(id).offsets, n = o.length - 1;
    from = Math.max(0, Math.min(n, from | 0)); to = Math.max(from, Math.min(n, to | 0));
    if (to <= from) return [];
    const fd = fs.openSync(files(id).data, 'r');
    try {
      const len = o[to] - o[from], buf = Buffer.alloc(len);
      fs.readSync(fd, buf, 0, len, o[from]);
      return buf.toString('utf8').split('\n').filter(Boolean).map(l => JSON.parse(l));
    } finally { fs.closeSync(fd); }
  }
  // חיפוש בכל ההיסטוריה: [{ i, snip }] לפי הסדר
  function search(id, q, limit = 3000) {
    const e = entry(id);
    if (!e.txt) e.txt = fs.readFileSync(files(id).txt, 'utf8').split('\n');
    const ql = q.toLowerCase(), out = [];
    for (let i = 0; i < e.txt.length && out.length < limit; i++) {
      const line = e.txt[i]; if (!line) continue;
      const k = line.toLowerCase().indexOf(ql); if (k < 0) continue;
      out.push({ i: e.owner[i] != null ? e.owner[i] : i, snip: line.slice(Math.max(0, k - 50), k + q.length + 70) });
    }
    return out;
  }
  function remove(id) { const f = files(id); for (const p of [f.data, f.idx, f.txt]) { try { fs.unlinkSync(p); } catch { } } cache.delete(id); }
  const exists = id => fs.existsSync(files(id).idx);
  return { build, read, count, search, remove, exists, textForSearch };
};
