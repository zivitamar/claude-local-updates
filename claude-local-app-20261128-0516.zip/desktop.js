'use strict';
// ============================================================
//  שליטה מלאה במחשב עבור Claude — כמו אדם: רואה את המסך, קורא כל תוכנה כקוד (UI Automation), עובר בין חלונות,
//  פותח תוכנות/קבצים, ומשתמש בעכבר ובמקלדת האמיתיים (תנועה ומהירות של אדם). העוזר desktop/ClaudeDesktop.exe (C#, נבנה עם csc של Windows).
//  לדפדפן — כלי browser_* (בתוך Chrome של המשתמש, בלי לתפוס את העכבר); לכל שאר המחשב — desktop_*.
// ============================================================
const fs = require('fs'), os = require('os'), path = require('path'), { spawn, spawnSync } = require('child_process');

const SRC_DIR = path.join(__dirname, 'desktop');
const HOME = path.join(process.env.LOCALAPPDATA || os.homedir(), 'ClaudeLocal');
const CSC = 'C:\\Windows\\Microsoft.NET\\Framework64\\v4.0.30319';

// העוזר רץ מקובץ אמיתי (מתוך ה-asar של ה-EXE אי אפשר להריץ): מעתיקים / בונים ל-%LOCALAPPDATA%\ClaudeLocal
function helperPath() {
  const dst = path.join(HOME, 'ClaudeDesktop.exe');
  try {
    const built = path.join(SRC_DIR, 'ClaudeDesktop.exe');
    let src = null; try { src = fs.readFileSync(built); } catch { }
    // שם לפי תוכן (גרסה חדשה = קובץ חדש): עותק ישן שרץ בשרת אחר נעול ואי אפשר לדרוס אותו
    if (src) { const named = path.join(HOME, 'ClaudeDesktop-' + require('crypto').createHash('sha1').update(src).digest('hex').slice(0, 10) + '.exe'); if (!fs.existsSync(named)) { fs.mkdirSync(HOME, { recursive: true }); fs.writeFileSync(named, src); } return named; }
    if (fs.existsSync(dst)) return dst;
    // אין קובץ בנוי — בונים מהמקור עם csc של .NET Framework (קיים בכל Windows)
    const cs = path.join(HOME, 'ClaudeDesktop.cs'); fs.mkdirSync(HOME, { recursive: true }); fs.writeFileSync(cs, fs.readFileSync(path.join(SRC_DIR, 'ClaudeDesktop.cs')));
    const r = spawnSync(path.join(CSC, 'csc.exe'), ['-nologo', '-optimize', '-out:' + dst, `-r:${CSC}\\WPF\\UIAutomationClient.dll`, `-r:${CSC}\\WPF\\UIAutomationTypes.dll`, `-r:${CSC}\\WPF\\WindowsBase.dll`, '-r:System.Drawing.dll', '-r:System.Windows.Forms.dll', '-r:System.Web.Extensions.dll', cs], { encoding: 'utf8' });
    if (r.status !== 0) throw new Error('בניית העוזר נכשלה: ' + (r.stdout || r.stderr || '').slice(0, 300));
    return dst;
  } catch (e) { throw new Error('העוזר לשליטה במחשב לא זמין: ' + e.message); }
}

class DesktopCtl {
  constructor() { this.proc = null; this.pend = new Map(); this.seq = 0; this.buf = ''; this.shot = null; }
  start() {
    if (this.proc && !this.proc.killed && this.proc.exitCode == null) return;
    if (process.platform !== 'win32') throw new Error('שליטה במחשב זמינה רק ב-Windows');
    const exe = helperPath();
    this.proc = spawn(exe, [], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
    this.buf = '';
    this.proc.stdout.on('data', d => { this.buf += d; let i; while ((i = this.buf.indexOf('\n')) >= 0) { const l = this.buf.slice(0, i); this.buf = this.buf.slice(i + 1); let m; try { m = JSON.parse(l); } catch { continue; } const p = this.pend.get(m.id); if (p) { this.pend.delete(m.id); clearTimeout(p.t); m.ok ? p.res(m.result) : p.rej(new Error(m.error)); } } });
    this.proc.on('exit', () => { for (const p of this.pend.values()) { clearTimeout(p.t); p.rej(new Error('העוזר נסגר')); } this.pend.clear(); this.proc = null; });
    this.proc.stdin.on('error', () => { });
  }
  call(op, args = {}, ms = 30000) {
    this.start();
    const id = ++this.seq;
    return new Promise((res, rej) => { const t = setTimeout(() => { if (this.pend.has(id)) { this.pend.delete(id); rej(new Error('העוזר לא ענה בזמן (' + op + ')')); } }, ms); this.pend.set(id, { res, rej, t }); this.proc.stdin.write(JSON.stringify({ id, op, ...args }) + '\n'); });
  }
  stop() { try { if (this.proc) this.proc.kill(); } catch { } this.proc = null; }

  // חלון לפי hwnd או טקסט מהכותרת / שם התהליך
  async findWindow(a) {
    const wins = await this.call('windows');
    if (a.hwnd != null) { const w = wins.find(x => String(x.hwnd) === String(a.hwnd)); if (!w) throw new Error('החלון ' + a.hwnd + ' לא נמצא (אולי נסגר). הרץ desktop_windows.'); return w; }
    const m = String(a.window || a.match || '').toLowerCase().trim();
    if (!m) { const fg = wins.find(x => x.foreground); if (fg) return fg; throw new Error('אין חלון פעיל'); }
    const hits = wins.filter(x => (x.title + ' ' + x.process).toLowerCase().includes(m));
    if (!hits.length) throw new Error(`לא נמצא חלון שמתאים ל-"${m}". הרץ desktop_windows.`);
    return hits.find(x => x.foreground) || hits.find(x => !x.minimized) || hits[0];
  }
  // נקודה: מקואורדינטות של צילום המסך האחרון (ברירת מחדל) או מקואורדינטות מסך אמיתיות (screen=true)
  toScreen(a) {
    const x = Number(a.x), y = Number(a.y); if (!Number.isFinite(x) || !Number.isFinite(y)) throw new Error('חסרים x / y');
    if (a.screen || !this.shot) return { x: Math.round(x), y: Math.round(y) };
    return { x: Math.round(this.shot.x + x * this.shot.scale), y: Math.round(this.shot.y + y * this.shot.scale) };
  }
  async screenshot(a = {}) {
    const args = { maxw: Math.min(1920, Math.max(640, Number(a.max_width) || 1600)) };
    let label = 'כל המסך';
    if (a.window || a.hwnd != null) { const w = await this.findWindow(a); if (w.minimized) await this.call('window', { hwnd: w.hwnd, action: 'restore' }); args.hwnd = w.hwnd; label = 'החלון "' + w.title + '"'; }
    const r = await this.call('screenshot', args, 20000);
    this.shot = { x: r.x, y: r.y, scale: r.scale, w: r.w, h: r.h };
    return { output: `צילום של ${label}: ${r.w}x${r.h} (קנה מידה ${r.scale.toFixed(2)}). לחיצה בנקודה מהתמונה: desktop_click עם x,y של התמונה.`, images: [{ data: r.jpeg, mimeType: 'image/jpeg' }], is_error: false };
  }

  // 🔒 מעקב נעול: האם הפעולה תפעיל את חלון האפליקציה? (isApp = פונקציה שמזהה את החלון). מחזיר סיבה או null. קריאה בלבד (צילום, רשימה) — מותרת
  async lockGuard(name, a, isApp) {
    a = a || {};
    if (name === 'desktop_screenshot' || name === 'desktop_windows' || (name === 'desktop_clipboard' && a.set == null) || name === 'desktop_open' || name === 'desktop_move' || name === 'desktop_scroll') return null;
    const wins = await this.call('windows'); const apps = wins.filter(isApp);
    if (name === 'desktop_ui') return null; // הקריאה מותרת; איזה חלון נקרא נרשם ב-exec (lastUiApp) רק כשהקריאה הצליחה
    if (name === 'desktop_ui_action') return this.lastUiApp ? 'UI Automation' : null;
    if (!apps.length) return null;
    const inApp = (x, y) => apps.some(w => !w.minimized && x >= w.x && x < w.x + w.w && y >= w.y && y < w.y + w.h);
    if (name === 'desktop_window') { let w = null; try { w = await this.findWindow(a); } catch { } return w && isApp(w) && (a.action || 'focus') === 'close' ? 'סגירת החלון' : null; }
    if (name === 'desktop_click' || name === 'desktop_drag') { const p = this.toScreen(a); if (inApp(p.x, p.y)) return 'עכבר'; if (name === 'desktop_drag') { const t = this.toScreen({ ...a, x: a.x2, y: a.y2 }); if (inApp(t.x, t.y)) return 'עכבר'; } return null; }
    if (name === 'desktop_key' && /(^|\s)(alt\+(shift\+)?(tab|esc)|ctrl\+alt\+tab|win(\+\S+)?|lwin|rwin)(\s|$)/i.test(String(a.keys || ''))) return 'מעבר בין חלונות במקלדת'; // alt+tab / win: אפשר להגיע לחלון האפליקציה בלי שזה ייראה
    if (name === 'desktop_type' || name === 'desktop_key') { const fg = wins.find(w => w.foreground); return fg && isApp(fg) ? 'מקלדת' : null; }
    return null;
  }
  async exec(name, a) {
    a = a || {};
    const ok = output => ({ output, images: [], is_error: false }), bad = output => ({ output, images: [], is_error: true });
    try {
      switch (name) {
        case 'desktop_screenshot': return await this.screenshot(a);
        case 'desktop_windows': {
          let wins = await this.call('windows'); const m = String(a.match || '').toLowerCase(); if (m) wins = wins.filter(x => (x.title + ' ' + x.process).toLowerCase().includes(m));
          return ok(`חלונות פתוחים (${wins.length}; * = בחזית):\n` + wins.map(w => `${w.foreground ? '*' : ' '} hwnd=${w.hwnd} | ${w.process} | ${w.title.slice(0, 80)}${w.minimized ? ' (ממוזער)' : w.maximized ? ' (מוגדל)' : ''}`).join('\n'));
        }
        case 'desktop_window': { const w = await this.findWindow(a); await this.call('window', { hwnd: w.hwnd, action: a.action || 'focus' }); return ok(`${a.action || 'focus'}: ${w.title}`); }
        case 'desktop_ui': {
          const w = await this.findWindow(a);
          if (w.minimized) await this.call('window', { hwnd: w.hwnd, action: 'restore' });
          const r = await this.call('ui', { hwnd: w.hwnd, filter: a.filter || '', max: Math.min(400, Number(a.max) || 220) }, 30000);
          this.lastUiApp = !!(this.isApp && this.isApp(w)); // 🔒 האלמנטים שנקראו עכשיו שייכים לחלון האפליקציה? (תמיד נרשם — גם לפני נעילה)
          return ok(`חלון: ${r.title} (hwnd=${w.hwnd}) — ${r.count} אלמנטים${r.truncated ? ' (קוצר; השתמש ב-filter)' : ''}. פעולה בלי עכבר: desktop_ui_action עם המספר. @x,y = מיקום על המסך (ל-desktop_click עם screen=true).\n` + r.lines.join('\n'));
        }
        case 'desktop_ui_action': { const r = await this.call('ui_act', { ref: Number(a.ref), action: a.action || 'invoke', value: a.value }); return ok(a.action === 'read' ? String(r) : `בוצע: ${a.action || 'invoke'} על [${a.ref}]`); }
        case 'desktop_click': { const p = this.toScreen(a); const r = await this.call('mouse', { action: a.double ? 'double' : a.button === 'right' ? 'right' : 'click', x: p.x, y: p.y }); return ok(`נלחץ (עכבר אמיתי) ב-${p.x},${p.y}`); }
        case 'desktop_move': { const p = this.toScreen(a); await this.call('mouse', { action: 'move', x: p.x, y: p.y }); return ok(`העכבר ב-${p.x},${p.y}`); }
        case 'desktop_drag': { const f = this.toScreen({ ...a, x: a.x, y: a.y }), t = this.toScreen({ ...a, x: a.x2, y: a.y2 }); await this.call('mouse', { action: 'drag', x: f.x, y: f.y, x2: t.x, y2: t.y }); return ok(`נגרר מ-${f.x},${f.y} ל-${t.x},${t.y}`); }
        case 'desktop_scroll': { const args = { action: 'scroll', amount: (a.direction === 'up' ? 1 : -1) * Math.max(1, Number(a.amount) || 3) }; if (a.x != null) Object.assign(args, this.toScreen(a)); await this.call('mouse', args); return ok('נגלל ' + (a.direction === 'up' ? 'למעלה' : 'למטה')); }
        case 'desktop_type': { await this.call('type', { text: String(a.text == null ? '' : a.text) }, 120000); return ok(`הוקלד (מקלדת אמיתית): ${String(a.text).slice(0, 80)}`); }
        case 'desktop_key': { await this.call('key', { keys: String(a.keys || '') }); return ok('נלחץ: ' + a.keys); }
        case 'desktop_open': { const r = await this.call('open', { target: String(a.target || ''), args: a.args }); return ok('נפתח: ' + a.target + (typeof r === 'number' ? ' (pid ' + r + ')' : '')); }
        case 'desktop_clipboard': { const r = await this.call('clipboard', a.set != null ? { set: String(a.set) } : {}); return ok(a.set != null ? 'הועתק ללוח' : 'תוכן הלוח:\n' + r); }
        default: return bad('כלי לא מוכר: ' + name);
      }
    } catch (e) { return bad('שגיאת שליטה במחשב: ' + e.message); }
  }
}

const T = (name, description, properties, required) => ({ name, description, input_schema: { type: 'object', properties: properties || {}, ...(required ? { required } : {}) } });
const win = { window: { type: 'string', description: 'text from the window title or process name (default: the foreground window)' }, hwnd: { type: 'string' } };
const pt = { x: { type: 'number' }, y: { type: 'number' }, screen: { type: 'boolean', description: 'x,y are real screen pixels (e.g. @x,y from desktop_ui) instead of the last screenshot' } };
const TOOL_DEFS = [
  T('desktop_screenshot', 'COMPUTER (the user\'s Windows PC, like a person sitting at it): screenshot of the whole screen or one window (window=<title text>). Use it to SEE what is on the screen. Coordinates in the image can be passed straight to desktop_click.', { ...win, max_width: { type: 'number' } }),
  T('desktop_windows', 'COMPUTER: list the open windows (hwnd, process, title; * = foreground). match filters by title/process.', { match: { type: 'string' } }),
  T('desktop_window', 'COMPUTER: bring a window to the front (focus) / minimize / maximize / restore / close. Choose it by window=<title text> or hwnd.', { ...win, action: { type: 'string', enum: ['focus', 'minimize', 'maximize', 'restore', 'close'] } }),
  T('desktop_ui', 'COMPUTER: read a program window AS CODE (Windows UI Automation): numbered buttons, fields, menus, list items, texts with their values and screen position. Works for most apps (Explorer, Settings, Office, Notepad, installers, dialogs). Faster and more exact than screenshots. filter = text to narrow the list.', { ...win, filter: { type: 'string' }, max: { type: 'number' } }),
  T('desktop_ui_action', 'COMPUTER: act on an element from desktop_ui WITHOUT moving the mouse: invoke (press), toggle, set_value (type into a field), expand / collapse, select, focus, read (full text).', { ref: { type: 'number' }, action: { type: 'string', enum: ['invoke', 'toggle', 'set_value', 'expand', 'collapse', 'select', 'focus', 'read'] }, value: { type: 'string' } }, ['ref']),
  T('desktop_click', 'COMPUTER: click with the REAL mouse like a person (smooth human movement, then click). x,y from the last desktop_screenshot (or screen=true for real screen pixels). double / button=right supported.', { ...pt, double: { type: 'boolean' }, button: { type: 'string', enum: ['left', 'right'] } }, ['x', 'y']),
  T('desktop_move', 'COMPUTER: move the real mouse to a point (hover).', pt, ['x', 'y']),
  T('desktop_drag', 'COMPUTER: drag with the real mouse from x,y to x2,y2.', { ...pt, x2: { type: 'number' }, y2: { type: 'number' } }, ['x', 'y', 'x2', 'y2']),
  T('desktop_scroll', 'COMPUTER: scroll the mouse wheel (direction up/down, amount in notches, optional x,y to scroll over).', { ...pt, direction: { type: 'string', enum: ['up', 'down'] }, amount: { type: 'number' } }),
  T('desktop_type', 'COMPUTER: type text with the REAL keyboard into the focused window/field, at human speed (Hebrew and English). Newline = Enter.', { text: { type: 'string' } }, ['text']),
  T('desktop_key', 'COMPUTER: press real keys / shortcuts, space separated: enter, tab, esc, ctrl+c, ctrl+v, alt+tab, win+r, ctrl+shift+esc, f5, up, down ...', { keys: { type: 'string' } }, ['keys']),
  T('desktop_open', 'COMPUTER: open a program, file, folder or URL (like double-click / Start menu): target = path, program name (notepad, calc, explorer) or URL; args optional.', { target: { type: 'string' }, args: { type: 'string' } }, ['target']),
  T('desktop_clipboard', 'COMPUTER: read the clipboard, or set it (set=text).', { set: { type: 'string' } })
];

module.exports = { DesktopCtl, TOOL_DEFS };
