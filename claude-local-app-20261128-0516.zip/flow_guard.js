'use strict';
// ============================================================
//  GOLEM FLOW GUARD — steel enforcement for the local chat.
//  Blocks any HEAVY GOLEM training/measurement run unless a valid, fresh
//  declaration exists (number + expected value + time-budget), and blocks a
//  dead approach after 2 strikes. Shares state with the VS Code hook:
//    ~/.claude/golem_flow/{declaration.json, strikes.json, log.jsonl}
//  The authoritative protocol: memory/golem_work_flow_protocol.md
//  Non-GOLEM commands pass through untouched — this never interferes.
// ============================================================
const fs = require('fs');
const os = require('os');
const path = require('path');

const DIR = path.join(os.homedir(), '.claude', 'golem_flow');
const DECL = path.join(DIR, 'declaration.json');
const STRIKES = path.join(DIR, 'strikes.json');
const LOG = path.join(DIR, 'log.jsonl');
const PROTOCOL = path.join(
  os.homedir(),
  '.claude', 'projects',
  'c--Users-zivit-OneDrive------------------------------',
  'memory', 'golem_work_flow_protocol.md'
);

// Keep this list in sync with the VS Code hook and the FLOW.
const HEAVY = /grpo_codeexec\.py|eval_verbose\.py|passk|curve_min|chain_curve|lr5_test|passk_walls|_run_[a-z0-9_]*\.cmd|golem.*\.cmd|diag_[a-z0-9_]*\.py|train.*grpo|accelerate\s+launch/i;
const GRACE_MIN = 15; // allowed age = time_cap_min + grace

function readJson(f) { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } }
function appendLog(obj) {
  try {
    fs.mkdirSync(DIR, { recursive: true });
    fs.appendFileSync(LOG, JSON.stringify({ ts: Date.now(), ...obj }) + '\n', 'utf8');
  } catch { }
}

function isHeavy(name, input) {
  if (name !== 'run_command') return false;
  const cmd = (input && input.command) || '';
  return HEAVY.test(cmd);
}

const BLOCK_HEAD = 'GOLEM FLOW GUARD — heavy run BLOCKED. ';
const FIX =
  '\nTo proceed, follow golem_work_flow_protocol.md and write ~/.claude/golem_flow/declaration.json with ' +
  '{step, approach, number, expected, time_cap_min, ts:<now ms>} — a REAL number expected to move, its expected value ' +
  '(prior -> target, >= measured noise floor), and a time budget. Metric = pass@6, NEVER greedy.';

// Returns { allowed:true, reminder? } or { allowed:false, reason }
function checkFlow(name, input) {
  if (!isHeavy(name, input)) return { allowed: true };
  const cmd = (input && input.command) || '';

  const decl = readJson(DECL);
  if (!decl || decl.number == null || decl.expected == null || decl.time_cap_min == null || !decl.approach) {
    const reason = BLOCK_HEAD + 'No valid declaration (missing number / expected / time_cap_min / approach).' + FIX;
    appendLog({ decision: 'deny', why: 'no-declaration', cmd: cmd.slice(0, 200) });
    return { allowed: false, reason };
  }

  const ageMin = (Date.now() - (Number(decl.ts) || 0)) / 60000;
  const maxAge = Number(decl.time_cap_min) + GRACE_MIN;
  if (!(Number(decl.ts) > 0) || ageMin > maxAge) {
    const reason = BLOCK_HEAD +
      `Declaration is STALE (age ${ageMin.toFixed(0)}m > budget ${decl.time_cap_min}m + ${GRACE_MIN}m grace). ` +
      'The time-budget passed. STOP, judge the last run honestly (STAGE 5), then write a FRESH declaration.' + FIX;
    appendLog({ decision: 'deny', why: 'stale', ageMin: Math.round(ageMin), cmd: cmd.slice(0, 200) });
    return { allowed: false, reason };
  }

  const strikes = readJson(STRIKES);
  if (strikes && strikes.approach === decl.approach && Number(strikes.strikes) >= 2) {
    const reason = BLOCK_HEAD +
      `2-STRIKES on approach "${decl.approach}" — it failed to move the number twice. ` +
      'Do NOT re-tune the same direction. SWITCH approach (new declaration.approach resets the guard), ' +
      'or run the RESEARCH TRIGGER (>=100 cross-checked sources) before any further heavy run.';
    appendLog({ decision: 'deny', why: '2-strikes', approach: decl.approach, cmd: cmd.slice(0, 200) });
    return { allowed: false, reason };
  }

  appendLog({ decision: 'allow', step: decl.step, approach: decl.approach, number: decl.number, expected: decl.expected, cmd: cmd.slice(0, 200) });
  const reminder =
    `\n\n[FLOW GUARD ✓ declared] step ${decl.step} | approach="${decl.approach}" | ${decl.number}: ${decl.expected} | budget ${decl.time_cap_min}m.\n` +
    'Reminder: ONE heavy job on idx1 (verify 0 MiB + no stuck proc first); measure ONCE, honestly; a move counts only if >= noise floor; report ONLY measured+proven. After it finishes run STAGE 5 and, if the number did NOT move, increment strikes.json.';
  return { allowed: true, reminder };
}

// The full protocol text (for injecting into the system prompt). Cached read.
let _protocolCache = null, _protocolMtime = 0;
function protocolText() {
  try {
    const st = fs.statSync(PROTOCOL);
    if (!_protocolCache || st.mtimeMs !== _protocolMtime) {
      _protocolCache = fs.readFileSync(PROTOCOL, 'utf8');
      _protocolMtime = st.mtimeMs;
    }
    return _protocolCache;
  } catch { return null; }
}

// A compact system-prompt preamble that activates the FLOW for GOLEM work.
function systemFlowBlock() {
  const proto = protocolText();
  if (!proto) return '';
  return `\n\n================ GOLEM FLOW — ACTIVE & ENFORCED ================
For ANY GOLEM / model-training / measurement task you work ONLY by the protocol below. You have NO permission to deviate.
This is enforced in code: a heavy GOLEM run (training/measurement) is BLOCKED by flow_guard.js unless you first write
~/.claude/golem_flow/declaration.json with {step, approach, number, expected, time_cap_min, ts:<now ms>}. The SAME approach
is blocked after 2 strikes (update strikes.json after a failed round). Metric = pass@6, NEVER greedy. Report ONLY measured+proven.
Before each step state: STEP NUMBER + the NUMBER you expect to move + its EXPECTED VALUE + a TIME-BUDGET (min).

----- golem_work_flow_protocol.md -----
${proto}
===============================================================`;
}

module.exports = { checkFlow, isHeavy, systemFlowBlock, protocolText, DIR, DECL, STRIKES, LOG };
