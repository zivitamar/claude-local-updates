'use strict';
// ============================================================
//  answer_rules.js — אכיפת ההוראות על כל תשובה סופית (Stop hook): כללים שאפשר למדוד מוצאים מטקסט ההוראות,
//  והתשובה הסופית נבדקת מולם. תשובה שלא עומדת — נחסמת, ו-Claude חייב לכתוב אותה מחדש (עד 3 פעמים).
//  כללים: מילים · שורות · תווים · משפטים (מקסימום) · עברית בלבד · בלי אימוג'י
// ============================================================
const NUM = '(\\d{1,5})';
const PATTERNS = [
  { type: 'maxWords', re: new RegExp(`(?:עד|מקסימום|לכל היותר|לא יותר מ-?|לא יותר מ|max(?:imum)?|up to|at most|no more than)\\s*${NUM}\\s*(?:מילים|מילה|words?)`, 'i') },
  { type: 'maxWords', re: new RegExp(`${NUM}\\s*(?:מילים|words)\\s*(?:לכל היותר|מקסימום|max(?:imum)?|at most)`, 'i') },
  { type: 'maxLines', re: new RegExp(`(?:עד|מקסימום|לכל היותר|לא יותר מ-?|max(?:imum)?|up to|at most|no more than)\\s*${NUM}\\s*(?:שורות|lines?)`, 'i') },
  { type: 'maxChars', re: new RegExp(`(?:עד|מקסימום|לכל היותר|לא יותר מ-?|max(?:imum)?|up to|at most)\\s*${NUM}\\s*(?:תווים|אותיות|characters|chars)`, 'i') },
  { type: 'maxSentences', re: new RegExp(`(?:עד|מקסימום|לכל היותר|לא יותר מ-?|max(?:imum)?|up to|at most)\\s*${NUM}\\s*(?:משפטים|sentences?)`, 'i') }
];
// ★ כל כלל נלקח רק ממה שכתוב בהוראות — ובמשמעות שלו. "אם תכתוב הכל בשורה אחת לא אבין" = חובה לרדת שורות, לא "מקסימום שורה אחת".
//   משפט עם שלילה / תנאי (אל, לא, אסור, אם, אחרת, בלי…) לפני "שורה אחת" — לא הופך למגבלה של שורה אחת.
const NEG = /(?:^|[\s,(])(?:אל|לא|אסור|בלי|ללא|אם|אחרת|שלא|אף פעם|never|don'?t|do not|not|if|otherwise|avoid)(?=[\s,]|$)/i;
const ONE_LINE = /(?:ב?שורה\s+אחת|one[- ]line|a single line|single[- ]line)/i;
const LINE_BREAKS = /(?:ירידות?\s+שורו?ת|ירידת[- ]שורה|(?:^|[\s,])ו?(?:ת|ל|י|נ)?רד(?:ת|ו|י)?\s+(?:ב|ל)?שור(?:ה|ות)|ו?(?:ת|ל)?הוריד\s+שור|(?:ל|ת)?שבו?ר\s+(?:את\s+ה)?שורות|שבירת\s+שורות|בפסקאות|בכמה\s+שורות|בשורות\s+נפרדות|(?:כל|כל ה)(?:\s*(?:נקודה|משפט|רעיון|שלב))\s+בשורה|line[- ]?breaks?|new\s*lines?|separate\s+lines|several\s+lines|multiple\s+lines)/i;
const clauses = t => String(t || '').split(/\n+|(?<=[.!?;])\s+/).map(s => s.trim()).filter(Boolean);
function rulesFrom(text) {
  const t = String(text || ''), out = [];
  for (const p of PATTERNS) { const m = t.match(p.re); if (m) { const n = parseInt(m[1], 10); if (n > 0 && !out.some(r => r.type === p.type)) out.push({ type: p.type, n, src: m[0] }); } }
  // "אל תכתוב יותר מ-5 שורות" = מקסימום 5
  if (!out.some(r => r.type === 'maxLines')) for (const c of clauses(t)) { const m = c.match(/יותר\s+מ-?\s*(\d{1,4})\s*(?:שורות|lines)/i); if (m && NEG.test(c.slice(0, m.index))) { out.push({ type: 'maxLines', n: +m[1], src: m[0] }); break; } }
  if (!out.some(r => r.type === 'maxWords')) for (const c of clauses(t)) { const m = c.match(/יותר\s+מ-?\s*(\d{1,5})\s*(?:מילים|words)/i); if (m && NEG.test(c.slice(0, m.index))) { out.push({ type: 'maxWords', n: +m[1], src: m[0] }); break; } }
  let breaks = LINE_BREAKS.test(t);
  for (const c of clauses(t)) {
    const m = c.match(ONE_LINE); if (!m) continue;
    if (NEG.test(c.slice(0, m.index)) || LINE_BREAKS.test(c)) breaks = true; // מזהירים מפני שורה אחת → חובה לרדת שורות
    else if (!out.some(r => r.type === 'maxLines')) out.push({ type: 'maxLines', n: 1, src: m[0] });
  }
  if (breaks) { const i = out.findIndex(r => r.type === 'maxLines' && r.n === 1); if (i >= 0) out.splice(i, 1); out.push({ type: 'lineBreaks', src: 'חובה לרדת שורות' }); }
  if (/(?:ענה|תענה|לענות|תשובות|תשובה|answer|reply)[^.\n]{0,25}(?:רק |תמיד |אך ורק )?ב?עברית|in hebrew only|only in hebrew|hebrew only/i.test(t)) out.push({ type: 'hebrew', src: 'עברית' });
  if (/(?:בלי|ללא|אסור)\s*(?:שום\s*)?(?:אימוג'?י|אמוג'?י|אימוג׳י|סמיילים|emojis?)|no emojis?/i.test(t)) out.push({ type: 'noEmoji', src: 'בלי אימוג\'י' });
  return out;
}
// כללים שחולצו ע"י Claude (הבנת המשמעות) → אותו מבנה. מספר שלא כתוב בטקסט — נזרק (לא ממציאים מגבלות)
function rulesFromJson(j, text) {
  const t = String(text || ''), out = [], has = n => n === 1 ? (/\b1\b/.test(t) || ONE_LINE.test(t) || /אחת|אחד|one|single/i.test(t)) : new RegExp(`(^|\\D)${n}(\\D|$)`).test(t);
  const num = (k, type, he) => { const n = Math.round(Number(j && j[k])); if (n > 0 && has(n)) out.push({ type, n, src: he(n) }); };
  num('maxWords', 'maxWords', n => `עד ${n} מילים`); num('maxLines', 'maxLines', n => n === 1 ? 'שורה אחת' : `עד ${n} שורות`);
  num('maxChars', 'maxChars', n => `עד ${n} תווים`); num('maxSentences', 'maxSentences', n => `עד ${n} משפטים`);
  if (j && j.lineBreaks === true) { const i = out.findIndex(r => r.type === 'maxLines' && r.n === 1); if (i >= 0) out.splice(i, 1); out.push({ type: 'lineBreaks', src: 'חובה לרדת שורות' }); }
  if (j && j.hebrewOnly === true) out.push({ type: 'hebrew', src: 'עברית' });
  if (j && j.noEmoji === true) out.push({ type: 'noEmoji', src: 'בלי אימוג\'י' });
  return out;
}
// תיאור קצר בעברית של מה שההוק אוכף (מוצג ליד כל הוראה)
const describe = rules => rules.map(r => r.type === 'maxWords' ? `עד ${r.n} מילים` : r.type === 'maxLines' ? (r.n === 1 ? 'שורה אחת בלבד' : `עד ${r.n} שורות`) : r.type === 'maxChars' ? `עד ${r.n} תווים` : r.type === 'maxSentences' ? `עד ${r.n} משפטים` : r.type === 'lineBreaks' ? 'חובה לרדת שורות' : r.type === 'hebrew' ? 'עברית בלבד' : r.type === 'noEmoji' ? 'בלי אימוג\'י' : r.type);
// הטקסט שנספר: בלי בלוקי קוד, בלי סימוני Markdown
function plain(s) { return String(s || '').replace(/```[\s\S]*?```/g, ' ').replace(/`[^`]*`/g, ' ').replace(/!?\[([^\]]*)\]\([^)]*\)/g, '$1').replace(/[*_#>|~]/g, ' '); }
const words = s => (plain(s).match(/[\p{L}\p{N}][\p{L}\p{N}'"׳״\-.]*/gu) || []).length;
const lines = s => String(s || '').replace(/```[\s\S]*?```/g, 'X').split(/\n/).filter(l => l.trim()).length;
const sentences = s => (plain(s).split(/[.!?…]+(?:\s|$)|\n+/).filter(x => /[\p{L}\p{N}]/u.test(x))).length;
const EMOJI = /[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{1F000}-\u{1F2FF}]/u;
function check(answer, rules) {
  const v = [];
  for (const r of rules) {
    if (r.type === 'maxWords') { const n = words(answer); if (n > r.n) v.push({ rule: r, actual: n, text: `${n} words — the limit is ${r.n} words`, he: `${n} מילים — המגבלה ${r.n}` }); }
    else if (r.type === 'maxLines') { const n = lines(answer); if (n > r.n) v.push({ rule: r, actual: n, text: `${n} lines — the limit is ${r.n} line(s)`, he: `${n} שורות — המגבלה ${r.n}` }); }
    else if (r.type === 'maxChars') { const n = plain(answer).replace(/\s+/g, ' ').trim().length; if (n > r.n) v.push({ rule: r, actual: n, text: `${n} characters — the limit is ${r.n}`, he: `${n} תווים — המגבלה ${r.n}` }); }
    else if (r.type === 'maxSentences') { const n = sentences(answer); if (n > r.n) v.push({ rule: r, actual: n, text: `${n} sentences — the limit is ${r.n}`, he: `${n} משפטים — המגבלה ${r.n}` }); }
    else if (r.type === 'hebrew') { const t = plain(answer); const he = (t.match(/[֐-׿]/g) || []).length, lat = (t.match(/[A-Za-z]/g) || []).length; if (he + lat > 20 && he < lat) v.push({ rule: r, actual: Math.round(he / (he + lat) * 100), text: `the answer is mostly not in Hebrew (${Math.round(he / (he + lat) * 100)}% Hebrew letters)`, he: `התשובה לא בעברית (${Math.round(he / (he + lat) * 100)}% אותיות עבריות)` }); }
    else if (r.type === 'noEmoji') { if (EMOJI.test(answer)) v.push({ rule: r, actual: 1, text: 'the answer contains emoji', he: 'יש אימוג׳י בתשובה' }); }
    // חובה לרדת שורות: תשובה של יותר ממשפט אחד שנכתבה כולה בשורה אחת
    else if (r.type === 'lineBreaks') { const ln = lines(answer), se = sentences(answer); if (ln < 2 && se >= 2) v.push({ rule: r, actual: ln, text: `the whole answer (${se} sentences) is on ONE line — the user's instructions require line breaks: put each sentence / point on its own line`, he: `${se} משפטים בשורה אחת — ההוראות מחייבות לרדת שורות` }); }
  }
  return v;
}
module.exports = { rulesFrom, rulesFromJson, describe, check, words, lines, sentences };
