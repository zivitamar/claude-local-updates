# -*- coding: utf-8 -*-
# בדיקת הגייה בלי לשמוע: מתמלל כל קובץ קול (Whisper עברי מקומי — אותו מנוע של ההכתבה) ומשווה למשפט שהיה אמור להיאמר.
#   <karaoke venv python> -I tools/verify-voices.py <manifest.json> <out.json> [voice,...]
import sys, json, os, re, difflib
from faster_whisper import WhisperModel
man_path, out_path = sys.argv[1], sys.argv[2]
voices = sys.argv[3].split(',') if len(sys.argv) > 3 and sys.argv[3] else None
keys = sys.argv[4].split(',') if len(sys.argv) > 4 and sys.argv[4] else None  # אופציונלי: רק מפתחות מסוימים
man = json.load(open(man_path, encoding='utf-8'))
base = os.path.dirname(man_path)
model = None
def _cuda_dlls():  # cuBLAS/cuDNN מחבילות nvidia-* (כמו במנוע ההכתבה)
    import importlib.util
    for pkg in ('nvidia.cublas', 'nvidia.cudnn'):
        try:
            s = importlib.util.find_spec(pkg)
            if s and s.submodule_search_locations:
                d = os.path.join(list(s.submodule_search_locations)[0], 'bin')
                if os.path.isdir(d): os.add_dll_directory(d); os.environ['PATH'] = d + os.pathsep + os.environ.get('PATH', '')
        except Exception: pass
_cuda_dlls()
for dev, ct in ((os.environ.get('VERIFY_DEVICE', 'cpu'), 'int8'), ('cpu', 'int8')):
    try:
        model = WhisperModel('ivrit-ai/whisper-large-v3-turbo-ct2', device=dev, compute_type=ct, local_files_only=True); print('model on', dev, ct, flush=True); break
    except Exception as e:
        print('skip', dev, ct, e, flush=True)
NIQQUD = re.compile('[֑-ׇ]')
norm = lambda s: re.sub(r'[^\wא-ת ]', '', NIQQUD.sub('', s or '')).strip()
rows = []
for v, clips in man['clips'].items():
    if voices and v not in voices: continue
    for key, c in clips.items():
        if keys and key not in keys: continue
        segs, _ = model.transcribe(os.path.join(base, c['file']), language='he', beam_size=1, vad_filter=False, condition_on_previous_text=False, without_timestamps=True)
        text = ' '.join(s.text for s in segs).strip()
        sim = difflib.SequenceMatcher(None, norm(c['phrase']), norm(text)).ratio()
        rows.append({'voice': v, 'key': key, 'phrase': NIQQUD.sub('', c['phrase']), 'heard': text, 'sim': round(sim, 2)})
json.dump(rows, open(out_path, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('transcribed', len(rows))
