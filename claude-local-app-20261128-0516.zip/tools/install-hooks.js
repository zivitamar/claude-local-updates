'use strict';
// node tools/install-hooks.js — installs the pre-push hook of this clone: a push of main publishes a signed update
// for every installation (tools/ship-after-push.js). Hooks live in the git dir, not in the repository, so a fresh clone
// runs this once. Needs the release keys in %USERPROFILE%\.secrets (only the owner's machine has them).
const fs = require('fs'), path = require('path'), cp = require('child_process');
const gitDir = cp.execFileSync('git', ['rev-parse', '--git-common-dir'], { cwd: path.resolve(__dirname, '..'), encoding: 'utf8' }).trim();
const hook = path.resolve(path.resolve(__dirname, '..'), gitDir, 'hooks', 'pre-push');
fs.mkdirSync(path.dirname(hook), { recursive: true });
fs.writeFileSync(hook, [
  '#!/bin/sh',
  '# git push of main → a signed update for every installation (tools/ship-after-push.js, detached; log: %LOCALAPPDATA%\\ClaudeLocalBuild\\ship.log)',
  'while read local_ref local_sha remote_ref remote_sha; do',
  '  if [ "$remote_ref" = "refs/heads/main" ] && [ "$local_sha" != "0000000000000000000000000000000000000000" ]; then',
  '    node "$(git rev-parse --show-toplevel)/tools/ship-after-push.js" --detach "$local_sha" >/dev/null 2>&1',
  '  fi',
  'done',
  'exit 0', ''].join('\n'));
try { fs.chmodSync(hook, 0o755); } catch { }
console.log('installed', hook);
