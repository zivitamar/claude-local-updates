# סינתזת דיבור לקבצי WAV עם הקול העברי המובנה של Windows (Microsoft Asaf) — מקומי, בלי להשמיע כלום.
# קלט: קובץ JSON עם [{ "ssml": "...", "out": "path.wav" }, ...]  →  כותב כל קובץ, ומדפיס OK/ERR לכל שורה.
param([Parameter(Mandatory = $true)][string]$JobFile)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Media.SpeechSynthesis.SpeechSynthesizer, Windows.Media.SpeechSynthesis, ContentType = WindowsRuntime]
$null = [Windows.Storage.Streams.DataReader, Windows.Storage.Streams, ContentType = WindowsRuntime]
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Wait-Op($op, [Type]$type) { $t = $asTask.MakeGenericMethod($type).Invoke($null, @($op)); $null = $t.Wait(-1); return $t.Result }
$synth = New-Object Windows.Media.SpeechSynthesis.SpeechSynthesizer
$voice = [Windows.Media.SpeechSynthesis.SpeechSynthesizer]::AllVoices | Where-Object { $_.Language -eq 'he-IL' } | Select-Object -First 1
if (-not $voice) { Write-Output 'ERR no Hebrew voice'; exit 1 }
$synth.Voice = $voice
$jobs = Get-Content -Raw -Encoding UTF8 $JobFile | ConvertFrom-Json
foreach ($j in $jobs) {
  try {
    $stream = Wait-Op ($synth.SynthesizeSsmlToStreamAsync($j.ssml)) ([Windows.Media.SpeechSynthesis.SpeechSynthesisStream])
    $size = [uint32]$stream.Size
    $reader = New-Object Windows.Storage.Streams.DataReader($stream.GetInputStreamAt(0))
    $null = Wait-Op ($reader.LoadAsync($size)) ([uint32])
    $bytes = New-Object byte[] $size; $reader.ReadBytes($bytes)
    [IO.File]::WriteAllBytes($j.out, $bytes)
    Write-Output ('OK ' + $j.out)
  } catch { Write-Output ('ERR ' + $j.out + ' ' + $_.Exception.Message) }
}
