#!/bin/sh
# ============================================================
#  Claude Local — headless install on any Linux (x64 / arm64; Debian, Ubuntu, RHEL/Fedora/Rocky/Alma, Arch, SUSE, Alpine…)
#  Usage:  sh install-linux.sh <bundle.tgz> [port] [mesh-port]
#  Everything goes to ~/.local/share/claude-local (or $CLAUDE_LOCAL_HOME): its OWN Node runtime (official nodejs.org build,
#  SHA-256 checked) + the app + data. Nothing system-wide is changed unless running as root (then a system service).
#  The app downloads the official Claude Code CLI by itself (downloads.claude.ai, SHA-256 checked) on first start.
#  Runs as a service that comes back after reboot: systemd (system or user) → else cron @reboot.
#  Prints one line at the end:  CLAUDE_LOCAL_INSTALLED port=<p> mesh=<m> home=<dir> service=<kind>
# ============================================================
set -eu
BUNDLE="${1:?bundle.tgz}"; PORT="${2:-3456}"; MESH_PORT="${3:-47400}"
NODE_VERSION="${CLAUDE_LOCAL_NODE:-v22.18.0}"
BASE="${CLAUDE_LOCAL_HOME:-${XDG_DATA_HOME:-$HOME/.local/share}/claude-local}"
APP="$BASE/app"; DATA="$BASE/data"; NODE_DIR="$BASE/node"
say() { echo "[install] $*"; }
fetch() { if command -v curl >/dev/null 2>&1; then curl -fsSL "$1" -o "$2"; elif command -v wget >/dev/null 2>&1; then wget -qO "$2" "$1"; else echo "need curl or wget" >&2; exit 2; fi; }
mkdir -p "$BASE" "$DATA"

# ----- Node runtime (own copy, never touches the system Node) -----
case "$(uname -m)" in x86_64|amd64) NA=x64 ;; aarch64|arm64) NA=arm64 ;; armv7l) NA=armv7l ;; *) echo "unsupported CPU $(uname -m)" >&2; exit 3 ;; esac
LIBC=glibc; if ldd --version 2>&1 | grep -qi musl || [ -f /etc/alpine-release ]; then LIBC=musl; fi
if [ ! -x "$NODE_DIR/bin/node" ] || [ "$("$NODE_DIR/bin/node" -v 2>/dev/null)" != "$NODE_VERSION" ]; then
  T=$(mktemp -d)
  if [ "$LIBC" = musl ]; then
    say "musl libc (Alpine): using the distro node (needs >= 20)"; command -v node >/dev/null || { echo "apk add nodejs first" >&2; exit 4; }
    mkdir -p "$NODE_DIR/bin"; ln -sf "$(command -v node)" "$NODE_DIR/bin/node"
  else
    F="node-$NODE_VERSION-linux-$NA.tar.gz"
    say "downloading Node $NODE_VERSION ($NA)"
    fetch "https://nodejs.org/dist/$NODE_VERSION/$F" "$T/$F"
    fetch "https://nodejs.org/dist/$NODE_VERSION/SHASUMS256.txt" "$T/SUMS"
    WANT=$(grep " $F\$" "$T/SUMS" | cut -d' ' -f1); GOT=$(sha256sum "$T/$F" | cut -d' ' -f1)
    [ -n "$WANT" ] && [ "$WANT" = "$GOT" ] || { echo "Node SHA-256 mismatch" >&2; exit 5; }
    rm -rf "$NODE_DIR"; mkdir -p "$NODE_DIR"; tar -xzf "$T/$F" -C "$NODE_DIR" --strip-components=1
  fi
  rm -rf "$T"
fi
say "node $("$NODE_DIR/bin/node" -v)"

# ----- the app (replaced atomically; data stays) -----
rm -rf "$APP.new"; mkdir -p "$APP.new"; tar -xzf "$BUNDLE" -C "$APP.new"
[ -f "$APP.new/server.js" ] || { echo "bad bundle" >&2; exit 6; }
rm -rf "$APP.old"; [ -d "$APP" ] && mv "$APP" "$APP.old"; mv "$APP.new" "$APP"; rm -rf "$APP.old"
[ -f "$DATA/config.json" ] || printf '{"accountMode":"subscription","autoApprove":false}' > "$DATA/config.json"

# ----- service -----
ENVS="DATA_DIR=$DATA PORT=$PORT NO_BROWSER=1 CLAUDE_SUPERVISED=1 CLAUDE_MESH_PORT=$MESH_PORT"
RUNSH="$BASE/run.sh"
cat > "$RUNSH" <<EOF
#!/bin/sh
export $ENVS
export PATH="$NODE_DIR/bin:\$HOME/.local/bin:\$PATH"
cd "$APP"
exec "$NODE_DIR/bin/node" "$APP/server.js"
EOF
chmod 755 "$RUNSH"
KIND=none
UNIT="[Unit]
Description=Claude Local (headless)
After=network-online.target
Wants=network-online.target
[Service]
ExecStart=$RUNSH
Restart=always
RestartSec=3
[Install]
WantedBy=default.target"
if command -v systemctl >/dev/null 2>&1 && [ "$(id -u)" = 0 ] && systemctl list-units >/dev/null 2>&1; then
  printf '%s\n' "$UNIT" | sed 's/^WantedBy=default.target/WantedBy=multi-user.target/' > /etc/systemd/system/claude-local.service
  systemctl daemon-reload && systemctl enable --now claude-local.service >/dev/null 2>&1 && systemctl restart claude-local.service && KIND=systemd-system
elif command -v systemctl >/dev/null 2>&1 && systemctl --user list-units >/dev/null 2>&1; then
  mkdir -p "$HOME/.config/systemd/user"; printf '%s\n' "$UNIT" > "$HOME/.config/systemd/user/claude-local.service"
  systemctl --user daemon-reload && systemctl --user enable claude-local.service >/dev/null 2>&1 && systemctl --user restart claude-local.service && KIND=systemd-user
  # שירות משתמש ממשיך גם אחרי יציאה מה-SSH ואחרי אתחול רק עם linger
  if loginctl enable-linger "$(id -un)" >/dev/null 2>&1 || sudo -n loginctl enable-linger "$(id -un)" >/dev/null 2>&1; then KIND="$KIND+linger"; else
    ( crontab -l 2>/dev/null | grep -v 'claude-local/run.sh' ; echo "@reboot systemctl --user start claude-local.service || nohup $RUNSH >/dev/null 2>&1 &" ) | crontab - 2>/dev/null && KIND="$KIND+cron"; fi
fi
if [ "$KIND" = none ]; then
  ( crontab -l 2>/dev/null | grep -v 'claude-local/run.sh' ; echo "@reboot nohup $RUNSH >> $BASE/server.log 2>&1 &" ) | crontab - 2>/dev/null || true
  pkill -f "$APP/server.js" 2>/dev/null || true
  nohup "$RUNSH" >> "$BASE/server.log" 2>&1 &
  KIND=nohup+cron
fi

# ----- firewall: only the encrypted mesh port (the app's web port stays on 127.0.0.1) -----
FW=none
if command -v ufw >/dev/null 2>&1 && (ufw status 2>/dev/null || sudo -n ufw status 2>/dev/null) | grep -q "Status: active"; then (ufw allow "$MESH_PORT/tcp" >/dev/null 2>&1 || sudo -n ufw allow "$MESH_PORT/tcp" >/dev/null 2>&1) && FW=ufw; fi
if command -v firewall-cmd >/dev/null 2>&1 && (firewall-cmd --state >/dev/null 2>&1); then (firewall-cmd --permanent --add-port="$MESH_PORT/tcp" >/dev/null 2>&1 && firewall-cmd --reload >/dev/null 2>&1 || sudo -n sh -c "firewall-cmd --permanent --add-port=$MESH_PORT/tcp && firewall-cmd --reload" >/dev/null 2>&1) && FW=firewalld; fi

# ----- wait until it answers -----
i=0; while [ $i -lt 60 ]; do if (curl -fs "http://127.0.0.1:$PORT/api/mesh/info" >/dev/null 2>&1 || wget -qO- "http://127.0.0.1:$PORT/api/mesh/info" >/dev/null 2>&1); then break; fi; i=$((i+1)); sleep 1; done
[ $i -lt 60 ] || { echo "server did not start (see journalctl / $BASE/server.log)" >&2; exit 7; }
echo "CLAUDE_LOCAL_INSTALLED port=$PORT mesh=$MESH_PORT home=$BASE service=$KIND firewall=$FW node=$("$NODE_DIR/bin/node" -v)"
