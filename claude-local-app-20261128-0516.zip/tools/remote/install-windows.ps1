# ============================================================
#  Claude Local - headless install on Windows 10/11 and Windows Server 2016/2019/2022/2025 (x64 / arm64)
#  Usage:  powershell -NoProfile -ExecutionPolicy Bypass -File install-windows.ps1 -Bundle <bundle.zip|.tgz> [-Port 3456] [-MeshPort 47400]
#  Installs into %LOCALAPPDATA%\ClaudeLocal\headless: its OWN Node runtime (official nodejs.org zip, SHA-256 checked) + the app + data.
#  Runs as a Scheduled Task at startup under this user (S4U: no password stored, runs with nobody logged in, survives SSH logout
#  and reboots, restarts on failure). Opens ONLY the encrypted mesh port in Windows Firewall (the app's web port stays on 127.0.0.1).
#  Prints one line at the end:  CLAUDE_LOCAL_INSTALLED port=<p> mesh=<m> home=<dir> service=task firewall=<x> node=<v>
#  (ASCII only on purpose: Windows PowerShell 5.1 reads a BOM-less .ps1 as ANSI.)
# ============================================================
param([Parameter(Mandatory)][string]$Bundle, [int]$Port = 3456, [int]$MeshPort = 47400, [string]$NodeVersion = 'v22.18.0')
$ErrorActionPreference = 'Stop'; $ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
function Say($m) { Write-Output "[install] $m" }
$Base = Join-Path $env:LOCALAPPDATA 'ClaudeLocal\headless'
$App = Join-Path $Base 'app'; $Data = Join-Path $Base 'data'; $NodeDir = Join-Path $Base 'node'
New-Item -ItemType Directory -Force $Base, $Data | Out-Null

# ----- Node runtime -----
$arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'x64' }
$nodeExe = Join-Path $NodeDir 'node.exe'
$have = if (Test-Path $nodeExe) { (& $nodeExe -v) } else { '' }
if ($have -ne $NodeVersion) {
  $f = "node-$NodeVersion-win-$arch.zip"; $tmp = Join-Path $env:TEMP ("cl-node-" + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Force $tmp | Out-Null
  Say "downloading Node $NodeVersion ($arch)"
  Invoke-WebRequest -UseBasicParsing "https://nodejs.org/dist/$NodeVersion/$f" -OutFile (Join-Path $tmp $f)
  $sums = (Invoke-WebRequest -UseBasicParsing "https://nodejs.org/dist/$NodeVersion/SHASUMS256.txt").Content
  $want = (($sums -split "`n") | Where-Object { $_ -match " $([regex]::Escape($f))$" } | ForEach-Object { ($_ -split ' ')[0] }) | Select-Object -First 1
  $got = (Get-FileHash -Algorithm SHA256 (Join-Path $tmp $f)).Hash.ToLower()
  if (-not $want -or $want.ToLower() -ne $got) { throw "Node SHA-256 mismatch" }
  if (Test-Path $NodeDir) { Remove-Item $NodeDir -Recurse -Force }
  Expand-Archive (Join-Path $tmp $f) -DestinationPath $tmp -Force
  Move-Item (Join-Path $tmp ("node-$NodeVersion-win-$arch")) $NodeDir
  Remove-Item $tmp -Recurse -Force
}
Say ("node " + (& $nodeExe -v))

# ----- stop a running copy, replace the app (data stays) -----
$taskName = 'ClaudeLocalHeadless'
try { Stop-ScheduledTask -TaskName $taskName -ErrorAction Stop } catch { }
# order matters: the run.cmd loop restarts node within 3 s, so stop the loop (cmd.exe) first, then node
for ($k = 0; $k -lt 3; $k++) {
  Get-CimInstance Win32_Process -Filter "Name='cmd.exe'" | Where-Object { $_.CommandLine -like "*ClaudeLocal\headless\run.cmd*" } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  Get-CimInstance Win32_Process -Filter "Name='node.exe'" | Where-Object { $_.CommandLine -like "*ClaudeLocal\headless\app\server.js*" } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  Start-Sleep -Milliseconds 700
}
$new = "$App.new"; if (Test-Path $new) { Remove-Item $new -Recurse -Force }
New-Item -ItemType Directory -Force $new | Out-Null
if ($Bundle -like '*.zip') { Expand-Archive $Bundle -DestinationPath $new -Force }
else { $tar = Join-Path $env:SystemRoot 'System32\tar.exe'; if (-not (Test-Path $tar)) { throw 'tar.exe missing (Server 2016): send a .zip bundle' }; & $tar -xzf $Bundle -C $new; if ($LASTEXITCODE) { throw "tar failed $LASTEXITCODE" } }
if (-not (Test-Path (Join-Path $new 'server.js'))) { throw 'bad bundle' }
Start-Sleep -Milliseconds 800
if (Test-Path $App) {
  $old = "$App.old-" + (Get-Date -Format 'yyyyMMddHHmmss')
  for ($k = 0; $k -lt 10 -and (Test-Path $App); $k++) { try { Rename-Item $App $old -ErrorAction Stop } catch { Start-Sleep 1 } }
  if (Test-Path $App) { throw 'the old app folder is still locked' }
  Remove-Item $old -Recurse -Force -ErrorAction SilentlyContinue
}
Move-Item $new $App
Get-ChildItem $Base -Directory -Filter 'app.old-*' -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
if (-not (Test-Path (Join-Path $Data 'config.json'))) { Set-Content -Path (Join-Path $Data 'config.json') -Value '{"accountMode":"subscription","autoApprove":false}' -Encoding ASCII }

# ----- runner + scheduled task (S4U, at startup, restart on failure) -----
$run = Join-Path $Base 'run.cmd'
$lines = @('@echo off', "set DATA_DIR=$Data", "set PORT=$Port", 'set NO_BROWSER=1', 'set CLAUDE_SUPERVISED=1', "set CLAUDE_MESH_PORT=$MeshPort", "cd /d `"$App`"", ":loop", "`"$nodeExe`" `"$App\server.js`" >> `"$Base\server.log`" 2>&1", 'timeout /t 3 /nobreak >nul', 'goto loop')
Set-Content -Path $run -Value $lines -Encoding ASCII
$action = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument "/c `"$run`""
$trigger = New-ScheduledTaskTrigger -AtStartup
$me = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name   # in an SSH session USERDOMAIN can be wrong
$principal = New-ScheduledTaskPrincipal -UserId $me -LogonType S4U -RunLevel Highest
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -StartWhenAvailable -MultipleInstances IgnoreNew
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
Start-ScheduledTask -TaskName $taskName

# ----- firewall: only the encrypted mesh port -----
$fw = 'none'
try {
  Get-NetFirewallRule -DisplayName 'Claude Local mesh' -ErrorAction SilentlyContinue | Remove-NetFirewallRule
  New-NetFirewallRule -DisplayName 'Claude Local mesh' -Direction Inbound -Protocol TCP -LocalPort $MeshPort -Action Allow -Profile Any -Program $nodeExe | Out-Null
  $fw = 'windows-firewall'
} catch { $fw = 'not-admin' }

# ----- wait until it answers -----
$ok = $false
for ($i = 0; $i -lt 90; $i++) { try { Invoke-WebRequest -UseBasicParsing "http://127.0.0.1:$Port/api/mesh/info" -TimeoutSec 3 | Out-Null; $ok = $true; break } catch { Start-Sleep 1 } }
if (-not $ok) { throw "server did not start - see $Base\server.log" }
Write-Output "CLAUDE_LOCAL_INSTALLED port=$Port mesh=$MeshPort home=$Base service=task-s4u firewall=$fw node=$(& $nodeExe -v)"
