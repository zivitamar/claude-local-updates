﻿# התקנה חד-פעמית של התוסף "Claude Local — שליטה בכרום" בפרופיל ה-Chrome של המשתמש, בלי עכבר:
# פותח chrome://extensions, מדליק "מצב מפתח", לוחץ "טעינת פריט לא ארוז" ובוחר את תיקיית התוסף — דרך UI Automation (לא מזיז את העכבר).
# שימוש: powershell -File install-chrome-extension.ps1 -ExtDir <תיקייה> [-Profile Default]
param([Parameter(Mandatory)][string]$ExtDir, [string]$Profile = 'Default')
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
$UIA = [System.Windows.Automation.AutomationElement]
$TS = [System.Windows.Automation.TreeScope]
$CT = [System.Windows.Automation.ControlType]
function Log($m) { Write-Output ("[{0:HH:mm:ss}] {1}" -f (Get-Date), $m) }
function Find-All($root, $scope) { $root.FindAll($scope, [System.Windows.Automation.Condition]::TrueCondition) }
function Wait-For([scriptblock]$fn, [int]$ms = 10000) { $t0 = Get-Date; while (((Get-Date) - $t0).TotalMilliseconds -lt $ms) { $r = & $fn; if ($r) { return $r }; Start-Sleep -Milliseconds 200 }; return $null }

$chrome = @('C:\Program Files\Google\Chrome\Application\chrome.exe', 'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe', "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $chrome) { throw 'Chrome לא נמצא' }
function Chrome-Windows { $UIA::RootElement.FindAll($TS::Children, (New-Object System.Windows.Automation.PropertyCondition($UIA::ClassNameProperty, 'Chrome_WidgetWin_1'))) }
function Find-ByName($root, [string]$pattern, [int]$ms = 8000) {
  Wait-For { foreach ($e in (Find-All $root $TS::Descendants)) { $n = $e.Current.Name; if ($n -and $n -match $pattern) { return $e } } } $ms
}
function Invoke-El($e) {
  $pats = $e.GetSupportedPatterns() | ForEach-Object { $_.ProgrammaticName }
  if ($pats -match 'InvokePattern') { $e.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke(); return }
  if ($pats -match 'ExpandCollapsePattern') { $e.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand(); return }
  if ($pats -match 'TogglePattern') { $e.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern).Toggle(); return }
  if ($pats -match 'SelectionItemPattern') { $e.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern).Select(); return }
  throw ('אין דרך ללחוץ על "' + $e.Current.Name + '" (' + ($pats -join ',') + ')')
}
# Chrome לא פותח chrome:// משורת הפקודה — פותחים חלון ריק משלנו, ומגיעים לדף התוספים דרך התפריט של Chrome ("תוספים" › "ניהול תוספים")
$before = @(Chrome-Windows | ForEach-Object { $_.Current.NativeWindowHandle })
Log "פותח חלון Chrome בפרופיל $Profile"
Start-Process -FilePath $chrome -ArgumentList @("--profile-directory=$Profile", '--new-window', 'about:blank')
$win = Wait-For { foreach ($w in (Chrome-Windows)) { if ($before -notcontains $w.Current.NativeWindowHandle -and $w.Current.Name -match 'about:blank|כרטיסייה חדשה|New Tab') { return $w } } } 12000
if (-not $win) { throw 'החלון החדש של Chrome לא נמצא' }
$hwnd = $win.Current.NativeWindowHandle
Log ("חלון: " + $win.Current.Name)
# שורת הכתובת של החלון שלנו: כותבים chrome://extensions ושולחים Enter כהודעה לחלון הזה בלבד (PostMessage — לא קלט של המקלדת במחשב)
Add-Type -Namespace W32 -Name Msg -MemberDefinition '[DllImport("user32.dll")] public static extern bool PostMessage(System.IntPtr h, uint m, System.IntPtr w, System.IntPtr l);'
$omni = Wait-For { $win.FindFirst($TS::Descendants, (New-Object System.Windows.Automation.PropertyCondition($UIA::AutomationIdProperty, 'view_1012'))) } 5000
if (-not $omni) { $omni = Wait-For { $win.FindFirst($TS::Descendants, (New-Object System.Windows.Automation.PropertyCondition($UIA::ControlTypeProperty, $CT::Edit))) } 3000 }
if (-not $omni) { throw 'שורת הכתובת לא נמצאה' }
$omni.SetFocus(); Start-Sleep -Milliseconds 150
$omni.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).SetValue('chrome://extensions/')
Start-Sleep -Milliseconds 200
$hw = [IntPtr]$hwnd
[W32.Msg]::PostMessage($hw, 0x0100, [IntPtr]0x0D, [IntPtr]0x001C0001) | Out-Null
[W32.Msg]::PostMessage($hw, 0x0102, [IntPtr]0x0D, [IntPtr]0x001C0001) | Out-Null
[W32.Msg]::PostMessage($hw, 0x0101, [IntPtr]0x0D, [IntPtr]0xC01C0001) | Out-Null
$win = Wait-For { foreach ($w in (Chrome-Windows)) { if ($w.Current.NativeWindowHandle -eq $hwnd -and $w.Current.Name -match 'תוספים|Extensions') { return $w } } } 8000
if (-not $win) { throw 'דף התוספים לא נפתח' }
Log ("דף: " + $win.Current.Name)
# 1. מצב מפתח
function Find-Button($root, [string]$pattern, [int]$ms = 8000) {
  Wait-For { foreach ($e in (Find-All $root $TS::Descendants)) { $c = $e.Current; if ($c.Name -and $c.Name -match $pattern -and $c.ControlType -eq $CT::Button) { return $e } } } $ms
}
$dev = Find-Button $win '^\W*(מצב מפתח|מצב מפתחים|מצב פיתוח|Developer mode)\W*$'
if (-not $dev) { throw 'המתג "מצב מפתח" לא נמצא' }
$tp = $null; try { $tp = $dev.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern) } catch { }
if ($tp) { if ($tp.Current.ToggleState -ne 'On') { $tp.Toggle(); Log 'מצב מפתח: הודלק' } else { Log 'מצב מפתח: כבר דלוק' } }
else { $dev.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke(); Log 'מצב מפתח: נלחץ' }

# 2. טעינת פריט לא ארוז (נפתח חלון בחירת תיקייה — הלחיצה רצה ברקע כי היא חוסמת עד שהחלון נסגר)
Start-Sleep -Milliseconds 400
$load = Find-Button $win 'לא ארוז|[Uu]npacked'
if (-not $load) { throw 'הכפתור "טעינת פריט לא ארוז" לא נמצא' }
Log ("כפתור: " + $load.Current.Name)
$rid = $load.GetRuntimeId() -join ','
$job = [powershell]::Create().AddScript({ param($wname, $rid)
  Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
  $UIA = [System.Windows.Automation.AutomationElement]
  $w = $UIA::RootElement.FindAll([System.Windows.Automation.TreeScope]::Children, [System.Windows.Automation.Condition]::TrueCondition) | Where-Object { $_.Current.Name -eq $wname } | Select-Object -First 1
  foreach ($e in $w.FindAll([System.Windows.Automation.TreeScope]::Descendants, [System.Windows.Automation.Condition]::TrueCondition)) { if (($e.GetRuntimeId() -join ',') -eq $rid) { $e.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke(); break } }
}).AddArgument($win.Current.Name).AddArgument($rid)
$h = $job.BeginInvoke()

# 3. חלון בחירת התיקייה: כותבים את הנתיב ולוחצים "בחר תיקייה"
$dlg = Wait-For {
  foreach ($d in $UIA::RootElement.FindAll($TS::Descendants, (New-Object System.Windows.Automation.PropertyCondition($UIA::ClassNameProperty, '#32770')))) { return $d }
} 10000
if (-not $dlg) { throw 'חלון בחירת התיקייה לא נפתח' }
Log ("דיאלוג: " + $dlg.Current.Name)
# שדה "תיקייה" (Edit עם מזהה 1152) וכפתור "בחר תיקייה" (מזהה 1): הודעות Windows ישירות לחלון הדיאלוג (WM_SETTEXT + BM_CLICK) — בלי עכבר ובלי מקלדת
Add-Type -TypeDefinition @'
using System; using System.Text; using System.Runtime.InteropServices; using System.Collections.Generic;
public static class DlgW {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr p, EnumProc f, IntPtr l);
  [DllImport("user32.dll")] public static extern int GetDlgCtrlID(IntPtr h);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern IntPtr SendMessage(IntPtr h, uint m, IntPtr w, string l);
  [DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
  public static List<IntPtr> Children(IntPtr p) { var r = new List<IntPtr>(); EnumChildWindows(p, (h, l) => { r.Add(h); return true; }, IntPtr.Zero); return r; }
  public static string Cls(IntPtr h) { var s = new StringBuilder(256); GetClassName(h, s, 256); return s.ToString(); }
}
'@
$dh = [IntPtr]$dlg.Current.NativeWindowHandle
$fEdit = $null; $fOk = $null
$null = Wait-For { foreach ($k in [DlgW]::Children($dh)) { $id = [DlgW]::GetDlgCtrlID($k); $cls = [DlgW]::Cls($k); if ($id -eq 1152 -and $cls -eq 'Edit') { $script:fEdit = $k }; if ($id -eq 1 -and $cls -eq 'Button') { $script:fOk = $k } }; return ($script:fEdit -and $script:fOk) } 5000
if (-not $fEdit) { throw 'שדה התיקייה בדיאלוג לא נמצא' }
[DlgW]::SendMessage($fEdit, 0x000C, [IntPtr]::Zero, $ExtDir) | Out-Null
Log "נבחרה התיקייה: $ExtDir"
if ($fOk) { [DlgW]::SendMessage($fOk, 0x00F5, [IntPtr]::Zero, [IntPtr]::Zero) | Out-Null } else { [DlgW]::SendMessage($dh, 0x0111, [IntPtr]1, [IntPtr]::Zero) | Out-Null }
Log 'אושר'
$null = Wait-For { $h.IsCompleted } 8000
# בדיקה שהתוסף נטען (מופיע ברשימת התוספים בדף) ואז סוגרים את החלון שפתחנו
$found = Find-ByName $win 'Claude Local' 8000
if ($found) { Log 'התוסף מופיע בדף התוספים' } else { Log 'אזהרה: התוסף לא נמצא ברשימה' }
$close = $win.FindFirst($TS::Descendants, (New-Object System.Windows.Automation.PropertyCondition($UIA::AutomationIdProperty, 'view_4')))
if ($close) { Invoke-El $close; Log 'החלון שנפתח להתקנה נסגר' }
Log 'סיום'
