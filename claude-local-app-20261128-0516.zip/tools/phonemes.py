# -*- coding: utf-8 -*-
# בדיקת הגייה ברמת הצליל (לא מילים): מזהה פונמות (IPA) בכל קובץ — כך רואים "baʃ" מול "baʔeʃ", "mənateʁ" מול "menteʁ".
#   <karaoke venv python> -I tools/phonemes.py <wav> [<wav> ...]
import sys, json, warnings, os
warnings.filterwarnings('ignore')
try: sys.stdout.reconfigure(encoding='utf-8')
except Exception: pass
os.environ.setdefault('HF_HUB_DISABLE_XET', '1')
import torch, soundfile as sf, numpy as np
from transformers import Wav2Vec2FeatureExtractor, Wav2Vec2ForCTC
from huggingface_hub import hf_hub_download
MID = 'facebook/wav2vec2-xlsr-53-espeak-cv-ft'
fe = Wav2Vec2FeatureExtractor.from_pretrained(MID); model = Wav2Vec2ForCTC.from_pretrained(MID).eval()
vocab = {v: k for k, v in json.load(open(hf_hub_download(MID, 'vocab.json'), encoding='utf-8')).items()}
def decode(ids):  # CTC: איחוד חזרות + הסרת blank (<pad>)
    s, prev = [], None
    for i in ids:
        if i != prev and vocab.get(i, '') not in ('<pad>', '<s>', '</s>', '<unk>'): s.append(vocab.get(i, ''))
        prev = i
    return ' '.join(s).replace('|', ' ')
class P:  # אותו ממשק כמו Processor
    def __call__(self, x, sampling_rate, return_tensors): return fe(x, sampling_rate=sampling_rate, return_tensors=return_tensors)
    def batch_decode(self, ids): return [decode(r.tolist()) for r in ids]
proc = P()
out = {}
for f in sys.argv[1:]:
    x, sr = sf.read(f, dtype='float32')
    if x.ndim > 1: x = x.mean(1)
    if sr != 16000:
        n = int(len(x) * 16000 / sr); x = np.interp(np.linspace(0, len(x) - 1, n), np.arange(len(x)), x).astype('float32')
    iv = proc(x, sampling_rate=16000, return_tensors='pt').input_values
    with torch.no_grad(): ids = model(iv).logits.argmax(-1)
    out[f] = proc.batch_decode(ids)[0]
print(json.dumps(out, ensure_ascii=False, indent=1))
