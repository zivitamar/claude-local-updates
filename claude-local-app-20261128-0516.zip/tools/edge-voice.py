# A real neural voice (Microsoft Edge read-aloud voices via the edge-tts package) for the sound clips.
# Used by tools/make-voices.js for the female voice (he-IL-HilaNeural). Network is needed only while BUILDING the clips;
# the app ships the finished WAV files, so users need nothing.
#   <voicetools python> edge-voice.py <jobs.json>      jobs = {"voice": "...", "jobs": [{"text": "...", "out": "x.wav"}]}
import sys, json, asyncio, io
import soundfile as sf, edge_tts
spec = json.load(open(sys.argv[1], encoding='utf-8'))
voice = spec.get('voice', 'he-IL-HilaNeural'); rate = spec.get('rate', '+0%')
async def one(j, sem):
    async with sem:
        err = None
        for attempt in range(5):
            try:
                buf = bytearray()
                async for ch in edge_tts.Communicate(j['text'], voice, rate=rate).stream():
                    if ch['type'] == 'audio': buf += ch['data']
                x, sr = sf.read(io.BytesIO(bytes(buf)), dtype='float32')
                if x.ndim > 1: x = x.mean(1)
                sf.write(j['out'], x, sr, subtype='PCM_16'); return True
            except Exception as e:
                err = e; await asyncio.sleep(1.5 * (attempt + 1))
        print('ERR', j['out'], err, flush=True); return False
async def main():
    sem = asyncio.Semaphore(4); r = await asyncio.gather(*[one(j, sem) for j in spec['jobs']])
    print(f'edge {voice}: {sum(r)}/{len(r)}', flush=True)
asyncio.run(main())
