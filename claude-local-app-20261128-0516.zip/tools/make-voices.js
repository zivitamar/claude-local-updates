'use strict';
// ============================================================
//  make-voices.js — יוצר את קבצי הקול של מערכת הצלילים: כל משפט מהקטלוג ב-3 קולות.
//  מנוע: הקול העברי המובנה של Windows (Microsoft Asaf) דרך tools/tts-windows.ps1 — מקומי, בלי להשמיע כלום.
//  עיבוד (כאן, על הדגימות): המרה ל-16kHz · חיתוך שקט מדויק בהתחלה ובסוף · fade קצר · נרמול עוצמה · אפקט רובוט.
//  פלט: public/sounds/voices/<voice>/<key>.wav + public/sounds/voices/manifest.json (משך + שקט שנמדד בקצוות אחרי החיתוך)
//    node tools/make-voices.js [--only=<key,...>]
// ============================================================
const fs = require('fs'), path = require('path'), os = require('os'), { execFileSync } = require('child_process');
const ROOT = path.join(__dirname, '..');
const CAT = require(path.join(ROOT, 'public', 'sound-catalog.js'));
const OUT = path.join(ROOT, 'public', 'sounds', 'voices');
const SR = 16000;
// שלושה קולות שונים באמת: המשפט מוקלט פעם אחת (Asaf), ואת שני האחרים יוצר Praat "Change gender" — מזיז פורמנטים וגובה בנפרד
// (לא רק pitch, שנשמע "אותו גבר מהר"): אישה = פורמנטים ×1.2 וגובה ~220Hz · גבר עמוק = פורמנטים ×0.88, ~90Hz, ואיטי ב-25%
// האישה = קול נשי אמיתי (Microsoft Hila, neural) ולא גבר "מוזז": Praat על Asaf נמדד 0.794 נשיות (91/115) והבעלים שמע גבר;
// Hila: 0.999 בכל 115 (מסווג מגדר wav2vec2). 24kHz כדי לשמור על הצליליות. רשת נדרשת רק בבנייה — הקבצים נשלחים עם האפליקציה.
const VOICES = [
  { id: 'asaf', name: 'גבר', morph: null },
  { id: 'female', name: 'אישה', engine: 'edge', edgeVoice: 'he-IL-HilaNeural', sr: 24000 },
  { id: 'deep', name: 'גבר עמוק ואיטי', morph: { formant: 0.92, pitch: 92, range: 0.9, dur: 1.15 } }
];
// הגייה של Hila (ניקוד בלבד — edge-tts לא מקבל SSML). כל שורה נבדקה בזיהוי פונמות + Whisper:
// בָּאשׁ→bə-eʃ, מנטר→mainter, סקיל→sə-kil, תוכנה→"תחנה", לשרת/ברשת/ללשונית/בתור/בעכבר/לשלב→ תחילית lə/bə, המנוי→ha-manuj
const FEMALE_SAY = {
  'tool:Bash': 'בָּשׁ', 'tool:Monitor': 'מְנָטֵר תהליך', 'tool:Skill': 'מַפְעִיל Skill', 'tool:Grep': 'Grep',
  'cmd:ssh': 'מתחבר אֶל הַשָּׁרָת', 'pc:open': 'פותח אפליקציה', 'chrome:eval': 'מריץ קוד על הדף', 'tool:WebSearch': 'מחפש באינטרנט',
  'chrome:switch': 'עובר לָה לְשׁוֹנִית', 'ev:queued': 'ההודעה בַּתוֹר', 'pc:click': 'לוחץ בָּעַכְבָּר',
  'ev:flow_step': 'התזרים עבר לָה שָׁלָב הַבָּא', 'ev:research_stage': 'המחקר עבר לָה שָׁלָב הַבָּא', 'ev:research_bg': 'המחקר רץ בָּרֶקַע, ממתין לתוצאה',
  'ev:refused': 'קלוד, סירב', /* בלי פסיק: "קלוץ סרב" */ 'ev:flow_done': 'התזרים, הִסְתַּיֵּם' /* בלי פסיק: ה' נבלעת — "מסתיים" */
};
const FEMALE_WORDS = [['המנוי', 'הַמִּנּוּי']];
const femaleText = it => FEMALE_SAY[it.key] || FEMALE_WORDS.reduce((t, [w, r]) => t.replace(new RegExp('(^|[\\s,.])' + w + '(?=[\\s,.]|$)', 'g'), (m, a) => a + r), String(it.phrase));
const MORPH_PY = path.join(process.env.LOCALAPPDATA || os.homedir(), 'ClaudeLocal', 'voicetools-venv', 'Scripts', 'python.exe');
// הגייה מדויקת (נמדדה בזיהוי פונמות — tools/phonemes.py): קטע SSML במקום הטקסט; cutFirst = להשאיר רק את המילה הראשונה
// (מילה בודדת "בָּשׁ" יוצאת עם אף באמצע — "baːnʃ"; בתוך משפט היא "baʃ" נקי, אז מקליטים "בָּשׁ, פקודה" וחותכים)
const SSML_SAY = {
  'tool:Bash': { ssml: 'בָּשׁ, פקודה', cutFirst: true },
  'tool:Monitor': { ssml: '<phoneme alphabet="ipa" ph="mənaˈteʁ">מנטר</phoneme> תהליך' }
};
const only = (process.argv.find(a => a.startsWith('--only=')) || '').slice(7).split(',').filter(Boolean);
const onlyVoices = (process.argv.find(a => a.startsWith('--voices=')) || '').slice(9).split(',').filter(Boolean);
const ROBOT_FX = (process.argv.find(a => a.startsWith('--robot=')) || '--robot=v4').slice(8);
const safe = k => k.replace(/[:]/g, '_');
const xml = s => String(s).replace(/[<>&]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c]));
// איות להגייה בלבד (הטקסט שמוצג נשאר כמו שהוא). כל שורה נבדקה בתמלול (Whisper עברית) — ראה tools/verify-voices.py
const SAY = [ // [מה שכתוב, איך לומר] — הוסף כאן רק אחרי שתמלול הוכיח שהאיות הרגיל נשמע לא נכון
];
const spoken = p => SAY.reduce((s, [a, b]) => s.split(a).join(b), String(p));
// הגייה של מילים בודדות (IPA, מוטעם): נמדד בזיהוי פונמות שהקול אומר אחרת — "לשרת" יצא lə-ʃaʁet, "פייתון" pa-ja-ton,
// "ברשת"/"בדף" bə- (במקום ba- של ה' הידיעה), "המנוי" ha-manuj (= המנוי האדם) במקום ha-minuj (המנוי = subscription)
// ה-IPA של Asaf לא מכיר ʃ (יוצא x: "la-xarat"); ניקוד לבד מקצר את התחילית ל-lə / bə; תג phoneme לתחילית מאריך ל-"laah".
// מה שנמדד נקי בשלושת הקולות (זיהוי פונמות): התחילית כהברה נפרדת עם קמץ — "לָה שָׁרָת" → la-ʃaʁat, "בָּה רֶשֶׁת" → ba-ʁeʃet (בלי הפסקה באמצע)
const PH = (ph, t) => `<phoneme alphabet="ipa" ph="${ph}">${t}</phoneme>`;
const IPA_WORDS = [
  ['לשרת', 'לָה שָׁרָת'], ['ברשת', 'בָּה רֶשֶׁת'], ['ללשונית', 'לָה לְשׁוֹנִית'], ['לחלון', 'לַחַלּוֹן'], ['בתור', PH('baˈtoʁ', 'בתור')],
  ['פַּייתוֹן', PH('ˈpajton', 'פייתון')], ['פייתון', PH('ˈpajton', 'פייתון')], ['בדף', PH('baˈdaf', 'בדף')], ['המנוי', PH('haminuˈi', 'המנוי')]
];
// מחליף מילה שלמה (רק כשהמילה עומדת לבד: לא "מהרשת" / "הרשת")
const ipaWords = s => IPA_WORDS.reduce((t, [w, rep]) => t.replace(new RegExp('(^|[\\s,.])(' + w + ')(?=[\\s,.]|$)', 'g'), (m, a) => a + rep), s);

// ---------- WAV ----------
function readWav(buf) {
  if (buf.toString('ascii', 0, 4) !== 'RIFF') throw new Error('not RIFF');
  let p = 12, fmt = null, data = null;
  while (p + 8 <= buf.length) { const id = buf.toString('ascii', p, p + 4), n = buf.readUInt32LE(p + 4); if (id === 'fmt ') fmt = { ch: buf.readUInt16LE(p + 10), sr: buf.readUInt32LE(p + 12), bits: buf.readUInt16LE(p + 22) }; if (id === 'data') data = buf.subarray(p + 8, p + 8 + n); p += 8 + n + (n & 1); }
  if (!fmt || !data || fmt.bits !== 16) throw new Error('unsupported wav');
  const n = data.length / 2 / fmt.ch, x = new Float32Array(n);
  for (let i = 0; i < n; i++) { let s = 0; for (let c = 0; c < fmt.ch; c++) s += data.readInt16LE((i * fmt.ch + c) * 2); x[i] = s / fmt.ch / 32768; }
  return { sr: fmt.sr, x };
}
function writeWav(x, sr) {
  const b = Buffer.alloc(44 + x.length * 2);
  b.write('RIFF', 0); b.writeUInt32LE(36 + x.length * 2, 4); b.write('WAVEfmt ', 8); b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20); b.writeUInt16LE(1, 22);
  b.writeUInt32LE(sr, 24); b.writeUInt32LE(sr * 2, 28); b.writeUInt16LE(2, 32); b.writeUInt16LE(16, 34); b.write('data', 36); b.writeUInt32LE(x.length * 2, 40);
  for (let i = 0; i < x.length; i++) b.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round(x[i] * 32767))), 44 + i * 2);
  return b;
}
function resample(x, from, to) {
  if (from === to) return x;
  // מסנן נמוך פשוט לפני דילול (ממוצע נע) + אינטרפולציה לינארית
  let y = x; if (to < from) { const k = Math.max(1, Math.round(from / to)); y = new Float32Array(x.length); let acc = 0; for (let i = 0; i < x.length; i++) { acc += x[i]; if (i >= k) acc -= x[i - k]; y[i] = acc / Math.min(i + 1, k); } }
  const n = Math.floor(y.length * to / from), out = new Float32Array(n);
  for (let i = 0; i < n; i++) { const t = i * from / to, i0 = Math.floor(t), f = t - i0; out[i] = (y[i0] || 0) * (1 - f) + (y[i0 + 1] || 0) * f; }
  return out;
}
// ---------- חיתוך מדויק ----------
// חלונות של 5ms — בכל קצב דגימה (Asaf/עמוק 16kHz, האישה 24kHz)
function envelope(x, sr = SR) { const WIN = Math.round(sr * 0.005), n = Math.ceil(x.length / WIN), e = new Float32Array(n); for (let w = 0; w < n; w++) { let s = 0, c = 0; for (let i = w * WIN; i < Math.min(x.length, (w + 1) * WIN); i++) { s += x[i] * x[i]; c++; } e[w] = Math.sqrt(s / Math.max(1, c)); } return e; }
const db = v => 20 * Math.log10(Math.max(v, 1e-9));
function trim(x, SR = 16000) {
  const WIN = Math.round(SR * 0.005);
  const e = envelope(x, SR); let peak = 0; for (const v of e) if (v > peak) peak = v;
  const thr = Math.max(Math.pow(10, -46 / 20), peak * Math.pow(10, -34 / 20)); // מעל רצפת הרעש: -46dBFS או 34dB מתחת לשיא
  // הסוף: סף נמוך יותר — עיצור סופי (ט, ת, ף, ס) הוא "פיצוץ" חלש אחרי רגע של שקט, ואסור לחתוך אותו
  // (בסף הרגיל "גיט" נחתך ל"גיי" ו"מרחף" ל"מרחב" — נמדד בתמלול)
  // (וב-52/44 עדיין נחתך "ל" סופי: "מפעיל סְקִיל" יצא "…סקי" — נמדד בזיהוי פונמות; לכן 56/50 ו-70ms זנב)
  const thrEnd = Math.max(Math.pow(10, -56 / 20), peak * Math.pow(10, -50 / 20));
  let a = 0, b = e.length - 1; while (a < e.length && e[a] < thr) a++; while (b > a && e[b] < thrEnd) b--;
  const s0 = Math.max(0, a * WIN - Math.round(SR * 0.008)), s1 = Math.min(x.length, (b + 1) * WIN + Math.round(SR * 0.07));
  const y = x.slice(s0, s1);
  const fi = Math.round(SR * 0.004), fo = Math.round(SR * 0.012);
  for (let i = 0; i < fi && i < y.length; i++) y[i] *= i / fi;
  for (let i = 0; i < fo && i < y.length; i++) y[y.length - 1 - i] *= i / fo;
  return { y, thr };
}
function normalize(y, peakDb = -1) { let m = 0; for (const v of y) m = Math.max(m, Math.abs(v)); const g = m ? Math.pow(10, peakDb / 20) / m : 1; for (let i = 0; i < y.length; i++) y[i] *= g; return y; }
// אפקט רובוט. v1 = אפנון טבעתי עמוק + ביט-קראש (רובוטי מאוד, אבל רק 90/106 מילים נשמעו נכון).
// v2/v3 = פחות עיוות: צליל מתכתי (מסנן מסרק 5ms) + אפנון קל — נשאר רובוטי, והמילים ברורות.
function robotize(x, fx = ROBOT_FX) {
  const y = new Float32Array(x.length), f = 62, d = Math.round(SR * 0.005);
  for (let i = 0; i < x.length; i++) {
    const r = Math.sin(2 * Math.PI * f * i / SR); let v;
    if (fx === 'v1') { v = 0.3 * x[i] + 0.85 * x[i] * r; v = Math.round(v * 48) / 48; }
    else if (fx === 'v2') { v = 0.6 * x[i] + 0.5 * x[i] * r; v = Math.round(v * 96) / 96; }
    else if (fx === 'v4') { const c = x[i] + 0.4 * (x[i - d] || 0); v = 0.8 * c + 0.25 * c * r; }
    else { const c = x[i] + 0.55 * (x[i - d] || 0); v = 0.7 * c + 0.35 * c * r; }
    y[i] = v;
  }
  return y;
}
// שקט שנשאר בקצוות אחרי החיתוך (ms) — ההוכחה שהחיתוך מדויק
// מדידה לפי דגימה בודדת: מתי הדגימה הראשונה/האחרונה שעוברת את סף החיתוך
function edges(y, thr, sr = SR) { let a = 0, b = y.length - 1; while (a < y.length && Math.abs(y[a]) < thr) a++; while (b > a && Math.abs(y[b]) < thr) b--; return { lead: Math.round(a / sr * 1000), tail: Math.round((y.length - 1 - b) / sr * 1000) }; }

// מילה ראשונה בלבד: עד הפער השקט הראשון (≥60ms) אחרי תחילת הדיבור
function cutFirst(x, sr) {
  const W = Math.round(sr * 0.005), n = Math.ceil(x.length / W), e = new Float32Array(n);
  for (let w = 0; w < n; w++) { let s = 0, c = 0; for (let i = w * W; i < Math.min(x.length, (w + 1) * W); i++) { s += x[i] * x[i]; c++; } e[w] = Math.sqrt(s / Math.max(1, c)); }
  const peak = Math.max(...e), thr = peak * Math.pow(10, -40 / 20); let a = 0; while (a < n && e[a] < thr) a++;
  const need = Math.round(0.06 / 0.005); let run = 0;
  for (let w = a + Math.round(0.12 / 0.005); w < n; w++) { if (e[w] < thr) { if (++run >= need) return x.slice(0, Math.min(x.length, (w - need + 1) * W + Math.round(sr * 0.03))); } else run = 0; }
  return x;
}

(async () => {
  const items = [...CAT.EVENTS.map(e => ({ key: e.key, phrase: e.phrase })), ...Object.entries(CAT.EXTRA_PHRASES).map(([key, phrase]) => ({ key, phrase }))].filter(i => !only.length || only.includes(i.key));
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'voices-'));
  // 1) כל משפט מוקלט פעם אחת בקול הבסיס (Asaf), עם ההגייה המדויקת
  const base = items.map(it => {
    const sp = SSML_SAY[it.key];
    const inner = sp ? sp.ssml : ipaWords(xml(spoken(it.phrase)));
    return { ssml: `<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='he-IL'>${inner}</speak>`, out: path.join(tmp, 'base__' + safe(it.key) + '.wav'), item: it, cut: !!(sp && sp.cutFirst) };
  });
  const jobFile = path.join(tmp, 'jobs.json');
  fs.writeFileSync(jobFile, JSON.stringify(base.map(j => ({ ssml: j.ssml, out: j.out }))), 'utf8');
  const t0 = Date.now();
  const res = execFileSync('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(__dirname, 'tts-windows.ps1'), '-JobFile', jobFile], { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024, windowsHide: true, timeout: 600000 });
  const errs = res.split('\n').filter(l => /^ERR/.test(l)); if (errs.length) console.log(errs.join('\n'));
  console.log(`synthesized ${base.length - errs.length}/${base.length} in ${((Date.now() - t0) / 1000).toFixed(1)}s`);
  // הבסיס נחתך כבר כאן (16kHz, חיתוך מדויק) — כך Praat מעבד רק את הדיבור ולא "ממציא" זנב רעש בשקט שאחריו (נמדד: זנב עד 950ms)
  for (const b of base) {
    if (!fs.existsSync(b.out)) continue;
    const w = readWav(fs.readFileSync(b.out)); let x = b.cut ? cutFirst(w.x, w.sr) : w.x; // "בָּשׁ, פקודה" → "בָּשׁ"
    x = resample(x, w.sr, SR);
    if (process.env.KEEP_RAW) { fs.mkdirSync(process.env.KEEP_RAW, { recursive: true }); fs.writeFileSync(path.join(process.env.KEEP_RAW, safe(b.item.key) + '.wav'), writeWav(x, SR)); } // לבדיקה: לפני החיתוך
    const { y } = trim(x);
    const pad = new Float32Array(y.length + Math.round(SR * 0.02)); pad.set(y, 0);
    fs.writeFileSync(b.out, writeWav(pad, SR));
  }
  // 2) הקולות האחרים: Praat "Change gender" מהקלטת הבסיס (תהליך אחד לכולם)
  const jobs = [];
  const wantVoices = VOICES.filter(v => !onlyVoices.length || onlyVoices.includes(v.id));
  const morphJobs = [], edgeJobs = {};
  for (const v of wantVoices) for (const b of base) {
    if (v.engine === 'edge') { // קול נוירוני אמיתי (האישה) — מהטקסט, לא מהקלטת הבסיס
      const out = path.join(tmp, v.id + '__' + safe(b.item.key) + '.wav');
      (edgeJobs[v.id] = edgeJobs[v.id] || { voice: v.edgeVoice, jobs: [] }).jobs.push({ text: femaleText(b.item), out });
      jobs.push({ out, voice: v, item: b.item }); continue;
    }
    const out = v.morph ? path.join(tmp, v.id + '__' + safe(b.item.key) + '.wav') : b.out;
    if (v.morph) morphJobs.push({ in: b.out, out, ...v.morph });
    jobs.push({ out, voice: v, item: b.item });
  }
  if (morphJobs.length) {
    const mf = path.join(tmp, 'morph.json'); fs.writeFileSync(mf, JSON.stringify(morphJobs), 'utf8');
    const t1 = Date.now();
    const r2 = execFileSync(MORPH_PY, ['-I', path.join(__dirname, 'voice-morph.py'), mf], { encoding: 'utf8', maxBuffer: 16 * 1024 * 1024, windowsHide: true, timeout: 900000 });
    console.log(r2.trim().split('\n').slice(-3).join('\n'), `(${((Date.now() - t1) / 1000).toFixed(1)}s)`);
  }
  for (const [vid, spec] of Object.entries(edgeJobs)) {
    const f = path.join(tmp, 'edge-' + vid + '.json'); fs.writeFileSync(f, JSON.stringify(spec), 'utf8');
    const t2 = Date.now();
    const r3 = execFileSync(MORPH_PY, ['-I', path.join(__dirname, 'edge-voice.py'), f], { encoding: 'utf8', maxBuffer: 16 * 1024 * 1024, windowsHide: true, timeout: 900000 });
    console.log(r3.trim().split('\n').slice(-4).join('\n'), `(${((Date.now() - t2) / 1000).toFixed(1)}s)`);
  }
  let manifest = { voices: [], clips: {} }; try { manifest = JSON.parse(fs.readFileSync(path.join(OUT, 'manifest.json'), 'utf8')); } catch { }
  manifest.generatedAt = new Date().toISOString(); manifest.sampleRate = SR; manifest.engine = 'גבר: Windows OneCore Microsoft Asaf (he-IL) · אישה: Microsoft Hila neural (he-IL-HilaNeural) · גבר עמוק: Asaf + Praat Change gender';
  manifest.voices = VOICES.map(v => ({ id: v.id, name: v.name }));
  for (const old of ['high', 'robot']) if (manifest.clips[old] && !VOICES.some(v => v.id === old)) { try { fs.rmSync(path.join(OUT, old), { recursive: true, force: true }); } catch { } delete manifest.clips[old]; }
  let worstLead = 0, worstTail = 0, n = 0;
  for (const j of jobs) {
    if (!fs.existsSync(j.out)) continue;
    const w = readWav(fs.readFileSync(j.out)), osr = j.voice.sr || SR; // כל קול בקצב שלו (האישה 24kHz)
    let x = resample(w.x, w.sr, osr);
    const { y, thr } = trim(x, osr);
    const ed = edges(y, thr, osr); // נמדד לפני הנרמול, באותו סף של החיתוך
    normalize(y, -1);
    const dir = path.join(OUT, j.voice.id); fs.mkdirSync(dir, { recursive: true });
    const file = safe(j.item.key) + '.wav';
    fs.writeFileSync(path.join(dir, file), writeWav(y, osr));
    worstLead = Math.max(worstLead, ed.lead); worstTail = Math.max(worstTail, ed.tail); n++;
    (manifest.clips[j.voice.id] = manifest.clips[j.voice.id] || {})[j.item.key] = { file: j.voice.id + '/' + file, dur: +(y.length / osr).toFixed(3), lead: ed.lead, tail: ed.tail, phrase: j.item.phrase, srcSr: w.sr, sr: osr };
  }
  // מפתחות שכבר לא בקטלוג — נמחקים מהמניפסט ומהדיסק (רק בהרצה מלאה)
  if (!only.length) { const live = new Set(items.map(i => i.key)); for (const v of Object.keys(manifest.clips)) for (const k of Object.keys(manifest.clips[v])) if (!live.has(k)) { try { fs.unlinkSync(path.join(OUT, manifest.clips[v][k].file)); } catch { } delete manifest.clips[v][k]; console.log('pruned', v, k); } }
  fs.writeFileSync(path.join(OUT, 'manifest.json'), JSON.stringify(manifest, null, 1));
  fs.rmSync(tmp, { recursive: true, force: true });
  console.log(`wrote ${n} clips · worst leading silence ${worstLead}ms · worst trailing ${worstTail}ms → ${OUT}`);
})();
