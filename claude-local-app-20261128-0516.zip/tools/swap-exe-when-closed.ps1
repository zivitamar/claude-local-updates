# Replaces the owner's EXE folder (Dst) with the new build (Src) ONLY after he closes the app.
# It never closes or starts anything by itself. Keeps a backup in "<Dst>.bak". Log: %LOCALAPPDATA%\ClaudeLocalBuild\swap-exe.log
# (ASCII only on purpose: Windows PowerShell 5.1 reads a BOM-less .ps1 as ANSI.)
#   powershell -NoProfile -ExecutionPolicy Bypass -File swap-exe-when-closed.ps1 -Src <out\Claude Local-win32-x64> -Dst <dist\Claude Local-win32-x64>
param([Parameter(Mandatory)][string]$Src, [Parameter(Mandatory)][string]$Dst)
$log = Join-Path $env:LOCALAPPDATA 'ClaudeLocalBuild\swap-exe.log'
function Write-Log($m) { "$(Get-Date -Format s) $m" | Out-File -FilePath $log -Append -Encoding utf8 }
Write-Log "waiting for the app to close: $Dst"
$dstExe = Join-Path $Dst 'Claude Local.exe'
while ($true) {
  $busy = @(Get-Process -Name 'Claude Local' -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $dstExe })
  if ($busy.Count -eq 0) { break }
  Start-Sleep -Seconds 5
}
Start-Sleep -Seconds 3
# integrity check before swapping: the essential files must exist in the new build
foreach ($f in 'Claude Local.exe', 'resources\app.asar', 'chrome_100_percent.pak', 'chrome_200_percent.pak', 'icudtl.dat', 'resources.pak') {
  if (-not (Test-Path (Join-Path $Src $f))) { Write-Log "ABORT: missing $f in $Src"; exit 1 }
}
$bak = "$Dst.bak"
if (Test-Path $bak) { Remove-Item $bak -Recurse -Force }
Copy-Item $Dst $bak -Recurse -Force
robocopy $Src $Dst /MIR /XF debug.log /R:5 /W:2 /NFL /NDL /NP | Out-File -FilePath $log -Append -Encoding utf8
$rc = $LASTEXITCODE
if ($rc -ge 8) { Write-Log "robocopy failed ($rc) - restoring the backup"; robocopy $bak $Dst /MIR /R:5 /W:2 /NFL /NDL /NP | Out-Null; exit 1 }
Write-Log "SWAPPED ok (robocopy $rc); backup: $bak"
