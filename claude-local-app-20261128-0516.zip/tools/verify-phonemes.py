# -*- coding: utf-8 -*-
# בדיקת כל ההקלטות ברמת הפונמות (בלי לשמוע): לכל משפט — ההקלטה המקורית לפני חיתוך מול כל אחד מ-3 הקולות הסופיים.
#   * סוף שלם: הפונמה האחרונה (עיצור/תנועה) של המקור קיימת גם בסוף הקובץ הסופי (לא נחתכה)
#   * דמיון: כמה רצף הפונמות של הקול הסופי דומה למקור (אישה / גבר עמוק עוברים שינוי — צריכים להישאר מובנים)
#   <karaoke venv python> -I tools/verify-phonemes.py <raw_dir> <voices_dir> <out.json>
import sys, os, json, difflib, warnings
warnings.filterwarnings('ignore')
try: sys.stdout.reconfigure(encoding='utf-8')
except Exception: pass
os.environ.setdefault('HF_HUB_DISABLE_XET', '1')
import torch, soundfile as sf, numpy as np
from transformers import Wav2Vec2FeatureExtractor, Wav2Vec2ForCTC
from huggingface_hub import hf_hub_download
MID = 'facebook/wav2vec2-xlsr-53-espeak-cv-ft'
fe = Wav2Vec2FeatureExtractor.from_pretrained(MID); model = Wav2Vec2ForCTC.from_pretrained(MID).eval()
vocab = {v: k for k, v in json.load(open(hf_hub_download(MID, 'vocab.json'), encoding='utf-8')).items()}
def ph(f):
    x, sr = sf.read(f, dtype='float32')
    if x.ndim > 1: x = x.mean(1)
    if sr != 16000: n = int(len(x) * 16000 / sr); x = np.interp(np.linspace(0, len(x) - 1, n), np.arange(len(x)), x).astype('float32')
    # שקט של 0.4 שנ' בשני הצדדים — למזהה צריך הקשר אחרי הפונמה האחרונה (בלי זה הוא "מפספס" עיצור סופי גם כשהוא קיים)
    pad = np.zeros(6400, dtype='float32'); x = np.concatenate([pad, x, pad])
    with torch.no_grad(): ids = model(fe(x, sampling_rate=16000, return_tensors='pt').input_values).logits.argmax(-1)[0].tolist()
    s, prev = [], None
    for i in ids:
        t = vocab.get(i, '')
        if i != prev and t not in ('<pad>', '<s>', '</s>', '<unk>', '|'): s.append(t.replace('ː', ''))
        prev = i
    return s
# קבוצות קרובות (המזהה מתבלבל בין ר/ל, ב/ו, ח/כ — לא בעיה בהקלטה)
CL = {'ʁ': 'r', 'l': 'r', 'r': 'r', 'v': 'b', 'b': 'b', 'x': 'h', 'χ': 'h', 'h': 'h', 'ɛ': 'e', 'e': 'e', 'ə': 'e', 'ɪ': 'i', 'i': 'i', 'ɑ': 'a', 'a': 'a', 'ɔ': 'o', 'o': 'o', 'ʊ': 'u', 'u': 'u'}
norm = lambda s: [CL.get(p, p) for p in s]
raw_dir, vdir, out = sys.argv[1], sys.argv[2], sys.argv[3]
rows = []
for f in sorted(os.listdir(raw_dir)):
    if not f.endswith('.wav'): continue
    ref = norm(ph(os.path.join(raw_dir, f)))
    for v in ('asaf', 'female', 'deep'):
        p = os.path.join(vdir, v, f)
        if not os.path.exists(p): continue
        got = norm(ph(p))
        sim = difflib.SequenceMatcher(None, ref, got).ratio()
        end_ok = bool(ref) and bool(got) and ref[-1] in got[-2:]
        rows.append({'key': f[:-4], 'voice': v, 'ref': ' '.join(ref), 'got': ' '.join(got), 'sim': round(sim, 2), 'end_ok': end_ok})
json.dump(rows, open(out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
bad = [r for r in rows if not r['end_ok'] or r['sim'] < 0.6]
print('clips', len(rows), 'end_ok', sum(r['end_ok'] for r in rows), 'sim>=0.6', sum(r['sim'] >= 0.6 for r in rows), 'flagged', len(bad))
for r in bad[:40]: print(r['voice'], r['key'], r['sim'], 'END-OK' if r['end_ok'] else 'END-CUT', '| ref:', r['ref'], '| got:', r['got'])
