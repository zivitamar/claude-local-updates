# -*- coding: utf-8 -*-
# שינוי קול אמיתי (לא רק גובה): Praat "Change gender" — מזיז את הפורמנטים (צבע הקול / גודל מיתרי הקול) ואת גובה הצליל בנפרד,
# כך שאישה נשמעת אישה (ולא "גבר מהיר"), והגבר העמוק נשמע אדם אחר, איטי יותר.
#   <voicetools venv python> -I tools/voice-morph.py <jobs.json>
#   jobs.json = [{ "in": "...wav", "out": "...wav", "formant": 1.2, "pitch": 220, "range": 1.1, "dur": 1.0 }, ...]
import sys, json
import parselmouth
from parselmouth.praat import call
jobs = json.load(open(sys.argv[1], encoding='utf-8'))
ok = 0
for j in jobs:
    try:
        s = parselmouth.Sound(j['in'])
        # Change gender: min pitch, max pitch (לניתוח), יחס פורמנטים, חציון גובה חדש, פקטור טווח, פקטור משך
        out = call(s, 'Change gender', 75, 600, float(j['formant']), float(j['pitch']), float(j.get('range', 1.0)), float(j.get('dur', 1.0)))
        call(out, 'Scale peak', 0.95)  # בלי קיטום דגימות
        out.save(j['out'], 'WAV'); ok += 1
    except Exception as e:
        print('ERR', j['out'], e, flush=True)
print('morphed', ok, 'of', len(jobs), flush=True)
