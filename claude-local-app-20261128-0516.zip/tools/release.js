'use strict';
// ============================================================
//  tools/release.js — גרסה חדשה לכל ההתקנות (REQUESTS-8 ד):
//   1. קוד האפליקציה (stage של build.js, בלי docs / בדיקות / נתונים) → claude-local-app-<build>.zip
//   2. ה-APK (release, חתום במפתח הקבוע של האפליקציה) → claude-local-<build>.apk
//   3. manifest.json עם sha256 של כל קובץ, חתום ed25519 (המפתח הפרטי רק ב-%USERPROFILE%\.secrets — לא ב-git)
//   4. --publish: GitHub Release בריפו הציבורי של העדכונים (latest) — כל ההתקנות בעולם מושכות משם
//  דגלים: --publish · --no-apk · --notes "…" · --build 20261125-0130 · --feed-dir <תיקייה> (בדיקות: "GitHub" מקומי)
// ============================================================
const fs = require('fs'), path = require('path'), os = require('os'), cp = require('child_process'), crypto = require('crypto');
const { signManifest, verifyManifest } = require('../updater');
const ROOT = path.resolve(__dirname, '..');
const ANDROID = process.env.CL_ANDROID || 'D:\\code\\claude-local-android';
const REPO = process.env.CLAUDE_UPDATES_REPO || 'zivitamar/claude-local-updates';
const SECRETS = path.join(os.homedir(), '.secrets');
const ARGS = process.argv.slice(2), arg = k => { const i = ARGS.indexOf(k); return i >= 0 ? ARGS[i + 1] : null; };
const log = (...a) => console.log('[release]', ...a);
const die = m => { console.error('[release] ✖ ' + m); process.exit(1); };
const stamp = () => { const d = new Date(), p = n => String(n).padStart(2, '0'); return `${d.getUTCFullYear()}${p(d.getUTCMonth() + 1)}${p(d.getUTCDate())}-${p(d.getUTCHours())}${p(d.getUTCMinutes())}`; };
const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
// APK versionCode grows with the build stamp: minutes since 2026-01-01
const versionCodeOf = b => { const m = /^(\d{4})(\d{2})(\d{2})-(\d{2})(\d{2})/.exec(b); return Math.floor((Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5]) - Date.UTC(2026, 0, 1)) / 60000); };

// never inherit a hook's GIT_DIR: every git command here names its own repository (-C) and must act on THAT one
for (const k of Object.keys(process.env)) if (/^GIT_(DIR|WORK_TREE|INDEX_FILE|PREFIX|COMMON_DIR|OBJECT_DIRECTORY|ALTERNATE_OBJECT_DIRECTORIES|NAMESPACE|QUARANTINE_PATH)$/.test(k)) delete process.env[k];
function run(cmd, args, opts = {}) { const r = cp.spawnSync(cmd, args, { stdio: 'inherit', windowsHide: true, ...opts }); if (r.status !== 0) die(cmd + ' ' + args.join(' ') + ' → exit ' + r.status); }

(async () => {
  const build = arg('--build') || stamp();
  const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  const OUT = path.join(process.env.CLAUDE_BUILD_HOME || path.join(process.env.LOCALAPPDATA || os.homedir(), 'ClaudeLocalBuild'), 'release', build);
  fs.rmSync(OUT, { recursive: true, force: true }); fs.mkdirSync(OUT, { recursive: true });
  log('build', build, '→', OUT);

  // 1. the app code
  run(process.execPath, [path.join(ROOT, 'electron', 'build.js'), '--stage-only'], { env: { ...process.env, CLAUDE_BUILT_AT: build } });
  const STAGE = path.join(process.env.CLAUDE_BUILD_HOME || path.join(process.env.LOCALAPPDATA || os.homedir(), 'ClaudeLocalBuild'), 'stage');
  if (fs.existsSync(path.join(STAGE, 'docs'))) die('docs/ must not ship (personal network notes)');
  // הבעלים 27/11: גרסה שבורה לא מתפרסמת לעולם. (א) אותה בדיקה שהמעדכן עושה במחשבים; (ב) השרת באמת עולה מהחבילה ועונה
  { const bad = require('../updater').verifyPackage(STAGE); if (bad.length) die('BROKEN package, not published:\n  ' + bad.join('\n  ')); }
  {
    const tmpData = fs.mkdtempSync(path.join(os.tmpdir(), 'rel-boot-'));
    const probe = `const S=require(${JSON.stringify(path.join(STAGE, 'server.js'))});S.startServer(0,'127.0.0.1').then(async s=>{const p=s.address().port;const r=await fetch('http://127.0.0.1:'+p+'/api/config');console.log('BOOT-OK',p,r.status);process.exit(r.ok?0:3)}).catch(e=>{console.error('BOOT-FAIL',e&&e.stack||e);process.exit(2)});setTimeout(()=>{console.error('BOOT-TIMEOUT');process.exit(4)},45000);`;
    const r = cp.spawnSync(process.execPath, ['-e', probe], { cwd: STAGE, env: { ...process.env, DATA_DIR: tmpData, NO_BROWSER: '1', CLAUDE_UPDATES: 'off', CLAUDE_NO_MESH: '1' }, encoding: 'utf8', timeout: 60000, windowsHide: true });
    try { fs.rmSync(tmpData, { recursive: true, force: true }); } catch { }
    if (r.status !== 0) die('BROKEN package: the server does not start from it — not published\n' + String(r.stderr || '').slice(-2500) + String(r.stdout || '').slice(-800));
    log('boot test: the server starts from the package and answers (' + String(r.stdout).trim().split('\n').pop() + ')');
  }
  const appFile = `claude-local-app-${build}.zip`;
  if (process.platform === 'win32') run(path.join(process.env.SystemRoot || 'C:/Windows', 'System32', 'tar.exe'), ['-a', '-c', '-f', path.join(OUT, appFile), '-C', STAGE, '.']);
  else run('zip', ['-qr', path.join(OUT, appFile), '.'], { cwd: STAGE }); // GitHub Actions (ubuntu)
  const manifest = { schema: 1, product: 'Claude Local', version: pkg.version, build, publishedAt: new Date().toISOString(), notes: arg('--notes') || '', app: { file: appFile, sha256: sha(path.join(OUT, appFile)), size: fs.statSync(path.join(OUT, appFile)).size } };

  // 2. the APK (same release, same key every time)
  // the Android app did not change (CI: the android/ pointer is the same) → the APK of the current feed goes on unchanged
  if (ARGS.includes('--reuse-apk')) {
    const U = require('../updater'); const feed = process.env.CLAUDE_UPDATES_URL || U.DEFAULT_FEED;
    try {
      const cur = JSON.parse((await U.get(feed + 'manifest.json?t=' + Date.now(), { maxBytes: 1e6 })).buf.toString('utf8'));
      if (cur.apk && verifyManifest(cur)) { const r = await U.get(feed + cur.apk.file, { toFile: path.join(OUT, cur.apk.file) }); if (r.sha256 === cur.apk.sha256) { manifest.apk = cur.apk; log('APK reused from the feed:', cur.apk.versionName); } }
    } catch (e) { log('no APK to reuse (' + e.message + ') — building it'); }
  }
  if (!ARGS.includes('--no-apk') && !manifest.apk) {
    const ks = JSON.parse(fs.readFileSync(path.join(SECRETS, 'claude-local-android.json'), 'utf8'));
    const vc = versionCodeOf(build), vn = pkg.version + '+' + build;
    const gradle = process.platform === 'win32' ? ['cmd.exe', ['/c', path.join(ANDROID, 'gradlew.bat')]] : ['bash', [path.join(ANDROID, 'gradlew')]];
    run(gradle[0], [...gradle[1], ':app:assembleRelease', '--console=plain', '-q'], { cwd: ANDROID, env: { ...process.env, JAVA_HOME: process.env.JAVA_HOME || 'D:\\AndroidStudio\\jbr', CL_VERSION_CODE: String(vc), CL_VERSION_NAME: vn, CL_KEYSTORE: path.join(SECRETS, 'claude-local-android.jks'), CL_KEYSTORE_PASS: ks.storePass, CL_KEY_ALIAS: ks.alias, CL_KEY_PASS: ks.keyPass } });
    const apkSrc = path.join(ANDROID, 'app', 'build', 'outputs', 'apk', 'release', 'app-release.apk');
    if (!fs.existsSync(apkSrc)) die('release APK missing: ' + apkSrc);
    const apkFile = `claude-local-${build}.apk`; fs.copyFileSync(apkSrc, path.join(OUT, apkFile));
    manifest.apk = { file: apkFile, sha256: sha(path.join(OUT, apkFile)), size: fs.statSync(path.join(OUT, apkFile)).size, versionCode: vc, versionName: vn };
  }

  // 3. sign
  const key = process.env.CLAUDE_UPDATE_KEY_FILE || path.join(SECRETS, 'claude-local-update-ed25519.pem');
  const signed = signManifest(manifest, fs.readFileSync(key, 'utf8'));
  if (!verifyManifest(signed)) die('the signature does not verify with the public key inside updater.js');
  fs.writeFileSync(path.join(OUT, 'manifest.json'), JSON.stringify(signed, null, 2));
  log('manifest signed ✓', JSON.stringify({ build, app: manifest.app.size, apk: manifest.apk && manifest.apk.size }));

  // 4. where it goes
  const feedDir = arg('--feed-dir');
  if (feedDir) { fs.mkdirSync(feedDir, { recursive: true }); for (const f of fs.readdirSync(OUT)) fs.copyFileSync(path.join(OUT, f), path.join(feedDir, f)); log('feed dir:', feedDir); }
  if (ARGS.includes('--publish')) {
    // a) the feed every installation reads: branch "feed" = ONLY the latest release (one orphan commit, force-pushed —
    //    the public repo stays small); served by raw.githubusercontent.com
    const HOME = process.env.CLAUDE_BUILD_HOME || path.join(process.env.LOCALAPPDATA || os.homedir(), 'ClaudeLocalBuild');
    // core.autocrlf off: the files go up byte for byte; and the push must land in the UPDATES repo, nowhere else
    const repoDir = path.join(HOME, 'feed-repo'); const git = (...a) => run('git', ['-C', repoDir, '-c', 'core.autocrlf=false', ...a]);
    const top = () => cp.spawnSync('git', ['-C', repoDir, 'rev-parse', '--show-toplevel'], { encoding: 'utf8', windowsHide: true }).stdout.trim();
    const viaSsh = !!process.env.FEED_SSH_KEY; if (viaSsh) process.env.GIT_SSH_COMMAND = `ssh -i "${process.env.FEED_SSH_KEY}" -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new`;
    if (!fs.existsSync(path.join(repoDir, '.git'))) run('git', ['clone', '-q', '--depth', '1', viaSsh ? `git@github.com:${REPO}.git` : `https://github.com/${REPO}.git`, repoDir]);
    const origin = cp.spawnSync('git', ['-C', repoDir, 'remote', 'get-url', 'origin'], { encoding: 'utf8', windowsHide: true }).stdout.trim();
    if (path.resolve(top()) !== path.resolve(repoDir) || !origin.includes(REPO)) die(`the feed checkout is not ${REPO} (${top()} → ${origin}) — nothing pushed`);
    git('fetch', '-q', 'origin'); git('checkout', '-q', '--orphan', 'feed-' + build);
    cp.spawnSync('git', ['-C', repoDir, 'rm', '-rq', '--cached', '.'], { stdio: 'ignore', windowsHide: true }); // an empty index is fine
    for (const f of fs.readdirSync(repoDir)) if (f !== '.git') fs.rmSync(path.join(repoDir, f), { recursive: true, force: true });
    for (const f of fs.readdirSync(OUT)) fs.copyFileSync(path.join(OUT, f), path.join(repoDir, f));
    if (manifest.apk) fs.copyFileSync(path.join(OUT, manifest.apk.file), path.join(repoDir, 'claude-local.apk')); // a stable name to download the app the first time
    git('add', '-A'); git('-c', 'user.name=Claude Local release', '-c', 'user.email=release@claude-local.invalid', 'commit', '-q', '-m', `release ${build}`);
    git('push', '-q', '-f', 'origin', `feed-${build}:feed`);
    log('feed: https://raw.githubusercontent.com/' + REPO + '/feed/manifest.json');
    if (ARGS.includes('--ci')) { console.log(JSON.stringify({ build, out: OUT, manifest: signed })); return; }
    // b) a GitHub Release too — a page to download the app / the APK by hand (first install)
    const gh = fs.existsSync('C:\\Program Files\\GitHub CLI\\gh.exe') ? 'C:\\Program Files\\GitHub CLI\\gh.exe' : 'gh';
    const files = fs.readdirSync(OUT).map(f => path.join(OUT, f)); if (manifest.apk) files.push(path.join(repoDir, 'claude-local.apk'));
    run(gh, ['release', 'create', 'v' + build, ...files, '--repo', REPO, '--title', `Claude Local ${pkg.version}+${build}`, '--notes', manifest.notes || ('גרסה ' + build), '--latest']);
    log('published: https://github.com/' + REPO + '/releases/tag/v' + build);
  }
  console.log(JSON.stringify({ build, out: OUT, manifest: signed }));
})().catch(e => die(e.stack || e.message));
