'use strict';
// ============================================================
//  tools/ship-after-push.js — "עדכון ב-git = כל ההתקנות מתעדכנות" (REQUESTS-8 ד).
//  ה-hook pre-push של המאגר מפעיל אותו ברקע כשדוחפים את main. הוא:
//   1. מחכה שהדחיפה הצליחה (origin/main ב-GitHub == ה-commit שנדחף)
//   2. בונה גרסה חתומה (tools/release.js) — ה-APK נבנה רק אם android/ השתנה מאז הגרסה הקודמת, אחרת עובר כמו שהוא
//   3. מפרסם לערוץ הציבורי (ענף feed של claude-local-updates, במפתח deploy שמותר לו רק שם)
//  המפתחות הפרטיים נשארים ב-%USERPROFILE%\.secrets. ההתקנות עצמן תלויות רק ב-GitHub.
//  יומן: %LOCALAPPDATA%\ClaudeLocalBuild\ship.log   ·   הרצה ידנית: node tools/ship-after-push.js <sha>
// ============================================================
const fs = require('fs'), path = require('path'), os = require('os'), cp = require('child_process');
// a git hook runs with GIT_DIR (and friends) set to THIS repository: inherited by release.js, its `git -C feed-repo …`
// would commit and push the release into this repository instead of the updates feed (happened 11-25, cleaned up)
for (const k of Object.keys(process.env)) if (/^GIT_(DIR|WORK_TREE|INDEX_FILE|PREFIX|COMMON_DIR|OBJECT_DIRECTORY|ALTERNATE_OBJECT_DIRECTORIES|NAMESPACE|QUARANTINE_PATH)$/.test(k)) delete process.env[k];
const ROOT = path.resolve(__dirname, '..');
const HOME = path.join(process.env.LOCALAPPDATA || os.homedir(), 'ClaudeLocalBuild'); fs.mkdirSync(HOME, { recursive: true });
const LOG = path.join(HOME, 'ship.log'), STATE = path.join(HOME, 'last-release.json'), LOCK = path.join(HOME, 'ship.lock');
const log = m => fs.appendFileSync(LOG, `${new Date().toISOString()} ${m}\n`);
const git = (...a) => { const r = cp.spawnSync('git', ['-C', ROOT, ...a], { encoding: 'utf8', windowsHide: true }); return (r.stdout || '').trim(); };
const sleep = ms => new Promise(r => setTimeout(r, ms));

// the hook returns at once: the release runs in its own detached process (git push is never held)
if (process.argv.includes('--detach')) { const a = process.argv.slice(2).filter(x => x !== '--detach'); cp.spawn(process.execPath, [__filename, ...a], { detached: true, stdio: 'ignore', windowsHide: true, cwd: ROOT }).unref(); process.exit(0); }
(async () => {
  const sha = process.argv[2] || git('rev-parse', 'HEAD');
  // one at a time: a newer push waits for the running release, then releases the newest commit
  for (let i = 0; i < 180; i++) { try { fs.writeFileSync(LOCK, String(process.pid), { flag: 'wx' }); break; } catch { const pid = +fs.readFileSync(LOCK, 'utf8'); try { process.kill(pid, 0); } catch { fs.rmSync(LOCK, { force: true }); continue; } await sleep(10000); } }
  try {
    // 1. the push reached GitHub
    let remote = ''; for (let i = 0; i < 40; i++) { remote = (git('ls-remote', 'origin', 'refs/heads/main').split(/\s/)[0] || ''); if (remote === sha) break; await sleep(3000); }
    if (remote !== sha) { log(`skip ${sha.slice(0, 8)}: origin/main is ${remote.slice(0, 8)} (the push did not land, or a newer one did)`); return; }
    let last = {}; try { last = JSON.parse(fs.readFileSync(STATE, 'utf8')); } catch { }
    if (last.sha === sha) { log(`skip ${sha.slice(0, 8)}: already released as ${last.build}`); return; }
    // 2. the APK only when the android/ pointer moved
    const androidNow = (git('ls-tree', sha, 'android').split(/\s+/)[2] || '');
    const reuse = last.android && last.android === androidNow;
    const subject = git('log', '-1', '--format=%s', sha).slice(0, 300);
    log(`release ${sha.slice(0, 8)} "${subject}" ${reuse ? '(APK reused)' : '(APK built: android ' + androidNow.slice(0, 8) + ')'}`);
    const r = cp.spawnSync(process.execPath, [path.join(ROOT, 'tools', 'release.js'), '--publish', '--ci', ...(reuse ? ['--reuse-apk'] : []), '--notes', subject],
      { cwd: ROOT, encoding: 'utf8', windowsHide: true, timeout: 40 * 60 * 1000, env: { ...process.env, FEED_SSH_KEY: path.join(os.homedir(), '.secrets', 'ci-feed-deploy') } });
    if (r.status !== 0) { log(`FAILED ${sha.slice(0, 8)}: ${(r.stderr || r.stdout || '').slice(-1500)}`); return; }
    const out = JSON.parse(r.stdout.trim().split('\n').pop());
    fs.writeFileSync(STATE, JSON.stringify({ sha, build: out.build, android: androidNow, at: new Date().toISOString() }));
    log(`published ${out.build} for ${sha.slice(0, 8)} — every installation picks it up within its next check (≤30 min; instantly for computers that hear it on the network)`);
  } catch (e) { log('error: ' + (e.stack || e.message)); }
  finally { try { if (+fs.readFileSync(LOCK, 'utf8') === process.pid) fs.rmSync(LOCK, { force: true }); } catch { } }
})();
