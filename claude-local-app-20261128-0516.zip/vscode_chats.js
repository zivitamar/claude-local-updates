'use strict';
// ============================================================
//  vscode_chats.js — הצ'אטים של Claude Code ב-VS Code (וגם בטרמינל) של המשתמש, מכל החלונות והתיקיות.
//  מקור האמת: ~/.claude/projects/<תיקייה>/<sessionId>.jsonl (התמלול של כל צ'אט) + ~/.claude/sessions/<pid>.json
//  (רישום הצ'אטים הפתוחים עכשיו: שם, מצב idle/busy, תהליך).
//  • list(): כל הצ'אטים — שם, תיקייה, מודל, הרשאות, פעילות אחרונה, פתוח/סגור. קריאה חלקית (ראש+זנב) + מטמון לפי גודל/זמן.
//  • read(): ההודעות האחרונות של צ'אט.
//  • toAppMessages(): התמלול המלא בפורמט ההודעות של האפליקציה (לתצוגה בלבד — ההקשר האמיתי עובר דרך --fork-session).
// ============================================================
const fs = require('fs'), path = require('path'), os = require('os');

const CLAUDE_DIR = process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
const PROJECTS = path.join(CLAUDE_DIR, 'projects'), SESSIONS = path.join(CLAUDE_DIR, 'sessions');
const HEAD = 96 * 1024, TAIL = 768 * 1024;
const cache = new Map(); // file -> { key, info }

function readSlice(fd, pos, len) { const b = Buffer.alloc(len); const n = fs.readSync(fd, b, 0, len, pos); return b.subarray(0, n).toString('utf8'); }
function lines(text, dropFirst) { const l = text.split('\n'); if (dropFirst) l.shift(); const out = []; for (const s of l) { if (!s || s[0] !== '{') continue; try { out.push(JSON.parse(s)); } catch { } } return out; }
const textOf = c => typeof c === 'string' ? c : Array.isArray(c) ? c.filter(b => b && b.type === 'text').map(b => b.text).join('\n') : '';
const clean = t => String(t || '').replace(/<system-reminder>[\s\S]*?<\/system-reminder>/g, '').replace(/<(command-[a-z]+|local-command-stdout)>[\s\S]*?<\/\1>/g, '').trim();
const isRealUserText = j => j.type === 'user' && !j.isMeta && !j.isSidechain && j.message && clean(textOf(j.message.content)) && !(Array.isArray(j.message.content) && j.message.content.some(b => b.type === 'tool_result'));

// ---------- צ'אטים פתוחים עכשיו ----------
function alive(pid) { try { process.kill(pid, 0); return true; } catch (e) { return e.code === 'EPERM'; } }
function liveSessions() {
  const map = new Map();
  let files = []; try { files = fs.readdirSync(SESSIONS).filter(f => /^\d+\.json$/.test(f)); } catch { }
  for (const f of files) {
    try { const j = JSON.parse(fs.readFileSync(path.join(SESSIONS, f), 'utf8')); if (!j.sessionId || !alive(j.pid)) continue; map.set(j.sessionId, { pid: j.pid, name: j.name || '', status: j.status || '', entrypoint: j.entrypoint || '', cwd: j.cwd || '', startedAt: j.startedAt || 0 }); } catch { }
  }
  return map;
}

// ---------- סיכום של צ'אט אחד (ראש + זנב של הקובץ) ----------
function summarize(file) {
  const st = fs.statSync(file); const key = st.size + ':' + st.mtimeMs;
  const c = cache.get(file); if (c && c.key === key) return c.info;
  const fd = fs.openSync(file, 'r');
  let head, tail;
  try { head = lines(readSlice(fd, 0, Math.min(HEAD, st.size)), false); tail = st.size > HEAD ? lines(readSlice(fd, Math.max(0, st.size - TAIL), Math.min(TAIL, st.size)), true) : head; } finally { fs.closeSync(fd); }
  const all = st.size > HEAD ? head.concat(tail) : head;
  const info = { sessionId: path.basename(file, '.jsonl'), file, size: st.size, mtime: st.mtimeMs, cwd: '', entrypoint: '', customTitle: '', aiTitle: '', summary: '', firstPrompt: '', lastPrompt: '', model: '', effort: '', permissionMode: '', version: '', lastTs: 0, forkedFrom: '' };
  for (const j of all) {
    if (j.cwd && !info.cwd) info.cwd = j.cwd;
    if (j.entrypoint) info.entrypoint = j.entrypoint;
    if (j.version) info.version = j.version;
    if (j.type === 'custom-title' && j.customTitle) info.customTitle = j.customTitle;
    if (j.type === 'ai-title' && j.aiTitle) info.aiTitle = j.aiTitle;
    if (j.type === 'summary' && j.summary) info.summary = j.summary;
    if (j.type === 'last-prompt' && j.lastPrompt) info.lastPrompt = j.lastPrompt;
    if (j.permissionMode && j.type === 'user') info.permissionMode = j.permissionMode;
    if (j.type === 'assistant' && j.message && j.message.model && !/synthetic/.test(j.message.model)) info.model = j.message.model;
    if (j.effort && typeof j.effort === 'string') info.effort = j.effort;
    if (j.timestamp) { const t = Date.parse(j.timestamp); if (t > info.lastTs) info.lastTs = t; }
  }
  const fp = head.find(isRealUserText); if (fp) info.firstPrompt = clean(textOf(fp.message.content)).slice(0, 200);
  if (!info.lastTs) info.lastTs = st.mtimeMs;
  cache.set(file, { key, info });
  return info;
}
function titleOf(i, live) { return (live && live.name && !/^[a-z]+-[0-9a-f]{2}$/i.test(live.name) ? live.name : '') || i.customTitle || i.aiTitle || i.summary || i.firstPrompt.slice(0, 80) || '(בלי שם)'; }

// ---------- כל הצ'אטים ----------
function list({ query = '', source = 'vscode', limit = 60, includeEmpty = false } = {}) {
  const live = liveSessions();
  const out = [];
  let dirs = []; try { dirs = fs.readdirSync(PROJECTS, { withFileTypes: true }).filter(d => d.isDirectory()); } catch { }
  for (const d of dirs) {
    let files = []; try { files = fs.readdirSync(path.join(PROJECTS, d.name)).filter(f => f.endsWith('.jsonl')); } catch { }
    for (const f of files) {
      const file = path.join(PROJECTS, d.name, f);
      let i; try { i = summarize(file); } catch { continue; }
      const lv = live.get(i.sessionId) || null;
      const ep = (lv && lv.entrypoint) || i.entrypoint;
      if (source === 'vscode' && ep !== 'claude-vscode') continue;
      if (source === 'cli' && !/^(cli|claude-vscode)$/.test(ep)) continue;
      if (!includeEmpty && !i.firstPrompt && !i.aiTitle && !i.customTitle) continue;
      out.push({ ...i, entrypoint: ep, title: titleOf(i, lv), live: lv, cwd: i.cwd || (lv && lv.cwd) || '' });
    }
  }
  const q = String(query || '').trim().toLowerCase();
  const norm = s => String(s || '').toLowerCase().replace(/\s*\(fork\)/g, ' (fork)').replace(/\s+/g, ' ').trim();
  let res = out;
  if (q) {
    const nq = norm(q);
    res = out.map(c => { const t = norm(c.title); const score = t === nq ? 3 : t.startsWith(nq) ? 2 : (t.includes(nq) || norm(c.aiTitle).includes(nq) || norm(c.customTitle).includes(nq) || c.sessionId.startsWith(q)) ? 1 : (norm(c.firstPrompt).includes(nq) || norm(c.lastPrompt).includes(nq)) ? 0.5 : 0; return { c, score }; }).filter(x => x.score > 0).sort((a, b) => b.score - a.score || b.c.lastTs - a.c.lastTs).map(x => x.c);
  } else res = out.sort((a, b) => (b.live ? 1 : 0) - (a.live ? 1 : 0) || b.lastTs - a.lastTs);
  return { total: out.length, items: res.slice(0, Math.max(1, Math.min(500, limit))) };
}
function find(ref, { source = 'all' } = {}) {
  ref = String(ref || '').trim(); if (!ref) return { error: 'חסר שם או מזהה של צ\'אט' };
  const { items } = list({ query: ref, source, limit: 500, includeEmpty: true });
  const exactId = items.find(c => c.sessionId === ref || c.sessionId.startsWith(ref) && ref.length >= 6);
  if (exactId) return { chat: exactId };
  if (!items.length) return { error: 'לא נמצא צ\'אט בשם "' + ref + '"' };
  const norm = s => String(s || '').toLowerCase().replace(/\s+/g, ' ').trim();
  const exact = items.filter(c => norm(c.title) === norm(ref));
  if (exact.length === 1) return { chat: exact[0] };
  const pool = exact.length ? exact : items;
  if (pool.length === 1) return { chat: pool[0] };
  return { error: 'יש כמה צ\'אטים שמתאימים — ציין את המזהה (session):', candidates: pool.slice(0, 12) };
}

// ---------- קריאת התמלול המלא ----------
function readAll(file) { return lines(fs.readFileSync(file, 'utf8'), false); }
function recent(file, last = 12) {
  const all = readAll(file).filter(j => (j.type === 'user' || j.type === 'assistant') && !j.isSidechain && !j.isMeta && j.message);
  const out = [];
  for (const j of all) {
    const c = j.message.content; let t = '';
    if (j.type === 'user') { if (Array.isArray(c) && c.some(b => b.type === 'tool_result')) continue; t = clean(textOf(c)); }
    else { t = (Array.isArray(c) ? c : []).map(b => b.type === 'text' ? b.text : b.type === 'tool_use' ? '[כלי ' + b.name + ']' : '').filter(Boolean).join(' '); }
    if (!t) continue;
    const prev = out[out.length - 1];
    if (prev && prev.role === j.type && j.type === 'assistant') prev.text += ' ' + t; else out.push({ role: j.type, text: t, ts: Date.parse(j.timestamp) || 0 });
  }
  return out.slice(-last);
}
// התמלול → הודעות האפליקציה (טקסט, כלים ותוצאות; תמונות וחשיבה חתומה לא נשמרות — הן בהקשר של ה-CLI עצמו)
function toAppMessages(file) {
  const all = readAll(file).filter(j => (j.type === 'user' || j.type === 'assistant') && !j.isSidechain && j.message);
  const msgs = []; const cut = (s, n) => (s.length > n ? s.slice(0, n) + '\n…[קוצר בתצוגה — המלא נמצא בהקשר של Claude]' : s);
  for (const j of all) {
    const ts = Date.parse(j.timestamp) || 0; const c = j.message.content;
    if (j.type === 'user') {
      if (j.isMeta) continue;
      if (Array.isArray(c) && c.some(b => b.type === 'tool_result')) {
        const blocks = c.filter(b => b.type === 'tool_result').map(b => ({ type: 'tool_result', tool_use_id: b.tool_use_id, is_error: !!b.is_error, content: cut(typeof b.content === 'string' ? b.content : (Array.isArray(b.content) ? b.content.map(x => x.type === 'text' ? x.text : '[' + x.type + ']').join('\n') : ''), 3000) }));
        const prev = msgs[msgs.length - 1];
        if (prev && prev.role === 'user' && prev._tr) prev.content.push(...blocks); else msgs.push({ role: 'user', content: blocks, ts, _tr: true });
        continue;
      }
      const t = clean(textOf(c)); if (!t) continue;
      msgs.push({ role: 'user', content: [{ type: 'text', text: cut(t, 20000) }], ts });
    } else {
      const blocks = (Array.isArray(c) ? c : []).map(b => b.type === 'text' && b.text ? { type: 'text', text: b.text } : b.type === 'tool_use' ? { type: 'tool_use', id: b.id, name: b.name, input: (() => { const s = JSON.stringify(b.input || {}); return s.length > 6000 ? { _truncated: s.slice(0, 6000) } : b.input; })() } : null).filter(Boolean);
      if (!blocks.length) continue;
      const prev = msgs[msgs.length - 1];
      if (prev && prev.role === 'assistant' && prev._mid === j.message.id) prev.content.push(...blocks);
      else msgs.push({ role: 'assistant', content: blocks, ts, _mid: j.message.id });
    }
  }
  for (const m of msgs) { delete m._tr; delete m._mid; }
  return msgs;
}
// ---------- המרה מדויקת (גרסה 2): כל שורה בתמלול → אותו פורמט שהמנוע שומר בשיחה חיה (cli_engine) ----------
//  • הודעות Claude: טקסט / חשיבה / כלי (בלי caller), מקובצות לפי מזהה ההודעה — בדיוק כמו handleAssistant
//  • תוצאות כלים: טקסט (תמונה → [image]), עד 60,000 תווים, וזמן הביצוע מחושב מהתמלול — כמו handleUser
//  • ההודעות שלך: הטקסט בדיוק כמו שנכתב (+ תמונות). הקשר שהעורך הוסיף (קובץ פתוח, בחירה, system-reminder) — מוסתר
//  • לא הודעות שלך ולא מוצגות: התראות משימות רקע, הודעות מערכת (isMeta), הערות מסנן הבטיחות
//  • פקודות / → "/model sonnet" · פלט פקודה מקומית / "נעצר" / סיכום שיחה ישנה → הודעת מידע קצרה
const RESULT_CAP = 60000;
const flatten = c => typeof c === 'string' ? c : Array.isArray(c) ? c.map(b => (b && b.type === 'text' ? b.text : b && b.type === 'image' ? '[image]' : b && b.text) || '').join('\n') : (() => { try { return JSON.stringify(c); } catch { return String(c); } })();
const capR = s => (s.length > RESULT_CAP ? s.slice(0, RESULT_CAP) + '\n…(truncated)' : s);
const HIDDEN_RE = /^\s*<(ide_opened_file|ide_selection|ide_diagnostics|system-reminder|local-command-caveat)\b/;
function userBlocks(c) {
  const arr = typeof c === 'string' ? [{ type: 'text', text: c }] : (Array.isArray(c) ? c : []);
  const out = [];
  for (const b of arr) {
    if (!b) continue;
    if (b.type === 'image' && b.source) { out.push({ type: 'image', source: b.source }); continue; }
    if (b.type !== 'text' || typeof b.text !== 'string') continue;
    if (HIDDEN_RE.test(b.text)) { out.push({ type: 'text', text: b.text, hidden: true }); continue; }
    let t = b.text.replace(/<system-reminder>[\s\S]*?<\/system-reminder>/g, '').replace(/<pasted_content\b[^>]*>\n?/g, '').replace(/\n?<\/pasted_content\b[^>]*>/g, '');
    const cmd = t.match(/<command-name>\s*([^<]+?)\s*<\/command-name>/);
    if (cmd) { const args = (t.match(/<command-args>([\s\S]*?)<\/command-args>/) || [])[1] || ''; t = ('/' + cmd[1].replace(/^\//, '') + (args.trim() ? ' ' + args.trim() : '')); }
    if (!t.trim()) continue;
    out.push({ type: 'text', text: t });
  }
  return out;
}
async function* convert(file) {
  const rl = require('readline').createInterface({ input: fs.createReadStream(file, { encoding: 'utf8', highWaterMark: 1 << 20 }), crlfDelay: Infinity });
  let pending = null; const toolTs = new Map();
  const notice = (text, ts) => ({ role: 'assistant', content: [{ type: 'local_notice', info: true, text }], ts, doneAt: ts });
  for await (const l of rl) {
    if (l.length < 20 || l.charCodeAt(0) !== 123) continue;
    if (l.startsWith('{"type":"') && !l.startsWith('{"type":"user"') && !l.startsWith('{"type":"assistant"')) continue; // api-request / ai-title / … — לא הודעות
    let j; try { j = JSON.parse(l); } catch { continue; }
    if ((j.type !== 'user' && j.type !== 'assistant') || j.isSidechain || !j.message) continue;
    const ts = Date.parse(j.timestamp) || 0;
    if (j.type === 'assistant') {
      const msg = j.message; if (!Array.isArray(msg.content)) continue;
      const blocks = msg.content.map(b => {
        if (b.type === 'text') return { type: 'text', text: b.text };
        if (b.type === 'thinking') return { type: 'thinking', thinking: b.thinking || '', signature: b.signature || '' };
        if (b.type === 'tool_use') { const { caller, ...rest } = b; return rest; }
        if (b.type === 'redacted_thinking') return null;
        return b;
      }).filter(b => b && !(b.type === 'text' && !b.text));
      if (!blocks.length) continue;
      for (const b of blocks) if (b.type === 'tool_use') toolTs.set(b.id, ts);
      if (pending && pending.cliMsgId === msg.id) { for (const b of blocks) { if (b.type === 'tool_use' && pending.content.some(x => x.type === 'tool_use' && x.id === b.id)) continue; pending.content.push(b); } pending.doneAt = ts; continue; }
      if (pending) yield pending;
      pending = { role: 'assistant', content: blocks, ts, doneAt: ts, model: msg.model || '', cliMsgId: msg.id, thinkingMs: [] };
      continue;
    }
    // user
    const c = j.message.content;
    if (Array.isArray(c) && c.some(b => b && b.type === 'tool_result')) {
      if (pending) { yield pending; pending = null; }
      const stored = c.filter(b => b && b.type === 'tool_result').map(r => ({ type: 'tool_result', tool_use_id: r.tool_use_id, content: capR(flatten(r.content)), is_error: !!r.is_error, ms: toolTs.has(r.tool_use_id) ? Math.max(0, ts - toolTs.get(r.tool_use_id)) : 0 }));
      yield { role: 'user', content: stored, ts };
      continue;
    }
    const kind = j.origin && j.origin.kind;
    const raw = typeof c === 'string' ? c : Array.isArray(c) ? c.filter(b => b && b.type === 'text').map(b => b.text).join('\n') : '';
    if (j.isCompactSummary) { if (pending) { yield pending; pending = null; } yield { role: 'assistant', content: [{ type: 'compaction', content: raw }], ts, doneAt: ts }; continue; }
    if (kind === 'task-notification' || /^\s*<task-notification>/.test(raw)) continue;
    if (kind === 'peer') {
      const o = j.origin; const body = o.body || raw.replace(/^Another Claude session sent a message:\s*/, '').replace(/<\/?(cross-session-message|agent-message)\b[^>]*>/g, '').trim();
      if (pending) { yield pending; pending = null; }
      yield { role: 'user', content: [{ type: 'text', text: '📨 הודעה מצ\'אט אחר של Claude' + (o.name ? ' (' + o.name + ')' : '') + ':\n' + body }], ts, peer: { name: o.name || '', id: o.msg_id || null } };
      continue;
    }
    if (j.isMeta) continue;
    const so = raw.match(/<local-command-stdout>([\s\S]*?)<\/local-command-stdout>/);
    if (so) { if (pending) { yield pending; pending = null; } if (so[1].trim()) yield notice(so[1].trim(), ts); continue; }
    if (/^\s*\[Request interrupted by user/.test(raw)) { if (pending) { yield pending; pending = null; } yield notice('⏹ נעצר לפי בקשתך', ts); continue; }
    const blocks = userBlocks(c);
    if (!blocks.some(b => b.type === 'image' || (b.type === 'text' && !b.hidden))) continue;
    if (pending) { yield pending; pending = null; }
    yield { role: 'user', content: blocks, ts };
  }
  if (pending) yield pending;
}
function lineCount(file) { let n = 0; const fd = fs.openSync(file, 'r'); const b = Buffer.alloc(1 << 20); try { let r; let pos = 0; while ((r = fs.readSync(fd, b, 0, b.length, pos)) > 0) { for (let i = 0; i < r; i++) if (b[i] === 10) n++; pos += r; } } finally { fs.closeSync(fd); } return n; }

module.exports = { list, find, recent, toAppMessages, convert, liveSessions, summarize, lineCount, PROJECTS, SESSIONS };
