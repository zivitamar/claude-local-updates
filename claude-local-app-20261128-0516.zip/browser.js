'use strict';
// ============================================================
//  שליטה בדפדפן Chrome אמיתי עבור Claude — בלי תוסף ובלי הזדווגות, ובלי תמונות כדי לפעול.
//  האפליקציה מפעילה Chrome משלה (פרופיל נפרד שנשמר בין הפעלות, כך שהתחברויות נשמרות) עם פורט דיבוג, ומדברת איתו ב-CDP.
//  Claude קורא את הדף כקוד (DOM + shadow DOM + iframes → רשימת אלמנטים ממוספרת) ולוחץ / מקליד באירועי קלט אמיתיים לפי המספרים:
//  מדויק ומהיר (אלפיות שנייה, לא צילומי מסך). הכלים נחשפים דרך שרת ה-MCP של האפליקציה (/api/mcp/<שיחה>).
//  משתני סביבה: CLAUDE_BROWSER_HEADLESS=1 (חלון נסתר, לבדיקות) · CLAUDE_BROWSER_EXE · CLAUDE_BROWSER_PORT
// ============================================================
const fs = require('fs'), os = require('os'), path = require('path'), net = require('net'), { spawn } = require('child_process');

const sleep = ms => new Promise(r => setTimeout(r, ms));
const freePort = () => new Promise(res => { const s = net.createServer(); s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => res(p)); }); });

function findChrome() {
  const c = [process.env.CLAUDE_BROWSER_EXE,
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    path.join(process.env.LOCALAPPDATA || '', 'Google', 'Chrome', 'Application', 'chrome.exe'),
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe', 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    '/usr/bin/google-chrome', '/usr/bin/chromium', '/usr/bin/chromium-browser', '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'];
  return c.find(p => { try { return p && fs.statSync(p).isFile(); } catch { return false; } }) || null;
}

// JS שרץ בתוך הדף. אוסף אלמנטים אינטראקטיביים נראים — כולל בתוך shadow DOM פתוח ו-iframes באותו origin — ושומר אותם במרשם window.__cc (מספר ← אלמנט + היסט iframe).
const WALK = `
  const vw = innerWidth, vh = innerHeight;
  const Q = 'a[href],button,input,textarea,select,summary,[role=button],[role=link],[role=textbox],[role=searchbox],[role=combobox],[role=tab],[role=menuitem],[role=option],[role=checkbox],[role=radio],[role=switch],[role=slider],[contenteditable=""],[contenteditable=true],[onclick],[tabindex]:not([tabindex="-1"]),label[for]';
  function* deep(root, off) {
    for (const e of root.querySelectorAll('*')) { if (e.shadowRoot) yield* deep(e.shadowRoot, off); }
    for (const e of root.querySelectorAll(Q)) yield [e, off];
    for (const f of root.querySelectorAll('iframe')) { try { const d = f.contentDocument; if (d) { const r = f.getBoundingClientRect(); yield* deep(d, { x: off.x + r.left, y: off.y + r.top }); } } catch (e) {} }
  }
  const rectOf = (e, off) => { const r = e.getBoundingClientRect(); return { l: r.left + off.x, t: r.top + off.y, w: r.width, h: r.height }; };
  const vis = (e, off) => { const r = rectOf(e, off); if (r.w < 2 || r.h < 2) return false; const s = (e.ownerDocument.defaultView || window).getComputedStyle(e); if (s.visibility === 'hidden' || s.display === 'none' || +s.opacity === 0) return false; return r.t + r.h > -vh && r.t < vh * 2 && r.l + r.w > 0 && r.l < vw; };
  const label = e => { const t = (e.getAttribute('aria-label') || e.innerText || e.value || e.placeholder || e.title || e.alt || (e.querySelector && e.querySelector('img') && e.querySelector('img').alt) || e.getAttribute('name') || '').replace(/\\s+/g, ' ').trim(); return t.slice(0, 90); };
`;
const SNAPSHOT_JS = `(() => {
  ${WALK}
  const max = 170;
  const all = []; const seen = new Set();
  for (const [e, off] of deep(document, { x: 0, y: 0 })) { if (seen.has(e)) continue; seen.add(e); if (vis(e, off)) all.push([e, off]); }
  const inView = ([e, off]) => { const r = rectOf(e, off); return r.t >= 0 && r.t < vh; };
  all.sort((a, b) => (inView(b) ? 1 : 0) - (inView(a) ? 1 : 0));
  window.__cc = new Map();
  const kind = e => { const t = e.tagName.toLowerCase(); const r = e.getAttribute('role'); if (t === 'input') return 'input:' + (e.type || 'text'); if (r) return r; if (t === 'a') return 'link'; return t; };
  const out = []; let n = 0;
  for (const pair of all) {
    const [e, off] = pair; if (n >= max) break; const lb = label(e); const k = kind(e);
    if (!lb && !/input|textbox|searchbox|combobox|textarea|select|checkbox|radio|switch|slider/.test(k)) continue;
    n++; window.__cc.set(n, pair);
    let extra = ''; if (e.tagName === 'A' && e.href) extra = ' -> ' + e.href.replace(/^https?:\\/\\//, '').slice(0, 70);
    if ('value' in e && e.value && /input|textarea|select/.test(e.tagName.toLowerCase())) extra += ' value="' + String(e.value).slice(0, 40) + '"';
    if (e.disabled) extra += ' (disabled)'; if (e.checked) extra += ' (checked)';
    out.push('[' + n + '] ' + k + ' "' + lb + '"' + extra + (inView(pair) ? '' : '  (below)'));
  }
  const text = (document.body ? document.body.innerText : '').replace(/\\n{3,}/g, '\\n\\n').trim().slice(0, 1800);
  return JSON.stringify({ url: location.href, title: document.title, scrollY: Math.round(scrollY), scrollH: document.documentElement.scrollHeight, viewport: vw + 'x' + vh, count: out.length, elements: out, text });
})()`;
// מחכה שהדף יירגע: readyState=complete ותוכן/משאבים יציבים quietMs
const settleJS = (quiet, max) => `(async () => { const t0 = performance.now(); let last = '', since = performance.now(); while (performance.now() - t0 < ${max}) { const sig = (document.body ? document.body.innerText.length : 0) + '|' + performance.getEntriesByType('resource').length + '|' + document.readyState + '|' + location.href; if (sig !== last) { last = sig; since = performance.now(); } else if (document.readyState === 'complete' && performance.now() - since >= ${quiet}) break; await new Promise(r => setTimeout(r, 30)); } return document.readyState; })()`;

const NOT_CONNECTED = 'ה-Chrome שלך לא מחובר לאפליקציה: התוסף "Claude Local — שליטה בכרום" לא מותקן או ש-Chrome סגור. ' +
  'התקנה חד-פעמית: הגדרות האפליקציה › "שליטה בכרום" › "התקן בכרום" (או ב-Chrome: chrome://extensions › מצב מפתח › "טען פריט לא ארוז" › התיקייה chrome-extension). ' +
  'אל תנסה דרך אחרת (Bash / curl / Playwright / Chromium) — דווח למשתמש שצריך לחבר את התוסף.';

class BrowserCtl {
  // mode: 'chrome' (ברירת מחדל) = ה-Chrome האמיתי של המשתמש דרך התוסף · 'launch' = Chrome נפרד עם פרופיל משלו (רק לבדיקות: CLAUDE_BROWSER_MODE=launch)
  constructor({ dataDir, log, bridge, mode } = {}) {
    this.dataDir = dataDir || path.join(os.tmpdir(), 'claude-browser'); this.log = log || (() => { });
    this.profile = path.join(this.dataDir, 'browser-profile'); this.stateFile = path.join(this.dataDir, 'browser-state.json');
    this.port = 0; this.conns = new Map(); this.activeId = null; this.proc = null; this.starting = null;
    this.bridge = bridge || null;
    this.mode = mode || (process.env.CLAUDE_BROWSER_MODE === 'launch' || !bridge ? 'launch' : 'chrome');
    if (this.bridge) this.bridge.onEvent(m => this.onExtEvent(m));
  }
  get ext() { return this.mode === 'chrome'; }
  onExtEvent(m) {
    const id = String(m.tabId); const c = this.conns.get(id);
    if (m.method === 'tabClosed' || m.method === 'detached') { if (m.method === 'tabClosed') { this.conns.delete(id); if (this.activeId === id) this.activeId = null; } return; }
    if (!c) return;
    if (m.method === 'Page.javascriptDialogOpening') { c.dialogs.push({ type: m.params.type, message: m.params.message, at: Date.now() }); c.send('Page.handleJavaScriptDialog', { accept: true, promptText: m.params.defaultPrompt || '' }).catch(() => { }); }
    else if (m.method === 'Page.frameNavigated' && m.params && m.params.frame && !m.params.frame.parentId) c.navs++;
  }
  async newTab(url) {
    if (this.ext) { const t = await this.bridge.call('tabs.create', { url: url || 'about:blank' }); this.activeId = String(t.id); return { ...t, id: String(t.id) }; }
    const t = await this.http('/json/new?' + encodeURI(url || 'about:blank'), 'PUT'); this.activeId = t.id; return t;
  }
  async closeTab(id) { if (this.ext) return this.bridge.call('tabs.close', { tabId: Number(id) }); return this.http('/json/close/' + id); }
  state() { try { return JSON.parse(fs.readFileSync(this.stateFile, 'utf8')); } catch { return {}; } }
  async alive(port) { if (!port) return false; try { const r = await fetch(`http://127.0.0.1:${port}/json/version`, { signal: AbortSignal.timeout(1500) }); return r.ok; } catch { return false; } }
  // מחזיר פורט של Chrome חי (מפעיל Chrome אם צריך). קריאות במקביל חולקות הפעלה אחת
  ensure() {
    if (this.ext) return this.bridge.waitConnected(2500).then(ok => { if (!ok) throw new Error(NOT_CONNECTED); return 'ext'; });
    if (this.port && this._okAt && Date.now() - this._okAt < 3000) return Promise.resolve(this.port);
    if (this.starting) return this.starting;
    this.starting = (async () => {
      const st = this.state();
      for (const p of [this.port, st.port, parseInt(process.env.CLAUDE_BROWSER_PORT || '', 10)]) if (p && await this.alive(p)) { this.port = p; this._okAt = Date.now(); return p; }
      const exe = findChrome(); if (!exe) throw new Error('לא נמצא Chrome במחשב (אפשר להגדיר CLAUDE_BROWSER_EXE).');
      fs.mkdirSync(this.profile, { recursive: true });
      const port = parseInt(process.env.CLAUDE_BROWSER_PORT || '', 10) || await freePort();
      const args = [`--remote-debugging-port=${port}`, '--remote-allow-origins=*', `--user-data-dir=${this.profile}`, '--no-first-run', '--no-default-browser-check', '--disable-search-engine-choice-screen', '--window-size=1366,900', '--lang=he'];
      if (process.env.CLAUDE_BROWSER_HEADLESS) args.push('--headless=new', '--disable-gpu', '--mute-audio');
      args.push('about:blank');
      this.proc = spawn(exe, args, { detached: true, stdio: 'ignore', windowsHide: false }); this.proc.unref();
      for (let i = 0; i < 80; i++) { if (await this.alive(port)) { this.port = port; this._okAt = Date.now(); try { fs.mkdirSync(this.dataDir, { recursive: true }); fs.writeFileSync(this.stateFile, JSON.stringify({ port, pid: this.proc.pid, startedAt: Date.now() })); } catch { } this.log('browser started on ' + port); return port; } await sleep(200); }
      throw new Error('Chrome לא עלה בזמן.');
    })().finally(() => { this.starting = null; });
    return this.starting;
  }
  async http(p, method = 'GET') { const port = await this.ensure(); const r = await fetch(`http://127.0.0.1:${port}${p}`, { method, signal: AbortSignal.timeout(10000) }); const t = await r.text(); try { return JSON.parse(t); } catch { return t; } }
  async pages() {
    if (this.ext) { await this.ensure(); const r = await this.bridge.call('tabs.list'); this.lastFocusedWindow = r.lastFocusedWindow; return (r.tabs || []).filter(t => !/^chrome-extension:|^devtools:/.test(t.url || '')).map(t => ({ ...t, id: String(t.id) })); }
    const l = await this.http('/json/list'); return (Array.isArray(l) ? l : []).filter(t => t.type === 'page' && !/^chrome-extension:|^devtools:/.test(t.url || ''));
  }
  async resolveTab(id) {
    const pages = await this.pages();
    if (!pages.length) { await this.newTab('about:blank'); return this.resolveTab(id); }
    const want = id || this.activeId; const hit = want && pages.find(p => p.id === String(want));
    if (id && !hit) throw new Error('הלשונית ' + id + ' לא נמצאה (אולי נסגרה). הרץ browser_tabs.');
    // ב-Chrome של המשתמש: בלי לשונית שנבחרה — הלשונית הפעילה בחלון שהוא עובד בו (מה שהוא רואה עכשיו)
    const t = hit || (this.ext ? (pages.find(p => p.active && p.focusedWindow) || pages.find(p => p.active) || pages[0]) : pages[0]);
    this.activeId = t.id; return t;
  }
  // חיבור CDP לשונית (נשמר). דיאלוגים של JS (alert / confirm / prompt) נסגרים אוטומטית ונרשמים
  async conn(tab) {
    if (this.ext) {
      let c = this.conns.get(tab.id); if (c) return c;
      const tabId = Number(tab.id);
      c = { ext: true, tabId, dialogs: [], navs: 0, send: (method, params = {}, ms = 30000) => this.bridge.call('cdp', { tabId, method, params }, ms) };
      this.conns.set(tab.id, c);
      return c;
    }
    let c = this.conns.get(tab.id); if (c && c.ws.readyState === 1) return c;
    const ws = new WebSocket(tab.webSocketDebuggerUrl);
    await new Promise((res, rej) => { ws.onopen = res; ws.onerror = () => rej(new Error('חיבור ל-Chrome נכשל')); setTimeout(() => rej(new Error('timeout חיבור ל-Chrome')), 8000); });
    c = { ws, id: 0, pend: new Map(), dialogs: [], navs: 0 };
    ws.onmessage = ev => {
      let m; try { m = JSON.parse(ev.data); } catch { return; }
      if (m.id && c.pend.has(m.id)) { const p = c.pend.get(m.id); c.pend.delete(m.id); m.error ? p.rej(new Error(m.error.message)) : p.res(m.result); }
      else if (m.method === 'Page.javascriptDialogOpening') { c.dialogs.push({ type: m.params.type, message: m.params.message, at: Date.now() }); c.send('Page.handleJavaScriptDialog', { accept: true, promptText: m.params.defaultPrompt || '' }).catch(() => { }); }
      else if (m.method === 'Page.frameNavigated' && !m.params.frame.parentId) c.navs++;
    };
    ws.onclose = () => { this.conns.delete(tab.id); for (const p of c.pend.values()) p.rej(new Error('החיבור לשונית נסגר')); };
    c.send = (method, params = {}, ms = 30000) => new Promise((res, rej) => { const i = ++c.id; c.pend.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method, params })); setTimeout(() => { if (c.pend.has(i)) { c.pend.delete(i); rej(new Error('timeout ' + method)); } }, ms); });
    this.conns.set(tab.id, c);
    await c.send('Page.enable').catch(() => { });
    return c;
  }
  async tab(id) { const t = await this.resolveTab(id); const c = await this.conn(t); return { t, c }; }
  async evalIn(c, expression, { awaitPromise = true, objectId = false } = {}) {
    const r = await c.send('Runtime.evaluate', { expression, returnByValue: !objectId, awaitPromise, userGesture: true });
    if (r.exceptionDetails) throw new Error((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails.text || 'שגיאת JS בדף');
    return objectId ? r.result : (r.result ? r.result.value : undefined);
  }
  async waitReady(c, ms = 15000, quiet = 200) {
    const t0 = Date.now();
    while (Date.now() - t0 < ms) { try { const st = await this.evalIn(c, settleJS(quiet, Math.min(2500, ms))); if (st === 'complete') return; } catch { /* הקשר הדף התחלף (ניווט) — מנסים שוב */ } await sleep(80); }
  }
  async snapshot(c) { const raw = await this.evalIn(c, SNAPSHOT_JS); return JSON.parse(raw); }
  fmtSnap(j, c) {
    const dlg = c && c.dialogs.length ? `\n[דיאלוג JS שנסגר אוטומטית: ${c.dialogs.splice(0).map(d => d.type + ': ' + d.message).join(' | ')}]` : '';
    return `עמוד: ${j.title}\nכתובת: ${j.url}\nגלילה: ${j.scrollY}/${j.scrollH} · חלון ${j.viewport}${dlg}\n\nאלמנטים (השתמש במספר ב-browser_click / browser_type):\n${j.elements.join('\n') || '(אין אלמנטים אינטראקטיביים נראים)'}\n\nטקסט נראה בדף:\n${j.text}`;
  }
  async result(c, head, a) { if (a && a.snapshot === false) return { output: head + (c.dialogs.length ? '\n[דיאלוג: ' + c.dialogs.splice(0).map(d => d.message).join(' | ') + ']' : ''), images: [], is_error: false }; return { output: (head ? head + '\n\n' : '') + this.fmtSnap(await this.snapshot(c), c), images: [], is_error: false }; }
  // מרכז אלמנט לפי ref / selector / text → {x,y} (כולל היסט iframe)
  async locate(c, a) {
    const js = `(() => {
      ${WALK}
      const a = ${JSON.stringify({ ref: a.ref, selector: a.selector, text: a.text })};
      let pair = null;
      if (a.ref != null && window.__cc && window.__cc.get(Number(a.ref))) pair = window.__cc.get(Number(a.ref));
      else if (a.selector) { const e = document.querySelector(a.selector); if (e) pair = [e, { x: 0, y: 0 }]; }
      else if (a.text) { const t = String(a.text).toLowerCase(); for (const p of deep(document, { x: 0, y: 0 })) { if (vis(p[0], p[1]) && (label(p[0]) + ' ' + (p[0].innerText || '')).toLowerCase().includes(t)) { pair = p; break; } } if (!pair) { const cand = [...document.querySelectorAll('h1,h2,h3,h4,span,div,p,li,td,label')].find(e => { const r = e.getBoundingClientRect(); return r.width > 2 && r.height > 2 && (e.innerText || '').toLowerCase().includes(t) && e.children.length < 4; }); if (cand) pair = [cand, { x: 0, y: 0 }]; } }
      if (!pair) return null;
      const [el, off] = pair; el.scrollIntoView({ block: 'center', inline: 'center' });
      const r = rectOf(el, off); return { x: Math.round(r.l + r.w / 2), y: Math.round(r.t + r.h / 2), tag: el.tagName.toLowerCase(), text: ((el.innerText || el.value || el.getAttribute('aria-label') || '') + '').slice(0, 60) };
    })()`;
    return this.evalIn(c, js);
  }
  // תנועת עכבר כמו של אדם (בתוך הדף בלבד — העכבר של המחשב לא זז): מסלול קצר ומעוגל מהמיקום הקודם, ואז לחיצה עם החזקה קצרה
  async glide(c, x, y) {
    const sx = c.mx != null ? c.mx : x + (Math.random() < 0.5 ? -1 : 1) * (60 + Math.random() * 120), sy = c.my != null ? c.my : y + (Math.random() < 0.5 ? -1 : 1) * (40 + Math.random() * 80);
    const steps = 6 + Math.floor(Math.random() * 4), cx = (sx + x) / 2 + (Math.random() - 0.5) * 40, cy = (sy + y) / 2 + (Math.random() - 0.5) * 40;
    for (let i = 1; i <= steps; i++) { const t = i / steps, u = 1 - t; await c.send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: Math.round(u * u * sx + 2 * u * t * cx + t * t * x), y: Math.round(u * u * sy + 2 * u * t * cy + t * t * y) }); await sleep(4 + Math.random() * 6); }
    c.mx = x; c.my = y;
  }
  async mouse(c, x, y, { double = false, button = 'left', move = true } = {}) {
    if (move) await this.glide(c, x, y);
    for (let i = 1; i <= (double ? 2 : 1); i++) { await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button, clickCount: i }); await sleep(35 + Math.random() * 45); await c.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button, clickCount: i }); if (double) await sleep(60); }
  }
  // הקלדה אות-אות עם לחיצות מקשים אמיתיות (keydown / keypress / input / keyup לכל תו), בקצב של אדם מהיר. טקסט ארוך מאוד (>300) — מודבק בבת אחת, כמו הדבקה
  async typeText(c, text) {
    text = String(text == null ? '' : text);
    if (text.length > 300) { await c.send('Input.insertText', { text }); return; }
    for (const ch of text) {
      if (ch === '\n') { await this.key(c, 'Enter'); continue; }
      const up = ch.toUpperCase(), ascii = /^[\x20-\x7e]$/.test(ch);
      const vk = /^[a-z]$/i.test(ch) ? up.charCodeAt(0) : /^[0-9]$/.test(ch) ? ch.charCodeAt(0) : ch === ' ' ? 32 : 0;
      const code = /^[a-z]$/i.test(ch) ? 'Key' + up : /^[0-9]$/.test(ch) ? 'Digit' + ch : ch === ' ' ? 'Space' : '';
      const mods = ascii && /[A-Z!@#$%^&*()_+{}|:"<>?~]/.test(ch) ? 8 : 0;
      await c.send('Input.dispatchKeyEvent', { type: 'keyDown', text: ch, unmodifiedText: ch, key: ch, code, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk, modifiers: mods });
      await c.send('Input.dispatchKeyEvent', { type: 'keyUp', key: ch, code, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk, modifiers: mods });
      await sleep(6 + Math.random() * 14);
    }
  }
  async key(c, spec) {
    const KEYS = { Enter: [13, 'Enter', '\r'], Tab: [9, 'Tab', ''], Escape: [27, 'Escape', ''], Backspace: [8, 'Backspace', ''], Delete: [46, 'Delete', ''], ArrowDown: [40, 'ArrowDown', ''], ArrowUp: [38, 'ArrowUp', ''], ArrowLeft: [37, 'ArrowLeft', ''], ArrowRight: [39, 'ArrowRight', ''], Home: [36, 'Home', ''], End: [35, 'End', ''], PageDown: [34, 'PageDown', ''], PageUp: [33, 'PageUp', ''], Space: [32, ' ', ' '] };
    const parts = String(spec).split('+'); const main = parts.pop(); const mods = parts.map(p => p.toLowerCase());
    const modBits = (mods.includes('alt') ? 1 : 0) | (mods.includes('control') || mods.includes('ctrl') ? 2 : 0) | (mods.includes('meta') || mods.includes('cmd') ? 4 : 0) | (mods.includes('shift') ? 8 : 0);
    const k = KEYS[main] || KEYS[main[0].toUpperCase() + main.slice(1)];
    const info = k ? { windowsVirtualKeyCode: k[0], key: k[1], code: k[1] === ' ' ? 'Space' : k[1], text: k[2] } : { windowsVirtualKeyCode: main.toUpperCase().charCodeAt(0), key: main, code: 'Key' + main.toUpperCase(), text: modBits & 6 ? '' : main };
    const CMD = { a: 'selectAll', c: 'copy', v: 'paste', x: 'cut', z: 'undo', y: 'redo' };
    const kd = { type: info.text ? 'keyDown' : 'rawKeyDown', modifiers: modBits, ...info };
    if ((modBits & 6) && CMD[main.toLowerCase()]) kd.commands = [CMD[main.toLowerCase()]];
    await c.send('Input.dispatchKeyEvent', kd);
    await c.send('Input.dispatchKeyEvent', { type: 'keyUp', modifiers: modBits, key: info.key, code: info.code, windowsVirtualKeyCode: info.windowsVirtualKeyCode });
  }
  async afterAction(c) { await sleep(40); await this.waitReady(c, 12000, 150); }

  // ---------------- הכלים ----------------
  async exec(name, a) {
    a = a || {};
    const bad = text => ({ output: text, images: [], is_error: true });
    switch (name) {
      case 'browser_tabs': {
        await this.ensure(); const act = a.action || 'list';
        let head = '';
        if (act === 'new') { const t = await this.newTab(a.url || 'about:blank'); const { c } = await this.tab(t.id); await c.send('Page.bringToFront').catch(() => { }); if (a.url) await this.waitReady(c, 20000, 250); head = 'נפתחה לשונית חדשה (id=' + t.id + ') — Claude עובד בה עכשיו.'; }
        else if (act === 'switch') {
          const pages = await this.pages(); const m = String(a.match || a.title || '').toLowerCase().trim();
          let t = (a.id != null && pages.find(p => p.id === String(a.id))) || (a.index != null && pages[parseInt(a.index, 10)]) || null;
          if (!t && m) { const hits = pages.filter(p => (p.title + ' ' + p.url).toLowerCase().includes(m)); if (hits.length > 1 && !a.first) return bad(`נמצאו ${hits.length} לשוניות שמתאימות ל-"${a.match}". בחר לפי id:\n` + hits.map(p => `id=${p.id} | ${p.title} | ${p.url}`).join('\n')); t = hits[0]; }
          if (!t) return bad('לשונית לא נמצאה' + (m ? ' שמתאימה ל-"' + a.match + '"' : '') + '. הרץ browser_tabs לרשימה.');
          this.activeId = t.id; const { c } = await this.tab(t.id); await c.send('Page.bringToFront').catch(() => { });
          head = `Claude עובד עכשיו בלשונית הקיימת: ${t.title || ''} (${t.url}). לא נפתח חלון חדש.`;
          if (a.snapshot !== false) return this.result(c, head, { snapshot: true });
        }
        else if (act === 'close') { const t = await this.resolveTab(a.id); await this.closeTab(t.id); this.conns.delete(t.id); if (this.activeId === t.id) this.activeId = null; }
        let pages = await this.pages(); const act2 = this.activeId; const total = pages.length;
        const mm = act === 'list' && a.match ? String(a.match).toLowerCase() : ''; if (mm) pages = pages.filter(p => (p.title + ' ' + p.url).toLowerCase().includes(mm));
        // שורה קצרה לכל לשונית (גם עם 100+ לשוניות הרשימה נשארת קטנה): כתובת בלי פרמטרים, כותרת מקוצרת
        const shortUrl = u => { const s = String(u || '').replace(/[?#].*$/, ''); return s.length > 70 ? s.slice(0, 69) + '…' : s; };
        const shortT = t => { t = String(t || '(ללא כותרת)').replace(/\s+/g, ' '); return t.length > 60 ? t.slice(0, 59) + '…' : t; };
        const line = p => this.ext
          ? `${p.id === act2 ? '*' : ' '} id=${p.id} w${p.window}${p.active ? '·מוצגת' : ''}${p.group ? '·' + p.group : ''} | ${shortT(p.title)} | ${shortUrl(p.url)}`
          : `${p.id === act2 ? '*' : ' '} id=${p.id} | ${p.title || '(ללא כותרת)'} | ${p.url}`;
        const legend = this.ext ? `הלשוניות ב-Chrome של המשתמש (${mm ? pages.length + ' מתוך ' + total + ' מתאימות ל-"' + a.match + '"' : total}; * = הלשונית ש-Claude עובד בה; wN = חלון). לעבודה בלשונית קיימת: browser_tabs action=switch עם id או match.\n` : '';
        return { output: (head ? head + '\n\n' : '') + legend + (pages.length ? pages.map(line).join('\n') : '(אין לשוניות ' + (mm ? 'שמתאימות' : 'פתוחות') + ')'), images: [], is_error: false };
      }
      case 'browser_navigate': {
        if (!a.url) return bad('חסר url');
        let url = String(a.url).trim(); if (!/^[a-z]+:/i.test(url)) url = 'https://' + url;
        await this.ensure();
        // ב-Chrome של המשתמש: אם Claude עוד לא בחר לשונית (או שהיא נסגרה) — לשונית חדשה, ולא דורסים לשונית שלו
        if (this.ext && !a.tab && !a.new_tab) { const pages = await this.pages(); if (!this.activeId || !pages.some(p => p.id === this.activeId)) a = { ...a, new_tab: true }; }
        if (a.new_tab) { await this.newTab('about:blank'); }
        const { c } = await this.tab(a.tab); await c.send('Page.bringToFront').catch(() => { });
        const r = await c.send('Page.navigate', { url }); if (r.errorText) return bad('הניווט נכשל: ' + r.errorText + ' (' + url + ')');
        await this.waitReady(c, 25000, 250);
        return this.result(c, '', a);
      }
      case 'browser_snapshot': { const { c } = await this.tab(a.tab); return this.result(c, '', { snapshot: true }); }
      case 'browser_find': { // חיפוש מהיר של אלמנטים לפי טקסט, בלי snapshot מלא
        const { c } = await this.tab(a.tab); const j = await this.snapshot(c); const t = String(a.text || '').toLowerCase();
        const hits = j.elements.filter(l => l.toLowerCase().includes(t)); return { output: hits.length ? hits.slice(0, 30).join('\n') : 'לא נמצא אלמנט עם הטקסט הזה (נסה browser_snapshot או גלילה).', images: [], is_error: !hits.length };
      }
      case 'browser_click': case 'browser_hover': {
        const { c } = await this.tab(a.tab); await c.send('Page.bringToFront').catch(() => { });
        const pt = (typeof a.x === 'number' && typeof a.y === 'number') ? { x: a.x, y: a.y, tag: 'point', text: '' } : await this.locate(c, a);
        if (!pt) return bad('האלמנט לא נמצא. הרץ browser_snapshot ובחר מספר (ref) עדכני, או השתמש ב-text / selector.');
        if (name === 'browser_hover') { await this.glide(c, pt.x, pt.y); await sleep(250); return this.result(c, `הועבר העכבר מעל ${pt.tag} "${pt.text || ''}" (${pt.x},${pt.y}).`, a); }
        await this.mouse(c, pt.x, pt.y, { double: !!a.double, button: a.button === 'right' ? 'right' : 'left' });
        await this.afterAction(c);
        return this.result(c, `נלחץ על ${pt.tag} "${pt.text || ''}" (${pt.x},${pt.y}).`, a);
      }
      case 'browser_drag': {
        const { c } = await this.tab(a.tab); const f = await this.locate(c, a.from || {}); const t = await this.locate(c, a.to || {}); if (!f || !t) return bad('אלמנט המקור או היעד לא נמצא');
        await c.send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: f.x, y: f.y }); await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x: f.x, y: f.y, button: 'left', clickCount: 1 });
        for (let i = 1; i <= 8; i++) await c.send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: Math.round(f.x + (t.x - f.x) * i / 8), y: Math.round(f.y + (t.y - f.y) * i / 8), button: 'left', buttons: 1 });
        await c.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: t.x, y: t.y, button: 'left', clickCount: 1 }); await this.afterAction(c);
        return this.result(c, 'נגרר.', a);
      }
      case 'browser_type': {
        const { c } = await this.tab(a.tab);
        if (a.ref != null || a.selector || a.text_target) { const pt = await this.locate(c, { ref: a.ref, selector: a.selector, text: a.text_target }); if (!pt) return bad('שדה הטקסט לא נמצא. הרץ browser_snapshot.'); await this.mouse(c, pt.x, pt.y); await sleep(60); }
        if (a.clear !== false && (a.ref != null || a.selector)) { await this.evalIn(c, "(() => { let e = document.activeElement; while (e && e.shadowRoot && e.shadowRoot.activeElement) e = e.shadowRoot.activeElement; if (e && (e.tagName === 'INPUT' || e.tagName === 'TEXTAREA')) { e.select(); return 1; } if (e && e.isContentEditable) { document.execCommand('selectAll'); return 1; } return 0; })()"); await this.key(c, 'Backspace'); }
        if (a.paste) await c.send('Input.insertText', { text: String(a.text == null ? '' : a.text) }); else await this.typeText(c, a.text);
        if (a.submit) { await sleep(120); await this.key(c, 'Enter'); await this.afterAction(c); } else await sleep(60);
        return this.result(c, `הוקלד "${a.text}"${a.submit ? ' ונלחץ Enter' : ''}.`, a);
      }
      case 'browser_select': {
        const { c } = await this.tab(a.tab);
        // בחירה בקלט אמיתי: פוקוס על הרשימה (סגורה) ולחיצות חצים עד האפשרות — האירועים input/change הם של הדפדפן (isTrusted). גיבוי: הצבה ב-JS
        const pick = `(() => { const p = window.__cc && window.__cc.get(${Number(a.ref) || 0}); const e = p ? p[0] : document.querySelector(${JSON.stringify(a.selector || 'select')}); if (!e || e.tagName !== 'SELECT') return { err: 'not-select' }; const want = ${JSON.stringify(String(a.value == null ? a.label : a.value))}.toLowerCase(); const i = [...e.options].findIndex(o => o.value.toLowerCase() === want || o.text.trim().toLowerCase() === want); const j = i >= 0 ? i : [...e.options].findIndex(o => o.text.toLowerCase().includes(want)); if (j < 0) return { err: 'no-option' }; window.__ccSel = e; e.focus(); return { delta: j - e.selectedIndex, index: j, text: e.options[j].text }; })()`;
        const r = await this.evalIn(c, pick);
        if (!r || r.err) return bad(r && r.err === 'no-option' ? 'האפשרות לא נמצאה ברשימה' : 'האלמנט אינו רשימת בחירה (select)');
        for (let k = 0; k < Math.abs(r.delta); k++) await this.key(c, r.delta > 0 ? 'ArrowDown' : 'ArrowUp');
        const okSel = await this.evalIn(c, `window.__ccSel && window.__ccSel.selectedIndex === ${r.index}`);
        if (!okSel) await this.evalIn(c, `(() => { const e = window.__ccSel; e.selectedIndex = ${r.index}; e.dispatchEvent(new Event('input', { bubbles: true })); e.dispatchEvent(new Event('change', { bubbles: true })); return 1; })()`);
        return this.result(c, 'נבחר: ' + r.text + (okSel ? '' : ' (הוצב ב-JS)'), a);
      }
      case 'browser_upload': {
        const { c } = await this.tab(a.tab); const files = [].concat(a.files || a.file || []).map(String); if (!files.length) return bad('חסר files');
        for (const f of files) if (!fs.existsSync(f)) return bad('הקובץ לא קיים: ' + f);
        const obj = await this.evalIn(c, `(() => { const p = window.__cc && window.__cc.get(${Number(a.ref) || 0}); return p ? p[0] : (document.querySelector(${JSON.stringify(a.selector || 'input[type=file]')})); })()`, { objectId: true });
        if (!obj || !obj.objectId) return bad('שדה הקובץ לא נמצא'); await c.send('DOM.enable').catch(() => { }); await c.send('DOM.setFileInputFiles', { files, objectId: obj.objectId });
        return this.result(c, 'הקבצים הוצמדו לשדה: ' + files.join(', '), a);
      }
      case 'browser_press_key': { const { c } = await this.tab(a.tab); for (const k of String(a.key || '').split(/\s+/).filter(Boolean)) { await this.key(c, k); await sleep(40); } await this.afterAction(c); return this.result(c, `נלחץ ${a.key}.`, a); }
      case 'browser_scroll': {
        const { c } = await this.tab(a.tab); const amt = Math.abs(Number(a.amount) || 700) * (a.direction === 'up' ? -1 : 1);
        await this.evalIn(c, a.ref != null ? `(() => { const p = window.__cc && window.__cc.get(${Number(a.ref)}); if (p) p[0].scrollIntoView({ block: 'center' }); else window.scrollBy(0, ${amt}); return 1; })()` : `window.scrollBy(0, ${amt}); 1`); await sleep(250);
        return this.result(c, '', a);
      }
      case 'browser_screenshot': {
        const { c } = await this.tab(a.tab); await c.send('Page.bringToFront').catch(() => { });
        const r = await c.send('Page.captureScreenshot', { format: 'jpeg', quality: 70, captureBeyondViewport: !!a.full_page });
        return { output: 'צילום מסך של העמוד', images: [{ data: r.data, mimeType: 'image/jpeg' }], is_error: false };
      }
      case 'browser_eval': { const { c } = await this.tab(a.tab); const v = await this.evalIn(c, String(a.expression || 'null')); return { output: typeof v === 'string' ? v : JSON.stringify(v === undefined ? null : v, null, 2), images: [], is_error: false }; }
      case 'browser_get_text': { const { c } = await this.tab(a.tab); const v = await this.evalIn(c, `(() => { const e = ${a.selector ? `document.querySelector(${JSON.stringify(a.selector)})` : 'document.body'}; return e ? e.innerText : null })()`); return v == null ? bad('הסלקטור לא נמצא') : { output: String(v).slice(0, 20000), images: [], is_error: false }; }
      case 'browser_wait': {
        const { c } = await this.tab(a.tab); const ms = Math.min(120, Number(a.timeout_sec) || 15) * 1000; const t0 = Date.now();
        if (!a.text && !a.selector) { await sleep(Math.min(ms, Math.max(50, (Number(a.seconds) || 1) * 1000))); return this.result(c, 'המתנה הסתיימה.', a); }
        while (Date.now() - t0 < ms) {
          const hit = await this.evalIn(c, `(() => ${a.selector ? `!!document.querySelector(${JSON.stringify(a.selector)})` : `(document.body.innerText || '').toLowerCase().includes(${JSON.stringify(String(a.text).toLowerCase())})`})()`).catch(() => false);
          if (hit) return this.result(c, `התנאי התקיים אחרי ${Date.now() - t0}ms.`, a);
          await sleep(100);
        }
        const r = await this.result(c, 'התנאי לא התקיים בזמן (' + Math.round(ms / 1000) + ' שניות).', a); r.is_error = true; return r;
      }
      case 'browser_history': { const { c } = await this.tab(a.tab); const act = a.action || 'back'; await this.evalIn(c, act === 'reload' ? 'location.reload(), 1' : act === 'forward' ? 'history.forward(), 1' : 'history.back(), 1'); await this.afterAction(c); return this.result(c, '', a); }
      case 'browser_batch': { // סדרת פעולות בקריאה אחת (חוסך סבבים מול המודל): נעצר בשגיאה הראשונה
        const acts = Array.isArray(a.actions) ? a.actions.slice(0, 40) : []; if (!acts.length) return bad('חסר actions');
        const lines = []; let last = null;
        for (let i = 0; i < acts.length; i++) {
          const x = acts[i] || {}; const tool = String(x.tool || '').startsWith('browser_') ? x.tool : 'browser_' + x.tool;
          if (tool === 'browser_batch') return bad('batch בתוך batch אסור');
          const r = await this.exec(tool, { ...(x.args || {}), snapshot: false, tab: (x.args && x.args.tab) || a.tab });
          lines.push(`${i + 1}. ${tool.replace('browser_', '')} ${r.is_error ? '✗ ' : '✓ '}${String(r.output).split('\n')[0].slice(0, 140)}`);
          last = r; if (r.is_error) { lines.push('(הסדרה נעצרה בשגיאה)'); break; }
          if (x.wait_ms) await sleep(Math.min(5000, x.wait_ms));
        }
        const { c } = await this.tab(a.tab);
        return { output: lines.join('\n') + '\n\n' + this.fmtSnap(await this.snapshot(c), c), images: last && last.images || [], is_error: !!(last && last.is_error) };
      }
      default: return bad('כלי לא מוכר: ' + name);
    }
  }
  async shutdown() { for (const c of this.conns.values()) try { c.ws.close(); } catch { } this.conns.clear(); }
  async quit() { try { const st = this.state(); const port = this.port || st.port; if (port && await this.alive(port)) { const v = await (await fetch(`http://127.0.0.1:${port}/json/version`)).json(); const ws = new WebSocket(v.webSocketDebuggerUrl); await new Promise(r => (ws.onopen = r)); ws.send(JSON.stringify({ id: 1, method: 'Browser.close' })); await sleep(500); } } catch { } this.conns.clear(); }
}

const T = (name, description, properties, required) => ({ name, description, input_schema: { type: 'object', properties: properties || {}, ...(required ? { required } : {}) } });
const tab = { tab: { type: 'string', description: 'Tab id (optional, default: the active tab)' } };
const snap = { snapshot: { type: 'boolean', description: 'false = return only a one-line result (faster, for chained actions)' } };
const target = { ref: { type: 'number', description: 'element number from the latest snapshot' }, selector: { type: 'string' }, text: { type: 'string', description: 'visible text / aria-label to target' } };
const TOOL_DEFS = [
  T('browser_tabs', 'REAL Chrome of the user (his own profile, logins and open tabs): list ALL his open tabs in all windows (id, window, title, url; * = the tab you work in), or open a new tab (action=new, url), switch to one of HIS EXISTING tabs (action=switch with id, or match = text from its title/url, e.g. the router page he already opened — then work there and do NOT open a new window), or close one. When the user names a page he has open, go straight to action=switch with match=<a word from its title or address> (fastest — no need to list first; if several tabs match you get their ids). action=list with match filters the list.', { action: { type: 'string', enum: ['list', 'new', 'switch', 'close'] }, url: { type: 'string' }, id: { type: 'string' }, match: { type: 'string', description: 'text from the tab title or url: for switch (choose that tab) or list (filter)' }, first: { type: 'boolean', description: 'switch: if several tabs match, take the first' }, index: { type: 'number' } }),
  T('browser_navigate', 'REAL Chrome of the user (his own profile, logins and open tabs):open a URL (active tab, or a new tab with new_tab=true). Waits until the page settles and returns a code-level snapshot: title, url, numbered interactive elements [n] (links, buttons, inputs, incl. shadow DOM and iframes) and the visible text. No screenshot needed. Use the numbers with browser_click / browser_type.', { url: { type: 'string' }, new_tab: { type: 'boolean' }, ...snap, ...tab }, ['url']),
  T('browser_snapshot', 'REAL Chrome of the user (his own profile, logins and open tabs):re-read the current page as code: numbered interactive elements and visible text. Take a fresh snapshot after the page changes.', { ...tab }),
  T('browser_find', 'REAL Chrome of the user (his own profile, logins and open tabs):quickly list the snapshot elements whose label contains the given text (cheaper than reading the whole snapshot).', { text: { type: 'string' }, ...tab }, ['text']),
  T('browser_click', 'REAL Chrome of the user (his own profile, logins and open tabs):click an element by its snapshot number (ref), CSS selector, visible text, or x/y. Sends real mouse events at the element\'s exact position (works on YouTube, React apps, shadow DOM, iframes). Returns the new snapshot (or one line with snapshot=false).', { ...target, x: { type: 'number' }, y: { type: 'number' }, double: { type: 'boolean' }, button: { type: 'string', enum: ['left', 'right'] }, ...snap, ...tab }),
  T('browser_hover', 'REAL Chrome of the user (his own profile, logins and open tabs):move the mouse over an element (opens hover menus / tooltips).', { ...target, ...snap, ...tab }),
  T('browser_type', 'REAL Chrome of the user (his own profile, logins and open tabs): type text into an input (focuses it by ref/selector, clears it first unless clear=false). submit=true presses Enter afterwards (runs a search).', { text: { type: 'string' }, ref: { type: 'number' }, selector: { type: 'string' }, clear: { type: 'boolean' }, submit: { type: 'boolean' }, paste: { type: 'boolean', description: 'insert all the text at once (like paste) instead of typing key by key' }, ...snap, ...tab }, ['text']),
  T('browser_press_key', 'REAL Chrome of the user (his own profile, logins and open tabs):press keys, space-separated (Enter, Tab, Escape, ArrowDown, PageDown, Control+a, ...).', { key: { type: 'string' }, ...snap, ...tab }, ['key']),
  T('browser_select', 'REAL Chrome of the user (his own profile, logins and open tabs):choose an option in a <select> by value or visible label.', { ref: { type: 'number' }, selector: { type: 'string' }, value: { type: 'string' }, ...snap, ...tab }, ['value']),
  T('browser_upload', 'REAL Chrome of the user (his own profile, logins and open tabs):attach local file(s) to a file input (ref/selector).', { ref: { type: 'number' }, selector: { type: 'string' }, files: { type: 'array', items: { type: 'string' } }, ...snap, ...tab }, ['files']),
  T('browser_drag', 'REAL Chrome of the user (his own profile, logins and open tabs):drag from one element to another ({ref|selector|text} each).', { from: { type: 'object' }, to: { type: 'object' }, ...snap, ...tab }, ['from', 'to']),
  T('browser_scroll', 'REAL Chrome of the user (his own profile, logins and open tabs):scroll down/up by pixels (default 700), or scroll an element (ref) into view.', { direction: { type: 'string', enum: ['down', 'up'] }, amount: { type: 'number' }, ref: { type: 'number' }, ...snap, ...tab }),
  T('browser_screenshot', 'REAL Chrome of the user (his own profile, logins and open tabs):screenshot of the current tab (use only when you need to SEE the page; the snapshot is faster and exact).', { full_page: { type: 'boolean' }, ...tab }),
  T('browser_eval', 'REAL Chrome of the user (his own profile, logins and open tabs):run JavaScript in the page and return the JSON result (read data, check state such as video.paused, drive complex widgets).', { expression: { type: 'string' }, ...tab }, ['expression']),
  T('browser_get_text', 'REAL Chrome of the user (his own profile, logins and open tabs):full text of the page or of a CSS selector.', { selector: { type: 'string' }, ...tab }),
  T('browser_wait', 'REAL Chrome of the user (his own profile, logins and open tabs):wait for text / a selector to appear (timeout_sec, default 15), or wait N seconds.', { text: { type: 'string' }, selector: { type: 'string' }, seconds: { type: 'number' }, timeout_sec: { type: 'number' }, ...snap, ...tab }),
  T('browser_history', 'REAL Chrome of the user (his own profile, logins and open tabs):back / forward / reload.', { action: { type: 'string', enum: ['back', 'forward', 'reload'] }, ...snap, ...tab }),
  T('browser_batch', 'REAL Chrome of the user (his own profile, logins and open tabs):run several browser actions in ONE call (fastest way: no round trips). actions = [{tool:"navigate",args:{url}}, {tool:"type",args:{ref,text,submit:true}}, {tool:"click",args:{text:"..."}}, ...]. Stops at the first error and returns the per-action log plus the final snapshot. Note: refs change after navigation, so inside a batch target by text/selector after a page change.', { actions: { type: 'array', items: { type: 'object', properties: { tool: { type: 'string' }, args: { type: 'object' }, wait_ms: { type: 'number' } }, required: ['tool'] } }, ...tab }, ['actions'])
];

module.exports = { BrowserCtl, TOOL_DEFS, findChrome, SNAPSHOT_JS };
