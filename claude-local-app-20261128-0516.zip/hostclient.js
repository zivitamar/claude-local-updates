'use strict';
// ============================================================
//  Server-side client of the session host (HOT-UPDATE plan, stage 1.6).
//  connect({dataDir}) -> true when a host is reachable (EXE: CLAUDE_HOST_PIPE/TOKEN from main.js;
//  dev: CLAUDE_HOST=1 starts `node sessionhost/sessionhost.js` through a detached trampoline).
//  HostChild mimics the parts of a ChildProcess that cli_engine uses, plus line/seq/attach.
// ============================================================
const net = require('net');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn, execFileSync } = require('child_process');
const EventEmitter = require('events');
const P = require('./sessionhost/proto');

const ENV_PIPE = process.env.CLAUDE_HOST_PIPE || '';
const ENV_TOKEN = process.env.CLAUDE_HOST_TOKEN || '';
delete process.env.CLAUDE_HOST_TOKEN; // never inherited by anything the server spawns

const bus = new EventEmitter();
let conn = null;          // {sock, pipe, token}
let token = '';
let ridSeq = 0, widSeq = 0;
const children = new Map();   // sid -> HostChild
const spawnWait = new Map();  // rid -> HostChild
let listWait = [];
let hookFn = null;

const state = { active: false, hostPid: 0, hookPort: 0, codeHash: '', proto: 0, helloSessions: [] };

function send(obj) {
  if (!conn || conn.closed) return false;
  try { conn.sock.write(JSON.stringify(obj) + '\n'); return true; } catch { return false; }
}

class HostStdin extends EventEmitter {
  constructor(hc) { super(); this.hc = hc; this.ended = false; }
  get writable() { return !this.ended && this.hc.exitCode === null && !this.hc.lost; }
  write(data, wid, cb) {
    if (typeof wid === 'function') { cb = wid; wid = null; }
    if (!this.writable) { const e = new Error('write after end'); e.code = 'EPIPE'; process.nextTick(() => this.emit('error', e)); return false; }
    const w = wid || `a:${process.pid}:${++widSeq}`;
    send({ t: 'write', sid: this.hc.sid, wid: w, data: Buffer.isBuffer(data) ? data.toString('utf8') : String(data) });
    if (cb) process.nextTick(cb);
    return true;
  }
  end(data) { if (data != null) this.write(data); if (this.ended) return; this.ended = true; send({ t: 'end', sid: this.hc.sid }); }
  destroy() { this.end(); }
}

class HostChild extends EventEmitter {
  constructor(sid, key) {
    super();
    this.sid = sid; this.key = key || null;
    this.pid = undefined; this.killed = false; this.exitCode = null; this.isHosted = true;
    this.curSeq = 0; this.lost = false;
    this.stdin = new HostStdin(this);
  }
  _out(f) {
    if (f.seq <= this.curSeq) return;          // replay overlap: never deliver a line twice
    this.curSeq = f.seq;
    if (f.t === 'out') this.emit('line', f.seq, f.s, f.line);
    else if (f.t === 'exit') {
      this.exitCode = f.code;
      this.emit('exit', f.code, null);
      this.emit('close', f.code, null);
    }
  }
  attach(fromSeq) {
    if (fromSeq == null) fromSeq = this.curSeq + 1;
    return new Promise(resolve => { this.once('caughtUp', resolve); send({ t: 'attach', sid: this.sid, fromSeq }); });
  }
  ack(seq) { send({ t: 'ack', sid: this.sid, seq: seq == null ? this.curSeq : seq }); }
  release() { send({ t: 'release', sid: this.sid }); children.delete(this.sid); }
  killTree() { this.killed = true; send({ t: 'kill', sid: this.sid, tree: true }); }
  kill() { this.killTree(); return true; }
  _lost() {
    if (this.exitCode !== null || this.lost) return;
    this.lost = true;
    this.emit('error', Object.assign(new Error('session host disconnected'), { code: 'EHOSTLOST' }));
  }
}

function onFrame(f) {
  switch (f.t) {
    case 'out': case 'exit': { const c = children.get(f.sid); if (c) c._out(f); return; }
    case 'caughtUp': { const c = children.get(f.sid); if (c) c.emit('caughtUp', f.seq); return; }
    case 'spawned': {
      const c = spawnWait.get(f.rid); if (!c) return; spawnWait.delete(f.rid);
      c.pid = f.pid; c.emit('spawn'); return;
    }
    case 'err': {
      if (f.rid != null && spawnWait.has(f.rid)) {
        const c = spawnWait.get(f.rid); spawnWait.delete(f.rid); children.delete(c.sid);
        const e = Object.assign(new Error(f.msg || f.code), { code: f.code === 'denied' ? 'EACCES' : (f.code || 'ESPAWN') });
        c.exitCode = -1; c.emit('error', e); c.emit('close', -1, null); return;
      }
      if (f.sid) { const c = children.get(f.sid); if (c) c.stdin.emit('error', Object.assign(new Error(f.msg || f.code), { code: f.code === 'gone' ? 'EPIPE' : f.code, wid: f.wid })); }
      return;
    }
    case 'wrote': { const c = children.get(f.sid); if (c) c.emit('wrote', f.wid, f.seq, f.dup); return; }
    case 'sessions': { const w = listWait; listWait = []; for (const r of w) r(f.items || []); return; }
    case 'hook': return onHook(f);
    default: return;
  }
}

function onHook(f) {
  const reply = (status, body) => send({ t: 'hookReply', hid: f.hid, status, body });
  if (!hookFn) return reply(503, '{}');
  Promise.resolve().then(() => hookFn({ hid: f.hid, convId: f.convId, kind: f.kind, body: f.body }))
    .then(r => { r = r || {}; reply(r.status || 200, r.body == null ? {} : r.body); })
    .catch(e => reply(500, JSON.stringify({ error: String(e && e.message || e) })));
}

function openPipe(pipe, tok, timeoutMs) {
  return new Promise(resolve => {
    let done = false;
    const sock = net.connect(pipe);
    const c = { sock, pipe, closed: false };
    const fin = ok => { if (done) return; done = true; clearTimeout(t); resolve(ok ? c : null); if (!ok) { try { sock.destroy(); } catch { } } };
    const t = setTimeout(() => fin(false), timeoutMs);
    sock.setEncoding('utf8');
    sock.on('error', () => fin(false));
    sock.on('connect', () => sock.write(JSON.stringify({ t: 'hello', proto: P.PROTO, token: tok, gen: Date.now(), pid: process.pid }) + '\n'));
    const reader = P.frameReader(f => {
      if (!done) {
        if (f.t === 'helloOk') { c.hello = f; fin(true); }
        else { c.err = f.code; bus.emit('helloErr', f.code); fin(false); }
        return;
      }
      onFrame(f);
    }, () => { try { sock.destroy(); } catch { } });
    sock.on('data', reader);
    sock.on('close', () => {
      c.closed = true;
      if (!done) return fin(false);
      if (conn === c) {
        conn = null; state.active = false;
        for (const ch of children.values()) ch._lost();
        for (const ch of spawnWait.values()) ch._lost();
        spawnWait.clear();
        bus.emit('disconnect');
      }
    });
  });
}

// ---------- dev mode: self-spawned host ----------
function hostDir(dataDir) { return path.join(dataDir || process.env.DATA_DIR || path.join(__dirname, 'data'), 'host'); }
function readJson(f) { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } }
const TRAMPOLINE = "const{spawn}=require('child_process');const c=spawn(process.execPath,[process.env.CLAUDE_HOST_ENTRY],{detached:true,stdio:'ignore',windowsHide:true,env:process.env});c.unref();process.exit(0);";

async function devHost(dataDir, timeoutMs) {
  const dir = hostDir(dataDir);
  const info = readJson(path.join(dir, 'dev-host.json'));
  let tok = ''; try { tok = fs.readFileSync(path.join(dir, 'token'), 'utf8').trim(); } catch { }
  if (info && info.pipe && tok && info.proto === P.PROTO) {
    const c = await openPipe(info.pipe, tok, timeoutMs);
    if (c) return { c, tok };
  }
  // start a new host through a trampoline (survives taskkill /T of this server; measured in the plan, 1.2)
  fs.mkdirSync(dir, { recursive: true });
  tok = crypto.randomBytes(32).toString('hex');
  const tokFile = path.join(dir, 'token');
  fs.writeFileSync(tokFile, tok);
  try { execFileSync('icacls', [tokFile, '/inheritance:r', '/grant:r', `${process.env.USERNAME}:F`], { stdio: 'ignore', windowsHide: true }); } catch { }
  const pipe = `\\\\.\\pipe\\claude-local-host-${crypto.randomBytes(8).toString('hex')}`;
  const infoFile = path.join(dir, 'dev-host.json');
  try { fs.unlinkSync(infoFile); } catch { }
  const env = Object.assign({}, process.env, {
    CLAUDE_HOST_PIPE: pipe, CLAUDE_HOST_TOKEN: tok, CLAUDE_HOST_STATE: dir, CLAUDE_HOST_INFO: infoFile,
    CLAUDE_HOST_DEV: '1', CLAUDE_HOST_ENTRY: path.join(__dirname, 'sessionhost', 'sessionhost.js'),
  });
  const t = spawn(process.execPath, ['-e', TRAMPOLINE], { detached: true, stdio: 'ignore', windowsHide: true, env });
  t.unref();
  const t0 = Date.now();
  while (Date.now() - t0 < 5000) {
    const i = readJson(infoFile);
    if (i && i.pipe === pipe) { const c = await openPipe(pipe, tok, timeoutMs); if (c) return { c, tok }; break; }
    await new Promise(r => setTimeout(r, 50));
  }
  return null;
}

async function connect(opts = {}) {
  if (state.active) return true;
  const timeoutMs = opts.timeoutMs || 3000;
  let pipe = opts.pipe || ENV_PIPE, tok = opts.token || ENV_TOKEN;
  let c = null;
  if (pipe && tok) c = await openPipe(pipe, tok, timeoutMs);
  else if (process.env.CLAUDE_HOST === '1') { const r = await devHost(opts.dataDir, timeoutMs); if (r) { c = r.c; tok = r.tok; } }
  if (!c) return false;
  conn = c; token = tok;
  Object.assign(state, { active: true, hostPid: c.hello.hostPid, hookPort: c.hello.hookPort, codeHash: c.hello.codeHash, proto: c.hello.proto, helloSessions: c.hello.sessions || [] });
  bus.emit('connect', state);
  return true;
}

function spawnRaw(key, cmd, args, o = {}) {
  const sid = o.sid || ('h_' + crypto.randomUUID());
  const hc = new HostChild(sid, key);
  if (!state.active) { process.nextTick(() => { hc.exitCode = -1; hc.emit('error', Object.assign(new Error('session host not connected'), { code: 'EHOSTLOST' })); hc.emit('close', -1, null); }); return hc; }
  const rid = ++ridSeq;
  children.set(sid, hc); spawnWait.set(rid, hc);
  send({ t: 'spawn', rid, sid, key: key || null, cmd, args: args || [], cwd: o.cwd || null, env: o.env || null, verbatim: !!o.verbatim });
  return hc;
}
const spawnCli = (key, file, args, o = {}) => spawnRaw(key, file, args, o);
function spawnShell(key, command, o = {}) {
  const sysCmd = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'cmd.exe');
  return spawnRaw(Object.assign({ kind: 'shell' }, key || {}), sysCmd, ['/d', '/s', '/c', `"${command}"`], Object.assign({}, o, { verbatim: true }));
}
function child(sid) {
  let c = children.get(sid);
  if (!c) {
    c = new HostChild(sid, null);
    const s = state.helloSessions.find(x => x.sid === sid);
    if (s) { c.pid = s.pid; c.key = s.key; if (s.state === 'exited') c._exitedInHost = s.exitCode; }
    children.set(sid, c);
  }
  return c;
}
function sessions() {
  if (!state.active) return Promise.resolve([]);
  return new Promise(r => { listWait.push(r); send({ t: 'list' }); });
}
function disconnect() { if (conn) { try { conn.sock.end(); } catch { } } }

module.exports = {
  connect, spawnCli, spawnShell, child, sessions, disconnect, HostChild, bus,
  ack: (sid, seq) => send({ t: 'ack', sid, seq }),
  release: sid => { children.delete(sid); return send({ t: 'release', sid }); },
  gate: (convId, policy = {}) => send({ t: 'gate', convId, stop: policy.stop === 'block' ? 'block' : 'allow', reason: policy.reason || '' }),
  onHook: fn => { hookFn = fn; },
  detaching: () => send({ t: 'detaching' }),
  sessTok: convId => P.sessTok(token, convId),
  hookUrl: (convId, kind) => `http://127.0.0.1:${state.hookPort}/h/${encodeURIComponent(convId)}/${P.sessTok(token, convId)}/${kind}`,
  get active() { return state.active; },
  get hostPid() { return state.hostPid; },
  get hookPort() { return state.hookPort; },
  get codeHash() { return state.codeHash; },
  get helloSessions() { return state.helloSessions; },
  _reset() { if (conn) { try { conn.sock.destroy(); } catch { } } conn = null; state.active = false; children.clear(); spawnWait.clear(); }, // tests
};
