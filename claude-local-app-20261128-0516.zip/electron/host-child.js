'use strict';
// ============================================================
//  "Claude Local sessions" - the session host process of the EXE (HOT-UPDATE plan, stage 1.3).
//  main.js runs it with utilityProcess.fork (NOT inside the server's process tree), so restarting the
//  server does not kill running claude.exe children. The code itself is pinned by main.js to
//  %LOCALAPPDATA%\ClaudeLocal\host\bin\<sha12>\sessionhost.js (CLAUDE_HOST_ENTRY).
//  env: CLAUDE_HOST_PIPE, CLAUDE_HOST_TOKEN, CLAUDE_HOST_ENTRY, CLAUDE_HOST_STATE
//  parent messages: {type:'drain', graceMs} | {type:'stats'} | {type:'retire'}
// ============================================================
const path = require('path');
const pipe = process.env.CLAUDE_HOST_PIPE;
const token = process.env.CLAUDE_HOST_TOKEN;
const entry = process.env.CLAUDE_HOST_ENTRY || path.join(__dirname, '..', 'sessionhost', 'sessionhost.js');
const stateDir = process.env.CLAUDE_HOST_STATE || null;
delete process.env.CLAUDE_HOST_TOKEN; // never inherited by children

function send(msg) {
  try {
    if (process.parentPort) process.parentPort.postMessage(msg);
    else if (process.send) process.send(msg);
  } catch { }
}

let host = null;
async function onMessage(m) {
  if (!m || !host) return;
  if (m.type === 'drain') { const killed = await host.drain({ graceMs: Number(m.graceMs) || 3000 }); send({ type: 'drained', killed }); }
  else if (m.type === 'stats') send(Object.assign({ type: 'stats' }, host.stats()));
  else if (m.type === 'retire') { if (host.retire()) setTimeout(() => process.exit(0), 50); else send({ type: 'retire-refused', sessions: host.stats().running }); }
}
if (process.parentPort) process.parentPort.on('message', e => onMessage(e && e.data)); else process.on('message', onMessage);

const H = require(entry);
H.startHost({ pipe, token, stateDir, devMode: false, onEvent: ev => send(Object.assign({ type: 'host-event' }, ev)) })
  .then(h => { host = h; send({ type: 'ready', pid: process.pid, hookPort: h.hookPort, proto: H.PROTO, codeHash: h.codeHash }); })
  .catch(e => { console.error('[host-child] failed to start:', e && e.message); process.exit(1); });
