'use strict';
// ============================================================
//  Claude מקומי — מעטפת Electron.
//  השרת (server.js) רץ כתהליך נפרד (utilityProcess -> electron/server-child.js), לא בתוך תהליך החלון:
//  קריאת fs סינכרונית או כתיבת JSON גדולה בשרת לא יכולות להקפיא את הממשק.
//  main.js רק: מרים את השרת, ממתין שיענה על /api/config, טוען את הכתובת בחלון, ומפקח עליו:
//    יציאה בקוד 75 = בקשת restart  -> שרת חדש + טעינת החלון מחדש
//    יציאה בקוד 0  = בקשת shutdown -> סוגרים את האפליקציה
//    כל יציאה אחרת = קריסה         -> הרמה מחדש (עד 3 פעמים בדקה), אחרת הודעת שגיאה
//  בסגירה/restart הורגים את כל עץ התהליכים של השרת (taskkill /T /F).
//  החלון בלבד: ברירות המחדל של Chromium, בלי הזרקת CSS/JS, בלי כותרת מותאמת, בלי תפריט, זום 100%.
//
//  משתני סביבה (לבדיקות / פיתוח):
//    CLAUDE_DATA_DIR    תיקיית נתונים (עוקף הכול; בלי העתקה מהתיקייה הישנה)
//    CLAUDE_USER_DATA   תיקיית userData של Electron (בידוד מלא; בלי העתקה מהתיקייה הישנה)
//    CLAUDE_LEGACY_DATA תיקיית מקור להעתקה חד-פעמית (לבדיקת ההעתקה)
//    CLAUDE_PORT        פורט מועדף (ברירת מחדל 3456)
//    CLAUDE_DEVTOOLS=1  מאפשר Ctrl+Shift+I / F12
//  שורת פקודה: --remote-debugging-port=NNNN עובד כרגיל (Chromium).
// ============================================================
const path = require('path');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');
const { spawnSync } = require('child_process');
const { app, BrowserWindow, Menu, shell, dialog, ipcMain, screen, session, clipboard, utilityProcess } = require('electron');

const APP_NAME = 'Claude Local';
const TITLE = 'Claude מקומי';
const BG = '#1f1e1d';                 // רק צבע הרקע לפני הציור הראשון (מונע הבהוב לבן); לא משפיע על הדף
const APP_ROOT = path.join(__dirname, '..');
const PREFERRED_PORT = 3456;
const HOST = '127.0.0.1';
const EXIT_RESTART = 75;
const DEVTOOLS = process.env.CLAUDE_DEVTOOLS === '1';
// בדיקות בלבד: החלון לא מוצג אף פעם (נבדק דרך --remote-debugging-port) — כדי שבדיקה של ה-EXE לא תקפיץ חלון על המסך
// (חלון שלא הוצג אף פעם לא מצייר פריימים — לכן הוא "מוצג" מחוץ למסך, שקוף, בלי שורת משימות ובלי לקחת פוקוס)
const HIDDEN_WINDOW = process.env.CLAUDE_HIDDEN_WINDOW === '1' && !!process.env.CLAUDE_USER_DATA;
// עותק בדיקה גם מושתק לגמרי (שום צליל לא יוצא לרמקולים) — הצלילים עצמם נבדקים מתוך גרף השמע, לא באוזן
if (HIDDEN_WINDOW) { app.commandLine.appendSwitch('disable-features', 'CalculateNativeWinOcclusion'); app.commandLine.appendSwitch('disable-renderer-backgrounding'); app.commandLine.appendSwitch('mute-audio'); }
const RELAUNCHED = process.argv.includes('--relaunched');
// התיקייה הישנה (גרסת הדפדפן). משמשת רק להעתקה חד-פעמית בהרצה ראשונה.
const LEGACY_DATA_HARDCODED = 'C:\\Users\\zivit\\OneDrive\\שולחן העבודה\\קלוד API\\data';

// ---------- נתיבים: חייב לקרות לפני app.ready ----------
app.setName(APP_NAME);
const USER_DATA = process.env.CLAUDE_USER_DATA ? path.resolve(process.env.CLAUDE_USER_DATA) : path.join(app.getPath('appData'), APP_NAME);
try { fs.mkdirSync(USER_DATA, { recursive: true }); } catch { }
app.setPath('userData', USER_DATA);
const DATA_DIR = process.env.CLAUDE_DATA_DIR ? path.resolve(process.env.CLAUDE_DATA_DIR) : path.join(USER_DATA, 'data');

// ---------- לוג לקובץ (אין קונסול באפליקציית GUI) ----------
const LOG_FILE = path.join(USER_DATA, 'app.log');
try { if (fs.existsSync(LOG_FILE) && fs.statSync(LOG_FILE).size > 2 * 1024 * 1024) fs.renameSync(LOG_FILE, LOG_FILE + '.1'); } catch { }
function fileLog(level, args) {
  try {
    const line = `[${new Date().toISOString()}] ${level} ` + args.map(a => (typeof a === 'string' ? a : (a && a.stack) || JSON.stringify(a))).join(' ') + '\n';
    fs.appendFileSync(LOG_FILE, line);
  } catch { }
}
for (const lvl of ['log', 'info', 'warn', 'error']) {
  const orig = console[lvl].bind(console);
  console[lvl] = (...a) => { fileLog(lvl.toUpperCase(), a); try { orig(...a); } catch { } };
}
for (const s of [process.stdout, process.stderr]) { try { s && s.on && s.on('error', () => { }); } catch { } }
// חריגה לא תפוסה לא צריכה להקפיץ דיאלוג שגיאה של Electron באמצע עבודה
process.on('uncaughtException', e => fileLog('UNCAUGHT', [e]));
process.on('unhandledRejection', e => fileLog('UNHANDLED-REJECTION', [e]));

let win = null;
let ORIGIN = '';         // http://127.0.0.1:PORT
let child = null;        // utilityProcess של השרת
let stopping = false;
let buildInfo = {};
try { buildInfo = JSON.parse(fs.readFileSync(path.join(APP_ROOT, 'build-info.json'), 'utf8')); } catch { }
const VERSION = (app.getVersion() || '0.0.0') + (buildInfo.builtAt ? '+' + buildInfo.builtAt : (app.isPackaged ? '' : '+dev'));
// ---------- "קוד חי": הבנייה האחרונה (build.js מפרסם אותה ל-%LOCALAPPDATA%\ClaudeLocal\live) ----------
// השרת והממשק נטענים משם אם הבנייה שם חדשה (או שווה) לזו שבתוך ה-EXE. Ctrl+Shift+R מרים את השרת מחדש מהבנייה האחרונה.
const LIVE_DIR = process.env.CLAUDE_LIVE_DIR || path.join(process.env.LOCALAPPDATA || os.homedir(), 'ClaudeLocal', 'live');
function codeRoot() { return codeCandidates()[0]; }
// ---------- "לעולם לא קורס" (הבעלים 27/11): בנייה שלא עולה מסומנת פגומה, ועוברים אוטומטית לבנייה הקודמת שעבדה ←
//  ואם אף בנייה חיה לא עולה — הקוד שבתוך ה-EXE עצמו. אין חלון שגיאה "השרת לא עלה"; אם גם זה נכשל, מנסים שוב בלי סוף.
const BAD_FILE = path.join(LIVE_DIR, 'bad-builds.json');
const readBad = () => { try { return JSON.parse(fs.readFileSync(BAD_FILE, 'utf8')) || {}; } catch { return {}; } };
function markBad(code, why) {
  if (!code || code.source !== 'live') return;
  const b = readBad(); b[path.basename(code.dir).toLowerCase()] = { at: new Date().toISOString(), why: String(why || '').slice(0, 300) };
  try { fs.mkdirSync(LIVE_DIR, { recursive: true }); fs.writeFileSync(BAD_FILE, JSON.stringify(b, null, 1)); } catch { }
  console.error('[app] live build marked BAD:', code.dir, why);
}
function codeCandidates() {
  const packaged = { dir: APP_ROOT, builtAt: buildInfo.builtAt || (app.isPackaged ? '' : 'dev'), source: app.isPackaged ? 'packaged' : 'dev' };
  if (!app.isPackaged || process.env.CLAUDE_NO_LIVE === '1') return [packaged];
  const bad = readBad(), out = [], seen = new Set();
  const add = (dir, builtAt) => { if (!dir) return; const k = path.basename(dir).toLowerCase(); if (seen.has(k) || bad[k] || !fs.existsSync(path.join(dir, 'server.js'))) return; if (String(builtAt || '') < String(buildInfo.builtAt || '')) return; seen.add(k); out.push({ dir, builtAt, source: 'live' }); };
  try { const cur = JSON.parse(fs.readFileSync(path.join(LIVE_DIR, 'current.json'), 'utf8')); if (cur) add(cur.dir, cur.builtAt); } catch { }
  // בנייה פגומה ב-current → הבניות הקודמות (מהחדשה לישנה)
  try {
    const dirs = fs.readdirSync(LIVE_DIR, { withFileTypes: true }).filter(d => d.isDirectory() && /^\d{8}-\d{4}/.test(d.name)).map(d => d.name).sort().reverse();
    for (const n of dirs) { let b = n.slice(0, 13); try { b = JSON.parse(fs.readFileSync(path.join(LIVE_DIR, n, 'build-info.json'), 'utf8')).builtAt || b; } catch { } add(path.join(LIVE_DIR, n), b); }
  } catch { }
  out.push(packaged);
  return out;
}
function rememberGood(code) {
  if (!code || code.source !== 'live') return;
  try { const f = path.join(LIVE_DIR, 'current.json'); const cur = JSON.parse(fs.readFileSync(f, 'utf8')); if (cur && path.resolve(cur.dir || '') === path.resolve(code.dir)) return; } catch { }
  try { fs.writeFileSync(path.join(LIVE_DIR, 'current.json'), JSON.stringify({ dir: code.dir, builtAt: code.builtAt, source: 'fallback' })); console.log('[app] current.json → last good build', code.dir); } catch { }
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

// ---------- נעילת מופע יחיד ----------
function focusWindow() {
  if (!win || win.isDestroyed() || HIDDEN_WINDOW) return;
  console.log('[app] focus requested (another launch)');
  if (win.isMinimized()) win.restore();
  if (!win.isVisible()) win.show();
  // Windows לא תמיד מרשה לתהליך ברקע להקפיץ חלון לחזית — "תמיד למעלה" לרגע + steal מביאים אותו קדימה בוודאות
  try { win.setAlwaysOnTop(true); win.show(); win.focus(); app.focus({ steal: true }); win.moveTop(); } catch { }
  setTimeout(() => { try { if (win && !win.isDestroyed()) win.setAlwaysOnTop(false); } catch { } }, 400);
}
app.on('second-instance', focusWindow);

async function acquireLock() {
  // אחרי relaunch המופע הישן עוד עשוי להחזיק את הנעילה כמה מאות מילי-שניות
  const tries = RELAUNCHED ? 30 : 1;
  for (let i = 0; i < tries; i++) {
    if (app.requestSingleInstanceLock()) return true;
    if (i < tries - 1) await sleep(300);
  }
  return false;
}

// ---------- העתקה חד-פעמית של נתונים מהתיקייה הישנה ----------
function migrateLegacyData() {
  // כשיש עקיפה בסביבה (בדיקות/בידוד) לא נוגעים בנתוני האמת של הבעלים, אלא אם ביקשו במפורש CLAUDE_LEGACY_DATA
  if (process.env.CLAUDE_DATA_DIR) return;
  if (process.env.CLAUDE_USER_DATA && !process.env.CLAUDE_LEGACY_DATA) return;
  if (fs.existsSync(path.join(DATA_DIR, 'config.json'))) return;
  const candidates = [];
  if (process.env.CLAUDE_LEGACY_DATA) candidates.push(path.resolve(process.env.CLAUDE_LEGACY_DATA));
  else {
    if (!app.isPackaged) candidates.push(path.join(APP_ROOT, 'data'));
    try { candidates.push(path.join(app.getPath('desktop'), 'קלוד API', 'data')); } catch { }
    candidates.push(LEGACY_DATA_HARDCODED);
  }
  const src = candidates.find(c => path.resolve(c).toLowerCase() !== path.resolve(DATA_DIR).toLowerCase() && fs.existsSync(path.join(c, 'config.json')));
  if (!src) return;
  fs.mkdirSync(DATA_DIR, { recursive: true });
  for (const name of ['config.json', 'usage.json', 'projects.json', 'instructions', 'conversations', 'agents', 'research']) {
    const from = path.join(src, name);
    if (!fs.existsSync(from)) continue;
    try { fs.cpSync(from, path.join(DATA_DIR, name), { recursive: true, force: false, errorOnExist: false }); }
    catch (e) { console.error('[migrate] failed for', name, e.message); }
  }
  try { fs.writeFileSync(path.join(DATA_DIR, 'migrated-from.txt'), `Copied (not moved) from:\n${src}\nat ${new Date().toISOString()}\n`, 'utf8'); } catch { }
  console.log('[migrate] copied legacy data from', src);
}

// ---------- תהליך השרת ----------
const PORT_FILE = path.join(USER_DATA, 'port.json');
function readSavedPort() { try { const p = Number(JSON.parse(fs.readFileSync(PORT_FILE, 'utf8')).port); return p > 0 && p < 65536 ? p : 0; } catch { return 0; } }

function killTree(pid) {
  // הורג את השרת וכל התהליכים שהוא הפעיל (PowerShell/cmd של כלי הצ'אט וכו'). חייב לרוץ כשהשרת עוד חי, אחרת צאצאיו יתומים.
  if (!pid) return;
  try { spawnSync('taskkill', ['/PID', String(pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore', timeout: 8000 }); } catch { }
}
function sendToChild(c, msg) { try { c && c.postMessage(msg); } catch { } }

// ---------- HOT-UPDATE 1.4: "Claude Local sessions" — the session host (keeps claude.exe alive across server restarts) ----------
// The host is a separate utilityProcess (NOT in the server's tree). Its code is pinned to HOST_ROOT\bin\<sha12> so a new live
// build never changes the code under a running host. Any failure here => host = null => exactly the old behavior.
// Switch: CLAUDE_HOST=0 in env, or "sessionHost": false in data\config.json.
const HOST_ROOT = process.env.CLAUDE_HOST_ROOT ? path.resolve(process.env.CLAUDE_HOST_ROOT)
  : process.env.CLAUDE_USER_DATA ? path.join(USER_DATA, 'host')
    : path.join(process.env.LOCALAPPDATA || os.homedir(), 'ClaudeLocal', 'host');
const HOST_PIPE = `\\\\.\\pipe\\claude-local-host-${crypto.randomBytes(8).toString('hex')}`;  // fixed for this app run:
const HOST_TOKEN = crypto.randomBytes(32).toString('hex');                                      // a restarted host reuses them
let host = null;          // {proc, pid, codeHash, proto, hookPort, exited, code, expected}
const hostCrashes = [];
function hostEnabled() {
  if (process.env.CLAUDE_HOST === '0') return false;
  try { if (JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'config.json'), 'utf8')).sessionHost === false) return false; } catch { }
  return true;
}
function hostAlive() { return !!(host && host.code === undefined); }
// same hash as sessionhost.js codeHash(): sha256(sessionhost.js + proto.js), first 12 hex
function hostCodeHash(dir) {
  try {
    const h = crypto.createHash('sha256');
    for (const f of ['sessionhost.js', 'proto.js']) h.update(fs.readFileSync(path.join(dir, f)));
    return h.digest('hex').slice(0, 12);
  } catch { return ''; }
}
function hostSourceDir(codeDir) {
  for (const d of [path.join(codeDir || APP_ROOT, 'sessionhost'), path.join(APP_ROOT, 'sessionhost')])
    if (hostCodeHash(d)) return d;
  return '';
}
// copies sessionhost/{sessionhost,proto}.js of the live (or packaged) code to HOST_ROOT\bin\<sha12>; returns {entry, hash} or null
function pinHostCode(codeDir) {
  const src = hostSourceDir(codeDir);
  if (!src) return null;
  const hash = hostCodeHash(src);
  const dest = path.join(HOST_ROOT, 'bin', hash);
  if (hostCodeHash(dest) !== hash) {
    fs.mkdirSync(dest, { recursive: true });
    for (const f of ['proto.js', 'sessionhost.js']) {
      const tmp = path.join(dest, f + '.' + process.pid + '.tmp');
      fs.copyFileSync(path.join(src, f), tmp);
      fs.renameSync(tmp, path.join(dest, f));
    }
    if (hostCodeHash(dest) !== hash) throw new Error('pinned host code hash mismatch');
  }
  return { entry: path.join(dest, 'sessionhost.js'), hash };
}
function sendToHost(msg) { if (hostAlive()) sendToChild(host.proc, msg); }
// one request/reply over postMessage (stats / drain); resolves null on timeout or when the host is gone
function askHost(msg, replyType, ms) {
  return new Promise(resolve => {
    if (!hostAlive()) return resolve(null);
    const h = host;
    const done = v => { clearTimeout(t); try { h.proc.removeListener('message', on); } catch { } resolve(v); };
    const on = m => { if (m && m.type === replyType) done(m); };
    const t = setTimeout(() => done(null), ms);
    h.proc.on('message', on);
    h.exited.then(() => done(null));
    sendToChild(h.proc, msg);
  });
}
function startHost() {
  return new Promise(resolve => {
    if (!hostEnabled()) { console.log('[app] session host disabled (CLAUDE_HOST=0 / sessionHost:false)'); return resolve(null); }
    let pinned;
    try { pinned = pinHostCode(codeRoot().dir); } catch (e) { console.error('[app] host code pin failed:', e && e.message); }
    if (!pinned) { console.log('[app] no session host code - old mode'); return resolve(null); }
    try { fs.mkdirSync(HOST_ROOT, { recursive: true }); } catch { }
    const env = { ...process.env, CLAUDE_HOST_PIPE: HOST_PIPE, CLAUDE_HOST_TOKEN: HOST_TOKEN, CLAUDE_HOST_ENTRY: pinned.entry, CLAUDE_HOST_STATE: HOST_ROOT };
    delete env.ELECTRON_RUN_AS_NODE;
    delete env.CLAUDE_DATA_DIR;
    let proc;
    try { proc = utilityProcess.fork(path.join(__dirname, 'host-child.js'), [], { env, cwd: os.homedir(), stdio: 'pipe', serviceName: 'Claude Local sessions' }); }
    catch (e) { console.error('[app] host fork failed:', e && e.message); return resolve(null); }
    const info = { proc, pid: proc.pid, codeHash: pinned.hash, proto: 0, hookPort: 0, expected: false };
    info.exited = new Promise(res => { info._resolveExit = res; });
    const pipeLog = (stream, lvl) => stream && stream.on('data', d => { for (const l of String(d).split(/\r?\n/)) if (l.trim()) fileLog(lvl, ['[host]', l]); });
    pipeLog(proc.stdout, 'LOG'); pipeLog(proc.stderr, 'ERR');
    let settled = false;
    const fail = why => { if (settled) return; settled = true; clearTimeout(timer); console.error('[app] session host not ready (' + why + ') - old mode'); info.expected = true; if (info.code === undefined) killTree(proc.pid); resolve(null); };
    const timer = setTimeout(() => fail('timeout 5s'), 5000);
    proc.on('message', m => {
      if (m && m.type === 'ready' && !settled) {
        settled = true; clearTimeout(timer);
        Object.assign(info, { pid: m.pid || proc.pid, proto: Number(m.proto) || 0, hookPort: m.hookPort || 0, codeHash: m.codeHash || pinned.hash });
        host = info;
        console.log(`[app] session host pid=${info.pid} proto=${info.proto} code=${info.codeHash} hookPort=${info.hookPort}`);
        resolve(info);
      } else if (m && m.type === 'host-event') fileLog('LOG', ['[host-event]', JSON.stringify(m)]);
    });
    proc.on('exit', code => {
      info.code = code; info._resolveExit(code);
      if (!settled) return fail('exited with code ' + code);
      onHostExit(info, code);
    });
  });
}
function onHostExit(info, code) {
  if (info !== host) return;
  host = null;
  if (stopping || info.expected) return;
  console.error('[app] session host exited unexpectedly, code', code);
  const now = Date.now();
  hostCrashes.push(now); while (hostCrashes.length && now - hostCrashes[0] > 60000) hostCrashes.shift();
  if (hostCrashes.length > 3) { console.error('[app] session host keeps crashing - staying in old mode until the next server restart'); return; }
  setTimeout(() => { if (!stopping && !host) startHost().catch(() => { }); }, 1000);   // same pipe+token: the server reconnects
}
async function stopHost() {
  const h = host;
  if (!h) return;
  h.expected = true;
  sendToChild(h.proc, { type: 'retire' });
  await Promise.race([h.exited, sleep(2000)]);
  if (h.code === undefined) { killTree(h.pid); await Promise.race([h.exited, sleep(3000)]); }
  if (host === h) host = null;
}
async function restartHost(reason) {
  console.log('[app] restarting session host:', reason);
  await stopHost();
  return startHost();
}
// the live code carries a different host than the running one AND the host has no sessions -> safe to replace now
async function hostStale() {
  if (!hostAlive()) return false;
  const live = hostCodeHash(hostSourceDir(codeRoot().dir));
  if (!live || live === host.codeHash) return false;
  const st = await askHost({ type: 'stats' }, 'stats', 1500);
  return !!(st && Number(st.sessions) === 0);
}

// מרים שרת חדש. prefs = פורטים מועדפים לפי סדר. מחזיר {proc, port, exited}
function spawnServer(prefs, code = codeRoot()) {
  return new Promise((resolve, reject) => {
    const env = { ...process.env, DATA_DIR, NO_BROWSER: '1', CLAUDE_SUPERVISED: '1', CLAUDE_PORT_PREFS: prefs.join(','), CLAUDE_CODE_ROOT: code.dir, CLAUDE_CODE_SOURCE: code.source, CLAUDE_SHELL_VERSION: VERSION };
    console.log('[app] code:', code.source, code.builtAt, code.dir);
    delete env.ELECTRON_RUN_AS_NODE;      // שלא ידלוף לכלי המחשב שהשרת מפעיל
    delete env.CLAUDE_DATA_DIR;
    delete env.CLAUDE_HOST_PIPE; delete env.CLAUDE_HOST_TOKEN;
    // session host חי: השרת מתחבר אליו (hostclient.js) ומריץ דרכו את Claude — כך הפעלה מחדש / עדכון לא עוצרים אף תור
    if (hostAlive()) { env.CLAUDE_HOST_PIPE = HOST_PIPE; env.CLAUDE_HOST_TOKEN = HOST_TOKEN; }
    const proc = utilityProcess.fork(path.join(__dirname, 'server-child.js'), [], { env, cwd: os.homedir(), stdio: 'pipe', serviceName: 'Claude Local server' });
    let settled = false;
    const info = { proc, port: 0, expected: false, source: code.source, codeDir: code.dir };
    info.exited = new Promise(res => { info._resolveExit = res; });
    const pipe = (stream, lvl) => stream && stream.on('data', d => { for (const l of String(d).split(/\r?\n/)) if (l.trim()) fileLog(lvl, ['[server]', l]); });
    pipe(proc.stdout, 'LOG'); pipe(proc.stderr, 'ERR');
    const timer = setTimeout(() => { if (!settled) { settled = true; killTree(proc.pid); reject(new Error('השרת לא התחיל תוך 20 שניות')); } }, 20000);
    proc.on('message', m => {
      if (m && m.type === 'ready' && !settled) { settled = true; clearTimeout(timer); info.port = m.port; info.hostProto = Number(m.hostProto) || 0; resolve(info); }
      else if (m && m.type === 'focus') focusWindow(); // מופע נוסף ביקש להציג את החלון (דרך השרת — עובד גם בין מנהל/משתמש רגיל)
    });
    proc.on('exit', code => {
      info.code = code; info._resolveExit(code);
      if (!settled) { settled = true; clearTimeout(timer); reject(new Error('השרת נסגר מיד עם קוד ' + code)); return; }
      onServerExit(info, code);
    });
  });
}
async function waitForApi(port, ms = 15000) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    try { const r = await fetch(`http://${HOST}:${port}/api/config`, { signal: AbortSignal.timeout(1500) }); if (r.ok) return true; } catch { }
    await sleep(150);
  }
  return false;
}
async function bringUpOne(prefs, code) {
  const info = await spawnServer(prefs, code);
  if (!(await waitForApi(info.port))) { info.expected = true; killTree(info.proc.pid); throw new Error('השרת לא ענה על /api/config'); }
  return info;
}
// מנסה כל בנייה לפי הסדר (חיה נוכחית → חיות קודמות → הקוד שב-EXE). לא זורק לעולם: אם הכל נכשל — מחכה ומנסה שוב
async function bringUpServer(prefs) {
  let info = null;
  for (let round = 0; !info; round++) {
    for (const code of codeCandidates()) {
      try { info = await bringUpOne(prefs, code); rememberGood(code); break; }
      catch (e) { console.error('[app] build failed to start:', code.source, code.dir, e && e.message); if (/נסגר מיד/.test(String(e && e.message))) markBad(code, e && e.message); /* קריסה בעלייה = קוד שבור; איטיות לא נחשבת פגם */ }
    }
    if (!info) { if (stopping) throw new Error('stopping'); console.error('[app] no build started (round ' + round + ') — retrying'); await sleep(Math.min(30000, 2000 * (round + 1))); }
  }
  child = info;
  ORIGIN = `http://${HOST}:${info.port}`;
  try { fs.writeFileSync(PORT_FILE, JSON.stringify({ port: info.port })); } catch { }
  console.log(`[app] server pid=${info.proc.pid} ${ORIGIN} | data ${DATA_DIR}`);
  return info;
}

const crashes = [];
let restarting = null;
async function restartServer(reason) {
  if (stopping) return;
  if (restarting) return restarting;
  restarting = (async () => {
    console.log('[app] restarting server:', reason);
    const old = child;
    if (old) {
      old.expected = true;
      if (old.code === undefined && old.hostProto && hostAlive()) {
        // HOT-UPDATE: השרת מחובר ל-session host — מתנתק בלי לעצור אף תור (Claude ממשיך לרוץ במארח), והשרת החדש מאמץ
        sendToChild(old.proc, { type: 'detach', reason });
        await Promise.race([old.exited, sleep(Number(process.env.CLAUDE_DETACH_WAIT_MS) || 8000)]);
        if (old.code === undefined) { console.error('[app] server did not detach in time - killing it'); killTree(old.proc.pid); await Promise.race([old.exited, sleep(4000)]); }
      } else {
        sendToChild(old.proc, { type: 'abort-all' });
        if (old.code === undefined) { await sleep(300); killTree(old.proc.pid); await Promise.race([old.exited, sleep(4000)]); }
      }
    }
    child = null;
    // מארח חדש רק כשאין בו אף תור (קוד מארח חדש בעדכון) / המארח נפל — אחרת ממשיכים עם אותו מארח
    try { if (await hostStale()) await restartHost('new session host code, no sessions'); else if (!hostAlive()) await startHost(); }
    catch (e) { console.error('[app] session host check failed:', e && e.message); }
    const prefs = [...new Set([Number((ORIGIN.match(/:(\d+)$/) || [])[1]) || 0, Number(process.env.CLAUDE_PORT) || PREFERRED_PORT, readSavedPort()].filter(Boolean))];
    try { await bringUpServer(prefs); }
    catch (e) {
      console.error('[app] server restart failed:', e);
      return; // bringUpServer לא נכשל לעולם (רק כשסוגרים) — אין חלון שגיאה
    }
    if (win && !win.isDestroyed()) { try { await win.webContents.session.clearCache(); } catch { } win.loadURL(ORIGIN + '/'); }
  })().finally(() => { restarting = null; });
  return restarting;
}
function onServerExit(info, code) {
  if (stopping || info.expected || info !== child) return;
  child = null;
  console.log('[app] server exited with code', code);
  if (code === EXIT_RESTART) return void restartServer('requested by /api/restart');
  if (code === 0) { app.quit(); return; }              // /api/shutdown
  const now = Date.now();
  crashes.push(now); while (crashes.length && now - crashes[0] > 60000) crashes.shift();
  // קורס שוב ושוב → הבנייה הזו פגומה: מסמנים ועוברים לקודמת (לא חלון שגיאה, לא סגירה)
  if (crashes.length > 3) { markBad({ source: info.source, dir: info.codeDir },'crashed ' + crashes.length + 'x in 60s'); crashes.length = 0; }
  restartServer('server crashed, code ' + code);
}
function abortRunningWork() { if (child) sendToChild(child.proc, { type: 'abort-all' }); }

// ---------- מצב חלון ----------
const STATE_FILE = path.join(USER_DATA, 'window-state.json');
function loadState() { try { return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')) || {}; } catch { return {}; } }
function isOnScreen(b) {
  return screen.getAllDisplays().some(d => {
    const w = d.workArea;
    const iw = Math.min(b.x + b.width, w.x + w.width) - Math.max(b.x, w.x);
    const ih = Math.min(b.y + b.height, w.y + w.height) - Math.max(b.y, w.y);
    return iw >= 200 && ih >= 100 && b.y >= w.y - 20;
  });
}
let saveTimer = null;
function saveState() {
  if (!win || win.isDestroyed()) return;
  try {
    const nb = win.getNormalBounds();
    const st = { ...nb, maximized: win.isMaximized(), zoomLevel: win.webContents.getZoomLevel() };
    fs.writeFileSync(STATE_FILE, JSON.stringify(st));
  } catch { }
}
function saveStateSoon() { clearTimeout(saveTimer); saveTimer = setTimeout(saveState, 400); }

// ---------- עזרים ----------
function isLocalUrl(u) {
  try {
    if (u === 'about:blank') return true;
    const url = new URL(u);
    const port = new URL(ORIGIN).port;
    return url.origin === ORIGIN || url.origin === `http://localhost:${port}` || (url.protocol === 'blob:' && url.pathname.startsWith(ORIGIN));
  } catch { return false; }
}
function openExternalSafe(u) {
  try { if (/^(https?|mailto):/i.test(String(u))) { console.log('[external] open in default browser:', String(u).slice(0, 200)); shell.openExternal(String(u)); return true; } } catch { }
  console.log('[external] blocked (not http/https/mailto):', String(u).slice(0, 80));
  return false;
}

// ---------- חלון ----------
function createWindow() {
  const st = loadState();
  const wa = screen.getPrimaryDisplay().workArea;
  let width = Math.min(Number(st.width) || 1500, wa.width), height = Math.min(Number(st.height) || 950, wa.height);
  width = Math.max(width, Math.min(900, wa.width)); height = Math.max(height, Math.min(600, wa.height));
  const opts = {
    width, height, minWidth: 900, minHeight: 600,
    title: TITLE,
    backgroundColor: BG,
    show: false,
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      backgroundThrottling: false,   // הצ'אט ממשיך להתעדכן גם כשהחלון ברקע
      additionalArguments: ['--claude-version=' + VERSION]
    }
  };
  if (!app.isPackaged) opts.icon = path.join(APP_ROOT, 'build', 'icon.ico');   // באריזה האייקון כבר בתוך ה-exe
  if (Number.isFinite(st.x) && Number.isFinite(st.y) && isOnScreen({ x: st.x, y: st.y, width, height })) { opts.x = st.x; opts.y = st.y; }
  if (HIDDEN_WINDOW) Object.assign(opts, { x: -12000, y: -12000, skipTaskbar: true, focusable: false, opacity: 0 });

  win = new BrowserWindow(opts);
  if (st.maximized && !HIDDEN_WINDOW) win.maximize(); // maximize() מציג חלון מוסתר
  const wc = win.webContents;

  let shown = false;
  const showOnce = () => { if (shown || !win || win.isDestroyed()) return; shown = true; if (HIDDEN_WINDOW) { win.setOpacity(0); win.showInactive(); return; } win.show(); };
  win.once('ready-to-show', showOnce);
  setTimeout(showOnce, 4000);

  wc.on('dom-ready', () => { if (Number.isFinite(st.zoomLevel)) wc.setZoomLevel(st.zoomLevel); });   // 0 = 100% (ברירת מחדל)
  win.on('resize', saveStateSoon); win.on('move', saveStateSoon);
  win.on('maximize', saveStateSoon); win.on('unmaximize', saveStateSoon);
  win.on('close', saveState);
  win.on('closed', () => { win = null; });
  win.on('page-title-updated', e => { e.preventDefault(); });   // הכותרת קבועה (הדף מכריז על אותה כותרת בכל מקרה)

  // קישורים חיצוניים -> דפדפן ברירת המחדל. פנימיים (אותו origin) נפתחים בחלון משנה.
  wc.setWindowOpenHandler(({ url }) => {
    if (isLocalUrl(url)) return { action: 'allow', overrideBrowserWindowOptions: { autoHideMenuBar: true, backgroundColor: BG, title: TITLE } };
    openExternalSafe(url);
    return { action: 'deny' };
  });
  wc.on('will-navigate', (e, url) => {
    if (isLocalUrl(url)) return;
    e.preventDefault();       // כולל גרירת קובץ על החלון שהייתה מנווטת ל-file://
    openExternalSafe(url);
  });

  // קיצורי מקלדת (אין תפריט, אז מטפלים ידנית)
  const zoomBy = d => { const z = Math.max(-3, Math.min(5, Math.round((wc.getZoomLevel() + d) * 10) / 10)); wc.setZoomLevel(z); saveStateSoon(); };
  wc.on('before-input-event', (event, input) => {
    if (input.type !== 'keyDown') return;
    // לפי המקש הפיזי (input.code) — במקלדת בעברית R מגיע כ-"ר", אז key לבד לא מספיק
    const k = input.key, code = input.code || '', ctrl = input.control || input.meta;
    const kl = /^Key[A-Z]$/.test(code) ? code.slice(3).toLowerCase() : /^Digit\d$/.test(code) ? code.slice(5) : (k || '').toLowerCase();
    let handled = true;
    if (k === 'F11') win.setFullScreen(!win.isFullScreen());
    // Ctrl+Shift+R = רענון מלא: השרת עולה מחדש מהבנייה האחרונה (קוד חי) והחלון נטען מחדש — בלי לסגור את התוכנה. F5 / Ctrl+R = רענון החלון בלבד
    else if (ctrl && input.shift && !input.alt && kl === 'r') restartServer('Ctrl+Shift+R');
    else if (k === 'F5' || (ctrl && !input.alt && kl === 'r')) wc.reload();
    else if (DEVTOOLS && (k === 'F12' || (ctrl && input.shift && kl === 'i'))) wc.toggleDevTools();
    else if (ctrl && !input.alt && (k === '+' || k === '=' || k === 'Add')) zoomBy(0.5);
    else if (ctrl && !input.alt && (k === '-' || k === '_' || k === 'Subtract')) zoomBy(-0.5);
    else if (ctrl && !input.alt && (k === '0' || k === 'Insert')) { wc.setZoomLevel(0); saveStateSoon(); }
    else handled = false;
    if (handled) event.preventDefault();
  });
  wc.on('zoom-changed', (_e, dir) => zoomBy(dir === 'in' ? 0.5 : -0.5));   // Ctrl+גלגלת

  // תפריט קליק-ימני בסיסי (בלי תפריט אפליקציה אין אחד מובנה)
  wc.on('context-menu', (_e, p) => {
    const t = [];
    if (p.linkURL) t.push({ label: 'העתק כתובת קישור', click: () => clipboard.writeText(p.linkURL) }, { label: 'פתח בדפדפן', click: () => openExternalSafe(p.linkURL) }, { type: 'separator' });
    if (p.isEditable) {
      for (const s of (p.dictionarySuggestions || []).slice(0, 5)) t.push({ label: s, click: () => wc.replaceMisspelling(s) });
      if ((p.dictionarySuggestions || []).length) t.push({ type: 'separator' });
      t.push({ label: 'גזור', role: 'cut', enabled: p.editFlags.canCut }, { label: 'העתק', role: 'copy', enabled: p.editFlags.canCopy },
        { label: 'הדבק', role: 'paste', enabled: p.editFlags.canPaste }, { type: 'separator' }, { label: 'בחר הכול', role: 'selectAll' });
    } else if (p.selectionText) {
      t.push({ label: 'העתק', role: 'copy' }, { label: 'בחר הכול', role: 'selectAll' });
    }
    if (DEVTOOLS) t.push({ type: 'separator' }, { label: 'בדוק אלמנט', click: () => wc.inspectElement(p.x, p.y) });
    if (t.length) Menu.buildFromTemplate(t).popup({ window: win });
  });

  // טעינה נכשלה (למשל השרת באמצע restart) - ניסיונות חוזרים קצרים
  let retries = 0;
  wc.on('did-fail-load', (_e, code, desc, url, isMain) => {
    if (!isMain || code === -3 || stopping) return;
    console.error('[load] failed', code, desc, url);
    if (retries++ < 40) setTimeout(() => { if (win && !win.isDestroyed() && !stopping) win.loadURL(ORIGIN + '/'); }, 700);
  });
  wc.on('did-finish-load', () => { retries = 0; });

  win.loadURL(ORIGIN + '/');
  return win;
}

// ---------- IPC (מהממשק דרך preload) ----------
function trusted(e) { try { return isLocalUrl(e.senderFrame.url); } catch { return false; } }
function registerIpc() {
  ipcMain.handle('desktop:pickFolder', async (e, opts = {}) => {
    if (!trusted(e)) return null;
    const r = await dialog.showOpenDialog(win, { title: opts.title || 'בחירת תיקייה', defaultPath: opts.defaultPath || undefined, properties: ['openDirectory', 'createDirectory'] });
    return r.canceled || !r.filePaths.length ? null : r.filePaths[0];
  });
  ipcMain.handle('desktop:openExternal', (e, url) => (trusted(e) ? openExternalSafe(url) : false));
  ipcMain.handle('desktop:setZoom', (e, f) => {
    if (!trusted(e) || !Number.isFinite(f) || !win) return false;
    win.webContents.setZoomFactor(Math.max(0.25, Math.min(5, f))); saveStateSoon(); return true;
  });
  // restart = הרמה מחדש של תהליך השרת (טוען קוד שרת חדש) + טעינת החלון מחדש. החלון נשאר פתוח.
  ipcMain.handle('desktop:restart', e => { if (!trusted(e)) return false; setTimeout(() => restartServer('desktop.restart()'), 50); return true; });
  ipcMain.handle('desktop:quit', e => { if (!trusted(e)) return false; setTimeout(() => app.quit(), 50); return true; });
}

// ---------- סגירה נקייה ----------
app.on('before-quit', e => {
  if (stopping) return;
  stopping = true;
  e.preventDefault();
  abortRunningWork();                       // מבטל ריצות פעילות (השרת הורג את תהליכי-הבן שלהן)
  saveState();
  setTimeout(async () => {
    if (child) killTree(child.proc.pid);    // ואז כל עץ התהליכים של השרת
    // סגירת האפליקציה (לא הפעלה מחדש): גם ה-session host נסגר — Claude שעוד רץ בו נעצר בעדינות ואז נסגר
    try { if (hostAlive()) { await askHost({ type: 'drain', graceMs: 1500 }, 'drained', 3000); await stopHost(); } } catch { }
    app.quit();
  }, 350);
});
app.on('window-all-closed', () => app.quit());
// גיבוי אחרון: גם אם נסגרים בדרך אחרת, לא משאירים שרת / מארח יתום
process.on('exit', () => { if (child && child.code === undefined) killTree(child.proc.pid); if (host && host.code === undefined) killTree(host.pid); });

// כל web-contents: בלי webview
app.on('web-contents-created', (_e, contents) => { contents.on('will-attach-webview', ev => ev.preventDefault()); });

// צליל סיום-עבודה: מותר לנגן אודיו בלי מחוות משתמש (האפליקציה רצה ברקע בזמן ש-Claude עובד)
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
// הכתבה קולית ממשיכה להקליט גם כשהחלון ממוזער / מאחורי חלון אחר: הדף לא "מורד לרקע" (בלי האטה של טיימרים והודעות האודיו)
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('disable-background-timer-throttling');

// ---------- עלייה ----------
// מופע נוסף: התוכנה כבר פתוחה. מבקשים מהמופע הקיים להציג את החלון דרך השרת שלו (עובד גם כשהקיים רץ כמנהל — הודעה רגילה בין
// מופעים נחסמת אז ע"י Windows, ואז "לא נפתח כלום"). אם הקיים לא עונה — הוא תקוע: סוגרים אותו וממשיכים לעלות במקומו.
async function handleSecondInstance() {
  const port = readSavedPort() || PREFERRED_PORT;
  try { const r = await fetch(`http://${HOST}:${port}/api/app/focus`, { method: 'POST', signal: AbortSignal.timeout(2500) }); if (r.ok && (await r.json()).ok) return 'focused'; } catch { }
  console.log('[app] the running instance does not answer — closing it');
  try { spawnSync('taskkill', ['/F', '/T', '/FI', `IMAGENAME eq ${path.basename(process.execPath)}`, '/FI', `PID ne ${process.pid}`], { windowsHide: true, stdio: 'ignore', timeout: 8000 }); } catch { }
  for (let i = 0; i < 20; i++) { await sleep(300); if (app.requestSingleInstanceLock()) return 'took-over'; }
  return 'failed';
}

(async function main() {
  if (!(await acquireLock())) {
    const r = await handleSecondInstance();
    if (r === 'focused') { app.quit(); return; }
    if (r === 'failed') { await app.whenReady(); dialog.showErrorBox(TITLE, 'Claude מקומי כבר פתוח, אבל לא עונה ולא ניתן לסגור אותו (ייתכן שהוא רץ כמנהל מערכת). סגור אותו במנהל המשימות ונסה שוב.\n\nלוג: ' + LOG_FILE); app.quit(); return; }
  }
  await app.whenReady();
  // after a power cut / reboot the app comes back by itself (the server and the hub reconnect on their own)
  try { if (app.isPackaged && !process.env.CLAUDE_USER_DATA) app.setLoginItemSettings({ openAtLogin: true }); } catch (e) { console.error("[app] login item", e.message); }
  Menu.setApplicationMenu(null);           // בלי שורת תפריט (הקיצורים מטופלים ב-before-input-event)

  try {
    migrateLegacyData();
    try { await startHost(); } catch (e) { console.error('[app] session host start failed:', e && e.message); } // לפני השרת: הוא מתחבר אליו בעלייה
    await bringUpServer([...new Set([Number(process.env.CLAUDE_PORT) || PREFERRED_PORT, readSavedPort()].filter(Boolean))]);
  } catch (e) {
    console.error('[app] failed to start server:', e); // רק כשסוגרים באמצע עלייה — bringUpServer לא נכשל אחרת
    app.exit(0);
    return;
  }

  // זהות כמו Chrome: ה-UA בלי "Electron/…" ובלי שם האפליקציה
  try { session.defaultSession.setUserAgent(session.defaultSession.getUserAgent().replace(/\s(Electron|ClaudeLocal|Claude Local)\/\S+/g, '')); }
  catch (e) { console.error('[app] UA setup failed', e.message); }

  const allowed = new Set(['clipboard-read', 'clipboard-sanitized-write', 'notifications', 'fullscreen', 'media']);
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb, details) => cb(allowed.has(perm) && isLocalUrl(details.requestingUrl || wc.getURL())));
  session.defaultSession.setPermissionCheckHandler((wc, perm, origin) => allowed.has(perm) && isLocalUrl(origin || (wc && wc.getURL())));

  registerIpc();
  createWindow();
})().catch(e => { fileLog('FATAL', [e]); try { dialog.showErrorBox(TITLE, String(e && e.stack || e)); } catch { } app.exit(1); });
