'use strict';
// ============================================================
//  תהליך השרת של האפליקציה. main.js מריץ אותו כתהליך נפרד (utilityProcess),
//  כך שקריאת fs סינכרונית / כתיבת JSON גדולה בשרת לעולם לא מקפיאה את החלון.
//
//  מה הוא עושה: טוען את server.js כמו שהוא, מאזין על 127.0.0.1 ושולח להורה {type:'ready', port}.
//  החוזה מול ההורה:
//    - /api/restart  -> יציאה עם קוד 75   (main.js מרים שרת חדש וטוען מחדש את החלון)
//    - /api/shutdown -> יציאה עם קוד 0    (main.js סוגר את האפליקציה)
//    - הודעה {type:'abort-all'} מההורה: מבטל ריצות/סוכנים/מחקרים פעילים (לפני שההורה הורג את עץ התהליכים)
//  משתני סביבה: DATA_DIR, CLAUDE_PORT_PREFS="3456,40123" (פורטים מועדפים לפי סדר; אחריהם פורט פנוי אקראי),
//               CLAUDE_SUPERVISED=1, NO_BROWSER=1.
//  רץ גם ב-node רגיל (לבדיקות):  node electron/server-child.js
// ============================================================
// הקוד נטען מהבנייה שה-EXE בחר (קוד חי מ-%LOCALAPPDATA%\ClaudeLocal\live, או הקוד שבתוך ה-EXE)
const S = require(process.env.CLAUDE_CODE_ROOT ? require('path').join(process.env.CLAUDE_CODE_ROOT, 'server.js') : '../server.js');

const EXIT_RESTART = 75;
const prefs = String(process.env.CLAUDE_PORT_PREFS || '').split(',').map(Number).filter(n => n > 0 && n < 65536);

// server.js עדיין מכבד hooks (אם יוסרו, CLAUDE_SUPERVISED=1 עושה אותו דבר בצד השרת)
if (S.hooks) {
  S.hooks.restart = () => process.exit(EXIT_RESTART);
  S.hooks.shutdown = () => process.exit(0);
  S.hooks.focus = () => send({ type: 'focus' }); // מופע נוסף של ה-EXE ביקש להציג את החלון
}

function send(msg) {
  try {
    if (process.parentPort) process.parentPort.postMessage(msg);   // utilityProcess
    else if (process.send) process.send(msg);                      // child_process.fork / node
  } catch { }
}

function abortAll() {
  try { if (S.running) for (const r of S.running.values()) { try { r.controller.abort(); } catch { } } } catch { }
  try { S.agentsMgr && S.agentsMgr.stopAll(); } catch { }
  try { S.researchMgr && S.researchMgr.stopAll(); } catch { }
}
const onMessage = m => {
  if (!m) return;
  if (m.type === 'abort-all') abortAll();
  // HOT-UPDATE 1.5: the session host keeps the CLI processes; a server that supports it detaches instead of aborting
  // (detach מחזיר null כשהשרת לא מחובר ל-host — אז עוצרים כרגיל)
  else if (m.type === 'detach') { const p = typeof S.detach === 'function' ? S.detach({ exitCode: 0, reason: m.reason }) : null; if (!p) abortAll(); }
};
if (process.parentPort) process.parentPort.on('message', e => onMessage(e && e.data)); else process.on('message', onMessage);

(async () => {
  let server = null;
  for (const p of prefs) {
    try { server = await S.startServer(p, '127.0.0.1'); break; }
    catch (e) { if (e.code !== 'EADDRINUSE' && e.code !== 'EACCES') throw e; console.log(`[server-child] port ${p} busy (${e.code})`); }
  }
  if (!server) server = await S.startServer(0, '127.0.0.1');
  send({ type: 'ready', port: server.address().port, pid: process.pid, hostProto: S.HOST_PROTO || 0 });
})().catch(e => { console.error('[server-child] failed to start:', e); process.exit(1); });
