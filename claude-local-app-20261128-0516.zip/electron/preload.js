'use strict';
// ============================================================
//  preload: הגשר היחיד בין הממשק (דפדפן) לבין Electron.
//  contextIsolation פעיל, nodeIntegration כבוי. הממשק מקבל רק את window.desktop.
// ============================================================
const { contextBridge, ipcRenderer, webUtils } = require('electron');

// הגרסה מגיעה מ-main.js דרך additionalArguments (preload ב-sandbox לא יכול לקרוא את app.getVersion)
const versionArg = (process.argv.find(a => a.startsWith('--claude-version=')) || '').slice('--claude-version='.length);

contextBridge.exposeInMainWorld('desktop', {
  isDesktop: true,
  version: versionArg || 'dev',
  platform: process.platform,

  // הנתיב האמיתי (מוחלט) של קובץ/תיקייה שנגררו מ-Windows Explorer. '' אם אין (למשל תמונה מהדבקה).
  pathForFile(file) {
    try { return webUtils.getPathForFile(file) || ''; } catch { return ''; }
  },
  // דיאלוג בחירת תיקייה של Windows. מחזיר נתיב מלא או null אם בוטל.
  pickFolder(opts) { return ipcRenderer.invoke('desktop:pickFolder', opts && typeof opts === 'object' ? { title: opts.title, defaultPath: opts.defaultPath } : {}); },
  // פתיחת קישור בדפדפן ברירת המחדל (http/https/mailto בלבד)
  openExternal(url) { return ipcRenderer.invoke('desktop:openExternal', String(url)); },
  // זום: 1 = 100%
  setZoom(f) { return ipcRenderer.invoke('desktop:setZoom', Number(f)); },
  restart() { return ipcRenderer.invoke('desktop:restart'); },
  quit() { return ipcRenderer.invoke('desktop:quit'); }
});
