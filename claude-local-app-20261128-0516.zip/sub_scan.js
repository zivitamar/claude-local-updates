'use strict';
// ============================================================
//  sub_scan.js — רץ כתהליך נפרד (לא חוסם את השרת).
//  סוכם את העלות בתעריף API (טוקנים × מחירון) של כל הודעות Claude Code בכל השיחות
//  (~/.claude/projects/**.jsonl), בדליים של 10 דקות. קריאה מצטברת: כל קובץ נקרא רק מהמקום שבו נעצר
//  (קבצי השיחה רק מתארכים). פלט: JSON עם העלות מכל זמן התחלה שהתבקש.
//  רץ כ-worker thread (ב-EXE אין "Electron כ-Node", לכן לא תהליך נפרד) או משורת פקודה:
//  node sub_scan.js <cacheFile> <start1,start2,...>
// ============================================================
const fs = require('fs'), path = require('path'), os = require('os');
const pricing = require('./pricing');
let wt = null; try { wt = require('worker_threads'); } catch { }
const W = wt && !wt.isMainThread ? wt.workerData : null;
const [cacheFile, startsArg] = W ? [W.cacheFile, W.starts.join(',')] : process.argv.slice(2);
const starts = String(startsArg || '').split(',').map(Number).filter(n => n > 0);
const BUCKET = 10 * 60 * 1000, KEEP = 9 * 24 * 3600 * 1000;
const root = path.join(os.homedir(), '.claude', 'projects');
let cache = { files: {} };
const VER = 2; // גרסת נוסחת המחיר: שינוי בה = סריקה מחדש של הכל (אחרת הסכומים הישנים נשארים בנוסחה הישנה)
try { cache = JSON.parse(fs.readFileSync(cacheFile, 'utf8')); if (!cache.files) cache.files = {}; } catch { }
if (cache.v !== VER) cache = { v: VER, files: {} };
const minKeep = Date.now() - KEEP;

const list = [];
(function walk(d) { let es = []; try { es = fs.readdirSync(d, { withFileTypes: true }); } catch { return; } for (const e of es) { const p = path.join(d, e.name); if (e.isDirectory()) walk(p); else if (e.name.endsWith('.jsonl')) list.push(p); } })(root);

const alive = new Set();
let readBytes = 0;
for (const f of list) {
  let st; try { st = fs.statSync(f); } catch { continue; }
  if (st.mtimeMs < minKeep) continue;
  alive.add(f);
  let c = cache.files[f];
  if (!c || st.size < c.size) c = cache.files[f] = { size: 0, b: {}, ids: [] };
  if (st.size === c.size) continue;
  const fd = fs.openSync(f, 'r');
  try {
    const CH = 8 * 1024 * 1024; let pos = c.size, rest = '';
    const ids = new Set(c.ids);
    while (pos < st.size) {
      const len = Math.min(CH, st.size - pos), buf = Buffer.alloc(len);
      fs.readSync(fd, buf, 0, len, pos); pos += len; readBytes += len;
      const text = rest + buf.toString('utf8'); const lines = text.split('\n'); rest = lines.pop();
      for (const line of lines) {
        if (line.indexOf('"usage"') < 0 || line.indexOf('"assistant"') < 0) continue;
        let j; try { j = JSON.parse(line); } catch { continue; }
        if (j.type !== 'assistant' || !j.message || !j.message.usage) continue;
        const m = j.message.model || ''; if (!m || m === '<synthetic>') continue;
        const k = (j.message.id || '') + '|' + (j.requestId || ''); if (ids.has(k)) continue; ids.add(k);
        const ts = Date.parse(j.timestamp || 0); if (!(ts > minKeep)) continue;
        const bk = Math.floor(ts / BUCKET) * BUCKET;
        c.b[bk] = (c.b[bk] || 0) + pricing.costOf(m, j.message.usage);
      }
    }
    // שורה חלקית בסוף (נכתבת עכשיו): לא נספרת — נקרא אותה שוב בפעם הבאה
    c.size = st.size - Buffer.byteLength(rest, 'utf8');
    c.ids = [...ids].slice(-400);
  } finally { fs.closeSync(fd); }
}
for (const f of Object.keys(cache.files)) if (!alive.has(f)) delete cache.files[f];
for (const c of Object.values(cache.files)) for (const k of Object.keys(c.b)) if (+k < minKeep) delete c.b[k];
try { fs.writeFileSync(cacheFile + '.tmp', JSON.stringify(cache)); fs.renameSync(cacheFile + '.tmp', cacheFile); } catch { }

const out = {};
for (const s of starts) { let sum = 0; for (const c of Object.values(cache.files)) for (const [k, v] of Object.entries(c.b)) if (+k >= s - BUCKET / 2) sum += v; out[s] = +sum.toFixed(4); }
const result = { costs: out, files: alive.size, readMB: +(readBytes / 1048576).toFixed(1) };
if (W) wt.parentPort.postMessage(result); else process.stdout.write(JSON.stringify(result));
