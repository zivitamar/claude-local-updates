'use strict';
// ============================================================
//  accountbox.js — "תיבת הדואר של החשבון": כל מכשיר של אותו משתמש מוצא את המערכת שלו רק לפי חשבון ה-Claude שלו.
//  האחסון: Files API של Anthropic בתוך חשבון ה-Claude עצמו (אותו אסימון OAuth של המנוי) — בלי צד שלישי. רק מי שמחובר
//  לאחד מחשבונות המערכת יכול לקרוא / לכתוב שם.
//   • מחשב שבמערכת מפרסם claude-local-hub.json בכל חשבון שמור עם "אימות מכשירים": כתובת המרכזיה + המפתח + כרטיסי המחשבים.
//   • מכשיר חדש (מחשב / טלפון) שנכנס לאחד החשבונות: קורא את הקובץ → מתחבר למרכזיה, מכיר את המחשבים, ומשאיר בקשת הצטרפות
//     claude-local-join-<id>.json עם הכרטיס שלו.
//   • המחשבים בודקים את התיבה כל דקה: בקשה שנמצאת בחשבון = הוכחה שהמבקש מחובר לחשבון → מצרפים אותו לרשת ומוחקים את הבקשה.
// ============================================================
const API = 'https://api.anthropic.com/v1/files';
const HDR = t => ({ authorization: 'Bearer ' + t, 'anthropic-version': '2023-06-01', 'anthropic-beta': 'files-api-2025-04-14,oauth-2025-04-20' });
const cardP = c => { try { return JSON.parse(JSON.parse(Buffer.from(String(c).split(' ')[1], 'base64url').toString('utf8')).p); } catch { return {}; } };
const cardId = c => cardP(c).id || '', cardTs = c => cardP(c).ts || 0;
const NS = (process.env.CLAUDE_ACCOUNTBOX_NS || '').replace(/[^a-z0-9-]/gi, ''); // tests: a separate namespace, never the real files
const PFX = 'claude-local' + (NS ? '-' + NS : '');
const HUB_FILE = PFX + '-hub.json', JOIN_RE = new RegExp('^' + PFX + '-join-([0-9a-f]{16})\\.json$'), JOIN_NAME = id => PFX + '-join-' + id + '.json';

async function list(token) { const r = await fetch(API + '?limit=1000', { headers: HDR(token), signal: AbortSignal.timeout(20000) }); if (!r.ok) throw new Error('files list ' + r.status); return (await r.json()).data || []; }
async function read(token, id) { const r = await fetch(`${API}/${id}/content`, { headers: HDR(token), signal: AbortSignal.timeout(20000) }); if (!r.ok) throw new Error('file read ' + r.status); return r.text(); }
async function del(token, id) { try { await fetch(`${API}/${id}`, { method: 'DELETE', headers: HDR(token), signal: AbortSignal.timeout(20000) }); } catch { } }
async function put(token, name, obj) {
  const fd = new FormData(); fd.append('file', new Blob([JSON.stringify(obj)], { type: 'application/json' }), name);
  const r = await fetch(API, { method: 'POST', headers: HDR(token), body: fd, signal: AbortSignal.timeout(30000) }); if (!r.ok) throw new Error('file write ' + r.status + ' ' + (await r.text()).slice(0, 200)); return (await r.json()).id;
}
async function profile(token) { const r = await fetch('https://api.anthropic.com/api/oauth/profile', { headers: HDR(token), signal: AbortSignal.timeout(20000) }); if (!r.ok) throw new Error('profile ' + r.status); const j = await r.json(); return { email: String((j.account && j.account.email) || '').toLowerCase(), uuid: j.account && j.account.uuid }; }

/**
 * tokens(): [{ email, token }] of every account of this system that may admit devices (live + saved with device auth on)
 * hub: relay.js instance · mesh: mesh.js instance (card(), acceptAccountHello())
 */
function createAccountBox({ tokens, hub, mesh, log = () => { }, everyMs = 60000 }) {
  const S = { lastRun: 0, published: {}, admitted: 0, errors: {}, timer: null };
  async function runOnce() {
    S.lastRun = Date.now();
    const cfg = hub && hub.shareable(); const accts = await tokens().catch(() => []);
    for (const a of accts) {
      try {
        const files = await list(a.token);
        // 1. publish / refresh the hub + my card (only when it changed)
        if (cfg) {
          const want = { v: 1, hub: { url: cfg.url, net: cfg.net, key: cfg.key }, cards: [mesh.card()], at: Date.now() };
          const mine = files.filter(f => f.filename === HUB_FILE);
          let same = false;
          if (mine.length === 1) { try { const cur = JSON.parse(await read(a.token, mine[0].id)); const myId = mesh.id; const hasMe = (cur.cards || []).some(c => cardId(c) === myId); same = cur.hub && cur.hub.url === cfg.url && cur.hub.net === cfg.net && cur.hub.key === cfg.key && hasMe && Date.now() - (cur.at || 0) < 12 * 3600e3; if (!same && cur.cards) want.cards = [...(cur.cards || []).filter(c => cardId(c) !== myId && Date.now() - cardTs(c) < 20 * 3600e3).slice(0, 30), want.cards[0]]; } catch { } }
          if (!same) { const id = await put(a.token, HUB_FILE, want); for (const f of mine) if (f.id !== id) await del(a.token, f.id); S.published[a.email] = Date.now(); log('[accountbox] published the hub to ' + a.email); }
        }
        // 2. join requests left by my other devices (the file being in MY account = the device is signed in to it)
        for (const f of files.filter(x => JOIN_RE.test(x.filename))) {
          try {
            const j = JSON.parse(await read(a.token, f.id));
            const r = mesh.acceptAccountHello(String(j.card || ''), null, 'account:' + a.email);
            if (r && r.ok !== false) { S.admitted++; log('[accountbox] admitted ' + (r.id || '?') + ' via ' + a.email); }
            else log('[accountbox] join refused: ' + JSON.stringify(r).slice(0, 120));
          } catch (e) { log('[accountbox] join ' + e.message); }
          await del(a.token, f.id);
        }
        delete S.errors[a.email];
      } catch (e) { S.errors[a.email] = e.message; }
    }
  }
  /** a NEW device: find my system through my Claude account; returns the hub config (and leaves a join request) */
  async function joinWith(token) {
    const files = await list(token);
    const f = files.filter(x => x.filename === HUB_FILE).sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)))[0];
    if (!f) return null;
    const box = JSON.parse(await read(token, f.id));
    for (const c of box.cards || []) { try { mesh.acceptAccountHello(c, null, 'account-box'); } catch { } }
    await put(token, JOIN_NAME(mesh.id), { v: 1, card: mesh.card(), at: Date.now() });
    if (box.hub && hub) hub.adopt(box.hub);
    return box.hub || null;
  }
  function start() { clearInterval(S.timer); S.timer = setInterval(() => runOnce().catch(e => log('[accountbox] ' + e.message)), everyMs); if (S.timer.unref) S.timer.unref(); setTimeout(() => runOnce().catch(() => { }), 5000); }
  function stop() { clearInterval(S.timer); }
  return { runOnce, joinWith, start, stop, status: () => ({ ...S, timer: undefined }) };
}
module.exports = { createAccountBox, list, read, put, del, profile, HUB_FILE, JOIN_RE };
