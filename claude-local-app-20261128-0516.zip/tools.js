'use strict';
// ============================================================
//  כלים שנותנים ל-Claude גישה למחשב: פקודות, קבצים, תיקיות, חיפוש
// ============================================================
const fs = require('fs');
const fsp = fs.promises;
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');

const MAX_OUTPUT = 30000; // מקסימום תווים שחוזרים ל-Claude מכל כלי
const IS_WIN = process.platform === 'win32';

// ---------- הגדרות הכלים (נשלחות ל-API של Claude) ----------
const TOOLS = [
  {
    name: 'run_command',
    description:
      `Run a shell command on the user's computer and return its output. Default shell: ${IS_WIN ? 'Windows PowerShell 5.1' : 'bash'}` +
      (IS_WIN ? '; set shell to "cmd" for cmd.exe batch syntax or "bash" for Git Bash (Unix commands). ' : '. ') +
      'Use it for anything: installing packages, running scripts, git, opening programs/files/websites, system info, processes, network, etc. ' +
      'Commands that never exit (servers, GUI apps) must be started in the background (e.g. Start-Process) or they will time out.',
    input_schema: {
      type: 'object',
      properties: {
        command: { type: 'string', description: 'The command to run' },
        shell: { type: 'string', enum: IS_WIN ? ['powershell', 'cmd', 'bash'] : ['bash'], description: 'Which shell runs the command (default: ' + (IS_WIN ? 'powershell' : 'bash') + ')' },
        cwd: { type: 'string', description: 'Working directory (optional)' },
        timeout_seconds: { type: 'number', description: 'Timeout in seconds (default 120, max 1800)' }
      },
      required: ['command']
    }
  },
  {
    name: 'read_file',
    description: 'Read a text file from the computer. Optionally only a range of lines.',
    input_schema: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'Absolute path, or relative to the working directory' },
        start_line: { type: 'number', description: 'First line (1-based, optional)' },
        end_line: { type: 'number', description: 'Last line, inclusive (optional)' }
      },
      required: ['path']
    }
  },
  {
    name: 'write_file',
    description: 'Create a new file or completely overwrite a file. Parent folders are created automatically.',
    input_schema: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'Absolute path, or relative to the working directory' },
        content: { type: 'string', description: 'Full file content' }
      },
      required: ['path', 'content']
    }
  },
  {
    name: 'edit_file',
    description: 'Edit an existing file by replacing exact text. old_text must match exactly and be unique, unless replace_all is true.',
    input_schema: {
      type: 'object',
      properties: {
        path: { type: 'string' },
        old_text: { type: 'string', description: 'Exact text to find' },
        new_text: { type: 'string', description: 'Replacement text' },
        replace_all: { type: 'boolean', description: 'Replace all occurrences (default false)' }
      },
      required: ['path', 'old_text', 'new_text']
    }
  },
  {
    name: 'list_directory',
    description: 'List files and folders in a directory (with sizes). Optionally recursive (3 levels).',
    input_schema: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'Directory path (default: working directory)' },
        recursive: { type: 'boolean' }
      }
    }
  },
  {
    name: 'search_files',
    description: 'Search a regex in file names and text file contents under a folder (recursive).',
    input_schema: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'Folder to search (default: working directory)' },
        pattern: { type: 'string', description: 'Regular expression (case-insensitive)' },
        file_pattern: { type: 'string', description: 'Optional file name filter, e.g. *.js' }
      },
      required: ['pattern']
    }
  }
];

// כלים שרק קוראים - לא צריכים אישור גם במצב "שאל לפני ביצוע"
const READ_ONLY_TOOLS = new Set(['read_file', 'list_directory', 'search_files']);

// ---------- עזרים ----------
function truncate(text) {
  text = String(text);
  if (text.length <= MAX_OUTPUT) return text;
  const half = MAX_OUTPUT / 2;
  return text.slice(0, half) + `\n\n... [truncated ${text.length - MAX_OUTPUT} characters] ...\n\n` + text.slice(-half);
}

function resolvePath(p, cwd) {
  if (!p) return cwd;
  p = String(p).trim().replace(/^["']|["']$/g, '');
  if (p.startsWith('~')) p = path.join(os.homedir(), p.slice(1));
  return path.isAbsolute(p) ? path.normalize(p) : path.resolve(cwd, p);
}

function formatSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 ** 2) return (bytes / 1024).toFixed(1) + ' KB';
  if (bytes < 1024 ** 3) return (bytes / 1024 ** 2).toFixed(1) + ' MB';
  return (bytes / 1024 ** 3).toFixed(2) + ' GB';
}

const countOccurrences = (text, sub) => (sub ? text.split(sub).length - 1 : 0);

function globToRegex(glob) {
  const re = glob.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\?/g, '.');
  return new RegExp('^' + re + '$', 'i');
}

// PowerShell מחזיר לפעמים שגיאות בפורמט CLIXML - ממירים לטקסט רגיל
function cleanClixml(s) {
  if (!s.includes('#< CLIXML')) return s;
  return [...s.matchAll(/<S S="Error">([\s\S]*?)<\/S>/g)]
    .map(m => m[1].replace(/_x000D__x000A_/g, '\n').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&'))
    .join('');
}

// ---------- איתור Git Bash (ב-Windows, bash.exe שב-System32 הוא WSL ולא Git Bash) ----------
let _bashPath;
function findBash() {
  if (_bashPath !== undefined) return _bashPath;
  if (!IS_WIN) return (_bashPath = 'bash');
  const cands = [
    process.env.GIT_BASH,
    path.join(process.env.ProgramFiles || 'C:\\Program Files', 'Git', 'bin', 'bash.exe'),
    path.join(process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', 'Git', 'bin', 'bash.exe'),
    path.join(process.env.LOCALAPPDATA || '', 'Programs', 'Git', 'bin', 'bash.exe')
  ].filter(Boolean);
  _bashPath = cands.find(p => { try { return fs.existsSync(p); } catch { return false; } }) || null;
  return _bashPath;
}
// ---------- פענוח פלט של cmd.exe ----------
// cmd שרץ בלי חלון (CREATE_NO_WINDOW) כותב פקודות פנימיות בקידוד ה-OEM של Windows (בעברית: CP862)
// גם אחרי chcp 65001, ותוכנות חיצוניות (git/node) כותבות UTF-8. לכן מפענחים שורה-שורה:
// שורה שהיא UTF-8 תקין -> UTF-8, אחרת -> קידוד ה-OEM של המחשב.
const CP437_HIGH = [
  0xC7, 0xFC, 0xE9, 0xE2, 0xE4, 0xE0, 0xE5, 0xE7, 0xEA, 0xEB, 0xE8, 0xEF, 0xEE, 0xEC, 0xC4, 0xC5,
  0xC9, 0xE6, 0xC6, 0xF4, 0xF6, 0xF2, 0xFB, 0xF9, 0xFF, 0xD6, 0xDC, 0xA2, 0xA3, 0xA5, 0x20A7, 0x192,
  0xE1, 0xED, 0xF3, 0xFA, 0xF1, 0xD1, 0xAA, 0xBA, 0xBF, 0x2310, 0xAC, 0xBD, 0xBC, 0xA1, 0xAB, 0xBB,
  0x2591, 0x2592, 0x2593, 0x2502, 0x2524, 0x2561, 0x2562, 0x2556, 0x2555, 0x2563, 0x2551, 0x2557, 0x255D, 0x255C, 0x255B, 0x2510,
  0x2514, 0x2534, 0x252C, 0x251C, 0x2500, 0x253C, 0x255E, 0x255F, 0x255A, 0x2554, 0x2569, 0x2566, 0x2560, 0x2550, 0x256C, 0x2567,
  0x2568, 0x2564, 0x2565, 0x2559, 0x2558, 0x2552, 0x2553, 0x256B, 0x256A, 0x2518, 0x250C, 0x2588, 0x2584, 0x258C, 0x2590, 0x2580,
  0x3B1, 0xDF, 0x393, 0x3C0, 0x3A3, 0x3C3, 0xB5, 0x3C4, 0x3A6, 0x398, 0x3A9, 0x3B4, 0x221E, 0x3C6, 0x3B5, 0x2229,
  0x2261, 0xB1, 0x2265, 0x2264, 0x2320, 0x2321, 0xF7, 0x2248, 0xB0, 0x2219, 0xB7, 0x221A, 0x207F, 0xB2, 0x25A0, 0xA0
];
let _oemCp;
function oemCodePage() {
  if (_oemCp !== undefined) return _oemCp;
  _oemCp = 437;
  if (IS_WIN) {
    try {
      const out = require('child_process').execSync('reg query HKLM\\SYSTEM\\CurrentControlSet\\Control\\Nls\\CodePage /v OEMCP',
        { encoding: 'utf8', windowsHide: true, timeout: 5000 });
      const m = out.match(/OEMCP\s+REG_SZ\s+(\d+)/); if (m) _oemCp = Number(m[1]);
    } catch { }
  }
  return _oemCp;
}
function decodeOem(buf) {
  const cp = oemCodePage();
  if (cp !== 437 && cp !== 862) {
    try { return new TextDecoder('ibm' + cp).decode(buf); } catch { try { return new TextDecoder('windows-' + cp).decode(buf); } catch { return buf.toString('latin1'); } }
  }
  let s = '';
  for (const b of buf) {
    if (b < 0x80) s += String.fromCharCode(b);
    else if (cp === 862 && b <= 0x9A) s += String.fromCharCode(0x5D0 + (b - 0x80)); // א..ת
    else s += String.fromCharCode(CP437_HIGH[b - 0x80]);
  }
  return s;
}
const utf8Strict = new TextDecoder('utf-8', { fatal: true });
function decodeCmdOutput(buf) {
  const parts = [];
  let start = 0;
  for (let i = 0; i <= buf.length; i++) {
    if (i === buf.length || buf[i] === 0x0A) {
      const line = buf.subarray(start, i);
      let s;
      try { s = utf8Strict.decode(line); } catch { s = decodeOem(line); }
      parts.push(s);
      start = i + 1;
    }
  }
  return parts.join('\n');
}

const normShell = s => {
  s = String(s || '').toLowerCase().trim();
  if (!IS_WIN) return 'bash';
  if (s === 'cmd' || s === 'cmd.exe' || s === 'batch') return 'cmd';
  if (s === 'bash' || s === 'git-bash' || s === 'sh') return 'bash';
  return 'powershell';
};

// ---------- מימוש הכלים ----------
function runCommand({ command, shell, cwd: dir, timeout_seconds }, cwd, signal) {
  return new Promise(resolve => {
    if (signal && signal.aborted) return resolve({ output: 'Cancelled by the user.', is_error: true });
    if (!command || !String(command).trim()) return resolve({ output: 'command must not be empty.', is_error: true });
    const workDir = dir ? resolvePath(dir, cwd) : cwd;
    if (!fs.existsSync(workDir)) return resolve({ output: `Directory not found: ${workDir}`, is_error: true });
    const timeoutMs = Math.min(Math.max(Number(timeout_seconds) || 120, 1), 1800) * 1000;
    const sh = normShell(shell);

    let child;
    try {
      if (IS_WIN && sh === 'powershell') {
        const script =
          '[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; $OutputEncoding=[System.Text.Encoding]::UTF8; ' +
          "$ProgressPreference='SilentlyContinue'; " + command;
        const encoded = Buffer.from(script, 'utf16le').toString('base64');
        child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded],
          { cwd: workDir, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
      } else if (IS_WIN && sh === 'cmd') {
        // /d = בלי AutoRun, /s /c = הפקודה כמו שהיא. הפלט מפוענח ב-decodeCmdOutput (OEM/UTF-8 לפי שורה)
        child = spawn(process.env.ComSpec || 'cmd.exe', ['/d', '/s', '/c', `"${command}"`],
          { cwd: workDir, windowsHide: true, windowsVerbatimArguments: true, stdio: ['ignore', 'pipe', 'pipe'] });
      } else {
        const bash = findBash();
        if (!bash) return resolve({ output: 'Git Bash was not found on this computer. Install Git for Windows (https://git-scm.com) or use shell "powershell".', is_error: true });
        child = spawn(bash, ['-lc', command], {
          cwd: workDir, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'],
          env: { ...process.env, LANG: process.env.LANG || 'C.UTF-8', CHERE_INVOKING: '1' }
        });
      }
    } catch (e) {
      return resolve({ output: 'Failed to start command: ' + e.message, is_error: true });
    }

    const out = [], err = [];
    let timedOut = false;
    child.stdout.on('data', d => out.push(d));
    child.stderr.on('data', d => err.push(d));

    const killTree = () => {
      try {
        if (IS_WIN) spawn('taskkill', ['/pid', String(child.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' });
        else child.kill('SIGKILL');
      } catch { }
    };
    let cancelled = false;
    const onAbort = () => { cancelled = true; killTree(); };
    if (signal) signal.addEventListener('abort', onAbort, { once: true });
    const timer = setTimeout(() => { timedOut = true; killTree(); }, timeoutMs);

    child.on('error', e => { clearTimeout(timer); resolve({ output: 'Failed to start command: ' + e.message, is_error: true }); });
    child.on('close', code => {
      clearTimeout(timer);
      if (signal) signal.removeEventListener('abort', onAbort);
      if (cancelled) return resolve({ output: 'Stopped by the user (the command was killed).', is_error: true });
      const dec = b => (IS_WIN && sh === 'cmd' ? decodeCmdOutput(b) : b.toString('utf8'));
      const stdout = dec(Buffer.concat(out)).trim();
      const stderr = cleanClixml(dec(Buffer.concat(err))).trim();
      let output = stdout;
      if (stderr) output += (output ? '\n\n' : '') + '[stderr]\n' + stderr;
      if (timedOut) output += `\n\n[Command timed out after ${timeoutMs / 1000}s and was stopped]`;
      output += `\n\n[exit code: ${code}]`;
      resolve({ output: truncate(output.trim()), is_error: timedOut || code !== 0 });
    });
  });
}

async function readFile({ path: p, start_line, end_line }, cwd) {
  const file = resolvePath(p, cwd);
  const stat = await fsp.stat(file);
  if (stat.isDirectory()) return { output: `${file} is a directory. Use list_directory.`, is_error: true };
  if (stat.size > 10 * 1024 * 1024) return { output: `File too large (${formatSize(stat.size)}). Use run_command.`, is_error: true };
  const text = await fsp.readFile(file, 'utf8');
  if (text.slice(0, 8000).includes('\u0000')) return { output: `${file} is a binary file (${formatSize(stat.size)}).`, is_error: true };
  const lines = text.split(/\r?\n/);
  const start = Math.max(1, Number(start_line) || 1);
  const end = Math.min(lines.length, Number(end_line) || lines.length);
  const partial = start > 1 || end < lines.length ? `, showing ${start}-${end}` : '';
  return { output: truncate(`File: ${file} (${lines.length} lines${partial})\n\n` + lines.slice(start - 1, end).join('\n')) };
}

async function writeFile({ path: p, content }, cwd) {
  const file = resolvePath(p, cwd);
  await fsp.mkdir(path.dirname(file), { recursive: true });
  const existed = fs.existsSync(file);
  await fsp.writeFile(file, content ?? '', 'utf8');
  return { output: `${existed ? 'Overwrote' : 'Created'} ${file} (${Buffer.byteLength(content ?? '', 'utf8')} bytes)` };
}

async function editFile({ path: p, old_text, new_text, replace_all }, cwd) {
  const file = resolvePath(p, cwd);
  if (!old_text) return { output: 'old_text must not be empty.', is_error: true };
  let text = await fsp.readFile(file, 'utf8');
  let oldT = old_text, newT = new_text ?? '';
  let count = countOccurrences(text, oldT);
  // תמיכה בקבצי Windows עם סופי שורה CRLF
  if (count === 0 && text.includes('\r\n') && !oldT.includes('\r\n')) {
    const crlfOld = oldT.replace(/\n/g, '\r\n');
    const c = countOccurrences(text, crlfOld);
    if (c > 0) { oldT = crlfOld; newT = newT.replace(/\r?\n/g, '\r\n'); count = c; }
  }
  if (count === 0) return { output: `old_text not found in ${file}. Read the file again and copy the exact text.`, is_error: true };
  if (count > 1 && !replace_all) return { output: `old_text appears ${count} times. Add more context or set replace_all: true.`, is_error: true };
  text = replace_all ? text.split(oldT).join(newT) : text.replace(oldT, () => newT);
  await fsp.writeFile(file, text, 'utf8');
  return { output: `Edited ${file} (${replace_all ? count : 1} replacement(s))` };
}

async function listDirectory({ path: p, recursive }, cwd) {
  const root = resolvePath(p, cwd);
  const stat = await fsp.stat(root);
  if (!stat.isDirectory()) return { output: `${root} is not a directory.`, is_error: true };
  const lines = [];
  const LIMIT = 500;
  async function walk(dir, depth, prefix) {
    let entries;
    try { entries = await fsp.readdir(dir, { withFileTypes: true }); }
    catch (e) { lines.push(`${prefix}[cannot read: ${e.code || e.message}]`); return; }
    entries.sort((a, b) => (b.isDirectory() - a.isDirectory()) || a.name.localeCompare(b.name));
    for (const e of entries) {
      if (lines.length >= LIMIT) { lines.push('... (list truncated)'); return; }
      const full = path.join(dir, e.name);
      if (e.isDirectory()) {
        lines.push(`${prefix}📁 ${e.name}/`);
        if (recursive && depth < 3 && !['node_modules', '.git'].includes(e.name)) await walk(full, depth + 1, prefix + '    ');
      } else {
        let size = '';
        try { size = formatSize((await fsp.stat(full)).size); } catch { }
        lines.push(`${prefix}📄 ${e.name}  (${size})`);
      }
    }
  }
  await walk(root, 1, '');
  return { output: truncate(`Directory: ${root}\n\n` + (lines.join('\n') || '(empty)')) };
}

async function searchFiles({ path: p, pattern, file_pattern }, cwd) {
  const root = resolvePath(p, cwd);
  let re;
  try { re = new RegExp(pattern, 'i'); } catch (e) { return { output: 'Invalid regex: ' + e.message, is_error: true }; }
  const fileRe = file_pattern ? globToRegex(file_pattern) : null;
  const SKIP = new Set(['node_modules', '.git', '$Recycle.Bin', 'AppData', 'System Volume Information']);
  const results = [];
  const LIMIT = 200;
  let scanned = 0;

  async function walk(dir, depth) {
    if (results.length >= LIMIT || scanned > 20000 || depth > 12) return;
    let entries;
    try { entries = await fsp.readdir(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      if (results.length >= LIMIT) return;
      const full = path.join(dir, e.name);
      if (e.isDirectory()) { if (!SKIP.has(e.name)) await walk(full, depth + 1); continue; }
      if (!e.isFile()) continue;
      scanned++;
      if (fileRe && !fileRe.test(e.name)) continue;
      if (re.test(e.name)) results.push(`${full}  [file name match]`);
      try {
        if ((await fsp.stat(full)).size > 2 * 1024 * 1024) continue;
        const text = await fsp.readFile(full, 'utf8');
        if (text.slice(0, 8000).includes('\u0000')) continue;
        const lines = text.split(/\r?\n/);
        for (let i = 0; i < lines.length && results.length < LIMIT; i++) {
          if (re.test(lines[i])) results.push(`${full}:${i + 1}: ${lines[i].trim().slice(0, 200)}`);
        }
      } catch { }
    }
  }
  await walk(root, 0);
  const head = `Search "${pattern}" in ${root}: ${results.length} result(s)${results.length >= LIMIT ? ' (limit reached)' : ''}\n\n`;
  return { output: truncate(head + (results.join('\n') || 'No matches.')) };
}

const HANDLERS = {
  run_command: runCommand,
  read_file: readFile,
  write_file: writeFile,
  edit_file: editFile,
  list_directory: listDirectory,
  search_files: searchFiles
};

async function executeTool(name, input, cwd, signal) {
  const handler = HANDLERS[name];
  if (!handler) return { output: `Unknown tool: ${name}`, is_error: true };
  if (signal && signal.aborted) return { output: 'Cancelled by the user.', is_error: true };
  try {
    const r = await handler(input || {}, cwd, signal);
    return { output: r.output || '(no output)', is_error: !!r.is_error };
  } catch (e) {
    return { output: `Error: ${e.message}`, is_error: true };
  }
}

module.exports = { TOOLS, READ_ONLY_TOOLS, executeTool, resolvePath, findBash, normShell, formatSize, truncate, decodeCmdOutput };
