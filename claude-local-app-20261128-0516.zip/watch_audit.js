'use strict';
// ============================================================
//  watch_audit.js — 🔎 בודק עצמאי לכל סבב מעקב (גם "תקין" וגם "לא תקין")
//  מודל נפרד (תהליך משלו, בלי כלים, בלי הסשן של הסבב) מקבל: את המשימה של הבעלים, את כל מה ש-Claude באמת הריץ בסבב
//  וכל פלט שראה (בסדר), ואת הדיווח הסופי — וקובע לכל פריט במשימה:
//    • מה המצב האמיתי לפי הפלטים בלבד (תקין / לא תקין / לא נבדק)
//    • איזה סימון Claude נתן לו בדיווח (✅ / ❌ / שניהם / אין) — סימון שלא תואם את הפלט = שגיאת סימון
//    • עובדות בדיווח שאף פלט בסבב לא מראה (מספרים, ציטוטים, "כל N השורות", דברים שהועתקו מסבב קודם)
//  כך לא עובר: "תקין" כשפריט לא תקין / דולג / לא נבדק · ❌ על פריט שתקין · ✅ על פריט שבור · עובדה שלא נבדקה.
//  הפרומפט עובר ב-stdin (ארוך מדי לשורת הפקודה). התשובה: JSON בלבד.
// ============================================================
const MARK = 'WATCH-AUDIT-V2';
const SYSTEM = 'You are a strict, independent auditor of an automated check. You never trust claims; you only trust tool outputs. You answer with a single JSON object and nothing else.';
const clip = (s, n) => { s = String(s == null ? '' : s); if (s.length <= n) return s; const a = Math.floor(n * 0.65), b = n - a; return s.slice(0, a) + `\n…[${s.length - n} chars cut]…\n` + s.slice(-b); };
function textOf(content) {
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) return content.map(b => !b ? '' : b.type === 'text' ? b.text : b.type === 'image' ? '[image: a screenshot/picture — the auditor cannot see it]' : '').filter(Boolean).join('\n');
  return '';
}
// הראיות: כל קריאה לכלי בסבב (לפי הסדר) עם הפלט המדויק שלה. segment = ההודעות של הסבב (אחרי הודעת הסבב, כולל בקשות המשך של אותו סבב)
function evidenceOf(segment) {
  const res = {}, calls = [];
  for (const m of segment || []) if (m && m.role === 'user' && Array.isArray(m.content)) for (const b of m.content) if (b && b.type === 'tool_result') res[b.tool_use_id] = b;
  for (const m of segment || []) {
    if (!m || m.role !== 'assistant' || !Array.isArray(m.content)) continue;
    for (const b of m.content) if (b && b.type === 'tool_use') { const r = res[b.id]; calls.push({ name: b.name, input: b.input || {}, output: r ? textOf(r.content) : null, isError: !!(r && r.is_error) }); }
  }
  return calls;
}
// "מחטים" לפלט ארוך שקוצר: מה שהדיווח מצטט (`…`) ותגיות בסוגריים מהמשימה ([ERROR]) — שורות מהחלק שקוצר שמכילות אותן נשמרות,
// כדי שהבודק יראה את הראיה שעליה Claude מסתמך גם כשהפלט ארוך (למשל שורת ERROR בשורה 2156 של לוג)
function needlesOf(report, task) {
  const n = new Set();
  for (const m of String(report || '').matchAll(/`([^`\n]{4,160})`/g)) n.add(m[1].trim());
  for (const m of String(task || '').matchAll(/\[[A-Z]{3,12}\]/g)) n.add(m[0]);
  return [...n].filter(x => x.length >= 4).slice(0, 40);
}
function clipKeep(s, n, needles) {
  s = String(s == null ? '' : s); if (s.length <= n) return s;
  const a = Math.floor(n * 0.65), b = n - a, mid = s.slice(a, s.length - b);
  const keep = []; if (needles && needles.length) { const lines = mid.split('\n'); for (const l of lines) { if (keep.length >= 25) break; if (needles.some(x => l.includes(x))) keep.push(l.length > 300 ? l.slice(0, 300) + '…' : l); } }
  return s.slice(0, a) + `\n…[${s.length - n} chars cut${keep.length ? `; ${keep.length} line(s) from the cut part that contain text the report quotes or the task's [TAGS]:` : ']…'}` + (keep.length ? '\n' + keep.join('\n') + '\n]…' : '') + '\n' + s.slice(-b);
}
function renderEvidence(calls, budget = 40000, needles = []) {
  if (!calls.length) return '(none — the checker ran NO tool at all in this round)';
  const per = Math.max(600, Math.floor(budget / calls.length) - 300);
  return calls.map((c, i) => `[${i + 1}] ${c.name} ${clip(JSON.stringify(c.input), 700)}\n→ ${c.output == null ? '(no output recorded)' : (c.isError ? '(ERROR) ' : '') + clipKeep(c.output, per, needles)}`).join('\n\n');
}
function buildPrompt({ task, calls, report, status }) {
  const st = status === 'ok' ? '"סטטוס: תקין" (= every item is OK)' : status === 'warn' ? '"סטטוס: לא תקין" (= at least one item is not OK)' : 'a status line';
  return `${MARK}
An automated "watch" round just ended. A checker (another AI) had to check every item of the owner's TASK and write a report: one line per item — "✅" means the item meets the TASK's rule, "❌" means it does not (or could not be checked). It ended the report with ${st}. Your job: audit the report INDEPENDENTLY, using ONLY the tool outputs below as evidence.

TASK (the owner's standing task):
<<<
${clip(task, 6000)}
>>>

WHAT THE CHECKER ACTUALLY RAN IN THIS ROUND — every tool call with its exact output, in order. This is the only evidence; a claim in the report counts only if an output here shows it:
<<<
${renderEvidence(calls, 40000, needlesOf(report, task))}
>>>

THE CHECKER'S FINAL REPORT:
<<<
${clip(report, 8000)}
>>>

Step 1 — list the CHECK items: only things the TASK asks to be TRUE about the world (a file's content, a value, a service answering, a number vs a threshold, something that must or must not exist). Asking the checker to WRITE / SAY / REMIND / SUMMARIZE something is NOT a check item: it is satisfied by the report itself. Do not invent items the TASK does not state (for example "the reminder must be scheduled" — scheduling is the app's job). If there are no check items at all, items is [] and the verdict is "ok".
Step 2 — for each check item decide its REAL state from the outputs only:
- "ok" only if an output above shows its real value AND that value satisfies the task's own rule exactly (thresholds are exact: 91% is NOT below 90%; 500MB is NOT at least 512MB; 85% IS below 90%).
- "not_ok" if an output shows a value that breaks the rule (or the file the task needs does not exist).
- "not_checked" if no output above shows it, or the command for it failed. A cut output ("…[N chars cut]…") cannot prove that something is ABSENT from the part that was cut.
- An item that was wrong but the checker fixed it is "ok" only if a LATER output (after the fix) shows the fixed value; "fixed" without a later output = "not_checked".
- If the task forbids changing files and the checker changed one, the item it changed is "not_ok".
- An output marked [image] is a picture you cannot see: accept a claim based on it only if the report describes what it showed and nothing contradicts it.
Step 3 — for each check item, read the REPORT and write the mark it gives that item: "✅", "❌", "both" (the item appears with both marks, or a line has both, or a ❌ line whose own words say the item passes, or a ✅ line whose own words say it fails), or "none" (no marked line for it).
Step 4 — list UNSUPPORTED FACTS, only of these three kinds:
  (a) CONTRADICTED: a value, count or quote that an output above shows differently (the report says 42% but the output says 91%; says 149 lines but the outputs show 150).
  (b) NEVER READ IN THIS ROUND: a quote or value from a file/command that no tool call in this round read or ran at all (for example text copied from an earlier round's report).
  (c) CHECK NEVER DONE: the report says it did a check that no tool call performed — "re-read after the fix" with no later read, "searched for the word X" when no command searched for X, "verified all N lines" when no command covered the whole file, "I changed nothing" when a write/edit tool was used.
  Do NOT list: anything that an output could contain in a part that was cut ("…[N chars cut]…" — you cannot see it), counts the CLI reports about a file it read (line totals), the marks themselves, reasoning, advice, wording/style, or anything that follows from an output (grep printed nothing → "0 lines"; grep -v "[INFO]" printed nothing → "all lines are [INFO]"). When unsure, do not list it — and never list a fact that you then find is supported. Quote the report's exact words. If there are none, unsupported is [].

Answer with ONLY this JSON object (no markdown, no prose):
{"items":[{"item":"<short name of the task item>","state":"ok"|"not_ok"|"not_checked","mark":"✅"|"❌"|"both"|"none","evidence":"<the exact value you saw in an output, or why it is missing>"}],"unsupported":[{"claim":"<the report's exact words>","why":"<short: what the outputs show instead>"}],"verdict":"ok"|"not_ok","reason":"<only if not_ok: ONE short sentence in the TASK's language naming the item and what is wrong>"}
verdict = "ok" only when every check item's state is "ok" (or there are no check items).`;
}
const normMark = m => { m = String(m || '').trim().toLowerCase(); return /^(✅|ok|check|pass)/.test(m) ? '✅' : /^(❌|x|not_ok|fail|cross)/.test(m) ? '❌' : /^both/.test(m) ? 'both' : 'none'; };
// שגיאת סימון: הסימון בדיווח לא תואם את מה שהפלטים מראים. ❌ על פריט שלא ניתן לאמת (not_checked) — לא שגיאה (זה הכיוון הבטוח)
function markErrorsOf(items) {
  const out = [];
  for (const x of items) {
    if (x.state === 'ok' && x.mark !== '✅') out.push({ item: x.item, mark: x.mark, should: '✅', evidence: x.evidence });
    else if (x.state === 'not_ok' && x.mark !== '❌') out.push({ item: x.item, mark: x.mark, should: '❌', evidence: x.evidence });
    else if (x.state === 'not_checked' && x.mark !== '❌') out.push({ item: x.item, mark: x.mark, should: '❌', evidence: x.evidence });
  }
  return out;
}
function parse(text) {
  const s = String(text || ''); const a = s.indexOf('{'), b = s.lastIndexOf('}'); if (a < 0 || b <= a) return null;
  let j; try { j = JSON.parse(s.slice(a, b + 1)); } catch { return null; }
  if (!j || !/^(ok|not_ok)$/.test(j.verdict)) return null;
  const items = Array.isArray(j.items) ? j.items.filter(x => x && typeof x === 'object').map(x => ({ item: String(x.item || '').slice(0, 160), state: /^(ok|not_ok|not_checked)$/.test(x.state) ? x.state : 'not_checked', mark: x.mark == null ? null : normMark(x.mark), evidence: String(x.evidence || '').slice(0, 300) })) : [];
  // עובדה שהבודק עצמו כתב עליה שהיא נתמכת ("is supported", "no contradiction") — לא נחשבת (תשובה לא עקבית של הבודק, לא בעיה בדיווח)
  const selfOk = w => /\b(?:is|are|was|fully|thus|so|therefore)\s+supported\b|\bnot\s+unsupported\b|\bno\s+contradiction\b|\bsupported\s+by\s+(?:output|the output|tool)|נתמכ(?:ת|ים|ות)?\s+(?:בפלט|ע"י)|אין\s+סתירה/i.test(String(w || ''));
  const unsupported = Array.isArray(j.unsupported) ? j.unsupported.filter(x => x && (x.claim || x.why) && !selfOk(x.why)).map(x => ({ claim: String(x.claim || '').slice(0, 240), why: String(x.why || '').slice(0, 240) })).slice(0, 8) : [];
  const bad = items.filter(x => x.state !== 'ok');
  let reason = String(j.reason || '').trim().slice(0, 300);
  if (j.verdict === 'not_ok' && !bad.length && !reason) return null; // "לא תקין" בלי פריט ובלי סיבה — תשובה לא עקבית: שואלים שוב
  const verdict = j.verdict === 'not_ok' || bad.length ? 'not_ok' : 'ok'; // עקביות: פריט אחד לא תקין / לא נבדק = לא תקין, גם אם כתב ok
  if (verdict === 'not_ok' && !reason) reason = bad.length ? bad.map(x => x.item + ' — ' + (x.state === 'not_checked' ? 'לא נבדק' : 'לא תקין') + (x.evidence ? ': ' + x.evidence : '')).join('; ').slice(0, 300) : 'הבודק העצמאי מצא שלא הכל תקין';
  const marksKnown = items.every(x => x.mark);
  return { verdict, items, reason: verdict === 'ok' ? '' : reason, markErrors: marksKnown ? markErrorsOf(items) : [], unsupported };
}
// ask(prompt) → טקסט התשובה של המודל. שגיאה / תשובה לא תקינה פעמיים → unavailable (לא חוסם: הסבב נשאר כפי ש-Claude קבע, ומסומן שלא אומת)
async function audit({ task, segment, report, ask, status }) {
  const calls = evidenceOf(segment), prompt = buildPrompt({ task, calls, report, status });
  const t0 = Date.now(); let last = '';
  for (let k = 0; k < 2; k++) {
    try { last = await ask(prompt); } catch (e) { last = 'ERROR: ' + (e && e.message || e); continue; }
    const p = parse(last); if (p) return { ...p, calls: calls.length, ms: Date.now() - t0 };
  }
  return { verdict: 'unavailable', reason: 'הבודק העצמאי לא החזיר תשובה תקינה: ' + clip(last, 160), items: [], markErrors: [], unsupported: [], calls: calls.length, ms: Date.now() - t0 };
}
module.exports = { MARK, SYSTEM, audit, evidenceOf, renderEvidence, buildPrompt, parse, markErrorsOf, needlesOf };
